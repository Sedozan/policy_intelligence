# PIE — Gap-to-Done audit (2026-09-28)

Scope: audit `pie_mvp` against `claude/definition-of-done.md` (8 pillars + measurement bar),
and design automated NCCI acquisition to replace manual download + reformat.

Note: the pasted template mentioned `services/` and a "retry bug in the linked issue".
This repo has no `services/` folder and no linked issue. Adapted: one subagent per module
group, audited against the DoD pillars instead.

## Checklist
- [x] Unzip, inventory, run offline tests — 63 passed
- [x] Read core docs (README, REVIEW_BRIEF, PHASE15_CHANGES) + project docs
- [x] Subagent A — ingestion & corpus → Pillar 1: Partial (early)
- [x] Subagent B — extraction & grounding → Pillar 2: Partial; Pillar 5: Not started
- [x] Subagent C — reconciliation, detection → Pillar 3: Not started; 4: Partial; 6: Not started
- [x] Subagent D — governance & reuse → Pillar 7: Partial; 8: Partial; measurement bar: Not started
- [x] Verify each subagent's evidence — re-read cited lines: normalize L97 sorted key, extract_rules `_rules` swallow + fuller-quote overwrite + cache path, gap L61-72, migrate MODE overwrite, LOADABLE_STATUS, MAX_DETECTORS=300, PTP self-join per rule. All confirmed.
- [x] NCCI automation: CMS page verified (6 zips/quarter, txt+xlsx inside, PTP split across xlsx; slugs NOT uniform across quarters; only current + previous quarter listed)
- [x] Build + test `acquire_ncci.py` offline — 23 tests; 2M-row PTP parse 20 s / 1.8 GB
- [x] `notebooks/acquire_ncci.py`, config (`NCCI_RAW_DIR`, `NCCI_ACQUISITION_LOG`), README
- [x] Final gap table (pillar, done?, evidence) + prioritized plan → GAP_TO_DONE.md
- [x] Deliver: gap report + updated package
- [ ] (SB, on cluster) `SHOW TABLES IN main.sedo LIKE 'medicaid_ncci_edit_*'` — confirm DME token is `dme`
- [ ] (SB, on cluster) run `notebooks/acquire_ncci` — egress probe decides download vs drop zone
- [ ] Fix D1–D8 (see GAP_TO_DONE.md) — awaiting go-ahead
- [ ] Resolve D10: PTP deletion-date inclusive or exclusive (CMS Technical Guidance Manual / RISSNET)

## Found along the way
- [ ] D1 HYBRID caches unparseable model output as "no rules" (extract_rules.py:554-558)
- [ ] D2 grounding: short/unrelated quotes score 1.0; fuzzy stores non-verbatim quote; fuller-quote overwrite (:592, :816-852)
- [ ] D3 reversed PTP pair merged across editions (rule_normalize.py:97)
- [ ] D4 overlapping edition windows compile both; ambiguity_flag never blocks
- [ ] D5 stale approvals compile after doc revision; policy_change_log write-only
- [ ] D6 migrate_state_rules unguarded overwrite; review ingest logs before write
- [ ] D7 coverage counts leads/expired/uncompiled as covered (gap.py:61-65)
- [ ] D8 findings lack build_id; NCCI rule_ids change quarterly → orphaned findings
- [ ] D9 NCCI ingest silent paths (no tables → continue; blank modifier → deleted; bad eff → quarter start)
- [ ] D10 PTP deletion-date semantics unverified
- [x] Seed count is 21, not 19 (README/REVIEW_BRIEF say 19)
- [x] CMS NCCI URL slugs non-uniform across quarters; page lists only 2 quarters → must archive
- [x] Chapter registry is 31 files (29 + 10A + 11A), not 29
