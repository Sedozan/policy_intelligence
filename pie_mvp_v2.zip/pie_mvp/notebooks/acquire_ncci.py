# Databricks notebook source
# MAGIC %md
# MAGIC # Acquire NCCI — CMS Medicaid NCCI quarterly files → `main.sedo` tables (no manual reformatting)
# MAGIC
# MAGIC Replaces: download 6 zips by hand → open → rename/reformat columns → load one table per file.
# MAGIC
# MAGIC | step | what happens | fails loudly when |
# MAGIC |---|---|---|
# MAGIC | 1 | probe egress to cms.gov | cluster cannot reach the internet → switch to the drop zone (below) |
# MAGIC | 2 | read the CMS page, **discover** zip links (slugs differ quarter to quarter, so URLs are never built) | a quarter lacks one of the 6 files; CMS adds a link we cannot classify |
# MAGIC | 3 | download → `NCCI_RAW_DIR/<YYYY>q<N>/` (kept forever, SHA-256 logged) | CMS returns an HTML page instead of a zip |
# MAGIC | 4 | parse text file (Excel fallback), locate header, map columns to the **same names as the hand-loaded tables** | missing column, bad date, bad modifier indicator, non-numeric MUE, file quarter ≠ link quarter |
# MAGIC | 5 | write `medicaid_ncci_edit_<service>_<ptp\|mue>_q<N>_<YYYY>` | table already exists (skipped, never overwritten unless `OVERWRITE = True`) |
# MAGIC | 6 | log every file to `ncci_acquisition_log`; report missing quarters | any file failed → the notebook ends red (so a scheduled Job alerts) |
# MAGIC
# MAGIC **No egress?** Download the zips from the CMS page by hand into `NCCI_RAW_DIR` (any sub-folder), keep
# MAGIC the CMS file names, set `DOWNLOAD = False`. Steps 4–6 are the same.
# MAGIC
# MAGIC **Schedule:** a Databricks Job on this notebook, monthly (e.g. 5th of each month). CMS posts a quarter about a
# MAGIC month before it takes effect and keeps only two quarters on the page; a missed quarter is a permanent MUE gap,
# MAGIC and `mue_history` will then refuse to build. Re-runs are idempotent.
# MAGIC
# MAGIC **Then:** `preflight_ncci` → `build_kb`.

# COMMAND ----------

import os, sys
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
import config, acquire_ncci as acq, ingest_ncci_tables as ing, kb_io
for m in (config, acq, ing, kb_io):
    importlib.reload(m)

# ---- parameters
DOWNLOAD         = True                    # False = read zips already in NCCI_RAW_DIR (drop zone)
OVERWRITE        = False                   # True replaces an existing quarter table - destructive, leave False
QUARTERS         = None                    # e.g. {"2026q4"}; None = every quarter listed on the page / in the drop zone
CROSS_CHECK_XLSX = False                   # also parse the Excel copy and require the same row count (slow for PTP)
RAW_DIR          = config.NCCI_RAW_DIR
LOG_TABLE        = config.NCCI_ACQUISITION_LOG
CAT, SCH         = config.CATALOG, config.SCHEMA
os.makedirs(RAW_DIR, exist_ok=True)
print("raw archive:", RAW_DIR)

# COMMAND ----------

# MAGIC %md ## 1–2. Egress probe and link discovery

session = acq.make_session() if DOWNLOAD else None
if DOWNLOAD:
    ok, detail = acq.probe_egress(session)
    print(f"egress to cms.gov: {'OK' if ok else 'BLOCKED'} - {detail}")
    if not ok:
        raise RuntimeError("This cluster cannot reach cms.gov. Either run on compute with internet egress, or "
                           f"download the zips by hand into {RAW_DIR} and set DOWNLOAD = False.")
    html = acq._get(session, acq.CMS_PAGE).text
    links = acq.discover_links(html)
else:
    links = acq.links_from_drop_zone(RAW_DIR)

unknown = [l for l in links if l.kind == "unknown"]
edits = [l for l in links if l.kind == "edits"]
print(f"{len(edits)} edit files, {sum(l.kind == 'change_report' for l in links)} change reports, {len(unknown)} unclassified")
for l in sorted(edits, key=lambda l: (l.label, l.edit, l.service)):
    print(f"  {l.label}  {l.edit}  {l.service:12s}  {l.url.rsplit('/', 1)[-1]}")
for l in unknown:
    print(f"  UNCLASSIFIED (review - CMS may have changed naming): {l.url}")
incomplete = acq.check_quarter_complete(links)
for q, miss in incomplete.items():
    print(f"  WARNING {q} is missing {miss}")
assert edits, "no NCCI edit files found - check the page / drop zone before going further"

# COMMAND ----------

# MAGIC %md ## 3–5. Download, parse, validate, load

existing = ing.discover_tables(spark, CAT, SCH)
prev_counts = {}
for m in existing:                           # latest existing table per (edit, service) = the row-count baseline
    prev_counts[f"{m['edit_type']}/{m['service']}"] = m["fqn"]
prev_counts = {k: spark.table(v).count() for k, v in prev_counts.items()}

results = acq.acquire(spark, links, RAW_DIR, CAT, SCH, download_files=DOWNLOAD, overwrite=OVERWRITE,
                      session=session, quarters=QUARTERS, cross_check_xlsx=CROSS_CHECK_XLSX,
                      prev_counts=prev_counts)
res = acq.results_frame(results)
kb_io.write_table(spark, res, LOG_TABLE, mode="append")
display(res[["quarter", "edit", "service", "status", "rows", "fmt", "warning", "error", "sha256"]])

# COMMAND ----------

# MAGIC %md ## 6. Completeness and go / no-go

after = ing.discover_tables(spark, CAT, SCH)
by = {}
for m in after:
    by.setdefault((m["service"], m["edit_type"]), []).append((m["year"], m["quarter"]))
print("quarters loaded (service, edit): missing between first loaded and the current quarter")
for k in sorted(by):
    miss = acq.missing_quarters(by[k])
    print(f"  {k[0]:12s} {k[1]}  {len(by[k])} loaded, latest {max(by[k])}  missing: {miss or 'none'}")

failed = res[res["status"] == "failed"]
warned = res[res["warning"].notna()]
if len(warned):
    print(f"\n{len(warned)} file(s) loaded WITH WARNINGS - read them before build_kb:")
    for _, r in warned.iterrows():
        print(f"  {r['quarter']} {r['edit']}/{r['service']}: {r['warning']}")
if len(failed):
    raise RuntimeError(f"{len(failed)} NCCI file(s) failed; nothing else was affected. "
                       + "; ".join(f"{r['quarter']} {r['edit']}/{r['service']}: {r['error'][:200]}" for _, r in failed.iterrows()))
print("\nGO: next run preflight_ncci, then build_kb.")
