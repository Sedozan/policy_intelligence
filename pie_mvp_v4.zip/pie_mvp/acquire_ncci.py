"""
acquire_ncci.py  -  CMS Medicaid NCCI quarterly files -> raw archive -> main.sedo Delta tables.

Replaces the manual loop (download 6 zips, open, reformat columns, load a table per file).
Output tables use the SAME names and column names as the hand-loaded ones, so
ingest_ncci_tables.discover_tables / ptp_rules / mue_history need no change:

    main.sedo.medicaid_ncci_edit_<practitioner|outpatient|dme>_<ptp|mue>_q<N>_<YYYY>

Facts this module is built on (checked against the live CMS page, 2026-09-28):
  * Page: https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files
  * 6 zips per quarter (PTP + MUE x practitioner / outpatient hospital / DME) + a change report.
  * Each zip holds text AND Excel; large PTP files are split across several workbooks.
  * PTP layout: Quarter Begin Date, Category, Column One, Column Two, Effective Date,
    Deletion Date, Modifier Indicator, PTP Edit Rationale.
    MUE layout: Quarter Begin Date, Category, HCPCS/CPT code, MUE Value, MUE Rationale.
  * URL slugs are NOT uniform across quarters (2026Q3 outpatient is
    "...-ptp-edits-hospital-outpatient-services.zip", 2026Q4 is "...-outpatient-hospital-services.zip";
    2026Q3 DME PTP drops "-services"). So links are DISCOVERED from the page, never built.
  * The page lists only the current and previous quarter. A quarter not captured while it is
    listed is gone from this source -> run this on a schedule, and archive every zip.

Not verified (sandbox cannot reach cms.gov): the exact preamble/header rows inside the text
file and the delimiter. The parser therefore LOCATES the header row and SNIFFS the delimiter,
and fails loudly (ParseError) instead of guessing when the layout is not what it expects.

Design rules (same spirit as kb_io.table_or_none):
  * Nothing is silently dropped: bad dates, bad modifier indicators, non-numeric MUE values,
    a quarter-begin date that disagrees with the link, or an HTML page saved as a .zip -> raise.
  * Nothing is silently overwritten: an existing table is skipped unless overwrite=True.
  * Raw zips are kept forever, hashed, under <data>/ncci_raw/<YYYY>q<N>/.
  * Retries only on transient failures (connection errors, 429, 5xx), bounded, with backoff.
    A 403/404 is not retried - it means blocked or moved, and retrying hides that.
"""
from __future__ import annotations

import csv
import hashlib
import io
import os
import re
import time
import zipfile
from dataclasses import dataclass, field, asdict
from datetime import date, datetime, timezone
from html import unescape
from urllib.parse import urljoin

import pandas as pd

CMS_PAGE = "https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files"
USER_AGENT = "Mozilla/5.0 (compatible; PIE-NCCI-acquire/1.0; +policy-intelligence)"
TABLE_TEMPLATE = "medicaid_ncci_edit_{service}_{edit}_q{quarter}_{year}"
QUARTER_START = {1: (1, 1), 2: (4, 1), 3: (7, 1), 4: (10, 1)}

# Service keys MUST match the existing table names (ingest regex is [a-z]+).
SERVICE_KEYWORDS = [                     # checked in order; first hit wins
    ("dme", ("durable-medical-equipment", "durable medical equipment", "-dme")),
    ("outpatient", ("outpatient",)),
    ("practitioner", ("practitioner",)),
]

# Output column names = the names in SB's hand-loaded tables (exact-match in ingest._find_col).
PTP_COLUMNS = {
    "QuarterBeginDate": ("quarterbegin",),
    "Category": ("category",),
    "Col1": ("column1", "columnone", "col1", "comprehensive"),
    "Col2": ("column2", "columntwo", "col2", "component"),
    "PriorTo1996Flag": ("1996",),                      # Medicare layout only; kept if present
    "EffDt": ("effective",),
    "DelDt": ("deletion",),
    "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable": ("modifier",),
    "PTP_Edit_Rationale": ("rationale",),
}
PTP_REQUIRED = ("Col1", "Col2", "EffDt", "DelDt",
                "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable")

MUE_COLUMNS = {
    "QuarterBeginDate": ("quarterbegin",),
    "Category": ("category",),
    "HCPCS_CPT_Code": ("hcpcs", "cptcode"),
    "MUE_Values": ("muevalue",),
    "MUE_Adjudication_Indicator": ("adjudication", "mai"),
    "MUE_Rationale": ("rationale",),
}
MUE_REQUIRED = ("HCPCS_CPT_Code", "MUE_Values")

PROVENANCE_COLUMNS = ["src_zip", "src_sha256", "src_member", "src_url", "loaded_at"]

CODE_RE = re.compile(r"^[A-Z0-9]{5}$")                 # CPT / HCPCS Level II
MAX_NON_DATA_ROWS = 50                                  # preamble/footer lines tolerated


class ParseError(ValueError):
    """The file is not in the layout this module was built for. Never guess past it."""


class DownloadError(RuntimeError):
    """The file could not be fetched, or what came back is not a zip."""


# ------------------------------------------------------------------ discovery
@dataclass
class Link:
    url: str
    text: str
    kind: str                     # "edits" | "change_report" | "unknown"
    edit: str | None = None       # "ptp" | "mue"
    service: str | None = None    # "practitioner" | "outpatient" | "dme"
    year: int | None = None
    quarter: int | None = None

    @property
    def label(self) -> str:
        return f"{self.year}q{self.quarter}" if self.year else "unknown"

    @property
    def table(self) -> str | None:
        if self.kind != "edits":
            return None
        return TABLE_TEMPLATE.format(service=self.service, edit=self.edit,
                                     quarter=self.quarter, year=self.year)


_HREF_RE = re.compile(r"""<a\b[^>]*?href\s*=\s*["']([^"']+?\.zip)["'][^>]*>(.*?)</a>""", re.I | re.S)
_YQ_RE = re.compile(r"(20\d{2})[\s_-]*q([1-4])", re.I)
_EFF_RE = re.compile(r"effective[\s_-]*(\d{2})(\d{2})(20\d{2})", re.I)


def _classify(url: str, text: str) -> Link:
    blob = f"{url} {text}".lower()
    link = Link(url=url, text=re.sub(r"\s+", " ", unescape(re.sub(r"<[^>]+>", " ", text))).strip(),
                kind="unknown")
    m = _YQ_RE.search(blob)
    if m:
        link.year, link.quarter = int(m.group(1)), int(m.group(2))
    if "change-report" in blob or "change report" in blob:
        link.kind = "change_report"
        if not m:
            e = _EFF_RE.search(blob)
            if e:
                mm, yy = int(e.group(1)), int(e.group(3))
                link.year, link.quarter = yy, (mm - 1) // 3 + 1
        return link
    edit = "ptp" if "ptp" in blob else "mue" if "mue" in blob else None
    service = next((key for key, kws in SERVICE_KEYWORDS if any(k in blob for k in kws)), None)
    if edit and service and link.year:
        link.kind, link.edit, link.service = "edits", edit, service
    return link


def discover_links(html: str, base: str = CMS_PAGE) -> list[Link]:
    """Every .zip link on the page, classified. Unclassifiable links are returned with
    kind='unknown' so the caller REPORTS them (a new CMS naming scheme must be seen)."""
    seen, out = set(), []
    for href, text in _HREF_RE.findall(html):
        url = urljoin(base, unescape(href.strip()))
        if url in seen:
            continue
        seen.add(url)
        out.append(_classify(url, text))
    return out


def check_quarter_complete(links: list[Link]) -> dict[str, list[str]]:
    """{'2026q4': [missing 'ptp/dme', ...]} - a quarter should have all 6 edit files."""
    want = {(e, s) for e in ("ptp", "mue") for s, _ in SERVICE_KEYWORDS}
    have: dict[str, set] = {}
    for l in links:
        if l.kind == "edits":
            have.setdefault(l.label, set()).add((l.edit, l.service))
    return {q: sorted(f"{e}/{s}" for e, s in want - got) for q, got in have.items() if want - got}


# ------------------------------------------------------------------- network
def make_session():
    import requests
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT})
    return s


def _get(session, url: str, timeout: int = 120, attempts: int = 4, backoff: float = 2.0,
         sleep=time.sleep):
    """GET with bounded retries on TRANSIENT failures only. Returns the response."""
    last = None
    for i in range(attempts):
        try:
            r = session.get(url, timeout=timeout)
        except Exception as e:                            # connection reset, DNS, timeout
            last = f"{type(e).__name__}: {e}"
        else:
            if r.status_code == 200:
                return r
            if r.status_code not in (429, 500, 502, 503, 504):
                raise DownloadError(f"GET {url} -> HTTP {r.status_code} (not retried: "
                                    f"{'blocked by egress/WAF' if r.status_code == 403 else 'not transient'})")
            last = f"HTTP {r.status_code}"
        if i < attempts - 1:
            sleep(backoff * (2 ** i))
    raise DownloadError(f"GET {url} failed after {attempts} attempts; last error: {last}")


def probe_egress(session=None, url: str = CMS_PAGE) -> tuple[bool, str]:
    """(ok, detail). Run first: most locked-down clusters fail here, not later."""
    try:
        r = _get(session or make_session(), url, timeout=30, attempts=1)
        return True, f"HTTP 200, {len(r.content):,} bytes"
    except Exception as e:
        return False, str(e)[:400]


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def archive_path(raw_dir: str, link: Link) -> str:
    return os.path.join(raw_dir, link.label, os.path.basename(link.url))


def download(link: Link, raw_dir: str, session=None, force: bool = False) -> dict:
    """Fetch one zip into the archive. Idempotent: an archived file is reused, not refetched."""
    dest = archive_path(raw_dir, link)
    if os.path.exists(dest) and not force:
        _assert_zip(dest)
        return {"path": dest, "sha256": sha256_file(dest), "bytes": os.path.getsize(dest), "status": "archived"}
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    r = _get(session or make_session(), link.url)
    data = r.content
    if not data.startswith(b"PK"):
        head = data[:120].decode("latin-1", "replace").replace("\n", " ")
        raise DownloadError(f"{link.url} did not return a zip (got {len(data):,} bytes starting {head!r}) - "
                            f"usually a WAF/interstitial page; download it by hand into {os.path.dirname(dest)}")
    tmp = dest + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, dest)                                  # never leave a half-written zip under the real name
    return {"path": dest, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "status": "downloaded"}


def _assert_zip(path: str):
    with open(path, "rb") as f:
        if f.read(2) != b"PK":
            raise DownloadError(f"{path} is not a zip (an HTML error page saved as .zip?) - delete it and refetch")


def links_from_drop_zone(raw_dir: str) -> list[Link]:
    """No egress? Download the zips by hand into <raw_dir>/<anything>/ (or raw_dir itself).
    File names carry year/quarter/edit/service, so they classify exactly like page links."""
    out = []
    for root, _, files in os.walk(raw_dir):
        for fn in sorted(files):
            if fn.lower().endswith(".zip"):
                out.append(_classify(os.path.join(root, fn), fn))
    return out


# -------------------------------------------------------------------- parsing
def _norm(s) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def _map_header(cells: list, spec: dict) -> dict[int, str]:
    """{position: canonical name}. Unknown headers keep a sanitized name (as-delivered)."""
    out, used = {}, set()
    for i, raw in enumerate(cells):
        n = _norm(raw)
        if not n:
            continue
        canon = next((c for c, keys in spec.items() if c not in used and any(k in n for k in keys)), None)
        if canon is None:
            canon = re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")[:60] or f"col_{i}"
        used.add(canon)
        out[i] = canon
    return out


def _find_header(rows: list[list], spec: dict, required: tuple, scan: int = 60) -> tuple[int, dict, int]:
    """Locate the header row (optionally continued on the next row, as CMS Excel headers often are).
    Returns (row index, {pos: canonical}, header height)."""
    for i, row in enumerate(rows[:scan]):
        for height in (1, 2):
            if i + height > len(rows):
                continue
            if height == 1:
                cells = row
            else:
                nxt = rows[i + 1]
                width = max(len(row), len(nxt))
                cells = [f"{row[j] if j < len(row) else ''} {nxt[j] if j < len(nxt) else ''}" for j in range(width)]
            mapping = _map_header(cells, spec)
            if all(r in mapping.values() for r in required):
                return i, mapping, height
    raise ParseError(f"no header row with {list(required)} in the first {scan} rows; "
                     f"first rows seen: {[r[:6] for r in rows[:5]]}")


def _text_rows(data: bytes) -> list[list[str]]:
    try:
        txt = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        txt = data.decode("latin-1")
    lines = txt.splitlines()
    sample = "\n".join(l for l in lines[:80] if l.strip())
    delim = None
    for d in ("\t", "|", ","):                               # CMS text files: tab first
        if sum(l.count(d) >= 3 for l in sample.splitlines()) >= 3:
            delim = d
            break
    if delim is None:
        raise ParseError("could not detect a delimiter (tab, pipe, comma) in the text file")
    return [row for row in csv.reader(lines, delimiter=delim)]


def _xlsx_rows(data: bytes) -> list[list]:
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    rows = []
    for ws in wb.worksheets:
        for r in ws.iter_rows(values_only=True):
            rows.append(["" if v is None else v for v in r])
    wb.close()
    return rows


def _to_yyyymmdd(v) -> int | None:
    """CMS dates: 20250101 / 20250101.0 / 1/1/2025 / 2025-01-01 / Excel datetime. '*' or blank = none."""
    if v is None:
        return None
    if isinstance(v, (datetime, date)):
        return v.year * 10000 + v.month * 100 + v.day
    s = str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    if s in ("", "*", "nan", "NaT", "None"):
        return None
    if re.fullmatch(r"\d{8}", s):
        int(datetime.strptime(s, "%Y%m%d").strftime("%Y%m%d"))   # validates the calendar date
        return int(s)
    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%y"):
        try:
            d = datetime.strptime(s, fmt)
            return d.year * 10000 + d.month * 100 + d.day
        except ValueError:
            pass
    raise ValueError(s)


def _code(v) -> str:
    """Excel stores 01996 as the number 1996; a text file keeps the string."""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, int) or (isinstance(v, float) and v == v and v.is_integer()):
        return str(int(v)).zfill(5)
    return str(v).strip().upper()


def _dates_to_int(s: pd.Series) -> tuple[pd.Series, list]:
    """Vectorised fast path for yyyymmdd (the bulk of CMS rows); per-value fallback for the rest."""
    txt = s.map(lambda v: "" if v is None else (v.strftime("%Y%m%d") if isinstance(v, (datetime, date)) else str(v)))
    txt = txt.str.strip().str.replace(r"\.0$", "", regex=True)
    out = pd.Series(pd.NA, index=s.index, dtype="Int64")
    blank = txt.isin(["", "*", "nan", "NaT", "None"])
    ymd = txt.str.fullmatch(r"\d{8}")
    ok = ymd & pd.to_datetime(txt.where(ymd), format="%Y%m%d", errors="coerce").notna()
    out[ok] = txt[ok].astype("int64")
    errs = []
    for i in txt.index[~ok & ~blank]:
        try:
            out[i] = _to_yyyymmdd(txt[i])
        except ValueError:
            errs.append(txt[i])
    return out, errs[:5] + ([f"({len(errs)} rows)"] if errs else [])


def frame_from_rows(rows: list[list], edit: str) -> tuple[pd.DataFrame, dict]:
    """Rows of one member file -> canonical frame + parse stats. Raises ParseError on anything off."""
    spec, required = (PTP_COLUMNS, PTP_REQUIRED) if edit == "ptp" else (MUE_COLUMNS, MUE_REQUIRED)
    hi, mapping, height = _find_header(rows, spec, required)
    body = rows[hi + height:]
    pos = sorted(mapping)
    cols = [mapping[i] for i in pos]
    raw = pd.DataFrame(body) if body else pd.DataFrame()
    df = pd.DataFrame({mapping[i]: (raw[i] if i in raw.columns else "") for i in pos}, columns=cols)
    df = df.fillna("")

    code_cols = ["Col1", "Col2"] if edit == "ptp" else ["HCPCS_CPT_Code"]
    for c in code_cols:
        df[c] = df[c].map(_code)
    is_data = pd.Series(True, index=df.index)
    for c in code_cols:
        is_data &= df[c].str.match(CODE_RE.pattern)
    non_data = df[~is_data]
    # blank lines and footers are fine; a body full of non-codes means a misread layout
    non_blank = non_data[(non_data[code_cols].astype(str).apply(lambda s: s.str.strip()) != "").any(axis=1)]
    if len(non_blank) > MAX_NON_DATA_ROWS:
        raise ParseError(f"{len(non_blank):,} body rows have a code column that is not a 5-char CPT/HCPCS code; "
                         f"examples: {non_blank.head(3).to_dict('records')}")
    df = df[is_data].reset_index(drop=True)
    if df.empty:
        raise ParseError("header found but no data rows")

    bad: dict[str, list] = {}
    date_cols = [c for c in ("QuarterBeginDate", "EffDt", "DelDt") if c in df.columns]
    for c in date_cols:
        df[c], errs = _dates_to_int(df[c])
        if errs:
            bad[c] = errs
    if edit == "ptp":
        if df["EffDt"].isna().any():
            bad.setdefault("EffDt", []).append(f"{int(df['EffDt'].isna().sum())} blank effective dates")
        mc = "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable"
        df[mc] = df[mc].map(lambda v: str(v).strip()[:1] if str(v).strip() else "")
        badm = df.loc[~df[mc].isin(["0", "1", "9"]), mc]
        if len(badm):
            bad[mc] = badm.head(5).tolist() + [f"({len(badm)} rows)"]
    else:
        vals = pd.to_numeric(df["MUE_Values"].map(lambda v: str(v).strip()), errors="coerce")
        badv = df.loc[vals.isna() | (vals < 0) | (vals % 1 != 0), "MUE_Values"]
        if len(badv):
            bad["MUE_Values"] = badv.head(5).tolist() + [f"({len(badv)} rows)"]
        df["MUE_Values"] = vals.astype("Int64")
    if bad:
        raise ParseError(f"unparseable values (not dropped, fix or report): { {k: v[:6] for k, v in bad.items()} }")

    for c in df.columns:
        if c not in date_cols and c != "MUE_Values":
            df[c] = df[c].map(lambda v: None if v is None or str(v).strip() == "" else str(v).strip())
    stats = {"header_row": hi, "header_height": height, "rows": len(df), "non_data_rows_skipped": len(non_blank),
             "non_data_examples": non_blank.head(3)[code_cols].values.tolist(), "columns": cols}
    return df, stats


def parse_zip(path: str, edit: str, expected_quarter: tuple[int, int] | None = None,
              prefer: str = "txt", cross_check_xlsx: bool = False) -> tuple[pd.DataFrame, dict]:
    """All member files of the preferred format, concatenated. Excel is the fallback (and the
    optional cross-check: same row count from both formats = the text parse is complete)."""
    _assert_zip(path)
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if not n.endswith("/") and not os.path.basename(n).startswith(("~", "."))]
        txt = sorted(n for n in names if n.lower().endswith((".txt", ".csv")))
        xls = sorted(n for n in names if n.lower().endswith(".xlsx"))
        order = [("txt", txt), ("xlsx", xls)] if prefer == "txt" else [("xlsx", xls), ("txt", txt)]
        fmt, members = next(((f, m) for f, m in order if m), (None, []))
        if not members:
            raise ParseError(f"{os.path.basename(path)}: no .txt/.csv/.xlsx inside; members: {names}")
        frames, per_member = [], []
        for n in members:
            rows = _text_rows(z.read(n)) if fmt == "txt" else _xlsx_rows(z.read(n))
            try:
                df, st = frame_from_rows(rows, edit)
            except ParseError as e:
                raise ParseError(f"{os.path.basename(path)}::{n}: {e}") from None
            df["src_member"] = n
            frames.append(df)
            per_member.append({"member": n, **st})
        df = pd.concat(frames, ignore_index=True)
        stats = {"format": fmt, "members": per_member, "rows": len(df)}
        if cross_check_xlsx and fmt == "txt" and xls:
            n_x = sum(frame_from_rows(_xlsx_rows(z.read(n)), edit)[0].shape[0] for n in xls)
            stats["xlsx_rows"] = n_x
            if n_x != len(df):
                raise ParseError(f"{os.path.basename(path)}: text has {len(df):,} rows, Excel has {n_x:,}")

    if expected_quarter and "QuarterBeginDate" in df.columns:
        y, q = expected_quarter
        mo, d = QUARTER_START[q]
        want = y * 10000 + mo * 100 + d
        got = sorted({int(v) for v in df["QuarterBeginDate"].dropna().unique()})
        if got and got != [want]:
            raise ParseError(f"{os.path.basename(path)}: Quarter Begin Date {got} but the link says {y}Q{q} ({want})")
    return df, stats


# ------------------------------------------------------------------- checks
def compare_to_previous(new_rows: int, prev_rows: int | None, max_drop: float = 0.20) -> str | None:
    """A quarter that loses >20% of rows vs the previous one is almost always a partial parse."""
    if prev_rows and new_rows < prev_rows * (1 - max_drop):
        return f"row count fell {prev_rows:,} -> {new_rows:,} ({1 - new_rows / prev_rows:.0%}); check before trusting"
    return None


def current_quarter(today: date | None = None) -> tuple[int, int]:
    t = today or date.today()
    return t.year, (t.month - 1) // 3 + 1


def missing_quarters(loaded: list[tuple[int, int]], today: date | None = None) -> list[str]:
    """Quarters between the earliest loaded and the current one that have no table."""
    if not loaded:
        return []
    y, q = min(loaded)
    cy, cq = current_quarter(today)
    have, out = set(loaded), []
    while (y, q) <= (cy, cq):
        if (y, q) not in have:
            out.append(f"{y}Q{q}")
        y, q = (y + 1, 1) if q == 4 else (y, q + 1)
    return out


# ------------------------------------------------------------------- writing
def to_spark_fast(spark, df: pd.DataFrame):
    """Arrow-backed createDataFrame with an explicit schema (kb_io.to_spark is row-by-row and
    too slow for ~2M PTP rows). Dates stay int yyyymmdd, like the hand-loaded tables."""
    from pyspark.sql import types as T
    fields = []
    for c in df.columns:
        if c in ("QuarterBeginDate", "EffDt", "DelDt"):
            t = T.IntegerType()
        elif c == "MUE_Values":
            t = T.LongType()
        else:
            t = T.StringType()
        fields.append(T.StructField(c, t, True))
    spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")
    pdf = df.astype(object).where(df.notna(), None)
    return spark.createDataFrame(pdf, schema=T.StructType(fields))


def table_exists(spark, fqn: str) -> bool:
    return bool(spark.catalog.tableExists(fqn))


@dataclass
class LoadResult:
    quarter: str
    edit: str | None
    service: str | None
    kind: str
    url: str
    table: str | None = None
    status: str = ""                 # loaded | skipped_exists | archived_only | failed
    sha256: str | None = None
    bytes: int | None = None
    rows: int | None = None
    fmt: str | None = None
    members: str | None = None
    warning: str | None = None
    error: str | None = None
    loaded_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="seconds"))


def acquire(spark, links: list[Link], raw_dir: str, catalog: str, schema: str, *,
            download_files: bool = True, overwrite: bool = False, session=None,
            quarters: set[str] | None = None, cross_check_xlsx: bool = False,
            prev_counts: dict[str, int] | None = None, log=print) -> list[LoadResult]:
    """Download (or read from the drop zone), parse, validate and load every edit file.
    One file's failure is recorded and does not stop the others; the caller decides go/no-go."""
    session = session or (make_session() if download_files else None)
    results: list[LoadResult] = []
    for l in links:
        if quarters and l.label not in quarters:
            continue
        res = LoadResult(quarter=l.label, edit=l.edit, service=l.service, kind=l.kind, url=l.url, table=l.table)
        try:
            if download_files and l.url.startswith("http"):
                got = download(l, raw_dir, session)
            else:
                _assert_zip(l.url)
                got = {"path": l.url, "sha256": sha256_file(l.url), "bytes": os.path.getsize(l.url),
                       "status": "drop_zone"}
            res.sha256, res.bytes = got["sha256"], got["bytes"]
            if l.kind != "edits":
                res.status = "archived_only"
                results.append(res)
                log(f"  {l.label} {l.kind:13s} archived ({got['status']})")
                continue
            fqn = f"{catalog}.{schema}.{l.table}"
            if spark is not None and table_exists(spark, fqn) and not overwrite:
                res.status = "skipped_exists"
                results.append(res)
                log(f"  {l.label} {l.edit}/{l.service:12s} table exists - not overwritten ({fqn})")
                continue
            df, st = parse_zip(got["path"], l.edit, (l.year, l.quarter), cross_check_xlsx=cross_check_xlsx)
            df["src_zip"] = os.path.basename(got["path"])
            df["src_sha256"] = got["sha256"]
            df["src_url"] = l.url if l.url.startswith("http") else None
            df["loaded_at"] = res.loaded_at
            res.rows, res.fmt = len(df), st["format"]
            res.members = "; ".join(m["member"] for m in st["members"])
            prev_key = f"{l.edit}/{l.service}"
            warns = [compare_to_previous(len(df), (prev_counts or {}).get(prev_key))]
            skipped = sum(m["non_data_rows_skipped"] for m in st["members"])
            if skipped:
                ex = [e for m in st["members"] for e in m["non_data_examples"]][:3]
                warns.append(f"{skipped} non-code body rows skipped (footer/notes?) e.g. {ex}")
            res.warning = "; ".join(w for w in warns if w) or None
            if spark is not None:
                import config
                (to_spark_fast(spark, df).write.format(getattr(config, "TABLE_FORMAT", "delta"))
                 .mode("overwrite" if overwrite else "errorifexists")
                 .option("overwriteSchema", "true").saveAsTable(fqn))
            res.status = "loaded"
            log(f"  {l.label} {l.edit}/{l.service:12s} {len(df):>10,} rows  {st['format']}  -> {fqn}"
                + (f"   WARNING {res.warning}" if res.warning else ""))
        except Exception as e:
            res.status, res.error = "failed", f"{type(e).__name__}: {str(e)[:800]}"
            log(f"  {l.label} {l.edit}/{l.service} FAILED  {res.error[:300]}")
        results.append(res)
    return results


def results_frame(results: list[LoadResult]) -> pd.DataFrame:
    return pd.DataFrame([asdict(r) for r in results])
