# PIE — Gap to Done (audit of pie_mvp vs `definition-of-done.md`, 2026-09-28; status updated 2026-09-29)

## Status after the 2026-09-29 refactor

| Pillar | 09-28 | 09-29 | What changed / what is still missing |
|---|---|---|---|
| 1 Corpus | Partial (early) | Partial (early) | NCCI acquisition automated; all 31 chapter files staged. Still 1 real chapter-extraction pending; no AMPM / fee schedule / A.A.C. / other federal sources |
| 2 Grounding | Partial | Partial | D1/D2 fixed; every section has an outcome (recall ledger). **No measured precision/recall yet** — v01 exists, needs an SME-scored sample |
| 3 Reconciliation | Not started | Partial (first cut) | NCCI editions reconciled per date segment with a label; seed/extracted duplicates collapse; federal/state overlaps computed (`policy_rule_overlaps`). No precedence decisions (by design: flagged, not resolved) |
| 4 Detection | Partial | Partial → close | Whole claims table, every compiled rule (NCCI table-driven); findings carry $ and PA status; precision tooling (v02) exists. **Precision unmeasured** until investigators disposition a sample |
| 5 Ambiguity register | Not started | Partial | `policy_ambiguity_register` table + d05 export. Categories still depend on the extractor's reason codes |
| 6 Contradiction register | Not started | Candidates only | `state_not_covered_vs_federal_edit` candidates with both sources. No conflict model beyond that; human review required |
| 7 Governance | Partial | Mostly | `build_id` + history; approver, quote and doc_hash reach `policy_rules`; stale approvals excluded; re-sign on revision; review log records the version reviewed. Open: 21 seeds still compile unsigned (`COMPILE_LEGACY_SEEDS`) |
| 8 Reusability | Partial | Partial | 9 demo notebooks, documented tables in README. No column comments, no embeddings, no scheduled Jobs yet |
| Measurement bar | Not started | Tooling built | v01/v02 compute the numbers with 95% intervals; v03 shows GO/NOT YET. **Every row is NOT YET until scored samples exist** |

Verified by: 148 offline tests; `tests/e2e_local_spark.py --demos` runs every notebook in order on local Spark with planted violations — all checks pass. Not verified on Databricks.


Method: four parallel read-only audits (one per module group), each claim cited to file:line;
high-impact claims re-read by hand; behavioural claims probed with the real classes (gate → normalize
→ compile → SQLite). 63 existing tests pass; 23 new (acquire_ncci) pass.

## Verdict per pillar

| Pillar | Status | Evidence (file:line) |
|---|---|---|
| 1 Corpus | **Partial (early)** | 31 chapter files registered (29 + 10A, 11A; URLs match live page) but `MVP_CHAPTERS` = 6 (config.py:128). Only authority label is `origin` ∈ {ncci, manual, extracted} (schema.py:81). Zero code for AMPM, fee schedule, A.A.C., PFS, add-on, age/sex, CLIA, descriptors, NCD/LCD. `CODE_RE` blind to revenue/DRG/NDC/ICD (policy_docs.py:36). No per-code authority list; gap.py:72 buckets only. |
| 2 Grounding | **Partial** | Quote/doc/section/doc_hash on drafts (extract_rules.py:948-975); no page column, `end_date` never set, no authority field. Exact-match on any substring: a 2-word quote scores 1.0 (:816-852); codes checked against section, not quote (:840). Fuzzy match stores the model's non-verbatim text (:845, :969). HYBRID "fuller quote" overwrite drops correctly grounded pattern rules (:592-593). Zero-proposal sections not recorded (:1016). No precision/recall code, no gold set. |
| 3 Reconciliation | **Not started** | Only NCCI edition-vs-edition collapse (rule_normalize.py:89-147) + exact de-dup (:175). No jurisdiction/relationship field. Probe: state `code_not_covered` + state 2/day + NCCI MUE on one code all compile unlinked; contradictory findings on the same line. |
| 4 Detection | **Partial** | 6 of 12 predicate types compile (detector_gen.py:316-323). One SQL self-join per PTP pair (:209-220) → ~500k statements; `MAX_DETECTORS=300` (run_detectors.py:21); `limit(20_000)` unordered (:58). Coverage counts any rule incl. leads/expired (gap.py:61-65). PA = flag + severity, "clear" never emitted; NCCI `pa_present=0` means "not evaluated". No finding disposition column → precision uncomputable. |
| 5 Ambiguity register | **Not started** (as a product) | Leads live in `state_rules` with free-text reason; `NOT_CHECKABLE_REASONS` enum not enforced (schema.py:55-60, :101). No register table/view. |
| 6 Contradiction register | **Not started** | Only a within-section regex ("not covered" + "re-instated", extract_rules.py:490-505) and one hand seed. |
| 7 Governance | **Partial** | Reviewer + doc_hash check at ingest (state_rules.py:254-273). But approver/timestamp never leave `state_rules` (row_to_rule drops them); detectors drop doc_hash; findings carry only `rule_id`, and NCCI rule_ids change every quarter → old findings orphaned. Stale approvals keep compiling after a PDF revision (state_rules.py:89 filters by status only; `policy_change_log` is write-only). 21 seed rules (not 19) compile unsigned (state_rules.py:40). |
| 8 Reusability | **Partial** | ~16 Delta tables, README row list only; no column comments; types inferred from pandas. No chunk/embedding table. No Jobs/scheduling. |
| Measurement bar | **Not started** | Coverage % computed but only printed (build_kb.py:190). No extraction P/R, detector precision, or register sizes. The "~90% fidelity" in the DoD status has no code or sample behind it in this package. |

## Defects found in the trusted path (fix before any new scope)

| # | Defect | Where | Why it matters |
|---|---|---|---|
| D1 | HYBRID `_rules` swallows unparseable model JSON (`except: return []`), result is **cached** as "no rules" | extract_rules.py:554-558, :1026 | The first real LLM run — the next planned step — would silently under-extract and poison the cache. Undoes F14. |
| D2 | Grounding admits truncated / unrelated quotes at score 1.0; fuzzy stores non-verbatim text; fuller-quote overwrite | extract_rules.py:592, :816-852, :969 | Highest-confidence rules are the least checked; review sort order is wrong. |
| D3 | Reversed PTP pair across editions merged by sorted key → one direction and its indicator-0 lost | rule_normalize.py:97 | Silent false negatives on hard denials. |
| D4 | Overlapping edition windows: both compile, stricter fires, no flag; `ambiguity_flag` never blocks compile | rule_normalize.py:93-147; detector_gen.py:353 | Contradicts the stated most-permissive policy. |
| D5 | Stale approvals compile after a doc revision; old-version drafts can still be approved | state_rules.py:89, :263-265; policy_changes.py | Violates "sign-off bound to the version reviewed". |
| D6 | `migrate_state_rules` overwrites `state_rules` unguarded; review ingest overwrites unguarded, logs before writing | migrate_state_rules.py:33,94; state_rules.py:334-335 | One re-run deletes every review. |
| D7 | Coverage treats leads / expired / uncompiled rules as "covered" | gap.py:61-65; build_kb.py:188 | Overstates the number that goes on the client slide. |
| D8 | Findings not reproducible: no build_id, rule_ids re-hash quarterly, `policy_detectors` overwritten | schema.py:66-69; build_kb.py:213-214 | A finding can't be traced to the rule text that produced it a quarter later. |
| D9 | NCCI ingest: zero tables matched → build continues with no federal edits; blank modifier → counted as deleted; bad eff date → quarter start | ingest_ncci_tables.py:357-360, :173-177 | Silent loss of federal coverage. (acquire_ncci now fails loudly upstream of this.) |
| D10 | PTP deletion date treated as inclusive end | ingest_ncci_tables.py:178, :200 | **Unverified** — CMS docs I could reach don't define it. If the edit ends the day before, every deleted edit fires one extra day. |

## Order of work (and why this order)

1. **Fix D1–D8** (trusted path). Cheap, test-pinned, and D1 blocks the first real LLM run.
2. **Measurement before breadth.** Gold set + scoring: extraction P/R on Ch19 (~100+ scored rules per stratum — at n=20 a 95% claim can't be told from 80%); a `disposition` column on findings + stratified sample per rule type; coverage = compiled ∧ in-window ∧ ran; register sizes in the build log.
3. **Table-driven detectors.** PTP/MUE as joins to edit tables (one query per predicate type), no 300 cap, deterministic output, `build_id` + rule version on every finding.
4. **Reconciliation data model + ambiguity register** (shared "scenario key": code + unit basis + population + window; relationship label; enforced reason enum; register table).
5. **Corpus breadth:** NCCI automated (done), 31 chapters in yield order, per-code authority matrix. Federal sources beyond NCCI **only after** confirming AHCCCS adopts them (the Medicaid NCCI page publishes PTP + MUE only; PFS/add-on/age-sex are Medicare artefacts — importing them unadopted manufactures false findings).
6. **Contradiction register**, table docs/comments, Jobs, embeddings layer.

## NCCI: manual → automated (delivered)

`acquire_ncci.py` + `notebooks/acquire_ncci`: discovers links on the CMS page (slugs differ between
quarters, so URLs are never built), archives each zip with SHA-256, parses text (Excel fallback),
maps to the **same column names as the hand-loaded tables**, validates (dates, modifier 0/1/9, numeric
MUE, file quarter = link quarter, row-count drop vs previous), writes `medicaid_ncci_edit_*` (never
overwrites), logs to `main.sedo.ncci_acquisition_log`. Round-trip tested through `ptp_rules` /
`mue_history`. 2M-row PTP parse: 20 s, 1.8 GB.
Unverified: text-file preamble/delimiter (parser locates/sniffs and fails loudly), cluster egress to
cms.gov (drop-zone fallback), DME service token in existing table names (`dme` assumed).
