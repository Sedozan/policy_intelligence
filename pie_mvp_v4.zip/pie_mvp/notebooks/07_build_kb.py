# Databricks notebook source
# MAGIC %md
# MAGIC # 07 · Build the Policy Knowledge Base  (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Rebuilds `main.policy_kb` deterministically. Every build gets a `build_id`; current tables are
# MAGIC overwritten, and `*_history` tables keep every build so a finding can always be traced to the rule
# MAGIC text that produced it.
# MAGIC
# MAGIC | step | what | writes |
# MAGIC |---|---|---|
# MAGIC | 0 | preflight: every configured column / table resolves | — |
# MAGIC | 1 | scope = procedure codes in the paid-claims table; claims date range | — |
# MAGIC | 2 | NCCI PTP + MUE from `main.sedo.medicaid_ncci_edit_*` | — |
# MAGIC | 3 | state rules: `approved` (+ `legacy_hand_authored` if `config.COMPILE_LEGACY_SEEDS`) — **approvals from an older PDF version are excluded** | — |
# MAGIC | 4 | gate → normalise (NCCI editions: directional, split by overlapping windows) → compile | `policy_rules`, `policy_detectors`, NCCI edit tables, `policy_batch_detectors` |
# MAGIC | 5 | coverage from **compiled, in-window** detectors | `policy_coverage`, `policy_coverage_summary`, `policy_gap` |
# MAGIC | 6 | registers: ambiguity + federal/state overlaps | `policy_ambiguity_register`, `policy_rule_overlaps` |
# MAGIC | 7 | build log + history | `policy_build_log`, `policy_rules_history`, `policy_detectors_history` |
# MAGIC
# MAGIC Next: `08_run_detectors`.

# COMMAND ----------

import os, sys, json, time
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
import config
import ingest_ncci_tables, state_rules, validate_gate, rule_normalize, detector_gen, gap, schema, kb_io, registers
for m in (config, schema, kb_io, ingest_ncci_tables, state_rules, validate_gate, rule_normalize, detector_gen, gap, registers):
    importlib.reload(m)

SOURCE_CATALOG, SOURCE_SCHEMA = config.CATALOG, config.SCHEMA
KB              = config.KB
CLAIMS          = config.CLAIMS_TABLE
STATE_RULES_TBL = config.STATE_RULES_TABLE
CC              = config.CLAIM_COLS
PAID_COL        = CC.get("paid_amt")
SCOPE           = "claims"            # "claims" (codes paid in the claims table) | "all"
# all_data_C_A is paid-only (SB, 2026-09-20; config.CLAIMS_PAID_ONLY). If that ever changes, set an
# SQL predicate here (e.g. "AND PMT_AMT > 0") AND give detectors a paid-claims view.
PAID_FILTER     = ""

BUILD_ID = "B" + pd.Timestamp.now().strftime("%Y%m%dT%H%M%S")
BUILT_AT = pd.Timestamp.now().isoformat(timespec="seconds")
print("build", BUILD_ID)

# COMMAND ----------

# MAGIC %md ## 0. Preflight

# COMMAND ----------

problems = []
claims_cols = {c.upper() for c in spark.table(CLAIMS).columns}
need = [v for k, v in CC.items() if k != "mods" and isinstance(v, str)] + list(CC["mods"])
for c in dict.fromkeys(need):
    if c.upper() not in claims_cols:
        problems.append(f"claims column missing: {c}")

metas = ingest_ncci_tables.discover_tables(spark, SOURCE_CATALOG, SOURCE_SCHEMA)
if not metas and not getattr(config, "NCCI_ALLOW_EMPTY", False):
    problems.append(f"no medicaid_ncci_edit_* tables in {SOURCE_CATALOG}.{SOURCE_SCHEMA} (run 00_acquire_ncci)")
fc = ingest_ncci_tables._find_col
for m in metas:
    cols = spark.table(m["fqn"]).columns
    if m["edit_type"] == "ptp":
        want = {"col1": fc(cols, "column1", "col1", "comprehensive code"), "col2": fc(cols, "column2", "col2", "component code"),
                "modifier": fc(cols, "modifier indicator", "modifier"), "effdt": fc(cols, "effective date", "effdt"),
                "deldt": fc(cols, "deletion date", "deldt")}
    else:
        want = {"code": fc(cols, "hcpcs/cpt code", "hcpcs cpt code", "procedure code", "code"),
                "value": fc(cols, "mue value", "mue values")}
    missing = [k for k, v in want.items() if v is None]
    if missing:
        problems.append(f"{m['table']}: cannot resolve {missing}; columns are {cols}")

try:
    st_cols = set(spark.table(STATE_RULES_TBL).columns)
    miss = [c for c in state_rules.STATE_RULE_COLUMNS if c not in st_cols]
    if miss:
        print(f"  note: {STATE_RULES_TBL} lacks newer columns {miss}; they are added on the next write")
except Exception as e:
    problems.append(f"{STATE_RULES_TBL} not readable: {e}  (run 02_migrate_state_rules first)")

if problems:
    raise RuntimeError("PREFLIGHT FAILED:\n  - " + "\n  - ".join(problems))
print("preflight OK")

# COMMAND ----------

# MAGIC %md ## 1. Scope and claims window

# COMMAND ----------

t0 = time.time()
PROC, DOS = CC["code"], CC["dos"]
rng = spark.sql(f"SELECT CAST(MIN({DOS}) AS DATE) AS lo, CAST(MAX({DOS}) AS DATE) AS hi FROM {CLAIMS}").collect()[0]
CLAIMS_WINDOW = (str(rng["lo"]) if rng["lo"] else None, str(rng["hi"]) if rng["hi"] else None)
if SCOPE == "claims":
    scope_codes = {r.code for r in spark.sql(
        f"SELECT DISTINCT UPPER(TRIM({PROC})) AS code FROM {CLAIMS} WHERE {PROC} IS NOT NULL {PAID_FILTER}").collect()}
    print(f"scope: {len(scope_codes):,} distinct procedure codes; claims dates {CLAIMS_WINDOW}")
else:
    scope_codes = None
    print(f"scope: all codes; claims dates {CLAIMS_WINDOW}")

# COMMAND ----------

# MAGIC %md ## 2. Federal rules — NCCI PTP + MUE

# COMMAND ----------

ncci_rules = ingest_ncci_tables.ingest_tables(spark, SOURCE_CATALOG, SOURCE_SCHEMA, code_filter=scope_codes)
ncci_quarters = sorted({(m["service"], m["edit_type"], m["label"]) for m in metas})
print(f"NCCI source: {getattr(config, 'NCCI_SOURCE', 'unknown')} - per the CMS public edit set; Arizona-specific "
      f"deactivations (RISSNET state files) are NOT applied.")

# COMMAND ----------

# MAGIC %md ## 3. State rules — reviewed, current document version only

# COMMAND ----------

current_doc_hash = {}
inv = kb_io.table_or_none(spark, f"{KB}.policy_document_inventory")
if inv is not None and len(inv):
    inv = inv.sort_values("fetched_at") if "fetched_at" in inv.columns else inv
    current_doc_hash = inv.groupby(inv["chapter"].astype(str))["doc_hash"].last().to_dict()
state_report = {}
st_rules = state_rules.load_state_rules(spark, STATE_RULES_TBL, scope_codes, current_doc_hash=current_doc_hash,
                                        report=state_report)
state_df = spark.table(STATE_RULES_TBL).toPandas()
print(f"state: {len(st_rules)} loaded; {len(state_report['stale'])} stale approvals excluded; "
      f"{state_report['legacy']} legacy seed rules (COMPILE_LEGACY_SEEDS={getattr(config, 'COMPILE_LEGACY_SEEDS', True)})")

# COMMAND ----------

# MAGIC %md ## 4. Gate → normalise → compile

# COMMAND ----------

rules = ncci_rules + st_rules
accepted, rejected = validate_gate.gate(rules)
print("gate:", json.dumps(validate_gate.summarize(accepted, rejected)))
for r in rejected[:10]:
    print("   rejected:", r["reject_reason"], "|", (r.get("statement") or "")[:80])

accepted, norm_report = rule_normalize.normalize_rules(accepted)
print("normalise:", json.dumps(norm_report))

detectors = detector_gen.build_detectors(accepted, batch_ncci=True)
summary = detector_gen.summarize(detectors)
print("detectors:", json.dumps({k: v for k, v in summary.items() if k != "lead_reasons"}))

# who approved each state rule, joined back by extraction_key (extracted) or rule_id (seeds)
def _lookup(df, key):
    if key not in df:
        return {}
    d = df[df[key].notna() & (df[key].astype(str) != "")].drop_duplicates(key, keep="last")
    return d.set_index(key)[["reviewer", "reviewed_at", "review_status"]].to_dict("index")
rev, rev_id = _lookup(state_df, "extraction_key"), _lookup(state_df, "rule_id")
for r in accepted:
    src = rev.get(r.get("extraction_key")) or rev_id.get(r.get("rule_id")) or {}
    r.update(build_id=BUILD_ID, built_at=BUILT_AT, reviewer=src.get("reviewer"), reviewed_at=src.get("reviewed_at"),
             review_status=src.get("review_status") if r.get("origin") != "ncci" else "federal_table",
             jurisdiction="federal" if r.get("origin") == "ncci" else "state")
for d in detectors:
    d["build_id"] = BUILD_ID

ptp_edits, mue_limits = detector_gen.ncci_edit_tables(accepted)
batch_rows = [
    {"batch": detector_gen.BATCH_PTP, "rules": len(ptp_edits), "sql": detector_gen.batch_ptp_sql(), "build_id": BUILD_ID},
    {"batch": detector_gen.BATCH_MUE, "rules": len(mue_limits), "sql": detector_gen.batch_mue_sql(), "build_id": BUILD_ID},
]
print(f"batched NCCI: {len(ptp_edits):,} PTP edits, {len(mue_limits):,} MUE limits (2 SQL statements)")

# COMMAND ----------

# MAGIC %md ## 5. Coverage (compiled, in-window detectors only) and gap

# COMMAND ----------

coverage = gap.coverage_table(spark, accepted, CLAIMS, PAID_COL, detectors=detectors, claims_window=CLAIMS_WINDOW)
cov_summary = gap.coverage_summary(coverage)
gap_df = gap.gap_rows(coverage)
for df_ in (coverage, cov_summary, gap_df):
    df_["build_id"] = BUILD_ID
print(cov_summary.to_string(index=False))
print(f"\ngap: {len(gap_df):,} paid codes no state detector checks; top 15 by paid $:")
print(gap_df.head(15).to_string(index=False))

# COMMAND ----------

# MAGIC %md ## 6. Registers — ambiguity, federal/state overlaps

# COMMAND ----------

amb = registers.ambiguity_register(state_df, accepted)
ovl = registers.rule_overlaps(accepted, detectors)
for df_ in (amb, ovl):
    df_["build_id"] = BUILD_ID
print("ambiguity register:", amb["category"].value_counts().to_dict() if len(amb) else "empty")
print("rule overlaps:", ovl["relationship"].value_counts().to_dict() if len(ovl) else "none")

# COMMAND ----------

# MAGIC %md ## 7. Write

# COMMAND ----------

from kb_io import write_table

def write(rows, table, mode="overwrite"):
    return write_table(spark, rows, f"{KB}.{table}", mode)

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {KB}")
paid_by = coverage.groupby("coverage")["paid_dollars"].sum()
tot = float(coverage["paid_dollars"].sum() or 0)
build_meta = {
    "build_id": BUILD_ID, "built_at": BUILT_AT, "scope": SCOPE, "claims_table": CLAIMS,
    "claims_from": CLAIMS_WINDOW[0], "claims_to": CLAIMS_WINDOW[1],
    "scope_codes": len(scope_codes) if scope_codes else 0,          # 0 = SCOPE "all"
    "rules": len(accepted), "ncci_rules": sum(r["origin"] == "ncci" for r in accepted),
    "state_rules": sum(r["origin"] != "ncci" for r in accepted),
    "detectors_compiled": summary["compiled"], "detectors_batched": summary["batched"], "leads": summary["leads"],
    "stale_approvals_excluded": len(state_report["stale"]), "legacy_seed_rules": state_report["legacy"],
    "pct_paid_covered_any": round(100 * float(paid_by.drop("none", errors="ignore").sum()) / tot, 2) if tot else float("nan"),
    "pct_paid_covered_state": round(100 * float(paid_by.reindex(["both", "state_only"]).fillna(0).sum()) / tot, 2) if tot else float("nan"),
    "ambiguity_register_rows": len(amb), "overlap_rows": len(ovl),
    "contradiction_candidates": int((ovl["relationship"] == "state_not_covered_vs_federal_edit").sum()) if len(ovl) else 0,
    "ncci_quarters": json.dumps(ncci_quarters), "gate": json.dumps(validate_gate.summarize(accepted, rejected)),
    "normalize": json.dumps(norm_report),
}

print("writing outputs:")
write(accepted,   "policy_rules")
write(detectors,  "policy_detectors")
write(ptp_edits.assign(build_id=BUILD_ID),  "policy_ncci_ptp_edits")
write(mue_limits.assign(build_id=BUILD_ID), "policy_ncci_mue_limits")
write(batch_rows, "policy_batch_detectors")
write(coverage,   "policy_coverage")
write(cov_summary, "policy_coverage_summary")
write(gap_df,     "policy_gap")
write(amb,        "policy_ambiguity_register")
write(ovl,        "policy_rule_overlaps")
# history: append-only, keyed by build_id - old findings join here, not to the overwritten tables
write(accepted,   "policy_rules_history", mode="append")
write([{k: v for k, v in d.items() if k != "sql"} for d in detectors], "policy_detectors_history", mode="append")
write([build_meta], "policy_build_log", mode="append")
print(f"\nbuild {BUILD_ID} finished in {time.time()-t0:,.0f}s")
print(json.dumps({k: v for k, v in build_meta.items() if k not in ("gate", "normalize", "ncci_quarters")}, indent=1))
