# Databricks notebook source
# MAGIC %md
# MAGIC # v01 · Extraction scoring — precision, fidelity and recall on a human-scored sample
# MAGIC
# MAGIC **What this measures:** how often an extracted rule is a real rule (*precision*), how often a real rule says what the
# MAGIC source says (*fidelity*), and how many rules in a section the pipeline found out of all it should have (*recall*).
# MAGIC Each number comes with a 95% interval and its sample size.
# MAGIC **How it works:** two phases.
# MAGIC 1. **EXPORT** (`EXPORT = True`): draws a stratified sample and writes a workbook for a policy expert.
# MAGIC    Sheet `RULES`: extracted rules by chapter × how they were found; fill `is_real_rule` (Y/N), `faithful_to_source` (Y/N),
# MAGIC    `notes`, `scorer`. Sheet `RECALL`: sections (including ones the pre-filter skipped and ones with no rules) with the
# MAGIC    section text and the rules extracted from it; fill `missed_rules` (a whole number, 0 if none) and `scorer`.
# MAGIC 2. **INGEST** (`SCORED_WORKBOOK = "<path>"`): reads the filled workbook, computes the metrics, appends them to
# MAGIC    `policy_quality_metrics` and the raw scores to `policy_extraction_scores`.
# MAGIC
# MAGIC **Limits:** until a workbook has been scored and ingested, **extraction precision, fidelity and recall are unmeasured**.
# MAGIC A sample measures the chapters and extraction methods it was drawn from, nothing else. Pooled ("all") numbers are not
# MAGIC weighted by stratum size. Recall intervals are optimistic (rules in one section are not independent).
# MAGIC Definition-of-done bar: fidelity ≥ 0.95 at the **lower** end of the 95% interval.
# MAGIC
# MAGIC Writes: the workbook under `data/validation/`, and (INGEST only) appends to the two tables above.

# COMMAND ----------

# MAGIC %pip install -q openpyxl

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import Window, functions as F
import config, kb_io, quality
for _m in (config, kb_io, quality):
    importlib.reload(_m)

EXPORT          = True          # phase 1: draw the sample and write the workbook
STATUSES        = None          # None = every extracted rule except rejected (the pipeline's own quality, before review);
                                # ["approved"] = what the definition of done asks: fidelity of APPROVED rules
N_PER_STRATUM   = 15            # rules per chapter x extraction_source (all of them when a stratum is smaller)
N_SECTIONS      = 10            # sections per chapter x outcome on the RECALL sheet
SEED            = 20260929      # same seed + same data = same sample
SCORED_WORKBOOK = None          # phase 2: path of the filled workbook; None = skip ingest
REINGEST        = False         # True = ingest a sample_id that was already ingested (adds a second set of rows)
FIDELITY_TARGET = 0.95          # definition-of-done bar, judged on the lower 95% bound

# COMMAND ----------

KB = config.KB
OUT_DIR = f"{config.WORKSPACE_DATA_DIR}/validation"
T_METRICS, T_SCORES = f"{KB}.policy_quality_metrics", f"{KB}.policy_extraction_scores"
SAMPLE_ID = f"v01-{pd.Timestamp.now().strftime('%Y%m%d')}-s{SEED}"
RULE_COLS = ["sample_id", "stratum", "stratum_size", "chapter", "extraction_source", "review_status", "statement", "predicate",
             "verbatim_quote", "source_doc", "source_locator", "source_url", "section_heading", "section_text",
             "rule_id", "extraction_key", "doc_hash", "section_id"]
RULE_SCORE_COLS = ["is_real_rule", "faithful_to_source", "notes", "scorer"]
SEC_COLS = ["sample_id", "stratum", "stratum_size", "chapter", "outcome", "outcome_reason", "heading", "page_start", "page_end",
            "section_text", "rules_extracted", "rules_extracted_text", "section_id", "doc_hash"]
SEC_SCORE_COLS = ["missed_rules", "scorer"]
README = pd.DataFrame({"how to score": [
    "RULES sheet - one extracted rule per row. Read the verbatim quote in the context of the section text.",
    "  is_real_rule: Y if the text states a billing/coverage rule this reading captures; N if it is not a rule (a heading, an example, "
    "a process duty mis-read as a limit, a duplicate).",
    "  faithful_to_source: only when is_real_rule = Y. Y if statement + predicate say exactly what the text says (codes, limits, "
    "conditions, exceptions); N if anything is wrong, missing or invented.",
    "RECALL sheet - one policy section per row, with the rules the pipeline took from it.",
    "  missed_rules: how many rules the section states that are NOT in rules_extracted_text (0 if none). Count each distinct limit, "
    "pair, exclusion or requirement once.",
    "Fill scorer with your name on every row you score. Leave rows blank rather than guessing - blanks are excluded, not counted.",
    "Do not add, remove or reorder rows or columns.",
]})

# COMMAND ----------

# MAGIC %md ## Phase 1 — export the sample

# COMMAND ----------

def current_sections():
    """Sections of each chapter's CURRENT document version (latest inventory row), one row per section."""
    inv = spark.table(f"{KB}.policy_document_inventory").toPandas().sort_values("fetched_at")
    cur = inv.groupby(inv["chapter"].astype(str))["doc_hash"].last().to_dict()
    cur_df = spark.createDataFrame(pd.DataFrame({"chapter": list(cur), "doc_hash": list(cur.values())}),
                                   "chapter string, doc_hash string")
    w = Window.partitionBy("chapter", "doc_hash", "section_id").orderBy(F.desc("run_id"))
    return (spark.table(f"{KB}.policy_sections").withColumn("chapter", F.col("chapter").cast("string"))
            .join(cur_df, ["chapter", "doc_hash"]).withColumn("_r", F.row_number().over(w)).where("_r = 1").drop("_r"))


EXPORT_PATH = None
if EXPORT:
    sr = spark.table(config.STATE_RULES_TABLE).where("origin = 'extracted' AND review_status <> 'rejected'").toPandas()
    if STATUSES:
        sr = sr[sr["review_status"].isin(STATUSES)]
    print(f"population: extracted rules with review_status {STATUSES or 'any except rejected'}")
    secs = current_sections().select("section_id", "doc_hash", F.col("heading").alias("section_heading"),
                                     F.col("text").alias("section_text")).toPandas()
    sr["chapter"] = sr["chapter"].astype(str)
    sr["extraction_source"] = sr["extraction_source"].fillna("(unknown)")
    rules = quality.stratified_sample(sr, ["chapter", "extraction_source"], N_PER_STRATUM, SEED, key=["extraction_key", "rule_id"])
    rules = rules.merge(secs, on=["section_id", "doc_hash"], how="left")
    rules["sample_id"] = SAMPLE_ID
    for c in RULE_SCORE_COLS:
        rules[c] = None
    for c in ("section_text", "verbatim_quote", "statement"):
        rules[c] = rules[c].map(quality.clip_text)
    print(f"RULES: {len(rules):,} of {len(sr):,} rule(s) sampled:")
    display(rules.groupby(["stratum", "stratum_size"]).size().reset_index(name="sampled"))
    no_text = int(rules["section_text"].isna().sum())
    if no_text:
        print(f"  {no_text} sampled rule(s) come from an older document version; their section text is not attached "
              "(score them from the quote and the PDF).")

    # RECALL: sections of the current version, stratified by chapter x outcome, with what was extracted from each
    wo = Window.partitionBy("section_id", "doc_hash").orderBy(F.desc("run_id"))
    outc = spark.table(f"{KB}.policy_extraction_outcomes").withColumn("_r", F.row_number().over(wo)).where("_r = 1").drop("_r")
    s = (current_sections().join(outc.select("section_id", "doc_hash", "outcome", F.col("reason").alias("outcome_reason")),
                                 ["section_id", "doc_hash"], "left")
         .select("chapter", "section_id", "doc_hash", "heading", "page_start", "page_end", F.col("text").alias("section_text"),
                 "outcome", "outcome_reason").toPandas())
    s["outcome"] = s["outcome"].fillna("(no outcome recorded)")
    per = (sr.groupby("section_id").agg(rules_extracted=("statement", "size"),
                                        rules_extracted_text=("statement", lambda x: "\n".join(f"- {t}" for t in x)))
           .reset_index())
    s = s.merge(per, on="section_id", how="left")
    s["rules_extracted"] = s["rules_extracted"].fillna(0).astype(int)
    recall = quality.stratified_sample(s, ["chapter", "outcome"], N_SECTIONS, SEED, key=["section_id", "doc_hash"])
    recall["sample_id"] = SAMPLE_ID
    for c in SEC_SCORE_COLS:
        recall[c] = None
    for c in ("section_text", "rules_extracted_text"):
        recall[c] = recall[c].map(quality.clip_text)
    print(f"RECALL: {len(recall):,} of {len(s):,} current section(s) sampled:")
    display(recall.groupby(["stratum", "stratum_size"]).size().reset_index(name="sampled"))

    os.makedirs(OUT_DIR, exist_ok=True)
    EXPORT_PATH = quality.xlsx_write_sheets(
        {"README": README, "RULES": rules[RULE_COLS + RULE_SCORE_COLS], "RECALL": recall[SEC_COLS + SEC_SCORE_COLS]},
        f"{OUT_DIR}/v01_extraction_sample_{SAMPLE_ID}.xlsx")
    print(f"\nwrote {EXPORT_PATH}\nNext: an expert fills it; then set SCORED_WORKBOOK to its path (EXPORT = False) and re-run.")

# COMMAND ----------

# MAGIC %md ## Phase 2 — ingest the scored workbook

# COMMAND ----------

metrics = pd.DataFrame()
if not SCORED_WORKBOOK:
    print("SCORED_WORKBOOK is None - nothing to ingest. Extraction precision, fidelity and recall remain UNMEASURED "
          "until a scored workbook is ingested.")
elif not os.path.exists(SCORED_WORKBOOK):
    print(f"SCORED_WORKBOOK {SCORED_WORKBOOK} does not exist - nothing ingested. Extraction quality remains UNMEASURED.")
else:
    book = quality.xlsx_read_sheets(SCORED_WORKBOOK)
    missing = [sh for sh in ("RULES", "RECALL") if sh not in book]
    assert not missing, f"workbook lacks sheet(s) {missing}"
    rs, ss = book["RULES"], book["RECALL"]
    for sh, df, need in (("RULES", rs, RULE_COLS + RULE_SCORE_COLS), ("RECALL", ss, SEC_COLS + SEC_SCORE_COLS)):
        lost = [c for c in need if c not in df.columns]
        assert not lost, f"sheet {sh} lost column(s) {lost} - re-export rather than editing the layout"
    sid = str(rs["sample_id"].dropna().iloc[0]) if rs["sample_id"].notna().any() else str(ss["sample_id"].dropna().iloc[0])
    if spark.catalog.tableExists(T_METRICS) and not REINGEST:
        done = spark.table(T_METRICS).where(F.col("sample_id") == sid).count()
        assert done == 0, f"sample {sid} was already ingested ({done} metric rows). Set REINGEST = True to add it again."
    bad = rs[rs["is_real_rule"].map(quality._yn).isna() & rs["is_real_rule"].notna()]
    if len(bad):
        print(f"  {len(bad)} RULES row(s) have an is_real_rule value that is not Y/N - treated as blank: "
              f"{sorted(bad['is_real_rule'].astype(str).unique())[:5]}")
    metrics = quality.extraction_metrics(rs, ss)
    now = pd.Timestamp.now().isoformat(timespec="seconds")
    metrics["sample_id"], metrics["computed_at"] = sid, now
    metrics = metrics[["metric", "scope_type", "scope", "n", "value", "ci_low", "ci_high", "sample_id", "computed_at", "notes"]]
    display(metrics)

    raw = pd.concat([rs.assign(kind="rule"), ss.assign(kind="section")], ignore_index=True, sort=False)
    raw["sample_id"], raw["ingested_at"], raw["workbook"] = sid, now, SCORED_WORKBOOK
    raw = raw.drop(columns=["section_text"], errors="ignore")         # the text lives in policy_sections
    kb_io.write_table(spark, metrics, T_METRICS, mode="append")
    kb_io.write_table(spark, quality.as_text_frame(raw), T_SCORES, mode="append")

# COMMAND ----------

# MAGIC %md ## Against the definition-of-done bar

# COMMAND ----------

if len(metrics):
    fid = metrics[metrics["metric"] == "extraction_fidelity"]
    for r in fid.to_dict("records"):
        if r["n"] == 0:
            print(f"fidelity [{r['scope']}]: no scored real rules - UNMEASURED.")
            continue
        ok = r["ci_low"] >= FIDELITY_TARGET
        line = (f"fidelity [{r['scope']}]: {r['value']:.3f} (95% CI {r['ci_low']:.3f}-{r['ci_high']:.3f}, n={r['n']}) -> "
                f"{'MEETS' if ok else 'does NOT meet'} the bar (lower bound >= {FIDELITY_TARGET}).")
        if not ok:
            need = quality.n_needed(r["value"], FIDELITY_TARGET)
            line += (f" At this observed rate the bar cannot be met by more samples (rate <= {FIDELITY_TARGET})."
                     if need is None else f" If the rate holds, about {need - r['n']:,} more scored real rules are needed "
                                          f"(n = {need:,}).")
        print(line)
    for m in ("extraction_precision", "extraction_recall"):
        for r in metrics[metrics["metric"] == m].to_dict("records"):
            print(f"{m.split('_')[1]} [{r['scope']}]: " + ("UNMEASURED (n=0)" if r["n"] == 0 else
                  f"{r['value']:.3f} (95% CI {r['ci_low']:.3f}-{r['ci_high']:.3f}, n={r['n']})"))
    print("The definition of done sets no numeric bar for precision or recall yet; it requires them to be measured and stated.")
