# Databricks notebook source
# MAGIC %md
# MAGIC # v03 · Pipeline health and the measurement bar
# MAGIC
# MAGIC **What this answers:** is the latest build and detector run sound, are the federal edits current, what did extraction do
# MAGIC with each chapter, what quality numbers exist — and, against the definition-of-done measurement bar, what is **GO** and
# MAGIC what is **NOT YET**, with the reason for each.
# MAGIC **How to read it:** the last table is the summary. A row says GO only when the number it rests on exists and meets the
# MAGIC bar; a missing number is always NOT YET, never assumed. A rate counts as *measured* only when its 95% interval is
# MAGIC narrow enough to state (`MAX_CI_WIDTH`, default ±10 points): 3 of 4 correct is a number, not a measurement.
# MAGIC **Limits:** this reports what the tables say. Quality metrics come from human-scored samples (v01, v02); until those
# MAGIC are scored and ingested, extraction precision/recall/fidelity and detector precision are unmeasured.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import Window, functions as F
import config, quality, acquire_ncci, ingest_ncci_tables
for _m in (config, quality, acquire_ncci, ingest_ncci_tables):
    importlib.reload(_m)

FIDELITY_TARGET = 0.95          # definition-of-done bar, judged on the lower 95% bound
MAX_CI_WIDTH    = 0.20          # a rate counts as "measured" only when its 95% interval is at most this wide

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def have(name):
    return spark.catalog.tableExists(T(name))


def num(v):
    try:
        return None if v is None or pd.isna(v) else v
    except (TypeError, ValueError):
        return v


GO = []            # rows of the final table


def bar(item, ok, reason):
    GO.append({"measurement bar item": item, "status": "GO" if ok else "NOT YET", "reason": reason})

# COMMAND ----------

# MAGIC %md ## 1. Latest build

# COMMAND ----------

bl = spark.table(T("policy_build_log")).orderBy(F.desc("built_at")).limit(1).toPandas() if have("policy_build_log") else pd.DataFrame()
BUILD_ID = spark.table(T("policy_rules")).where("build_id IS NOT NULL").select("build_id").first()[0] if have("policy_rules") else None
b = bl.iloc[0].to_dict() if len(bl) else {}
if b:
    show_keys = ["build_id", "built_at", "claims_from", "claims_to", "scope_codes", "rules", "ncci_rules", "state_rules",
                 "detectors_compiled", "detectors_batched", "leads", "stale_approvals_excluded", "legacy_seed_rules",
                 "pct_paid_covered_any", "pct_paid_covered_state", "ambiguity_register_rows", "overlap_rows",
                 "contradiction_candidates"]
    display(pd.DataFrame({"field": show_keys, "value": [str(b.get(k)) for k in show_keys]}))
    if BUILD_ID and b.get("build_id") != BUILD_ID:
        print(f"WARNING: the current policy_rules build ({BUILD_ID}) is not the latest build log row ({b.get('build_id')}).")
else:
    print("No build yet - run 07_build_kb.")

# COMMAND ----------

# MAGIC %md ## 2. Latest detector run

# COMMAND ----------

run = {}
if have("policy_detector_runs"):
    runs = spark.table(T("policy_detector_runs"))
    rid = runs.agg(F.max("run_id")).first()[0]
    r = runs.where(F.col("run_id") == rid).toPandas()
    nf = spark.table(T("policy_findings")).where(F.col("run_id") == rid).count() if have("policy_findings") else 0
    run = {"run_id": rid, "build_id": r["build_id"].dropna().iloc[0] if r["build_id"].notna().any() else None,
           "detector_rows": len(r), "errors": int(r["error"].notna().sum()),
           "partial_run": bool(r["partial_run"].fillna(False).astype(bool).any()) if "partial_run" in r else None,
           "detectors_eligible": int(r["detectors_eligible"].max()) if "detectors_eligible" in r and r["detectors_eligible"].notna().any() else None,
           "findings": nf}
    display(pd.DataFrame({"field": list(run), "value": [str(v) for v in run.values()]}))
    if run["errors"]:
        display(r[r["error"].notna()][["rule_id", "predicate_type", "error"]])
else:
    print("No detector run yet - run 08_run_detectors.")

# COMMAND ----------

# MAGIC %md ## 3. NCCI freshness

# COMMAND ----------

metas = ingest_ncci_tables.discover_tables(spark, config.CATALOG, config.SCHEMA)
cy, cq = acquire_ncci.current_quarter()
fresh = []
for (svc, edit), g in pd.DataFrame(metas).groupby(["service", "edit_type"]) if metas else []:
    loaded = sorted({(int(y), int(q)) for y, q in zip(g["year"], g["quarter"])})
    fresh.append({"service": svc, "edit": edit, "latest": f"{loaded[-1][0]}Q{loaded[-1][1]}",
                  "current": loaded[-1] >= (cy, cq), "missing_up_to_today": ", ".join(acquire_ncci.missing_quarters(loaded)) or "none"})
fresh = pd.DataFrame(fresh)
print(f"today is in {cy}Q{cq}")
display(fresh) if len(fresh) else print("no NCCI tables found")

# COMMAND ----------

# MAGIC %md ## 4. Extraction outcomes by chapter (current document version)

# COMMAND ----------

oc = pd.DataFrame()
if have("policy_extraction_outcomes") and have("policy_document_inventory"):
    inv = spark.table(T("policy_document_inventory")).toPandas().sort_values("fetched_at")
    cur = inv.groupby(inv["chapter"].astype(str))["doc_hash"].last().to_dict()
    cur_df = spark.createDataFrame(pd.DataFrame({"chapter": list(cur), "doc_hash": list(cur.values())}),
                                   "chapter string, doc_hash string")
    w = Window.partitionBy("section_id", "doc_hash").orderBy(F.desc("run_id"))
    oc = (spark.table(T("policy_extraction_outcomes")).withColumn("chapter", F.col("chapter").cast("string"))
          .join(cur_df, ["chapter", "doc_hash"]).withColumn("_r", F.row_number().over(w)).where("_r = 1")
          .groupBy("chapter").pivot("outcome").count().fillna(0).toPandas())
    display(oc.sort_values("chapter", key=lambda s: s.map(lambda v: (len(v), v))))
    if have("policy_extraction_log"):
        lg = spark.table(T("policy_extraction_log")).toPandas().sort_values("started_at").groupby("chapter").tail(1)
        print("latest extraction run per chapter (backend = how rules were found; model_failures > 0 needs a look):")
        display(lg[[c for c in ("chapter", "run_id", "backend", "model_backend", "model_calls", "model_failures", "proposals",
                                "grounded", "dropped", "error") if c in lg.columns]])
else:
    print("No extraction outcomes yet (no chapter extracted with this package version).")

# COMMAND ----------

# MAGIC %md ## 5. Latest quality metrics (from v01 / v02)

# COMMAND ----------

qm = pd.DataFrame()
if have("policy_quality_metrics"):
    qm = spark.table(T("policy_quality_metrics")).toPandas().sort_values("computed_at").groupby(["metric", "scope"]).tail(1)
    display(qm.sort_values(["metric", "scope"])[["metric", "scope_type", "scope", "n", "value", "ci_low", "ci_high",
                                                  "sample_id", "computed_at", "notes"]])
else:
    print("policy_quality_metrics does not exist: NO quality metric has been measured yet (run v01 / v02 and ingest scored workbooks).")


def precise(m):
    return (m["ci_high"] - m["ci_low"]) <= MAX_CI_WIDTH


def describe(label, m):
    txt = f"{label}: {m['value']:.2f} (95% CI {m['ci_low']:.2f}-{m['ci_high']:.2f}, n={int(m['n'])})"
    if not precise(m):
        need = quality.n_for_ci_width(m["value"], MAX_CI_WIDTH)
        txt += f" too few to state" + (f", ~{need - int(m['n']):,} more needed" if need else "")
    return txt


def metric(name, scope):
    if not len(qm):
        return None
    m = qm[(qm["metric"] == name) & (qm["scope"].astype(str) == str(scope))]
    return m.iloc[0].to_dict() if len(m) and int(m.iloc[0]["n"] or 0) > 0 else None

# COMMAND ----------

# MAGIC %md ## 6. The measurement bar — GO / NOT YET

# COMMAND ----------

sr = spark.table(config.STATE_RULES_TABLE).toPandas()
ext_chapters = sorted({str(c) for c in sr.loc[sr["origin"] == "extracted", "chapter"].dropna()}, key=lambda v: (len(v), v))

for name, label in (("extraction_precision", "Extraction precision measured per chapter"),
                    ("extraction_recall", "Extraction recall measured per chapter")):
    if not ext_chapters:
        bar(label, False, "no extracted rules yet")
        continue
    ms = {c: metric(name, c) for c in ext_chapters}
    miss = [c for c in ext_chapters if ms[c] is None]
    wide = [c for c in ext_chapters if ms[c] is not None and not precise(ms[c])]
    vals = "; ".join(describe(f"ch {c}", ms[c]) for c in ext_chapters if ms[c] is not None)
    bar(label, not miss and not wide,
        (f"{vals}. " if vals else "") + (f"no scored sample for chapter(s) {', '.join(miss)} (run v01). " if miss else "")
        + ("" if miss or wide else "every extracted chapter is measured to within the interval width."))

fid = metric("extraction_fidelity", "all")
if fid is None:
    bar(f"Extraction fidelity >= {FIDELITY_TARGET} (lower 95% bound)", False, "no scored fidelity sample (run v01 and ingest)")
else:
    ok = fid["ci_low"] >= FIDELITY_TARGET
    need = None if ok else quality.n_needed(fid["value"], FIDELITY_TARGET)
    bar(f"Extraction fidelity >= {FIDELITY_TARGET} (lower 95% bound)", ok,
        f"{fid['value']:.3f}, 95% CI {fid['ci_low']:.3f}-{fid['ci_high']:.3f}, n={int(fid['n'])}"
        + ("" if ok else (" - the observed rate is at or below the bar, more samples cannot fix it" if need is None
                          else f" - about {need - int(fid['n']):,} more scored real rules needed if the rate holds")))

if run.get("run_id") and have("policy_findings"):
    strata = (spark.table(T("policy_findings")).where(F.col("run_id") == run["run_id"])
              .select(F.concat_ws(" | ", "origin", "predicate_type").alias("s")).distinct().toPandas()["s"].tolist())
    ms = {x: metric("detector_precision", x) for x in strata}
    miss = [x for x in strata if ms[x] is None]
    wide = [x for x in strata if ms[x] is not None and not precise(ms[x])]
    vals = "; ".join(describe(x, ms[x]) for x in strata if ms[x] is not None)
    bar("Detector precision measured per rule type", bool(strata) and not miss and not wide,
        (f"{vals}. " if vals else "") + (f"no reviewed sample for {', '.join(miss)} (run v02). " if miss else "")
        + ("the latest run has no findings" if not strata else
           "" if miss or wide else "every rule type that fired is measured to within the interval width."))
else:
    bar("Detector precision measured per rule type", False, "no detector run yet")

cov_any, cov_state = num(b.get("pct_paid_covered_any")), num(b.get("pct_paid_covered_state"))
bar("Coverage reported (% of paid $ under an active rule)", cov_any is not None,
    f"{cov_any}% of paid $ under any compiled in-window rule, {cov_state}% under a state rule (build {b.get('build_id')}). "
    "An upper bound: a code counts as covered if any rule checks it." if cov_any is not None else "no coverage number in the build log")

amb, contra = num(b.get("ambiguity_register_rows")), num(b.get("contradiction_candidates"))
bar("Register sizes reported (ambiguities, contradictions)", amb is not None and contra is not None,
    f"{amb} ambiguity entries, {contra} contradiction candidates (candidates, not confirmed)" if amb is not None and contra is not None
    else "register sizes missing from the build log")

if run.get("run_id"):
    problems = ([f"run is on build {run['build_id']}, current is {BUILD_ID}"] if run["build_id"] != BUILD_ID else []) + \
               ([f"{run['errors']} detector error(s)"] if run["errors"] else []) + (["partial run"] if run["partial_run"] else [])
    bar("Latest detector run complete on the current build", not problems,
        "; ".join(problems) or f"run {run['run_id']}: {run['findings']:,} findings, no errors")
else:
    bar("Latest detector run complete on the current build", False, "no detector run yet")

if len(fresh):
    behind = fresh[~fresh["current"]]
    bar(f"NCCI edits current through {cy}Q{cq}", behind.empty,
        "; ".join(f"{r.service} {r.edit}: latest {r.latest}" for r in behind.itertuples()) or "every loaded edition is current")
else:
    bar(f"NCCI edits current through {cy}Q{cq}", False, "no NCCI tables")

legacy = int(num(b.get("legacy_seed_rules")) or 0)
waiting = int(((sr["review_status"] == "needs_review") & sr["prior_review"].notna()).sum()) if "prior_review" in sr else 0
bar("Nothing compiles without version-bound sign-off", legacy == 0 or not config.COMPILE_LEGACY_SEEDS,
    (f"{legacy} hand-authored seed rule(s) compile without a named reviewer (config.COMPILE_LEGACY_SEEDS = True). "
     if legacy and config.COMPILE_LEGACY_SEEDS else "only signed rules compile. ")
    + f"{int(num(b.get('stale_approvals_excluded')) or 0)} stale approval(s) excluded; {waiting} rule(s) waiting for re-sign.")

inv_ch = set(spark.table(T("policy_document_inventory")).select(F.col("chapter").cast("string")).distinct().toPandas()["chapter"]) \
    if have("policy_document_inventory") else set()
bar("Corpus: every AHCCCS FFS manual chapter ingested", inv_ch >= set(config.CHAPTERS),
    f"{len(inv_ch & set(config.CHAPTERS))} of {len(config.CHAPTERS)} chapter files ingested"
    + (f"; missing {', '.join(sorted(set(config.CHAPTERS) - inv_ch, key=lambda v: (len(v), v)))}" if set(config.CHAPTERS) - inv_ch else "")
    + ". Other authorities (AMPM, fee schedule, other federal edits) are not loaded.")

go_table = pd.DataFrame(GO)
display(go_table)
print(f"{int((go_table['status'] == 'GO').sum())} GO, {int((go_table['status'] != 'GO').sum())} NOT YET. "
      "Done is not declarable while any measurement-bar row is NOT YET.")
