# Databricks notebook source
# MAGIC %md
# MAGIC # 08 · Run detectors against paid claims  (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Runs the build in `main.policy_kb` over the **whole** claims table:
# MAGIC
# MAGIC * **NCCI** — two table-driven statements (PTP pairs, per-line MUEs) cover every federal edit at once.
# MAGIC   The old one-statement-per-pair design needed ~500k self-joins, so runs were capped at 300 detectors
# MAGIC   and MUEs effectively never ran.
# MAGIC * **State** — one statement per compiled rule.
# MAGIC
# MAGIC Writes, in this order (findings first, so telemetry never claims hits that were not stored):
# MAGIC
# MAGIC * `policy_findings` — flagged lines / member-days with `run_id, build_id, rule_id, extraction_key, origin,
# MAGIC   predicate_type, paid_amt, pa_status`. Join `policy_rules_history` on `(build_id, rule_id)` for the rule
# MAGIC   text, quote, source and approver as they were when the finding was produced.
# MAGIC * `policy_detector_runs` — one row per state detector, one row per NCCI rule that fired, one summary row
# MAGIC   per NCCI batch. A batched rule with no row in a run where its batch ran had zero hits.
# MAGIC
# MAGIC `pa_status`: `not_evaluated` (NCCI — CMS: PA is not an NCCI bypass) · `pa_on_file` (severity `verify_pa`:
# MAGIC the PA may authorise the extra units; check it) · `no_pa_on_file`.
# MAGIC
# MAGIC Next: `demos/` and `validation/`.

# COMMAND ----------

import os, sys, time, json
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
from pyspark.sql import functions as F
import config, kb_io
for m in (config, kb_io):
    importlib.reload(m)

KB                    = config.KB
FMT                   = getattr(config, "TABLE_FORMAT", "delta")
RUN_NCCI_BATCH        = True
RUN_STATE             = True
MAX_ROWS_PER_DETECTOR = None      # None = keep every finding. If set, the kept rows are the first N by claim/line (deterministic).
INCLUDE_UNROUTED      = False     # UNROUTED detectors (a service category with no form mapping) over-flag

det = spark.table(f"{KB}.policy_detectors").toPandas()
BUILD_ID = str(det["build_id"].dropna().iloc[0]) if "build_id" in det and det["build_id"].notna().any() else None
assert BUILD_ID, "policy_detectors has no build_id - run 07_build_kb with this package version first"
batches = spark.table(f"{KB}.policy_batch_detectors").toPandas() if RUN_NCCI_BATCH else pd.DataFrame()
state = det[(det["compiled"] == True) & det["sql"].notna()]
if not INCLUDE_UNROUTED:
    state = state[~state["routing"].astype(str).str.startswith("UNROUTED")]
batched_rules = int(det["batch"].notna().sum()) if "batch" in det else 0
DET_ELIGIBLE = len(state) + batched_rules
print(f"build {BUILD_ID}: {len(state)} per-rule detectors + {batched_rules:,} NCCI rules in {len(batches)} batch statement(s)")

run_id = pd.Timestamp.now().strftime("%Y%m%dT%H%M%S")
FINDINGS = f"{KB}.policy_findings"

# One fixed schema. Types match what earlier runs wrote, so appends never hit a type conflict.
_SCHEMA = [("run_id", "string"), ("build_id", "string"), ("rule_id", "string"), ("extraction_key", "string"),
           ("origin", "string"), ("predicate_type", "string"), ("batch", "string"),
           ("claim_id", "string"), ("line_no", "string"), ("member_id", "string"), ("servicing_provider", "string"),
           ("dos", "string"), ("period_start", "string"), ("finding", "string"), ("observed_units", "double"),
           ("allowed_units", "int"), ("finding_severity", "string"), ("pa_present", "int"), ("pa_status", "string"),
           ("paid_amt", "double"), ("col1_claim_id", "string"), ("col1_line_no", "string"), ("pair_scope", "string"),
           ("evidence_lines", "string")]


def normalise(sdf, consts: dict):
    for k, v in consts.items():
        if k not in sdf.columns or v is not None:
            sdf = sdf.withColumn(k, F.lit(v))
    for c, _ in _SCHEMA:
        if c not in sdf.columns:
            sdf = sdf.withColumn(c, F.lit(None))
    sdf = sdf.withColumn("pa_status", F.when((F.col("origin") == "ncci") | F.col("pa_present").isNull(),
                                             F.lit("not_evaluated"))
                                     .when(F.col("pa_present") == 1, F.lit("pa_on_file"))
                                     .otherwise(F.lit("no_pa_on_file")))
    sdf = sdf.select(*[F.col(c).cast(t).alias(c) for c, t in _SCHEMA])
    if MAX_ROWS_PER_DETECTOR:
        sdf = sdf.orderBy("claim_id", "line_no", "member_id", "dos", "period_start").limit(MAX_ROWS_PER_DETECTOR)
    return sdf


def append(sdf):
    sdf.write.format(FMT).mode("append").option("mergeSchema", "true").saveAsTable(FINDINGS)


def hits_by_rule(where: str) -> dict:
    return {r["rule_id"]: r["n"] for r in spark.sql(
        f"SELECT rule_id, COUNT(*) AS n FROM {FINDINGS} WHERE run_id = '{run_id}' AND {where} GROUP BY rule_id").collect()}

# COMMAND ----------

# MAGIC %md ## NCCI — table-driven

# COMMAND ----------

runs = []
PTYPE = {"ncci_ptp": "code_pair_prohibited", "ncci_mue": "max_units_per_line"}
for b in batches.to_dict("records"):
    t0 = time.time()
    rec = {"run_id": run_id, "build_id": BUILD_ID, "rule_id": f"BATCH:{b['batch']}", "extraction_key": None,
           "predicate_type": PTYPE[b["batch"]], "batch": b["batch"], "origin": "ncci", "hits": None,
           "seconds": None, "error": None, "rules_in_batch": int(b["rules"])}
    try:
        if int(b["rules"]) > 0:
            append(normalise(spark.sql(b["sql"]), {"run_id": run_id, "build_id": BUILD_ID, "origin": "ncci",
                                                   "predicate_type": PTYPE[b["batch"]], "batch": b["batch"],
                                                   "extraction_key": None}))
        per_rule = hits_by_rule(f"batch = '{b['batch']}'")
        rec["hits"] = int(sum(per_rule.values()))
        for rid, n in per_rule.items():
            runs.append({"run_id": run_id, "build_id": BUILD_ID, "rule_id": rid, "extraction_key": None,
                         "predicate_type": PTYPE[b["batch"]], "batch": b["batch"], "origin": "ncci", "hits": int(n),
                         "seconds": None, "error": None, "rules_in_batch": None})
    except Exception as e:
        rec["error"] = f"{type(e).__name__}: {str(e)[:500]}"
    rec["seconds"] = round(time.time() - t0, 1)
    runs.append(rec)
    print(f"  {b['batch']}: {b['rules']:,} rules -> {rec['hits']} findings in {rec['seconds']}s"
          + (f"  ERROR {rec['error'][:200]}" if rec["error"] else ""))

# COMMAND ----------

# MAGIC %md ## State — one statement per rule

# COMMAND ----------

if RUN_STATE:
    for i, d in enumerate(state.to_dict("records"), 1):
        t0 = time.time()
        rec = {"run_id": run_id, "build_id": BUILD_ID, "rule_id": d["rule_id"], "extraction_key": d.get("extraction_key"),
               "predicate_type": d["predicate_type"], "batch": None, "origin": d["origin"], "hits": None,
               "seconds": None, "error": None, "rules_in_batch": None}
        try:
            append(normalise(spark.sql(d["sql"]), {"run_id": run_id, "build_id": BUILD_ID, "rule_id": d["rule_id"],
                                                   "extraction_key": d.get("extraction_key"), "origin": d["origin"],
                                                   "predicate_type": d["predicate_type"], "batch": None}))
            rec["hits"] = int(hits_by_rule(f"rule_id = '{d['rule_id']}'").get(d["rule_id"], 0))
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {str(e)[:500]}"
        rec["seconds"] = round(time.time() - t0, 1)
        runs.append(rec)
        if i % 25 == 0:
            print(f"  state {i}/{len(state)}")

runs_df = pd.DataFrame(runs, columns=["run_id", "build_id", "rule_id", "extraction_key", "predicate_type", "batch",
                                      "origin", "hits", "seconds", "error", "rules_in_batch"])
# fixed types: an all-null column in one run must not create the appended table with the wrong type
for c in ("hits", "rules_in_batch"):
    runs_df[c] = pd.to_numeric(runs_df[c]).astype("Int64")
runs_df["seconds"] = pd.to_numeric(runs_df["seconds"]).astype(float)
for c in ("extraction_key", "batch", "error"):
    runs_df[c] = runs_df[c].astype(object)
runs_df["detectors_eligible"] = DET_ELIGIBLE
runs_df["partial_run"] = (not RUN_NCCI_BATCH) or (not RUN_STATE) or bool(MAX_ROWS_PER_DETECTOR)
kb_io.write_table(spark, runs_df, f"{KB}.policy_detector_runs", mode="append")
errors = runs_df["error"].notna().sum()
print(f"\nrun {run_id}: {int(runs_df.loc[runs_df['rule_id'].astype(str).str.startswith('BATCH:') | runs_df['batch'].isna(), 'hits'].fillna(0).sum()):,} findings; "
      f"{int(errors)} detector error(s)")
if errors:
    display(runs_df[runs_df["error"].notna()][["rule_id", "predicate_type", "error"]])

# COMMAND ----------

# MAGIC %md ## What fired (this run)

# COMMAND ----------

display(spark.sql(f"""
SELECT f.origin, f.predicate_type, f.finding_severity, f.pa_status,
       COUNT(*) AS findings, COUNT(DISTINCT f.rule_id) AS rules, ROUND(SUM(f.paid_amt), 2) AS paid_amt
FROM {FINDINGS} f WHERE f.run_id = '{run_id}'
GROUP BY 1, 2, 3, 4 ORDER BY paid_amt DESC
"""))
