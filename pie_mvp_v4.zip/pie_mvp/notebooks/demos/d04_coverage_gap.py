# Databricks notebook source
# MAGIC %md
# MAGIC # d04 · Coverage and gap — how much paid money does policy actually check?
# MAGIC
# MAGIC **What this answers:** the share of paid dollars on codes checked by a federal rule, a state rule, both, or nothing;
# MAGIC which unchecked codes carry the most money; and where AHCCCS policy text exists but nothing runs against claims.
# MAGIC **How to read it:** a code is *covered* when a **compiled detector whose effective window overlaps the claims period**
# MAGIC checks it. Policy text that did not become a detector (a "lead") does not count as coverage.
# MAGIC **Limits:** "covered" means some rule checks the code, not that every rule for it is loaded. Federal = NCCI PTP + MUE only
# MAGIC (CMS public edit set, Arizona deactivations not applied). State = the manual chapters extracted and approved so far.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import functions as F
import config
importlib.reload(config)

TOP_N = 25              # rows in each ranked list (the notebook says how many more there are)

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def show(df, what, n=TOP_N):
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}).")


BUILD_ID = spark.table(T("policy_rules")).where("build_id IS NOT NULL").select("build_id").first()[0]
cov = spark.table(T("policy_coverage")).where(F.col("build_id") == BUILD_ID).toPandas()
summ = spark.table(T("policy_coverage_summary")).where(F.col("build_id") == BUILD_ID).toPandas()
assert len(cov), f"policy_coverage has no rows for the current build {BUILD_ID} - re-run 07_build_kb"
blog = spark.table(T("policy_build_log")).where(F.col("build_id") == BUILD_ID).toPandas()
b = blog.iloc[0] if len(blog) else {}
print(f"build {BUILD_ID} | claims {b.get('claims_from')} to {b.get('claims_to')} | {len(cov):,} paid code(s)")

# COMMAND ----------

# MAGIC %md ## 1. Share of paid dollars by who checks it

# COMMAND ----------

LABEL = {"both": "federal and state", "federal_only": "federal only (NCCI)", "state_only": "state only (AHCCCS manual)",
         "none": "nothing checks it"}
summ["checked_by"] = summ["coverage"].map(LABEL).fillna(summ["coverage"])
display(summ[["checked_by", "codes", "lines", "paid_dollars", "pct_lines", "pct_paid"]].sort_values("paid_dollars", ascending=False))
tot = float(cov["paid_dollars"].sum() or 0)


def pct(mask):
    return 100 * float(cov.loc[mask, "paid_dollars"].sum()) / tot if tot else float("nan")


fed, st, none = pct(cov["coverage"].isin(["both", "federal_only"])), pct(cov["coverage"].isin(["both", "state_only"])), \
    pct(cov["coverage"] == "none")
print(f"Of ${tot:,.2f} paid: {fed:.1f}% is on codes a federal edit checks, {st:.1f}% on codes a state rule checks, "
      f"{none:.1f}% on codes nothing checks. (Federal and state overlap, so the first two can add to more than 100%.)")
print("Read these as an upper bound. A code counts as checked if ANY compiled rule looks at it, even a narrow one: a pair "
      "rule checks a code only when its partner code is billed the same day, yet all the code's dollars count as covered. "
      "And coverage does not mean every policy for the code is loaded.")

# COMMAND ----------

# MAGIC %md ## 2. The gap — unchecked codes ranked by paid dollars

# COMMAND ----------

gap_none = cov[cov["coverage"] == "none"].sort_values("paid_dollars", ascending=False)
print(f"{len(gap_none):,} paid code(s) that NO rule checks:")
show(gap_none[["code", "lines", "units", "paid_dollars", "state_leads"]], "unchecked codes")
fed_only = cov[cov["coverage"] == "federal_only"].sort_values("paid_dollars", ascending=False)
print(f"\n{len(fed_only):,} paid code(s) checked ONLY by NCCI (no AHCCCS rule compiled for them):")
show(fed_only[["code", "lines", "units", "paid_dollars", "ncci_rules", "state_leads"]], "federal-only codes")

# COMMAND ----------

# MAGIC %md ## 3. Policy text exists, but nothing state-side runs
# MAGIC Codes with AHCCCS policy text in the knowledge base (`state_leads` > 0) that still have no compiled state detector.
# MAGIC These are the cheapest coverage gains: the reason column says what is missing.

# COMMAND ----------

leads = cov[(cov["state_leads"] > 0) & cov["coverage"].isin(["none", "federal_only"])].sort_values("paid_dollars", ascending=False)
if len(leads):
    rules = spark.table(T("policy_rules")).where("origin <> 'ncci'").toPandas()
    dets = spark.table(T("policy_detectors")).where("NOT compiled").select("rule_id", "reason").toPandas()
    rules = rules.merge(dets, on="rule_id")
    rules["code_list"] = rules["codes"].map(lambda s: json.loads(s) if isinstance(s, str) else [])
    ex = rules.explode("code_list")
    why = (ex[ex["code_list"].isin(set(leads["code"]))].groupby("code_list")
           .agg(reasons=("reason", lambda s: "; ".join(sorted({str(x) for x in s}))),
                example=("statement", "first")).reset_index().rename(columns={"code_list": "code"}))
    out = leads.merge(why, on="code", how="left")
    print(f"{len(out):,} code(s) have policy text but no compiled state detector:")
    show(out[["code", "coverage", "paid_dollars", "state_leads", "reasons", "example"]], "codes")
else:
    print("No paid code has state policy text that failed to compile (state_leads > 0 with no state detector).")
