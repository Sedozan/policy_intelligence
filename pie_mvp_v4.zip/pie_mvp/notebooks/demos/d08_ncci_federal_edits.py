# Databricks notebook source
# MAGIC %md
# MAGIC # d08 · Federal NCCI edits — what is loaded, how fresh, and what fires
# MAGIC
# MAGIC **What this answers:** which CMS Medicaid NCCI files were loaded and verified, which quarters are missing up to today,
# MAGIC where the practitioner / outpatient / DME editions disagree, and which NCCI edits flag the most paid dollars.
# MAGIC **How to read it:** PTP files are cumulative (each quarter lists every pair with its own dates), so only the newest PTP
# MAGIC quarter is used — what matters is that the *current* quarter is loaded. MUE limits are rebuilt from consecutive
# MAGIC quarters, so a missing quarter in the middle stops the build; after the last loaded quarter the last value is assumed.
# MAGIC **Limits:** NCCI = CMS public edit set; Arizona-specific deactivations (state files on RISSNET) are **not** applied.
# MAGIC Whether a PTP edit still applies on its deletion date is unverified (`config.NCCI_DELETION_DATE_INCLUSIVE`).
# MAGIC Findings are candidates for review, not confirmed overpayments.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
from pyspark.sql import functions as F
import config, acquire_ncci, ingest_ncci_tables
for _m in (config, acquire_ncci, ingest_ncci_tables):
    importlib.reload(_m)

RUN_ID   = None         # None = the latest detector run
MAX_ROWS = 25           # longest list shown per section (the notebook says how many more there are)

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def show(df, what, n=MAX_ROWS):
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}).")


print(f"NCCI source: {getattr(config, 'NCCI_SOURCE', '?')} — per the CMS public edit set; Arizona deactivations are NOT applied.")
print(f"PTP deletion date treated as the last day in force: {config.NCCI_DELETION_DATE_INCLUSIVE} (UNVERIFIED - SB to confirm).")

# COMMAND ----------

# MAGIC %md ## 1. Acquisition log — what was downloaded, checked and loaded

# COMMAND ----------

if spark.catalog.tableExists(config.NCCI_ACQUISITION_LOG):
    log = spark.table(config.NCCI_ACQUISITION_LOG).toPandas()
    log["sha256"] = log["sha256"].astype(str).str[:16]
    print(f"{len(log):,} file(s) logged: {log['status'].value_counts().to_dict()}")
    show(log.sort_values(["quarter", "edit", "service"], ascending=[False, True, True])[
        ["quarter", "edit", "service", "status", "rows", "sha256", "table", "loaded_at", "warning", "error"]], "log rows")
else:
    print(f"No {config.NCCI_ACQUISITION_LOG}: NCCI tables were loaded by hand (before 00_acquire_ncci existed).")

# COMMAND ----------

# MAGIC %md ## 2. Quarters loaded, and quarters missing up to today

# COMMAND ----------

metas = ingest_ncci_tables.discover_tables(spark, config.CATALOG, config.SCHEMA)
cy, cq = acquire_ncci.current_quarter()
rows = []
for (svc, edit), g in pd.DataFrame(metas).groupby(["service", "edit_type"]) if metas else []:
    loaded = sorted({(int(y), int(q)) for y, q in zip(g["year"], g["quarter"])})
    miss = acquire_ncci.missing_quarters(loaded)
    latest = f"{loaded[-1][0]}Q{loaded[-1][1]}"
    gaps = [m for m in miss if (int(m[:4]), int(m[-1])) < loaded[-1]]
    behind = [m for m in miss if (int(m[:4]), int(m[-1])) > loaded[-1]]
    rows.append({"service": svc, "edit": edit, "quarters_loaded": ", ".join(f"{y}Q{q}" for y, q in loaded),
                 "latest": latest, "current_quarter_loaded": loaded[-1] >= (cy, cq),
                 "not_loaded_since_latest": ", ".join(behind) or "none",
                 "gaps_between_loaded": (", ".join(gaps) or "none") + (" (PTP: harmless, only the newest is used)"
                                                                       if gaps and edit == "ptp" else "")})
fresh = pd.DataFrame(rows)
print(f"today is in {cy}Q{cq}.")
show(fresh, "service/edit combinations")
if len(fresh) and not fresh["current_quarter_loaded"].all():
    print("Some editions are behind the current quarter: federal findings for recent claims use the last loaded quarter's "
          "edits. Run 00_acquire_ncci.")
editions = set(fresh["service"]) if len(fresh) else set()
if editions and editions != {"practitioner", "outpatient", "dme"}:
    print(f"Editions loaded: {sorted(editions)}. Missing editions: {sorted({'practitioner', 'outpatient', 'dme'} - editions)}.")

# COMMAND ----------

# MAGIC %md ## 3. Editions that disagree on the same code
# MAGIC When practitioner / outpatient / DME give different values for one code, the build keeps the **most permissive** one
# MAGIC (highest MUE, bypassable pair) so a shared claim form is not flagged by the stricter edition. The per-edition values are kept.

# COMMAND ----------

dis = (spark.table(T("policy_rules")).where(F.col("reconciliation").startswith("ncci_editions_disagree"))
       .select("rule_id", "statement", "reconciliation", "notes", "effective_date", "end_date").toPandas())
print(f"{len(dis):,} NCCI rule(s) where editions disagree.")
show(dis, "rules")

# COMMAND ----------

# MAGIC %md ## 4. NCCI edits that flag the most paid dollars (latest run)

# COMMAND ----------

RUN_ID = RUN_ID or spark.table(T("policy_detector_runs")).agg(F.max("run_id")).first()[0]
f = spark.table(T("policy_findings")).where((F.col("run_id") == RUN_ID) & (F.col("origin") == "ncci"))
n = f.count()
lines = f.dropDuplicates(["claim_id", "line_no"])
tot = lines.agg(F.count("*").alias("n"), F.sum("paid_amt").alias("paid")).first()
print(f"run {RUN_ID}: {n:,} NCCI finding(s) on {tot['n']:,} distinct claim line(s), ${float(tot['paid'] or 0):,.2f} paid "
      "(each line once, even when several edits flag it).")
top = (f.dropDuplicates(["rule_id", "claim_id", "line_no"]).groupBy("rule_id", "predicate_type", "finding_severity")
       .agg(F.count("*").alias("lines"), F.round(F.sum("paid_amt"), 2).alias("paid"))
       .join(spark.table(T("policy_rules")).select("rule_id", "statement", "doc_version"), "rule_id", "left")
       .orderBy(F.desc("paid"), "rule_id").toPandas())
print("By edit (a line flagged by two edits counts under both, so these rows can add to more than the total):")
show(top, "edits")
