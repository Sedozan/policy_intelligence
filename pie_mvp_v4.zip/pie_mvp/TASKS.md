# PIE — work log and checklist

## 2026-09-29 — make the pipeline work as expected, clean notebooks, demos

### Pipeline fixes (from GAP_TO_DONE.md)
- [x] D1 HYBRID cached unparseable model output as "no rules" → tolerant parse, retryable, never cached (subagent; verified by probe)
- [x] D2 grounding: min quote length, codes-near-quote flag, truncated-condition flag, source text stored (not model text), word-number drift, no quote overwrite in HYBRID merge (subagent; verified by probe)
- [x] D2b provenance column `extraction_source`; D11 per-section outcomes table `policy_extraction_outcomes`
- [x] D3 PTP direction kept across editions
- [x] D4 overlapping edition windows split into segments, collapsed per segment; `reconciliation` label
- [x] D5 new document version → approvals go to `needs_review` with `prior_review`; build excludes approvals from an older doc_hash
- [x] D6 migrate upserts seeds (never overwrites); review ingest: pending-only, doc_hash required, table written before log, shrink guard
- [x] D7 coverage counts compiled, in-window detectors only; `state_leads` column; summary table saved
- [x] D8 `build_id` on rules/detectors/findings; `*_history` tables; NCCI rule ids stable across quarters
- [x] D9 NCCI ingest fails loudly (no tables, bad modifier, missing eff date, non-numeric MUE); `config.NCCI_STRICT`
- [x] D10 `config.NCCI_DELETION_DATE_INCLUSIVE` switch (semantics still UNVERIFIED — SB to confirm)
- [x] Detection at scale: NCCI PTP + MUE table-driven (2 SQL statements), no 300 cap; equivalence-tested vs per-rule SQL on 5 random seeds
- [x] Findings carry `paid_amt`, `pa_status`, `origin`, `predicate_type`, `extraction_key`, `build_id`
- [x] State pairs evaluate PA on either line; daily caps accept `code_set`
- [x] Seed vs extracted duplicates collapse to the extracted rule (`supersedes` recorded)
- [x] Registers: `policy_ambiguity_register`, `policy_rule_overlaps` (contradiction candidates)
- [x] Superseded PDFs archived to `policy_docs/_versions/`
- [x] Bug found by e2e: all-null reviewer column → float64 → assignment fails (pandas 3); fixed
- [x] Bug found by e2e: `policy_review_log` text columns created as DOUBLE from empty cells → first real note would fail the append; fixed + notebook 06 checks an existing table and prints the repair
- [x] Bugs reported by demo subagent: quote not carried to policy_rules; MUE doc_version cited only the first quarter; v04 stale text/CSV path — fixed and pinned
- [x] Extracted rules get `EXT-` ids (were `MAN-`, read as hand-authored)

### Notebooks
- [x] Removed `extract_chapters` (single-cluster GPU+UC path; SB's GPU cannot write Delta), `diag_model` (serving-endpoint route, unused), `demo_kb` (split into demos/)
- [x] Numbered in run order 00–08; `profile_chapters` → `validation/v04_chapter_profile`
- [x] demos/ (9) and validation/ (v01–v03 new, v04 moved) notebooks + `quality.py` (subagent; re-run and verified)
- [x] README rewritten around the true run order; historical docs → docs/

### Verification
- [x] 148 offline tests
- [x] `tests/e2e_local_spark.py`: every pipeline notebook, in order, on local Spark 3.5 (ANSI on) — ALL CHECKS PASSED
- [x] e2e with `--demos` — ALL CHECKS PASSED (independently re-run)

### Open (need SB)
- [ ] Confirm PTP deletion-date semantics (D10)
- [ ] `COMPILE_LEGACY_SEEDS` — keep the 21 unsigned seeds compiling? (default True = unchanged behaviour)
- [ ] DME service token in existing NCCI table names (`dme` assumed)
- [ ] First real HYBRID run: Ch19 only, then score with validation/v01

## 2026-09-28 — gap audit + NCCI automation
- [x] Four-way audit vs definition-of-done → GAP_TO_DONE.md
- [x] `acquire_ncci.py` + notebook (drop zone / download, archive, validate, log)
