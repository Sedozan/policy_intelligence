"""
rule_normalize.py  -  post-gate, pre-compile normalisation of rule dicts.

Runs on Rule.to_dict() output after validate_gate.gate(). Pure and idempotent.

  stable ids     rule_id is re-derived from CONTENT (origin, source, statement,
                 predicate, dates). The legacy assign_id() collided badly - one
                 id was shared by nine different Chapter 10 rules - which makes
                 policy_rules unusable as a keyed table.
  dedupe         identical content collapses to one row.
  plane          derived deterministically from predicate type; never hand-set,
                 never 'enforcement' (a claims outcome is not a policy plane).
  provenance     source_url / doc_hash filled for NCCI rows if missing.
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Iterable

MEDICAID_NCCI_URL = ("https://www.cms.gov/medicare/coding-billing/"
                     "ncci-medicaid/medicaid-ncci-edit-files")

# ----------------------------------------------------------------- plane
_PLANE_BY_PREDICATE = {
    "code_pair_prohibited":   "coding_edit",
    "max_units_per_line":     "coding_edit",
    "max_units_per_dos":      "coding_edit",
    "max_units_per_day":      "coding_edit",
    "max_units_per_period":   "coverage_scope",
    "max_dollars_per_period": "coverage_scope",
    "frequency_limit":        "coverage_scope",
    "code_not_covered":       "coverage_scope",
}
_PLANE_BY_REASON = {
    "requires_medical_record":   "medical_necessity",
    "requires_member_attribute": "coverage_scope",
    "cross_source_conflict":     "coverage_scope",
    "ambiguous_source":          "coverage_scope",
}


def derive_plane(rule: dict) -> str:
    pred = rule.get("predicate") or {}
    t = pred.get("type")
    if t == "not_checkable":
        reason = pred.get("reason") or rule.get("not_checkable_reason")
        return _PLANE_BY_REASON.get(reason, "coverage_scope")
    return _PLANE_BY_PREDICATE.get(t, "coverage_scope")


# ------------------------------------------------------------- stable id
from schema import content_signature, stable_rule_id, PLANES  # noqa: E402


# ------------------------------------------------------------ provenance
def enrich_provenance(rule: dict) -> dict:
    if rule.get("origin") != "ncci":
        return rule
    if not rule.get("source_url"):
        rule["source_url"] = MEDICAID_NCCI_URL
    if not rule.get("doc_hash"):
        rule["doc_hash"] = content_signature(rule)[:16]
    return rule


# ------------------------------------------------- cross-edition collapse
# NCCI publishes practitioner / outpatient / dme editions separately, and in this
# claims table all three land on FORM_TYP 'A' (form cannot tell them apart). So a
# code that appears in >1 edition would otherwise produce multiple detectors on the
# same 'A' claims, and the stricter one would false-positive the other edition's
# claims. We collapse per (predicate shape + codes + EXACT date window) to the MOST
# PERMISSIVE limit:
#   MUE  -> the maximum threshold  (a finding then violates every edition)
#   PTP  -> indicator 1 if any edition allows a bypass, else 0
# The per-edition values are kept in predicate['editions'] and the note, for audit.
#
# The date window is PART OF THE KEY (fix, 2026-09-20). Two rules collapse only when
# they cover the SAME effective/end window. This is the guard against the P0 that
# reviewers found: keying by (type, code) alone also merged different TEMPORAL runs
# of the SAME edition — e.g. code A at 2 units Jan-Mar and 4 units Apr-onward would
# collapse to "4 units from Jan", so a February 3-unit claim wrongly passed. It also
# stops the unsafe window-widening (applying a threshold during dates it never held).
# Editions that genuinely share a window still collapse (the intended dedup); editions
# with different windows stay as separate, correctly-windowed detectors. Whether the
# MOST-PERMISSIVE default is right at all is a separate (open) decision; this only
# guarantees the collapse never fabricates or destroys a temporal run.
_MUE_TYPES = {"max_units_per_line", "max_units_per_dos", "max_units_per_day"}

# D3 (2026-09-29): the PTP key is DIRECTIONAL. Column One/Column Two order is the edit:
# CMS denies the Column Two code. Sorting the pair merged A/B (indicator 1) with B/A
# (indicator 0) into one direction, silently losing a hard denial.
# D4 (2026-09-29): editions whose windows OVERLAP without being identical (practitioner
# 4 units from 2020, outpatient 1 unit from 2023) used to compile as two detectors, so
# the STRICTER limit fired from 2023 with no flag - the opposite of the stated policy.
# Now each group is split into elementary date intervals and collapsed per interval.
_MIN, _MAX = date.min, date.max


def _group_key(r: dict):
    if r.get("origin") != "ncci":
        return None
    p = r.get("predicate") or {}
    t = p.get("type")
    if t == "code_pair_prohibited":
        return ("ptp", str(p.get("code_a")).upper(), str(p.get("code_b")).upper())
    if t in _MUE_TYPES:
        return (t, str(p.get("code")).upper())
    return None


def _edition_key(r: dict):
    """Kept for callers/tests: the group key plus the rule's own window."""
    k = _group_key(r)
    return None if k is None else k + ((r.get("effective_date"), r.get("end_date")),)


def _d(s, default):
    return date.fromisoformat(str(s)[:10]) if s not in (None, "") else default


def _bounds(r: dict) -> tuple[date, date]:
    """[start, end_exclusive)."""
    end = _d(r.get("end_date"), None)
    return _d(r.get("effective_date"), _MIN), (_MAX if end is None else end + timedelta(days=1))


def _collapse_members(kind: str, members: list[dict]) -> tuple[dict, dict, str]:
    svc_of = lambda m: (m.get("predicate") or {}).get("service_category")
    if kind == "ptp":
        base = max(members, key=lambda m: str((m.get("predicate") or {}).get("modifier_indicator")) == "1")
        p = dict(base["predicate"])
        editions = {svc_of(m): str(m["predicate"].get("modifier_indicator")) for m in members}
        p["modifier_indicator"] = "1" if "1" in editions.values() else "0"
        what = "most-permissive indicator kept"
    else:
        base = max(members, key=lambda m: int((m.get("predicate") or {}).get("threshold", 0)))
        p = dict(base["predicate"])
        editions = {svc_of(m): int(m["predicate"].get("threshold", 0)) for m in members}
        p["threshold"] = max(editions.values())
        what = "maximum (most-permissive) threshold kept"
    return base, p, (editions, what)


def collapse_ncci_editions(rules: list[dict]) -> tuple[list[dict], int]:
    groups: dict = {}
    out: list[dict] = []
    for r in rules:
        k = _group_key(r)
        (groups.setdefault(k, []).append(r) if k is not None else out.append(r))
    collapsed = 0
    for k, members in groups.items():
        if len(members) == 1:
            out.append(members[0])
            continue
        spans = [_bounds(m) for m in members]
        cuts = sorted({b for s in spans for b in s})
        segs: list[list] = []                     # [lo, hi, active_idx_tuple]
        for lo, hi in zip(cuts, cuts[1:]):
            active = tuple(i for i, (a, b) in enumerate(spans) if a <= lo and b >= hi)
            if not active:
                continue
            if segs and segs[-1][1] == lo and segs[-1][2] == active:
                segs[-1][1] = hi                  # same members active: extend
            else:
                segs.append([lo, hi, active])
        emitted = 0
        for lo, hi, active in segs:
            act = [members[i] for i in active]
            if len(act) == 1 and _bounds(act[0]) == (lo, hi):
                out.append(act[0]); emitted += 1
                continue
            base, p, (editions, what) = _collapse_members("ptp" if k[0] == "ptp" else "mue", act)
            winner = dict(base)
            p["service_category"] = "ncci"
            p["editions"] = editions
            winner["predicate"] = p
            winner["effective_date"] = None if lo == _MIN else lo.isoformat()
            winner["end_date"] = None if hi == _MAX else (hi - timedelta(days=1)).isoformat()
            bits = ", ".join(f"{s}={v}" for s, v in editions.items())
            clipped = "" if all(_bounds(m) == (lo, hi) for m in act) else " Window split where editions overlap."
            winner["notes"] = ((base.get("notes") or "") + f" Collapsed across NCCI editions ({bits}); {what}.{clipped}").strip()
            if len(set(editions.values())) > 1:
                winner["ambiguity_flag"] = True
                winner["ambiguity_note"] = ((base.get("ambiguity_note") or "")
                                            + f" NCCI editions disagree ({bits}); using most permissive.").strip()
                winner["reconciliation"] = "ncci_editions_disagree:most_permissive"
            else:
                winner["reconciliation"] = "ncci_editions_agree"
            out.append(winner); emitted += 1
        collapsed += len(members) - emitted
    return out, collapsed


# --------------------------------------------- state duplicates (seed vs extracted)
# The 21 hand-authored seeds and approved extracted rules often state the SAME policy
# (Ch10 CHW pairs, 11975 not covered). Both compiled, so one paid line produced two
# identical findings and double-counted its dollars. Same meaning = same predicate
# (minus routing labels) + codes + population + window. Keep ONE: an approved extracted
# rule (it carries the verbatim quote, page and doc_hash) over a hand-authored seed.
_ROUTING_KEYS = {"service_category", "editions"}


def _state_key(r: dict):
    # only executable, coded rules: two uncoded leads with the same reason are DIFFERENT policy text
    if r.get("origin") == "ncci" or not r.get("machine_checkable", True) or not r.get("codes"):
        return None
    if (r.get("predicate") or {}).get("type") == "not_checkable":
        return None
    p = {k: v for k, v in (r.get("predicate") or {}).items() if k not in _ROUTING_KEYS}
    if p.get("type") == "code_pair_prohibited":
        # compare what COMPILES: the compiler defaults scope and indicator, so the key must too
        from detector_gen import pair_scope
        p["scope"] = pair_scope(r)
        p["modifier_indicator"] = str(p.get("modifier_indicator", "0"))
    import json as _json

    def _d(v):                       # pandas NaN != NaN would make identical rules look different
        return None if v is None or (isinstance(v, float) and v != v) or v == "" else str(v)[:10]
    return (_json.dumps(p, sort_keys=True, default=str), tuple(sorted(str(c).upper() for c in r.get("codes") or [])),
            (r.get("population") or "all").lower(), _d(r.get("effective_date")), _d(r.get("end_date")))


def collapse_state_duplicates(rules: list[dict]) -> tuple[list[dict], int]:
    rank = {"extracted": 0, "manual": 1}
    groups: dict = {}
    out = []
    for r in rules:
        k = _state_key(r)
        (groups.setdefault(k, []).append(r) if k is not None else out.append(r))
    dropped = 0
    for members in groups.values():
        members = sorted(members, key=lambda m: rank.get(m.get("origin"), 2))
        keep = dict(members[0])
        if len(members) > 1:
            gone = [stable_rule_id(m) for m in members[1:]]
            keep["supersedes"] = sorted(set((keep.get("supersedes") or []) + gone))
            keep["reconciliation"] = f"state_duplicate_collapsed:{len(gone)}"
            keep["notes"] = ((keep.get("notes") or "") + f" Supersedes {len(gone)} identical rule(s): {', '.join(gone)}.").strip()
            dropped += len(gone)
        out.append(keep)
    return out, dropped


# ---------------------------------------------------------- orchestrator
def normalize_rules(rules: Iterable[dict], collapse_editions: bool = True) -> tuple[list[dict], dict]:
    rules = [dict(r) for r in rules]
    dropped_enforcement = sum(1 for r in rules
                              if r.get("plane") == "enforcement" or (r.get("predicate") or {}).get("type") == "edit_failure")
    rules = [r for r in rules
             if not (r.get("plane") == "enforcement" or (r.get("predicate") or {}).get("type") == "edit_failure")]
    editions_collapsed = 0
    if collapse_editions:
        rules, editions_collapsed = collapse_ncci_editions(rules)
    rules, state_dupes = collapse_state_duplicates(rules)

    out: dict[str, dict] = {}
    collapsed = 0
    id_changed = 0
    for r in rules:
        r = dict(r)
        new_id = stable_rule_id(r)
        if r.get("rule_id") != new_id:
            id_changed += 1
        r["rule_id"] = new_id
        r["plane"] = derive_plane(r)
        r = enrich_provenance(r)
        if new_id in out:
            collapsed += 1
            continue
        out[new_id] = r

    rows = list(out.values())
    planes: dict[str, int] = {}
    for r in rows:
        planes[r["plane"]] = planes.get(r["plane"], 0) + 1
    report = {
        "rules_out": len(rows),
        "enforcement_rows_dropped": dropped_enforcement,
        "ncci_editions_collapsed": editions_collapsed,
        "state_duplicates_collapsed": state_dupes,
        "duplicate_content_collapsed": collapsed,
        "rule_ids_rederived": id_changed,
        "plane_counts": planes,
    }
    return rows, report
