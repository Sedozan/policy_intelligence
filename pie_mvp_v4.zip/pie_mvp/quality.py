"""
quality.py  -  the measurement bar, in plain pandas (no Spark).

Used by notebooks/validation/v01_extraction_scoring and v02_detector_precision. Everything here is
deterministic and unit-tested (tests/test_quality.py).

  wilson(k, n)                 95% Wilson score interval for a proportion k/n.
  n_needed(p_hat, target)      sample size at which the Wilson LOWER bound reaches `target`,
                               if the observed rate stays at p_hat.
  n_for_ci_width(p_hat, width) sample size at which the whole interval is no wider than `width`.
  stratified_sample(df, by, n_per, seed)
                               up to n_per rows per stratum, chosen by a seeded hash of each
                               row's key - same rows every time, whatever order Spark returns.
  extraction_metrics(rules, sections)   precision / fidelity / recall rows per chapter + pooled.
  detector_metrics(findings)            precision per origin x predicate_type + pooled,
                                        plus the share the reviewer could not decide.
  xlsx_write_sheets / xlsx_read_sheets  multi-sheet workbooks, Volume-safe like state_rules._xlsx_write
                                        (which writes a single sheet).
  as_text_frame(df)            all-text columns before appending a workbook to a table.

Metric rows have the columns in METRIC_COLUMNS; the notebook adds sample_id and computed_at.
"""
from __future__ import annotations

import hashlib
import math

import pandas as pd

METRIC_COLUMNS = ["metric", "scope_type", "scope", "n", "value", "ci_low", "ci_high", "notes"]
DISPOSITIONS = ("true_violation", "false_positive", "cannot_tell")

_YES = {"y", "yes", "true", "1", "1.0", "t"}
_NO = {"n", "no", "false", "0", "0.0", "f"}


# ------------------------------------------------------------------ intervals
def wilson(k, n, z: float = 1.96) -> tuple[float, float, float]:
    """(p, lo, hi). n = 0 -> (nan, 0.0, 1.0): no data means the rate could be anything."""
    n = float(n or 0)
    if n <= 0:
        return float("nan"), 0.0, 1.0
    k = float(k)
    if k < 0 or k > n:
        raise ValueError(f"k={k} outside 0..n={n}")
    p = k / n
    z2 = z * z
    denom = 1.0 + z2 / n
    centre = (p + z2 / (2 * n)) / denom
    half = (z / denom) * math.sqrt(p * (1 - p) / n + z2 / (4 * n * n))
    return p, max(0.0, centre - half), min(1.0, centre + half)


def n_needed(p_hat: float, target: float, z: float = 1.96, n_max: int = 1_000_000) -> int | None:
    """Smallest n whose Wilson lower bound is >= target when the observed rate is p_hat.

    None when it can never happen (p_hat <= target: the lower bound is always below p_hat)
    or would need more than n_max. The observed rate is held fixed, so this is a planning
    number, not a promise - the next samples can move p_hat either way."""
    if p_hat is None or (isinstance(p_hat, float) and math.isnan(p_hat)) or p_hat <= target:
        return None

    def lo(n):
        return wilson(p_hat * n, n, z)[1]

    if lo(n_max) < target:
        return None
    a, b = 1, n_max                                   # lo(n) rises with n at a fixed rate
    while a < b:
        m = (a + b) // 2
        if lo(m) >= target:
            b = m
        else:
            a = m + 1
    return a


def n_for_ci_width(p_hat: float, width: float, z: float = 1.96, n_max: int = 1_000_000) -> int | None:
    """Smallest n whose Wilson interval (hi - lo) is <= width when the observed rate is p_hat.
    A planning number for "measured precisely enough to state"; None if above n_max or p_hat is missing."""
    if p_hat is None or (isinstance(p_hat, float) and math.isnan(p_hat)) or width <= 0:
        return None

    def w(n):
        _, lo, hi = wilson(p_hat * n, n, z)
        return hi - lo

    if w(n_max) > width:
        return None
    a, b = 1, n_max                                   # the interval narrows as n grows
    while a < b:
        m = (a + b) // 2
        if w(m) <= width:
            b = m
        else:
            a = m + 1
    return a


# ------------------------------------------------------------------ sampling
def _strings(df: pd.DataFrame, cols: list, blank: str, sep: str = "|") -> pd.Series:
    """Row-wise join of `cols` as text; missing values become `blank`."""
    parts = [df[c].astype(object).where(df[c].notna(), blank).astype(str) for c in cols]
    out = parts[0]
    for p in parts[1:]:
        out = out + sep + p
    return out


def sample_hash(df: pd.DataFrame, key: list, seed: int) -> pd.Series:
    """sha256("<seed>#<k1>|<k2>|...") per row, nulls as ''. Spark equivalent: sample_hash_sql()."""
    joined = _strings(df, list(key), "")
    return pd.Series([hashlib.sha256(f"{seed}#{s}".encode()).hexdigest() for s in joined], index=df.index)


def sample_hash_sql(key: list, seed: int) -> str:
    """The same hash as sample_hash(), as a Spark SQL expression - lets a notebook pre-select the
    candidate rows in Spark (millions of findings) and hand only those to stratified_sample(),
    which then picks exactly the rows it would have picked from the full table. Key columns must
    be strings (or render identically with CAST AS STRING)."""
    cols = ", ".join(f"COALESCE(CAST({c} AS STRING), '')" for c in key)
    return f"sha2(concat('{int(seed)}#', concat_ws('|', {cols})), 256)"


def stratified_sample(df: pd.DataFrame, by: list, n_per: int, seed: int = 0,
                      key: list | None = None) -> pd.DataFrame:
    """Up to n_per rows from every stratum (combination of `by` values).

    Selection is the lowest sample_hash() of each row's `key` columns (default: every column), so
    the result does not depend on row order or on the pandas / numpy version, and adding rows to a
    stratum never reshuffles which of the old rows were picked. Adds:
      stratum       the `by` values joined with ' | '  (missing -> '(none)')
      stratum_size  rows in that stratum before sampling (to weight a pooled estimate)
    """
    if df is None or len(df) == 0:
        cols = list(df.columns) if df is not None else []
        return pd.DataFrame(columns=cols + ["stratum", "stratum_size"])
    if n_per is None or int(n_per) < 1:
        raise ValueError("n_per must be >= 1")
    key = list(key) if key else [c for c in df.columns]
    d = df.copy()
    d["stratum"] = _strings(d, list(by), "(none)", " | ") if by else "all"
    d["stratum_size"] = d.groupby("stratum")["stratum"].transform("size").astype(int)
    d["_h"] = sample_hash(d, key, seed)
    d = d.sort_values(["stratum", "_h"], kind="mergesort")
    d["_rank"] = d.groupby("stratum").cumcount()
    out = d[d["_rank"] < int(n_per)].drop(columns=["_h", "_rank"])
    return out.reset_index(drop=True)


# ------------------------------------------------------------------ helpers
def _yn(v):
    """'Y'/'N' (and yes/no/true/false/1/0) -> True/False; blank or anything else -> None."""
    if _is_blank(v):
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    return True if s in _YES else False if s in _NO else None


def _int_or_none(v):
    try:
        if _is_blank(v):
            return None
        i = int(float(v))
        return i if i >= 0 else None
    except (TypeError, ValueError):
        return None


def _row(metric, scope_type, scope, k, n, notes="") -> dict:
    p, lo, hi = wilson(k, n)
    return {"metric": metric, "scope_type": scope_type, "scope": str(scope), "n": int(n),
            "value": p, "ci_low": lo, "ci_high": hi, "notes": notes}


def _scopes(df: pd.DataFrame, col: str):
    """[(scope_type, scope, sub-frame)] - one per value of `col`, then the pooled sample."""
    out = []
    if col in df.columns:
        for v, g in df.groupby(df[col].astype(object).where(df[col].notna(), "(none)").astype(str), sort=True):
            out.append((col, v, g))
    out.append(("overall", "all", df))
    return out


_POOLED = "pooled over the sample, not weighted by stratum size"


# ------------------------------------------------------------------ extraction
def extraction_metrics(scored_rules: pd.DataFrame | None, scored_sections: pd.DataFrame | None) -> pd.DataFrame:
    """Per chapter and pooled:

    extraction_precision  is_real_rule = Y among rules scored Y or N
    extraction_fidelity   faithful_to_source = Y among REAL rules scored Y or N
    extraction_recall     found / (found + missed) over sampled sections, where found =
                          rules_extracted (what the pipeline produced from the section) and
                          missed = missed_rules (the SME's count). Rules are treated as
                          independent trials; rules cluster in sections, so the interval is
                          optimistic.
    Blank scores are excluded and counted in notes.
    """
    rows = []
    r = scored_rules.copy() if scored_rules is not None else pd.DataFrame()
    if len(r):
        r["_real"] = r["is_real_rule"].map(_yn) if "is_real_rule" in r else None
        r["_faith"] = r["faithful_to_source"].map(_yn) if "faithful_to_source" in r else None
        for st, sc, g in _scopes(r, "chapter"):
            scored = g[g["_real"].notna()]
            k = int((scored["_real"] == True).sum())  # noqa: E712
            blank = len(g) - len(scored)
            note = (f"{blank} unscored row(s) excluded. " if blank else "") + (_POOLED if st == "overall" else "")
            rows.append(_row("extraction_precision", st, sc, k, len(scored), note.strip()))
            real = scored[scored["_real"] == True]  # noqa: E712
            fs = real[real["_faith"].notna()]
            fk = int((fs["_faith"] == True).sum())  # noqa: E712
            fblank = len(real) - len(fs)
            note = (f"{fblank} real rule(s) without a fidelity score excluded. " if fblank else "") + \
                   (_POOLED if st == "overall" else "")
            rows.append(_row("extraction_fidelity", st, sc, fk, len(fs), note.strip()))
    s = scored_sections.copy() if scored_sections is not None else pd.DataFrame()
    if len(s):
        s["_found"] = s["rules_extracted"].map(_int_or_none) if "rules_extracted" in s else 0
        s["_missed"] = s["missed_rules"].map(_int_or_none) if "missed_rules" in s else None
        for st, sc, g in _scopes(s, "chapter"):
            scored = g[g["_missed"].notna()]
            found = int(scored["_found"].fillna(0).sum())
            missed = int(scored["_missed"].sum()) if len(scored) else 0
            blank = len(g) - len(scored)
            note = (f"{len(scored)} section(s) scored; {found} rule(s) found, {missed} missed. "
                    + (f"{blank} unscored section(s) excluded. " if blank else "")
                    + "Rules within a section are not independent, so the interval is optimistic.")
            rows.append(_row("extraction_recall", st, sc, found, found + missed, note))
    return pd.DataFrame(rows, columns=METRIC_COLUMNS)


# ------------------------------------------------------------------ detectors
def detector_metrics(scored_findings: pd.DataFrame | None) -> pd.DataFrame:
    """Per stratum (origin x predicate_type) and pooled:

    detector_precision        true_violation / (true_violation + false_positive)
    detector_cannot_tell_share cannot_tell / every dispositioned finding

    cannot_tell is EXCLUDED from precision (it is neither right nor wrong) but reported, because a
    high share means the evidence shown to the reviewer is not enough to decide.
    """
    rows = []
    f = scored_findings.copy() if scored_findings is not None else pd.DataFrame()
    if not len(f):
        return pd.DataFrame(rows, columns=METRIC_COLUMNS)
    disp = f["disposition"] if "disposition" in f else pd.Series([None] * len(f), index=f.index)
    f["_d"] = disp.map(lambda v: str(v).strip().lower() if isinstance(v, str) and str(v).strip() else None)
    f["_d"] = f["_d"].where(f["_d"].isin(DISPOSITIONS), None)
    if "stratum" not in f:
        f["stratum"] = (f.get("origin", pd.Series("?", index=f.index)).astype(str) + " | "
                        + f.get("predicate_type", pd.Series("?", index=f.index)).astype(str))
    for st, sc, g in _scopes(f, "stratum"):
        tv = int((g["_d"] == "true_violation").sum())
        fp = int((g["_d"] == "false_positive").sum())
        ct = int((g["_d"] == "cannot_tell").sum())
        blank = int(g["_d"].isna().sum())
        note = (f"{tv} true, {fp} false positive, {ct} cannot_tell (excluded)"
                + (f", {blank} blank/invalid (excluded)" if blank else "") + "."
                + (f" {_POOLED}." if st == "overall" else ""))
        rows.append(_row("detector_precision", st, sc, tv, tv + fp, note))
        rows.append(_row("detector_cannot_tell_share", st, sc, ct, tv + fp + ct,
                         "share of dispositioned findings the reviewer could not decide"))
    return pd.DataFrame(rows, columns=METRIC_COLUMNS)


# ------------------------------------------------------------------ workbooks
XLSX_CELL_MAX = 32_000          # Excel refuses cells over 32,767 characters


def _is_blank(v) -> bool:
    if v is None:
        return True
    if isinstance(v, str):
        return not v.strip()
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def clip_text(v, limit: int = XLSX_CELL_MAX):
    """Cut long text so a workbook cell can hold it; says so in the cell."""
    if _is_blank(v):
        return None
    s = str(v)
    return s if len(s) <= limit else s[: limit - 40] + f" ...[cut: {len(s):,} chars total]"


def xlsx_write_sheets(sheets: dict, path: str) -> str:
    """Several sheets in one workbook, Volume-safe the same way as state_rules._xlsx_write (which
    writes one sheet): openpyxl seeks while writing, which a UC Volume (FUSE) rejects, so write to
    local disk and then copy sequentially. Returns where the file actually is."""
    import os
    import shutil
    import tempfile
    local = os.path.join(tempfile.gettempdir(), os.path.basename(path))
    with pd.ExcelWriter(local, engine="openpyxl") as xw:
        for name, df in sheets.items():
            df.to_excel(xw, sheet_name=str(name)[:31], index=False)
    if os.path.abspath(local) == os.path.abspath(path):
        return path
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        shutil.copyfile(local, path)
        return path
    except OSError as e:
        print(f"  could not copy workbook to {path} ({e}); it is at {local}")
        return local


def xlsx_read_sheets(path: str) -> dict:
    """{sheet name: DataFrame}; falls back to a local copy when the path is on a Volume."""
    import os
    import shutil
    import tempfile
    try:
        return pd.read_excel(path, sheet_name=None, engine="openpyxl")
    except OSError:
        local = os.path.join(tempfile.gettempdir(), "read_" + os.path.basename(path))
        shutil.copyfile(path, local)
        return pd.read_excel(local, sheet_name=None, engine="openpyxl")


def as_text_frame(df: pd.DataFrame, keep_numeric: tuple = ()) -> pd.DataFrame:
    """Every column as text (None for blanks) except `keep_numeric`. Appending a workbook whose
    column happens to be all-blank would otherwise create the table column as DOUBLE and make the
    next append fail on a type conflict (the policy_review_log bug, 2026-09)."""
    out = df.copy()
    for c in out.columns:
        if c in keep_numeric:
            out[c] = pd.to_numeric(out[c], errors="coerce").astype(float)
        else:
            out[c] = [None if _is_blank(v) else str(v) for v in out[c]]
            out[c] = out[c].astype(object)
    return out
