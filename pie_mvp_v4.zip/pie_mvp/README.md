# PIE — Policy Intelligence Engine (MVP package)

Turns AHCCCS billing policy into checks you can run: federal NCCI edits and AHCCCS FFS Provider Billing
Manual chapters become one cited, versioned, reviewed rule table. That table compiles to SQL, the SQL runs
over paid claims, and every finding traces back to the policy text, the document version and the person
who approved the rule.

The LLM only **proposes** state rules. Deterministic grounding checks each proposal against the PDF, a named
reviewer signs it, and only signed rules compile. No model sits in the detection path.

---

## Run order

Copy the whole `pie_mvp` folder into `…/Projects/policy_intelligence/` (overwrite), then import the notebooks
keeping the folder structure. All notebooks find the package on their own. Set `PKB_PACKAGE_DIR` only if you
move them.

| # | notebook | compute | when | what it does | writes |
|---|---|---|---|---|---|
| 00 | `00_acquire_ncci` | CPU + UC | **quarterly** (schedule it monthly) | finds the six CMS Medicaid NCCI zips on the CMS page, archives them, parses, validates, loads one table per file. No egress: drop the zips in `data/ncci_raw/` and set `DOWNLOAD = False` | `main.sedo.medicaid_ncci_edit_*`, `ncci_acquisition_log` |
| 01 | `01_preflight_ncci` | CPU + UC | after 00 | read-only GO/NO-GO on the NCCI tables (quarter gaps, PTP snapshot assumption, claims date coverage, edition disagreement) | — |
| 02 | `02_migrate_state_rules` | CPU + UC | once (safe to re-run) | upserts the 21 hand-authored seed rules. **Never** deletes drafts or reviews | `main.sedo.state_rules` |
| 03 | `03_stage_inputs` | CPU + UC | each extraction cycle | copies chapter PDFs (all 31 files) and table snapshots into workspace files for the GPU step | `data/policy_docs/`, `data/snapshots/` |
| 04 | `04_extract_chapters_gpu` | **Serverless GPU** | each extraction cycle | gpt-oss-120b proposes rules; grounding keeps or refuses each one. Files only, no Spark. Default `CHAPTERS_TO_RUN = ["19"]` | `data/extraction_runs/<run_id>/` |
| 05 | `05_persist_extraction` | CPU + UC | after 04 | merges drafts into `state_rules`, appends run telemetry, exports the review workbook | `state_rules`, `policy_extraction_*`, `policy_sections`, `policy_document_inventory`, `data/review/policy_rules_review.xlsx` |
| — | *SME review* | Excel | after 05 | reviewer fills `decision` (Approve / Reject / Fix), `reviewer`, `review_note` in the workbook | — |
| 06 | `06_review_decisions` | CPU + UC | after review | applies signed decisions to pending rows only | `state_rules`, `policy_review_log` |
| 07 | `07_build_kb` | CPU + UC | after 00 or 06 | gate → normalise → compile; coverage; registers; `build_id` + history | `policy_rules`, `policy_detectors`, NCCI edit tables, coverage, gap, registers, `*_history`, `policy_build_log` |
| 08 | `08_run_detectors` | CPU + UC | after 07 | NCCI as two table-driven statements, state rules one statement each, whole claims table | `policy_findings`, `policy_detector_runs` |

**Your first real extraction:** run 03 → 04 (Ch19 only, `LLM_BACKEND = "HYBRID"`) → 05 → review → 06 → 07 → 08,
then score it with `validation/v01_extraction_scoring`. Widen `CHAPTERS_TO_RUN` only after the score is known.

**When AHCCCS revises a chapter:** run 03 → 04 → 05. Approved rules from the old PDF drop to `needs_review` with
their `prior_review` kept, and 07 **excludes** them until someone re-signs them against the new text. The old PDF
is kept in `data/policy_docs/_versions/`.

---

## Demos and validation (`notebooks/demos`, `notebooks/validation`)

Read-only unless noted. Each opens with *What this answers / How to read it / Limits*.

| notebook | answers |
|---|---|
| `d01_code_lookup` | everything that governs one procedure code: federal edits, state rules with quotes, leads, overlaps, exposure, findings. Says "No governing authority found" when that is the answer |
| `d02_finding_explainer` | the audit trail for one finding: claim lines, the rule *as it was in that build*, the policy words, the source, the approver, PA status, and a plain-English paragraph |
| `d03_provider_review` | providers by distinct flagged dollars, which rules drive them, flag rate against peers billing the same codes |
| `d04_coverage_gap` | share of paid dollars a compiled detector checks (federal / state / none); biggest unchecked codes; policy text with no detector yet |
| `d05_ambiguity_register` | unclear or unenforceable policy, by category, with quotes. Exports an xlsx for AHCCCS |
| `d06_federal_state_overlaps` | where CMS and AHCCCS rules cover the same code, who is stricter, contradiction **candidates** |
| `d07_policy_change_impact` | document versions, change events, rules waiting for re-sign, stale approvals, orphaned findings |
| `d08_ncci_federal_edits` | NCCI quarters loaded or missing, acquisition log, edition disagreements, top-firing edits |
| `d09_policy_text_search` | keyword search over the manual's sections with page references |
| `v01_extraction_scoring` | exports a scoring sample; after the SME scores it, computes extraction precision, fidelity and recall per chapter with 95% intervals (writes `policy_quality_metrics`) |
| `v02_detector_precision` | exports a findings sample; after investigator dispositions, computes precision per rule type (writes `policy_quality_metrics`, `policy_finding_reviews`) |
| `v03_pipeline_health` | the definition-of-done measurement bar: GO / NOT YET per item. Nothing says GO without a measured number |
| `v04_chapter_profile` | which chapters the current grammar can handle (code families, rule cues) — run before choosing the next chapter |

---

## Package

```
config.py              every table name, claims column, switch and path
schema.py              Rule + closed predicate grammar + content-derived ids (NCCI- / EXT- / MAN-)
acquire_ncci.py        CMS page → archived zips → validated main.sedo quarter tables
ingest_ncci_tables.py  NCCI tables → rules (latest PTP snapshot; dated MUE runs; fails loudly on bad rows)
policy_docs.py         PDF → sections (acquire + archive old versions, parse, headings, pre-filter)
extract_rules.py       sections → proposals (STUB / HFLOCAL / HYBRID) → grounding → drafts; per-section outcomes
extract_io.py          GPU ⇄ CPU hand-off files; guard against shrinking state_rules
state_rules.py         the reviewed rule table: merge, re-sign on new doc version, review workbook round-trip
state_seed.py          21 hand-authored, cited Ch10/Ch19 rules (legacy_hand_authored)
validate_gate.py       clean / patched / downgraded / needs_review / rejected, with reasons
rule_normalize.py      stable ids, planes, NCCI edition collapse (directional, split by window), state duplicate collapse
detector_gen.py        rules → SQL; NCCI PTP/MUE as two table-driven statements
gap.py                 coverage from compiled, in-window detectors, weighted by paid dollars
registers.py           ambiguity register; federal/state overlaps and contradiction candidates
quality.py             sampling, Wilson intervals, extraction and detector metrics
policy_changes.py      what changed between document versions
kb_io.py               pandas → Delta with explicit types
tests/                 148 offline tests; e2e_local_spark.py runs every notebook on a local Spark
docs/                  earlier review brief and change logs (historical)
```

## Tables (`main.policy_kb` unless noted)

| table | one row per |
|---|---|
| `main.sedo.state_rules` | state rule, hand-authored or extracted, with `review_status`, `prior_review`, `extraction_source` |
| `main.sedo.medicaid_ncci_edit_*`, `main.sedo.ncci_acquisition_log` | CMS edit row per quarter; acquisition event |
| `policy_document_inventory`, `policy_sections` | chapter × fetch (doc_hash, revision date); section |
| `policy_extraction_outcomes` | section × run: `skipped_prefilter` / `no_rules` / `proposals` / `failed_retryable` — the recall ledger |
| `policy_extraction_log`, `policy_extraction_dropped`, `policy_extraction_cache`, `policy_change_log` | run telemetry, refused proposals, model cache, change events |
| `policy_review_log` | reviewer decision, the doc_hash it was made against, and whether it was applied |
| `policy_rules`, `policy_rules_history` | rule in the current build / every build (`build_id`, reviewer, quote, jurisdiction) |
| `policy_detectors`, `policy_detectors_history`, `policy_batch_detectors` | rule → SQL or lead reason; the two NCCI batch statements |
| `policy_ncci_ptp_edits`, `policy_ncci_mue_limits` | NCCI edit as data, for the batch statements |
| `policy_coverage`, `policy_coverage_summary`, `policy_gap` | paid code × coverage; coverage shares; unchecked codes by paid $ |
| `policy_ambiguity_register`, `policy_rule_overlaps` | unclear policy entry; federal/state rule pair on a code |
| `policy_build_log` | build: counts, coverage %, stale approvals excluded, register sizes, NCCI quarters |
| `policy_findings`, `policy_detector_runs` | flagged line or member-day (`build_id`, `paid_amt`, `pa_status`); detector execution |
| `policy_quality_metrics`, `policy_extraction_scores`, `policy_finding_reviews` | measured quality numbers and the raw scores behind them |

A finding reaches its rule text with `policy_findings JOIN policy_rules_history USING (build_id, rule_id)`.
The same claim line can be flagged by more than one rule (e.g. an NCCI pair and a state pair), so count
**distinct `(claim_id, line_no)`** when adding up dollars.

## Decisions that are yours (config.py)

| switch | default | meaning |
|---|---|---|
| `COMPILE_LEGACY_SEEDS` | `True` | the 21 seed rules compile without a named reviewer or document version. The definition of done says nothing should. `False` = approved rules only |
| `NCCI_DELETION_DATE_INCLUSIVE` | `True` | **unverified**: whether a PTP edit still applies on its deletion date. Confirm in the Medicaid NCCI Technical Guidance Manual; it shifts every deleted edit by one day |
| `NCCI_STRICT` | `True` | bad NCCI rows (modifier not 0/1/9, missing effective date, non-numeric MUE) stop the build instead of being dropped |
| `NCCI_ALLOW_EMPTY` | `False` | no NCCI tables stops the build instead of publishing a state-only KB |
| `NCCI_ALLOW_MUE_GAPS` | `False` | a missing MUE quarter stops the build instead of assuming the old value held |

## How the rules stay honest

| stage | guarantee |
|---|---|
| propose | closed grammar; the model must quote the source; unclear → `not_checkable`, never a guess |
| ground | the quote must be in the section and at least 6 words (or name every code); every code in the section; threshold in the quoted sentence; negation/number drift refused. A quote that drops an "unless…/except…" clause, or codes stated far from the quote, is kept but flagged and capped at 0.5 confidence. The stored quote is the **source** text, not the model's |
| outcomes | every section gets an outcome row, so recall can be measured |
| merge | keyed by meaning. Approved rows are never downgraded by a re-run of the same document. A **new document version** sends them back for re-sign |
| review | a decision needs a named reviewer, the document version it was made on, and a row that is still pending |
| build | only approved rules (and seeds, if allowed) from the **current** document version compile. Identical seed/extracted rules collapse to one |
| detect | deterministic SQL; NCCI ignores PA (CMS: not a bypass); state findings with a PA number are `verify_pa`, never suppressed |

**NCCI routing.** The claims `FORM_TYP` does not tell practitioner, outpatient and DME editions apart (all land on
`A`), so NCCI detectors select claims by procedure code. A code in more than one edition takes the most permissive
limit **per date segment**, keeps each pair's direction, and is flagged `ncci_editions_disagree` when editions differ.
The real fix is a provider-type field; flip `NCCI_ROUTE_BY_FORM` when one exists. Findings follow the CMS public edit
set; Arizona deactivations (RISSNET files) are not applied.

## Testing

```
python -m pytest tests -q                         # 148 offline tests, ~2 s
# every notebook, in the order above, on a local Spark (needs pyspark + Java):
python tests/e2e_local_spark.py --demos
```
The end-to-end run uses synthetic claims and NCCI tables with the real column names, the fixture PDF (Chapter 10
layout), the pattern backend instead of the model, and parquet instead of Delta. It plants known violations and
checks they are found (and that a modifier-59 bypass is not). It also checks that a PDF revision pulls approvals
out of the build until they are re-signed.

## Not verified yet (needs your workspace)

* A real model run (04 with HYBRID). Every draft so far has come from regex patterns.
* The exact layout inside CMS's NCCI text files (the parser finds the header itself and stops if it can't).
* Cluster egress to cms.gov and azahcccs.gov (drop-zone and upload fallbacks exist).
* The DME token in your existing NCCI table names (`dme` assumed): `SHOW TABLES IN main.sedo LIKE 'medicaid_ncci_edit_*'`.
* PTP deletion-date semantics (see the switches above).

## Upgrading from the previous package (one-time effects)

* **NCCI rule ids change once.** The quarter label left the id, so from now on ids stay the same across quarters.
  Extracted rules now use the `EXT-` prefix. Findings from before this version have no `build_id` and won't join to
  history.
* New columns (`state_rules.prior_review / extraction_source / model_quote`, and new findings and run columns) are
  added on the next write.
* `06_review_decisions` checks that `policy_review_log`'s text columns are text. If an earlier run created them as
  DOUBLE (empty workbook cells), it stops and prints the one-line repair. It changes nothing on its own.
* Notebooks were renamed 00–08. `extract_chapters` (single GPU+UC cluster), `diag_model` (serving-endpoint route) and
  `demo_kb` (now `demos/`) were removed.
