"""quality.py: Wilson interval, sample-size planning, deterministic stratified sampling, metric edge cases.
Run: cd pie_mvp && python -m pytest tests -q
"""
import math
import os
import sys

import pandas as pd
import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import quality as q


# ------------------------------------------------------------------ wilson
def _wilson_by_hand(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z / d * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return c - h, c + h


def test_wilson_95_of_100():
    p, lo, hi = q.wilson(95, 100)
    assert p == pytest.approx(0.95)
    assert lo == pytest.approx(0.8883, abs=5e-4)          # published value 0.888
    assert hi == pytest.approx(0.9785, abs=5e-4)          # published value 0.978
    assert (lo, hi) == pytest.approx(_wilson_by_hand(95, 100))


@pytest.mark.parametrize("k,n,lo,hi", [
    (0, 10, 0.0, 0.2775),      # all failures: lower bound pinned at 0, upper well above 0
    (10, 10, 0.7225, 1.0),     # all successes: upper bound 1, lower bound well below 1
    (5, 10, 0.2366, 0.7634),   # symmetric around 0.5
    (18, 20, 0.6990, 0.9721),  # the "n=20 can't tell 95% from 80%" case in GAP_TO_DONE
])
def test_wilson_known_values(k, n, lo, hi):
    _, a, b = q.wilson(k, n)
    assert a == pytest.approx(lo, abs=5e-4) and b == pytest.approx(hi, abs=5e-4)


def test_wilson_n_zero_is_uninformative():
    p, lo, hi = q.wilson(0, 0)
    assert math.isnan(p) and lo == 0.0 and hi == 1.0


def test_wilson_rejects_k_above_n():
    with pytest.raises(ValueError):
        q.wilson(5, 4)


# ------------------------------------------------------------------ n_needed
def test_n_needed_reaches_target_and_is_minimal():
    n = q.n_needed(0.98, 0.95)
    assert n is not None
    assert q.wilson(0.98 * n, n)[1] >= 0.95
    assert q.wilson(0.98 * (n - 1), n - 1)[1] < 0.95


def test_n_needed_impossible_when_rate_not_above_target():
    assert q.n_needed(0.95, 0.95) is None
    assert q.n_needed(0.90, 0.95) is None
    assert q.n_needed(float("nan"), 0.95) is None


def test_n_needed_perfect_rate_closed_form():
    # p=1: lo = n / (n + z^2) >= t  <=>  n >= t z^2 / (1 - t)
    z = 1.96
    assert q.n_needed(1.0, 0.95) == math.ceil(0.95 * z * z / 0.05)


def test_n_for_ci_width_minimal_and_monotone():
    n = q.n_for_ci_width(0.9, 0.10)
    _, lo, hi = q.wilson(0.9 * n, n)
    assert hi - lo <= 0.10
    _, lo, hi = q.wilson(0.9 * (n - 1), n - 1)
    assert hi - lo > 0.10
    assert q.n_for_ci_width(0.5, 0.10) > n                   # p = 0.5 is the widest
    assert q.n_for_ci_width(float("nan"), 0.1) is None


# ------------------------------------------------------------------ sampling
def _frame(n=60):
    return pd.DataFrame({"chapter": [str(10 + i % 3) for i in range(n)],
                         "src": ["pattern" if i % 2 else "model" for i in range(n)],
                         "rule_id": [f"R{i:03d}" for i in range(n)]})


def test_stratified_sample_is_deterministic_and_order_independent():
    df = _frame()
    a = q.stratified_sample(df, ["chapter", "src"], 3, seed=7, key=["rule_id"])
    b = q.stratified_sample(df.sample(frac=1, random_state=1), ["chapter", "src"], 3, seed=7, key=["rule_id"])
    assert list(a["rule_id"]) == list(b["rule_id"])
    assert len(a) == 6 * 3
    assert set(a["stratum_size"]) == {10}
    c = q.stratified_sample(df, ["chapter", "src"], 3, seed=8, key=["rule_id"])
    assert set(c["rule_id"]) != set(a["rule_id"])            # the seed matters


def test_stratified_sample_small_strata_and_nulls():
    df = pd.DataFrame({"chapter": ["10", "10", None], "rule_id": ["a", "b", "c"]})
    s = q.stratified_sample(df, ["chapter"], 5, seed=1, key=["rule_id"])
    assert len(s) == 3                                        # smaller than n_per: take all
    assert set(s["stratum"]) == {"10", "(none)"}
    assert s["chapter"].isna().sum() == 1                     # data itself is not rewritten


def test_stratified_sample_adding_rows_keeps_old_picks_unless_displaced():
    df = _frame(30)
    a = q.stratified_sample(df, ["chapter"], 4, seed=3, key=["rule_id"])
    more = pd.concat([df, pd.DataFrame({"chapter": ["99"], "src": ["model"], "rule_id": ["NEW"]})])
    b = q.stratified_sample(more, ["chapter"], 4, seed=3, key=["rule_id"])
    assert set(a["rule_id"]) <= set(b["rule_id"])


def test_stratified_sample_empty():
    s = q.stratified_sample(pd.DataFrame(columns=["chapter", "rule_id"]), ["chapter"], 3)
    assert len(s) == 0 and "stratum" in s.columns


def test_sample_hash_sql_mentions_every_key():
    sql = q.sample_hash_sql(["claim_id", "line_no"], 5)
    assert "'5#'" in sql and "claim_id" in sql and "line_no" in sql and "sha2" in sql


# ------------------------------------------------------------------ extraction metrics
def test_extraction_metrics_basic_and_blank_scores():
    rules = pd.DataFrame({"chapter": ["10"] * 4 + ["19"] * 2,
                          "is_real_rule": ["Y", "Y", "N", None, "yes", "n"],
                          "faithful_to_source": ["Y", "N", "Y", None, "Y", None]})
    secs = pd.DataFrame({"chapter": ["10", "10", "19"], "rules_extracted": [2, 0, 1], "missed_rules": [1, 1, None]})
    m = q.extraction_metrics(rules, secs).set_index(["metric", "scope"])
    assert m.loc[("extraction_precision", "10"), "n"] == 3            # blank excluded
    assert m.loc[("extraction_precision", "10"), "value"] == pytest.approx(2 / 3)
    assert "1 unscored" in m.loc[("extraction_precision", "10"), "notes"]
    # fidelity among REAL rules only: ch10 real = 2 (Y,Y) -> faithful Y,N
    assert m.loc[("extraction_fidelity", "10"), "n"] == 2
    assert m.loc[("extraction_fidelity", "10"), "value"] == pytest.approx(0.5)
    assert m.loc[("extraction_precision", "all"), "n"] == 5
    # recall: ch10 found 2, missed 2 -> 0.5 ; ch19 unscored -> n = 0
    assert m.loc[("extraction_recall", "10"), "value"] == pytest.approx(0.5)
    assert m.loc[("extraction_recall", "19"), "n"] == 0
    assert math.isnan(m.loc[("extraction_recall", "19"), "value"])
    assert m.loc[("extraction_recall", "all"), "n"] == 4


def test_extraction_metrics_empty_inputs():
    assert len(q.extraction_metrics(None, None)) == 0
    m = q.extraction_metrics(pd.DataFrame({"chapter": ["10"], "is_real_rule": [None],
                                           "faithful_to_source": [None]}), None)
    row = m[(m.metric == "extraction_precision") & (m.scope == "10")].iloc[0]
    assert row["n"] == 0 and math.isnan(row["value"]) and row["ci_low"] == 0.0 and row["ci_high"] == 1.0


def test_extraction_recall_all_found_nothing_missed():
    secs = pd.DataFrame({"chapter": ["4"], "rules_extracted": [3], "missed_rules": [0]})
    r = q.extraction_metrics(None, secs).iloc[0]
    assert r["value"] == 1.0 and r["n"] == 3


# ------------------------------------------------------------------ detector metrics
def test_detector_metrics_excludes_cannot_tell():
    f = pd.DataFrame({"origin": ["ncci"] * 4 + ["extracted"] * 2,
                      "predicate_type": ["code_pair_prohibited"] * 4 + ["code_not_covered"] * 2,
                      "disposition": ["true_violation", "false_positive", "cannot_tell", "  TRUE_VIOLATION ",
                                      "bogus", None]})
    m = q.detector_metrics(f).set_index(["metric", "scope"])
    k = ("detector_precision", "ncci | code_pair_prohibited")
    assert m.loc[k, "n"] == 3 and m.loc[k, "value"] == pytest.approx(2 / 3)
    assert m.loc[("detector_cannot_tell_share", "ncci | code_pair_prohibited"), "value"] == pytest.approx(1 / 4)
    e = ("detector_precision", "extracted | code_not_covered")
    assert m.loc[e, "n"] == 0 and "2 blank/invalid" in m.loc[e, "notes"]


def test_detector_metrics_all_cannot_tell():
    f = pd.DataFrame({"stratum": ["s"] * 3, "disposition": ["cannot_tell"] * 3})
    m = q.detector_metrics(f).set_index(["metric", "scope"])
    assert m.loc[("detector_precision", "s"), "n"] == 0
    assert math.isnan(m.loc[("detector_precision", "s"), "value"])
    assert m.loc[("detector_cannot_tell_share", "s"), "value"] == 1.0


def test_detector_metrics_empty():
    assert list(q.detector_metrics(None).columns) == q.METRIC_COLUMNS
    assert len(q.detector_metrics(pd.DataFrame())) == 0
