"""
End-to-end run of the REAL notebooks, in README order, on a local Spark (no Databricks).

    SPARK_HOME=... PYTHONPATH=<pyspark> python tests/e2e_local_spark.py [--keep] [--demos]

What is real: every notebook's source, every module, Spark SQL (ANSI mode on, as on DBR 17),
the fixture PDF (AHCCCS Chapter 10 layout). What is simulated: the claims and NCCI tables
(synthetic, real column names), tables are parquet instead of Delta, the model is the STUB
pattern backend, and the SME review is filled in by this script.

Scenario:
  1  00_acquire_ncci (drop zone, CMS-shaped zips) + hand-loaded-style NCCI table for an older quarter
  2  01_preflight_ncci, 02_migrate_state_rules (twice: must be idempotent, must keep reviews)
  3  03_stage -> 04_extract (STUB) -> 05_persist -> reviewer approves -> 06_review_decisions
  4  07_build_kb -> 08_run_detectors; assert findings for the planted violations
  5  the Ch10 PDF is REVISED -> re-extract -> approved rules become needs_review, 07_build_kb
     excludes nothing stale that was re-signed... and 08 still runs
  6  (--demos) every notebook under notebooks/demos and notebooks/validation
"""
from __future__ import annotations

import io
import json
import os
import shutil
import sys
import tempfile
import time
import traceback
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ROOT = os.environ.get("E2E_ROOT", os.path.join(tempfile.gettempdir(), "pie_e2e"))
KEEP = "--keep" in sys.argv
DEMOS = "--demos" in sys.argv

if not KEEP and os.path.exists(ROOT):
    shutil.rmtree(ROOT)
os.makedirs(ROOT, exist_ok=True)
os.environ.update({
    "PKB_PACKAGE_DIR": PKG, "PKB_CATALOG": "spark_catalog", "PKB_OUTPUT_CATALOG": "spark_catalog",
    "PKB_CLAIMS": "spark_catalog.prod_input.all_data_c_a", "PKB_TABLE_FORMAT": "parquet",
    "PKB_WORKSPACE_DATA_DIR": os.path.join(ROOT, "data"), "PKB_NCCI_RAW_DIR": os.path.join(ROOT, "data", "ncci_raw"),
})
sys.path.insert(0, PKG)
sys.path.insert(0, HERE)

import pandas as pd  # noqa: E402
from pyspark.sql import SparkSession  # noqa: E402

spark = (SparkSession.builder.master("local[2]").appName("pie-e2e")
         .config("spark.ui.enabled", "false").config("spark.sql.ansi.enabled", "true")
         .config("spark.sql.warehouse.dir", os.path.join(ROOT, "warehouse"))
         .config("spark.sql.shuffle.partitions", "4").config("spark.driver.memory", "2g").getOrCreate())
spark.sparkContext.setLogLevel("ERROR")
for s in ("sedo", "policy_kb", "prod_input"):
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS spark_catalog.{s}")

import config  # noqa: E402

DISPLAYED: list = []


def display(x):
    DISPLAYED.append(x)
    try:
        df = x.toPandas() if hasattr(x, "toPandas") else x
        print(df.head(12).to_string() if hasattr(df, "to_string") else df)
    except Exception as e:                       # display must never be the thing that fails
        print(f"[display] {type(e).__name__}: {e}")


class _Lib:
    def restartPython(self):
        pass


class _DBU:
    library = _Lib()

    class widgets:
        @staticmethod
        def get(name):
            raise Exception("no widgets locally")


def run_nb(rel: str, subs: dict | None = None):
    path = os.path.join(PKG, "notebooks", rel)
    src = open(path).read()
    for old, new in (subs or {}).items():
        assert old in src, f"{rel}: substitution target not found: {old!r}"
        src = src.replace(old, new)
    g = {"spark": spark, "display": display, "dbutils": _DBU(), "__name__": "__main__", "__file__": path}
    t0 = time.time()
    print(f"\n{'=' * 100}\n>>> {rel}\n{'=' * 100}")
    cwd = os.getcwd()
    os.chdir(os.path.dirname(path))
    try:
        exec(compile(src, path, "exec"), g)
    finally:
        os.chdir(cwd)
    print(f"<<< {rel} OK ({time.time() - t0:.1f}s)")
    return g


def T(name):
    return spark.table(f"spark_catalog.{name}").toPandas()


# ---------------------------------------------------------------- fixtures
def make_claims():
    """Planted violations (all on 2026-01-15 unless noted):
       m1/p1: 11111 + 22222 same provider, no modifier        -> NCCI PTP hard denial (indicator 0)
       m2/p1: 33333 + 44444, 59 on one line                    -> bypassed (indicator 1) -> no finding
       m3/p1: J3490 x 5 units                                   -> NCCI MUE 1/line
       m4:    98960 x 3 + 98961 x 2 same day                    -> Ch10 CHW 4/day seed + same-day pair seed
       m5:    11975                                             -> Ch10 'do not bill' (not covered)"""
    C = config.CLAIM_COLS
    rows = []

    def add(cid, ln, mem, prov, dos, code, units, paid, m1="", pa=None):
        rows.append({C["claim_id"]: cid, C["line_no"]: ln, C["member"]: mem, C["servicing_provider"]: prov,
                     C["billing_provider"]: prov, C["dos"]: dos, C["code"]: code, C["units"]: units,
                     C["paid_amt"]: paid, C["pos"]: "11", C["form"]: "A", C["mods"][0]: m1, C["mods"][1]: "",
                     C["mods"][2]: "", C["mods"][3]: "", C["pa_no"]: pa})
    add("c1", 1, "m1", "p1", "2026-01-15", "11111", 1, 100.0)
    add("c1", 2, "m1", "p1", "2026-01-15", "22222", 1, 60.0)
    add("c2", 1, "m2", "p1", "2026-01-15", "33333", 1, 80.0)
    add("c2", 2, "m2", "p1", "2026-01-15", "44444", 1, 40.0, m1="59")
    add("c3", 1, "m3", "p2", "2026-01-15", "J3490", 5, 25.0)
    add("c4", 1, "m4", "p3", "2026-01-15", "98960", 3, 30.0)
    add("c4", 2, "m4", "p3", "2026-01-15", "98961", 2, 20.0, pa="PA123")
    add("c5", 1, "m5", "p4", "2026-02-01", "11975", 1, 300.0)
    for i in range(40):                                     # background volume, no violations
        add(f"bg{i}", 1, f"b{i % 7}", "p9", "2025-11-0" + str(1 + i % 9), "99213", 1, 75.0)
    df = pd.DataFrame(rows)
    import kb_io
    sdf = kb_io.to_spark(spark, df)
    from pyspark.sql import functions as F
    sdf = (sdf.withColumn(C["dos"], F.to_date(C["dos"]))
              .withColumn(C["units"], F.col(C["units"]).cast("decimal(15,4)"))
              .withColumn(C["paid_amt"], F.col(C["paid_amt"]).cast("decimal(15,2)")))
    sdf.write.mode("overwrite").format("parquet").saveAsTable(config.CLAIMS_TABLE)


def cms_zip(path, member, text):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(member, text)


def make_ncci():
    raw = os.path.join(config.NCCI_RAW_DIR, "2026q1")
    os.makedirs(raw, exist_ok=True)
    ptp = ("Medicaid NCCI PTP Edits - Practitioner Services\n"
           "Quarter Begin Date\tCategory\tColumn One\tColumn Two\tEffective Date\tDeletion Date\tModifier Indicator\tPTP Edit Rationale\n"
           "20260101\tPractitioner\t11111\t22222\t20100101\t*\t0\tMutually exclusive procedures\n"
           "20260101\tPractitioner\t33333\t44444\t20100101\t*\t1\tMisuse of column two code\n"
           "20260101\tPractitioner\t98960\t98961\t20100101\t*\t1\tStandard\n")
    mue = ("Quarter Begin Date\tCategory\tHCPCS/CPT Code\tPractitioner Services MUE Values\tMUE Rationale\n"
           "20260101\tPractitioner\tJ3490\t1\tNature of Service\n"
           "20260101\tPractitioner\t98960\t8\tClinical\n")
    cms_zip(os.path.join(raw, "medicaid-ncci-2026-q1-ptp-edits-practitioner-services.zip"), "PTP.txt", ptp)
    cms_zip(os.path.join(raw, "medicaid-ncci-2026-q1-mue-edits-practitioner-services.zip"), "MUE.txt", mue)
    # an OLDER quarter loaded the old manual way (SB's column names), so ingest sees both shapes
    old = pd.DataFrame({"HCPCS/CPT Code": ["J3490", "98960"], "Practitioner Services MUE Values": [1, 8],
                        "MUE Rationale": ["Nature of Service", "Clinical"]})
    (spark.createDataFrame(old).toDF("HCPCS_CPT_Code_manual", "Practitioner_Services_MUE_Values", "MUE_Rationale")
     .write.mode("overwrite").format("parquet")
     .saveAsTable(f"spark_catalog.sedo.medicaid_ncci_edit_practitioner_mue_q4_2025"))


def fixture_pdf(dest_dir, revised=False):
    import fixture_pdf
    os.makedirs(dest_dir, exist_ok=True)
    path = os.path.join(dest_dir, os.path.basename(config.CHAPTERS["10"][1]))
    fixture_pdf.build(path)
    if revised:                                            # a revision = new bytes = new doc_hash
        with open(path, "ab") as f:
            f.write(b"\n% revised 2026-10-01\n")
    return path


def approve_all(reviewer="SB (e2e)", note=None):
    import state_rules
    wb = os.path.join(config.WORKSPACE_DATA_DIR, "review", "policy_rules_review.xlsx")
    df = pd.read_excel(wb)
    df["decision"] = "Approve"
    df["reviewer"] = reviewer
    if note:
        df["review_note"] = note
    df.to_excel(wb, index=False)
    return len(df)


# ------------------------------------------------------------------ scenario
FAIL = []


def check(cond, msg):
    print(("  PASS  " if cond else "  FAIL  ") + msg)
    if not cond:
        FAIL.append(msg)


def main():
    make_claims()
    make_ncci()
    pdf_dir = config.STAGE_PDF_DIR
    fixture_pdf(pdf_dir)

    run_nb("00_acquire_ncci.py", {"DOWNLOAD         = True": "DOWNLOAD         = False"})
    log = T("sedo.ncci_acquisition_log")
    check(set(log["status"]) == {"loaded"}, f"acquire: both CMS zips loaded ({log['status'].tolist()})")
    run_nb("01_preflight_ncci.py")

    run_nb("02_migrate_state_rules.py")
    n_seed = len(T("sedo.state_rules"))
    check(n_seed > 0, f"migrate: {n_seed} seed rows")

    stage_subs = {"CHAPTERS_TO_STAGE = list(config.CHAPTERS)": 'CHAPTERS_TO_STAGE = ["10"]',
                  "DOWNLOAD          = True": "DOWNLOAD          = False"}
    gpu_subs = {'CHAPTERS_TO_RUN = ["19"]': 'CHAPTERS_TO_RUN = ["10"]',
                'LLM_BACKEND     = "HYBRID"': 'LLM_BACKEND     = "STUB"',
                "ALLOW_PATTERNS_ONLY = False": "ALLOW_PATTERNS_ONLY = True"}
    run_nb("03_stage_inputs.py", stage_subs)
    run_nb("04_extract_chapters_gpu.py", gpu_subs)
    run_nb("05_persist_extraction.py")
    sr = T("sedo.state_rules")
    drafts = sr[sr["review_status"] == "draft"]
    check(len(drafts) > 0, f"extraction: {len(drafts)} drafts from the fixture PDF")
    check(drafts["extraction_source"].notna().all(), "drafts carry extraction_source")
    outc = T("policy_kb.policy_extraction_outcomes")
    check(len(outc) > 0 and set(outc["outcome"]) >= {"proposals"}, f"outcomes recorded: {outc['outcome'].value_counts().to_dict()}")

    n = approve_all()
    run_nb("06_review_decisions.py")
    sr = T("sedo.state_rules")
    check((sr["review_status"] == "approved").sum() == n, f"review: {n} approved with a named reviewer")

    run_nb("02_migrate_state_rules.py")                     # D6: re-run must keep the approvals
    sr2 = T("sedo.state_rules")
    check((sr2["review_status"] == "approved").sum() == n and len(sr2) == len(sr), "migrate re-run kept every review (D6)")

    run_nb("07_build_kb.py")
    bl = T("policy_kb.policy_build_log").iloc[-1]
    check(bl["detectors_batched"] > 0, f"build: {bl['detectors_batched']} NCCI rules batched, {bl['detectors_compiled']} compiled")
    run_nb("08_run_detectors.py")
    f = T("policy_kb.policy_findings")
    last = f[f["run_id"] == f["run_id"].max()]
    got = {(r.origin, r.predicate_type, r.claim_id) for r in last.itertuples()}
    print(last[["origin", "predicate_type", "rule_id", "claim_id", "line_no", "finding", "paid_amt", "pa_status"]].to_string())
    check(("ncci", "code_pair_prohibited", "c1") in got, "PTP hard denial found on the Column Two line (c1)")
    check(not any(k[2] == "c2" and k[1] == "code_pair_prohibited" and k[0] == "ncci" for k in got), "59-bypassed pair NOT flagged")
    check(("ncci", "max_units_per_line", "c3") in got, "MUE J3490 5 > 1 found")
    check(any(k[0] != "ncci" and k[2] == "c5" for k in got), "state 'do not bill 11975' found")
    check(last["build_id"].notna().all() and last["paid_amt"].notna().all(), "findings carry build_id and paid_amt")
    hist = T("policy_kb.policy_rules_history")
    j = last.merge(hist, on=["build_id", "rule_id"], how="left")
    check(j["statement"].notna().all(), "every finding joins policy_rules_history on (build_id, rule_id)")

    # ---- a PDF revision: approvals must go back for re-sign and stop compiling until then
    fixture_pdf(pdf_dir, revised=True)
    run_nb("03_stage_inputs.py", stage_subs)
    run_nb("04_extract_chapters_gpu.py", gpu_subs)
    run_nb("05_persist_extraction.py")
    sr3 = T("sedo.state_rules")
    ext = sr3[sr3["origin"] == "extracted"]
    check((ext["review_status"] == "needs_review").all() and ext["prior_review"].notna().all(),
          f"revision: extracted approvals -> needs_review with prior_review ({ext['review_status'].value_counts().to_dict()})")
    run_nb("07_build_kb.py")
    rules = T("policy_kb.policy_rules")
    check(not (rules["origin"] == "extracted").any(), "revision: no extracted rule compiles until re-signed (D5)")
    approve_all("SB (e2e) re-sign", note="re-read against the revised PDF")
    run_nb("06_review_decisions.py")
    run_nb("07_build_kb.py")
    rules = T("policy_kb.policy_rules")
    check((rules["origin"] == "extracted").any(), "after re-sign: extracted rules compile again")
    run_nb("08_run_detectors.py")

    if DEMOS:
        import random
        import quality

        def table_counts():
            out = {}
            for db in ("sedo", "policy_kb", "prod_input"):
                for t in spark.catalog.listTables(db):
                    out[f"{db}.{t.name}"] = spark.table(f"spark_catalog.{db}.{t.name}").count()
            return out

        def try_nb(rel, subs=None, label=None):
            try:
                g = run_nb(rel, subs)
                check(True, f"{label or rel} ran")
                return g
            except Exception as e:
                traceback.print_exc()
                check(False, f"{label or rel}: {type(e).__name__}: {e}")
                return None

        before = table_counts()
        G = {}
        for sub in ("demos", "validation"):
            d = os.path.join(PKG, "notebooks", sub)
            for nb in sorted(os.listdir(d)) if os.path.isdir(d) else []:
                if nb.endswith(".py"):
                    G[nb] = try_nb(f"{sub}/{nb}", E2E_DEMO_SUBS.get(nb)) or {}
        after = table_counts()
        changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
        check(not changed, f"demos + validation exports wrote no table rows (changed: {changed})")
        check(bool(G.get("d05_ambiguity_register.py")) and os.path.isdir(os.path.join(config.WORKSPACE_DATA_DIR, "demos"))
              and any(f.endswith(".xlsx") for f in os.listdir(os.path.join(config.WORKSPACE_DATA_DIR, "demos"))),
              "d05 exported the ambiguity register workbook under data/demos/")
        go0 = G.get("v03_pipeline_health.py", {}).get("go_table")
        quality_rows = go0[go0["measurement bar item"].str.contains("precision|recall|fidelity", case=False)] if go0 is not None else None
        check(quality_rows is not None and len(quality_rows) == 4 and (quality_rows["status"] == "NOT YET").all(),
              "v03 before any scoring: every quality row is NOT YET (no GO without a metric)")

        # d01 on a code the KB has never seen must say so explicitly
        g = try_nb("demos/d01_code_lookup.py", {'CODE     = "98960"': 'CODE     = "ZZZZ9"'}, "d01 on an unknown code")
        check(g is not None and g.get("found_anything") is False, "d01 reports 'No governing authority found' for an unknown code")

        # the package finder must work two levels down without PKB_PACKAGE_DIR
        saved = os.environ.pop("PKB_PACKAGE_DIR")
        try:
            try_nb("demos/d04_coverage_gap.py", None, "d04 without PKB_PACKAGE_DIR (grandparent finder)")
        finally:
            os.environ["PKB_PACKAGE_DIR"] = saved

        # ---- validation INGEST paths: score the exported workbooks (random but deterministic) and ingest them
        rng = random.Random(20260929)
        v01 = G.get("v01_extraction_scoring.py", {}).get("EXPORT_PATH")
        v02 = G.get("v02_detector_precision.py", {}).get("EXPORT_PATH")
        check(bool(v01) and os.path.exists(v01), f"v01 exported a workbook ({v01})")
        check(bool(v02) and os.path.exists(v02), f"v02 exported a workbook ({v02})")
        ingest = {"EXPORT          = True": "EXPORT          = False"}
        if v01 and os.path.exists(v01):
            book = quality.xlsx_read_sheets(v01)
            r = book["RULES"]
            r["is_real_rule"] = [rng.choice("YYYYN") for _ in range(len(r))]
            r["faithful_to_source"] = [rng.choice("YYYYYYN") if x == "Y" else None for x in r["is_real_rule"]]
            r["scorer"] = "e2e"
            sc = book["RECALL"]
            sc["missed_rules"] = [rng.choice([0, 0, 1]) for _ in range(len(sc))]
            sc["scorer"] = "e2e"
            scored = os.path.join(os.path.dirname(v01), "scored_v01.xlsx")
            quality.xlsx_write_sheets(book, scored)
            try_nb("validation/v01_extraction_scoring.py", {**ingest, "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"},
                   "v01 INGEST")
            qm = T("policy_kb.policy_quality_metrics")
            check(set(qm["metric"]) >= {"extraction_precision", "extraction_fidelity", "extraction_recall"},
                  f"v01 ingest: extraction metrics in policy_quality_metrics ({sorted(set(qm['metric']))})")
            check(len(T("policy_kb.policy_extraction_scores")) == len(r) + len(sc), "v01 ingest: raw scores appended")
            try:
                run_nb("validation/v01_extraction_scoring.py", {**ingest, "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"})
                check(False, "v01 refuses to ingest the same sample twice")
            except AssertionError:
                check(True, "v01 refuses to ingest the same sample twice")
        if v02 and os.path.exists(v02):
            book = quality.xlsx_read_sheets(v02)
            fs = book["FINDINGS"]
            fs["disposition"] = [rng.choice(["true_violation", "true_violation", "false_positive", "cannot_tell"]) for _ in range(len(fs))]
            fs["reviewer"] = "e2e"
            scored = os.path.join(os.path.dirname(v02), "scored_v02.xlsx")
            quality.xlsx_write_sheets(book, scored)
            try_nb("validation/v02_detector_precision.py", {**ingest, "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"},
                   "v02 INGEST")
            qm = T("policy_kb.policy_quality_metrics")
            check("detector_precision" in set(qm["metric"]) and len(qm) > 0, f"v02 ingest: detector metrics ({len(qm)} metric rows)")
            check(len(T("policy_kb.policy_finding_reviews")) == len(fs), "v02 ingest: raw reviews appended")
        g = try_nb("validation/v03_pipeline_health.py", None, "v03 after ingest")
        go = g.get("go_table") if g else None
        if go is not None:
            fid = go[go["measurement bar item"].str.startswith("Extraction fidelity")].iloc[0]
            m = T("policy_kb.policy_quality_metrics")
            m = m[(m["metric"] == "extraction_fidelity") & (m["scope"] == "all")].iloc[-1]
            check((fid["status"] == "GO") == bool(m["ci_low"] >= 0.95),
                  f"v03 fidelity row agrees with the metric (lower bound {m['ci_low']:.3f} -> {fid['status']})")

    print("\n" + ("ALL CHECKS PASSED" if not FAIL else f"{len(FAIL)} CHECK(S) FAILED:\n  - " + "\n  - ".join(FAIL)))
    return 0 if not FAIL else 1


# per-notebook parameter substitutions for demos that need an input (e.g. a code to look up)
E2E_DEMO_SUBS: dict = {
    "d01_code_lookup.py": {'CODE     = "98960"': 'CODE     = "98960"'},          # the planted CHW code (Ch10 + NCCI)
    "d03_provider_review.py": {"MIN_PEERS = 5 ": "MIN_PEERS = 1 "},              # every synthetic code has one provider
    "d09_policy_text_search.py": {'QUERY         = "prior authorization"': 'QUERY         = "same day"'},
    "v04_chapter_profile.py": {"DOWNLOAD  = True": "DOWNLOAD  = False",
                               'CHAPTERS  = list(config.CHAPTERS)': 'CHAPTERS  = ["10"]'},
}

if __name__ == "__main__":
    try:
        sys.exit(main())
    finally:
        spark.stop()
