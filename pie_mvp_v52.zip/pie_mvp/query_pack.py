"""
query_pack.py  -  the QUERY VALIDATION PACK: every compiled query, what it means in plain English,
and proof that the stored SQL text behaves that way on known claims.

For each query (one per compiled state rule; the two NCCI batch statements and - v5.2, 2026-10-04 - the three AHCCCS
rule-table batch statements, each tested on a sample of its edit rows) the pack carries:
  * the rule as signed: statement, verbatim quote, source + page, reviewer, conditions (age / exception /
    "may"), pair scope, claim form, effective window;
  * `what_it_does`: a plain-English reading of the SQL, generated from the predicate (not from the SQL);
  * the SQL text exactly as stored, and its sha256 (the same hash 07 wrote and 08 checks before running);
  * SCENARIOS: small synthetic claim sets built from the predicate - cases that MUST be flagged and cases
    that must NOT be (one unit under the limit, next day, other provider, $0 line, a bypass modifier, the
    day before the window, a member one year too young...) - and the result of running the stored SQL
    (unchanged text, only the table names swapped for scratch tables) against them: PASS / FAIL.
A reviewer then reads the SQL next to the policy words and the scenario results and signs each query.

Isolation: scenarios run against SCRATCH tables (<KB>.qv_*), never the production snapshot or edit
tables. Every scenario has its own member ids, so all scenarios of all queries share one synthetic
claims table and each query runs ONCE; its findings are attributed back to scenarios by member id.
"""
from __future__ import annotations

import json
from datetime import date, timedelta

import pandas as pd

import config
import detector_gen as dg
import ncci_routing
import schema

C = config.CLAIM_COLS
BASE_DOS = date(2026, 1, 15)
ADULT_DOB = date(1980, 1, 1)
# scratch tables live in this schema (default: the KB schema). Tests point it elsewhere.
SCRATCH_SCHEMA = dg.KB
QV_BUILD = "QV_BUILD"
# 2026-10-04 (v5.2): the AHCCCS table batches' scratch edit tables, written only when a table sample is tested
_TABLE_SCRATCH = {dg.BATCH_AHCCCS_PAIR: "ahcccs_pair_edits", dg.BATCH_AHCCCS_DAILY: "ahcccs_daily_limits",
                  dg.BATCH_AHCCCS_PTYPE: "ahcccs_provider_types"}
# every scratch table build_pack may create (<SCRATCH_SCHEMA>.qv_<name>) - v06 drops them all after the pack
SCRATCH_TABLES = ("claims_raw", "claims_snapshot", "ptp_edits", "mue_limits") + tuple(_TABLE_SCRATCH.values())


def _qv(name: str) -> str:
    return f"{SCRATCH_SCHEMA}.qv_{name}"


# ------------------------------------------------------------------ plain English
def _codes(p: dict) -> list[str]:
    return [dg._q(c) for c in (p.get("code_set") or ([p["code"]] if p.get("code") else []))]


def _window_text(rule: dict) -> str:
    eff, end = rule.get("effective_date"), rule.get("end_date")
    if eff and end:
        return f"Only dates of service {str(eff)[:10]} through {str(end)[:10]} (both included)."
    if eff:
        return f"Only dates of service on or after {str(eff)[:10]}."
    if end:
        return f"Only dates of service up to {str(end)[:10]} (included)."
    return "No date limit."


def _qual_text(rule: dict) -> str:
    p = rule.get("predicate") or {}
    bits = []
    if p.get("age"):
        bits.append(f"Only members {schema.age_label(p['age'])} on the date of service (from date of birth; a line "
                    f"with no usable date of birth is never flagged).")
    if rule.get("origin") != "ncci":
        if str(p.get("exception") or "").strip():
            bits.append(f"The policy states an exception ('{str(p['exception']).strip()}'), so every finding is labelled "
                        f"verify_exception - check the record before treating it as a violation.")
        elif p.get("discretionary") is True:
            bits.append("The policy says the claim MAY be denied, so findings are labelled discretionary.")
        if dg.COL["pa_no"]:
            bits.append("A line with a prior-authorization number is labelled verify_pa (the PA may cover it).")
    return " ".join(bits)


def what_it_does(rule: dict) -> str:
    """Plain-English reading of the compiled query, generated from the predicate."""
    p = rule.get("predicate") or {}
    t = p.get("type")
    form = (f" on lines that take the {p['ncci_edition']} NCCI edit file (CMS Table 2: provider type and claim form)"
            if rule.get("origin") == "ncci" and p.get("ncci_edition") else "")
    common = ("Reads paid lines from the detection snapshot (codes and modifiers trimmed and upper-cased, exact "
              "duplicate rows removed, $0 / reversal / reversed lines not payable).")
    if t == "code_pair_prohibited":
        a, b = dg._q(p["code_a"]), dg._q(p["code_b"])
        scope = dg.pair_scope(rule)
        who = {"member_provider_day": "the same member and the same servicing provider",
               dg.MSBD: ("the same member, the same servicing provider and the same billing provider (a line missing "
                         "either provider id is never paired)")}.get(scope, "the same member (any provider)")
        mi = schema.normalize_indicator(p.get("modifier_indicator"), rule.get("origin"))
        mod = ("No modifier can bypass it." if mi == "0" else
               "An NCCI-associated modifier on either line bypasses it (59, XE/XP/XS/XU, anatomic modifiers on "
               "different sites, ...; 24/25/57 only on an E&M code), except when both lines carry the same anatomic "
               "modifier and neither has 58/59/78/79/XE/XP/XS/XU.")
        s = (f"Flags a paid {b} line when {who} also has a paid {a} line on the same date of service{form}. {mod} "
             f"One finding per {b} line; the {a} line(s) are listed as evidence; the dollars are what the {b} line "
             f"was paid.")
        if dg._both_ways(rule):          # 2026-10-04 (v2.6): the table disallows the pair in both directions
            s += (f" The table disallows this pair in both directions: the reverse rule flags the {a} line, so both "
                  f"lines are findings, and the finding says AHCCCS would deny one of the two lines (their dollars "
                  f"are not additive).")
    elif t in ("max_units_per_line",):
        s = (f"Flags each paid {_codes(p)[0]} line{form} with more than {int(p['threshold'])} unit(s) ON THAT LINE "
             f"(units on different lines are not added). Dollars at risk = the whole line (Medicaid MUEs deny the "
             f"line).")
        if p.get("later_max_threshold") is not None or p.get("removed_later"):
            s += (" A later CMS quarter raised or removed this limit, so a line within the later value is labelled "
                  "verify_mue_changed_later.")
    elif t in ("max_units_per_day", "max_units_per_dos"):
        cs = _codes(p)
        # 2026-10-04 (v5.2): a daily cap with scope member_provider_day adds per servicing provider, like the per-DOS cap;
        # (v2.6) member_servicing_billing_day per servicing AND billing provider
        msbd = t == "max_units_per_day" and dg.daily_scope(rule) == dg.MSBD
        per_provider = t == "max_units_per_dos" or dg.daily_scope(rule) in dg.PER_PROVIDER_SCOPES
        per = ("member, servicing provider and billing provider" if msbd else
               "member and servicing provider" if per_provider else "member")
        s = (f"Adds the paid units of {' + '.join(cs)} per {per} per date of service and flags the day when the "
             f"total is more than {int(p['threshold'])}. One finding per {per}-day, listing every contributing line; "
             f"reversal rows net out the lines they reverse; a $0 line does not count; at least one line must be "
             f"payable." + (" Lines missing the servicing or the billing provider id are not counted." if msbd else
                            " Lines with no servicing provider are not counted." if per_provider else ""))
        if rule.get("origin") != "ncci":     # 2026-10-04 (QUERY_SEMANTICS v2.6 §3): the daily-cap labels
            s += (f" A day over the limit only because ONE line alone is over it is labelled verify_span (the claims "
                  f"table has no service end date: that line may cover several days); otherwise a day with a line "
                  f"carrying a bilateral / anatomic / repeat / distinct-service modifier "
                  f"({', '.join(str(m) for m in (getattr(config, 'DAILY_CAP_VERIFY_MODIFIERS', ()) or ())) or 'none configured'}; any "
                  f"of the four modifier columns) is labelled verify_modifier.")
    elif t == "max_units_per_period":
        cs = _codes(p)
        per = {"month": "calendar month", "year": "calendar year",
               "benefit_year": "AHCCCS contract/benefit year (October 1 - September 30)"}[p.get("period", "month")]
        s = (f"Adds the paid units of {' + '.join(cs)} per member per {per} and flags the period when the total is "
             f"more than {int(p['threshold'])}. One finding per member-period (period_start / period_end are the "
             f"period's first and last day), listing every contributing line; reversal rows net out the lines they "
             f"reverse; a $0 line does not count. Only lines inside the rule's own date window are added.")
    elif t == "code_not_covered":
        s = (f"Flags every paid line of {' / '.join(_codes(p))} (a code the policy says is not covered). $0 and "
             f"reversed lines are not flagged.")
    elif t == "provider_type_allowed":
        role = str(p.get("provider_role") or "billing").strip().lower()
        who = {"billing": "BILLING provider (the provider that submits the claim)",
               dg.ROLE_BILLING_OR_RENDERING: (
                   f"BILLING provider (the provider that submits the claim) - or, when the line is billed by a group "
                   f"(billing provider type {' / '.join(_groups()) or 'none configured'}), the RENDERING (servicing) "
                   f"provider -")}.get(role, "SERVICING provider")
        s = (f"Flags every paid line of {' / '.join(_codes(p))} whose {who} type is not one of "
             f"{', '.join(dg._allowed_types(p))}. Provider type codes are compared trimmed and upper-cased ('2' = "
             f"'02'); a line with no provider type (blank, or the text NONE / NAN / NULL) is never flagged. Dollars at "
             f"risk = the whole line.")
        if role == dg.ROLE_BILLING_OR_RENDERING:
            s += " The finding says which type was judged (billed by ... / rendered by ... for a group)."
    else:
        s = f"(predicate type {t} does not compile)"
    return " ".join(x for x in (s, _qual_text(rule), _window_text(rule), common) if x)


def signal_text(rule: dict) -> str:
    """Plain English for the rolling-window utilization signal of a period limit."""
    p = rule.get("predicate") or {}
    period = p.get("period", "month")
    days = int(getattr(config, "ROLLING_WINDOW_DAYS", {}).get(period) or dg.ROLLING_DAYS[period])
    s = (f"For each member: the most paid units of {' + '.join(_codes(p))} in any {days}-day window (rolling - any "
         f"start day, not the policy's fixed {period}); one row per member whose units exceed {int(p['threshold'])} "
         f"in some window, with that window's dates. A SIGNAL for the anomaly work, NOT a violation: the policy limit "
         f"itself is judged on its own {period} by this rule's finding query. Reversal rows net out the lines they "
         f"reverse; a $0 line does not count.")
    bits = []
    if p.get("age"):
        bits.append(f"Only members {schema.age_label(p['age'])} on the date of service.")
    return " ".join([s] + bits + [_window_text(rule)])


# ------------------------------------------------------------------ scenarios
def _dos(rule: dict) -> date:
    """A date of service inside the rule's window, preferring BASE_DOS."""
    eff = rule.get("effective_date")
    end = rule.get("end_date")
    d = BASE_DOS
    if eff and d < date.fromisoformat(str(eff)[:10]):
        d = date.fromisoformat(str(eff)[:10])
    if end and d > date.fromisoformat(str(end)[:10]):
        d = date.fromisoformat(str(end)[:10])
    return d


def _dob(p: dict, dos: date, ok: bool = True) -> date:
    """A date of birth that satisfies (ok=True) or fails (ok=False) the rule's age condition on `dos`."""
    a = p.get("age") or {}
    lo, hi = a.get("min"), a.get("below")
    if ok:
        if lo is not None:
            return date(dos.year - int(lo) - 1, 1, 1) if hi is None or int(lo) + 1 < int(hi) else date(dos.year - int(lo), 1, 1)
        if hi is not None:
            return date(dos.year - max(int(hi) - 5, 0), 1, 1)
        return ADULT_DOB
    if lo is not None:
        return date(dos.year - int(lo) + 1, 6, 1)        # a year too young
    return date(dos.year - int(hi) - 5, 1, 1)             # too old


# a (claim form, servicing provider type) that takes each NCCI edit file (billed by the same type) - and routes that
# take ANOTHER file: (form, servicing type, billing type); billing None = the same as the servicing type
EDITION_LINES = {"practitioner": ("A", "08"), "outpatient": ("O", "02"), "dme": ("A", "30")}
OTHER_ROUTES = {"practitioner": (("A", "30", None), ("O", "08", None)), "outpatient": (("O", "43", None), ("A", "08", None)),
                "dme": (("A", "08", None), ("O", "02", None))}
# 2026-10-03: the BILLING provider decides (CMS: "claims from" a type of provider) - an MD's service billed by an
# FQHC (CMS-optional row, off by default) or by a hospital on a CMS-1500 (OPH), an FQHC's own line
COMMON_ROUTES = (("A", "C2", None), ("A", "08", "C2"), ("A", "08", "02"))
_SAME = object()


def _line(member, cid, ln, prov, dos, code, units=1, paid=10.0, m1=None, pa=None, form="A", dob=ADULT_DOB, ptype="08",
          btype=_SAME, bprov=_SAME, m2=None, m3=None, m4=None):
    """One synthetic claim line. ptype = servicing provider type, btype = billing provider type (default: the same);
    bprov = the billing provider ID (default: the servicing provider's id); m1..m4 = the four modifier columns."""
    out = {C["claim_id"]: cid, C["line_no"]: ln, C["member"]: member, C["servicing_provider"]: prov,
           C.get("billing_provider", "BProv_ID"): prov if bprov is _SAME else bprov, C["dos"]: dos, C["code"]: code,
           C["units"]: float(units), C["paid_amt"]: float(paid), C["pos"]: "11", C["form"]: form, C["mods"][0]: m1,
           C["mods"][1]: m2, C["mods"][2]: m3, C["mods"][3]: m4, C["pa_no"]: pa, C["dob"]: dob}
    if C.get("prov_type"):
        out[C["prov_type"]] = ptype
    if C.get("billing_type"):
        out[C["billing_type"]] = ptype if btype is _SAME else btype
    return out


def _period_bounds(period: str, d: date) -> tuple[date, date]:
    if period == "month":
        start = d.replace(day=1)
        nxt = (start + timedelta(days=32)).replace(day=1)
    elif period == "year":
        start, nxt = date(d.year, 1, 1), date(d.year + 1, 1, 1)
    else:
        y = d.year if d.month >= 10 else d.year - 1
        start, nxt = date(y, 10, 1), date(y + 1, 10, 1)
    return start, nxt - timedelta(days=1)


def scenarios(rule: dict, tag: str) -> list[dict]:
    """[{sid, description, lines, expect, severity}] for one rule. `tag` makes member ids unique."""
    p = rule.get("predicate") or {}
    t = p.get("type")
    edition = str(p.get("ncci_edition") or "") if rule.get("origin") == "ncci" else ""
    form, ptype = EDITION_LINES.get(edition, ("A", "08"))
    d = _dos(rule)
    dob = _dob(p, d)
    base_sev = dg._qualified(rule, {"code_pair_prohibited": "hard_denial" if schema.normalize_indicator(
        p.get("modifier_indicator"), rule.get("origin")) == "0" else "unbypassed_pair",
        "code_not_covered": "not_covered_paid",
        "provider_type_allowed": "provider_type_not_allowed"}.get(t, "units_over_limit"))
    out = []

    def add(sid, desc, lines, expect, sev=None, findings=None):
        out.append({"sid": sid, "member": f"{tag}_{sid}", "description": desc, "lines": lines, "expect": expect,
                    "severity": sev if expect else None, **({"findings": findings} if findings else {})})

    def L(sid, cid, ln, code, **kw):
        kw.setdefault("form", form)
        kw.setdefault("ptype", ptype)
        kw.setdefault("dob", dob)
        kw.setdefault("prov", "P1")
        kw.setdefault("dos", d)
        prov, dos_ = kw.pop("prov"), kw.pop("dos")
        return _line(f"{tag}_{sid}", f"{tag}{sid}{cid}", ln, prov, dos_, code, **kw)

    if t == "code_pair_prohibited":
        a, b = dg._q(p["code_a"]), dg._q(p["code_b"])
        mi = schema.normalize_indicator(p.get("modifier_indicator"), rule.get("origin"))
        # 2026-10-04 (v2.6): a pair disallowed both ways says so in its finding - the scenario checks the text
        add("F1", f"{a} and {b} paid, same member, provider and day" + (
            " (the pair is disallowed both ways: the finding says so)" if dg._both_ways(rule) else ""),
            [L("F1", "x", 1, a), L("F1", "x", 2, b)], 1, base_sev,
            findings=[dg._pair_finding(rule, a, b)] if dg._both_ways(rule) else None)
        add("N1", f"{b} alone", [L("N1", "x", 1, b)], 0)
        add("N2", f"{a} and {b} on consecutive days", [L("N2", "x", 1, a), L("N2", "y", 1, b, dos=d + timedelta(days=1))], 0)
        add("N3", f"{b} line paid $0", [L("N3", "x", 1, a), L("N3", "x", 2, b, paid=0)], 0)
        add("N7", f"the {a} line paid $0 ({a} not payable, so nothing to deny {b} against)",
            [L("N7", "x", 1, a, paid=0), L("N7", "x", 2, b)], 0)
        if dg.pair_scope(rule) in dg.PER_PROVIDER_SCOPES:
            add("N4", f"{a} and {b} by DIFFERENT providers", [L("N4", "x", 1, a, prov="P1"), L("N4", "y", 1, b, prov="P2")], 0)
        else:
            add("F2", f"{a} and {b} by different providers (member-wide rule)",
                [L("F2", "x", 1, a, prov="P1"), L("F2", "y", 1, b, prov="P2")], 1, base_sev)
        if dg.pair_scope(rule) == dg.MSBD:      # 2026-10-04 (v2.6): the same servicing AND billing provider id
            add("N9", f"{a} and {b} by the same servicing provider P1, billed under DIFFERENT billing provider ids "
                f"(B1 / B2)", [L("N9", "x", 1, a, bprov="B1"), L("N9", "y", 1, b, bprov="B2")], 0)
            add("N10", f"{a} and {b} by the same servicing provider with NO billing provider id (a missing id never "
                f"matches)", [L("N10", "x", 1, a, bprov=None), L("N10", "x", 2, b, bprov=None)], 0)
        if mi == "1":
            add("N5", f"modifier 59 on the {b} line (bypass)", [L("N5", "x", 1, a), L("N5", "x", 2, b, m1="59")], 0)
            add("N8", f"modifier 59 on the {a} line (a modifier on either line bypasses)",
                [L("N8", "x", 1, a, m1="59"), L("N8", "x", 2, b)], 0)
            add("F5", "LT on both lines (the same anatomic modifier and no 59/X{EPSU}: NOT bypassed)",
                [L("F5", "x", 1, a, m1="LT"), L("F5", "x", 2, b, m1="LT")], 1, base_sev)
            if not _is_em_code(b):
                add("F6", f"modifier 25 on the {b} line ({b} is not an E&M code, so 25 does not bypass)",
                    [L("F6", "x", 1, a), L("F6", "x", 2, b, m1="25")], 1, base_sev)
        else:
            add("F3", f"modifier 59 on the {b} line (no bypass for indicator 0)",
                [L("F3", "x", 1, a), L("F3", "x", 2, b, m1="59")], 1, base_sev)
        if rule.get("origin") == "ncci":
            add("N6", "both lines on dental form D", [L("N6", "x", 1, a, form="D"), L("N6", "x", 2, b, form="D")], 0)
            for k, (f2, t2, b2) in enumerate(OTHER_ROUTES.get(edition, ()) + COMMON_ROUTES, 1):
                bt = t2 if b2 is None else b2
                e2 = ncci_routing.edition(f2, t2, billing_type=bt)
                add(f"R{k}", f"the F1 lines on form {f2}, servicing provider type {t2}, billed by type {bt} (they take "
                    f"the {e2 or 'no'} NCCI edit file)",
                    [L(f"R{k}", "x", 1, a, form=f2, ptype=t2, btype=bt), L(f"R{k}", "x", 2, b, form=f2, ptype=t2, btype=bt)],
                    1 if e2 == edition else 0, base_sev)
        elif dg.COL["pa_no"]:
            add("F4", f"PA number on the {b} line", [L("F4", "x", 1, a), L("F4", "x", 2, b, pa="PA1")], 1, dg.VERIFY_PA)
            # 2026-10-04 (v5.2): a PA on EITHER line of the pair labels the finding (spec §3: "on any line of the finding")
            add("F7", f"PA number on the {a} line (a PA on either line counts)",
                [L("F7", "x", 1, a, pa="PA1"), L("F7", "x", 2, b)], 1, dg.VERIFY_PA)
    elif t in ("max_units_per_line",):
        c, n = _codes(p)[0], int(p["threshold"])
        sev = base_sev
        if rule.get("origin") == "ncci" and (p.get("removed_later") or
                                             (p.get("later_max_threshold") is not None and n + 1 <= int(p["later_max_threshold"]))):
            sev = dg.VERIFY_MUE_CHANGED
        add("F1", f"one line of {c} with {n + 1} units", [L("F1", "x", 1, c, units=n + 1)], 1, sev)
        add("N1", f"one line of {c} with {n} units", [L("N1", "x", 1, c, units=n)], 0)
        add("N2", f"two lines of {c} with {n} units each (per line, not summed)",
            [L("N2", "x", 1, c, units=n), L("N2", "x", 2, c, units=n)], 0)
        add("N3", f"{n + 1} units but the line paid $0", [L("N3", "x", 1, c, units=n + 1, paid=0)], 0)
        add("N5", f"{n + 1} units on a line that was then reversed",
            [L("N5", "x", 1, c, units=n + 1, paid=40), L("N5", "r", 1, c, units=-(n + 1), paid=-40)], 0)
        if rule.get("origin") == "ncci":
            add("N4", "dental form D line over the limit", [L("N4", "x", 1, c, units=n + 1, form="D")], 0)
            for k, (f2, t2, b2) in enumerate(OTHER_ROUTES.get(edition, ()) + COMMON_ROUTES, 1):
                bt = t2 if b2 is None else b2
                e2 = ncci_routing.edition(f2, t2, billing_type=bt)
                add(f"R{k}", f"{n + 1} units on form {f2}, servicing provider type {t2}, billed by type {bt} (the "
                    f"{e2 or 'no'} NCCI edit file)", [L(f"R{k}", "x", 1, c, units=n + 1, form=f2, ptype=t2, btype=bt)],
                    1 if e2 == edition else 0, sev)
    elif t in ("max_units_per_day", "max_units_per_dos"):
        cs, n = _codes(p), int(p["threshold"])
        if len(cs) > 1:
            add("F1", f"{cs[0]} and {cs[1]} same day, {n + 1} units together",
                [L("F1", "x", 1, cs[0], units=n), L("F1", "x", 2, cs[1], units=1)], 1, base_sev)
        else:
            add("F1", f"{cs[0]} {n + 1} units on one day (two lines)",
                [L("F1", "x", 1, cs[0], units=n), L("F1", "y", 1, cs[0], units=1)], 1, base_sev)
        add("N1", f"exactly {n} units on one day", [L("N1", "x", 1, cs[0], units=n)], 0)
        add("N2", f"{n} units on two consecutive days",
            [L("N2", "x", 1, cs[0], units=n), L("N2", "y", 1, cs[0], units=n, dos=d + timedelta(days=1))], 0)
        add("N3", f"{n + 1} units where the same line appears twice (duplicate row)",
            [L("N3", "x", 1, cs[0], units=n), L("N3", "x", 1, cs[0], units=n)], 0)
        add("N4", f"{n} units plus a {n + 1}-unit line that was reversed (the reversal nets it out)",
            [L("N4", "x", 1, cs[0], units=n), L("N4", "y", 1, cs[-1], units=n + 1, paid=40),
             L("N4", "r", 1, cs[-1], units=-(n + 1), paid=-40)], 0)
        add("N5", f"{n} paid units plus 1 unit on a line paid $0 (a $0 line does not count)",
            [L("N5", "x", 1, cs[0], units=n), L("N5", "y", 1, cs[-1], units=1, paid=0)], 0)
        # 2026-10-04 (v5.2): whose units are added - per provider (per-DOS caps, daily caps with scope
        # member_provider_day: the AHCCCS daily limits) or the member's units from any provider (daily caps by default)
        if t == "max_units_per_dos" or dg.daily_scope(rule) in dg.PER_PROVIDER_SCOPES:
            add("N6", f"{n} units from provider P1 and 1 unit from provider P2 on one day (counted per provider)",
                [L("N6", "x", 1, cs[0], units=n, prov="P1"), L("N6", "y", 1, cs[-1], units=1, prov="P2")], 0)
            add("N7", f"{n + 1} units on lines with no servicing provider (not counted per provider)",
                [L("N7", "x", 1, cs[0], units=n, prov=None), L("N7", "y", 1, cs[-1], units=1, prov=None)], 0)
            if t == "max_units_per_day" and dg.daily_scope(rule) == dg.MSBD:    # v2.6: per billing provider id too
                add("N8", f"{n} units and 1 unit from servicing provider P1, billed under two billing provider ids "
                    f"(B1 / B2) (counted per servicing AND billing provider)",
                    [L("N8", "x", 1, cs[0], units=n, bprov="B1"), L("N8", "y", 1, cs[-1], units=1, bprov="B2")], 0)
                add("N9", f"{n + 1} units on lines with no billing provider id (not counted)",
                    [L("N9", "x", 1, cs[0], units=n, bprov=None), L("N9", "y", 1, cs[-1], units=1, bprov=None)], 0)
        else:
            add("F2", f"{n} units from provider P1 and 1 unit from provider P2 on one day (added across providers)",
                [L("F2", "x", 1, cs[0], units=n, prov="P1"), L("F2", "y", 1, cs[-1], units=1, prov="P2")], 1,
                base_sev)
        if rule.get("origin") != "ncci":        # 2026-10-04 (QUERY_SEMANTICS v2.6 §3): the daily-cap labels
            add("S1", f"ONE line of {cs[0]} with {n + 1} units (over the limit on its own - it may cover several days: "
                f"labelled verify_span)", [L("S1", "x", 1, cs[0], units=n + 1)], 1, dg.VERIFY_SPAN)
            m_a, m_b = _two_mods()
            if m_a:
                add("S2", f"{n} units with modifier {m_a} and 1 unit with modifier {m_b} (4th modifier column) on one "
                    f"day (labelled verify_modifier)",
                    [L("S2", "x", 1, cs[0], units=n, m1=m_a), L("S2", "y", 1, cs[-1], units=1, m4=m_b)], 1,
                    dg.VERIFY_MODIFIER)
        if rule.get("origin") != "ncci" and dg.COL["pa_no"]:
            add("F4", f"{n + 1} units on one day, a PA number on one of the lines",
                [L("F4", "x", 1, cs[0], units=n), L("F4", "y", 1, cs[-1], units=1, pa="PA1")], 1, dg.VERIFY_PA)
    elif t == "max_units_per_period":
        cs, n = _codes(p), int(p["threshold"])
        start, end = _period_bounds(p.get("period", "month"), d)
        if rule.get("effective_date"):                      # keep the flagged case inside the rule's window
            start = max(start, date.fromisoformat(str(rule["effective_date"])[:10]))
        d2 = min(end, start + timedelta(days=1)) if end > start else start
        add("F1", f"{n + 1} units inside one {p.get('period')}",
            [L("F1", "x", 1, cs[0], units=n, dos=start), L("F1", "y", 1, cs[-1], units=1, dos=d2)], 1, base_sev)
        add("N1", f"exactly {n} units inside one {p.get('period')}", [L("N1", "x", 1, cs[0], units=n, dos=start)], 0)
        add("N2", f"{n} units on the last day of one {p.get('period')} and {n} on the first day of the next",
            [L("N2", "x", 1, cs[0], units=n, dos=start - timedelta(days=1)), L("N2", "y", 1, cs[0], units=n, dos=start)], 0)
        add("N3", f"{n} units plus a 1-unit line in the same {p.get('period')} that was reversed",
            [L("N3", "x", 1, cs[0], units=n, dos=start), L("N3", "y", 1, cs[-1], units=1, paid=10, dos=d2),
             L("N3", "r", 1, cs[-1], units=-1, paid=-10, dos=d2)], 0)
        add("N4", f"{n} paid units plus 1 unit on a line paid $0 in the same {p.get('period')}",
            [L("N4", "x", 1, cs[0], units=n, dos=start), L("N4", "y", 1, cs[-1], units=1, paid=0, dos=d2)], 0)
    elif t == "code_not_covered":
        c = _codes(p)[0]
        add("F1", f"a paid {c} line", [L("F1", "x", 1, c)], 1, base_sev)
        add("N1", f"a {c} line paid $0", [L("N1", "x", 1, c, paid=0)], 0)
        add("N2", f"a {c} line paid then reversed",
            [L("N2", "x", 1, c, paid=30), L("N2", "r", 1, c, units=-1, paid=-30)], 0)
    elif t == "provider_type_allowed":
        c, ok = _codes(p)[0], dg._allowed_types(p)
        role = str(p.get("provider_role") or "billing").strip().lower()
        # 2026-10-04 (v2.6): billing_or_rendering - a non-group biller is judged on its own (billing) type, a group's
        # line (billing type in config.GROUP_BILLING_PROVIDER_TYPES) on its rendering provider's type
        groups = _groups() if role == dg.ROLE_BILLING_OR_RENDERING else []
        bad = next(x for x in ("77", "05", "08", "ZZ") if x not in ok and x not in groups)
        okk = next((x for x in ok if x not in groups), ok[0])        # an allowed type that is not a group type
        who = "billed by" if role in ("billing", dg.ROLE_BILLING_OR_RENDERING) else "with servicing provider"
        k = "btype" if who == "billed by" else "ptype"
        other = "ptype" if k == "btype" else "btype"
        add("F1", f"a paid {c} line {who} provider type {bad} (not in the list)", [L("F1", "x", 1, c, **{k: bad})], 1,
            base_sev)
        add("N1", f"a paid {c} line {who} provider type {okk} (in the list)", [L("N1", "x", 1, c, **{k: okk})], 0)
        add("N2", f"a paid {c} line {who} ' {okk.lower()} ' (the same code, padded / lower case)",
            [L("N2", "x", 1, c, **{k: f" {okk.lower()} "})], 0)
        add("N3", f"a paid {c} line with NO provider type (unknown is not a violation)", [L("N3", "x", 1, c, **{k: None})], 0)
        add("N4", f"a {c} line {who} {bad} but paid $0", [L("N4", "x", 1, c, paid=0, **{k: bad})], 0)
        role_word = "billing" if k == "btype" else "servicing"
        add("N5", f"a paid {c} line {who} {okk} while the other provider on the line is type {bad} (only the "
            f"{role_word} provider counts)", [L("N5", "x", 1, c, **{k: okk, other: bad})], 0)
        if groups:
            g, codes_ = groups[0], "/".join(_codes(p))
            spelled = f" {g.lstrip('0') or g} "
            add("G1", f"a paid {c} line billed by a group (type {g}) whose RENDERING provider type {okk} is in the list",
                [L("G1", "x", 1, c, btype=g, ptype=okk)], 0)
            add("G2", f"a paid {c} line billed by a group (type written '{spelled}') whose RENDERING provider type {bad} "
                f"is not in the list", [L("G2", "x", 1, c, btype=spelled, ptype=bad)], 1, base_sev,
                findings=[f"{codes_} rendered by provider type {bad} for a group ({g}) (allowed: {'/'.join(ok)})"])
            add("G3", f"a paid {c} line billed by a group (type {g}) with NO rendering provider type (unknown is not a "
                f"violation)", [L("G3", "x", 1, c, btype=g, ptype=None)], 0)
        if dg.COL["pa_no"]:
            add("F4", f"PA number on a {c} line {who} {bad}", [L("F4", "x", 1, c, pa="PA1", **{k: bad})], 1, dg.VERIFY_PA)
    else:
        return []
    # window and age, common to every type
    eff = rule.get("effective_date")
    if eff and out:
        before = date.fromisoformat(str(eff)[:10]) - timedelta(days=1)
        f1 = out[0]
        add("W1", f"the flagged case on {before} (the day before the rule starts)",
            [dict(x, **{C["dos"]: before, C["member"]: f"{tag}_W1", C["claim_id"]: str(x[C["claim_id"]]) + "w"})
             for x in f1["lines"]], 0)
    # 2026-10-04 (v5.2): the other end of the window - an AHCCCS table version judges claims only up to the day before
    # the next version's date, an NCCI edit up to its deletion date (both ends included)
    end_ = rule.get("end_date")
    if end_ and out:
        after = date.fromisoformat(str(end_)[:10]) + timedelta(days=1)
        f1 = out[0]
        add("W2", f"the flagged case on {after} (the day after the rule ends)",
            [dict(x, **{C["dos"]: after, C["member"]: f"{tag}_W2", C["claim_id"]: str(x[C["claim_id"]]) + "e"})
             for x in f1["lines"]], 0)
    if p.get("age") and out:
        f1 = out[0]
        bad = _dob(p, d, ok=False)
        add("A1", f"the flagged case for a member outside the age condition ({schema.age_label(p['age'])})",
            [dict(x, **{C["dob"]: bad, C["member"]: f"{tag}_A1", C["claim_id"]: str(x[C["claim_id"]]) + "a"})
             for x in f1["lines"]], 0)
        add("A2", "the flagged case for a member with no date of birth",
            [dict(x, **{C["dob"]: None, C["member"]: f"{tag}_A2", C["claim_id"]: str(x[C["claim_id"]]) + "n"})
             for x in f1["lines"]], 0)
    return out


def _groups() -> list[str]:
    """config.GROUP_BILLING_PROVIDER_TYPES as the queries compare them ([] when none, or when the value is refused)."""
    try:
        return dg._group_billing_types()
    except ValueError:
        return []


def _two_mods() -> tuple:
    """Two modifiers of config.DAILY_CAP_VERIFY_MODIFIERS for the verify_modifier scenario: RT and LT (a bilateral pair
    of lines) when configured, else the first two; (None, None) when none is configured (no such label then)."""
    try:
        mods = dg._daily_cap_mods()
    except ValueError:
        return None, None
    if "RT" in mods and "LT" in mods:
        return "RT", "LT"
    return (mods[0], mods[1 if len(mods) > 1 else 0]) if mods else (None, None)


def _is_em_code(code: str) -> bool:
    c = str(code)
    return len(c) == 5 and c.isdigit() and any(lo <= c <= hi for lo, hi in dg.EM_RANGES)


def signal_scenarios(rule: dict, tag: str) -> list[dict]:
    """Scenarios for the rolling-window utilization SIGNAL of a period limit (one row per member whose units
    in some window of `rolling_days` days exceed the limit). Not findings: no severity."""
    p = rule.get("predicate") or {}
    if p.get("type") != "max_units_per_period":
        return []
    cs, n = _codes(p), int(p["threshold"])
    period = p.get("period", "month")
    days = int(getattr(config, "ROLLING_WINDOW_DAYS", {}).get(period) or dg.ROLLING_DAYS[period])
    d = _dos(rule)
    dob = _dob(p, d)
    _, end = _period_bounds(period, d)
    b = end + timedelta(days=1)                       # first day of the next period
    rend = rule.get("end_date")
    across = not (rend and b > date.fromisoformat(str(rend)[:10]))
    d1, d2 = (end, b) if across else (d, d + timedelta(days=1))
    out = []

    def L(sid, cid, code, units, dos, **kw):
        return _line(f"{tag}_{sid}", f"{tag}{sid}{cid}", 1, "P1", dos, code, units=units, dob=kw.pop("dob", dob), **kw)

    def add(sid, desc, lines, expect):
        out.append({"sid": sid, "member": f"{tag}_{sid}", "description": desc, "lines": lines, "expect": expect,
                    "severity": None})
    where = (f"on the last day of one {period} and the first day of the next (the fixed {period} check does NOT fire)"
             if across else "on two consecutive days")
    add("F1", f"{n} + 1 units {where}: inside one {days}-day window",
        [L("F1", "x", cs[0], n, d1), L("F1", "y", cs[-1], 1, d2)], 1)
    add("N1", f"exactly {n} units inside {days} days", [L("N1", "x", cs[0], n, d1)], 0)
    add("N2", f"{n} units, then {n} more exactly {days} days later (no {days}-day window holds both)",
        [L("N2", "x", cs[0], n, d1), L("N2", "y", cs[0], n, d1 + timedelta(days=days))], 0)
    add("N3", f"{n} paid units plus 1 unit on a line paid $0 inside {days} days",
        [L("N3", "x", cs[0], n, d1), L("N3", "y", cs[-1], 1, d2, paid=0)], 0)
    eff = rule.get("effective_date")
    if eff:
        before = date.fromisoformat(str(eff)[:10]) - timedelta(days=1)
        add("W1", f"{n} + 1 units, all before the rule starts ({before})",
            [L("W1", "x", cs[0], n, before - timedelta(days=1)), L("W1", "y", cs[-1], 1, before)], 0)
    if p.get("age"):
        bad = _dob(p, d, ok=False)
        add("A1", f"the F1 case for a member outside the age condition ({schema.age_label(p['age'])})",
            [L("A1", "x", cs[0], n, d1, dob=bad), L("A1", "y", cs[-1], 1, d2, dob=bad)], 0)
    return out


# ------------------------------------------------------------------ running
def _claims_frame(all_lines: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(all_lines)
    for c in (C["dos"], C["dob"]):
        df[c] = pd.to_datetime(df[c]).dt.date.where(df[c].notna(), None)
    return df


def _write_claims(spark, df: pd.DataFrame, fmt: str):
    from pyspark.sql import functions as F
    import kb_io
    sdf = kb_io.to_spark(spark, df.drop(columns=[C["dos"], C["dob"]]).assign(
        **{C["dos"]: df[C["dos"]].astype(str), C["dob"]: df[C["dob"]].map(lambda v: None if v is None else str(v))}))
    sdf = (sdf.withColumn(C["dos"], F.to_date(C["dos"])).withColumn(C["dob"], F.to_date(C["dob"]))
              .withColumn(C["units"], F.col(C["units"]).cast("decimal(15,4)"))
              .withColumn(C["paid_amt"], F.col(C["paid_amt"]).cast("decimal(15,2)")))
    sdf.write.format(fmt).mode("overwrite").option("overwriteSchema", "true").saveAsTable(_qv('claims_raw'))
    dg.create_snapshot(spark, source=_qv('claims_raw'), target=_qv('claims_snapshot'), fmt=fmt)


def scratch_sql(sql: str, build_id: str | None = None) -> str:
    """The stored SQL with ONLY its table names (and build filter) pointed at the scratch tables."""
    s = (sql.replace(dg.DETECT, _qv("claims_snapshot")).replace(dg.PTP_EDITS_TABLE, _qv("ptp_edits"))
            .replace(dg.MUE_LIMITS_TABLE, _qv("mue_limits"))
            # 2026-10-04 (v5.2): the AHCCCS rule-table edit tables
            .replace(dg.AHCCCS_PAIR_EDITS_TABLE, _qv(_TABLE_SCRATCH[dg.BATCH_AHCCCS_PAIR]))
            .replace(dg.AHCCCS_DAILY_LIMITS_TABLE, _qv(_TABLE_SCRATCH[dg.BATCH_AHCCCS_DAILY]))
            .replace(dg.AHCCCS_PTYPE_TABLE, _qv(_TABLE_SCRATCH[dg.BATCH_AHCCCS_PTYPE])))
    if build_id:
        s = s.replace(f"WHERE build_id = '{build_id}'", f"WHERE build_id = '{QV_BUILD}'")
    return s


def _judge(found: list[dict], sc: dict) -> tuple[bool, str]:
    """A scenario's verdict: its member's findings (of its own rule in a batch statement - unless the scenario is judged
    across rules, `any_rule`, v2.6 both-ways pairs) - the count, the severity and (v2.6, when the scenario names them)
    the finding texts."""
    mine = [f for f in found if str(f.get("member_id")) == sc["member"]
            and (sc.get("any_rule") or not sc.get("rule_id") or "rule_id" not in f or f.get("rule_id") == sc["rule_id"])]
    n = len(mine)
    if n != sc["expect"]:
        return False, f"expected {sc['expect']} finding(s), got {n}"
    if sc["expect"] and sc["severity"] and any(f.get("finding_severity") != sc["severity"] for f in mine):
        return False, f"expected severity {sc['severity']}, got {sorted({f.get('finding_severity') for f in mine})}"
    if sc["expect"] and sc.get("findings") is not None:
        got = sorted(str(f.get("finding")) for f in mine)
        if got != sorted(sc["findings"]):
            return False, f"expected finding text {sorted(sc['findings'])}, got {got}"
    return True, f"{n} finding(s)" + (f", {mine[0].get('finding_severity')}" if mine else "")


def _iso(v) -> str | None:
    if v is None:
        return None
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    t = str(v).strip()[:10]
    return t or None


def dates_covered(rule: dict) -> str:
    """The dates of service a state query judges, in words. Most manual rules carry no start date (2026-10-03: 60 of the
    63 compiled state rules); such a rule judges EVERY date of service in the claims, which is only right if the rule
    was already in force on the oldest claim - the validator must see that, not an empty cell."""
    eff, end = _iso(rule.get("effective_date")), _iso(rule.get("end_date"))
    if eff and end:
        return f"{eff} to {end}"
    if eff:
        return f"from {eff}"
    tail = ("the source gives no start date: if this rule is newer than the oldest claims, mark PROBLEM and give the "
            "date (the reviewer sets corrected_effective_date)")
    return f"up to {end}; {tail}" if end else f"every date of service - {tail}"


_TABLE_TAG = {dg.BATCH_AHCCCS_PAIR: "TP", dg.BATCH_AHCCCS_DAILY: "TD", dg.BATCH_AHCCCS_PTYPE: "TT"}
_TABLE_STATEMENT = {
    dg.BATCH_AHCCCS_PAIR: "All AHCCCS Same Day Disallow pairs in policy_ahcccs_pair_edits, in ONE statement",
    dg.BATCH_AHCCCS_DAILY: "All AHCCCS daily limits in policy_ahcccs_daily_limits, in ONE statement",
    dg.BATCH_AHCCCS_PTYPE: "All AHCCCS B2-matrix provider-type rules in policy_ahcccs_provider_types, in ONE statement",
}
_TABLE_WHAT = {
    dg.BATCH_AHCCCS_PAIR: ("Joins every paid line pair of the same member and date of service (and, for an A* row, the "
                           "same servicing provider - v2.6: and the same billing provider id when the row's scope is "
                           "member_servicing_billing_day) to the Same Day Disallow edit table; one statement covers "
                           "every edit row - each sampled row below is tested like a single rule, and a pair the table "
                           "disallows both ways also as the pair of rules (scenario BW: both lines flagged)."),
    dg.BATCH_AHCCCS_DAILY: ("Joins every counted line to the daily-limit table on its code and adds the units per rule, "
                            "member and date (and servicing provider - v2.6: or servicing AND billing provider - where "
                            "the row says so); a day over the limit by ONE line alone is verify_span, one with a "
                            "bilateral / anatomic / repeat / distinct modifier verify_modifier; each sampled row is "
                            "tested like a single rule."),
    dg.BATCH_AHCCCS_PTYPE: ("Joins every paid line to the B2-matrix provider-type table on its code (v2.6: a row with "
                            "role billing_or_rendering judges a group's line - billing provider type 01 - on its "
                            "rendering provider's type); each sampled row is tested like a single rule."),
}


def _same_version(r1: dict, r2: dict) -> bool:
    return (_iso(r1.get("effective_date")), _iso(r1.get("end_date"))) == \
        (_iso(r2.get("effective_date")), _iso(r2.get("end_date")))


def _reverse_of(rule: dict, rules: list[dict]) -> dict | None:
    """The rule of `rules` that disallows the same two codes the other way round in the same version (v2.6: both rules
    carry both_ways), or None."""
    p = rule.get("predicate") or {}
    for r in rules:
        q = r.get("predicate") or {}
        if (r is not rule and r.get("rule_id") != rule.get("rule_id") and dg._both_ways(r)
                and str(q.get("code_a")).strip().upper() == str(p.get("code_b")).strip().upper()
                and str(q.get("code_b")).strip().upper() == str(p.get("code_a")).strip().upper()
                and _same_version(r, rule)):
            return r
    return None


def _both_ways_scenarios(rules: list[dict]) -> list[dict]:
    """2026-10-04 (v2.6, critic F4): for each pair disallowed both ways whose reverse rule is in the same statement, ONE
    scenario judged across the rules (any_rule): the two lines of one member and day - both are flagged, each by its
    own rule, each finding saying AHCCCS would deny one of the two lines."""
    out, done = [], set()
    for j, r in enumerate(rules):
        rv = _reverse_of(r, rules) if dg._both_ways(r) and r["rule_id"] not in done else None
        if rv is None:
            continue
        done |= {r["rule_id"], rv["rule_id"]}
        p = r["predicate"]
        a, b = dg._q(p["code_a"]), dg._q(p["code_b"])
        tag, d = f"TB{j:03d}", _dos(r)
        sev = {dg._qualified(x, "hard_denial" if schema.normalize_indicator(
            (x.get("predicate") or {}).get("modifier_indicator"), x.get("origin")) == "0" else "unbypassed_pair")
            for x in (r, rv)}
        out.append({"sid": "BW", "member": f"{tag}_BW", "rule_id": r["rule_id"], "any_rule": True,
                    "description": (f"{a} and {b} paid, same member, providers and day - the pair is disallowed both "
                                    f"ways: BOTH lines are flagged, the {b} line by this rule and the {a} line by the "
                                    f"reverse rule {rv['rule_id']}, each finding saying AHCCCS would deny one of the "
                                    f"two lines"),
                    "lines": [_line(f"{tag}_BW", f"{tag}BWx", 1, "P1", d, a, dob=_dob(p, d)),
                              _line(f"{tag}_BW", f"{tag}BWx", 2, "P1", d, b, dob=_dob(p, d))],
                    "expect": 2, "severity": sev.pop() if len(sev) == 1 else None,
                    "findings": sorted([dg._pair_finding(r, a, b), dg._pair_finding(rv, b, a)])})
    return out


def table_scenarios(kind: str, rules: list[dict]) -> list[dict]:
    """The scenarios of one AHCCCS table batch statement for its sampled rules: each rule's own (tagged with its rule_id,
    judged on that rule's findings only) and, for the Same Day statement, the both-ways pairs judged across rules."""
    sc = []
    for j, r in enumerate(rules):
        sc += [dict(s, rule_id=r["rule_id"]) for s in scenarios(r, f"{_TABLE_TAG[kind]}{j:03d}")]
    if kind == dg.BATCH_AHCCCS_PAIR:
        sc += _both_ways_scenarios(rules)
    return sc


def _billing_id_text(x: dict) -> str:
    """The billing provider id of a scenario line, when it is not the servicing provider's (v2.6 scenarios)."""
    b = C.get("billing_provider")
    if not b or x.get(b, x.get(C["servicing_provider"])) == x.get(C["servicing_provider"]):
        return ""
    return f" billing id {x.get(b)}"


def build_pack(spark, rules: list[dict], detectors: list[dict], batch_rows: list[dict] | None = None,
               ptp_sample: list[dict] | None = None, mue_sample: list[dict] | None = None,
               fmt: str | None = None, build_id: str | None = None,
               table_sample: list[dict] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """(queries, scenario_results). rules/detectors as written by 07 (rules keyed by rule_id).
    ptp_sample / mue_sample: NCCI rule dicts (from policy_rules) whose edit rows test the batch statements.
    table_sample (2026-10-04, v5.2): AHCCCS table rule dicts (origin 'ahcccs_table', from policy_rules; see
    sample_tables) whose edit rows test the three table batch statements - each rule's own scenarios, like a single
    rule. Their scratch edit tables are written only when there is such a sample."""
    fmt = fmt or getattr(config, "TABLE_FORMAT", "delta")
    by_id = {r["rule_id"]: r for r in rules}
    jobs = []          # (query_id, sql, [rules in this query], scenarios)
    for i, d in enumerate(dd for dd in detectors if dd.get("compiled") and dd.get("sql")):
        r = by_id.get(d["rule_id"])
        if r is None:
            continue
        jobs.append((d["rule_id"], d["sql"], [r], scenarios(r, f"Q{i:03d}"), d.get("sql_sha256")))
    sig = [dd for dd in detectors if dd.get("compiled") and isinstance(dd.get("signal_sql"), str) and dd["signal_sql"]]
    for i, d in enumerate(sig):
        r = by_id.get(d["rule_id"])
        if r is None:
            continue
        jobs.append((f"SIGNAL:{d['rule_id']}", d["signal_sql"], [r], signal_scenarios(r, f"S{i:03d}"),
                     d.get("signal_sql_sha256")))
    batch = {b["batch"]: b for b in (batch_rows or [])}
    edits_p = [r for r in (ptp_sample or [])]
    edits_m = [r for r in (mue_sample or [])]
    if "ncci_ptp" in batch and edits_p:
        sc = []
        for j, r in enumerate(edits_p):
            sc += [dict(s, rule_id=r["rule_id"]) for s in scenarios(r, f"P{j:03d}")]
        jobs.append(("BATCH:ncci_ptp", batch["ncci_ptp"]["sql"], edits_p, sc, batch["ncci_ptp"].get("sql_sha256")))
    if "ncci_mue" in batch and edits_m:
        sc = []
        for j, r in enumerate(edits_m):
            sc += [dict(s, rule_id=r["rule_id"]) for s in scenarios(r, f"M{j:03d}")]
        jobs.append(("BATCH:ncci_mue", batch["ncci_mue"]["sql"], edits_m, sc, batch["ncci_mue"].get("sql_sha256")))
    tsample = {k: [r for r in (table_sample or []) if dg.table_batch_kind(r) == k] for k in dg.TABLE_BATCHES}
    tested = []                          # the table rules whose batch statement runs here
    for k in dg.TABLE_BATCHES:
        if k in batch and tsample[k]:
            sc = table_scenarios(k, tsample[k])
            jobs.append((f"BATCH:{k}", batch[k]["sql"], tsample[k], sc, batch[k].get("sql_sha256")))
            tested += tsample[k]
    if not jobs:
        return pd.DataFrame(), pd.DataFrame()

    lines = [ln for _, _, _, scs, _ in jobs for s in scs for ln in s["lines"]]
    _write_claims(spark, _claims_frame(lines), fmt)
    import kb_io
    ptp, mue = dg.ncci_edit_tables(edits_p + edits_m)
    for df, t in ((ptp, _qv('ptp_edits')), (mue, _qv('mue_limits'))):
        df = df.assign(build_id=QV_BUILD)
        kb_io.write_table(spark, df, t, mode="overwrite")
    if tested:
        for k, df in zip(dg.TABLE_BATCHES, dg.ahcccs_edit_tables(tested)):
            kb_io.write_table(spark, df.assign(build_id=QV_BUILD), _qv(_TABLE_SCRATCH[k]), mode="overwrite")

    qrows, srows = [], []
    for qid, sql, rs, scs, sha in jobs:
        try:
            found = [r.asDict() for r in spark.sql(scratch_sql(sql, build_id)).collect()]
            err = None
        except Exception as e:                      # a query that does not run is a FAIL, recorded
            found, err = [], f"{type(e).__name__}: {str(e)[:300]}"
        ok_all = err is None
        for s in scs:
            ok, got = (False, err) if err else _judge(found, s)
            ok_all &= ok
            srows.append({"query_id": qid, "rule_id": s.get("rule_id", qid), "scenario": s["sid"],
                          "description": s["description"], "expected_findings": s["expect"],
                          "expected_severity": s["severity"], "result": got, "pass": ok,
                          "lines": "; ".join(f"{x[C['claim_id']]}:{x[C['line_no']]} {x[C['code']]} x{x[C['units']]:g} "
                                             f"${x[C['paid_amt']]:g} {x[C['dos']]} prov {x[C['servicing_provider']]}"
                                             f"{_billing_id_text(x)}"
                                             f"{' mod ' + '/'.join(str(x[m]) for m in C['mods'] if x.get(m)) if any(x.get(m) for m in C['mods']) else ''}"
                                             f"{' PA' if x[C['pa_no']] else ''} form {x[C['form']]}"
                                             f"{' type ' + str(x.get(C.get('prov_type'))) if C.get('prov_type') else ''}"
                                             f"{' billed by ' + str(x.get(C.get('billing_type'))) if C.get('billing_type') else ''}"
                                             for x in s["lines"])})
        r0 = rs[0]
        p0 = r0.get("predicate") or {}
        is_batch, is_sig = qid.startswith("BATCH"), qid.startswith("SIGNAL:")
        tkind = qid.split(":", 1)[1] if is_batch and qid.split(":", 1)[1] in dg.TABLE_BATCHES else None
        if tkind:
            what = _TABLE_WHAT[tkind] + " " + what_it_does(r0)
        elif is_batch and qid.endswith("ptp"):
            what = ("Joins every paid line pair (same member, servicing provider, date and claim form) to the edit "
                    "table; one statement covers every edit row - each sampled edit row below is tested like a single "
                    "rule. " + what_it_does(r0))
        elif is_batch:
            what = ("Joins every paid line to the MUE table on code and claim form; each sampled MUE row is tested "
                    "like a single rule. " + what_it_does(r0))
        elif is_sig:
            what = signal_text(r0)
        else:
            what = what_it_does(r0)
        qrows.append({
            "query_id": qid,
            "query_kind": ("AHCCCS table batch (finding query)" if tkind else "NCCI batch (finding query)" if is_batch
                           else "utilization signal (NOT a finding)" if is_sig else "state rule (finding query)"),
            "origin": dg.TABLE_ORIGIN if tkind else "ncci" if is_batch else r0.get("origin"),
            "predicate_type": "rolling_signal" if is_sig else p0.get("type"),
            "rules_tested": len(rs),
            "statement": (_TABLE_STATEMENT[tkind] if tkind else
                          ("All NCCI PTP pairs in policy_ncci_ptp_edits, in ONE statement" if qid.endswith("ptp") else
                           "All NCCI MUE limits in policy_ncci_mue_limits, in ONE statement") if is_batch else
                          r0.get("statement")),
            "verbatim_quote": None if is_batch else r0.get("verbatim_quote"),
            "source": ("AHCCCS rule tables, every loaded version (rows tested: see scenarios)" if tkind else
                       "CMS Medicaid NCCI edit files (rows tested: see scenarios)" if is_batch else
                       f"{r0.get('source_doc')} | {r0.get('source_locator')}"),
            "source_url": r0.get("source_url"),
            "reviewer": r0.get("reviewer"),
            "conditions": None if is_batch else dg._qualifier_label(r0),
            "pair_scope": dg.pair_scope(r0) if p0.get("type") == "code_pair_prohibited" and not is_batch else None,
            "effective_date": None if is_batch else r0.get("effective_date"),
            "end_date": None if is_batch else r0.get("end_date"),
            "dates_covered": ("each edit row's own version window: from its version's date to the day before the next "
                              "version's date (the latest version: open-ended)" if tkind else
                              "each edit row's own CMS effective and deletion dates" if is_batch else dates_covered(r0)),
            "what_it_does": what,
            "sql": sql, "sql_sha256": sha or dg.sql_sha256(sql),
            "scenarios": len(scs), "scenarios_passed": sum(1 for s in srows if s["query_id"] == qid and s["pass"]),
            "auto_test": "PASS" if ok_all and scs else ("FAIL" if scs else "NO SCENARIOS"),
            "predicate": json.dumps(p0, sort_keys=True, default=str),
            # filled in by the validator (the boss / an SME), then ingested by v06
            "validator": None, "validator_decision": None, "validator_note": None,
        })
    return pd.DataFrame(qrows), pd.DataFrame(srows)


def sample_ncci(rules: list[dict], n_ptp: int = 12, n_mue: int = 8, seed: int = 20261002) -> tuple[list, list]:
    """A stratified, reproducible sample of NCCI rules to test the two batch statements: PTP by
    (edit file, indicator, has end date), MUE by (edit file, relaxed later)."""
    import random
    rnd = random.Random(seed)
    ptp = [r for r in rules if r.get("origin") == "ncci" and (r.get("predicate") or {}).get("type") == "code_pair_prohibited"]
    mue = [r for r in rules if r.get("origin") == "ncci" and (r.get("predicate") or {}).get("type") == "max_units_per_line"]
    pk = lambda r: (r["predicate"].get("ncci_edition"), str(r["predicate"].get("modifier_indicator")), bool(r.get("end_date")))
    mk = lambda r: (r["predicate"].get("ncci_edition"), bool(r["predicate"].get("removed_later")
                                                       or r["predicate"].get("later_max_threshold") is not None))
    return _strat(ptp, pk, n_ptp, rnd), _strat(mue, mk, n_mue, rnd)


def _strat(rs: list[dict], key, n: int, rnd) -> list[dict]:
    """Up to n rules, round-robin over the strata of `key` (sorted), a random rule of each in turn: reproducible for a
    seed whatever order the rules arrive in."""
    groups: dict = {}
    for r in sorted(rs, key=lambda x: x["rule_id"]):
        groups.setdefault(key(r), []).append(r)
    out, keys = [], sorted(groups, key=str)
    while len(out) < n and any(groups.values()):
        for k in keys:
            if groups[k] and len(out) < n:
                out.append(groups[k].pop(rnd.randrange(len(groups[k]))))
    return out


def sample_tables(rules: list[dict], n_pair: int = 8, n_daily: int = 6, n_ptype: int = 6,
                  seed: int = 20261004) -> list[dict]:
    """2026-10-04 (v5.2): a stratified, reproducible sample of the AHCCCS table rules that run through the three table
    batch statements (table_batch_kind; pass it to build_pack as table_sample): Same Day Disallow pairs by (scope - D /
    A*, both ways, closed version window), daily limits by (scope, closed window), provider-type rules by (role, closed
    window). (v2.6) A sampled pair disallowed both ways brings its reverse rule, so the pack tests both lines flagged."""
    import random
    rnd = random.Random(seed)
    by = {k: [r for r in rules if dg.table_batch_kind(r) == k] for k in dg.TABLE_BATCHES}
    keys = {dg.BATCH_AHCCCS_PAIR: lambda r: (dg.pair_scope(r), dg._both_ways(r), bool(r.get("end_date"))),
            dg.BATCH_AHCCCS_DAILY: lambda r: (dg.daily_scope(r), bool(r.get("end_date"))),
            dg.BATCH_AHCCCS_PTYPE: lambda r: (str((r.get("predicate") or {}).get("provider_role") or "billing"),
                                              bool(r.get("end_date")))}
    out = []
    for k, n in zip(dg.TABLE_BATCHES, (n_pair, n_daily, n_ptype)):
        picked = _strat(by[k], keys[k], n, rnd)
        if k == dg.BATCH_AHCCCS_PAIR:        # v2.6: a both-ways pair brings its reverse rule (scenario BW)
            for r in list(picked):
                rv = _reverse_of(r, by[k]) if dg._both_ways(r) else None
                if rv is not None and rv["rule_id"] not in {x["rule_id"] for x in picked}:
                    picked.append(rv)
        out += picked
    return out
