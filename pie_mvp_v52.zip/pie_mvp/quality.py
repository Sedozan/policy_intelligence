"""
quality.py  -  the measurement bar, in plain pandas (no Spark).

Used by notebooks/validation/v01_extraction_scoring, v02_detector_precision, v03_pipeline_health and
v05_extraction_regression. Everything here is deterministic and unit-tested (tests/test_quality.py).

  wilson(k, n)                 95% Wilson score interval for a proportion k/n.
  n_needed(p_hat, target)      sample size at which the Wilson LOWER bound reaches `target`,
                               if the observed rate stays at p_hat.
  n_for_ci_width(p_hat, width) sample size at which the whole interval is no wider than `width`.
  stratified_sample(df, by, n_per, seed)
                               up to n_per rows per stratum, chosen by a seeded hash of each
                               row's key - same rows every time, whatever order Spark returns.
  stratified_ratio(df, y, x)   a rate from such a sample, each stratum weighted by its size in the
                               population, with a Wilson interval on the effective sample size.
  current_doc_hash(inventory)  {document: doc_hash} of each document's current version (v01 / v03).
  latest_runs(log, current_doc_hash)
                               {chapter: run_id} of the latest successful run of each current version.
  run_population(drafts, current_doc_hash, latest_run, state_rules, log)
                               v01's default RULES population: the drafts the LATEST successful run of each
                               chapter's current version produced (policy_extraction_drafts).
  scoring_population(state_rules, current_doc_hash, statuses)
                               v01's STATUSES population (e.g. approved rules), from state_rules.
  current_run_rows(df, current_doc_hash, latest_run)
                               rows of the current document version from the latest run (v01 DROPPED).
  sample_population(statuses)  the population label v01 stamps on every sheet row and v03 checks.
  sample_runs_text(runs)       the {chapter: run_id} a sample describes, as one canonical text (v01 stamps it).
  drop_reason_class(reason)    a dropped candidate's reason without its specifics (a stratum label).
  extraction_metrics(rules, sections, dropped)
                               precision / executable-rule precision / fidelity / recall / filter loss
                               rows per chapter + pooled, each weighted by stratum size.
  detector_metrics(findings)            precision per origin x predicate_type + pooled,
                                        plus the share the reviewer could not decide.
  metric_for_bar(metrics, name, scope, corpus_version, latest_run)
                               the metric row v03 may judge: the engine's own sample, the current corpus, the
                               latest run of every chapter it covers.
  lower_bound_bar / routing_bar / corpus_bar / signoff_bar / table_readings_bar / run_completeness
                               v03's GO / NOT YET verdicts, each with the reason it gives.
  corpus_differences(a, b)     the documents two {document: sha256} sets disagree on (v05 A/B).
  xlsx_write_sheets / xlsx_read_sheets  multi-sheet workbooks, Volume-safe like state_rules._xlsx_write
                                        (which writes a single sheet).
  as_text_frame(df)            all-text columns before appending a workbook to a table.

Metric rows have the columns in METRIC_COLUMNS; the notebook adds sample_id and computed_at.
"""
from __future__ import annotations

import hashlib
import json
import math

import pandas as pd

import schema

# 2026-10-04 (critic M51-3 / M51-6): every metric row also says how many drawn units were left unscored (unscored, next
# to scored_units: the units that count - rules, or sections for recall), which population the sample was drawn from
# and on which corpus - and (follow-up, same day) which extraction run of each chapter it covers (sample_runs: JSON
# {chapter: run_id}, sample_runs_text), so a re-extraction of the same corpus makes it stale. "notes" stays LAST: v02 /
# v07 write METRIC_COLUMNS[:-1] + [sample_id, computed_at, notes] and leave the extraction columns blank.
METRIC_COLUMNS = ["metric", "scope_type", "scope", "n", "value", "ci_low", "ci_high", "unscored", "scored_units",
                  "population", "corpus_version", "sample_runs", "notes"]
# the population v01 draws by default (STATUSES = None): the drafts of the latest successful run of each chapter's
# current document version - the engine's own output, before review. v03 judges a bar only on this population.
ENGINE_POPULATION = "engine_latest_run"
# a bar is NOT YET while more than this share of the drawn units was left unscored: blanks are excluded from a rate, and
# an excluded tenth can hide the rules a scorer found hard (critic M51-6: 80 scored + 20 blank said GO on the 80)
MAX_UNSCORED_SHARE = 0.10
EXTRACTION_METRICS = ("extraction_precision", "executable_rule_precision", "extraction_fidelity", "extraction_recall",
                      "extraction_filter_loss")
DISPOSITIONS = ("true_violation", "false_positive", "cannot_tell")
# the predicate types that CAN become SQL once approved. Whether a rule is executable is regress.compiles(): such a type
# AND a population of 'all' or one an age condition expresses (2026-10-04, critic M51-11: the type alone counted an
# age-less 'members under 21' cap as executable while the gate keeps it a lead)
COMPILED_TYPES = frozenset(schema.PREDICATE_TYPES_COMPILED)
# what the corpus covers today. Never "AHCCCS policy": the AMPM, the fee schedule and the coding resources
# (config.CORPUS_PENDING) are other authorities (2026-10-04, external review)
CORPUS_SCOPE = "AHCCCS FFS Provider Billing Manual chapters and exhibits"

_YES = {"y", "yes", "true", "1", "1.0", "t"}
_NO = {"n", "no", "false", "0", "0.0", "f"}


# ------------------------------------------------------------------ intervals
def wilson(k, n, z: float = 1.96) -> tuple[float, float, float]:
    """(p, lo, hi). n = 0 -> (nan, 0.0, 1.0): no data means the rate could be anything."""
    n = float(n or 0)
    if n <= 0:
        return float("nan"), 0.0, 1.0
    k = float(k)
    if k < 0 or k > n:
        raise ValueError(f"k={k} outside 0..n={n}")
    p = k / n
    z2 = z * z
    denom = 1.0 + z2 / n
    centre = (p + z2 / (2 * n)) / denom
    half = (z / denom) * math.sqrt(p * (1 - p) / n + z2 / (4 * n * n))
    return p, max(0.0, centre - half), min(1.0, centre + half)


def stratified_ratio(df: pd.DataFrame, y: str, x: str, stratum: str = "stratum", size: str = "stratum_size",
                     z: float = 1.96) -> dict:
    """A rate estimated from a STRATIFIED sample, each stratum weighted by its size in the population - the pooled
    number v03 judges. Critic 2026-10-04: v01 samples up to N rows per stratum whatever the stratum's size, so a plain
    pooled rate lets six small, clean strata outvote six big ones (178/180 pooled, lower bound 0.960, GO; weighted,
    about 0.925).

    df: one row per sampled unit with its stratum label, the stratum's size in the population (`size`, units of the
    same kind as the rows: rules, sections, pages - stratified_sample() writes it), a numerator `y` and a denominator
    `x` >= y >= 0. Precision: one rule per row, y = 1 if right else 0, x = 1. Recall: one section per row, y = real
    rules found, x = found + missed (a section with x = 0 still counts as sampled). Rows with y or x missing must be
    dropped by the caller (and reported as unscored).
    Estimator: the combined ratio R = sum_h (N_h/n_h) sum_i y_hi / sum_h (N_h/n_h) sum_i x_hi, its variance by
    linearisation, Var(R) = sum_h N_h^2 (1 - n_h/N_h) s_h^2 / n_h / X^2 with s_h^2 the sample variance of
    d_hi = y_hi - R x_hi (a stratum of one row borrows the variance of all rows, so it is never counted as certain),
    and the 95% interval a Wilson interval on the effective sample size n_eff = R(1-R)/Var(R), capped at the
    estimated population total X. When R is 0 or 1 (no variance to estimate) n_eff is the number of sampled units in
    the denominator (sum of x) - the plain Wilson interval. A stratum whose size is missing or smaller than its
    sample is taken at its sample size (weight 1) and named in `notes`.
    Returns {value, ci_low, ci_high, n (sum of x over the sample), n_eff, units, strata, notes}."""
    out = {"value": float("nan"), "ci_low": 0.0, "ci_high": 1.0, "n": 0, "n_eff": 0.0, "units": 0, "strata": 0,
           "notes": ""}
    if df is None or not len(df):
        return out
    d = pd.DataFrame({"h": df[stratum].astype(str) if stratum in df else "all",
                      "N": pd.to_numeric(df[size], errors="coerce") if size in df else float("nan"),
                      "y": pd.to_numeric(df[y], errors="coerce"), "x": pd.to_numeric(df[x], errors="coerce")})
    if d["y"].isna().any() or d["x"].isna().any() or (d["y"] < 0).any() or (d["y"] > d["x"]).any():
        raise ValueError("stratified_ratio: every row needs 0 <= y <= x (drop unscored rows first)")
    groups, odd = [], []
    for h, g in d.groupby("h", sort=True):
        n_h = len(g)
        N_h = g["N"].max()
        if pd.isna(N_h) or N_h < n_h:
            odd.append(h)
            N_h = n_h
        groups.append((h, float(N_h), n_h, g["y"].to_numpy(float), g["x"].to_numpy(float)))
    Y = sum(N / n * ys.sum() for _, N, n, ys, _ in groups)
    X = sum(N / n * xs.sum() for _, N, n, _, xs in groups)
    n_x = int(round(d["x"].sum()))
    out.update(units=int(len(d)), strata=len(groups), n=n_x,
               notes=(f"weighted by stratum size over {len(groups)} {'stratum' if len(groups) == 1 else 'strata'}"
                      + (f"; stratum size missing or below the sample for {odd[:5]}: weight 1" if odd else "")))
    if X <= 0:
        return out
    R = Y / X
    all_d = d["y"].to_numpy(float) - R * d["x"].to_numpy(float)
    pooled_var = float(all_d.var(ddof=1)) if len(all_d) >= 2 else 0.0
    var = 0.0
    for _, N, n, ys, xs in groups:
        dh = ys - R * xs
        s2 = float(dh.var(ddof=1)) if n >= 2 else pooled_var
        var += N * N * (1.0 - n / N) * s2 / n
    var /= X * X
    if 0.0 < R < 1.0 and var > 0:
        n_eff = min(R * (1.0 - R) / var, X)
    elif 0.0 < R < 1.0:
        n_eff = X                                   # every stratum fully sampled: a census of the population
    else:
        n_eff = float(n_x)
    n_eff = max(n_eff, 1e-9)
    p, lo, hi = wilson(R * n_eff, n_eff, z)
    out.update(value=float(R), ci_low=float(lo), ci_high=float(hi), n_eff=round(float(n_eff), 1))
    return out


def n_needed(p_hat: float, target: float, z: float = 1.96, n_max: int = 1_000_000) -> int | None:
    """Smallest n whose Wilson lower bound is >= target when the observed rate is p_hat.

    None when it can never happen (p_hat <= target: the lower bound is always below p_hat)
    or would need more than n_max. The observed rate is held fixed, so this is a planning
    number, not a promise - the next samples can move p_hat either way."""
    if p_hat is None or (isinstance(p_hat, float) and math.isnan(p_hat)) or p_hat <= target:
        return None

    def lo(n):
        return wilson(p_hat * n, n, z)[1]

    if lo(n_max) < target:
        return None
    a, b = 1, n_max                                   # lo(n) rises with n at a fixed rate
    while a < b:
        m = (a + b) // 2
        if lo(m) >= target:
            b = m
        else:
            a = m + 1
    return a


def n_for_ci_width(p_hat: float, width: float, z: float = 1.96, n_max: int = 1_000_000) -> int | None:
    """Smallest n whose Wilson interval (hi - lo) is <= width when the observed rate is p_hat.
    A planning number for "measured precisely enough to state"; None if above n_max or p_hat is missing."""
    if p_hat is None or (isinstance(p_hat, float) and math.isnan(p_hat)) or width <= 0:
        return None

    def w(n):
        _, lo, hi = wilson(p_hat * n, n, z)
        return hi - lo

    if w(n_max) > width:
        return None
    a, b = 1, n_max                                   # the interval narrows as n grows
    while a < b:
        m = (a + b) // 2
        if w(m) <= width:
            b = m
        else:
            a = m + 1
    return a


# ------------------------------------------------------------------ sampling
def _strings(df: pd.DataFrame, cols: list, blank: str, sep: str = "|") -> pd.Series:
    """Row-wise join of `cols` as text; missing values become `blank`."""
    parts = [df[c].astype(object).where(df[c].notna(), blank).astype(str) for c in cols]
    out = parts[0]
    for p in parts[1:]:
        out = out + sep + p
    return out


def sample_hash(df: pd.DataFrame, key: list, seed: int) -> pd.Series:
    """sha256("<seed>#<k1>|<k2>|...") per row, nulls as ''. Spark equivalent: sample_hash_sql()."""
    joined = _strings(df, list(key), "")
    return pd.Series([hashlib.sha256(f"{seed}#{s}".encode()).hexdigest() for s in joined], index=df.index)


def sample_hash_sql(key: list, seed: int) -> str:
    """The same hash as sample_hash(), as a Spark SQL expression - lets a notebook pre-select the
    candidate rows in Spark (millions of findings) and hand only those to stratified_sample(),
    which then picks exactly the rows it would have picked from the full table. Key columns must
    be strings (or render identically with CAST AS STRING)."""
    cols = ", ".join(f"COALESCE(CAST({c} AS STRING), '')" for c in key)
    return f"sha2(concat('{int(seed)}#', concat_ws('|', {cols})), 256)"


def stratified_sample(df: pd.DataFrame, by: list, n_per: int, seed: int = 0,
                      key: list | None = None) -> pd.DataFrame:
    """Up to n_per rows from every stratum (combination of `by` values).

    Selection is the lowest sample_hash() of each row's `key` columns (default: every column), so
    the result does not depend on row order or on the pandas / numpy version, and adding rows to a
    stratum never reshuffles which of the old rows were picked. Adds:
      stratum       the `by` values joined with ' | '  (missing -> '(none)')
      stratum_size  rows in that stratum before sampling (to weight a pooled estimate)
    """
    if df is None or len(df) == 0:
        cols = list(df.columns) if df is not None else []
        return pd.DataFrame(columns=cols + ["stratum", "stratum_size"])
    if n_per is None or int(n_per) < 1:
        raise ValueError("n_per must be >= 1")
    key = list(key) if key else [c for c in df.columns]
    d = df.copy()
    d["stratum"] = _strings(d, list(by), "(none)", " | ") if by else "all"
    d["stratum_size"] = d.groupby("stratum")["stratum"].transform("size").astype(int)
    d["_h"] = sample_hash(d, key, seed)
    d = d.sort_values(["stratum", "_h"], kind="mergesort")
    d["_rank"] = d.groupby("stratum").cumcount()
    out = d[d["_rank"] < int(n_per)].drop(columns=["_h", "_rank"])
    return out.reset_index(drop=True)


# ------------------------------------------------------------------ helpers
def _yn(v):
    """'Y'/'N' (and yes/no/true/false/1/0) -> True/False; blank or anything else -> None."""
    if _is_blank(v):
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    return True if s in _YES else False if s in _NO else None


def _int_or_none(v):
    """A count: a whole number >= 0 (2, 2.0, "2", "2.0") as an int; anything else - a decimal, a negative, text, a
    boolean, a blank - is None (blank, and reported by v01's ingest). 2026-10-04 (critic M51-7): int(float(v)) turned
    "0.5" into 0 and "2.9" into 2, so a scorer's typo silently changed recall instead of being reported."""
    if _is_blank(v) or pd.api.types.is_bool(v):
        return None
    try:
        f = float(v.strip()) if isinstance(v, str) else float(v)
    except (TypeError, ValueError):
        return None
    return int(f) if math.isfinite(f) and f.is_integer() and f >= 0 else None


def _row(metric, scope_type, scope, k, n, notes="") -> dict:
    p, lo, hi = wilson(k, n)
    return {"metric": metric, "scope_type": scope_type, "scope": str(scope), "n": int(n),
            "value": p, "ci_low": lo, "ci_high": hi, "notes": notes}


def _stamp(g: pd.DataFrame, col: str):
    """The one value of a sample stamp (population / corpus_version) over the rows of a scope: None when the sheet has
    no such column or every cell is blank (a workbook exported before 2026-10-04, critic M51-3), 'mixed: a | b' when the
    rows disagree (two samples pasted together) - never one of them picked."""
    vals = sorted({_text(v) for v in g[col]} - {""}) if col in g.columns else []
    if not vals:
        return None
    return vals[0] if len(vals) == 1 else "mixed: " + " | ".join(vals[:5])


def sample_runs_text(runs: dict | None) -> str | None:
    """{chapter: run_id} as ONE canonical text - JSON, keys sorted, a run not known as null - so the same runs always
    give the same stamp. None for no chapter. v01 stamps it on every sheet row (column sample_runs)."""
    if not runs:
        return None
    return json.dumps({str(k).strip(): (_text(v) or None) for k, v in runs.items()}, sort_keys=True)


def _runs_stamp(g: pd.DataFrame):
    """sample_runs of a scope: the one stamp its rows carry (None / 'mixed: ...' as _stamp says), narrowed to the
    chapters of these rows - a chapter's metric row names its own chapter's run, the pooled row every sampled chapter's,
    so a re-extraction of one chapter leaves another chapter's own number judgeable (follow-up to critic M51-3)."""
    s = _stamp(g, "sample_runs")
    runs = _json(s) if s and not s.startswith("mixed: ") else None
    if not isinstance(runs, dict):
        return s                                         # None, mixed, or unreadable: kept as it is (never judgeable)
    chapters = sorted(set(_text_col(g, "chapter")) - {""}) if "chapter" in g.columns else []
    return sample_runs_text({c: runs.get(c) for c in chapters}) if chapters else s


def _ratio_row(metric: str, st: str, sc, g: pd.DataFrame, units: pd.Series, y: pd.Series, x: pd.Series,
               counts: pd.Series, note: str) -> dict:
    """One metric row for a scope. g: the scope's sheet rows (they carry the sample stamps); units: which of them are
    this metric's sampled units; y / x: each unit's numerator / denominator; counts: the units whose scores count
    (blank, invalid or inconsistent ones are left out of the rate and carried as `unscored`). The rate is
    stratified_ratio over the counted units, each stratum weighted by its size; scored_units = the units counted.
    2026-10-04 (critic M51-2): the pooled and per-chapter rows were plain pools of a stratified sample, so small clean
    strata outvoted big ones."""
    use = units & counts
    cols = {"y": y[use], "x": x[use]}
    for c in ("stratum", "stratum_size"):
        if c in g.columns:
            cols[c] = g.loc[use, c]
    r = stratified_ratio(pd.DataFrame(cols, index=g.index[use.to_numpy(bool)]), "y", "x")
    tail = r["notes"] + (f"; effective sample size {r['n_eff']:g}" if r["units"] else "")
    return {"metric": metric, "scope_type": st, "scope": str(sc), "n": int(r["n"]), "value": r["value"],
            "ci_low": r["ci_low"], "ci_high": r["ci_high"], "unscored": int((units & ~counts).sum()),
            "scored_units": int(r["units"]), "population": _stamp(g, "population"),
            "corpus_version": _stamp(g, "corpus_version"), "sample_runs": _runs_stamp(g),
            "notes": " ".join(p for p in (note.strip(), (tail + ".") if tail else "") if p)}


def _scopes(df: pd.DataFrame, col: str, pooled: bool = True):
    """[(scope_type, scope, sub-frame)] - one per value of `col`, then (pooled=True) the pooled sample."""
    out = []
    if col in df.columns:
        for v, g in df.groupby(df[col].astype(object).where(df[col].notna(), "(none)").astype(str), sort=True):
            out.append((col, v, g))
    if pooled:
        out.append(("overall", "all", df))
    return out


_POOLED = "pooled over the sample, not weighted by stratum size"


def _json(v):
    """A dict / list given as itself or as JSON text; None when it cannot be read."""
    if isinstance(v, (dict, list)):
        return v
    if _is_blank(v):
        return None
    try:
        return json.loads(str(v))
    except ValueError:
        return None


def _text(v) -> str:
    return "" if _is_blank(v) else str(v).strip()


def _text_col(df: pd.DataFrame, col: str) -> pd.Series:
    """A column as stripped text ('' for blanks); all '' when the frame has no such column."""
    if col not in df.columns:
        return pd.Series("", index=df.index, dtype=object)
    return pd.Series([_text(v) for v in df[col]], index=df.index, dtype=object)


def _num_col(df: pd.DataFrame, col: str) -> pd.Series:
    """A count column as float (NaN for blank / invalid); all NaN when the frame has no such column."""
    if col not in df.columns:
        return pd.Series(float("nan"), index=df.index, dtype=float)
    return pd.Series([_int_or_none(v) for v in df[col]], index=df.index, dtype=float)


def predicate_type_of(v) -> str | None:
    """The `type` of a predicate given as a dict or as JSON text; None when it cannot be read."""
    p = _json(v)
    t = p.get("type") if isinstance(p, dict) else None
    return str(t) if t else None


def _rule_types(r: pd.DataFrame) -> pd.Series:
    """Each scored rule's predicate type: the sheet's predicate_type column, else read from its predicate."""
    given = _text_col(r, "predicate_type")
    preds = r["predicate"] if "predicate" in r.columns else pd.Series(None, index=r.index, dtype=object)
    return pd.Series([t or predicate_type_of(p) for t, p in zip(given, preds)], index=r.index, dtype=object)


def _executable(r: pd.DataFrame) -> pd.Series:
    """Would each sampled rule compile once approved? regress.compiles - the test v05's ship gate uses: a compiled
    predicate type (the sheet's predicate_type) AND a rule population ('rule_population') of 'all' or one its age
    condition expresses. A sheet without rule_population (exported before 2026-10-04, critic M51-11) is read as
    population 'all' - the type alone, as before - and extraction_metrics says so."""
    import regress
    types_ = _rule_types(r)
    preds = r["predicate"] if "predicate" in r.columns else pd.Series(None, index=r.index, dtype=object)
    pops = _text_col(r, "rule_population")
    out = []
    for t, p, pop in zip(types_, preds, pops):
        pd_ = _json(p)
        pd_ = dict(pd_) if isinstance(pd_, dict) else {}
        if t:
            pd_["type"] = t                                    # the type of the predicate the sheet shows
        out.append(bool(regress.compiles(pd_, pop or "all")))
    return pd.Series(out, index=r.index, dtype=bool)


# ------------------------------------------------------------------ populations (v01 export)
def current_doc_hash(inventory: pd.DataFrame | None) -> dict:
    """{document: doc_hash} of each document's CURRENT version: the doc_hash of its latest inventory row (by
    fetched_at; the recipe 07 uses), blank hashes left out. v01 stamps policy_docs.corpus_version of it on every sheet
    row and v03 compares that stamp with its own - one shared recipe, so the two agree on the same inventory."""
    if inventory is None or not len(inventory) or not {"chapter", "doc_hash"} <= set(inventory.columns):
        return {}
    inv = inventory.sort_values("fetched_at", kind="mergesort") if "fetched_at" in inventory.columns else inventory
    cur = inv.groupby(inv["chapter"].astype(str).str.strip())["doc_hash"].last().to_dict()
    return {str(k): _text(v) for k, v in cur.items() if _text(v)}


def latest_runs(log: pd.DataFrame | None, current_doc_hash: dict | None) -> dict:
    """{chapter: run_id} of the LATEST run that extracted each chapter's CURRENT document version without an error
    (policy_extraction_log rows; run ids are timestamps): its drafts are the engine's current output."""
    if log is None or not len(log) or not {"chapter", "doc_hash", "run_id"} <= set(log.columns):
        return {}
    cur = {str(k).strip(): _text(v) for k, v in (current_doc_hash or {}).items() if _text(v)}
    ch, h, run, err = (_text_col(log, c) for c in ("chapter", "doc_hash", "run_id", "error"))
    ok = pd.Series([c in cur and x == cur[c] and r != "" and e == "" for c, x, r, e in zip(ch, h, run, err)],
                   index=log.index, dtype=bool)
    return run[ok].groupby(ch[ok]).max().to_dict() if ok.any() else {}


def sample_population(statuses=None) -> str:
    """The population label v01 stamps on every sheet row (column `population`) and v03 checks: ENGINE_POPULATION for
    the default sample, 'statuses:<s1,s2>' for a STATUSES sample (e.g. the fidelity of approved rules)."""
    return ENGINE_POPULATION if not statuses else "statuses:" + ",".join(str(s) for s in statuses)


def run_population(drafts: pd.DataFrame | None, current_doc_hash: dict | None, latest_run: dict | None = None,
                   state_rules: pd.DataFrame | None = None, log: pd.DataFrame | None = None) -> tuple[pd.DataFrame, dict]:
    """v01's default RULES population (STATUSES = None): the drafts the LATEST successful run of each chapter's CURRENT
    document version produced - rows of policy_extraction_drafts (05 writes every run's drafts there) picked like the
    DROPPED sheet's candidates (current_run_rows; latest_run from latest_runs()). 2026-10-04 (critic M51-1): the
    population used to be state_rules, where merge_drafts keeps approved / rejected rows of OLDER runs (a re-extracted
    decided key keeps its old predicate; a decided key the new run no longer produces is never superseded), so the
    sample mixed engine versions. The predicate shown is the run's own; review_status (and reviewer_fix) come from
    state_rules, for information only.
    Report: rows / other_doc_version / older_run (left out), chapters {chapter: run sampled}, no_run_rows {chapter: its
    latest run, or None} - chapters that have extracted rules of their current version (or a latest run) but no rows in
    policy_extraction_drafts for that run (persisted before 2026-10-04: re-run 05 on the run folder) - and
    empty_latest_run [chapters whose latest run produced no draft (log drafts_unique = 0)]."""
    rows, rep = current_run_rows(drafts, current_doc_hash, latest_run)
    rep = dict(rep, chapters={}, no_run_rows={}, empty_latest_run=[])
    cur = {str(k).strip(): _text(v) for k, v in (current_doc_hash or {}).items() if _text(v)}
    latest = {str(k).strip(): _text(v) for k, v in (latest_run or {}).items() if _text(v)}
    rows = rows.copy()
    if len(rows):
        rows["chapter"] = _text_col(rows, "chapter")
        rep["chapters"] = (pd.Series(_text_col(rows, "run_id").to_numpy(), index=rows["chapter"].to_numpy())
                           .groupby(level=0).max().to_dict())
    # which chapters should have rows: those with a latest run, and those whose current version has extracted rules
    sr = state_rules if state_rules is not None else pd.DataFrame()
    expected = set(latest)
    if len(sr):
        o, st, c, h = (_text_col(sr, x) for x in ("origin", "review_status", "chapter", "doc_hash"))
        expected |= {cc for cc, oo, ss, hh in zip(c, o, st, h) if oo == "extracted" and ss != "superseded"
                     and cc in cur and hh == cur[cc]}
    n_drafts = {}
    if log is not None and len(log) and {"chapter", "run_id", "drafts_unique"} <= set(log.columns):
        for c, r, n in zip(_text_col(log, "chapter"), _text_col(log, "run_id"), log["drafts_unique"]):
            n_drafts[(c, r)] = _int_or_none(n)
    for c in sorted(expected - set(rep["chapters"]), key=lambda v: (len(v), v)):
        if n_drafts.get((c, latest.get(c))) == 0:
            rep["empty_latest_run"].append(c)
        else:
            rep["no_run_rows"][c] = latest.get(c)
    if not len(rows):
        return rows, rep
    # review status / reviewer_fix from state_rules, for the scorer's information (never what is sampled)
    by_key = {}
    if len(sr):
        for rec in sr.to_dict("records"):
            for k in (_text(rec.get("extraction_key")), _text(rec.get("rule_id"))):
                if k and k not in by_key:
                    by_key[k] = rec
    status, notes = [], []
    for rec in rows.to_dict("records"):
        s = by_key.get(_text(rec.get("extraction_key"))) or by_key.get(_text(rec.get("rule_id")))
        if s is None:
            status.append("(not in state_rules)")
            notes.append(None)
            continue
        status.append(_text(s.get("review_status")) or None)
        g = _json(s.get("grounding"))
        if isinstance(g, dict) and g.get("superseded_by_reviewer"):
            notes.append("a reviewer fixed this rule in state_rules; the predicate shown is the ENGINE's own (this "
                         "run's) - score that one")
        elif _canon_json(s.get("predicate")) != _canon_json(rec.get("predicate")):
            notes.append("state_rules holds an earlier run's predicate for this rule (review_status is about that "
                         "one); the predicate shown is this run's - score that one")
        else:
            notes.append(None)
    rows["review_status"] = pd.Series(status, index=rows.index, dtype=object)
    rows["reviewer_fix"] = pd.Series(notes, index=rows.index, dtype=object)
    rows["predicate_type"] = pd.Series([predicate_type_of(p) for p in rows["predicate"]] if "predicate" in rows
                                       else [None] * len(rows), index=rows.index, dtype=object)
    return rows, rep


def _canon_json(v) -> str:
    """A predicate as canonical JSON text ('' when unreadable), to tell two readings apart."""
    p = _json(v)
    return json.dumps(p, sort_keys=True) if isinstance(p, (dict, list)) else _text(v)


def scoring_population(state_rules: pd.DataFrame | None, current_doc_hash: dict | None, statuses=None,
                       engine_view: bool | None = None) -> tuple[pd.DataFrame, dict]:
    """v01's STATUSES population: rows of origin 'extracted' from each chapter's CURRENT document version
    (current_doc_hash {chapter: doc_hash of the latest inventory row}), never 'superseded' ones (drafts an older run of
    that version produced and the latest run no longer does).

    statuses = ["approved"]: the definition of done's "fidelity of APPROVED rules" (v01 STATUSES).
    statuses None: every non-superseded extracted row, REJECTED ones included. 2026-10-04 (critic M51-1): v01 no longer
    samples this as the engine's own output - state_rules keeps approved / rejected rows older runs left, so it mixes
    engine versions; run_population() is v01's default population now.
    engine_view (default: statuses is None): a rule a reviewer FIXED shows the engine's own predicate, which the fix kept
    in grounding.original_predicate, instead of the reviewer's correction - otherwise a reviewer's work would be scored
    as the engine's. reviewer_fix says on which rows a reviewer changed something and what the sheet shows.
    Adds predicate_type (of the predicate shown). Returns (rows, counts of what was left out and why)."""
    df = state_rules.copy() if state_rules is not None else pd.DataFrame()
    report = {"rows": int(len(df)), "not_extracted": 0, "superseded": 0, "other_doc_version": 0, "other_status": 0,
              "fixed_engine_predicate_shown": 0, "fixed_engine_predicate_not_recorded": 0}
    cur = {str(k).strip(): _text(v) for k, v in (current_doc_hash or {}).items() if _text(v)}
    origin, status = _text_col(df, "origin"), _text_col(df, "review_status")
    chapter, doc_hash = _text_col(df, "chapter"), _text_col(df, "doc_hash")
    keep = origin == "extracted"
    report["not_extracted"] = int((~keep).sum())
    superseded = keep & (status == "superseded")
    report["superseded"] = int(superseded.sum())
    keep &= ~superseded
    # a chapter with no inventory row has no current version: its rows cannot be placed, so they are left out too
    current = pd.Series([c in cur and h == cur[c] for c, h in zip(chapter, doc_hash)], index=df.index, dtype=bool)
    report["other_doc_version"] = int((keep & ~current).sum())
    keep &= current
    if statuses:
        other = keep & ~status.isin([str(s) for s in statuses])
        report["other_status"] = int(other.sum())
        keep &= ~other
    out = df[keep].copy()
    if engine_view is None:
        engine_view = not statuses
    shown, fixes = [], []
    for rec in out.to_dict("records"):
        pred = rec.get("predicate")
        g = _json(rec.get("grounding"))
        g = g if isinstance(g, dict) else {}
        if g.get("superseded_by_reviewer"):
            orig = g.get("original_predicate")
            unrecorded = (not orig) if isinstance(orig, (dict, list)) else _is_blank(orig)
            if not engine_view:
                fixes.append("predicate fixed by a reviewer: the signed (corrected) predicate is shown")
            elif unrecorded:
                fixes.append("predicate fixed by a reviewer: the engine's own predicate was not recorded, the "
                             "reviewer's is shown")
                report["fixed_engine_predicate_not_recorded"] += 1
            else:
                pred = orig if isinstance(orig, str) else json.dumps(orig)
                fixes.append("predicate fixed by a reviewer: the ENGINE's own predicate is shown (the statement may be "
                             "the reviewer's wording)")
                report["fixed_engine_predicate_shown"] += 1
        elif _text(rec.get("review_decision")).lower() == "fix":
            fixes.append("dates / population fixed by a reviewer; the predicate is the engine's")
        else:
            fixes.append(None)
        shown.append(pred)
    out["predicate"] = pd.Series(shown, index=out.index, dtype=object)
    out["reviewer_fix"] = pd.Series(fixes, index=out.index, dtype=object)
    out["predicate_type"] = pd.Series([predicate_type_of(p) for p in shown], index=out.index, dtype=object)
    return out, report


def current_run_rows(df: pd.DataFrame | None, current_doc_hash: dict | None,
                     latest_run: dict | None = None) -> tuple[pd.DataFrame, dict]:
    """Rows of a per-run table (policy_extraction_dropped ...) of each chapter's CURRENT document version, from the
    LATEST run that extracted it - the run whose drafts are the current ones (an older run of the same version dropped
    other candidates). latest_run {chapter: run_id} (from policy_extraction_log); a chapter it does not name takes the
    newest run_id among its own rows (run ids are timestamps). Returns (rows, counts of what was left out)."""
    d = df.copy() if df is not None else pd.DataFrame()
    report = {"rows": int(len(d)), "other_doc_version": 0, "older_run": 0}
    if not len(d):
        return d, report
    cur = {str(k).strip(): _text(v) for k, v in (current_doc_hash or {}).items() if _text(v)}
    chapter, doc_hash, run = _text_col(d, "chapter"), _text_col(d, "doc_hash"), _text_col(d, "run_id")
    current = pd.Series([c in cur and h == cur[c] for c, h in zip(chapter, doc_hash)], index=d.index, dtype=bool)
    report["other_doc_version"] = int((~current).sum())
    chapter, run = chapter[current], run[current]
    latest = {str(k).strip(): _text(v) for k, v in (latest_run or {}).items() if _text(v)}
    newest = run.groupby(chapter).max().to_dict() if len(run) else {}
    keep = pd.Series([r == latest.get(c, newest.get(c)) for c, r in zip(chapter, run)], index=chapter.index, dtype=bool)
    report["older_run"] = int((~keep).sum())
    return d.loc[keep[keep].index].copy(), report


def drop_reason_class(reason, post_checks=None) -> str:
    """A dropped candidate's drop_reason as a stratum label: its leading words without the specifics (the key a
    duplicate copies, the missing codes, the nearest sentence), so candidates dropped for the same reason share a
    stratum. A post-check drop is labelled by the checks that dropped it (post_checks: the JSON list of actions)."""
    r = _text(reason)
    if not r:
        return "(no reason)"
    low = r.lower()
    if low.startswith("duplicate"):
        # 'duplicate of <key>' (the run kept a copy with the same meaning) / 'duplicate (post-check): merged ...'
        return "duplicate"
    if low.startswith("post-check produced an invalid predicate"):
        return "post-check: invalid predicate"
    if low.startswith("post-check"):
        acts = _json(post_checks)
        names = sorted({str(a.get("check")) for a in acts if isinstance(a, dict) and a.get("action") == "drop"
                        and a.get("check")}) if isinstance(acts, list) else []
        return "post-check: " + " + ".join(names) if names else "post-check"
    return r.split(" (")[0].split(":")[0].strip() or r


# ------------------------------------------------------------------ extraction
def extraction_metrics(scored_rules: pd.DataFrame | None, scored_sections: pd.DataFrame | None,
                       scored_dropped: pd.DataFrame | None = None) -> pd.DataFrame:
    """Per chapter and pooled, every row a stratified_ratio over the sampled units of its scope - each stratum weighted
    by its size in the population (2026-10-04, critic M51-2: plain pools let small clean strata outvote big ones; a
    sheet without stratum_size is weighted 1 and says so) - with `unscored` (drawn units left out: blank, invalid or
    inconsistent scores; critic M51-6), `scored_units`, and the sample's `population` / `corpus_version` stamps copied
    from the sheet's rows (critic M51-3; None when the sheet has none, 'mixed: ...' when its rows disagree):

    extraction_precision       is_real_rule = Y among rules scored Y or N (every sampled draft, leads included)
    executable_rule_precision  among sampled rules that would COMPILE once approved (regress.compiles: a compiled
                               predicate type and a population of 'all' or one an age condition expresses - the test
                               v05's gate uses), the share that are real AND faithful_to_source. A real but unfaithful
                               rule counts against it - compiled, it produces wrong findings. A rule scored not real needs
                               no fidelity score (it already fails); a real one without one is unscored. Leads never
                               enter it. The type is the sheet's predicate_type (the predicate it shows: the engine's,
                               or with STATUSES = ["approved"] the signed one). A sheet WITHOUT predicate_type (exported
                               before 2026-10-04: rejected drafts left out, reviewers' predicates shown) yields n = 0 and
                               says why (critic M51-3). 2026-10-04 (external review)
    extraction_fidelity        faithful_to_source = Y among REAL rules scored Y or N (a rule not scored real or not, or
                               real without a fidelity score, is unscored)
    extraction_recall          real rules found / (real rules found + missed), the SECTION being the sampled unit:
                               real_rules_found = how many of the section's extracted rules are real, distinct rules it
                               states (the scorer's count; a duplicate counts once), missed_rules = the rules it states
                               that were not extracted. 2026-10-04 (external review): 'found' used to be rules_extracted -
                               EVERY draft, wrong ones included - so wrong drafts RAISED recall. A section counts only
                               when both numbers are whole numbers (never assumed), its rules_extracted is filled (so
                               real_rules_found can be checked against it) and real_rules_found does not exceed it (a
                               scoring slip). n counts rules; the interval comes from the variation between sections.
    extraction_filter_loss     DROPPED sheet: is_real_rule = Y among dropped candidates scored Y or N - real rules the
                               grounding or the post-checks threw away, a recall loss no other sheet sees. Also per drop
                               reason (scope_type 'drop_class'). No pass mark: it says which filter to look at.
    """
    rows = []
    r = scored_rules.copy() if scored_rules is not None else pd.DataFrame()
    if len(r):
        real, not_real, real_blank = _flags(r, "is_real_rule")
        faith, _unfaith, faith_blank = _flags(r, "faithful_to_source")
        typed = "predicate_type" in r.columns
        execu = _executable(r) if typed else pd.Series(False, index=r.index, dtype=bool)
        one = pd.Series(1, index=r.index, dtype=int)
        every = pd.Series(True, index=r.index, dtype=bool)
        for st, sc, g in _scopes(r, "chapter"):
            i = g.index
            blank = int(real_blank[i].sum())
            rows.append(_ratio_row("extraction_precision", st, sc, g, every[i], real[i].astype(int), one[i],
                                   ~real_blank[i], f"{blank} unscored row(s) excluded." if blank else ""))
            rows.append(_executable_row(g, st, sc, typed, "rule_population" in r.columns, execu[i], real[i],
                                        not_real[i], real_blank[i], faith[i], faith_blank[i]))
            fb, rb = int((real[i] & faith_blank[i]).sum()), int(real_blank[i].sum())
            rows.append(_ratio_row("extraction_fidelity", st, sc, g, ~not_real[i], faith[i].astype(int), one[i],
                                   real[i] & ~faith_blank[i],
                                   (f"{fb} real rule(s) without a fidelity score excluded. " if fb else "")
                                   + (f"{rb} rule(s) without is_real_rule excluded (their fidelity is unknown)."
                                      if rb else "")))
    s = scored_sections.copy() if scored_sections is not None else pd.DataFrame()
    if len(s):
        found, missed, extracted = (_num_col(s, "real_rules_found"), _num_col(s, "missed_rules"),
                                    _num_col(s, "rules_extracted"))
        both = found.notna() & missed.notna()
        # 2026-10-04 (critic M51-7): a section whose rules_extracted is blank cannot be checked against its
        # real_rules_found (the slip test below) - it was counted unchecked
        no_ext = both & extracted.isna()
        over = both & extracted.notna() & (found > extracted)
        ok = both & ~no_ext & ~over
        every = pd.Series(True, index=s.index, dtype=bool)
        no_col = "" if "real_rules_found" in s.columns else (
            "The sheet has no real_rules_found column (exported before 2026-10-04): recall cannot be computed from it - "
            "re-export. ")
        for st, sc, g in _scopes(s, "chapter"):
            i = g.index
            k, m = int(found[i][ok[i]].sum()), int(missed[i][ok[i]].sum())
            blank, n_ext, n_over = int((~both[i]).sum()), int(no_ext[i].sum()), int(over[i].sum())
            note = (f"{int(ok[i].sum())} section(s) scored; {k} real rule(s) found, {m} missed. "
                    + (f"{blank} section(s) without both real_rules_found and missed_rules excluded. " if blank else "")
                    + (f"{n_ext} section(s) excluded: rules_extracted is blank. " if n_ext else "")
                    + (f"{n_over} section(s) excluded: real_rules_found is above rules_extracted. " if n_over else "")
                    + no_col + "Sections are the sampled units: the interval comes from the variation between them.")
            rows.append(_ratio_row("extraction_recall", st, sc, g, every[i], found[i].fillna(0),
                                   (found[i] + missed[i]).fillna(0), ok[i], note))
    d = scored_dropped.copy() if scored_dropped is not None else pd.DataFrame()
    if len(d):
        real, _not_real, real_blank = _flags(d, "is_real_rule")
        d["_real"] = [True if t else (None if b else False) for t, b in zip(real, real_blank)]
        one = pd.Series(1, index=d.index, dtype=int)
        every = pd.Series(True, index=d.index, dtype=bool)
        for st, sc, g in _scopes(d, "chapter") + _scopes(d, "drop_class", pooled=False):
            i = g.index
            k, n_s, blank = int(real[i].sum()), int((~real_blank[i]).sum()), int(real_blank[i].sum())
            note = (f"{k} of {n_s} scored dropped candidate(s) are real rules the filters lost. "
                    + (f"{blank} unscored row(s) excluded. " if blank else "")
                    + (_stratum_estimate(g[~real_blank[i]]) if st == "overall" else ""))
            rows.append(_ratio_row("extraction_filter_loss", st, sc, g, every[i], real[i].astype(int), one[i],
                                   ~real_blank[i], note))
    return pd.DataFrame(rows, columns=METRIC_COLUMNS)


def _flags(df: pd.DataFrame, col: str) -> tuple[pd.Series, pd.Series, pd.Series]:
    """(yes, no, blank) masks of a Y/N score column; no such column = every row blank."""
    vals = [_yn(v) for v in df[col]] if col in df.columns else [None] * len(df)
    yes = pd.Series([v is True for v in vals], index=df.index, dtype=bool)
    no = pd.Series([v is False for v in vals], index=df.index, dtype=bool)
    return yes, no, ~(yes | no)


_OLD_LAYOUT = ("The RULES sheet has no predicate_type column (exported before 2026-10-04: rejected drafts were left out "
               "and reviewers' predicates shown), so which sampled rules are the engine's executable ones is unknown: "
               "executable-rule precision is not computed from it - re-export with v01.")


def _executable_row(g: pd.DataFrame, st: str, sc: str, typed: bool, has_pop: bool, ex: pd.Series, real: pd.Series,
                    not_real: pd.Series, real_blank: pd.Series, faith: pd.Series, faith_blank: pd.Series) -> dict:
    """executable_rule_precision for one scope (see extraction_metrics)."""
    if not typed:
        # 2026-10-04 (critic M51-3a): an old-layout sheet used to fall back to the predicate text and could say GO
        return {"metric": "executable_rule_precision", "scope_type": st, "scope": str(sc), "n": 0,
                "value": float("nan"), "ci_low": 0.0, "ci_high": 1.0, "unscored": 0, "scored_units": 0,
                "population": _stamp(g, "population"), "corpus_version": _stamp(g, "corpus_version"),
                "sample_runs": _runs_stamp(g), "notes": _OLD_LAYOUT}
    counts = not_real | (real & ~faith_blank)
    k, nr = int((ex & real & faith).sum()), int((ex & not_real).sum())
    uf = int((ex & real & ~faith & ~faith_blank).sum())
    no_real, no_faith = int((ex & real_blank).sum()), int((ex & real & faith_blank).sum())
    note = (f"{int(ex.sum())} sampled rule(s) that would compile: {k} real and faithful, {nr} not real, "
            f"{uf} real but unfaithful. "
            + (f"{no_real} without is_real_rule excluded. " if no_real else "")
            + (f"{no_faith} real rule(s) without faithful_to_source excluded. " if no_faith else "")
            + ("" if has_pop else "No rule_population column (exported before 2026-10-04): a compiled type counts as "
                                  "executable whatever its population. "))
    one = pd.Series(1, index=g.index, dtype=int)
    return _ratio_row("executable_rule_precision", st, sc, g, ex, (real & faith).astype(int), one, counts, note)


def _stratum_estimate(scored: pd.DataFrame) -> str:
    """Real rules among ALL the dropped candidates of the scored strata, estimated stratum by stratum
    (observed share x stratum_size): the number of rules the filters lose, not just the rate in the sample."""
    if not len(scored) or not {"stratum", "stratum_size"} <= set(scored.columns):
        return ""
    est = total = 0.0
    for _, g in scored.groupby(scored["stratum"].astype(str), sort=True):
        size = pd.to_numeric(g["stratum_size"], errors="coerce").max()
        if pd.isna(size):
            return ""
        est += float((g["_real"] == True).mean()) * float(size)  # noqa: E712
        total += float(size)
    return (f"Weighted by stratum size: about {est:,.0f} of the {total:,.0f} dropped candidate(s) in the scored strata "
            f"are real rules.")


# ------------------------------------------------------------------ detectors
def detector_metrics(scored_findings: pd.DataFrame | None) -> pd.DataFrame:
    """Per stratum (origin x predicate_type) and pooled:

    detector_precision        true_violation / (true_violation + false_positive)
    detector_cannot_tell_share cannot_tell / every dispositioned finding

    cannot_tell is EXCLUDED from precision (it is neither right nor wrong) but reported, because a
    high share means the evidence shown to the reviewer is not enough to decide.
    """
    rows = []
    f = scored_findings.copy() if scored_findings is not None else pd.DataFrame()
    if not len(f):
        return pd.DataFrame(rows, columns=METRIC_COLUMNS)
    disp = f["disposition"] if "disposition" in f else pd.Series([None] * len(f), index=f.index)
    f["_d"] = disp.map(lambda v: str(v).strip().lower() if isinstance(v, str) and str(v).strip() else None)
    f["_d"] = f["_d"].where(f["_d"].isin(DISPOSITIONS), None)
    if "stratum" not in f:
        f["stratum"] = (f.get("origin", pd.Series("?", index=f.index)).astype(str) + " | "
                        + f.get("predicate_type", pd.Series("?", index=f.index)).astype(str))
    for st, sc, g in _scopes(f, "stratum"):
        tv = int((g["_d"] == "true_violation").sum())
        fp = int((g["_d"] == "false_positive").sum())
        ct = int((g["_d"] == "cannot_tell").sum())
        blank = int(g["_d"].isna().sum())
        note = (f"{tv} true, {fp} false positive, {ct} cannot_tell (excluded)"
                + (f", {blank} blank/invalid (excluded)" if blank else "") + "."
                + (f" {_POOLED}." if st == "overall" else ""))
        # 2026-10-04 (critic M51-6): the drawn-but-unscored count travels with every metric row (METRIC_COLUMNS);
        # a finding sample has no extraction population or corpus stamp
        rows.append(dict(_row("detector_precision", st, sc, tv, tv + fp, note), unscored=blank,
                         scored_units=tv + fp))
        rows.append(dict(_row("detector_cannot_tell_share", st, sc, ct, tv + fp + ct,
                              "share of dispositioned findings the reviewer could not decide"), unscored=blank,
                         scored_units=tv + fp + ct))
    return pd.DataFrame(rows, columns=METRIC_COLUMNS)


# ------------------------------------------------------------------ v03: GO / NOT YET verdicts
# Each returns (ok, reason). A missing number is always NOT YET, never assumed.
def _implied_n(p: float, lo: float, z: float = 1.96, n_max: int = 1_000_000) -> int | None:
    """The sample size whose PLAIN Wilson lower bound at rate p equals `lo` - the effective sample size behind an
    interval stratified_ratio built (it puts a Wilson interval on n_eff). None when p / lo cannot say."""
    if p is None or lo is None or not (0.0 < lo < 1.0) or not (0.0 <= p <= 1.0):
        return None

    def reaches(m):
        return wilson(p * m, m, z)[1] >= lo - 1e-9

    if not reaches(n_max):
        return None
    a, b = 1, n_max
    while a < b:
        m = (a + b) // 2
        if reaches(m):
            b = m
        else:
            a = m + 1
    return a


def lower_bound_bar(m: dict | None, target: float, unit: str = "scored items",
                    missing: str = "no scored sample (run v01 and ingest)",
                    max_unscored: float | None = MAX_UNSCORED_SHARE) -> tuple[bool, str]:
    """Does a rate reach `target` at the LOWER end of its 95% interval? m = a metric row as a dict (value, ci_low,
    ci_high, n, and - since 2026-10-04 - unscored / scored_units); None or n = 0 -> NOT YET (`missing` says why). When
    it falls short, the reason says how many more scored `unit` would be needed if the observed rate held (scaled by the
    sample's design effect, n / effective n, for a stratum-weighted rate) - or that no number can, when the rate is at or
    below the bar (3 of 3 correct is a rate of 1.0 whose lower bound is 0.44: a number, not a pass).
    2026-10-04 (critic M51-6): more than `max_unscored` of the drawn units left unscored is NOT YET too - blanks leave
    the rate, so 80 scored and 20 blank used to say GO on the 80."""
    n = _int_or_none((m or {}).get("n")) or 0
    if m is None or not n:
        return False, missing
    value, lo, hi = float(m["value"]), float(m["ci_low"]), float(m["ci_high"])
    ok = lo >= target
    txt = f"{value:.3f}, 95% CI {lo:.3f}-{hi:.3f}, n={n}"
    if not ok:
        need = n_needed(value, target)
        if need is None:
            txt += " - the observed rate is at or below the bar, more samples cannot fix it"
        else:
            n_eff = _implied_n(value, lo) or n
            more = max(0, math.ceil((need - n_eff) * n / n_eff - 1e-9))
            txt += f" - about {more:,} more {unit} needed if the rate holds"
    uns = _int_or_none(m.get("unscored")) or 0
    if uns and max_unscored is not None:
        units = _int_or_none(m.get("scored_units"))
        drawn = (n if units is None else units) + uns
        if uns / drawn > max_unscored:
            ok = False
            txt += (f"; {uns} of {drawn} drawn unit(s) left unscored ({uns / drawn:.0%}, more than "
                    f"{max_unscored:.0%}): score them - the scored ones may not stand for the sample")
    return ok, txt


def _runs_problem(text: str, latest: dict) -> str | None:
    """None when every chapter a metric row's sample_runs names was measured on that chapter's CURRENT latest run
    (`latest` {chapter: run_id}, quality.latest_runs); otherwise why not, in plain words."""
    if not text:
        return "its sample_runs was not recorded (a sample exported before the run check of 2026-10-04)"
    runs = _json(text) if not text.startswith("mixed: ") else None
    if not isinstance(runs, dict) or not runs:
        return f"its sample_runs is not one run per chapter ({text[:120]})"
    bad = []
    for c in sorted(runs, key=lambda v: (len(str(v)), str(v))):
        r, now = _text(runs[c]), latest.get(str(c))
        if not r:
            bad.append(f"the run of chapter {c} it was measured on was not recorded")
        elif not now:
            bad.append(f"it was measured on run {r} of chapter {c}; chapter {c} has no successful run of its current "
                       "document version in policy_extraction_log")
        elif now != r:
            bad.append(f"it was measured on run {r} of chapter {c}; the latest run is {now}")
    return ("; ".join(bad[:3]) + (f" (and {len(bad) - 3} more chapter(s))" if len(bad) > 3 else "")) if bad else None


def metric_for_bar(metrics: pd.DataFrame | None, name: str, scope, corpus_version: str | None,
                   latest_run: dict | None = None, population: str = ENGINE_POPULATION) -> tuple[dict | None, str]:
    """(row, '') - the LATEST row of metric `name` for `scope` that a v03 bar may be judged on: drawn from `population`
    (the engine's own drafts: v01 with STATUSES = None), measured on the current corpus (`corpus_version`), on the
    current LATEST run of every chapter its sample_runs names (`latest_run` {chapter: run_id}: quality.latest_runs over
    policy_extraction_log and the current doc hashes; None = none known), with n > 0. Otherwise (None, why): what the
    latest row of that metric was measured on, and what to do.
    2026-10-04 (critic M51-3): v03 judged the latest row whatever its sample - an approved-only sample, a workbook
    exported before the population fix, or a sample of another document set could each say GO. Follow-up (same day): a
    re-extraction of the SAME corpus (04 again, e.g. with another reasoning effort) left the older run's sample
    judgeable, so a GO could describe an engine output that is no longer current; a row without sample_runs (exported
    before this check) is not judgeable either."""
    if metrics is None or not len(metrics) or not {"metric", "scope"} <= set(metrics.columns):
        return None, f"no {name} row"
    m = metrics[(metrics["metric"].astype(str) == name) & (metrics["scope"].astype(str) == str(scope))]
    if not len(m):
        return None, f"no {name} row for {scope}"
    if "computed_at" in m.columns:
        m = m.assign(_t=_text_col(m, "computed_at")).sort_values("_t", kind="mergesort").drop(columns="_t")
    pop, cv = _text_col(m, "population"), _text_col(m, "corpus_version")
    n = pd.Series([_int_or_none(v) or 0 for v in (m["n"] if "n" in m.columns else [0] * len(m))], index=m.index)
    want = _text(corpus_version)
    if not want:
        return None, "the current corpus_version is unknown (no document inventory), so no metric can be tied to it"
    latest = {str(k).strip(): _text(v) for k, v in (latest_run or {}).items() if _text(v)}
    runs_why = pd.Series([_runs_problem(t, latest) for t in _text_col(m, "sample_runs")], index=m.index, dtype=object)
    ok = (pop == population) & (cv == want) & (n > 0) & runs_why.isna()
    if ok.any():
        return m[ok].iloc[-1].to_dict(), ""
    last = m.iloc[-1]
    lp, lc, ln, lr = pop.iloc[-1], cv.iloc[-1], int(n.iloc[-1]), runs_why.iloc[-1]
    why = []
    if lp != population:
        why.append(f"it was drawn from population {lp!r}, not the engine's own drafts ({population!r}: v01 with "
                   f"STATUSES = None)" if lp else "its population was not recorded (a sample exported before 2026-10-04)")
    if lc != want:
        why.append(f"it was measured on corpus {lc}, the current corpus is {want}" if lc else
                   "its corpus_version was not recorded (a sample exported before 2026-10-04)")
    if lr is not None:
        why.append(lr)
    if not ln:
        notes = _text(last.get("notes"))
        why.append("n = 0" + (f": {notes[:300]}" if notes else ""))
    sid = _text(last.get("sample_id"))
    return None, (f"the latest {name} row" + (f" (sample {sid})" if sid else "") + " cannot be judged: "
                  + "; ".join(why) + " - re-export v01 (STATUSES = None) on the current corpus and latest runs, score it "
                  "and ingest it")


def run_completeness(rows: pd.DataFrame | None) -> tuple[int, list[str]]:
    """(detector errors, problems) of ONE detector run's policy_detector_runs rows; no problem = complete.
    2026-10-04 (critic M51-8): 08 stores the run's snapshot numbers as JSON in the `error` column of its 'RUN:snapshot'
    row, and v03 counted it as a detector error, so every run read NOT YET; RUN: rows are not detectors (08 counts its
    errors the same way). A run with partial_run True - a switch off, a row cap, or NCCI held back for unsigned routing -
    is not complete, and the reason is the `skipped` column of the queries it did not run: named here."""
    r = rows if rows is not None else pd.DataFrame()
    if not len(r):
        return 0, ["the run recorded no detector rows"]
    rid, err, sk = _text_col(r, "rule_id"), _text_col(r, "error"), _text_col(r, "skipped")
    det = ~rid.str.startswith("RUN:")
    errors = int((det & (err != "")).sum())
    problems = [f"{errors} detector error(s)"] if errors else []
    if "partial_run" in r.columns and any(_yn(v) is True for v in r["partial_run"]):
        reasons: dict = {}
        for q, s in zip(rid[det], sk[det]):
            if s:
                reasons.setdefault(s, []).append(q or "(no rule_id)")
        if reasons:
            problems.append("partial run: " + "; ".join(
                f"{', '.join(qs[:4])}{' ...' if len(qs) > 4 else ''} {why}" for why, qs in reasons.items()))
        else:
            problems.append("partial run: a part of the build was not run on purpose (08's RUN_NCCI_BATCH / RUN_STATE "
                            "switched off, or MAX_ROWS_PER_DETECTOR set); no query records why in `skipped`")
    return errors, problems


def routing_bar(uses_table: bool, summary: dict | None, observed, unsigned, kind: str | None = None) -> tuple[bool, str]:
    """NCCI routing (provider type -> CMS TGM Table 2 row) signed: GO only when routing is by provider type through the
    table, every provider type code 08 checks on a CMS-1500 / UB-04 line has a signed row (`unsigned` =
    ncci_routing.unsigned_observed(observed) is empty) and the routing kind is 'signed' (`kind` =
    run_guard.ncci_routing_kind(observed), the word 08 stamps on every NCCI finding). observed = the codes 08 checks
    (ncci_routing.observed_types_sql): the servicing type, plus the billing type only when routing by billing type -
    2026-10-04 (critic M51-9: v03 read both in every mode). kind 'form_fallback' (a line whose types the table does not
    map is routed by its claim form) is NOT YET whatever the table says. observed / unsigned None = the claims could not
    be read; kind None = not given (judged on observed / unsigned alone).
    2026-10-04: v03 compared summary()['mode'] with 'provider_type', so once the default became 'billing_provider_type'
    the bar always read "routing by claim form only"."""
    if not uses_table or kind == "form_only":
        return False, "routing by claim form only (config.NCCI_ROUTE_BY = 'form'): provider type ignored"
    s = summary or {}
    which = "billing or servicing" if s.get("mode") == "billing_provider_type" else "servicing"
    tail = (f"routing by {s.get('mode')}; {s.get('types_signed')} of {s.get('types_mapped')} provider types signed in "
            f"{s.get('table')}; optional Table 2 rows on: {', '.join(s.get('optional_on') or []) or 'none'}")
    if observed is None or unsigned is None:
        return False, f"the provider types on the claims could not be read, so the bar cannot be judged; {tail}"
    obs = sorted({_text(c) for c in observed} - {""})
    if not obs:
        return False, (f"no {which} provider type code observed on a CMS-1500 / UB-04 line (no such lines, or no provider "
                       f"type column), so nothing shows the table covers the claims; {tail}")
    uns = sorted({_text(c) for c in unsigned} - {""})
    if uns:
        return False, (f"{len(uns)} of {len(obs)} provider type code(s) observed on CMS-1500 / UB-04 lines ({which}) "
                       f"have no signed routing row, e.g. {', '.join(uns[:10])}; {tail}"
                       + ("; 08 runs no NCCI statement until they are signed (config.NCCI_REQUIRE_SIGNED_ROUTING)"
                          if s.get("require_signed") else
                          "; config.NCCI_REQUIRE_SIGNED_ROUTING = False: NCCI findings rest on an unsigned reading"))
    if kind == "form_fallback":
        return False, (f"config.NCCI_UNMAPPED_PROVIDER_TYPE = 'form': a line whose provider types the table does not map "
                       f"is routed by its claim form - a reading nobody signed (all {len(obs)} {which} provider type "
                       f"code(s) observed are signed); {tail}")
    if kind is not None and kind != "signed":
        return False, f"the routing is {kind!r}, not 'signed' (run_guard.ncci_routing_kind); {tail}"
    return True, (f"all {len(obs)} provider type code(s) observed on CMS-1500 / UB-04 lines ({which}) have a signed "
                  f"row; {tail}")


def tables_stale_vs_claims(versions: dict | None, claims_to, max_age_days: dict | None) -> dict:
    """{table_key: {newest_version, max_age_days, stale_after, claims_to}} for every AHCCCS rule table whose claims run
    PAST its newest version's date + max_age_days[key] days (2026-10-04, v5.2b, critic F12): a version stays in force
    until the next one is loaded, so past that age the claims are judged by a table AHCCCS has probably replaced (B2 is
    published monthly; the daily limits report carries a run date). A warning, as 07's NCCI_STALE - never an error.
    versions = {table_key: [version dates]} of the LOADED tables; claims_to = the claims' last date of service (ISO) or
    None (nothing to judge); a table with no max age configured (config.AHCCCS_TABLE_MAX_AGE_DAYS) is never stale.
    stale_after = the last day the newest version is taken as current: claims dated on it are not past it."""
    from datetime import date, timedelta
    to = _text(claims_to)[:10]
    out: dict = {}
    if not to:
        return out
    for key, vds in sorted((versions or {}).items()):
        n = (max_age_days or {}).get(key)
        ds = sorted({_text(v)[:10] for v in (vds or [])} - {""})
        if n is None or not ds:
            continue
        after = (date.fromisoformat(ds[-1]) + timedelta(days=int(n))).isoformat()
        if to > after:
            out[key] = {"newest_version": ds[-1], "max_age_days": int(n), "stale_after": after, "claims_to": to}
    return out


def stale_tables_text(stale: dict | None) -> str:
    """tables_stale_vs_claims as one line for a person (07's warning, v03's corpus row); '' when nothing is stale."""
    return "; ".join(f"{k} (newest version {s.get('newest_version')} + {s.get('max_age_days')} days = "
                     f"{s.get('stale_after')}; claims run to {s.get('claims_to')})"
                     for k, s in sorted((stale or {}).items()) if isinstance(s, dict))


def corpus_bar(current_doc_hash: dict | None, chapters, pending: dict | None, version: str,
               loaded_tables: dict | None = None, stale_tables: dict | None = None) -> tuple[bool, str]:
    """Corpus frozen and complete for its STATED scope (CORPUS_SCOPE). Frozen: `version` names the exact document set
    (policy_docs.corpus_version over the latest doc_hash of each document), so a rate measured on it has an unambiguous
    denominator. Complete: every document of `chapters` (config.CHAPTERS) is ingested AND no rule source of
    config.CORPUS_PENDING is still to load (listed by name). 2026-10-04 (critic M51-11): the reason called those sources
    "in-scope" and then put "other federal edits" outside the scope in the same sentence, while one of them is CMS's
    Medicaid NCCI files; it now says plainly what is still to load and which authorities this corpus does not hold.
    2026-10-04 (v5.2): loaded_tables = ahcccs_tables.loaded_versions(log) ({table_key: [{version_date, ...}]}): an
    AHCCCS rule table 00b loaded is part of the corpus (the caller passes a `version` that includes its file hashes,
    ahcccs_tables.corpus_entries) and leaves the "still to load" list - a CORPUS_PENDING key IS the table key.
    2026-10-04 (v5.2b, critic F12): stale_tables = the build log's ahcccs_stale_vs_claims (tables_stale_vs_claims): the
    tables whose claims run past the newest version's max age are named next to the loaded tables - shown, not judged
    (a newer version is a load away; the verdict stays the corpus's completeness)."""
    cur = {str(k).strip() for k, v in (current_doc_hash or {}).items() if _text(v)}
    want = [str(c) for c in (chapters or [])]
    missing = [c for c in want if c not in cur]
    extra = sorted(cur - set(want), key=lambda v: (len(v), v))
    tables = {str(k): sorted({_text(v.get("version_date") if isinstance(v, dict) else v) for v in (vs or [])} - {""})
              for k, vs in (loaded_tables or {}).items()}
    tables = {k: vs for k, vs in tables.items() if vs}
    pend = [str(p) for p in (pending or {}) if str(p) not in tables]
    ok = bool(want) and not missing and not pend
    return ok, (f"scope: {CORPUS_SCOPE}; corpus {version}; {len(want) - len(missing)} of {len(want)} documents ingested"
                + (f" (missing {', '.join(missing)})" if missing else "")
                + (f"; {len(extra)} other document(s) in the inventory ({', '.join(extra[:5])})" if extra else "")
                + (f"; {len(tables)} AHCCCS rule table(s) loaded: "
                   + ", ".join(f"{k} ({', '.join(vs)})" for k, vs in sorted(tables.items())) if tables else "")
                + (f"; the claims run past the newest version's max age (config.AHCCCS_TABLE_MAX_AGE_DAYS) of "
                   f"{stale_tables_text(stale_tables)}" if stale_tables_text(stale_tables) else "")
                + (f"; {len(pend)} rule source(s) still to load before the corpus is complete (config.CORPUS_PENDING): "
                   f"{', '.join(pend)}" if pend else "")
                + ". Not part of this corpus: the AMPM and the fee schedule.")


# 2026-10-04 (v5.2b, critic F9): rules read from the AHCCCS rule tables (detector_gen.TABLE_ORIGIN) carry no reviewer of
# their own - a table's rules are signed through its readings (reference/ahcccs_table_readings.csv,
# ahcccs_tables.table_compiles) - and the table each kind of table rule comes from (ahcccs_tables builds exactly these)
AHCCCS_TABLE_ORIGIN = "ahcccs_table"
AHCCCS_TABLE_OF_PREDICATE = {"code_pair_prohibited": "same_day_disallow", "max_units_per_day": "daily_limits",
                             "provider_type_allowed": "b2_matrix"}


def _table_rows(compiled_state: pd.DataFrame | None) -> pd.Series:
    """Which rows of a compiled-state frame are AHCCCS table rules (origin 'ahcccs_table')."""
    if compiled_state is None or not len(compiled_state):
        return pd.Series(dtype=bool)
    return _text_col(compiled_state, "origin") == AHCCCS_TABLE_ORIGIN


def signoff_bar(compiled_state: pd.DataFrame | None) -> tuple[bool, str]:
    """Every EXECUTABLE state rule signed by a named reviewer: each compiled state rule of the current build (one row
    per rule: rule_id, review_status, reviewer - policy_detectors joined to policy_rules) is 'approved' with a reviewer's
    name. A hand-authored seed compiling unsigned (config.COMPILE_LEGACY_SEEDS = True: legacy_hand_authored, no reviewer)
    is NOT YET; so is a build that compiles no state rule (nothing to stand on).
    2026-10-04 (v5.2b, critic F9): an AHCCCS table rule (origin 'ahcccs_table', review_status 'state_table') is NOT a
    state rule lacking a reviewer - it is signed through its table's readings, which table_readings_bar judges (v03
    shows both in one bar). Before, every TBL- rule was listed as unsigned and the bar could never be GO."""
    if compiled_state is None or not len(compiled_state):
        return False, "the current build compiles no state rule"
    tab = _table_rows(compiled_state)
    n_tab = int(tab.sum())
    note = (f" ({n_tab} AHCCCS table rule(s) not counted here: a table's rules are signed through its readings)"
            if n_tab else "")
    rules = compiled_state[~tab.to_numpy(bool)]
    if not len(rules):
        return True, (f"no extracted or hand-authored state rule compiles; the {n_tab} compiled state rule(s) are "
                      f"AHCCCS table rules, signed through their table's readings")
    st, rev, rid = (_text_col(rules, c) for c in ("review_status", "reviewer", "rule_id"))
    signed = (st == "approved") & (rev != "")
    bad = [r or "(no rule_id)" for r in rid[~signed]]
    legacy = int((st == "legacy_hand_authored").sum())
    if not bad:
        return True, (f"all {len(rules)} compiled state rule(s) approved by a named reviewer "
                      f"({rev.nunique()} reviewer(s))" + note)
    return False, (f"{len(bad)} of {len(rules)} compiled state rule(s) lack a named reviewer's approval"
                   + (f" ({legacy} hand-authored seed(s) compile unsigned: config.COMPILE_LEGACY_SEEDS = True)"
                      if legacy else "")
                   + f", e.g. {', '.join(bad[:5])}" + note)


def table_readings_bar(compiled_state: pd.DataFrame | None, tables: dict | None) -> tuple[bool, str]:
    """The AHCCCS table rules' half of the sign-off bar (2026-10-04, v5.2b, critic F9): a table's rules are signed
    through its readings, not rule by rule. compiled_state as signoff_bar (its 'ahcccs_table' rows are counted per table
    by predicate type, AHCCCS_TABLE_OF_PREDICATE); tables = {table_key: {"signed": bool, "reason": str}} for every
    LOADED table (v03: ahcccs_tables.table_compiles per table of the load log; signed = it compiles AND no reading is unsigned,
    so a build with config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS off is not taken as signed).
    -> (ok, why): NOT YET when a table's rules compile in this build while its readings are not signed, or when the
    build holds table rules of a table with no readings status; a loaded table held back (unsigned, no rule compiled)
    is stated, never a failure - nothing of it executes. why = '' when no table is loaded and no table rule compiles."""
    tables = tables or {}
    tab = _table_rows(compiled_state)
    n_by = {}
    if len(tab) and tab.any():
        kinds = _text_col(compiled_state[tab.to_numpy(bool)], "predicate_type")
        for k in kinds:
            key = AHCCCS_TABLE_OF_PREDICATE.get(k, f"(unknown table: {k or 'no predicate type'})")
            n_by[key] = n_by.get(key, 0) + 1
    if not tables and not n_by:
        return True, ""
    parts, bad = [], []
    for key in sorted(set(tables) | set(n_by)):
        n, t = n_by.get(key, 0), tables.get(key)
        if t is None:
            parts.append(f"{key}: {n} rule(s) compiled, but no readings status (the table is not in the load log)")
            bad.append(key)
            continue
        why = _text(t.get("reason")) or key
        if t.get("signed"):
            parts.append(f"{why}; {n} rule(s) compiled")
        elif n:
            parts.append(f"{why}; {n} rule(s) compiled UNSIGNED")
            bad.append(key)
        else:
            parts.append(f"{why}; held back: no rule compiled")
    return not bad, ("AHCCCS rule tables (signed through their readings, not rule by rule): " + " | ".join(parts)
                     + (f" - NOT YET for {', '.join(bad)}" if bad else ""))


def corpus_differences(a: dict | None, b: dict | None, la: str = "A", lb: str = "B") -> list[str]:
    """Where two {document id: sha256} sets disagree: another version of a document, or a document one side lacks."""
    a = {str(k): _text(v) for k, v in (a or {}).items() if _text(v)}
    b = {str(k): _text(v) for k, v in (b or {}).items() if _text(v)}
    out = []
    for c in sorted(set(a) | set(b), key=lambda v: (len(v), v)):
        if c not in b:
            out.append(f"{c} only in {la}")
        elif c not in a:
            out.append(f"{c} only in {lb}")
        elif a[c] != b[c]:
            out.append(f"{c}: {la} {a[c][:12]} vs {lb} {b[c][:12]}")
    return out


# ------------------------------------------------------------------ workbooks
XLSX_CELL_MAX = 32_000          # Excel refuses cells over 32,767 characters


def _is_blank(v) -> bool:
    if v is None:
        return True
    if isinstance(v, str):
        return not v.strip()
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def clip_text(v, limit: int = XLSX_CELL_MAX):
    """Cut long text so a workbook cell can hold it; says so in the cell."""
    if _is_blank(v):
        return None
    s = str(v)
    return s if len(s) <= limit else s[: limit - 40] + f" ...[cut: {len(s):,} chars total]"


def xlsx_write_sheets(sheets: dict, path: str) -> str:
    """Several sheets in one workbook, Volume-safe the same way as state_rules._xlsx_write (which
    writes one sheet): openpyxl seeks while writing, which a UC Volume (FUSE) rejects, so write to
    local disk and then copy sequentially. Returns where the file actually is."""
    import os
    import shutil
    import tempfile
    # a PRIVATE staging file (2026-10-03: <tmp>/<basename> was shared by every process on the machine)
    fd, local = tempfile.mkstemp(prefix="pie_", suffix="_" + os.path.basename(path))
    os.close(fd)
    with pd.ExcelWriter(local, engine="openpyxl") as xw:
        for name, df in sheets.items():
            df.to_excel(xw, sheet_name=str(name)[:31], index=False)
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        shutil.copyfile(local, path)
    except OSError as e:
        print(f"  could not copy workbook to {path} ({e}); it is at {local}")
        return local
    os.remove(local)
    return path


def xlsx_read_sheets(path: str) -> dict:
    """{sheet name: DataFrame}; falls back to a local copy when the path is on a Volume."""
    import os
    import shutil
    import tempfile
    try:
        return pd.read_excel(path, sheet_name=None, engine="openpyxl")
    except OSError:
        fd, local = tempfile.mkstemp(prefix="pie_read_", suffix="_" + os.path.basename(path))
        os.close(fd)
        try:
            shutil.copyfile(path, local)
            return pd.read_excel(local, sheet_name=None, engine="openpyxl")
        finally:
            os.remove(local)


def as_text_frame(df: pd.DataFrame, keep_numeric: tuple = ()) -> pd.DataFrame:
    """Every column as text (None for blanks) except `keep_numeric`. Appending a workbook whose
    column happens to be all-blank would otherwise create the table column as DOUBLE and make the
    next append fail on a type conflict (the policy_review_log bug, 2026-09)."""
    out = df.copy()
    for c in out.columns:
        if c in keep_numeric:
            out[c] = pd.to_numeric(out[c], errors="coerce").astype(float)
        else:
            out[c] = [None if _is_blank(v) else str(v) for v in out[c]]
            out[c] = out[c].astype(object)
    return out
