"""
gap.py  -  claims-weighted coverage and gap analysis.

The OIG question is "which PAID codes have no governing rule?" - so the gap
table starts from what was actually paid and weights every code by exposure.
No rule + $8M paid is a finding; no rule + $0 paid is noise. The PoC's
'risk' column was derived from rule presence alone (circular) and carried
editorial strings; both are gone.

One row per (paid code, claim form, NCCI edit file). A line takes one NCCI edit file - by provider type and
claim form (CMS TGM s6.0 Table 2; ncci_routing.py) - or none (dental, pharmacy, inpatient, residential, an optional
provider type not switched on), so a federal edit only covers the dollars a code was paid on lines of ITS edit
file; state rules cover every line.

A rule covers only the paid dollars of lines dated INSIDE its own window (2026-10-04, v5.2b, critic F10). Before, a
rule counted for every dollar of its code: an AHCCCS table version dated 2026-10-01 'covered' two years of older
claims, and the gap table went empty. The window test runs in Spark, where the claim lines are (17M on Databricks):
rule_windows() turns the live rules into a small table of (kind, code, edit file, effective date, end date) - merged
per code, so a few rows per code whatever the number of rules - which exposure_by_code() broadcasts to the lines.
Per row it adds the paid dollars and lines dated inside the window of a live state rule (every origin but NCCI,
the AHCCCS table rules included), of a live federal rule (NCCI, of the line's edit file) and of either:
paid_dollars_state_window / paid_dollars_federal_window / paid_dollars_any_window, lines_*_window.

coverage values (D7, 2026-09-29: counted from COMPILED detectors - a review lead or an uncompiled rule is not
coverage; v5.2b: and only inside the rule's own date window):
  both          some of the row's paid dollars lie inside the window of a live NCCI rule AND of a live state rule
  federal_only  inside a live NCCI rule's window only
  state_only    inside a live state rule's window only
  none          no paid dollar of the row lies inside a live rule's window (state_leads says whether policy text exists)
A row whose paid dollars are all outside every state rule's window is not state-covered, whatever rules its code
has. ncci_rules / state_rules still count the live rules on the code whose window overlaps the claims period.
"""
from __future__ import annotations

import uuid
from datetime import date, timedelta

import pandas as pd

WINDOW_COLUMNS = ["kind", "code", "edition", "effective_date", "end_date"]
DATED_COLUMNS = ["paid_dollars_state_window", "paid_dollars_federal_window", "paid_dollars_any_window",
                 "lines_state_window", "lines_federal_window", "lines_any_window"]
COVERAGE_COLUMNS = ["code", "form_typ", "ncci_edition", "coverage", "ncci_rules", "state_rules", "state_leads", "lines",
                    "units", "paid_dollars"] + DATED_COLUMNS
CLASSES = ("both", "federal_only", "state_only", "none")


def _paid_col(spark, claims: str, candidates=("PMT_AMT", "PAID_AMT", "AMT_PAID", "PAID_AMOUNT")) -> str | None:
    cols = {c.upper(): c for c in spark.table(claims).columns}
    for c in candidates:
        if c.upper() in cols:
            return cols[c.upper()]
    return None


# ------------------------------------------------------------------ the live rules' windows (v5.2b)
def _iso(v) -> str | None:
    """A rule date as ISO yyyy-mm-dd; None when there is none (an open end) or it cannot be read (a compiled rule always
    has ISO dates: detector_gen refuses any other)."""
    if v is None or (isinstance(v, float) and v != v):
        return None
    try:
        return date.fromisoformat(str(v).strip()[:10]).isoformat()
    except ValueError:
        return None


def _edition(rule: dict) -> str | None:
    return str((rule.get("predicate") or {}).get("ncci_edition") or "").strip().lower() or None


def _merge(spans: list) -> list:
    """[(effective, end)] (ISO text, None = open) -> the same days as sorted, disjoint windows; windows that overlap or
    touch (one ends the day before the next starts) become one."""
    out: list = []
    for eff, end in sorted(spans, key=lambda s: s[0] or ""):
        if out:
            p_eff, p_end = out[-1]
            if p_end is None or eff is None or \
                    eff <= (date.fromisoformat(p_end) + timedelta(days=1)).isoformat():
                out[-1] = (p_eff, None if p_end is None or end is None else max(p_end, end))
                continue
        out.append((eff, end))
    return out


def rule_windows(rules: list[dict], detectors: list[dict] | None = None) -> pd.DataFrame:
    """The date windows of the LIVE rules (compiled, when detectors are given), merged per (kind, code, edition):
    kind 'state' (every origin but NCCI - extracted, hand-authored, AHCCCS table rules) with edition None (a state rule
    judges every line), kind 'federal' (NCCI) with the rule's edit file (None = no edition: counts on every line, as in
    coverage_from_exposure). Columns WINDOW_COLUMNS; dates ISO text, None = open. A few rows per code, however many
    rules: the table exposure_by_code broadcasts to the claim lines."""
    compiled = None if detectors is None else {d["rule_id"] for d in detectors if d.get("compiled")}
    spans: dict = {}
    for r in rules or []:
        if compiled is not None and r.get("rule_id") not in compiled:
            continue
        eff, end = _iso(r.get("effective_date")), _iso(r.get("end_date"))
        if eff and end and end < eff:
            continue                                      # an empty window covers nothing
        fed = r.get("origin") == "ncci"
        key_kind, ed = ("federal", _edition(r)) if fed else ("state", None)
        for c in r.get("codes") or []:
            c = str(c).strip().upper()
            if c:
                spans.setdefault((key_kind, c, ed), []).append((eff, end))
    rows = [(k, c, ed, eff, end)
            for (k, c, ed), ss in sorted(spans.items(), key=lambda kv: (kv[0][0], kv[0][1], kv[0][2] or ""))
            for eff, end in _merge(ss)]
    return pd.DataFrame(rows, columns=WINDOW_COLUMNS).astype(object)


def _windows_frame(spark, windows: pd.DataFrame):
    """The window table as a Spark DataFrame with fixed types (dates as DATE)."""
    from pyspark.sql import types as T
    schema = T.StructType([T.StructField("kind", T.StringType()), T.StructField("code", T.StringType()),
                           T.StructField("edition", T.StringType()), T.StructField("effective_date", T.DateType()),
                           T.StructField("end_date", T.DateType())])

    def d(v):
        v = _iso(v)
        return None if v is None else date.fromisoformat(v)

    def s(v):
        return None if v is None or (isinstance(v, float) and v != v) or str(v).strip() == "" else str(v).strip()
    rows = [(s(k), s(c), (s(e) or "").lower() or None, d(f), d(t))
            for k, c, e, f, t in windows[WINDOW_COLUMNS].itertuples(index=False)]
    return spark.createDataFrame(rows, schema)


def dated_exposure_sql(src: str, windows: str, paid_col: str | None, units_col: str, proc_col: str, dos_col: str,
                       form_expr: str, ed_expr: str) -> str:
    """exposure_by_code's statement with the window test: the claim lines are first summed per (code, form, edit file,
    date of service), each such day is matched to the BROADCAST window table on its code (a federal window only on its
    own edit file, or on every line when it has none; a line with no date of service is inside no window), and its
    lines / dollars count once whatever the number of windows it falls in. Dates: CAST(dos AS DATE), the snapshot's."""
    paid = f"SUM({paid_col})" if paid_col else "CAST(NULL AS DOUBLE)"

    def dollars(flag):
        return f"SUM(CASE WHEN {flag} THEN paid_dollars ELSE 0 END)" if paid_col else "CAST(NULL AS DOUBLE)"
    return f"""WITH d AS (
  SELECT UPPER(TRIM({proc_col})) AS code, {form_expr} AS form_typ, {ed_expr} AS ncci_edition,
         CAST({dos_col} AS DATE) AS dos, COUNT(*) AS lines, SUM({units_col}) AS units, {paid} AS paid_dollars
  FROM {src} rc
  WHERE {proc_col} IS NOT NULL
  GROUP BY 1, 2, 3, 4
),
j AS (
  SELECT /*+ BROADCAST(w) */ d.code, d.form_typ, d.ncci_edition, d.dos,
         MAX(d.lines) AS lines, MAX(d.units) AS units, MAX(d.paid_dollars) AS paid_dollars,
         MAX(CASE WHEN w.kind = 'state' THEN 1 ELSE 0 END) AS in_state,
         MAX(CASE WHEN w.kind = 'federal' THEN 1 ELSE 0 END) AS in_federal
  FROM d LEFT JOIN {windows} w
    ON w.code = d.code AND d.dos IS NOT NULL
   AND (w.kind = 'state' OR w.edition IS NULL OR w.edition = d.ncci_edition)
   AND (w.effective_date IS NULL OR d.dos >= w.effective_date)
   AND (w.end_date IS NULL OR d.dos <= w.end_date)
  GROUP BY d.code, d.form_typ, d.ncci_edition, d.dos
)
SELECT code, form_typ, ncci_edition, SUM(lines) AS lines, SUM(units) AS units, SUM(paid_dollars) AS paid_dollars,
       {dollars("in_state = 1")} AS paid_dollars_state_window,
       {dollars("in_federal = 1")} AS paid_dollars_federal_window,
       {dollars("in_state = 1 OR in_federal = 1")} AS paid_dollars_any_window,
       SUM(CASE WHEN in_state = 1 THEN lines ELSE 0 END) AS lines_state_window,
       SUM(CASE WHEN in_federal = 1 THEN lines ELSE 0 END) AS lines_federal_window,
       SUM(CASE WHEN in_state = 1 OR in_federal = 1 THEN lines ELSE 0 END) AS lines_any_window
FROM j
GROUP BY 1, 2, 3"""


def exposure_by_code(spark, claims: str, paid_col: str | None = None,
                     units_col: str | None = None, proc_col: str | None = None,
                     windows: pd.DataFrame | None = None) -> pd.DataFrame:
    """Lines, units and paid dollars per (code, form, NCCI edit file). windows (rule_windows) adds the dated columns
    (DATED_COLUMNS): the dollars / lines inside the live rules' windows, computed in Spark against the window table
    broadcast to the lines - nothing but the per-row sums comes back to pandas."""
    import config
    units_col = units_col or config.CLAIM_COLS["units"]          # was hard-coded (config.py forbids it)
    proc_col = proc_col or config.CLAIM_COLS["code"]
    cols = {c.upper() for c in spark.table(claims).columns}
    if paid_col and paid_col.upper() not in cols:
        print(f"  gap: configured paid column {paid_col!r} not in {claims}; auto-detecting")
        paid_col = None
    paid_col = paid_col or _paid_col(spark, claims)
    paid_expr = f"SUM({paid_col}) AS paid_dollars" if paid_col else "CAST(NULL AS DOUBLE) AS paid_dollars"
    if not paid_col:
        print("  gap: no paid-amount column found; ranking by line volume only "
              "(set PAID_COL in the notebook to fix)")
    import ncci_routing
    form_col = config.CLAIM_COLS.get("form")
    form_expr = f"UPPER(TRIM(CAST({form_col} AS STRING)))" if form_col and form_col.upper() in cols else "''"
    ed_expr = ncci_routing.PIE_EDITION if form_expr != "''" else "CAST(NULL AS STRING)"
    src = ncci_routing.routed_sql(claims, config.CLAIM_COLS, cols={str(x).upper() for x in cols})
    if windows is None:
        df = spark.sql(f"""
        SELECT UPPER(TRIM({proc_col})) AS code,
               {form_expr}             AS form_typ,
               {ed_expr}               AS ncci_edition,
               COUNT(*)                AS lines,
               SUM({units_col})        AS units,
               {paid_expr}
        FROM {src} rc
        WHERE {proc_col} IS NOT NULL
        GROUP BY 1, 2, 3
    """).toPandas()
    else:
        view = f"pie_coverage_windows_{uuid.uuid4().hex[:12]}"
        _windows_frame(spark, windows).createOrReplaceTempView(view)
        try:
            df = spark.sql(dated_exposure_sql(src, view, paid_col, units_col, proc_col, config.CLAIM_COLS["dos"],
                                              form_expr, ed_expr)).toPandas()
        finally:
            try:
                spark.catalog.dropTempView(view)
            except Exception:                                    # a view that is gone already is no failure
                pass
        for c in DATED_COLUMNS:
            df[c] = pd.to_numeric(df[c], errors="coerce").astype(float)
    # Spark DECIMAL sums arrive as Python Decimal objects; make them plain floats
    df["units"] = pd.to_numeric(df["units"], errors="coerce").astype(float)
    df["paid_dollars"] = pd.to_numeric(df["paid_dollars"], errors="coerce").astype(float)
    df["lines"] = df["lines"].astype("int64")
    return df


def _overlaps(r: dict, window) -> bool:
    if not window:
        return True
    lo, hi = window
    eff, end = r.get("effective_date"), r.get("end_date")
    return not ((end and lo and str(end)[:10] < str(lo)[:10]) or (eff and hi and str(eff)[:10] > str(hi)[:10]))


def _num(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(float("nan"), index=df.index, dtype=float)
    return pd.to_numeric(df[col], errors="coerce").astype(float)


def _dated(cov: pd.DataFrame, what: str = "paid_dollars") -> bool:
    """Does the frame carry the window columns of `what` (paid_dollars / lines), with values (exposure_by_code with
    windows)?"""
    cs = [f"{what}_{k}_window" for k in ("state", "federal", "any")]
    return all(c in cov.columns for c in cs) and bool(cov[cs].notna().any().any())


def coverage_from_exposure(exp: pd.DataFrame, rules: list[dict], detectors: list[dict] | None = None,
                           claims_window: tuple | None = None) -> pd.DataFrame:
    """Pure part of coverage_table (testable without Spark). `exp` has one row per code, or per
    (code, form_typ, ncci_edition); an NCCI rule counts only on lines of its own edit file
    (predicate['ncci_edition']). When `exp` carries the dated columns (exposure_by_code with windows) the categorical
    coverage is dated (v5.2b): state-covered only when some of the row's paid dollars lie inside a live state rule's
    window (with no paid amounts: some lines), federal likewise; without them, by rule presence as before."""
    compiled = None if detectors is None else {d["rule_id"] for d in detectors if d.get("compiled")}
    ncci: dict[tuple, int] = {}          # (code, edition or None) -> rules
    state: dict[str, int] = {}
    leads: dict[str, int] = {}
    for r in rules:
        is_live = (compiled is None or r.get("rule_id") in compiled) and _overlaps(r, claims_window)
        is_ncci = r.get("origin") == "ncci"
        if not is_live and is_ncci:
            continue
        ed = _edition(r)
        for c in (r.get("codes") or []):
            c = str(c).strip().upper()
            if is_ncci:
                ncci[(c, ed)] = ncci.get((c, ed), 0) + 1
            else:
                bucket = state if is_live else leads
                bucket[c] = bucket.get(c, 0) + 1
    exp = exp.copy()
    if "form_typ" not in exp.columns:
        exp["form_typ"] = ""
    if "ncci_edition" not in exp.columns:
        exp["ncci_edition"] = None
    exp["form_typ"] = exp["form_typ"].fillna("").astype(str).str.strip().str.upper()
    exp["ncci_edition"] = exp["ncci_edition"].map(lambda v: None if v is None or (isinstance(v, float) and v != v)
                                                  or str(v).strip() == "" else str(v).strip().lower())
    for c in DATED_COLUMNS:
        exp[c] = _num(exp, c)

    def _n(row):
        # a line with no edit file takes no NCCI rule with an edition; a rule with no edition (old build / tests)
        # counts everywhere
        ed = row["ncci_edition"]
        return (ncci.get((row["code"], ed), 0) if ed else 0) + ncci.get((row["code"], None), 0)
    exp["ncci_rules"] = exp.apply(_n, axis=1).astype(int) if len(exp) else pd.Series(dtype=int)
    exp["state_rules"] = exp["code"].map(state).fillna(0).astype(int)
    exp["state_leads"] = exp["code"].map(leads).fillna(0).astype(int)

    def _inside(row, kind):
        """Some of the row's paid dollars (no paid amounts: lines) lie inside a live `kind` rule's window; None = the
        exposure is not dated (rule presence decides, as before v5.2b)."""
        d, n = row[f"paid_dollars_{kind}_window"], row[f"lines_{kind}_window"]
        if d == d:
            return d > 0
        if n == n:
            return n > 0
        return None

    def _cov(row):
        fd, sd = _inside(row, "federal"), _inside(row, "state")
        n = row["ncci_rules"] > 0 and fd is not False
        s_ = row["state_rules"] > 0 and sd is not False
        return "both" if n and s_ else "federal_only" if n else "state_only" if s_ else "none"

    exp["coverage"] = exp.apply(_cov, axis=1) if len(exp) else pd.Series(dtype=str)
    sort_cols = ["paid_dollars", "lines"] if exp["paid_dollars"].notna().any() else ["lines"]
    exp = exp.sort_values(sort_cols, ascending=False).reset_index(drop=True)
    return exp[COVERAGE_COLUMNS]


def coverage_table(spark, rules: list[dict], claims: str, paid_col: str | None = None,
                   detectors: list[dict] | None = None, claims_window: tuple | None = None) -> pd.DataFrame:
    """ncci_rules / state_rules = COMPILED rules in window; state_leads = state policy text
    on the code that does not compile (yet). Pass detectors= and claims_window=; without
    them every rule counts (the old, overstated behaviour). v5.2b: the paid dollars are dated against the live rules'
    windows in Spark (rule_windows -> exposure_by_code), and the coverage categories rest on them."""
    windows = rule_windows(rules, detectors)
    return coverage_from_exposure(exposure_by_code(spark, claims, paid_col, windows=windows), rules, detectors,
                                  claims_window)


def coverage_pcts(coverage: pd.DataFrame | None) -> tuple[float, float]:
    """(pct_paid_covered_any, pct_paid_covered_state) for the build log: the share of the paid dollars dated inside the
    window of a live rule of their code - any rule / a state rule (v5.2b). A coverage frame without the dated columns:
    all the dollars of the rows whose coverage says covered (the old reading). NaN when nothing was paid."""
    nan = float("nan")
    if coverage is None or not len(coverage):
        return nan, nan
    tot = float(_num(coverage, "paid_dollars").sum() or 0)
    if not tot:
        return nan, nan
    if _dated(coverage):
        any_, st = float(_num(coverage, "paid_dollars_any_window").sum()), \
            float(_num(coverage, "paid_dollars_state_window").sum())
    else:
        paid_by = coverage.groupby("coverage")["paid_dollars"].sum()
        any_ = float(paid_by.drop("none", errors="ignore").sum())
        st = float(paid_by.reindex(["both", "state_only"]).fillna(0).sum())
    return round(100 * any_ / tot, 2), round(100 * st / tot, 2)


def gap_rows(coverage: pd.DataFrame) -> pd.DataFrame:
    """Paid code/form rows with dollars NO state rule judges, ranked by those dollars: the rows no live state rule
    covers (coverage none / federal_only) and (v5.2b) the rows a state rule covers only in part - a rule judges only its
    own window. paid_dollars_outside_state_window = paid_dollars - paid_dollars_state_window (NaN when not dated)."""
    cov = coverage.copy()
    outside = _num(cov, "paid_dollars") - _num(cov, "paid_dollars_state_window")
    cov["paid_dollars_outside_state_window"] = outside
    keep = cov["coverage"].isin(["none", "federal_only"]) | (outside > 0)
    return (cov[keep].sort_values(["paid_dollars_outside_state_window", "paid_dollars", "lines"], ascending=False,
                                  kind="mergesort", na_position="last").reset_index(drop=True))


def coverage_summary(coverage: pd.DataFrame) -> pd.DataFrame:
    """One row per coverage class: codes, code_forms, lines, paid_dollars, pct_lines, pct_paid.
    v5.2b (critic F10), when the coverage is dated: a class's lines and dollars are the ones DATED inside the live
    rules' windows - both = inside a state AND a federal rule's window, state_only / federal_only = inside one kind
    only, none = inside no live rule's window - so a code with dollars before and after its rule's effective date counts
    in two classes (codes and code_forms do not add up across classes; lines and dollars do). The dollars match the
    build log: pct_paid_covered_state = both + state_only, pct_paid_covered_any = 100% - none. Not dated: by each row's
    coverage, as before."""
    if not len(coverage) or not (_dated(coverage, "lines")):
        g = coverage.groupby("coverage").agg(codes=("code", "nunique"), code_forms=("code", "count"),
                                             lines=("lines", "sum"), paid_dollars=("paid_dollars", "sum")).reset_index()
    else:
        L, P = _num(coverage, "lines"), _num(coverage, "paid_dollars")
        ls, lf, la = (_num(coverage, f"lines_{k}_window").fillna(0) for k in ("state", "federal", "any"))
        ps, pf, pa = (_num(coverage, f"paid_dollars_{k}_window").fillna(0) for k in ("state", "federal", "any"))
        lines = {"both": ls + lf - la, "state_only": la - lf, "federal_only": la - ls, "none": L - la}
        paid = {"both": ps + pf - pa, "state_only": pa - pf, "federal_only": pa - ps, "none": P - pa}
        rows = []
        for k in CLASSES:
            m = lines[k] > 0
            if m.any():
                rows.append({"coverage": k, "codes": int(coverage.loc[m, "code"].nunique()), "code_forms": int(m.sum()),
                             "lines": int(round(float(lines[k][m].sum()))),
                             "paid_dollars": round(float(paid[k][m].sum()), 2)})
        g = pd.DataFrame(rows, columns=["coverage", "codes", "code_forms", "lines", "paid_dollars"])
    tot_lines = coverage["lines"].sum()
    g["pct_lines"] = (100 * g["lines"] / tot_lines).round(1)
    if coverage["paid_dollars"].notna().any():
        tot_paid = coverage["paid_dollars"].sum()
        g["pct_paid"] = (100 * g["paid_dollars"] / tot_paid).round(1)
    return g.sort_values("lines", ascending=False).reset_index(drop=True)
