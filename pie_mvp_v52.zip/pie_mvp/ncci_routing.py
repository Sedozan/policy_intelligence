"""
ncci_routing.py  -  which Medicaid NCCI edit file applies to a claim line.

CMS decides it by PROVIDER TYPE and CLAIM FORM (2026 Medicaid NCCI Technical Guidance Manual, s6.0 Table 2,
verified 2026-10-02 at https://www.cms.gov/files/document/2026-medicaid-ncci-technical-guidance-manual-02282026.pdf):

    provider type                             mandatory   CMS-1500 / 837P: rendering   UB-04 / 837I
                                                          identified / not identified
    Physician / Nonphysician Practitioner     yes         PRA / PRA                    OPH
    Ambulatory Surgical Center (ASC)          yes         PRA / PRA                    PRA
    Outpatient Services in Hospitals          yes         OPH / OPH                    OPH
    Durable/Home Medical Equipment            yes         DME / DME                    DME
    Nonhospital-Based Testing Facilities      optional    PRA / PRA                    PRA
    Other Providers of Outpatient Services    optional    PRA / OPH                    OPH

    WHICH provider (2026-10-03): the TGM requires the methodologies for "claims ... from the following types of
    providers" (s5.3) and makes them optional for "claims from other types of providers of outpatient services" such
    as FQHCs, RHCs and community mental health centers (s5.5): the provider type is the one that SUBMITS the claim -
    the BILLING provider (config.CLAIM_COLS['billing_type'] = BProv_Type). "Rendering practitioner identified" is
    read from the SERVICING provider: an individual practitioner type (Table 2's footnotes 14 and 17) is a rendering
    practitioner; an organisation (the clinic itself, a group billing ID) is not. It only matters in the 'Other
    Providers' row. Dentists are physician practitioners (footnote 14); their ADA dental claims take no file (s5.2).
    TGM s5.2: NCCI does not apply to ADA dental claims, NDC / revenue-code-only claims, or inpatient and residential
    facility claims. Footnote 19: "Identical edits for the Medicaid NCCI methods are found in standalone DME edit files
    and the PRA and OPH files" - so a line takes ONE edit file, never a merge of several.

AHCCCS provider types are mapped to those rows in a reviewed reference table, keyed on the provider type CODE (the
description can change, so it is display-only): reference/ncci_provider_type_routing.csv - one code list, used for the
billing and the servicing provider alike. The snapshot (detector_gen.snapshot_select_sql) stamps every line with
`pie_ncci_edition` = practitioner | outpatient | dme | NULL using edition_sql(); NCCI rules carry the edition they
come from (predicate['ncci_edition']) and run only on lines of that edition.
"""
from __future__ import annotations

import csv
import hashlib
import os
import re

import config

EDITIONS = ("practitioner", "outpatient", "dme")
FORM_KIND = {"A": "professional", "O": "institutional"}        # NCCI never runs on C, D, I, L (TGM s5.2)
MODES = ("billing_provider_type", "provider_type", "form")
# category -> (Table 2 row, mandatory?, {"professional_identified" | "professional" | "institutional": edition})
# "professional_identified" = CMS-1500 with a rendering practitioner identified; "professional" = not identified.
TABLE2 = {
    "practitioner":        ("Physician / Nonphysician Practitioner", True,
                            {"professional_identified": "practitioner", "professional": "practitioner",
                             "institutional": "outpatient"}),
    "asc":                 ("Ambulatory Surgical Center (ASC)", True,
                            {"professional_identified": "practitioner", "professional": "practitioner",
                             "institutional": "practitioner"}),
    "outpatient_hospital": ("Outpatient Services in Hospitals", True,
                            {"professional_identified": "outpatient", "professional": "outpatient",
                             "institutional": "outpatient"}),
    "dme":                 ("Durable/Home Medical Equipment", True,
                            {"professional_identified": "dme", "professional": "dme", "institutional": "dme"}),
    "testing_facility":    ("Nonhospital-Based Testing Facilities", False,
                            {"professional_identified": "practitioner", "professional": "practitioner",
                             "institutional": "practitioner"}),
    "other_outpatient":    ("Other Providers of Outpatient Services", False,
                            {"professional_identified": "practitioner", "professional": "outpatient",
                             "institutional": "outpatient"}),
    "not_applicable":      ("(no NCCI: dental, pharmacy, inpatient / residential, LTC / HCBS, administrative)", None, {}),
}
# practitioner-category codes that are NOT a person, so never a rendering practitioner: the group billing ID
NOT_INDIVIDUAL = frozenset({"01"})
OPTIONAL = tuple(k for k, (_, mand, _e) in TABLE2.items() if mand is False)
# form-only routing (NCCI_ROUTE_BY = "form", and the fallback for a provider type the table does not map)
FORM_ONLY = {"A": "practitioner", "O": "outpatient"}
_COLUMNS = ["sprov_type", "description_at_mapping", "cms_category", "note", "status", "reviewer", "reviewed_at",
            "in_claims_2026_10_03",            # the code occurs as SProv_Type in all_data_C_A (79 codes)
            "billing_in_claims_2026_10_04"]    # ... as BProv_Type (70 codes; 01 group ID only as billing)


NULL_TEXT = ("NAN", "NONE", "NULL")      # a missing value written as text by an export (2026-10-03, oracle S07/S08)


def norm_type(v) -> str | None:
    """A provider type code as the table keys it: text, spaces trimmed (only the space character, as SQL TRIM), upper
    case, a lone digit zero-padded ('8' -> '08', the way a numeric column would hold '08'), a whole number written with
    decimals read as the number ('8.0' -> '08'); '' / None / the text NONE, NAN or NULL -> None (missing)."""
    if v is None:
        return None
    s = str(v).strip(" ").upper()
    if s in ("",) + NULL_TEXT:
        return None
    s = re.sub(r"\.0+$", "", s) if re.fullmatch(r"\d+\.0+", s) else s
    return s.zfill(2) if s.isdigit() and len(s) == 1 else s


def table_path() -> str:
    return getattr(config, "NCCI_PROVIDER_TYPE_TABLE", None) or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "reference", "ncci_provider_type_routing.csv")


def load_table(path: str | None = None) -> list[dict]:
    """Rows of the routing table, validated: every code once (after norm_type), every category known."""
    path = path or table_path()
    with open(path, newline="", encoding="utf-8") as f:
        rows = [dict(r) for r in csv.DictReader(f)]
    seen, bad = {}, []
    for r in rows:
        c = norm_type(r.get("sprov_type"))
        if c is None:
            bad.append(f"blank provider type code in {r}")
            continue
        if not re.fullmatch(r"[A-Z0-9]{1,4}", c):
            bad.append(f"provider type {c!r}: letters and digits only")
        if r.get("cms_category") not in TABLE2:
            bad.append(f"provider type {c!r}: unknown cms_category {r.get('cms_category')!r} (one of {sorted(TABLE2)})")
        if c in seen:
            bad.append(f"provider type {c!r} listed twice")
        seen[c] = r
        r["sprov_type"] = c
    if bad:
        raise ValueError(f"{path}: " + "; ".join(bad[:10]))
    return rows


def table_sha256(path: str | None = None) -> str:
    with open(path or table_path(), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def mode() -> str:
    m = str(getattr(config, "NCCI_ROUTE_BY", "billing_provider_type")).strip().lower()
    if m not in MODES:
        raise ValueError(f"config.NCCI_ROUTE_BY must be one of {MODES}, got {m!r}")
    return m


def uses_table() -> bool:
    return mode() in ("billing_provider_type", "provider_type")


def optional_on() -> tuple[str, ...]:
    on = tuple(getattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", ()) or ())
    bad = [c for c in on if c not in OPTIONAL]
    if bad:
        raise ValueError(f"config.NCCI_OPTIONAL_CATEGORIES_ON: {bad} are not optional Table 2 rows {list(OPTIONAL)}")
    return on


def unmapped_rule() -> str:
    u = str(getattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "none")).strip().lower()
    if u not in ("form", "none"):
        raise ValueError(f"config.NCCI_UNMAPPED_PROVIDER_TYPE must be 'form' or 'none', got {u!r}")
    return u


def category_edition(category: str, form: str | None, identified: bool = False) -> str | None:
    """The edit file Table 2 gives a category on a form (None: no NCCI). Optional rows only when switched on.
    identified: a rendering practitioner is identified (only the CMS-1500 column of the 'Other Providers' row cares)."""
    kind = FORM_KIND.get(str(form or "").strip().upper())
    if kind is None or category not in TABLE2:
        return None
    _, mandatory, by_kind = TABLE2[category]
    if mandatory is False and category not in optional_on():
        return None
    if kind == "professional" and identified:
        return by_kind.get("professional_identified")
    return by_kind.get(kind)


def individual_practitioners(table: list[dict] | None = None) -> list[str]:
    """Codes whose servicing provider is a rendering practitioner (a person): the practitioner category, less groups."""
    rows = table if table is not None else load_table()
    return sorted(r["sprov_type"] for r in rows if r["cms_category"] == "practitioner"
                  and r["sprov_type"] not in NOT_INDIVIDUAL)


def edition(form, prov_type, table: list[dict] | None = None, billing_type=None) -> str | None:
    """Python reference of edition_sql(): the edit file a line takes.
    prov_type = the SERVICING provider type code, billing_type = the BILLING provider type code (missing: None).
    billing mode: the billing type picks the Table 2 row (falling back to the servicing type, then the unmapped
    rule); provider_type mode: the servicing type picks it. Either way the servicing type says whether a rendering
    practitioner is identified."""
    optional_on(), unmapped_rule()                       # validate the switches on every call (fail loudly)
    f = str(form or "").strip().upper()
    if f not in FORM_KIND:
        return None
    m = mode()
    if m == "form":
        return FORM_ONLY.get(f)
    rows = table if table is not None else load_table()
    cats = {r["sprov_type"]: r["cms_category"] for r in rows}
    st, bt = norm_type(prov_type), norm_type(billing_type)
    identified = st in set(individual_practitioners(rows))
    key = bt if (m == "billing_provider_type" and bt in cats) else (st if st in cats else None)
    if key is None:
        return FORM_ONLY.get(f) if unmapped_rule() == "form" else None
    return category_edition(cats[key], f, identified)


def type_sql(col_expr: str) -> str:
    """SQL twin of norm_type(). Linear (the column appears once): the expression is inlined wherever a type is
    compared, and a nested CASE that repeated it pushed Spark's generated code past 64 KB (2026-10-03 simulation)."""
    nulls = "|".join(NULL_TEXT)
    t = f"REGEXP_REPLACE(UPPER(TRIM(CAST({col_expr} AS STRING))), '^({nulls})$', '')"
    t = f"REGEXP_REPLACE({t}, '^([0-9]+)\\\\.0+$', '$1')"           # '8.0' -> '8'
    t = f"REGEXP_REPLACE({t}, '^([0-9])$', '0$1')"                  # '8' -> '08'
    return f"NULLIF({t}, '')"


def _in(codes) -> str:
    return ",".join(f"'{c}'" for c in sorted(codes))


def edition_sql(form_expr: str, type_expr: str, table: list[dict] | None = None, billing_expr: str | None = None) -> str:
    """SQL CASE: the edit file a line takes, from its (normalised) claim form, servicing provider type code
    (type_expr) and billing provider type code (billing_expr; None = not available -> the servicing type decides).
    The SQL twin of edition()."""
    optional_on(), unmapped_rule()
    forms = ",".join(f"'{f}'" for f in FORM_KIND)
    m = mode()
    if m == "form":
        return (f"CASE WHEN {form_expr} = 'A' THEN '{FORM_ONLY['A']}' WHEN {form_expr} = 'O' THEN "
                f"'{FORM_ONLY['O']}' END")
    rows = table if table is not None else load_table()
    by_cat: dict[str, list[str]] = {}
    for r in rows:
        by_cat.setdefault(r["cms_category"], []).append(r["sprov_type"])
    indiv = individual_practitioners(rows)
    identified = f"COALESCE({type_expr} IN ({_in(indiv)}), FALSE)" if indiv else "FALSE"
    lit = lambda e: f"'{e}'" if e else "NULL"

    def by_category(key_expr: str) -> str:
        whens = []
        for cat in TABLE2:
            codes = by_cat.get(cat)
            if not codes:
                continue
            a_id, a, o = category_edition(cat, "A", True), category_edition(cat, "A"), category_edition(cat, "O")
            a_val = lit(a) if a_id == a else f"CASE WHEN {identified} THEN {lit(a_id)} ELSE {lit(a)} END"
            val = lit(a) if (a_id == a == o) else f"CASE WHEN {form_expr} = 'A' THEN {a_val} ELSE {lit(o)} END"
            whens.append(f"WHEN {key_expr} IN ({_in(codes)}) THEN {val}")
        return "CASE " + " ".join(whens) + " END"

    fallback = (f"CASE WHEN {form_expr} = 'A' THEN '{FORM_ONLY['A']}' ELSE '{FORM_ONLY['O']}' END"
                if unmapped_rule() == "form" else "NULL")
    all_codes = _in([r["sprov_type"] for r in rows])
    out = [f"WHEN {form_expr} IS NULL OR {form_expr} NOT IN ({forms}) THEN NULL"]
    if m == "billing_provider_type" and billing_expr:
        out.append(f"WHEN {billing_expr} IN ({all_codes}) THEN {by_category(billing_expr)}")
    out.append(f"WHEN {type_expr} IN ({all_codes}) THEN {by_category(type_expr)}")
    return "CASE " + " ".join(out) + f" ELSE {fallback} END"


PIE_FORM, PIE_PROV_TYPE, PIE_BPROV_TYPE, PIE_EDITION = "pie_form", "pie_prov_type", "pie_bprov_type", "pie_ncci_edition"


def routed_sql(table: str, cc: dict, quote=lambda x: x, cols: set | None = None) -> str:
    """A RAW claims table (01, 07, gap) with the routing columns added: pie_form, pie_prov_type, pie_bprov_type and
    pie_ncci_edition - the values the detection snapshot stamps. The cleaned codes are computed ONCE per row and the
    edit file from them (inlining the clean-up into every comparison made Spark's generated code exceed 64 KB).
    cc: config.CLAIM_COLS-like {logical: physical}; quote: how a column is quoted; cols: the table's columns (upper
    case) - a configured column the table lacks is treated as missing. Returns a parenthesised subquery."""
    have = lambda k: bool(cc.get(k)) and (cols is None or str(cc[k]).upper() in cols)
    form = f"UPPER(TRIM(CAST({quote(cc['form'])} AS STRING)))" if have("form") else "CAST(NULL AS STRING)"
    pt = type_sql(quote(cc["prov_type"])) if have("prov_type") else "CAST(NULL AS STRING)"
    bt = type_sql(quote(cc["billing_type"])) if have("billing_type") else "CAST(NULL AS STRING)"
    ed = edition_sql(PIE_FORM, PIE_PROV_TYPE, billing_expr=PIE_BPROV_TYPE if have("billing_type") else None)
    return (f"(SELECT r.*, {ed} AS {PIE_EDITION} FROM (SELECT t.*, {form} AS {PIE_FORM}, {pt} AS {PIE_PROV_TYPE}, "
            f"{bt} AS {PIE_BPROV_TYPE} FROM {table} t) r)")


def is_signed(row: dict) -> bool:
    """A routing row counts as signed when its status says 'signed' AND a reviewer is named."""
    return str(row.get("status") or "").strip().lower() == "signed" and bool(str(row.get("reviewer") or "").strip())


def unsigned_observed(codes, table: list[dict] | None = None) -> list[str]:
    """The provider type codes (billing or servicing, as they occur on CMS-1500 / UB-04 lines) whose routing row is
    NOT signed - not in the table, or in it unsigned. config.NCCI_REQUIRE_SIGNED_ROUTING: 08 runs NCCI only when this
    is empty (2026-10-04, external review: 100% signed routing for the provider types actually observed)."""
    rows = {r["sprov_type"]: r for r in (table if table is not None else load_table())}
    seen = {norm_type(c) for c in codes} - {None}
    return sorted(c for c in seen if c not in rows or not is_signed(rows[c]))


def observed_types_sql(table: str, form_col: str, prov_col: str = None, billing_col: str | None = None) -> str:
    """SQL: the provider type codes (one column `t`) that decide routing on the lines of `table` - the codes the
    signed-routing gate (run_guard.ncci_routing_gate) checks. Lines of a form NCCI applies to (CMS-1500 'A' /
    UB-04 'O'); the servicing type always (it says "rendering practitioner identified" and is the fallback), the
    billing type when routing by it. The columns must already be cleaned (the snapshot's pie_* columns)."""
    prov_col = prov_col or PIE_PROV_TYPE
    forms = ",".join(f"'{f}'" for f in FORM_KIND)
    cols = [prov_col] + ([billing_col or PIE_BPROV_TYPE] if mode() == "billing_provider_type" else [])
    parts = " UNION ALL ".join(f"SELECT {c} AS t FROM {table} WHERE {form_col} IN ({forms})" for c in cols)
    return f"SELECT DISTINCT t FROM ({parts}) u WHERE t IS NOT NULL ORDER BY t"


def summary(table: list[dict] | None = None) -> dict:
    """For the build log: how the routing was configured."""
    m = mode()
    out = {"mode": m, "optional_on": list(optional_on()), "unmapped_provider_type": unmapped_rule()}
    if m in ("billing_provider_type", "provider_type"):
        rows = table if table is not None else load_table()
        out.update(table=os.path.basename(table_path()), table_sha256=table_sha256(), types_mapped=len(rows),
                   types_signed=sum(1 for r in rows if is_signed(r)),
                   require_signed=bool(getattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True)),
                   by_category={c: sum(1 for r in rows if r["cms_category"] == c) for c in TABLE2})
    return out
