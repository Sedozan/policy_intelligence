"""
run_guard.py  -  what 08_run_detectors checks before it runs a query, as plain functions (tested offline).

1. build_problems(): one complete build, and every stored statement still the one 07 compiled. A statement whose
   sha256 is missing is refused too (07 always stores one; a blank hash used to switch the check off).
2. validation_status(): the validator's decision (v06 -> policy_query_validation) in force for each query's CURRENT
   SQL. A decision recorded against older SQL does not count: the query changed after it was validated.
3. skip_reason(): a query a validator marked PROBLEM never runs; with config.RUN_ONLY_VALIDATED_QUERIES = True, only
   queries signed OK run. Every finding carries `query_validation` (OK / not_validated), so a reader can always tell
   a finding from a validated query from one that was not.
4. ncci_routing_gate(): with config.NCCI_REQUIRE_SIGNED_ROUTING (default), the NCCI statements run only when every
   provider type code on the snapshot's CMS-1500 / UB-04 lines has a signed routing row (2026-10-04).
"""
from __future__ import annotations

import os

import pandas as pd

import config
import detector_gen
import ncci_routing

OK, PROBLEM, NOT_VALIDATED = "OK", "PROBLEM", "not_validated"


def _s(v) -> str:
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except (TypeError, ValueError):
        pass
    s = str(v).strip()
    return "" if s.lower() in ("nan", "none", "nat") else s


def _true(v) -> bool:
    """compiled flag as read back from a table: Python / numpy bool, 'true', 1 (NaN / None = False)."""
    if isinstance(v, str):
        return v.strip().lower() in ("true", "1")
    try:
        return bool(v) and not pd.isna(v)
    except (TypeError, ValueError):
        return False


def _records(df) -> list[dict]:
    return df.to_dict("records") if df is not None and len(df) else []


def current_hashes(det: pd.DataFrame, batches: pd.DataFrame | None = None) -> dict[str, str]:
    """query_id -> the sha256 07 stored for its SQL: per-rule state queries (rule_id), the NCCI batch statements
    (BATCH:<batch>) and the rolling-signal queries (SIGNAL:<rule_id>) - the ids the v06 pack uses."""
    cur = {}
    for r in _records(det):
        if _true(r.get("compiled")) and _s(r.get("sql")):
            cur[str(r["rule_id"])] = _s(r.get("sql_sha256"))
        if _true(r.get("compiled")) and _s(r.get("signal_sql")):
            cur[f"SIGNAL:{r['rule_id']}"] = _s(r.get("signal_sql_sha256"))
    for b in _records(batches):
        cur[f"BATCH:{b['batch']}"] = _s(b.get("sql_sha256"))
    return cur


def build_problems(det: pd.DataFrame, batches: pd.DataFrame | None, table_builds: dict[str, set],
                   build_log: pd.DataFrame | None, build_id: str) -> list[str]:
    """Why 08 must not run (empty list = go). table_builds: table name -> the build_ids it holds."""
    problems = []
    for t, s in table_builds.items():
        s = {str(x) for x in s}
        if s and s != {build_id}:
            problems.append(f"{t} holds build(s) {sorted(s)}, policy_detectors holds {build_id}")
    if build_log is None or not len(build_log):
        problems.append(f"policy_build_log has no 'complete' row for build {build_id} - 07 did not finish; re-run it")
    else:
        ok = build_log["build_id"].astype(str) == build_id
        if "status" in build_log:
            ok &= build_log["status"].astype(str) == "complete"
        if not ok.any():
            problems.append(f"policy_build_log has no 'complete' row for build {build_id} - 07 did not finish; re-run it")
    stmts = [(str(r["rule_id"]), r.get("sql"), r.get("sql_sha256")) for r in _records(det)
             if _true(r.get("compiled")) and _s(r.get("sql"))]
    stmts += [(f"BATCH:{b['batch']}", b.get("sql"), b.get("sql_sha256")) for b in _records(batches) if _s(b.get("sql"))]
    stmts += [(f"SIGNAL:{r['rule_id']}", r.get("signal_sql"), r.get("signal_sql_sha256")) for r in _records(det)
              if _true(r.get("compiled")) and _s(r.get("signal_sql"))]
    for qid, sql, want in stmts:
        if not _s(want):
            problems.append(f"{qid} has no sql_sha256 - 07 stores one for every statement; it cannot be verified")
        elif detector_gen.sql_sha256(sql) != _s(want):
            problems.append(f"SQL of {qid} does not match its sql_sha256 - it was edited after 07 compiled it")
    return problems


def validation_status(validations: pd.DataFrame | None, current: dict[str, str]) -> dict[str, str]:
    """query_id -> OK / PROBLEM / not_validated: the LATEST decision (validated_at) recorded for the query's current
    sql_sha256."""
    out = {q: NOT_VALIDATED for q in current}
    if validations is None or not len(validations):
        return out
    v = validations.copy()
    for c in ("query_id", "sql_sha256", "validator_decision", "validated_at"):
        v[c] = v[c].map(_s) if c in v else ""
    v = v[v.apply(lambda r: r["query_id"] in current and r["sql_sha256"] == current[r["query_id"]]
                  and r["validator_decision"].upper() in (OK, PROBLEM), axis=1)] if len(v) else v
    for qid, g in v.groupby("query_id"):
        out[qid] = g.sort_values("validated_at", kind="stable")["validator_decision"].iloc[-1].upper()
    return out


def only_validated() -> bool:
    return bool(getattr(config, "RUN_ONLY_VALIDATED_QUERIES", False))


def skip_reason(status: str) -> str | None:
    """Why a query with this validation status is not run (None = run it)."""
    if status == PROBLEM:
        return "not run: a validator marked this SQL PROBLEM (v06); fix the rule or the query, rebuild, re-validate"
    if only_validated() and status != OK:
        return "not run: not validated OK for this SQL (config.RUN_ONLY_VALIDATED_QUERIES = True)"
    return None


def require_signed_routing() -> bool:
    return bool(getattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True))


def ncci_routing_kind(observed_codes, table: list[dict] | None = None) -> str:
    """How the NCCI edit file of the observed lines is decided, as one word for the run log and every NCCI finding:
      signed         every provider type code on a CMS-1500 / UB-04 line has a signed routing row, and a line whose
                     types the table does not map takes no file (NCCI_UNMAPPED_PROVIDER_TYPE = "none")
      unsigned       some observed code has no signed row
      form_fallback  a line whose provider types the table does not map is routed by its claim form (unmapped =
                     "form") - a guess nobody signed, whatever the table says
      form_only      routing by claim form alone (NCCI_ROUTE_BY = "form")"""
    if ncci_routing.mode() == "form":
        return "form_only"
    if ncci_routing.unmapped_rule() == "form":
        return "form_fallback"
    return "unsigned" if ncci_routing.unsigned_observed(observed_codes, table) else "signed"


def ncci_routing_gate(observed_codes, table: list[dict] | None = None) -> str | None:
    """Why the NCCI batch statements are not run (None = run them). With config.NCCI_REQUIRE_SIGNED_ROUTING (default;
    2026-10-04 external review: "100% signed NCCI routing for provider types actually observed") every provider type
    code that decides routing on a CMS-1500 / UB-04 line of the snapshot (ncci_routing.observed_types_sql) must have a
    SIGNED row in the routing table (status 'signed' and a reviewer), and no line may be routed by a guess: routing
    by claim form alone, or the form fallback for unmapped types, has no mapping to sign, so it does not run either
    while the switch is on. Which edit file a provider type takes is a policy reading; findings must not rest on a
    reading nobody signed."""
    if not require_signed_routing():
        return None
    kind = ncci_routing_kind(observed_codes, table)
    if kind == "form_only":
        return ("not run: NCCI routed by claim form only (config.NCCI_ROUTE_BY = 'form') - there is no signed "
                "provider-type mapping; route by provider type with a signed table, or set "
                "config.NCCI_REQUIRE_SIGNED_ROUTING = False for an exploratory run")
    if kind == "form_fallback":
        return ("not run: config.NCCI_UNMAPPED_PROVIDER_TYPE = 'form' routes a line whose provider types are not in "
                "the table by its claim form - a guess nobody signed; set it to 'none', or set "
                "config.NCCI_REQUIRE_SIGNED_ROUTING = False for an exploratory run")
    if kind == "signed":
        return None
    unsigned = ncci_routing.unsigned_observed(observed_codes, table)
    shown = ", ".join(unsigned[:20]) + (f" ... (+{len(unsigned) - 20} more)" if len(unsigned) > 20 else "")
    return (f"not run: {len(unsigned)} provider type code(s) on CMS-1500 / UB-04 lines have no SIGNED routing row "
            f"({shown}) - sign them in {os.path.basename(ncci_routing.table_path())} (status 'signed' + reviewer), "
            f"or set config.NCCI_REQUIRE_SIGNED_ROUTING = False for an exploratory run")
