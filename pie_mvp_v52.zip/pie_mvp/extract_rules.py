"""
extract_rules.py  -  Stages 3-5: pre-filter, propose (LLM), ground, draft.

The model PROPOSES rules into the closed predicate grammar; it never decides.
Every proposal passes a deterministic grounding check (the quoted sentence must
exist in the section, every code must exist in the section, thresholds must be
present or be marked derived) and then lands in main.sedo.state_rules as a
DRAFT for a named reviewer. Nothing reaches a detector without that approval.

Backends (config.LLM_BACKEND):
  STUB     deterministic pattern extractor. Runs the whole pipeline with no
           model; also a floor for the simplest rule shapes.
  HFLOCAL  openai/gpt-oss-120b via transformers + openai-harmony ON THE CLUSTER -
           a mirror of SB's llm_summarization_v3 loop (final channel only, retry on
           truncation). The production path (2026-09-21).
  DBFM     Databricks Foundation Model serving endpoint, OpenAI-compatible. Optional.
  HYBRID   patterns + one of the above; refuses to run without the model unless
           told otherwise. A dead model is a loud failure, never a silent regex run.

Prompt v2 (2026-10-02, C3 critic review of the first real run): the prompt is the schema contract - the
not_checkable reasons come from schema.PROMPT_REASONS, age is on the claim, combined caps are one code_set rule,
every pair carries scope / indicator / direction, conditions become predicate.exception, "may be denied" is
discretionary, dates are grounded in the quote. After grounding, post_checks.py enforces the same contract
deterministically (a model that ignores the prompt still cannot produce a wider rule than the text).
"""
from __future__ import annotations

import copy
import difflib
import hashlib
import json
import re
from datetime import datetime

import config
import post_checks
import schema
from policy_docs import (CODE_RE, WORD_NUMBERS, clean_chars, code_list_break, code_ranges, date_cues, rule_signal,
                         sentence_spans)

# C3-08 / prompt v2: the cache is keyed on the prompt version (and the model, reasoning level and token budget -
# _generation_tag), so a v1 answer is never reused as a v2 answer and a 'low' answer never as a 'medium' one.
# Module-level ON PURPOSE (config.PROMPT_VERSION says the same): the prompt text lives in this file, so the version
# that keys its cache must live here too.
PROMPT_VERSION = "v2"

# --------------------------------------------------------------- prompt
# C3-14: the reason list is GENERATED from schema.PROMPT_REASONS (first-fit order, one-line meanings). The first
# run used three different lists; 69 of 146 reviewer fixes only relabelled the reason.
_REASON_BLOCK = "\n".join(f"  {r:<26} {meaning}" for r, meaning in schema.PROMPT_REASONS)

SYSTEM_PROMPT = f"""You extract billing rules from Arizona Medicaid (AHCCCS) Fee-For-Service manual text into a closed JSON grammar.
You are an extractor, not a decider: propose only what the text states, quote it verbatim, and flag anything
unclear instead of resolving it. Never invent a code, number, period, date or quote.

OUTPUT: a single JSON object: {{"rules": [...], "no_rule_reason": string|null}}. No other text.
Each rule object:
  "verbatim_quote"   the EXACT sentence(s) that state the rule, copied character for character
  "statement"        one plain-English sentence saying only what the quote says (keep its conditions and dates)
  "predicate"        one of the types below, with its fields
  "codes"            the CPT/HCPCS codes the rule applies to (may be empty)
  "population"       "all", or the group exactly as written ("members 21 years of age and older", "ALTCS members")
  "effective_date"   "YYYY-MM-DD" when the quote says effective / beginning / on or after a date, else null
  "end_date"         "YYYY-MM-DD" when the quote says prior to / before a date (use the day before) or through a date
  "not_checkable_reason" string|null (the predicate's reason when its type is not_checkable)
  "derived", "derivation_note", "ambiguous", "ambiguity_note", "confidence" (0.0-1.0, honest)

PREDICATE TYPES (closed grammar - use nothing else):
  {{"type":"max_units_per_day","code":"98960","threshold":4}}   per member per day; "code_set":[...] sums several codes
  {{"type":"max_units_per_period","code_set":["98960","98961","98962"],"threshold":24,"period":"month"}}   period: month|year|benefit_year
  {{"type":"code_pair_prohibited","code_a":"H2018","code_b":"H2014","scope":"member_provider_day","modifier_indicator":"0","service_category":"state"}}
  {{"type":"code_not_covered","code":"11975"}}   or "code_set":[...]
  {{"type":"max_dollars_per_period","code_set":["T2029"],"threshold":5000,"period":"benefit_year"}}
  {{"type":"frequency_limit","code_set":["97110"],"threshold":8,"period":"benefit_year","unit":"visits"}}
  {{"type":"modifier_required","code_set":["E0618","E0619"],"modifier":"RR"}}
  {{"type":"provider_type_allowed","code_set":["H0035"],"provider_types":["B2","02"]}}
  {{"type":"not_checkable","reason":"<reason>"}}
Optional on every type except not_checkable:
  "age": {{"min":21}} 21 and older | {{"below":21}} under 21 | {{"min":21,"below":65}} 21 through 64 (age on the date of service)
  "exception": "<the verbatim unless / except / when / only if clause>"
  "discretionary": true   when the text says the claim MAY be denied or may not be reimbursed

NOT_CHECKABLE REASONS - use the FIRST that fits:
{_REASON_BLOCK}

RULES OF EXTRACTION
1. One rule per distinct obligation. A cap the text calls combined ("inclusive of", "total", "combined", "in any
   combination") across several codes is ONE rule with a code_set, never one rule per code.
2. Every code_pair_prohibited has "scope" and "modifier_indicator":"0". scope "member_day" only when the text says the
   same member or any provider; "member_provider_day" when it says a single/same provider, or says neither.
   code_b is the code the text says may not be billed or may be denied: "H2014 may be denied when billed on the
   same day as any per diem code" -> code_a = each per diem code the section names, code_b = H2014.
   "A, B and C cannot be billed on the same day" -> one pair per combination (A/B, A/C, B/C).
   "A cannot be billed on the same day as B, C or D" -> code_b = A with each listed code (B/A, C/A, D/A); never B/C.
3. A rule with "unless / except / when / only if ..." keeps its type and puts the verbatim clause in "exception";
   if the condition IS the rule (it decides whether the rule applies at all), use not_checkable.
   "May be denied" adds "discretionary": true.
4. modifier_required only when the modifier belongs on EVERY line of those codes. "Must use HQ when serving two or
   more members" is not_checkable requires_medical_record.
5. code_not_covered only when the code itself is never payable. A code barred in one context ("94799 may not be
   billed for apnea management") is not_checkable.
6. Age is on the claim: a rule limited by age carries "age" ("EPSDT" used as an age rule = {{"below":21}};
   "does not apply to EPSDT members" = {{"min":21}}) and keeps "population" as written. Other EPSDT or program
   scoping (ALTCS, KidsCare, FES, QMB, Tribal) is not_checkable requires_member_attribute.
7. A retired or replaced code is code_not_covered only with the date the text gives (effective_date); no date ->
   not_checkable predicate_not_in_grammar. A code RANGE ("99201-99499") is not a code list -> not_checkable
   predicate_not_in_grammar, naming the range in the statement.
8. Numbers written as words are fine ("four units" -> 4). Policy adoption statements ("AHCCCS follows CCI") are
   not_checkable policy_reference.
9. If the section states no billing rule, return {{"rules": [], "no_rule_reason": "..."}}.
"""

USER_TEMPLATE = """CHAPTER {chapter}: {title}
SECTION: {heading}   (pages {page_start}-{page_end}, revision {revision})

TEXT:
\"\"\"
{text}
\"\"\"

Return the JSON object now."""

_REQUIRED_KEYS = schema.REQUIRED_KEYS          # single source: schema.py
_FIELDS_BY_TYPE = {
    "code_pair_prohibited": ["proc_cd", "member_id", "provider_id", "srvc_bgn_dt", "mod_1", "mod_2", "mod_3", "mod_4"],
    "max_units_per_day": ["proc_cd", "units", "member_id", "srvc_bgn_dt"],
    "max_units_per_period": ["proc_cd", "units", "member_id", "srvc_bgn_dt"],
    "max_units_per_line": ["proc_cd", "units"],
    "max_units_per_dos": ["proc_cd", "units", "member_id", "provider_id", "srvc_bgn_dt"],
    "code_not_covered": ["proc_cd"],
}


def _period_token(word: str) -> str:
    """Map the period phrase in the source to a compiler period token.
    AHCCCS 'contract year' / 'benefit year' both mean Oct 1 - Sep 30 (verified in
    the manual), which the compiler models as 'benefit_year'."""
    w = (word or "").strip().lower()
    if w in ("contract year", "benefit year"):
        return "benefit_year"
    if w == "year":
        return "year"
    return "month"


# ------------------------------------------------------------- backends
class Backend:
    name = "base"
    model = ""

    def complete(self, system: str, user: str) -> str:
        raise NotImplementedError


class ModelUnavailable(RuntimeError):
    """The model backend cannot be reached. Carries every attempt's real error."""


class ModelOutputUnparseable(ValueError):
    """The model answered, but not with our JSON (D1). A failure to retry, never 'no rules'."""


class ModelOutputTruncated(ValueError):
    """C3-07: the token budget ran out - in the analysis channel, or INSIDE the final JSON - even after the one
    retry at RETRY_BUDGET_FACTOR x budget. Never 'no rules': propose() splits the section in two at a paragraph
    boundary and extracts each half (depth <= SPLIT_MAX_DEPTH); past that the section fails retryably."""


def _workspace_host_token() -> tuple[str, str]:
    """Workspace URL + token for the OpenAI-compatible serving route.
    Env vars first (jobs, local dev), then the notebook context (interactive
    notebooks do NOT export DATABRICKS_HOST/TOKEN - reading os.environ[...] there
    raises KeyError, which is exactly the 2026-09-20 failure)."""
    import os
    host, token = os.environ.get("DATABRICKS_HOST"), os.environ.get("DATABRICKS_TOKEN")
    if host and token:
        return host.rstrip("/"), token
    try:
        import IPython
        dbutils = IPython.get_ipython().user_ns["dbutils"]
        ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
        return ctx.apiUrl().get().rstrip("/"), ctx.apiToken().get()
    except Exception as e:
        raise RuntimeError(f"DATABRICKS_HOST/DATABRICKS_TOKEN not set and notebook context unavailable "
                           f"({type(e).__name__}: {e})")


class DBFMBackend(Backend):
    """Databricks Foundation Model serving endpoint.

    Three ways to reach it, tried in order; EVERY failure is recorded with its full
    message and, if all fail, raised together as ModelUnavailable. Nothing is
    swallowed: a bare `except: fall back` hid the real error for a whole run.
      1. databricks-sdk  WorkspaceClient().serving_endpoints.get_open_ai_client()  (needs `openai`)
      2. mlflow.deployments  get_deploy_client("databricks").predict(...)          (always on a cluster)
      3. openai.OpenAI(base_url=<workspace>/serving-endpoints, api_key=<token>)   (env or notebook ctx)
    """
    name = "DBFM"

    def __init__(self, endpoint: str | None = None):
        self.model = endpoint or config.DBFM_ENDPOINT
        self._chat = None            # callable(msgs, json_mode) -> (content, finish_reason)
        self.client_route = None
        self.client_errors: list[str] = []
        self.calls = 0
        self.failures = 0
        self.last_error: str | None = None

    # ---- client construction -------------------------------------------------
    def _build(self):
        if self._chat is not None:
            return self._chat
        errors = []
        kw = dict(temperature=config.LLM_TEMPERATURE, max_tokens=config.LLM_MAX_TOKENS)

        def _via_openai_client(client):
            def chat(msgs, json_mode):
                extra = {"response_format": {"type": "json_object"}} if json_mode else {}
                r = client.chat.completions.create(model=self.model, messages=msgs, **kw, **extra)
                return (r.choices[0].message.content or ""), getattr(r.choices[0], "finish_reason", None)
            return chat

        try:
            from databricks.sdk import WorkspaceClient
            client = WorkspaceClient().serving_endpoints.get_open_ai_client()
            self._chat, self.client_route = _via_openai_client(client), "databricks-sdk openai client"
            return self._chat
        except Exception as e:
            errors.append(f"databricks-sdk: {type(e).__name__}: {e}")
        try:
            from mlflow.deployments import get_deploy_client
            client = get_deploy_client("databricks")

            def chat(msgs, json_mode):
                inputs = {"messages": msgs, **kw}
                if json_mode:
                    inputs["response_format"] = {"type": "json_object"}
                r = client.predict(endpoint=self.model, inputs=inputs)
                ch = r["choices"][0]
                return (ch.get("message", {}).get("content") or ""), ch.get("finish_reason")
            self._chat, self.client_route = chat, "mlflow.deployments"
            return self._chat
        except Exception as e:
            errors.append(f"mlflow.deployments: {type(e).__name__}: {e}")
        try:
            from openai import OpenAI
            host, token = _workspace_host_token()
            client = OpenAI(api_key=token, base_url=f"{host}/serving-endpoints")
            self._chat, self.client_route = _via_openai_client(client), f"openai client @ {host}"
            return self._chat
        except Exception as e:
            errors.append(f"openai+workspace: {type(e).__name__}: {e}")
        self.client_errors = errors
        raise ModelUnavailable(f"DBFM endpoint {self.model!r}: no client route works:\n  - " + "\n  - ".join(errors))

    # ---- completion ----------------------------------------------------------
    def complete(self, system: str, user: str) -> str:
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        chat = self._build()
        self.calls += 1
        try:
            try:
                content, finish = chat(msgs, True)
            except Exception as e_json:                 # endpoint may not support json_object
                content, finish = chat(msgs, False)     # plain retry; the json-mode error is kept for the record
                self.last_error = f"json_object mode rejected ({type(e_json).__name__}: {str(e_json)[:160]}); plain mode used"
        except Exception as e:
            self.failures += 1
            self.last_error = f"{type(e).__name__}: {e}"
            raise
        if finish == "length":
            # a truncated JSON is not a "no rules" answer; make it a visible, retryable failure
            raise ValueError(f"model output truncated at max_tokens={config.LLM_MAX_TOKENS} (finish_reason=length); "
                             f"raise config.LLM_MAX_TOKENS or split the section")
        return content

    def healthcheck(self) -> tuple[bool, str]:
        """One tiny call. Returns (ok, human-readable detail including the model's reply)."""
        try:
            reply = self.complete("Reply with a JSON object.", 'Return exactly {"ok": true}.')
            return True, (f"DBFM {self.model} OK via {self.client_route}; reply: {reply.strip()[:120]!r}")
        except Exception as e:
            return False, f"DBFM {self.model} FAILED: {type(e).__name__}: {e}"


# ------------------------------------------------ HFLOCAL: gpt-oss on the cluster
# One model per Python process. The notebook loads it once (exactly as the
# summarization notebook does) and hands the objects in; re-instantiating the
# backend never reloads 120B parameters.
_HF_RUNTIME: dict = {"model": None, "tokenizer": None, "harmony_enc": None, "model_id": None}


def load_hf_runtime(model_id: str | None = None, hf_token_path: str | None = None, log_fn=print) -> dict:
    """Load tokenizer + model + harmony encoding ONCE, the same way llm_summarization_v3 does:
    login(hf_token) ; AutoTokenizer/AutoModelForCausalLM.from_pretrained(torch_dtype="auto",
    device_map="auto", trust_remote_code=True) ; load_harmony_encoding(HARMONY_GPT_OSS)."""
    model_id = model_id or config.HF_MODEL
    if _HF_RUNTIME["model"] is not None and _HF_RUNTIME["model_id"] == model_id:
        return _HF_RUNTIME
    import time as _t
    t0 = _t.time()
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from openai_harmony import load_harmony_encoding, HarmonyEncodingName
    token_path = config.HF_TOKEN_PATH if hf_token_path is None else hf_token_path
    if token_path:
        from huggingface_hub import login
        with open(token_path) as f:
            login(f.read().strip())
    log_fn(f"Loading model: {model_id}")
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype="auto", device_map="auto",
                                                 trust_remote_code=True)
    harmony_enc = load_harmony_encoding(HarmonyEncodingName.HARMONY_GPT_OSS)
    _HF_RUNTIME.update(model=model, tokenizer=tokenizer, harmony_enc=harmony_enc, model_id=model_id)
    dev = getattr(model, "hf_device_map", None) or getattr(model, "device", "auto")
    log_fn(f"Model loaded: {model_id} in {_t.time() - t0:.0f}s | device map: {dev}")
    return _HF_RUNTIME


def _extract_channel_text(msg) -> tuple[str | None, str]:
    """(channel, text) from an openai-harmony Message: channel is 'analysis' | 'final' |
    'commentary' | None; content is a list of items carrying .text."""
    channel = getattr(msg, "channel", None)
    content = getattr(msg, "content", msg)
    if isinstance(content, str):
        return channel, content
    parts = []
    for item in (content or []):
        parts.append(getattr(item, "text", None) or (item.get("text", "") if isinstance(item, dict) else str(item)))
    return channel, "".join(parts)


class HFLocalBackend(Backend):
    """gpt-oss via transformers + openai-harmony, mirroring SB's generate_with_harmony /
    generate_final_with_retry:

      tokenizer.apply_chat_template(messages, add_generation_prompt=True, return_dict=True,
                                    reasoning_effort=<level>)
      model.generate(input_ids, max_new_tokens=<budget>, do_sample=False)
      harmony_enc.parse_messages_from_completion_tokens(new_ids, role=Role.ASSISTANT)
      keep channel == "final"; "analysis" is reasoning and is never returned
      no final + hit budget + no parse error  -> retry once at RETRY_BUDGET_FACTOR x budget
      final present + hit budget + JSON incomplete (C3-07: the budget ran out INSIDE the
      answer) -> the same single retry; still truncated -> ModelOutputTruncated

    Differences from the summarizer, on purpose: the "leak" check is replaced by the
    caller's JSON grammar check (a final that is not our JSON is a failure, never a
    rule); and there is NO deterministic fallback - a failed call raises, so the
    section is recorded as a model failure and retried next run (never cached).
    """
    name = "HFLOCAL"

    def __init__(self, model_id: str | None = None, reasoning_level: str | None = None,
                 model=None, tokenizer=None, harmony_enc=None):
        self.model = model_id or config.HF_MODEL          # Backend.model = the model's name
        self.reasoning_level = reasoning_level or config.LLM_REASONING
        if model is not None and tokenizer is not None and harmony_enc is not None:
            _HF_RUNTIME.update(model=model, tokenizer=tokenizer, harmony_enc=harmony_enc, model_id=self.model)
        self.calls = 0
        self.failures = 0
        self.retries = 0
        # C3-07 telemetry: every generate() call, so a run shows how close sections come to the budget
        self.tokens_generated = 0
        self.generate_calls = 0
        self.hit_budget_calls = 0
        self.truncated = 0
        self.last_error: str | None = None
        self.last_meta: dict | None = None
        self.client_route = "transformers+openai-harmony (local)"

    def budget(self) -> int:
        """max_new_tokens of the first attempt at this reasoning level (part of the cache key, C3-08)."""
        return int(config.REASONING_TOKEN_BUDGET.get(self.reasoning_level, 3000))

    def _rt(self) -> dict:
        rt = _HF_RUNTIME
        if rt["model"] is None or rt["tokenizer"] is None or rt["harmony_enc"] is None:
            rt = load_hf_runtime(self.model)
        return rt

    # ---- one generate, SB's generate_with_harmony -----------------------------
    def _generate(self, messages: list[dict], max_new_tokens: int | None = None) -> tuple[str, str, dict]:
        import torch
        from openai_harmony import Role
        rt = self._rt()
        model, tokenizer, enc = rt["model"], rt["tokenizer"], rt["harmony_enc"]
        budget = max_new_tokens or config.REASONING_TOKEN_BUDGET.get(self.reasoning_level, 3000)
        inputs = tokenizer.apply_chat_template(messages, return_tensors="pt", add_generation_prompt=True,
                                               return_dict=True, reasoning_effort=self.reasoning_level)
        input_ids = inputs["input_ids"].to(model.device)
        with torch.no_grad():
            output_ids = model.generate(input_ids, max_new_tokens=budget, do_sample=False)
        new_token_ids = output_ids[0][input_ids.shape[1]:].tolist()

        final_text, analysis_text, parse_error = "", "", None
        try:
            for msg in enc.parse_messages_from_completion_tokens(new_token_ids, role=Role.ASSISTANT):
                channel, content = _extract_channel_text(msg)
                if channel == "final":
                    final_text = content
                elif channel == "analysis":
                    analysis_text += content + " "
        except Exception as e:
            parse_error = f"{type(e).__name__}: {e}"
        meta = {"final_channel_present": bool(final_text.strip()), "parse_error": parse_error,
                "tokens_generated": len(new_token_ids), "budget": budget,
                "hit_budget": len(new_token_ids) >= budget - 2, "reasoning_level": self.reasoning_level}
        self.generate_calls += 1
        self.tokens_generated += meta["tokens_generated"]
        self.hit_budget_calls += int(meta["hit_budget"])
        return final_text.strip(), analysis_text.strip(), meta

    @staticmethod
    def _truncated(final: str, meta: dict) -> bool:
        """Out of budget: no final channel (and no parse error, as in SB's loop), or a final channel whose JSON
        was cut off (C3-07: the old check only looked for a missing final, so a section whose rule list ran past
        the budget failed 'unparseable' on every run, deterministically)."""
        if not meta.get("hit_budget"):
            return False
        if not meta.get("final_channel_present"):
            return not meta.get("parse_error")
        return not _json_complete(final)

    # ---- SB's generate_final_with_retry, fail-loud ------------------------------
    def complete(self, system: str, user: str) -> str:
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        self.calls += 1
        try:
            final, _, meta = self._generate(messages)
            meta["retried"] = False
            if self._truncated(final, meta):
                retry_budget = int(meta["budget"] * config.RETRY_BUDGET_FACTOR)
                self.retries += 1
                final, _, meta = self._generate(messages, max_new_tokens=retry_budget)
                meta["retried"] = True
            self.last_meta = meta
            if self._truncated(final, meta):
                self.truncated += 1
                where = ("final channel truncated (incomplete JSON)" if meta["final_channel_present"]
                         else "no final channel")
                raise ModelOutputTruncated(f"{where} after {meta['tokens_generated']}/{meta['budget']} tokens "
                                           f"(retried={meta['retried']}); the section will be split")
            if meta["parse_error"] and not meta["final_channel_present"]:
                raise ValueError(f"harmony parse failed: {meta['parse_error']}")
            if not meta["final_channel_present"]:
                raise ValueError(f"no final channel after {meta['tokens_generated']}/{meta['budget']} tokens "
                                 f"(retried={meta['retried']}); raise REASONING_TOKEN_BUDGET or split the section")
            return final
        except Exception as e:
            self.failures += 1
            self.last_error = f"{type(e).__name__}: {e}"
            raise

    def healthcheck(self) -> tuple[bool, str]:
        try:
            import time as _t
            t0 = _t.time()
            reply = self.complete("Reply with a JSON object.", 'Return exactly {"ok": true}.')
            m = self.last_meta or {}
            return True, (f"HFLOCAL {self.model} OK ({_t.time() - t0:.1f}s, {m.get('tokens_generated')} tokens, "
                          f"reasoning={self.reasoning_level}); reply: {reply[:120]!r}")
        except Exception as e:
            return False, f"HFLOCAL {self.model} FAILED: {type(e).__name__}: {e}"


class StubBackend(Backend):
    """Deterministic pattern extractor. No model. Emits the same JSON contract."""
    name = "STUB"
    # v2: combined caps -> one code_set rule, hub sentences pair hub x spoke only, pairs carry scope (C3-04/C3-12);
    # the model name is part of the cache key, so v1 pattern output is never reused
    model = "pattern-v2"

    _SENT = re.compile(r"(?<=[.;])\s+(?=[A-Z(])")
    _BULLET = re.compile(r"^(?:[•·▪◦\-\*]\s|\(?[a-z0-9]{1,2}[\.\)]\s)")
    _LEAD_IN = re.compile(r"do not bill|not covered|non-covered|not reimburs|not an ahcccs[- ]covered", re.I)

    def complete(self, system: str, user: str) -> str:
        m = re.search(r'TEXT:\n"""\n(.*?)\n"""', user, re.S)
        text = m.group(1) if m else user
        rules, prev_codes, lead = [], [], None
        # C3-16: paragraphs (and bullets, which segment() keeps on their own line) are split first, so a bullet list
        # without periods no longer glues the next paragraph onto a sentence (the 00938 list + nerve-block paragraph
        # became one 'modifier + range' rule in the first run, rejected)
        units = [u.strip() for para in text.split("\n") for u in self._split(para) if u.strip()]
        for s in units:
            codes = sorted(set(CODE_RE.findall(s)))
            if lead and self._BULLET.match(s):
                # "Do not bill for CPT codes:" / "The following ... are not covered:" + one bullet per code: the
                # lead-in carries the obligation; the quote is lead-in + item (exact in the section text)
                rules += self._patterns(f"{lead} {s}", lead_in=True)
                continue
            lead = s if (s.endswith(":") and self._LEAD_IN.search(s)) else None
            # "These codes cannot be billed together..." refers back to the previous sentence
            carry = prev_codes if (not codes and re.match(r"^(these|those|both|the above) codes?\b", s.lower())) else []
            rules += self._patterns(s, carry)
            if codes:
                prev_codes = codes
        rules += self._section_level(text)
        return json.dumps({"rules": rules, "no_rule_reason": None if rules else "no rule pattern matched"})

    def _split(self, para: str) -> list[str]:
        """Sentences of one paragraph; a '.' inside a code list ('S5150. T1019. H0031,') does not end one
        (policy_docs.code_list_break - the same rule the grounding sentence window uses)."""
        out = []
        for piece in self._SENT.split(para):
            if out and code_list_break(out[-1].rstrip(), piece.lstrip()):
                out[-1] = out[-1].rstrip() + " " + piece.lstrip()
            else:
                out.append(piece)
        return out

    @staticmethod
    def _num(tok: str) -> int | None:
        tok = tok.lower()
        if tok.isdigit():
            return int(tok)
        return WORD_NUMBERS.get(tok)

    def _patterns(self, s: str, carry: list[str] | None = None, lead_in: bool = False) -> list[dict]:
        out = []
        low = s.lower()
        codes = sorted(set(CODE_RE.findall(s))) or list(carry or [])
        base = {"verbatim_quote": s, "derived": False, "derivation_note": None, "ambiguous": False,
                "ambiguity_note": None, "not_checkable_reason": None, "population": "all", "confidence": 0.6}
        # C3-04: one cap over several codes is ONE code_set rule only when the sentence says it is combined
        # ("inclusive of", "total", ...). Otherwise one cap per code: a per-code reading never over-flags (it can
        # only miss), so it is the safe default for "a maximum of four units per day (codes A, B, C)".
        combined = len(codes) > 1 and bool(post_checks.INCLUSIVE_RE.search(s))

        m = re.search(r"maximum of (\w+(?:-\w+)?) units? per day", low)
        if m and codes and self._num(m.group(1)):
            n = self._num(m.group(1))
            if combined:
                out.append({**base, "statement": f"{'/'.join(codes)} combined: maximum {n} unit(s) per day.",
                            "predicate": {"type": "max_units_per_day", "code_set": codes, "threshold": n},
                            "codes": codes})
            else:
                for c in codes:
                    out.append({**base, "statement": f"{c}: maximum {n} unit(s) per day.",
                                "predicate": {"type": "max_units_per_day", "code": c, "threshold": n}, "codes": [c]})
        m = re.search(r"(?:up to|maximum of|no more than|not to exceed|limited to) "
                      r"(\w+(?:-\w+)?) units? per (contract year|benefit year|month|year)", low)
        if m and codes and self._num(m.group(1)):
            n = self._num(m.group(1))
            period = _period_token(m.group(2))
            for cs in ([codes] if combined else [[c] for c in codes]):
                out.append({**base, "statement": f"{'/'.join(cs)}{' combined' if combined else ''}: maximum {n} "
                                                 f"units per {m.group(2)}.",
                            "predicate": {"type": "max_units_per_period", "code_set": cs, "threshold": n,
                                          "period": period}, "codes": cs})
        if (re.search(r"(?:cannot|can not|may not|must not|shall not) be billed (?:together )?on the same "
                      r"(?:day|date of service)", low) or "prohibited from billing" in low) and len(codes) >= 2:
            # C3-12: a hub sentence ("T1016 cannot be billed on the same day as H0018, H0014 or H0035") pairs the hub
            # with each listed code - never two listed codes with each other; code_b is the barred code (C3-13).
            roles = post_checks.pair_roles(s)
            if roles["kind"] == "hub":
                pairs = [(o, b) for b in roles["subjects"] for o in roles["objects"] if o != b]
            elif roles["kind"] in ("symmetric", "reference") or (carry and not CODE_RE.findall(s)):
                pairs = [(codes[i], codes[j]) for i in range(len(codes)) for j in range(i + 1, len(codes))]
            else:
                pairs = []                     # a category ("any per diem code") is for the model + a reviewer
            # C3-01: scope is explicit; the wide member_day only when the sentence says "same member"
            scope = ("member_provider_day" if post_checks.PER_PROVIDER_RE.search(s) else
                     "member_day" if post_checks.MEMBER_SCOPE_RE.search(s) else "member_provider_day")
            who = "for the same member (any provider)" if scope == "member_day" else "by the same provider for the same member"
            for a, b in pairs:
                out.append({**base, "statement": f"{b} may not be billed on the same day as {a} {who}.",
                            "predicate": {"type": "code_pair_prohibited", "code_a": a, "code_b": b, "scope": scope,
                                          "modifier_indicator": "0", "service_category": "state"}, "codes": [a, b]})
        # a bullet under a "... are not covered:" lead-in is that list's item; elsewhere plain "not covered" is too
        # loose for patterns ("99213 is covered; 99214 is not covered" would bar both codes)
        noncov = r"do not bill|is not a covered service|not an ahcccs[- ]covered service|not reimburs"
        if re.search(noncov + (r"|not covered|non-covered" if lead_in else ""), low) and codes:
            # C3-18: a CPT descriptor in parentheses is not a condition ("99070 (Supplies and materials, except
            # spectacles, ...)" became a conditional-non-coverage lead in the first run, rejected)
            cond = re.search(r"\bunless\b|\bexcept\b|\bprior authorization\b|\bwith (?:a )?pa\b|\bif\b|\bwhen\b|\bonly\b",
                             post_checks.strip_code_descriptors(s).lower())
            for c in codes:
                if cond:
                    # "Do not bill X unless prior authorization is obtained" is CONDITIONAL
                    # non-coverage. The grammar has no condition yet, so this is an honest
                    # lead with the quote - never an unconditional code_not_covered (F11).
                    out.append({**base, "statement": f"{c}: conditional non-coverage ('{cond.group(0)}' clause).",
                                "predicate": {"type": "not_checkable", "reason": "predicate_not_in_grammar"},
                                "codes": [c], "ambiguous": True,
                                "ambiguity_note": f"sentence carries a condition ('{cond.group(0)}'); "
                                                  "conditional coverage is not in the grammar yet",
                                "not_checkable_reason": "predicate_not_in_grammar", "confidence": 0.5})
                else:
                    out.append({**base, "statement": f"{c} is not a covered/reimbursable service.",
                                "predicate": {"type": "code_not_covered", "code": c}, "codes": [c]})
        rng = code_ranges(s)
        if rng and re.search(r"\bmodifiers?\s+[A-Z0-9]{2}\b[^.;]{0,80}?\b(?:cannot|can not|may not|must not|is not|"
                             r"are not|should not)\b", s, re.I):
            # C3-18: only a sentence that BARS a modifier over a code range (the old pattern fired on any 'modifier'
            # near any range). Ranges are not code lists: predicate_not_in_grammar (schema.PROMPT_REASONS).
            out.append({**base, "statement": s, "predicate": {"type": "not_checkable", "reason": "predicate_not_in_grammar"},
                        "codes": [], "ambiguous": True,
                        "ambiguity_note": f"modifier restriction over code range(s) {', '.join('-'.join(r) for r in rng)}; "
                                          "a range is not an enumerated code list",
                        "not_checkable_reason": "predicate_not_in_grammar", "confidence": 0.5})
        if re.search(r"follows medicare'?s correct coding initiative", low):
            out.append({**base, "statement": s, "predicate": {"type": "not_checkable", "reason": "policy_reference"},
                        "codes": [], "not_checkable_reason": "policy_reference", "confidence": 0.7})
        return out


def _stub_section_level(self, text: str) -> list[dict]:
    """Contradictions usually span sentences: 'not covered.' ... 'will be re-instated'."""
    low = text.lower()
    out = []
    if "not covered" in low and re.search(r"re-?instated", low):
        sents = [x for x in self._SENT.split(text.replace("\n", " ")) if re.search(r"re-?instated", x, re.I)]
        if sents:
            out.append({"statement": "Coverage statement is contradictory: the section says both 'not covered' and "
                                     "'re-instated' for the same service/population.",
                        "predicate": {"type": "not_checkable", "reason": "ambiguous_source"}, "codes": [],
                        "verbatim_quote": sents[0].strip(), "derived": False, "derivation_note": None,
                        "ambiguous": True, "ambiguity_note": "text states both 'not covered' and 're-instated'",
                        "not_checkable_reason": "ambiguous_source", "population": "all", "confidence": 0.4})
    return out


StubBackend._section_level = _stub_section_level


class HybridBackend(Backend):
    """Run the deterministic pattern extractor AND a model on the same section,
    then union their proposals. A rule BOTH find is marked corroborated and gets
    a confidence bump; a rule only one finds is kept and flows to review like any
    other. Every proposal still passes the same grounding gate.

    Why combine them rather than pick one:
      * patterns are 100% precise on the shapes they know (a written 'maximum of
        four units per day') and cost nothing - a high-precision floor.
      * the model catches the prose-heavy rules patterns can't express.
      * agreement between two independent methods is the strongest signal a rule
        is real; disagreement surfaces exactly what a reviewer should look at.
      * if the model is down or slow, the patterns still produce a KB - the
        pipeline degrades instead of failing.
    """
    name = "HYBRID"

    def __init__(self, model_backend: Backend, patterns: Backend | None = None,
                 require_model: bool = True):
        """require_model=True (default): a failed model call RAISES, so the section is
        recorded as a model failure and retried next run. It never silently becomes a
        patterns-only result - on 2026-09-20 every model call failed for a whole run and
        the output looked like a successful extraction. require_model=False opts into
        degraded patterns-only output, flagged `degraded` and never cached."""
        self.model_backend = model_backend
        self.patterns = patterns or StubBackend()
        self.require_model = require_model
        self.model = f"{self.patterns.model}+{model_backend.name}:{model_backend.model}"
        self.model_calls = 0
        self.model_failures = 0
        self.model_unparseable = 0            # subset of model_failures (D1)
        self.last_model_error: str | None = None

    @staticmethod
    def _key(r: dict):
        """Full canonical proposition (F12): two proposals are the SAME rule only if
        every semantic field agrees - a monthly and an annual cap on the same code
        are different rules, not corroboration."""
        p = r.get("predicate") or {}
        codes = tuple(sorted(str(c).upper() for c in (r.get("codes") or [])))
        return (p.get("type"), codes, p.get("threshold"), p.get("period"), p.get("scope"),
                str(p.get("code_a") or "").upper(), str(p.get("code_b") or "").upper(),
                str(p.get("code") or "").upper(), str(p.get("modifier") or "").upper(),
                str(p.get("reason") or ""), (r.get("population") or "all").strip().lower())

    @staticmethod
    def _rules(js: str) -> list[dict]:
        """PATTERN half only: our own json.dumps, parsed strictly. A failure here is a bug in
        this file and raises; it used to read as 'no rules' (D1)."""
        return (json.loads(js) or {}).get("rules") or []

    @staticmethod
    def _model_rules(raw: str) -> tuple[list[dict], str | None]:
        """MODEL half, parsed as tolerantly as propose() parses a pure model (fences, harmony
        text). Unparseable output raises ModelOutputUnparseable (D1): the old bare
        `except: return []` turned a fenced or chatty reply into 'the model found nothing',
        which propose() then CACHED - never retried and invisible in the stats."""
        try:
            obj = _extract_json(raw or "")
        except Exception as e:
            raise ModelOutputUnparseable(f"unparseable model output: {e}; reply starts {str(raw)[:120]!r}")
        rules = obj.get("rules") or []
        if not isinstance(rules, list):
            raise ModelOutputUnparseable(f"unparseable model output: 'rules' is {type(rules).__name__}, not a list")
        return [r for r in rules if isinstance(r, dict)], obj.get("no_rule_reason")

    def complete(self, system: str, user: str) -> str:
        pat = self._rules(self.patterns.complete(system, user))
        for r in pat:
            r["source"] = "pattern"
        degraded, model_reason = False, None
        self.model_calls += 1
        try:
            mdl, model_reason = self._model_rules(self.model_backend.complete(system, user))
        except Exception as e:
            self.model_failures += 1
            if isinstance(e, ModelOutputUnparseable):
                self.model_unparseable += 1
            self.last_model_error = f"{type(e).__name__}: {e}"
            if self.require_model or isinstance(e, ModelOutputTruncated):
                # propose() records it as a retryable failure; a TRUNCATED answer is passed up even when
                # patterns-only output is allowed, because splitting the section recovers the model's rules (C3-07)
                raise
            mdl, degraded = [], True
            if self.model_failures in (1, 10, 100) or self.model_failures % 500 == 0:
                print(f"    HYBRID: model backend failed #{self.model_failures} - {self.last_model_error[:300]}\n"
                      f"    HYBRID: continuing with patterns only because require_model=False; "
                      f"this output is NOT a complete extraction")
        for r in mdl:
            r["source"] = "model"

        merged: dict = {}
        for r in pat + mdl:                       # patterns first; model can enrich
            k = self._key(r)
            if k in merged:
                prev = merged[k]
                if r["source"] != prev["source"] and prev["source"] != "pattern+model":
                    # corroboration means two INDEPENDENT methods agree; a duplicate
                    # from the same backend is not evidence and earns no bump.
                    prev["source"] = "pattern+model"
                    prev["confidence"] = round(min(0.97, max(float(prev.get("confidence", 0.5)),
                                                              float(r.get("confidence", 0.5))) + 0.1), 2)
                # D2f: never overwrite the first quote. Patterns come first and quote a whole
                # source sentence that grounds; swapping in a longer model quote (which may be
                # paraphrased) got corroborated rules DROPPED. The other quote is kept for the
                # reviewer only - grounding reads verbatim_quote.
                q = r.get("verbatim_quote")
                if q and _norm(q) != _norm(prev.get("verbatim_quote", "")) and not prev.get("alt_quote"):
                    prev["alt_quote"] = q
            else:
                merged[k] = dict(r)
        return json.dumps({"rules": list(merged.values()), "degraded": degraded,
                           "no_rule_reason": None if merged else (model_reason or "no rule found by patterns or model")})


def make_backend(name: str | None = None, allow_patterns_only: bool = False) -> Backend:
    name = (name or config.LLM_BACKEND).upper()
    if name == "STUB":
        return StubBackend()
    if name == "DBFM":
        return DBFMBackend()
    if name == "HFLOCAL":
        return HFLocalBackend()
    if name == "HYBRID":
        inner = getattr(config, "HYBRID_MODEL_BACKEND", "DBFM").upper()
        if inner in ("HYBRID", "STUB"):
            raise ValueError("config.HYBRID_MODEL_BACKEND must be a model backend (DBFM or HFLOCAL)")
        return HybridBackend(make_backend(inner), require_model=not allow_patterns_only)
    raise ValueError(f"unknown LLM_BACKEND {name!r}")


def healthcheck(backend: Backend) -> tuple[bool, str]:
    """Is the MODEL half alive? One real call, before any chapter is touched.
    STUB is honest about being patterns-only. Returns (ok, detail)."""
    target = backend.model_backend if isinstance(backend, HybridBackend) else backend
    if isinstance(target, StubBackend):
        return True, "STUB: deterministic patterns only - no model. Output is a floor, not an extraction."
    if hasattr(target, "healthcheck"):
        return target.healthcheck()
    try:
        reply = target.complete("Reply with a JSON object.", 'Return exactly {"ok": true}.')
        return True, f"{target.name}:{target.model} OK; reply: {reply.strip()[:120]!r}"
    except Exception as e:
        return False, f"{target.name}:{target.model} FAILED: {type(e).__name__}: {e}"


def model_health(backend: Backend) -> dict:
    """Call/failure counters for the run log (zeros for STUB)."""
    hy = backend if isinstance(backend, HybridBackend) else None
    mb = hy.model_backend if hy else backend
    return {
        "model_backend": f"{mb.name}:{mb.model}",
        "model_route": getattr(mb, "client_route", None),
        "model_calls": hy.model_calls if hy else getattr(mb, "calls", 0),
        "model_failures": hy.model_failures if hy else getattr(mb, "failures", 0),
        "model_retries": getattr(mb, "retries", 0),
        # D1: replies that were not our JSON (counted inside model_failures, so a run where
        # every reply is garbage still trips the all-calls-failed guards)
        "model_unparseable": hy.model_unparseable if hy else 0,
        # C3-07: out-of-budget answers (also inside model_failures; a split usually recovers the section) and
        # token telemetry, so a run shows how close sections come to the budget
        "model_truncated": int(getattr(mb, "truncated", 0)),
        "model_tokens_generated": int(getattr(mb, "tokens_generated", 0)),
        "model_hit_budget_calls": int(getattr(mb, "hit_budget_calls", 0)),
        "model_reasoning": getattr(mb, "reasoning_level", None),
        "last_model_error": (hy.last_model_error if hy else getattr(mb, "last_error", None)),
        "patterns_only_allowed": (not hy.require_model) if hy else isinstance(mb, StubBackend),
    }


# ------------------------------------------------------------- proposing
def _extract_json(text: str) -> dict:
    """Find the last well-formed JSON object in a model response (tolerates fences, harmony channels)."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.S)
    try:
        return json.loads(text)
    except Exception:
        pass
    starts = [m.start() for m in re.finditer(r"\{", text)]
    for st in reversed(starts):
        depth = 0
        for i in range(st, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    try:
                        obj = json.loads(text[st:i + 1])
                        if isinstance(obj, dict) and "rules" in obj:
                            return obj
                    except Exception:
                        break
    raise ValueError("no JSON object with a 'rules' key in model output")


def _json_complete(text: str) -> bool:
    """C3-07: does a final channel hold a COMPLETE JSON object? An answer cut off by the token budget
    ('{"rules": [{...}, {"statement": ...') has balanced INNER objects, so 'some {...} parses' is not enough:
    the extraction object (a 'rules' key) or the whole outer object must parse."""
    try:
        _extract_json(text or "")
        return True
    except Exception:
        pass
    t = (text or "").strip()
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b < a:
        return False
    try:
        return isinstance(json.loads(t[a:b + 1]), dict)
    except Exception:
        return False


# C3-07: a section whose answer does not fit the budget even after the retry is split in two at the paragraph
# boundary nearest its middle, each half extracted on its own; at most this many levels (4 pieces).
SPLIT_MAX_DEPTH = 2
_SPLIT_MIN_CHARS = 200


def split_section(section: dict) -> list[dict] | None:
    """Two halves of a section, cut at the paragraph boundary (else the sentence boundary) nearest the middle.
    Each half keeps heading, pages and section_id; only the MODEL sees a half - grounding always reads the
    whole section, so a quote that crosses the cut still grounds. None if the section cannot be split."""
    text = section.get("text") or ""
    if len(text) < _SPLIT_MIN_CHARS:
        return None
    cuts = [m.end() for m in re.finditer(r"\n+", text) if 0 < m.end() < len(text)]
    if not cuts:
        cuts = [a for a, _ in sentence_spans(text)][1:]
    if not cuts:
        return None
    cut = min(cuts, key=lambda c: abs(c - len(text) / 2))
    halves = [text[:cut].strip(), text[cut:].strip()]
    if not all(halves):
        return None
    return [dict(section, text=h, text_hash=hashlib.sha256(h.encode()).hexdigest()[:16], split_part=f"{i + 1}/2")
            for i, h in enumerate(halves)]


def propose(section: dict, inv: dict, backend: Backend, info: dict | None = None,
            _depth: int = 0) -> tuple[list[dict], str | None]:
    """(proposals, why). `info` (optional) receives {"pieces": n, "split_depth": d}: how many model-sized pieces the
    section needed (1 = no split)."""
    info = info if info is not None else {}
    info.setdefault("pieces", 1)
    info.setdefault("split_depth", 0)
    user = USER_TEMPLATE.format(chapter=inv["chapter"], title=inv["title"], heading=section["heading"],
                                page_start=section["page_start"], page_end=section["page_end"],
                                revision=inv.get("revision_date") or "unknown", text=section["text"])
    try:
        raw = backend.complete(SYSTEM_PROMPT, user)
    except ModelOutputUnparseable as e:          # HYBRID's model half answered, but not in JSON (D1)
        return [], str(e)                        # starts "unparseable" -> retryable, counted as such
    except ModelOutputTruncated as e:            # C3-07: out of budget even after the retry -> split the section
        halves = split_section(section) if _depth < SPLIT_MAX_DEPTH else None
        if not halves:
            return [], (f"backend error: {type(e).__name__}: {e} (split depth {_depth}: "
                        f"{'cannot split further' if _depth else 'section cannot be split'})")
        info["pieces"] += 1
        info["split_depth"] = max(info["split_depth"], _depth + 1)
        out, reasons = [], []
        for h in halves:
            props, why = propose(h, inv, backend, info, _depth + 1)
            if _retryable(why):
                return [], why                   # a half failed: the whole section is retried next run
            out += props
            if why:
                reasons.append(why)
        return out, (None if out else ("; ".join(dict.fromkeys(reasons)) or "no rule in either half"))
    except Exception as e:                       # endpoint timeout etc.: a retryable error, never a crash
        return [], f"backend error: {type(e).__name__}: {e}"
    try:
        obj = _extract_json(raw)
    except Exception as e:
        return [], f"unparseable model output: {e}"
    if obj.get("degraded"):                      # HYBRID ran patterns only; the model half failed
        return _clean_rules(obj), "degraded: model backend failed; patterns only"
    return _clean_rules(obj), obj.get("no_rule_reason")


def _clean_rules(obj: dict) -> list[dict]:
    clean = []
    for r in obj.get("rules") or []:
        if not isinstance(r, dict) or not isinstance(r.get("predicate"), dict):
            continue
        r.setdefault("codes", [])
        r.setdefault("confidence", 0.5)
        r.setdefault("population", "all")
        clean.append(r)
    return clean


# outcomes that must NOT be cached: a rerun has to retry them (F14)
def _retryable(why: str | None) -> bool:
    return bool(why) and (why.startswith("unparseable") or why.startswith("backend error")
                          or why.startswith("degraded"))


def _failure_kind(why: str) -> str:
    if why.startswith("backend error"):
        return "model_failed"
    if why.startswith("degraded"):
        return "degraded_patterns_only"
    return "unparseable"


# ------------------------------------------------------------- grounding
def _norm(s: str) -> str:
    # C3-11: every dash / quote / space variant (policy_docs.CHAR_MAP: U+2010-2015, U+2212, U+2011 from gpt-oss,
    # NBSP, thin spaces) and the bullet glyphs map the same way in the quote and in the source
    s = clean_chars(s).lower()
    return re.sub(r"\s+", " ", s).strip().rstrip(".;:")


def _sentences(text: str) -> list[str]:
    t = (text or "").replace("\n", " ")
    return [t[a:b] for a, b in _sentence_spans(text or "")]


def _sentence_spans(t: str) -> list[tuple[int, int]]:
    """(start, end) of each sentence of `t`, so [t[a:b] for a, b in spans] == _sentences(t). Offsets
    let grounding return the ORIGINAL source text for a quote (D2d) and find its neighbours.
    C3-16: policy_docs.sentence_spans - also splits at newlines (paragraphs, bullets) and inline bullets, and
    not after abbreviations. Pass the text WITH its newlines; the offsets also index text.replace('\\n', ' ')."""
    return sentence_spans(t)


def _norm_map(t: str) -> tuple[str, list[int]]:
    """_norm without the trailing-punctuation strip, plus, for every normalised character,
    its index in `t`. Maps an exact normalised match back to the source's own characters."""
    out, idx, prev_space = [], [], True
    for i, ch in enumerate(t):
        for c in clean_chars(ch).lower():               # C3-11: same table as _norm
            if c.isspace():
                if prev_space:
                    continue
                c, prev_space = " ", True
            else:
                prev_space = False
            out.append(c)
            idx.append(i)
    while out and out[-1] == " ":
        out.pop()
        idx.pop()
    return "".join(out), idx


# D2a: an exact match on ANY substring used to count, so "is obtained" grounded at 1.0.
GROUND_MIN_QUOTE_WORDS = getattr(config, "GROUND_MIN_QUOTE_WORDS", 6)
# C3-17: one word shorter is still evidence when the quote is itself an obligation ("Hospice services require
# prior authorization.") or names a code - D2a dropped such 5-word sentences
_OBLIGATION_RE = re.compile(r"\b(must|may not|cannot|can not|shall|limited to|require[sd]?|not covered|prohibited|"
                            r"denied|do not|does not|will not)\b")
# D2c: tokens that make a billing sentence conditional. A quote that cuts them off turns
# "do not bill X unless PA" into an unconditional non-coverage rule.
_CONDITION_RE = re.compile(r"\b(unless|except|if|when|only|provided|prior authorization|excluding|does not apply)\b")
# C3-19: "once" / "twice" are numbers in a limit ("billing will be submitted once per month")
_FREQ_WORDS = {"once": 1, "twice": 2, "thrice": 3}
_NUMBER_WORDS = {**WORD_NUMBERS, **_FREQ_WORDS}
_WORD_NUMBER_RE = re.compile(r"\d+|\b(?:" + "|".join(re.escape(w) for w in
                                                    sorted(_NUMBER_WORDS, key=len, reverse=True)) + r")\b")
_THOUSANDS_RE = re.compile(r"(?<=\d),(?=\d{3}\b)")


def _code_in(code: str, text_norm: str) -> bool:
    """C3-19: a code is present only as a whole token ('9896' is not in '98960')."""
    return re.search(rf"(?<![a-z0-9]){re.escape(str(code).lower())}(?![a-z0-9])", text_norm) is not None


def _threshold_present(n, text_norm: str) -> bool:
    if n is None:
        return True
    try:
        n = int(n)
    except (TypeError, ValueError):
        return False
    t = _THOUSANDS_RE.sub("", text_norm or "")         # C3-19: "$1,000" states 1000
    if re.search(rf"(?<![\d.]){n}(?!\d|\.\d)", t):    # whole number only: 1 is not in "1.5" / "0.1"
        return True
    words = [w for w, v in _NUMBER_WORDS.items() if v == n]
    return any(re.search(rf"\b{re.escape(w)}\b", t) for w in words)


# Words that flip or condition the meaning of a billing sentence. A fuzzy quote match
# (ratio >= 0.85) is only trusted when the quote and the source sentence agree on
# these EXACTLY, plus every number: "is covered" vs "is not covered" scores 0.9 on
# characters and means the opposite (F11).
_MEANING_TOKENS = {
    "not", "no", "never", "cannot", "non", "without", "unless", "except", "excluding",
    "only", "prior", "authorization", "authorized", "if", "when", "must", "may", "shall",
    "per", "day", "month", "year", "week", "lifetime", "each", "maximum", "minimum",
}


def _meaning_signature(s_norm: str) -> tuple:
    """Meaning tokens + every number. Numbers include WORD numbers (D2e): comparing digits only
    let "maximum of four units" vs "maximum of units" pass as a harmless fuzzy match. Words
    map to their value, so "four" and "4" agree."""
    toks = re.findall(r"[a-z]+|\d+", s_norm)
    s_num = _THOUSANDS_RE.sub("", s_norm)                       # "$1,000" and "$1000" agree
    nums = tuple(str(int(m)) if m.isdigit() else str(_NUMBER_WORDS[m]) for m in _WORD_NUMBER_RE.findall(s_num))
    return (tuple(t for t in toks if t in _MEANING_TOKENS), nums)


def _predicate_codes(p: dict) -> list[str]:
    out = []
    for k in ("code_a", "code_b", "code"):
        if p.get(k):
            out.append(str(p[k]).upper())
    out += [str(c).upper() for c in (p.get("code_set") or [])]
    return list(dict.fromkeys(out))


def predicate_valid(p: dict, strict_reason: bool = False, origin: str | None = None) -> tuple[bool, str]:
    """Structural check against the closed grammar. Thin wrapper: the contract lives in
    schema.validate_predicate so extraction, the gate, review ingest and the compiler agree."""
    return schema.validate_predicate(p, strict_reason=strict_reason, origin=origin)


def _integral(v) -> int | None:
    """int, integral float (4.0) or digit string ('4') -> int; anything else -> None."""
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        return int(v) if v.is_integer() else None
    if isinstance(v, str) and v.strip().isdigit():
        return int(v.strip())
    return None


def ground(proposal: dict, section: dict) -> dict:
    """Deterministic verification of one proposal against its source section.

    This is an evidence gate, not a semantic proof: it confirms the quote exists,
    every code the predicate names is in the section, and the threshold appears in
    the QUOTED SENTENCE (not merely somewhere in the section). Two tightenings over
    the PoC, both from external review:
      * codes: a proposal is dropped unless ALL its codes are in the source. Passing
        on 'some' let a real code + an invented code through together.
      * threshold: matched against the quoted sentence, so a section that says
        "4 units" in one rule and "24 units" in another cannot ground 24 onto the
        first. A threshold not found in the quote is kept but flagged (derived).
    Semantic correspondence (does the quote actually assert THIS relation?) is still
    the reviewer's job; see the review workbook's editable predicate.

    Evidence-quality checks (D2), none of which lose recall:
      * a quote under GROUND_MIN_QUOTE_WORDS words that does not name every predicate
        code is DROPPED - two words match anywhere and evidence nothing (D2a);
      * codes_in_quote_window: are the codes stated in the matched sentence or one either
        side? The section-level code check stays the drop gate (codes often sit in a
        heading or list); a far-away code is kept but flagged and capped (D2b);
      * quote_truncates_condition: the source sentence carries unless/except/if/... that
        the quote cut off - kept, flagged ambiguous, capped (D2c);
      * source_quote: the SOURCE text the quote resolved to, original casing. For a fuzzy
        match that is the source sentence, never the model's paraphrase (D2d).
      * source_sentences: the FULL source sentence(s) the quote lies in - what post_checks reads.
    C3-11/16/17/19: dashes / spaces normalised, newline- and bullet-aware sentences, a quote may
    fuzzy-match two adjacent sentences (a lead-in and its bullet), codes match as whole tokens, and a
    5-word quote that states an obligation or names a code is evidence.
    """
    raw = section["text"] or ""
    t = raw.replace("\n", " ")                       # 1:1 replace, so spans of `raw` index `t` too
    text_norm = _norm(t)
    spans = _sentence_spans(raw)
    sents = [t[a:b] for a, b in spans]
    quote = proposal.get("verbatim_quote") or ""
    qn = _norm(quote)
    matched = ""                       # the source sentence the quote resolves to
    source_quote, hit = None, []       # original-text span; indices of the sentences it lies in
    if qn and qn in text_norm:
        quote_found, matched = "exact", qn
        tn, idx = _norm_map(t)
        pos = tn.find(qn)
        if pos >= 0:
            a, b = idx[pos], idx[pos + len(qn) - 1] + 1
            if b < len(t) and t[b] in ".;":
                b += 1                                  # _norm stripped the closing stop
            source_quote = t[a:b]
            hit = [i for i, (sa, sb) in enumerate(spans) if sa < b and sb > a]
    elif qn:
        # C3-16: candidates are single sentences and adjacent pairs (a lead-in "... are not covered:" + its bullet)
        best_ratio, best = 0.0, None
        for i in range(len(sents)):
            for j in (i, i + 1):
                if j >= len(sents):
                    continue
                r = difflib.SequenceMatcher(None, qn, _norm(" ".join(sents[i:j + 1]))).ratio()
                if r > best_ratio + (0.02 if j > i else 0.0):  # prefer the single sentence on near ties
                    best_ratio, best = r, (i, j)
        best_sent = _norm(" ".join(sents[best[0]:best[1] + 1])) if best else ""
        quote_found = "fuzzy" if best_ratio >= 0.85 else "none"
        matched = best_sent if quote_found == "fuzzy" else ""
        if quote_found == "fuzzy" and _meaning_signature(qn) != _meaning_signature(matched):
            # characters agree, meaning may not: negation / condition / number drift
            quote_found, matched = "drift", best_sent
        if quote_found == "fuzzy":
            source_quote, hit = t[spans[best[0]][0]:spans[best[1]][1]], list(range(best[0], best[1] + 1))
    else:
        quote_found = "none"

    p = proposal.get("predicate") or {}
    codes = _predicate_codes(p) + [str(c).upper() for c in proposal.get("codes") or []]
    codes = list(dict.fromkeys(codes))
    if codes:
        missing = [c for c in codes if not _code_in(c, text_norm)]
        codes_found = "all" if not missing else ("some" if len(missing) < len(codes) else "none")
    else:
        codes_found, missing = "n/a", []
    # D2b: codes near the quote = the matched sentence(s) plus one sentence either side
    if hit:
        window = _norm(" ".join(sents[max(0, min(hit) - 1):max(hit) + 2]))
    else:
        window = text_norm             # not located (unreachable for exact/fuzzy): section-level only
    codes_in_window = all(_code_in(c, window) for c in codes) if codes else None
    full = t[spans[min(hit)][0]:spans[max(hit)][1]] if hit else None
    # D2c: the full source sentence(s) around an exact quote; conditions the quote cut off
    condition_sentence, truncates = None, False
    if quote_found == "exact" and hit:
        omitted = sorted({m for m in _CONDITION_RE.findall(_norm(post_checks.strip_code_descriptors(full)))
                          if not re.search(rf"\b{m}\b", qn)})
        if omitted:
            truncates, condition_sentence = True, full
    pcodes = _predicate_codes(p)
    n_words = len(qn.split())
    too_short = bool(qn) and n_words < GROUND_MIN_QUOTE_WORDS and \
        not (pcodes and all(_code_in(c, qn) for c in pcodes)) and \
        not (n_words >= GROUND_MIN_QUOTE_WORDS - 1 and (CODE_RE.search(quote) or _OBLIGATION_RE.search(qn)))
    # threshold must appear in the QUOTED sentence, not anywhere in the section
    thr_scope = matched or (qn if quote_found == "exact" else "")
    thr_ok = _threshold_present(p.get("threshold"), thr_scope) if "threshold" in p else None
    valid, why = predicate_valid(p)

    score = {"exact": 0.5, "fuzzy": 0.35, "drift": 0.0, "none": 0.0}[quote_found]
    score += {"all": 0.25, "n/a": 0.25, "some": 0.10, "none": 0.0}[codes_found]
    score += 0.15 if thr_ok in (True, None) else 0.05
    score += 0.10 if valid else 0.0

    keep, reason = True, None
    if quote_found == "none":
        keep, reason = False, "quote not found in source"
    elif quote_found == "drift":
        keep, reason = False, ("quote differs from source sentence in negation/condition/number "
                               f"tokens (nearest: {matched[:120]!r})")
    elif too_short:
        keep, reason = False, "quote too short to evidence the rule"
    elif not valid:
        keep, reason = False, f"invalid predicate: {why}"
    elif codes_found == "none":
        keep, reason = False, "codes not in source"
    elif codes_found == "some":
        keep, reason = False, f"not all codes in source (missing {', '.join(missing)})"
    return {"quote_found": quote_found, "codes_found": codes_found, "threshold_found": thr_ok,
            "predicate_valid": valid, "score": round(score, 2), "keep": keep, "drop_reason": reason,
            "codes": codes, "source_quote": source_quote, "codes_in_quote_window": codes_in_window,
            "quote_truncates_condition": truncates, "condition_sentence": condition_sentence,
            "source_sentences": full, "sentence_index": [min(hit), max(hit)] if hit else None}


# -------------------------------------------------------------- drafts
def semantic_key(chapter: str, p: dict, codes: list[str], population: str = "all",
                 effective_date: str | None = None, quote: str | None = None,
                 end_date: str | None = None) -> str:
    """Logical identity of a proposed rule (F06). Includes population and effective
    date so a scope or date change re-enters review instead of inheriting the old
    decision. For UNCODED proposals (leads) the normalised quote is part of the key:
    two different obligations that both say "requires documentation" must not
    collapse into one. Statement wording is deliberately NOT in the key (the model
    rephrases; the rule does not change).
    C3-02: the quote is part of the key for EVERY not_checkable rule, coded or not - two different T1016
    leads ("must be billed on a CMS 1500" / "group claims use member IDs") shared one key and one was lost
    silently. C3-06: an end date is part of the identity (added only when set, so keys without one are
    unchanged)."""
    sig = {"c": str(chapter), "p": p, "codes": sorted(codes),
           "pop": (population or "all").strip().lower(), "eff": effective_date}
    if end_date:
        sig["end"] = end_date
    if not codes or (p or {}).get("type") == "not_checkable":
        sig["q"] = _norm(quote or "")
    return hashlib.sha256(json.dumps(sig, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _effective_from_quote(quote: str) -> str | None:
    """First date in the quote that is introduced by an effective-date cue.

    Handles the phrasings AHCCCS actually uses, e.g. 'effective 4/1/2018',
    'Beginning with dates of service on and after April 1st, 2018', and
    'effective for dates of service on or after January 1, 2020'. A date with no
    such cue is ignored (a random date in the prose is not an effective date).
    C3-06: directional (policy_docs.date_cues) - 'prior to <date>' / 'before <date>' is an END date and is
    never returned here (it used to be, so the rule would flag exactly the wrong period)."""
    return next((c["date"] for c in date_cues(quote) if c["kind"] == "effective"), None)


def _end_from_quote(quote: str) -> str | None:
    """C3-06: inclusive end date: 'prior to X' / 'before X' -> X - 1 day; 'through X' / 'on or before X' -> X."""
    return next((c["date"] for c in date_cues(quote) if c["kind"] == "end"), None)


def _iso_or_none(v) -> str | None:
    if v in (None, ""):
        return None
    try:
        return datetime.strptime(str(v).strip()[:10], "%Y-%m-%d").date().isoformat()
    except ValueError:
        return None


def rule_dates(proposal: dict, quote: str) -> tuple[str | None, str | None, list[str]]:
    """(effective_date, end_date, notes) of a draft (C3-06).
    The model's effective_date / end_date are used when they are GROUNDED in the quote: the quote has a date
    with a cue of the same direction that gives exactly that day. If the model gave a grounded date, its
    choice stands for both fields (a transition sentence 'Prior to X ... Effective X ...' carries both cues
    and only the model knows which one this rule is). Otherwise the cue parser decides; if its window is empty
    (end before start: a transition sentence), the effective date is kept and the conflict is noted."""
    cues = date_cues(quote)
    effs = [c["date"] for c in cues if c["kind"] == "effective"]
    ends = [c["date"] for c in cues if c["kind"] == "end"]
    notes = []
    m_eff_raw = proposal.get("effective_date") or proposal.get("effective_from")
    m_end_raw = proposal.get("end_date") or proposal.get("effective_to")
    m_eff, m_end = _iso_or_none(m_eff_raw), _iso_or_none(m_end_raw)
    for raw, iso, name in ((m_eff_raw, m_eff, "effective_date"), (m_end_raw, m_end, "end_date")):
        if raw not in (None, "") and iso is None:
            notes.append(f"model {name} {raw!r} is not an ISO date; ignored")
    g_eff = m_eff if m_eff in effs else None
    g_end = m_end if m_end in ends else None
    if m_eff and not g_eff:
        notes.append(f"model effective_date {m_eff} is not grounded in the quote")
    if m_end and not g_end:
        notes.append(f"model end_date {m_end} is not grounded in the quote")
    if g_eff or g_end:
        eff, end = g_eff, g_end
    else:
        eff, end = (effs[0] if effs else None), (ends[0] if ends else None)
        if (m_eff or m_end) and (eff or end):
            notes.append(f"dates from the quote's cues: effective {eff}, end {end}")
    if eff and end and end < eff:
        notes.append(f"the quote states a transition (ends {end}, effective {eff}); the effective date is kept - "
                     f"a reviewer must confirm which period this rule covers")
        end = None
    return eff, end, notes


def to_draft_row(proposal: dict, g: dict, section: dict, inv: dict, backend: Backend, run_id: str) -> dict:
    from state_rules import rule_to_row
    p = dict(proposal["predicate"])
    t = p["type"]
    codes = g["codes"]
    # D2d: verbatim_quote is what the SOURCE says (original casing); the model's own text is
    # kept separately only when it differs. A fuzzy match used to store the paraphrase.
    model_q = proposal.get("verbatim_quote") or ""
    src_q = g.get("source_quote") or model_q
    model_quote = model_q if (model_q and _norm(model_q) != _norm(src_q)) else None
    # D2b provenance: HYBRID tags every proposal; a pure backend is either patterns or a model.
    source = proposal.get("source") or ("pattern" if isinstance(backend, StubBackend) else
                                        None if isinstance(backend, HybridBackend) else "model")
    ambiguous = bool(proposal.get("ambiguous")) or (g["threshold_found"] is False)
    anote = proposal.get("ambiguity_note")
    if g["threshold_found"] is False:
        anote = ((anote + " ") if anote else "") + "threshold not found verbatim in source; treat as derived."
    capped = False
    if g.get("codes_in_quote_window") is False:                       # D2b
        anote = ((anote + " ") if anote else "") + "codes not stated near the quoted sentence."
        capped = True
    if g.get("quote_truncates_condition"):                            # D2c
        ambiguous, capped = True, True
        anote = ((anote + " ") if anote else "") + \
            f"source sentence carries a condition the quote omits: {g.get('condition_sentence')}"
    # C3 post-checks: every action is in the grounding JSON; a short note goes to the reviewer, and anything that
    # needs a human look caps the confidence (the workbook is sorted lowest confidence first)
    actions = g.get("post_checks") or []
    if actions:
        anote = ((anote + " ") if anote else "") + post_checks.summarize(actions)
        if any(a.get("attention") for a in actions):
            capped = True
        if any(a.get("action") == "downgrade" for a in actions):
            ambiguous = True
    # C3-06: dates grounded in the SOURCE quote, directional ('prior to X' is an end date)
    eff, end, date_notes = rule_dates(proposal, src_q)
    if date_notes:
        anote = ((anote + " ") if anote else "") + "dates: " + "; ".join(date_notes) + "."
        if any("transition" in n for n in date_notes):
            ambiguous, capped = True, True
    if t == "not_checkable" and p.get("reason") and proposal.get("not_checkable_reason") not in (None, p.get("reason")):
        proposal = dict(proposal, not_checkable_reason=p.get("reason"))   # one reason per rule: the predicate's
    not_reason = proposal.get("not_checkable_reason") or (p.get("reason") if t == "not_checkable" else None)
    machine = t in schema.PREDICATE_TYPES_COMPILED and not not_reason
    pages = (f"page {section['page_start']}" if section["page_start"] == section["page_end"]
             else f"pages {section['page_start']}-{section['page_end']}")
    notes = f'Verbatim: "{src_q.strip()}"'
    if proposal.get("derived") and proposal.get("derivation_note"):
        notes += f" Derived: {proposal['derivation_note']}"
    if proposal.get("population") and proposal["population"] != "all":
        notes += f" Population: {proposal['population']}."
    if source:
        notes += f" Found by: {source}."

    rule = schema.Rule(
        origin="extracted", plane="coverage_scope", binding_status="state_policy",
        statement=(proposal.get("statement") or "").strip(),
        predicate=p, codes=codes, population=proposal.get("population") or "all",
        machine_checkable=machine, not_checkable_reason=not_reason,
        required_claim_fields=_FIELDS_BY_TYPE.get(t, []),
        ambiguity_flag=ambiguous, ambiguity_note=anote,
        source_doc=f"AHCCCS FFS Provider Billing Manual, Chapter {inv['chapter']} {inv['title']}",
        source_locator=f"{pages} — {section['heading']}", source_url=inv["url"],
        doc_version=f"rev {inv.get('revision_date') or 'unknown'}", doc_hash=inv["doc_hash"],
        effective_date=eff, end_date=end,
        notes=notes,
    )
    row = rule_to_row(rule, chapter=str(inv["chapter"]), review_status="draft",
                      review_note=f"extracted by {backend.name}:{backend.model} prompt {PROMPT_VERSION}")
    # keyed on the source text: identical to the old key for exact matches (_norm is the same),
    # and a model rephrasing the same sentence no longer mints a new uncoded lead
    key = semantic_key(inv["chapter"], p, codes, population=rule.population,
                       effective_date=rule.effective_date, quote=src_q, end_date=rule.end_date)
    llm_conf = float(proposal.get("confidence") or 0.5)
    conf = round(0.5 * llm_conf + 0.5 * g["score"], 2)
    row.update({
        "rule_id": f"EXT-{key}",
        "extraction_key": key,
        "verbatim_quote": src_q or None,
        "model_quote": model_quote,
        "extraction_source": source,
        "section_id": section["section_id"],
        "extraction_confidence": min(conf, 0.5) if capped else conf,
        "extraction_run_id": run_id,
        "extraction_backend": f"{backend.name}:{backend.model}",
        "grounding": json.dumps(g, default=str),
    })
    return row


# ---------------------------------------------------------- orchestrate
def _generation_tag(backend: Backend) -> str:
    """C3-08: what else decides the model's answer besides the text, prompt and model. Raising the reasoning effort
    (or the token budget) to recover misses used to reuse the low-effort answers from the cache. '' for backends
    without such settings, so STUB keys keep their shape."""
    mb = backend.model_backend if isinstance(backend, HybridBackend) else backend
    if isinstance(mb, HFLocalBackend):
        return f"|reasoning={mb.reasoning_level}|budget={mb.budget()}|retry_x={config.RETRY_BUDGET_FACTOR}"
    if isinstance(mb, DBFMBackend):
        return f"|max_tokens={config.LLM_MAX_TOKENS}|temperature={config.LLM_TEMPERATURE}"
    lvl = getattr(mb, "reasoning_level", None)
    return f"|reasoning={lvl}" if lvl else ""


def cache_key(section: dict, backend: Backend) -> str:
    """Cache key of one section's model answer: text hash | prompt version | backend | model | generation settings."""
    return f"{section['text_hash']}|{PROMPT_VERSION}|{backend.name}|{backend.model}{_generation_tag(backend)}"


def _model_counters(backend: Backend) -> tuple[int, int]:
    mb = backend.model_backend if isinstance(backend, HybridBackend) else backend
    return int(getattr(mb, "tokens_generated", 0)), int(getattr(mb, "hit_budget_calls", 0))


def _cache_read(entry) -> tuple[list[dict], str | None]:
    """Cache values are {"proposals": [...], "no_rule_reason": str|None} since D11; entries
    written before that are a plain proposals list (reason unknown)."""
    if isinstance(entry, dict):
        return copy.deepcopy(entry.get("proposals") or []), entry.get("no_rule_reason")
    return copy.deepcopy(entry or []), None


def extract_chapter(sections: list[dict], inv: dict, backend: Backend, run_id: str,
                    only_candidates: bool = True, cache: dict | None = None,
                    log_fn=print, checkpoint_fn=None, checkpoint_every: int | None = None,
                    outcomes: list | None = None
                    ) -> tuple[list[dict], list[dict], dict]:
    """Returns (draft_rows, dropped, stats). `cache` maps cache_key ->
    {"proposals": [...], "no_rule_reason": ...} (old plain-list values are still read).

    checkpoint_fn(cache) is called after every `checkpoint_every` NEW model calls (cache
    hits do not count) so a crash mid-chapter loses at most that many calls - the cache
    is the expensive artifact; drafts are re-derived from it for free on the next run.

    outcomes (D11): if a list is passed, ONE row per section is appended - skipped by the
    pre-filter, no rules (with the model's reason), proposals (grounded/dropped counts) or
    failed_retryable. Recall is measured from these, not assumed: before D11 a section that
    reached the model and yielded nothing was recorded nowhere, and skips were capped at
    100 headings. Passed in (not put in stats) so the log row stays one flat row per chapter.

    Per proposal (C3): post_checks.repair -> ground -> post_checks.check -> post_checks.section_pass ->
    draft. A post-check DROP or a merge DUPLICATE goes to `dropped` with its reason; every action is in the
    draft's grounding JSON under "post_checks". The cache holds the model's proposals, not the checked ones,
    so changing a check never needs a model call. Two drafts with the same extraction_key in one run: the
    higher-confidence one is kept and the other is written to `dropped` as "duplicate of <key>" (C3-02)."""
    cache = cache if cache is not None else {}
    outcomes = outcomes if outcomes is not None else []
    checkpoint_every = checkpoint_every or getattr(config, "CACHE_FLUSH_EVERY", 0)
    use_checks = getattr(config, "POST_CHECKS", True)
    new_calls_since_ckpt = 0
    drafts, dropped = [], []
    stats = {"chapter": inv["chapter"], "doc_hash": inv["doc_hash"], "run_id": run_id,
             "backend": f"{backend.name}:{backend.model}", "prompt_version": PROMPT_VERSION,
             "cache_key_tag": _generation_tag(backend),
             "sections": len(sections), "sections_candidate": 0, "sections_from_cache": 0,
             "sections_skipped_noncandidate": 0, "sections_no_rules": 0, "sections_with_proposals": 0,
             "proposals": 0, "grounded": 0, "dropped": 0,
             "unparseable": 0, "model_failed": 0, "degraded_patterns_only": 0,
             # C3: always present and always int, so the appended log table keeps one type per column
             "skipped_chars": 0, "duplicates": 0, "sections_split": 0, "tokens_generated": 0, "hit_budget_calls": 0,
             "post_check_downgrade": 0, "post_check_rescope": 0, "post_check_map_reason": 0, "post_check_drop": 0,
             "post_check_duplicate": 0, "post_check_flag": 0,
             "started_at": datetime.now().isoformat(timespec="seconds")}
    pctx = {"chapter": str(inv["chapter"]), "chapter_title": inv.get("title")}

    def _outcome(s, outcome, reason=None, n_prop=0, n_ok=0, n_drop=0, from_cache=False, tokens=0, hit=False,
                 pieces=0, n_checks=0):
        outcomes.append({"chapter": str(inv["chapter"]), "section_id": s.get("section_id"),
                         "heading": s.get("heading"), "page_start": s.get("page_start"),
                         "page_end": s.get("page_end"), "doc_hash": inv["doc_hash"], "run_id": run_id,
                         "outcome": outcome, "reason": reason, "n_proposals": n_prop, "n_grounded": n_ok,
                         "n_dropped": n_drop, "from_cache": from_cache,
                         # C3-07 / C3-17: section size, model tokens, budget hits, split pieces, post-check actions
                         "n_chars": len(s.get("text") or ""), "tokens_generated": int(tokens),
                         "hit_budget": bool(hit), "split_pieces": int(pieces), "n_post_check_actions": int(n_checks)})

    def _drop(s, pr, g, reason, actions=None):
        # D11: codes / doc / pages make a refused proposal traceable to its source
        dropped.append({"chapter": inv["chapter"], "section_id": s["section_id"], "heading": s["heading"],
                        "statement": pr.get("statement"), "predicate": json.dumps(pr.get("predicate")),
                        "codes": json.dumps(g["codes"]), "verbatim_quote": pr.get("verbatim_quote"),
                        "drop_reason": reason, "extraction_source": pr.get("source"),
                        "doc_hash": inv["doc_hash"], "page_start": s.get("page_start"),
                        "page_end": s.get("page_end"), "run_id": run_id,
                        "post_checks": json.dumps(actions or g.get("post_checks") or [], default=str)})
        stats["dropped"] += 1

    for s in sections:
        if only_candidates and not s.get("has_rule_signal"):
            # the pre-filter is a hard recall gate: a skipped section never reaches the
            # model. Record what it dropped so recall can be measured, not assumed.
            stats["sections_skipped_noncandidate"] += 1
            stats["skipped_chars"] += len(s.get("text") or "")
            _outcome(s, "skipped_prefilter", f"no rule signal (score {s.get('rule_signal')})")
            continue
        stats["sections_candidate"] += 1
        ck = cache_key(s, backend)
        from_cache = ck in cache
        info = {"pieces": 1, "split_depth": 0}
        tok0, hit0 = _model_counters(backend)
        if from_cache:
            proposals, why = _cache_read(cache[ck])
            stats["sections_from_cache"] += 1
            info["pieces"] = 0
        else:
            proposals, why = propose(s, inv, backend, info=info)
            if info["pieces"] > 1:
                stats["sections_split"] += 1
            if _retryable(why):
                # F14: a failed or degraded call is NOT a "no rules" result. Leave it out
                # of the cache so the next run retries instead of reporting a cache hit.
                kind = _failure_kind(why)
                stats[kind] += 1
                stats.setdefault("retryable_sections", []).append(
                    {"section_id": s.get("section_id"), "heading": s.get("heading"), "kind": kind, "why": why})
                if kind != "model_failed" or stats["model_failed"] in (1, 5, 25, 100):
                    log_fn(f"    [{s['heading'][:40]}] {why[:300]}")
            else:
                # D11: the reason is cached too, so a cache hit can still say WHY no rule
                cache[ck] = {"proposals": copy.deepcopy(proposals), "no_rule_reason": why}
                new_calls_since_ckpt += 1
                if checkpoint_fn and checkpoint_every and new_calls_since_ckpt >= checkpoint_every:
                    try:
                        checkpoint_fn(cache)
                        stats["checkpoints"] = stats.get("checkpoints", 0) + 1
                    except Exception as e:                  # never let a checkpoint kill the run
                        log_fn(f"    checkpoint failed: {type(e).__name__}: {e}")
                    new_calls_since_ckpt = 0
        tok1, hit1 = _model_counters(backend)
        stats["tokens_generated"] += tok1 - tok0
        stats["hit_budget_calls"] += hit1 - hit0
        stats["proposals"] += len(proposals)
        n_ok = n_drop = n_checks = 0
        kept = []
        for pr in proposals:
            pr, rep = post_checks.repair(pr) if use_checks else (pr, [])
            g = ground(pr, s)
            if g["keep"]:
                kept.append((pr, g, rep))
            else:
                _drop(s, pr, g, g["drop_reason"], rep)
                n_drop += 1
        if kept and use_checks:
            # C3: deterministic meaning checks AFTER grounding (post_checks.py): conditional modifiers, context-
            # limited non-coverage, invented / hub-spoke pairs, combined caps, scope, exception, discretionary
            pctx["heading"] = s.get("heading")
            items = [post_checks.check(pr, g, s["text"], pctx) for pr, g, _ in kept]
            items = post_checks.section_pass(items, s["text"], pctx)
        else:
            items = [(pr, []) for pr, _, _ in kept]
        for (pr2, acts), (_, g, rep) in zip(items, kept):
            acts = rep + acts
            n_checks += len(acts)
            for a in acts:
                stats[f"post_check_{a['action']}"] = stats.get(f"post_check_{a['action']}", 0) + 1
            g2 = dict(g, post_checks=acts)
            if pr2.get("pre_check_predicate") is not None:
                g2["pre_check_predicate"] = pr2["pre_check_predicate"]
            g2["codes"] = list(dict.fromkeys(_predicate_codes(pr2["predicate"]) +
                                             [str(c).upper() for c in pr2.get("codes") or []] +
                                             _predicate_codes(pr2.get("pre_check_predicate") or {})))
            pr2 = {k: v for k, v in pr2.items() if not k.startswith("_") and k != "pre_check_predicate"}
            if any(a["action"] == "drop" for a in acts):
                _drop(s, pr2, g2, "post-check: " + "; ".join(a["detail"] for a in acts if a["action"] == "drop"))
                n_drop += 1
                continue
            if any(a["action"] == "duplicate" for a in acts):
                _drop(s, pr2, g2, "duplicate (post-check): " + "; ".join(a["detail"] for a in acts
                                                                         if a["action"] == "duplicate"))
                stats["duplicates"] += 1
                n_drop += 1
                continue
            ok, why_bad = predicate_valid(pr2["predicate"])
            if not ok:                                       # guard: a check must never emit an invalid predicate
                _drop(s, pr2, g2, f"post-check produced an invalid predicate: {why_bad}")
                n_drop += 1
                continue
            drafts.append(to_draft_row(pr2, g2, s, inv, backend, run_id))
            stats["grounded"] += 1
            n_ok += 1
        tokens, hit = tok1 - tok0, hit1 > hit0
        if _retryable(why):
            _outcome(s, "failed_retryable", why, len(proposals), n_ok, n_drop, tokens=tokens, hit=hit,
                     pieces=info["pieces"], n_checks=n_checks)
        elif proposals:
            stats["sections_with_proposals"] += 1
            _outcome(s, "proposals", why, len(proposals), n_ok, n_drop, from_cache, tokens, hit, info["pieces"],
                     n_checks)
        else:
            stats["sections_no_rules"] += 1
            _outcome(s, "no_rules", why, from_cache=from_cache, tokens=tokens, hit=hit, pieces=info["pieces"])
    # de-duplicate within the run by semantic key (keep the highest-confidence copy). C3-02: the copy that loses
    # is written to `dropped` ("duplicate of <key>"), never discarded silently.
    best: dict[str, dict] = {}
    losers: list[dict] = []
    for d in drafts:
        k = d["extraction_key"]
        if k not in best:
            best[k] = d
        elif d["extraction_confidence"] > best[k]["extraction_confidence"]:
            losers.append(best[k])
            best[k] = d
        else:
            losers.append(d)
    by_sid = {x.get("section_id"): x for x in sections}
    for d in losers:
        keep = best[d["extraction_key"]]
        sec = by_sid.get(d.get("section_id")) or {}
        dropped.append({"chapter": inv["chapter"], "section_id": d.get("section_id"), "heading": sec.get("heading"),
                        "statement": d.get("statement"), "predicate": d.get("predicate"), "codes": d.get("codes"),
                        "verbatim_quote": d.get("verbatim_quote"),
                        "drop_reason": f"duplicate of {d['extraction_key']}",
                        "extraction_source": d.get("extraction_source"), "doc_hash": inv["doc_hash"],
                        "page_start": sec.get("page_start"), "page_end": sec.get("page_end"), "run_id": run_id,
                        "post_checks": json.dumps({"kept_section_id": keep.get("section_id"),
                                                   "kept_confidence": keep.get("extraction_confidence")})})
        stats["duplicates"] += 1
    drafts = list(best.values())
    stats["drafts_unique"] = len(drafts)
    stats.update(model_health(backend))
    stats["finished_at"] = datetime.now().isoformat(timespec="seconds")
    return drafts, dropped, stats
