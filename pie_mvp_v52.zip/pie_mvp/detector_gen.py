"""
detector_gen.py  -  compile rule dicts into SQL detectors. Deterministic, no LLM.

One row per rule. Machine-checkable rules with a known predicate type compile
to SQL; everything else is a review lead with a reason.

What every query reads (v5, 2026-10-02): NOT the raw claims table but the detection SNAPSHOT
(`config.DETECT_SNAPSHOT_TABLE`, built by snapshot_sql() at the start of 08). The raw table can
hold values a literal comparison gets wrong; the critics proved each case on Spark 4 (ANSI):
  * codes / modifiers / form compared as stored: ' 59', '59 ', 'xu' did not bypass an NCCI pair
    (false finding), 'j3490' or '22222 ' never matched (missed)            -> UPPER(TRIM()) once (C1-02/03)
  * an exact duplicate row was summed into a daily cap (3 units read as 6)  -> DISTINCT (C1-04)
  * a NULL or blank member was treated as one person                         -> dropped (C1-05)
  * a $0 line or a reversal (negative) row was a finding, and so was the
    original line it reversed                                                -> pie_payable (C1-01, C2-07)
  * date of birth arrives in whatever type the table has                     -> pie_dob (TRY_CAST)
The snapshot keeps the raw column NAMES (so the SQL reads like the claims table) plus pie_* columns.
Line-level checks (pairs, per-line MUE, not covered) use only `pie_payable` lines; aggregate caps (daily,
period, rolling signal) sum units over every row that carries money (paid <> 0: reversal rows net out the
lines they reverse; a $0 line does not count) and need at least one payable line. The stored SQL therefore reproduces a finding when re-run against the snapshot version the run
recorded (Delta time travel).

Correctness rules baked in here:
  * PTP modifier bypass is gated on the edit's modifier indicator. Indicator 0 emits NO bypass
    clause. Indicator 1 checks the full NCCI PTP-associated modifier set; 24/25/57 count only on an
    E&M code (CMS 2026 Medicaid NCCI Technical Guidance Manual s8.1: "Modifiers 24, 25, and 57 should
    only be appended to an E&M code (99202-99499, 92002-92014)") (C2-08).
  * A pair finding sits on the Column Two line (CMS denies Column Two) and there is ONE finding per
    (rule, Column Two line); the Column One lines are its sorted evidence (C1-07: 6 x 4 lines used to
    give 24 findings and 6x the dollars).
  * NCCI applies by EDIT FILE (CMS TGM s6.0 Table 2: provider type x claim form; s5.2: never dental, pharmacy,
    inpatient or residential). The snapshot stamps every line with pie_ncci_edition (ncci_routing.py: the
    SProv_Type code and FORM_TYP); every NCCI rule carries the edition it comes from (predicate['ncci_edition'])
    and checks only lines of that edition; both lines of a pair must be (2026-10-03; it used to route by form
    alone). State rules are not routed.
  * Every detector is windowed on ITS OWN effective_date / end_date (both inclusive; CMS: the deletion
    date is "the last date that an edit is active").
  * Age conditions (predicate['age']) test the member's age ON THE DATE OF SERVICE; a line with no
    usable date of birth never matches one (it can be missed, never wrongly flagged).
  * Qualifiers never widen a rule, they label it: predicate['exception'] -> 'verify_exception',
    predicate['discretionary'] -> 'discretionary', a PA on file -> 'verify_pa' (state rules only;
    CMS: a PA is not an NCCI bypass). `finding_basis` keeps the unqualified severity. 2026-10-04 (QUERY_SEMANTICS
    v2.6 §3): a state DAILY cap whose group is over the limit by ONE line alone -> 'verify_span' (no service end date
    in the claims), else one with a bilateral / anatomic / repeat / distinct modifier -> 'verify_modifier' (after
    verify_pa, before the predicate's own qualifiers).
  * finding_severity travels with the detector so the findings table can be triaged without
    re-reading policy.
  * Table-driven statements (NCCI PTP / MUE, and since v5.2 the three AHCCCS rule tables) give exactly the findings
    of the per-rule SQL of the same rules (multiset, every column; tests/test_sql_spark.py). The AHCCCS table rules
    are STATE rules: no edit-file routing, PA evaluated, qualifiers label; a daily cap's scope (member_day by default,
    member_provider_day or - v2.6 - member_servicing_billing_day for the AHCCCS daily limits) is part of the predicate.
  * v2.6 (2026-10-04, after the independent critic of v5.2): scope member_servicing_billing_day = the same servicing
    AND billing provider id (A* pairs, AHCCCS daily limits; a missing id never matches / is not counted); provider role
    billing_or_rendering = the billing type, a group's line (config.GROUP_BILLING_PROVIDER_TYPES) on its rendering
    type; a pair disallowed both ways says so in its finding (and the pair edit table's both_ways column).
"""
from __future__ import annotations

import hashlib
from datetime import date as _date

import config
import ncci_routing
import schema

# ---------------------------------------------------------------- claims
CLAIMS = getattr(config, "CLAIMS_TABLE", "main.prod_input.all_data_C_A")

# physical column names come from config.CLAIM_COLS; nothing is hard-coded here
_CC = config.CLAIM_COLS
COL = {
    "claim_id":  _CC["claim_id"],
    "line_no":   _CC["line_no"],
    "member":    _CC["member"],
    "provider":  _CC["servicing_provider"],   # NCCI: same servicing provider
    "billing":   _CC.get("billing_provider"),
    "dos":       _CC["dos"],
    "proc":      _CC["code"],
    "units":     _CC["units"],
    "form":      _CC["form"],
    "mods":      list(_CC["mods"]),
    "pa_no":     _CC.get("pa_no"),          # None if the claims table has no PA field
    "paid":      _CC.get("paid_amt"),       # every finding carries the paid dollars it touches
    "dob":       _CC.get("dob"),            # member date of birth (age conditions)
    "prov_type": _CC.get("prov_type"),      # servicing provider type CODE: a rendering practitioner identified?
    "billing_type": _CC.get("billing_type"),  # billing provider type CODE: which NCCI edit file a line takes
}
KB = f"{getattr(config, 'OUTPUT_CATALOG', 'main')}.{getattr(config, 'OUTPUT_SCHEMA', 'policy_kb')}"
PTP_EDITS_TABLE = f"{KB}.policy_ncci_ptp_edits"
MUE_LIMITS_TABLE = f"{KB}.policy_ncci_mue_limits"
# the table every detector reads (see module docstring); 08 rebuilds it at the start of each run
DETECT = getattr(config, "DETECT_SNAPSHOT_TABLE", f"{KB}.policy_claims_snapshot")

# snapshot-only columns
PIE_DOB, PIE_PAYABLE, PIE_REVERSAL, PIE_CANCELLED = "pie_dob", "pie_payable", "pie_reversal", "pie_cancelled"
PIE_EDITION, PIE_PROV_TYPE, PIE_UNITS_RAW = "pie_ncci_edition", "pie_prov_type", "pie_units_raw"
PIE_BPROV_TYPE = "pie_bprov_type"            # the BILLING provider type code, normalised (2026-10-03)


def _form_by_service() -> dict[str, list[str]]:
    """service label -> FORM_TYP values (config.FORM_TYPE_MAP inverted + SERVICE_FORM_MAP)."""
    m: dict[str, list[str]] = {}
    for form, svc in config.FORM_TYPE_MAP.items():
        m.setdefault(svc, []).append(form)
    m.update(getattr(config, "SERVICE_FORM_MAP", {}) or {})
    return m


# Full NCCI PTP-associated modifier set (TGM s8.1 / Medicaid NCCI FAQ 7.1; the critics checked the
# list against CMS: complete). Anatomic modifiers:
NCCI_ANATOMIC_MODS = (
    "E1", "E2", "E3", "E4", "FA", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9",
    "TA", "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9",
    "LT", "RT", "LC", "LD", "RC", "LM", "RI",
)
# CMS 2026 Medicaid NCCI Technical Guidance: "if both codes have the same anatomical modifier and
# neither code has modifier 58, 59, 78, 79, XE, XP, XS, or XU, the PTP edit is NOT bypassed".
NCCI_ANATOMIC_OVERRIDE_MODS = ("58", "59", "78", "79", "XE", "XP", "XS", "XU")
# C2-08: 24, 25 and 57 bypass ONLY when they sit on an E&M code line.
NCCI_EM_ONLY_MODS = ("24", "25", "57")
NCCI_GENERAL_BYPASS_MODS = NCCI_ANATOMIC_MODS + (
    "58", "78", "79",                                  # global surgery
    "27", "59", "91", "XE", "XS", "XP", "XU",          # other
)
NCCI_BYPASS_MODS = NCCI_GENERAL_BYPASS_MODS + NCCI_EM_ONLY_MODS      # the whole set (kept for readers)
# E&M code ranges for the 24/25/57 rule (TGM s8.1). Codes are 5 digits; compared as text.
EM_RANGES = (("99202", "99499"), ("92002", "92014"))

# Co-occurrence scope of a code-pair prohibition (schema.PAIR_SCOPES). NCCI PTP edits are
# adjudicated per provider (same servicing provider, member, DOS). A state pair is member-wide
# (any provider) ONLY when its predicate says scope 'member_day' - i.e. the text says "for the same
# member" and a reviewer signed it. With no scope a state pair is the NARROW member_provider_day
# (C3-01: the compiler used to default state pairs to member_day while the reviewer brief said
# provider, so "A single provider cannot bill both codes" (S9484/S9485) flagged two providers).
PAIR_SCOPES = set(schema.PAIR_SCOPES)
# 2026-10-04 (QUERY_SEMANTICS v2.6, critic F5): "the same provider" read as the same SERVICING provider AND the same
# BILLING provider id - a finding then breaks the rule whichever of the two AHCCCS means (A* pairs, the AHCCCS daily
# limits). A missing id of either never matches (pairs) / is not counted (daily caps).
MSBD = "member_servicing_billing_day"
PER_PROVIDER_SCOPES = ("member_provider_day", MSBD)


def _billing_id_col() -> str:
    """The billing provider ID column the scope member_servicing_billing_day compares. When config.CLAIM_COLS has none
    the scope cannot be judged: a compile error (the rule is a lead saying why), never SQL that silently matches
    nothing."""
    b = COL.get("billing")
    if not b:
        raise ValueError(f"scope {MSBD} needs config.CLAIM_COLS['billing_provider'] (the billing provider id)")
    return b


def pair_scope(rule: dict) -> str:
    p = rule.get("predicate") or {}
    if rule.get("origin") == "ncci":
        return "member_provider_day"        # CMS adjudicates PTP per provider; a stray scope never widens it
    s = p.get("scope")
    if s in PAIR_SCOPES:
        return s
    return "member_provider_day"


def daily_scope(rule: dict) -> str:
    """Whose units a daily cap (max_units_per_day) adds on one date of service. 2026-10-04 (v5.2): 'member_day' (the
    default, so every daily cap written before v5.2 compiles to exactly the SQL it had) = the member's units from ANY
    provider; 'member_provider_day' = one member's units from one servicing provider, rows with no provider not counted;
    (v2.6) 'member_servicing_billing_day' = from one servicing AND one billing provider, a row missing either id not
    counted (SB's reading of the AHCCCS daily limits table, config.AHCCCS_DAILY_LIMIT_SCOPE). The opposite default to
    pairs: a daily cap that names no provider has always meant the member's day."""
    s = (rule.get("predicate") or {}).get("scope")
    return s if s in PAIR_SCOPES else "member_day"


# --------------------------------------------------------------- helpers
def _q(code) -> str:
    """A code pasted into SQL: ASCII letters/digits only (C1-17: full-width digits used to pass)."""
    s = str(code).strip().upper()
    if not s or not (s.isascii() and s.isalnum()):
        raise ValueError(f"unsafe procedure code {code!r}")
    return s


_ISO = __import__("re").compile(r"^\d{4}-\d{2}-\d{2}$")


def _iso_or_raise(v):
    """Dates are pasted into SQL. A malformed one ('10/1/2025') or an impossible one ('2025-02-30',
    C1-16) is refused at compile time -> the rule becomes a lead with the reason; one bad edit row
    used to fail the whole NCCI batch at run time."""
    if v is None or v == "" or (isinstance(v, float) and v != v):
        return None
    v = str(v)[:10]
    if not _ISO.match(v):
        raise ValueError(f"date {v!r} is not ISO yyyy-mm-dd")
    _date.fromisoformat(v)
    return v


def _rule_window(rule: dict) -> tuple:
    eff, end = _iso_or_raise(rule.get("effective_date")), _iso_or_raise(rule.get("end_date"))
    if eff and end and end < eff:
        raise ValueError(f"end_date {end} is before effective_date {eff}")
    return eff, end


def _window(alias: str, rule: dict) -> str:
    eff, end = _rule_window(rule)
    conds = []
    if eff:
        conds.append(f"{alias}.{COL['dos']} >= DATE '{eff}'")
    if end:
        conds.append(f"{alias}.{COL['dos']} <= DATE '{end}'")
    return ("\n  AND " + "\n  AND ".join(conds)) if conds else ""


def _ncci_edition(rule: dict) -> str | None:
    """The NCCI edit file a rule comes from (rule_normalize stamps it). None = not NCCI."""
    if rule.get("origin") != "ncci":
        return None
    e = (rule.get("predicate") or {}).get("ncci_edition")
    if not e:
        raise ValueError("NCCI rule has no ncci_edition (rule_normalize.route_ncci_rules was not applied)")
    e = str(e).strip().lower()
    if e not in ncci_routing.EDITIONS:
        raise ValueError(f"bad ncci_edition {e!r}")
    return e


def _routing(aliases: tuple, rule: dict) -> tuple[str, str]:
    """(sql_clause, routing_label). NCCI: every alias must be a line of the rule's edit file. State: all lines."""
    e = _ncci_edition(rule)
    if e is None:
        return "", "all_forms"
    clause = "".join(f"\n  AND {a}.{PIE_EDITION} = '{e}'" for a in aliases)
    return clause, f"edition:{e}"


def _edition_col(rule: dict) -> str:
    e = _ncci_edition(rule)
    return f"'{e}' AS ncci_edition" if e else "CAST(NULL AS STRING) AS ncci_edition"


def _age_clause(alias: str, p: dict) -> str:
    """Member age on the date of service (schema: {'min': n} = n and older, {'below': n} = under n)."""
    a = p.get("age")
    if not a:
        return ""
    ok, why = schema.validate_age(a)
    if not ok:
        raise ValueError(why)
    if not COL["dob"]:
        raise ValueError("age condition needs config.CLAIM_COLS['dob']")
    dob, dos = f"{alias}.{PIE_DOB}", f"{alias}.{COL['dos']}"
    parts = [f"{dob} IS NOT NULL"]
    if a.get("min") is not None:
        parts.append(f"{dos} >= ADD_MONTHS({dob}, {12 * int(a['min'])})")
    if a.get("below") is not None:
        parts.append(f"{dos} < ADD_MONTHS({dob}, {12 * int(a['below'])})")
    return "\n  AND " + "\n  AND ".join(parts)


def _paid(alias: str, aggregate: bool = False) -> str:
    if not COL["paid"]:
        return "CAST(NULL AS DOUBLE) AS paid_amt"
    return (f"SUM({alias}.{COL['paid']})" if aggregate else f"{alias}.{COL['paid']}") + " AS paid_amt"


def _line_cols(alias: str) -> str:
    return (f"{alias}.{COL['claim_id']} AS claim_id, {alias}.{COL['line_no']} AS line_no,\n"
            f"       {alias}.{COL['member']} AS member_id, {alias}.{COL['provider']} AS servicing_provider,\n"
            f"       {alias}.{COL['dos']} AS dos, {alias}.{COL['form']} AS form_typ, {_paid(alias)}")


def _payable(alias: str) -> str:
    return f"{alias}.{PIE_PAYABLE}"


def _counted(alias: str) -> str:
    """Rows whose units count toward a daily / period limit: rows that carry money (paid <> 0). A reversal row
    (negative) nets out the line it reverses; a $0 line - denied or bundled when it was adjudicated - does not
    count (2026-10-02: counting it flagged days the payer had already held to the limit by denying the line)."""
    return f"\n  AND {alias}.{COL['paid']} <> 0" if COL["paid"] else ""


def sql_sha256(sql: str | None) -> str | None:
    return None if sql is None else hashlib.sha256(sql.encode("utf-8")).hexdigest()


# ------------------------------------------------------------- severities
# Most cautious label wins: a PA on file, then a stated exception, then "may be denied".
VERIFY_PA = "verify_pa"
VERIFY_EXCEPTION = "verify_exception"
DISCRETIONARY = "discretionary"
VERIFY_MUE_CHANGED = "verify_mue_changed_later"
VERIFY_COL1 = "verify_col1_not_payable"
# 2026-10-04 (QUERY_SEMANTICS v2.6 §3, critic F3 / F15) - daily caps of state rules only (max_units_per_day,
# max_units_per_dos; every origin but NCCI), after verify_pa and before the rule's own qualifiers:
#   verify_span      ONE counted row of the group alone is over the threshold: the claims table has no service end
#                    date, so that line may cover several days (a per diem billed once for a stay)
#   verify_modifier  a counted row carries a modifier of config.DAILY_CAP_VERIFY_MODIFIERS (bilateral 50, anatomic,
#                    repeat 76 / 77 / 91, distinct 59 / X{EPSU}) on any modifier column: units on separate sites /
#                    sessions may be allowed past a daily maximum
VERIFY_SPAN = "verify_span"
VERIFY_MODIFIER = "verify_modifier"
SEVERITIES = ("hard_denial", "unbypassed_pair", "units_over_limit", "not_covered_paid",
              "documentation_reviewable", VERIFY_PA, VERIFY_EXCEPTION, DISCRETIONARY, VERIFY_MUE_CHANGED,
              VERIFY_COL1, VERIFY_SPAN, VERIFY_MODIFIER)


def _pa_applies(rule: dict) -> bool:
    return bool(COL["pa_no"]) and rule.get("origin") != "ncci"


def _pa_true(alias: str) -> str:
    return f"{alias}.{COL['pa_no']} IS NOT NULL"          # the snapshot made blanks NULL


def _qualified(rule: dict, base: str) -> str:
    """Severity after the predicate's qualifiers (no PA yet): exception > discretionary > base."""
    p = rule.get("predicate") or {}
    if rule.get("origin") == "ncci":
        return base
    if str(p.get("exception") or "").strip():
        return VERIFY_EXCEPTION
    if p.get("discretionary") is True:
        return DISCRETIONARY
    return base


def _severity_sql(rule: dict, base: str, pa_flag: str | None) -> str:
    """`pa_present`, `finding_severity`, `finding_basis` select items. pa_flag: SQL 0/1 or None."""
    qual = _qualified(rule, base)
    if pa_flag is None or not _pa_applies(rule):
        # not evaluated (NCCI: CMS says a PA is no bypass; or no PA column) - NULL, never 0 = "no PA on file"
        return f"CAST(NULL AS INT) AS pa_present, '{qual}' AS finding_severity, '{base}' AS finding_basis"
    return (f"{pa_flag} AS pa_present,\n"
            f"       CASE WHEN {pa_flag} = 1 THEN '{VERIFY_PA}' ELSE '{qual}' END AS finding_severity,\n"
            f"       '{base}' AS finding_basis")


def _daily_cap_mods() -> list[str]:
    """config.DAILY_CAP_VERIFY_MODIFIERS as the snapshot holds modifiers (trimmed, upper-cased), distinct, in order. A
    value that is not a two-character modifier (ASCII letters / digits) is refused: a compile error - the rule becomes a
    lead - never SQL built from it."""
    raw = getattr(config, "DAILY_CAP_VERIFY_MODIFIERS", ()) or ()
    out = []
    for m in ((raw,) if isinstance(raw, str) else raw):
        s = str(m).strip().upper()
        if len(s) != 2 or not (s.isascii() and s.isalnum()):
            raise ValueError(f"config.DAILY_CAP_VERIFY_MODIFIERS holds {m!r}, not a two-character modifier")
        out.append(s)
    return list(dict.fromkeys(out))


def _daily_cap_case(qual_expr: str, basis_expr: str, pa_flag: str | None, val) -> str:
    """`pa_present`, `finding_severity`, `finding_basis` of a daily cap of a STATE rule (v2.6 §3): verify_pa (a PA on any
    counted row) > verify_span (MAX units of one PAYABLE line > threshold) > verify_modifier (a payable line with a
    modifier of config.DAILY_CAP_VERIFY_MODIFIERS on any modifier column) > qual_expr (the rule's qualified label).
    Aggregates over the group's counted rows (alias a). val: the threshold - a number, or the batch's INT expression."""
    whens = [f"WHEN {pa_flag} = 1 THEN '{VERIFY_PA}'"] if pa_flag is not None else []
    # 2026-10-05 (v2.6, critic re-check N4): both labels look at the group's PAYABLE lines only - a line a reversal
    # cancels (and the reversal row itself) nets out of the sum, so it must not make the group look like one long line
    # or carry a modifier the paid day does not have
    whens.append(f"WHEN MAX(CASE WHEN {_payable('a')} THEN a.{COL['units']} END) > {val} THEN '{VERIFY_SPAN}'")
    mods = _daily_cap_mods()
    if mods:
        whens.append(f"WHEN MAX(CASE WHEN {_payable('a')} AND {_mods_in('a', tuple(mods))} THEN 1 ELSE 0 END) = 1 "
                     f"THEN '{VERIFY_MODIFIER}'")
    pa_col = f"{pa_flag} AS pa_present" if pa_flag is not None else "CAST(NULL AS INT) AS pa_present"
    return (f"{pa_col},\n       CASE " + "\n            ".join(whens)
            + f"\n            ELSE {qual_expr} END AS finding_severity,\n       {basis_expr} AS finding_basis")


def _daily_cap_severity_sql(rule: dict, base: str, pa_flag: str | None, val) -> str:
    """The severity items of a per-rule daily cap: state rules get the v2.6 order (_daily_cap_case); NCCI keeps
    _severity_sql exactly (no PA, no span / modifier label - CMS adjudicates MUEs on its own terms)."""
    if rule.get("origin") == "ncci":
        return _severity_sql(rule, base, pa_flag)
    return _daily_cap_case(f"'{_qualified(rule, base)}'", f"'{base}'", pa_flag if _pa_applies(rule) else None, val)


def _ev_text(arr: str) -> str:
    """claim:line text of a sorted array of {c, l} structs; a missing id renders as '' (never dropped)."""
    return (f"ARRAY_JOIN(TRANSFORM({arr}, x -> CONCAT(COALESCE(CAST(x.c AS STRING), ''), ':', "
            f"COALESCE(CAST(x.l AS STRING), ''))), ',')")


def _ev_struct(claim: str, line: str) -> str:
    """One evidence entry. 'n' = the line number AS A NUMBER, so the order is numeric whatever type the claims table
    gives LN_NO (a text '12' sorted before '3' - 2026-10-03); missing values sort first."""
    return f"NAMED_STRUCT('c', {claim}, 'n', TRY_CAST(CAST({line} AS STRING) AS DOUBLE), 'l', {line})"


def _evidence_lines(alias: str = "a") -> str:
    """Contributing claim:line ids, distinct, sorted by (claim id, line number as a number). C1-10: the list
    must not follow the file layout. Oracle 2026-10-02: CONCAT with a NULL line number dropped the line (F-01),
    a line counted twice was listed twice (S-02), and text order put 'C1:12' before 'C1:3' (S-03)."""
    return (_ev_text(f"ARRAY_SORT(ARRAY_DISTINCT(COLLECT_LIST("
                     f"{_ev_struct(alias + '.' + COL['claim_id'], alias + '.' + COL['line_no'])})))") + " AS evidence_lines")


# -------------------------------------------------------------- compilers
def _mods_in(alias: str, mods: tuple) -> str:
    """The snapshot holds modifiers trimmed and upper-cased (NULL when blank)."""
    lst = ",".join(f"'{m}'" for m in mods)
    return "(" + " OR ".join(f"COALESCE({alias}.{m}, '') IN ({lst})" for m in COL["mods"]) + ")"


def _is_em(alias: str) -> str:
    c = f"{alias}.{COL['proc']}"
    rng = " OR ".join(f"{c} BETWEEN '{lo}' AND '{hi}'" for lo, hi in EM_RANGES)
    return f"({c} RLIKE '^[0-9]{{5}}$' AND ({rng}))"


def _bypass(alias: str) -> str:
    """An NCCI-associated modifier on this line that may bypass an indicator-1 edit (C2-08)."""
    return f"({_mods_in(alias, NCCI_GENERAL_BYPASS_MODS)} OR ({_is_em(alias)} AND {_mods_in(alias, NCCI_EM_ONLY_MODS)}))"


def _same_anatomic_modifier() -> str:
    """True when some anatomic modifier appears on BOTH line a and line b."""
    anat = ",".join(f"'{m}'" for m in NCCI_ANATOMIC_MODS)
    b_mods = ", ".join(f"COALESCE(b.{m}, '')" for m in COL["mods"])
    return "(" + " OR ".join(f"(COALESCE(a.{m}, '') IN ({anat}) AND COALESCE(a.{m}, '') IN ({b_mods}))"
                             for m in COL["mods"]) + ")"


def _indicator1_flags() -> str:
    """SQL that is TRUE when an indicator-1 edit is NOT bypassed: no bypass modifier on either line,
    or both lines carry the same anatomic modifier and neither carries 58/59/78/79/X{EPSU}."""
    any_bypass = f"({_bypass('a')} OR {_bypass('b')})"
    override = f"({_mods_in('a', NCCI_ANATOMIC_OVERRIDE_MODS)} OR {_mods_in('b', NCCI_ANATOMIC_OVERRIDE_MODS)})"
    return f"NOT ({any_bypass} AND NOT ({_same_anatomic_modifier()} AND NOT {override}))"


def _not_same_line() -> str:
    """Null-safe (C1-18: a NULL LN_NO made the old test NULL, so a pair on one claim never formed)."""
    c = COL
    return f"NOT (a.{c['claim_id']} <=> b.{c['claim_id']} AND a.{c['line_no']} <=> b.{c['line_no']})"


def _pair_rollup(inner: str, keep_rule_id: bool = False) -> str:
    """C1-07: one finding per (rule, Column Two line). Column One lines become evidence - distinct, sorted by
    (claim id, line number), missing ids kept - and the FIRST of them is col1_claim_id / col1_line_no (the
    same order as the evidence text)."""
    rid = "rule_id, " if keep_rule_id else ""
    return f"""SELECT {rid}claim_id, line_no, member_id, servicing_provider, dos, form_typ, ncci_edition, paid_amt,
       ev[0].c AS col1_claim_id, ev[0].l AS col1_line_no,
       pair_scope, finding, 1 AS observed_units, 0 AS allowed_units,
       CAST(NULL AS DOUBLE) AS excess_units, paid_amt AS paid_at_risk,
       pa_present,
       CASE WHEN pa_present = 1 THEN '{VERIFY_PA}' ELSE finding_severity_q END AS finding_severity,
       finding_basis,
       {_ev_text('ev')} AS evidence_lines
FROM (
SELECT {rid}claim_id, line_no, member_id, servicing_provider, dos, form_typ, ncci_edition, paid_amt, pair_scope, finding,
       finding_severity_q, finding_basis, MAX(pa_flag) AS pa_present,
       ARRAY_SORT(ARRAY_DISTINCT(COLLECT_LIST({_ev_struct('col1_claim_id', 'col1_line_no')}))) AS ev
FROM (
{inner}
) pairs
GROUP BY {rid}claim_id, line_no, member_id, servicing_provider, dos, form_typ, ncci_edition, paid_amt, pair_scope,
         finding, finding_severity_q, finding_basis
) rolled"""


# 2026-10-04 (QUERY_SEMANTICS v2.6 §2b, critic F4): a pair the AHCCCS Same Day table disallows in BOTH directions gives
# each line the finding of its own rule (predicate both_ways = True); the finding says so, because AHCCCS would deny
# only one of the two lines - their dollars are not additive (08 counts them once, joining the pair edit table's
# both_ways column). State rules only: an NCCI rule never carries it.
BOTH_WAYS_NOTE = " (pair disallowed both ways: AHCCCS would deny one of the two lines)"


def _both_ways(rule: dict) -> bool:
    return rule.get("origin") != "ncci" and (rule.get("predicate") or {}).get("both_ways") is True


def _check_both_ways(rule: dict) -> None:
    """A state pair's both_ways must be true / false: anything else is refused (the rule is a lead), never read as one
    way or the other. NCCI ignores the key."""
    p = rule.get("predicate") or {}
    if rule.get("origin") != "ncci" and "both_ways" in p and not isinstance(p["both_ways"], bool):
        raise ValueError(f"both_ways must be true or false (got {p['both_ways']!r})")


def _pair_finding(rule: dict, a: str, b: str) -> str:
    """The finding text of a code pair: the per-rule SQL and the edit tables write exactly this."""
    return f"{b} billed with {a}" + (BOTH_WAYS_NOTE if _both_ways(rule) else "")


def compile_code_pair(rule: dict) -> tuple[str, str, str]:
    """Code-pair prohibition. `a` is the Column One / comprehensive code, `b` the Column Two /
    component code: the finding sits on line b (for a state pair, code_b is the code the text says
    may not be billed). Scope: pair_scope(). Modifier bypass: indicator 0 none at all; indicator 1
    an NCCI-associated modifier on EITHER line bypasses, except the same-anatomic-modifier case."""
    p = rule["predicate"]
    a, b = _q(p["code_a"]), _q(p["code_b"])
    if a == b:
        raise ValueError("self pair")
    _check_both_ways(rule)
    mi = schema.normalize_indicator(p.get("modifier_indicator"), rule.get("origin"))
    if mi is None:
        # C1-06: '' / None / ' 0' / '0.0' used to compile as indicator 1 (bypassable)
        raise ValueError(f"modifier_indicator {p.get('modifier_indicator')!r} is not '0' or '1'")
    route_sql, route = _routing(("a", "b"), rule)
    scope = pair_scope(rule)
    if mi == "0":
        mod_clause, severity = "", "hard_denial"
    else:
        mod_clause, severity = f"\n  AND {_indicator1_flags()}", "unbypassed_pair"
    provider_join = (f"\n  AND a.{COL['provider']} = b.{COL['provider']}"
                     if scope in PER_PROVIDER_SCOPES else "")
    if scope == MSBD:               # v2.6: and the same billing provider id (NULL = NULL is never true: never matches)
        provider_join += f" AND a.{_billing_id_col()} = b.{_billing_id_col()}"
    pa = (f"CASE WHEN {_pa_true('a')} OR {_pa_true('b')} THEN 1 ELSE 0 END" if _pa_applies(rule)
          else "CAST(NULL AS INT)")
    inner = f"""SELECT {_line_cols('b')}, {_edition_col(rule)},
       a.{COL['claim_id']} AS col1_claim_id, a.{COL['line_no']} AS col1_line_no,
       '{scope}' AS pair_scope, '{_pair_finding(rule, a, b)}' AS finding,
       '{_qualified(rule, severity)}' AS finding_severity_q, '{severity}' AS finding_basis, {pa} AS pa_flag
FROM {DETECT} a
JOIN {DETECT} b
  ON  a.{COL['member']} = b.{COL['member']}{provider_join}
  AND a.{COL['dos']} = b.{COL['dos']}
  AND {_not_same_line()}
WHERE a.{COL['proc']} = '{a}' AND b.{COL['proc']} = '{b}'
  AND {_payable('a')} AND {_payable('b')}{mod_clause}{route_sql}{_window('b', rule)}{_age_clause('b', p)}"""
    return _pair_rollup(inner), severity, route


def _mue_changed_later_sql(p: dict, units: str) -> str | None:
    """C2-03 for one NCCI MUE: the CASE that labels a line within a LATER quarter's value (or of a code a
    later quarter removed) 'verify_mue_changed_later'. None when no later quarter relaxed it."""
    later, removed = p.get("later_max_threshold"), bool(p.get("removed_later"))
    if removed:
        return f"'{VERIFY_MUE_CHANGED}'"
    if later is None or (isinstance(later, float) and later != later):
        return None
    return f"CASE WHEN {units} <= {int(later)} THEN '{VERIFY_MUE_CHANGED}' ELSE 'units_over_limit' END"


def compile_units_per_line(rule: dict) -> tuple[str, str, str]:
    p = rule["predicate"]
    code, val = _q(p["code"]), int(p["threshold"])
    route_sql, route = _routing(("a",), rule)
    severity = "units_over_limit"
    pa = f"CASE WHEN {_pa_true('a')} THEN 1 ELSE 0 END" if _pa_applies(rule) else None
    sev = _severity_sql(rule, severity, pa)
    changed = _mue_changed_later_sql(p, f"a.{COL['units']}") if rule.get("origin") == "ncci" else None
    if changed:
        sev = f"CAST(NULL AS INT) AS pa_present, {changed} AS finding_severity, '{severity}' AS finding_basis"
    sql = f"""SELECT {_line_cols('a')}, {_edition_col(rule)},
       '{code} units per line > {val}' AS finding,
       a.{COL['units']} AS observed_units, {val} AS allowed_units,
       a.{COL['units']} - {val} AS excess_units, {_paid('a').replace(' AS paid_amt', '')} AS paid_at_risk,
       {sev}
FROM {DETECT} a
WHERE a.{COL['proc']} = '{code}' AND a.{COL['units']} > {val}
  AND {_payable('a')}{route_sql}{_window('a', rule)}{_age_clause('a', p)}"""
    return sql, severity, route


def _compile_units_per_day(rule: dict, group_provider: bool, group_billing: bool = False) -> tuple[str, str, str]:
    """Daily cap on one code, or summed over predicate['code_set'] ("4 units per day inclusive of
    98960/98961/98962"). group_provider: per servicing provider too; group_billing (v2.6, scope
    member_servicing_billing_day): per billing provider id too - a row missing either id is not counted."""
    p = rule["predicate"]
    codes = [_q(c) for c in (p.get("code_set") or [p["code"]])]
    code, val = "/".join(codes), int(p["threshold"])
    in_list = ",".join(f"'{c}'" for c in codes)
    route_sql, route = _routing(("a",), rule)
    severity = "documentation_reviewable" if p.get("mai") == 3 else "units_over_limit"
    bp = _billing_id_col() if group_billing else None
    grp = ([f"a.{COL['member']}"] + ([f"a.{COL['provider']}"] if group_provider else [])
           + ([f"a.{bp}"] if bp else []) + [f"a.{COL['dos']}"])
    grp = list(dict.fromkeys(grp))
    sel = (f"a.{COL['member']} AS member_id, "
           + (f"a.{COL['provider']} AS servicing_provider, " if group_provider else "")
           # 2026-10-04 (v2.6, lead): the group's billing provider id is part of WHICH group this is - without it two
           # findings of one member, servicing provider and day (two billing ids) were indistinguishable (same
           # finding_id in 08)
           + (f"a.{bp} AS billing_provider, " if bp else "")
           + f"a.{COL['dos']} AS dos")
    prov_nn = f"\n  AND a.{COL['provider']} IS NOT NULL" if group_provider else ""     # C1-05
    prov_nn += f"\n  AND a.{bp} IS NOT NULL" if bp else ""
    pa = f"MAX(CASE WHEN {_pa_true('a')} THEN 1 ELSE 0 END)" if _pa_applies(rule) else None
    sql = f"""SELECT {sel}, {_paid('a', aggregate=True)}, {_edition_col(rule)},
       '{code} units per day > {val}' AS finding,
       SUM(a.{COL['units']}) AS observed_units, {val} AS allowed_units,
       SUM(a.{COL['units']}) - {val} AS excess_units,
       {_paid_at_risk(val)},
       {_evidence_lines('a')},
       {_daily_cap_severity_sql(rule, severity, pa, val)}
FROM {DETECT} a
WHERE a.{COL['proc']} IN ({in_list}){_counted('a')}{prov_nn}{route_sql}{_window('a', rule)}{_age_clause('a', p)}
GROUP BY {', '.join(grp)}
HAVING SUM(a.{COL['units']}) > {val} AND MAX(CASE WHEN {_payable('a')} THEN 1 ELSE 0 END) = 1"""
    return sql, severity, route


def _paid_at_risk(val) -> str:
    """C1-08: an aggregate finding carries the WHOLE group's dollars in paid_amt; paid_at_risk is the
    share of them for the units over the limit (an estimate: units are not priced individually).
    `val`: the threshold - a number, or (v5.2 table batch) the INT expression of the edit row's threshold."""
    if not COL["paid"]:
        return "CAST(NULL AS DOUBLE) AS paid_at_risk"
    u, d = f"SUM(a.{COL['units']})", f"SUM(a.{COL['paid']})"
    return f"CASE WHEN {u} > 0 THEN {d} * ({u} - {val}) / {u} END AS paid_at_risk"


def compile_units_per_dos(rule: dict):      # NCCI MAI 2/3 model: same provider, same member, same DOS
    return _compile_units_per_day(rule, group_provider=True)


def compile_units_per_day(rule: dict):      # state daily benefit cap: per member, per DOS
    # 2026-10-04 (v5.2): ... or per member + servicing provider + DOS when the predicate's scope says so (the AHCCCS
    # daily limits table); (v2.6) + billing provider id for member_servicing_billing_day. No scope / 'member_day' ->
    # group_provider=False.
    s = daily_scope(rule)
    return _compile_units_per_day(rule, group_provider=s in PER_PROVIDER_SCOPES, group_billing=s == MSBD)


# C1-14: period_start is a DATE for every period (it used to be a timestamp, a calendar year, or the
# benefit year's END year); period_end is the period's last day. AHCCCS contract/benefit year = Oct 1
# - Sep 30 (FFS Ch10, Ch22).
_PERIOD_START = {
    "month":        "TRUNC({d}, 'MM')",
    "year":         "TRUNC({d}, 'YEAR')",
    "benefit_year": "ADD_MONTHS(TRUNC(ADD_MONTHS({d}, 3), 'YEAR'), -3)",
}
_PERIOD_MONTHS = {"month": 1, "year": 12, "benefit_year": 12}


def period_start_sql(period: str, dos_expr: str) -> str:
    return _PERIOD_START[period].format(d=dos_expr)


def compile_units_per_period(rule: dict) -> tuple[str, str, str]:
    p = rule["predicate"]
    codes = [_q(c) for c in (p.get("code_set") or ([p["code"]] if p.get("code") else []))]
    if not codes:
        raise ValueError("max_units_per_period needs code or code_set")
    period = p.get("period", "month")
    if period not in _PERIOD_START:
        raise ValueError(f"unsupported period {period!r}")
    val = int(p["threshold"])
    start = period_start_sql(period, f"a.{COL['dos']}")
    route_sql, route = _routing(("a",), rule)
    in_list = ",".join(f"'{c}'" for c in codes)
    severity = "units_over_limit"
    pa = f"MAX(CASE WHEN {_pa_true('a')} THEN 1 ELSE 0 END)" if _pa_applies(rule) else None
    sql = f"""SELECT a.{COL['member']} AS member_id, {start} AS period_start,
       DATE_ADD(ADD_MONTHS({start}, {_PERIOD_MONTHS[period]}), -1) AS period_end,
       {_paid('a', aggregate=True)}, {_edition_col(rule)},
       '{"/".join(codes)} units per {period} > {val}' AS finding,
       SUM(a.{COL['units']}) AS observed_units, {val} AS allowed_units,
       SUM(a.{COL['units']}) - {val} AS excess_units,
       {_paid_at_risk(val)},
       {_evidence_lines('a')},
       {_severity_sql(rule, severity, pa)}
FROM {DETECT} a
WHERE a.{COL['proc']} IN ({in_list}){_counted('a')}{route_sql}{_window('a', rule)}{_age_clause('a', p)}
GROUP BY a.{COL['member']}, {start}
HAVING SUM(a.{COL['units']}) > {val} AND MAX(CASE WHEN {_payable('a')} THEN 1 ELSE 0 END) = 1"""
    return sql, severity, route


def compile_code_not_covered(rule: dict) -> tuple[str, str, str]:
    p = rule["predicate"]
    codes = [_q(c) for c in (p.get("code_set") or [p["code"]])]
    route_sql, route = _routing(("a",), rule)
    in_list = ",".join(f"'{c}'" for c in codes)
    severity = "not_covered_paid"
    pa = f"CASE WHEN {_pa_true('a')} THEN 1 ELSE 0 END" if _pa_applies(rule) else None
    sql = f"""SELECT {_line_cols('a')}, {_edition_col(rule)},
       'non-covered code {"/".join(codes)} paid' AS finding,
       a.{COL['units']} AS observed_units, 0 AS allowed_units,
       a.{COL['units']} AS excess_units, {_paid('a').replace(' AS paid_amt', '')} AS paid_at_risk,
       {_severity_sql(rule, severity, pa)}
FROM {DETECT} a
WHERE a.{COL['proc']} IN ({in_list})
  AND {_payable('a')}{route_sql}{_window('a', rule)}{_age_clause('a', p)}"""
    return sql, severity, route


def _allowed_types(p: dict) -> list[str]:
    out = sorted({t for t in (ncci_routing.norm_type(x) for x in (p.get("provider_types") or [])) if t})
    if not out or any(not (t.isascii() and t.isalnum()) for t in out):
        raise ValueError(f"provider_types must be provider type codes (got {p.get('provider_types')!r})")
    return out


ROLE_BILLING_OR_RENDERING = "billing_or_rendering"


def _group_billing_types() -> list[str]:
    """config.GROUP_BILLING_PROVIDER_TYPES (v2.6: '01' Group-Payment ID) cleaned exactly like the claims column (§1:
    ' 1 ' / '1.0' -> '01'), distinct and sorted. A value that is not a provider type code after the clean-up (1-4 ASCII
    letters / digits) is refused: a compile error - the rule becomes a lead - never SQL built from it."""
    raw = getattr(config, "GROUP_BILLING_PROVIDER_TYPES", ()) or ()
    out = set()
    for v in ((raw,) if isinstance(raw, str) else raw):
        t = ncci_routing.norm_type(v)
        if not t or not (t.isascii() and t.isalnum()) or len(t) > 4:
            raise ValueError(f"config.GROUP_BILLING_PROVIDER_TYPES holds {v!r}, not a provider type code")
        out.add(t)
    return sorted(out)


def _group_billing_types_or_none() -> list[str]:
    try:
        return _group_billing_types()
    except ValueError:
        return []


def _group_billing_sql(alias: str) -> str:
    """TRUE when the line's (cleaned) billing provider type is a group billing type; FALSE when none is configured."""
    g = _group_billing_types()
    return f"{alias}.{PIE_BPROV_TYPE} IN ({','.join(repr(t) for t in g)})" if g else "FALSE"


def compile_provider_type_allowed(rule: dict) -> tuple[str, str, str]:
    """2026-10-03 (BProv_Type): "must be billed ... only by the following approved provider types" - a finding is a
    payable line of the code(s) whose provider type is KNOWN and not in the list. The BILLING provider by default (the
    provider that submits the claim); provider_role = 'servicing' reads the servicing provider; (v2.6, critic F1)
    'billing_or_rendering' reads the billing type, except on a GROUP's line (billing type in
    config.GROUP_BILLING_PROVIDER_TYPES) where the rendering (servicing) type is judged - the finding says which type it
    judged. A line with no provider type (of the role; the type judged) is never a finding: unknown is not a violation."""
    p = rule["predicate"]
    codes = [_q(c) for c in (p.get("code_set") or [p["code"]])]
    allowed = _allowed_types(p)
    role = str(p.get("provider_role") or "billing").strip().lower()
    route_sql, route = _routing(("a",), rule)
    in_list = ",".join(f"'{c}'" for c in codes)
    ok_list = ",".join(f"'{t}'" for t in allowed)
    severity = "provider_type_not_allowed"
    pa = f"CASE WHEN {_pa_true('a')} THEN 1 ELSE 0 END" if _pa_applies(rule) else None
    if role == ROLE_BILLING_OR_RENDERING:
        grp = _group_billing_sql("a")
        col = f"CASE WHEN {grp} THEN a.{PIE_PROV_TYPE} ELSE a.{PIE_BPROV_TYPE} END"
        finding = (f"CASE WHEN {grp} THEN CONCAT('{'/'.join(codes)} rendered by provider type ', a.{PIE_PROV_TYPE}, "
                   f"' for a group (', a.{PIE_BPROV_TYPE}, ') (allowed: {'/'.join(allowed)})')\n"
                   f"            ELSE CONCAT('{'/'.join(codes)} billed by provider type ', a.{PIE_BPROV_TYPE}, "
                   f"' (allowed: {'/'.join(allowed)})') END")
    else:
        col = "a." + {"billing": PIE_BPROV_TYPE, "servicing": PIE_PROV_TYPE}[role]
        finding = f"CONCAT('{'/'.join(codes)} billed by provider type ', {col}, ' (allowed: {'/'.join(allowed)})')"
    sql = f"""SELECT {_line_cols('a')}, {_edition_col(rule)},
       {finding} AS finding,
       a.{COL['units']} AS observed_units, 0 AS allowed_units,
       a.{COL['units']} AS excess_units, {_paid('a').replace(' AS paid_amt', '')} AS paid_at_risk,
       {_severity_sql(rule, severity, pa)}
FROM {DETECT} a
WHERE a.{COL['proc']} IN ({in_list})
  AND {_payable('a')}
  AND {col} IS NOT NULL AND {col} NOT IN ({ok_list}){route_sql}{_window('a', rule)}{_age_clause('a', p)}"""
    return sql, severity, route


_COMPILERS = {
    "provider_type_allowed": compile_provider_type_allowed,
    "code_pair_prohibited":  compile_code_pair,
    "max_units_per_line":    compile_units_per_line,
    "max_units_per_dos":     compile_units_per_dos,
    "max_units_per_day":     compile_units_per_day,
    "max_units_per_period":  compile_units_per_period,
    "code_not_covered":      compile_code_not_covered,
}

SUPPORTED_PREDICATES = tuple(_COMPILERS)


# ------------------------------------------------- detection snapshot (08)
def snapshot_sql(source: str | None = None, target: str | None = None) -> str:
    """The snapshot as one statement (CREATE OR REPLACE TABLE <snapshot> AS <snapshot_select_sql>) -
    for documentation and the run log. create_snapshot() executes the same SELECT through the
    DataFrame writer, which works on Delta AND on the open-source catalog the offline tests use."""
    return f"CREATE OR REPLACE TABLE {target or DETECT} AS\n" + snapshot_select_sql(source)


def create_snapshot(spark, source: str | None = None, target: str | None = None, fmt: str | None = None) -> str:
    """Build the detection snapshot. Returns the SELECT that was executed."""
    sel = snapshot_select_sql(source)
    fmt = fmt or getattr(config, "TABLE_FORMAT", "delta")
    (spark.sql(sel).write.format(fmt).mode("overwrite").option("overwriteSchema", "true")
     .saveAsTable(target or DETECT))
    return sel


def snapshot_select_sql(source: str | None = None) -> str:
    """SELECT ... - the normalised, de-duplicated claims every detector reads. Columns keep their claims-table names; pie_* columns are added:
      pie_dob          TRY_CAST(date_of_birth AS DATE) (NULL when missing/unparseable)
      pie_reversal     PMT_AMT < 0
      pie_cancelled    a positive line cancelled by a reversal row with the same member, provider,
                       date, code and modifiers and exactly opposite units and dollars (one reversal
                       cancels one line; a heuristic until the data owner names the adjustment key)
      pie_payable      PMT_AMT > 0, units > 0 (or NULL), and not cancelled
      pie_prov_type    the servicing provider type CODE, normalised (ncci_routing.type_sql)
      pie_bprov_type   the billing provider type CODE, normalised (NULL when the claims table has no billing type)
      pie_ncci_edition the NCCI edit file the line takes (CMS TGM Table 2; ncci_routing.edition_sql), NULL = none
      pie_units_raw    units as the claims table holds them
    Units: a reversal row (PMT_AMT < 0) carries NEGATIVE units here whatever sign the source uses - a money-back
    row never adds units (oracle R-01: a reversal booked with positive units used to double a daily sum and never
    cancelled its line). Rows with no member, date of service or procedure code are dropped (C1-05)."""
    src, c = source or CLAIMS, COL
    mods = [f"NULLIF(UPPER(TRIM(CAST({m} AS STRING))), '') AS {m}" for m in c["mods"]]
    cols = [f"CAST({c['claim_id']} AS STRING) AS {c['claim_id']}", c["line_no"],
            f"NULLIF(TRIM(CAST({c['member']} AS STRING)), '') AS {c['member']}",
            f"NULLIF(TRIM(CAST({c['provider']} AS STRING)), '') AS {c['provider']}"]
    if c["billing"] and c["billing"] != c["provider"]:
        cols.append(f"NULLIF(TRIM(CAST({c['billing']} AS STRING)), '') AS {c['billing']}")
    units = (f"CASE WHEN {c['paid']} < 0 THEN -ABS({c['units']}) ELSE {c['units']} END AS {c['units']}"
             if c["paid"] else c["units"])
    cols += [f"CAST({c['dos']} AS DATE) AS {c['dos']}",
             f"UPPER(TRIM(CAST({c['proc']} AS STRING))) AS {c['proc']}",
             units, f"{c['units']} AS {PIE_UNITS_RAW}"]
    if c["paid"]:
        cols.append(c["paid"])
    form_n = f"UPPER(TRIM(CAST({c['form']} AS STRING)))"
    cols.append(f"{form_n} AS {c['form']}")
    cols += mods
    if c["pa_no"]:
        cols.append(f"NULLIF(TRIM(CAST({c['pa_no']} AS STRING)), '') AS {c['pa_no']}")
    cols.append(_dob_expr())
    ptype = ncci_routing.type_sql(c["prov_type"]) if c["prov_type"] else "CAST(NULL AS STRING)"
    btype = ncci_routing.type_sql(c["billing_type"]) if c.get("billing_type") else "CAST(NULL AS STRING)"
    cols.append(f"{ptype} AS {PIE_PROV_TYPE}")
    cols.append(f"{btype} AS {PIE_BPROV_TYPE}")
    # the edit file from the CLEANED columns (computed once above): inlining the clean-up into every comparison of
    # the CASE made Spark's generated code for the DISTINCT exceed 64 KB (2026-10-03 simulation)
    edition = ncci_routing.edition_sql(c["form"], PIE_PROV_TYPE,
                                       billing_expr=PIE_BPROV_TYPE if c.get("billing_type") else None)
    keys = [c["member"], c["provider"], c["dos"], c["proc"]] + c["mods"]
    paid = c["paid"]
    neg_paid = f"-{paid}" if paid else "CAST(NULL AS DOUBLE)"
    on = " AND ".join(f"r.{k} <=> n.{k}" for k in keys) + f" AND r.{c['units']} <=> n.r_units"
    if paid:
        on += f" AND r.{paid} <=> n.r_paid"
    pos = f"r.{paid} > 0" if paid else "TRUE"
    neg = f"{paid} < 0" if paid else "FALSE"
    names = [x.split(" AS ")[-1].strip() for x in cols] + [PIE_EDITION]
    sel = ",\n       ".join(f"r.{n}" for n in names)
    return f"""WITH src AS (
  SELECT DISTINCT
       {(',' + chr(10) + '       ').join(cols)}
  FROM {src}
),
keyed AS (
  SELECT *, {edition} AS {PIE_EDITION} FROM src
  WHERE {c['member']} IS NOT NULL AND {c['dos']} IS NOT NULL AND {c['proc']} IS NOT NULL AND {c['proc']} <> ''
),
neg AS (
  SELECT {', '.join(keys)}, -{c['units']} AS r_units, {neg_paid} AS r_paid, COUNT(*) AS n_rev
  FROM keyed WHERE {neg}
  GROUP BY {', '.join(keys)}, -{c['units']}, {neg_paid}
),
ranked AS (
  SELECT k.*, ROW_NUMBER() OVER (PARTITION BY {', '.join(keys)}, {c['units']}{', ' + paid if paid else ''}
                                 ORDER BY {_cancel_order(c)}) AS pie_rn
  FROM keyed k
)
SELECT {sel},
       COALESCE({pos} AND r.pie_rn <= COALESCE(n.n_rev, 0), FALSE) AS {PIE_CANCELLED},
       COALESCE({('r.' + paid + ' < 0') if paid else 'FALSE'}, FALSE) AS {PIE_REVERSAL},
       COALESCE({pos} AND COALESCE(r.{c['units']}, 1) > 0 AND r.pie_rn > COALESCE(n.n_rev, 0), FALSE) AS {PIE_PAYABLE}
FROM ranked r
LEFT JOIN neg n ON {on}"""


def _cancel_order(c: dict) -> str:
    """Which of several identical lines a reversal cancels first: by claim id, then line NUMBER (numeric whatever the
    column type, as evidence is ordered), then - for rows of one claim line that differ in a column outside the match
    (2026-10-03, oracle v2.2: two rows of one line with different billing types took the cancellation in no defined
    order, so a rerun on the same data could flag the other row) - claim form, PA number, servicing type, billing
    type, billing provider, date of birth. Ascending, missing first. Deterministic: the same data, the same findings."""
    keys = [c["claim_id"], f"TRY_CAST(CAST({c['line_no']} AS STRING) AS DOUBLE)", c["line_no"], c["form"]]
    keys += [c["pa_no"]] if c["pa_no"] else []
    keys += [PIE_PROV_TYPE, PIE_BPROV_TYPE]
    keys += [c["billing"]] if c["billing"] and c["billing"] != c["provider"] else []
    keys += [PIE_DOB]
    return ", ".join(f"{k} ASC NULLS FIRST" for k in keys)


def _dob_expr() -> str:
    """Member date of birth as a DATE. A DATE / TIMESTAMP / ISO-string column needs only TRY_CAST;
    a string in another layout needs config.DOB_FORMAT (e.g. 'MM/dd/yyyy'). Unreadable -> NULL: the
    line can then never match an age condition (missed, never wrongly flagged)."""
    c = COL["dob"]
    if not c:
        return f"CAST(NULL AS DATE) AS {PIE_DOB}"
    fmt = getattr(config, "DOB_FORMAT", None)
    if fmt:
        if "'" in str(fmt):
            raise ValueError(f"bad DOB_FORMAT {fmt!r}")
        return f"CAST(TRY_TO_TIMESTAMP(CAST({c} AS STRING), '{fmt}') AS DATE) AS {PIE_DOB}"
    return f"TRY_CAST({c} AS DATE) AS {PIE_DOB}"


def snapshot_stats_sql(source: str | None = None, target: str | None = None) -> str:
    """One row: what the snapshot kept and why lines were not payable (written to the run log)."""
    src, tgt, c = source or CLAIMS, target or DETECT, COL
    paid = c["paid"]
    dob = f"SUM(CASE WHEN {PIE_DOB} IS NULL THEN 1 ELSE 0 END)"
    # 2026-10-05 (critic re-check N2): payable lines the v2.6 table readings cannot judge - no billing provider id
    # (member_servicing_billing_day never pairs / counts them), a group's line with no rendering type (B2
    # billing_or_rendering never flags it): misses, logged per run
    b = c.get("billing")
    bmiss = (f"SUM(CASE WHEN {PIE_PAYABLE} AND {b} IS NULL THEN 1 ELSE 0 END)" if b else "CAST(NULL AS BIGINT)")
    try:
        grp = _group_billing_sql("x").replace("x.", "")
    except ValueError:
        grp = "FALSE"
    gmiss = f"SUM(CASE WHEN {PIE_PAYABLE} AND {grp} AND {PIE_PROV_TYPE} IS NULL THEN 1 ELSE 0 END)"
    return f"""SELECT
  (SELECT COUNT(*) FROM {src}) AS source_rows,
  COUNT(*) AS snapshot_rows,
  SUM(CASE WHEN {PIE_PAYABLE} THEN 1 ELSE 0 END) AS payable_lines,
  SUM(CASE WHEN {PIE_REVERSAL} THEN 1 ELSE 0 END) AS reversal_rows,
  SUM(CASE WHEN {PIE_CANCELLED} THEN 1 ELSE 0 END) AS cancelled_lines,
  SUM(CASE WHEN {('NOT ' + PIE_REVERSAL + ' AND ' + paid + ' = 0') if paid else 'FALSE'} THEN 1 ELSE 0 END) AS zero_paid_lines,
  SUM(CASE WHEN {c['units']} IS NULL OR {c['units']} <= 0 THEN 1 ELSE 0 END) AS nonpositive_unit_lines,
  {dob} AS dob_missing_lines,
  {bmiss} AS payable_lines_no_billing_id,
  {gmiss} AS payable_group_lines_no_rendering_type
FROM {tgt}"""


# ------------------------------------------------ table-driven NCCI (batch)
# One SQL statement per rule cannot cover NCCI: ~500k PTP pairs meant ~500k claims self-joins, so
# run_detectors capped runs at 300 detectors and MUEs effectively never ran. NCCI PTP pairs and
# per-line MUEs are therefore written as DATA (two edit tables) and checked by ONE statement each.
# Semantics are identical to compile_code_pair / compile_units_per_line for NCCI rules (form route,
# member_provider_day scope, full modifier logic, payable lines, per-rule window); the Spark tests
# run both paths on the same claims and require the same findings (as multisets).
BATCH_PTP, BATCH_MUE = "ncci_ptp", "ncci_mue"
PTP_EDIT_COLUMNS = ["rule_id", "ncci_edition", "code_a", "code_b", "modifier_indicator", "effective_date", "end_date",
                    "finding", "finding_severity"]
MUE_LIMIT_COLUMNS = ["rule_id", "ncci_edition", "code", "threshold", "later_max_threshold", "removed_later",
                     "effective_date", "end_date", "finding"]


def batch_kind(rule: dict) -> str | None:
    if rule.get("origin") != "ncci":
        return None
    t = (rule.get("predicate") or {}).get("type")
    return BATCH_PTP if t == "code_pair_prohibited" else BATCH_MUE if t == "max_units_per_line" else None


def ncci_edit_tables(rules: list[dict]):
    """(ptp_edits, mue_limits) as pandas frames - the rows the batch SQL joins to. Only rules that
    COMPILE are written (a rule whose compile fails stays a lead and must not run here either)."""
    import pandas as pd
    ptp, mue = [], []
    for r in rules:
        k = batch_kind(r)
        if k is None or r.get("deactivated") or not r.get("machine_checkable", True):
            continue
        p = r["predicate"]
        try:
            eff, end = _rule_window(r)
            ed = _ncci_edition(r)
            base = {"rule_id": r["rule_id"], "ncci_edition": ed, "effective_date": eff, "end_date": end}
            if k == BATCH_PTP:
                a, b = _q(p["code_a"]), _q(p["code_b"])
                mi = schema.normalize_indicator(p.get("modifier_indicator"), "ncci")
                if a == b or mi is None:
                    continue
                ptp.append({**base, "code_a": a, "code_b": b, "modifier_indicator": mi,
                            "finding": f"{b} billed with {a}",
                            "finding_severity": "hard_denial" if mi == "0" else "unbypassed_pair"})
            else:
                c, v = _q(p["code"]), int(p["threshold"])
                lm = p.get("later_max_threshold")
                mue.append({**base, "code": c, "threshold": v,
                            "later_max_threshold": None if lm is None else int(lm),
                            "removed_later": bool(p.get("removed_later", False)),
                            "finding": f"{c} units per line > {v}"})
        except (ValueError, KeyError, TypeError):
            continue
    p_df = pd.DataFrame(ptp, columns=PTP_EDIT_COLUMNS)
    m_df = pd.DataFrame(mue, columns=MUE_LIMIT_COLUMNS)
    m_df["later_max_threshold"] = m_df["later_max_threshold"].astype("Int64")
    m_df["removed_later"] = m_df["removed_later"].astype(bool)
    return p_df, m_df


def _table_window(alias: str, e: str = "e") -> str:
    d = f"{alias}.{COL['dos']}"
    return (f"\n  AND ({e}.effective_date IS NULL OR {d} >= CAST({e}.effective_date AS DATE))"
            f"\n  AND ({e}.end_date IS NULL OR {d} <= CAST({e}.end_date AS DATE))")


def batch_ptp_sql(edits_table: str = None, build_id: str | None = None) -> str:
    """All NCCI PTP edits in one statement.

    Plan (C1-12): a busy member-provider-day with n Column One lines and m Column Two lines used to be
    joined line x line (n*m rows, 97% of one fixture run from ONE facility day) before the edit was
    even looked up. Now candidate (day, code_a, code_b) triples are found from DISTINCT codes per day
    first (small), the edit table is broadcast, and only matching lines are joined. Multiset-equal to
    the per-rule path. build_id (C1-19/C4-01): the statement only reads edit rows of the build it was
    compiled for, so a half-written build can never mix old SQL with new edits."""
    t = edits_table or PTP_EDITS_TABLE
    c = COL
    g = [c["member"], c["provider"], c["dos"], PIE_EDITION]
    gl = ", ".join(g)
    bfilter = f" WHERE build_id = '{build_id}'" if build_id else ""
    on_g = " AND ".join(f"a.{k} = b.{k}" for k in g)
    inner = f"""SELECT /*+ BROADCAST(e) */ {_line_cols('b')}, e.ncci_edition AS ncci_edition,
       a.{c['claim_id']} AS col1_claim_id, a.{c['line_no']} AS col1_line_no,
       'member_provider_day' AS pair_scope, e.finding AS finding,
       e.finding_severity AS finding_severity_q, e.finding_severity AS finding_basis, CAST(NULL AS INT) AS pa_flag,
       e.rule_id AS rule_id
FROM cand k
JOIN e ON e.code_a = k.code_a AND e.code_b = k.code_b AND e.ncci_edition = k.{PIE_EDITION}
JOIN lines a ON a.{c['member']} = k.{c['member']} AND a.{c['provider']} = k.{c['provider']}
            AND a.{c['dos']} = k.{c['dos']} AND a.{PIE_EDITION} = k.{PIE_EDITION} AND a.{c['proc']} = k.code_a
JOIN lines b ON {on_g} AND b.{c['proc']} = k.code_b AND {_not_same_line()}
WHERE (e.modifier_indicator = '0' OR {_indicator1_flags()}){_table_window('b')}"""
    return f"""WITH e AS (SELECT rule_id, ncci_edition, code_a, code_b, modifier_indicator, effective_date, end_date,
                  finding, finding_severity FROM {t}{bfilter}),
lines AS (SELECT * FROM {DETECT}
          WHERE {PIE_PAYABLE} AND {c['provider']} IS NOT NULL
            AND {PIE_EDITION} IN (SELECT DISTINCT ncci_edition FROM e)),
da AS (SELECT DISTINCT {gl}, {c['proc']} AS code_a FROM lines WHERE {c['proc']} IN (SELECT code_a FROM e)),
db AS (SELECT DISTINCT {gl}, {c['proc']} AS code_b FROM lines WHERE {c['proc']} IN (SELECT code_b FROM e)),
cand AS (SELECT /*+ BROADCAST(e) */ DISTINCT {', '.join('da.' + k for k in g)}, da.code_a, db.code_b
         FROM da JOIN db ON {' AND '.join(f'da.{k} = db.{k}' for k in g)}
         JOIN e ON e.code_a = da.code_a AND e.code_b = db.code_b AND e.ncci_edition = da.{PIE_EDITION})
{_pair_rollup(inner, keep_rule_id=True)}"""


def batch_mue_sql(limits_table: str = None, build_id: str | None = None) -> str:
    """All per-line NCCI MUEs in one statement. C2-03: CMS raises and deletes MUEs retroactively and
    the public files are undated, so a line within a LATER quarter's higher value (or of a code a later
    quarter removed) is 'verify_mue_changed_later', never a plain violation."""
    t = limits_table or MUE_LIMITS_TABLE
    bfilter = f" WHERE build_id = '{build_id}'" if build_id else ""
    u = f"a.{COL['units']}"
    return f"""WITH m AS (SELECT rule_id, ncci_edition, code, threshold, later_max_threshold, removed_later,
                  effective_date, end_date, finding FROM {t}{bfilter})
SELECT /*+ BROADCAST(m) */ {_line_cols('a')}, m.ncci_edition AS ncci_edition,
       m.finding AS finding, {u} AS observed_units, m.threshold AS allowed_units,
       {u} - m.threshold AS excess_units, {_paid('a').replace(' AS paid_amt', '')} AS paid_at_risk,
       CASE WHEN COALESCE(m.removed_later, FALSE)
                 OR (m.later_max_threshold IS NOT NULL AND {u} <= m.later_max_threshold)
            THEN '{VERIFY_MUE_CHANGED}' ELSE 'units_over_limit' END AS finding_severity,
       'units_over_limit' AS finding_basis, CAST(NULL AS INT) AS pa_present, m.rule_id AS rule_id
FROM {DETECT} a
JOIN m ON a.{COL['proc']} = m.code AND a.{PIE_EDITION} = m.ncci_edition
WHERE {u} > m.threshold AND {_payable('a')}{_table_window('a', 'm')}"""


# ------------------------------------------------ table-driven AHCCCS rule tables (batch, v5.2)
# 2026-10-04 (v5.2): AHCCCS publishes billing rules as DATA - the Same Day Disallow table, the HCPCS/CPT procedures with
# daily limits, the B2 matrix - and ahcccs_tables.py reads every version of them into rules with origin "ahcccs_table".
# Thousands of cells would be thousands of per-rule statements (each pair a claims self-join), so, as for NCCI, the
# rules are written as DATA (three edit tables, one row per rule - a code set one row per distinct code) and checked by
# ONE statement each. They are STATE rules, not NCCI: no edit-file routing (every line), a PA on file is evaluated
# ('verify_pa'), the predicate's qualifiers label findings (the Same Day Disallow note 2 exception -> 'verify_exception'),
# a pair's scope is its own (D -> member_day, A* -> config.AHCCCS_SAME_PROVIDER_SCOPE: v2.6 member_servicing_billing_day)
# and a daily limit's too (config.AHCCCS_DAILY_LIMIT_SCOPE). Each statement is
# multiset-equal, on every output column, to running the per-rule SQL of the same rules (tests/test_sql_spark.py, random
# claims); a table rule the statements cannot express (an age condition) is not batched and runs per rule.
TABLE_ORIGIN = "ahcccs_table"
BATCH_AHCCCS_PAIR, BATCH_AHCCCS_DAILY, BATCH_AHCCCS_PTYPE = "ahcccs_same_day", "ahcccs_daily_max", "ahcccs_provider_type"
TABLE_BATCH_PREDICATE = {BATCH_AHCCCS_PAIR: "code_pair_prohibited", BATCH_AHCCCS_DAILY: "max_units_per_day",
                         BATCH_AHCCCS_PTYPE: "provider_type_allowed"}
TABLE_BATCHES = tuple(TABLE_BATCH_PREDICATE)
# the KB tables 07 writes (current; + "_history" when config.KEEP_NCCI_EDIT_HISTORY) and the statements read
TABLE_BATCH_EDIT_TABLE = {BATCH_AHCCCS_PAIR: "policy_ahcccs_pair_edits", BATCH_AHCCCS_DAILY: "policy_ahcccs_daily_limits",
                          BATCH_AHCCCS_PTYPE: "policy_ahcccs_provider_types"}
AHCCCS_PAIR_EDITS_TABLE = f"{KB}.{TABLE_BATCH_EDIT_TABLE[BATCH_AHCCCS_PAIR]}"
AHCCCS_DAILY_LIMITS_TABLE = f"{KB}.{TABLE_BATCH_EDIT_TABLE[BATCH_AHCCCS_DAILY]}"
AHCCCS_PTYPE_TABLE = f"{KB}.{TABLE_BATCH_EDIT_TABLE[BATCH_AHCCCS_PTYPE]}"
# Edit-table columns (what each statement joins to; dates are ISO text, inclusive, NULL = open):
#   pairs   code_a = the evidence line's code (the per-diem COLUMN code of the Same Day Disallow table), code_b = the
#           finding line's code (the ROW code); pair_scope member_day | member_provider_day |
#           member_servicing_billing_day; modifier_indicator '0' | '1'; finding = the per-rule finding text;
#           finding_severity = the label before PA (verify_exception / discretionary / the basis); finding_basis =
#           hard_denial | unbypassed_pair; (v2.6) both_ways = TRUE when the version disallows the pair in both
#           directions (each line is then the finding of its own rule; AHCCCS would deny only one of them)
#   daily   code (one row per DISTINCT code of the rule; a code set adds over all of them), threshold (units),
#           daily_scope member_day | member_provider_day | member_servicing_billing_day, finding, finding_severity (the
#           label before PA / span / modifier), finding_basis (units_over_limit)
#   ptypes  code (one row per distinct code), provider_role billing | servicing | billing_or_rendering, allowed_types =
#           the cleaned, sorted provider type codes joined by '/', finding_prefix + <the line's type> + finding_suffix =
#           the per-rule finding text (v2.6: a group's line under billing_or_rendering: rendered_prefix + <rendering
#           type> + ' for a group (<billing type>)' + finding_suffix), finding_severity, finding_basis
#           (provider_type_not_allowed)
AHCCCS_PAIR_EDIT_COLUMNS = ["rule_id", "code_a", "code_b", "pair_scope", "modifier_indicator", "effective_date",
                            "end_date", "finding", "finding_severity", "finding_basis", "both_ways"]
AHCCCS_DAILY_LIMIT_COLUMNS = ["rule_id", "code", "threshold", "daily_scope", "effective_date", "end_date", "finding",
                              "finding_severity", "finding_basis"]
AHCCCS_PTYPE_COLUMNS = ["rule_id", "code", "provider_role", "allowed_types", "effective_date", "end_date",
                        "finding_prefix", "finding_suffix", "finding_severity", "finding_basis", "rendered_prefix"]
_KIND_BY_PREDICATE = {v: k for k, v in TABLE_BATCH_PREDICATE.items()}


def table_batch_kind(rule: dict) -> str | None:
    """The table batch statement a rule runs in, or None (it runs per rule, or not at all). Only rules with origin
    "ahcccs_table" of the three predicate types; a rule with an age condition is never batched (the statements carry no
    age test - it runs per rule, still exact)."""
    if rule.get("origin") != TABLE_ORIGIN:
        return None
    p = rule.get("predicate") or {}
    if p.get("age"):
        return None
    return _KIND_BY_PREDICATE.get(p.get("type"))


def _compiles(rule: dict) -> bool:
    """The checks build_detectors makes before it marks a rule compiled - so a rule has an edit row exactly when its
    detector row says compiled (a lead must never run through a batch statement)."""
    p = rule.get("predicate") or {}
    t = p.get("type")
    if rule.get("deactivated") or not rule.get("machine_checkable", True) or t not in _COMPILERS:
        return False
    if not schema.validate_predicate(p, origin=rule.get("origin"))[0]:
        return False
    try:
        _COMPILERS[t](rule)
    except Exception:
        return False
    return True


def ahcccs_edit_tables(rules: list[dict]):
    """(pairs, daily_limits, provider_types) as pandas frames with the columns above - the rows the three table batch
    statements join to. Only table rules that COMPILE and that a batch can express (table_batch_kind); a rule id seen
    twice is written once (a duplicate edit row would double its findings). Every value is derived with the per-rule
    compiler's own helpers (_q, _rule_window, pair_scope, daily_scope, _qualified, _allowed_types), so the batch and
    the per-rule SQL read one and the same rule."""
    import pandas as pd
    pairs, daily, ptypes, seen = [], [], [], set()
    for r in rules:
        k = table_batch_kind(r)
        if k is None or r.get("rule_id") in seen or not _compiles(r):
            continue
        seen.add(r.get("rule_id"))
        p = r["predicate"]
        eff, end = _rule_window(r)
        base = {"rule_id": r["rule_id"], "effective_date": eff, "end_date": end}
        if k == BATCH_AHCCCS_PAIR:
            a, b = _q(p["code_a"]), _q(p["code_b"])
            mi = schema.normalize_indicator(p.get("modifier_indicator"), r.get("origin"))
            basis = "hard_denial" if mi == "0" else "unbypassed_pair"
            pairs.append({**base, "code_a": a, "code_b": b, "pair_scope": pair_scope(r), "modifier_indicator": mi,
                          "finding": _pair_finding(r, a, b), "finding_severity": _qualified(r, basis),
                          "finding_basis": basis, "both_ways": _both_ways(r)})
        elif k == BATCH_AHCCCS_DAILY:
            codes = [_q(c) for c in (p.get("code_set") or [p["code"]])]
            val = int(p["threshold"])
            basis = "documentation_reviewable" if p.get("mai") == 3 else "units_over_limit"
            for c in dict.fromkeys(codes):
                daily.append({**base, "code": c, "threshold": val, "daily_scope": daily_scope(r),
                              "finding": f"{'/'.join(codes)} units per day > {val}",
                              "finding_severity": _qualified(r, basis), "finding_basis": basis})
        else:
            codes = [_q(c) for c in (p.get("code_set") or [p["code"]])]
            allowed = _allowed_types(p)
            basis = "provider_type_not_allowed"
            role = str(p.get("provider_role") or "billing").strip().lower()
            for c in dict.fromkeys(codes):
                ptypes.append({**base, "code": c, "provider_role": role,
                               "allowed_types": "/".join(allowed),
                               "finding_prefix": f"{'/'.join(codes)} billed by provider type ",
                               "finding_suffix": f" (allowed: {'/'.join(allowed)})",
                               "finding_severity": _qualified(r, basis), "finding_basis": basis,
                               # v2.6: a group's line judged on its rendering type (billing_or_rendering only)
                               "rendered_prefix": (f"{'/'.join(codes)} rendered by provider type "
                                                   if role == ROLE_BILLING_OR_RENDERING else None)})
    p_df = pd.DataFrame(pairs, columns=AHCCCS_PAIR_EDIT_COLUMNS)
    p_df["both_ways"] = p_df["both_ways"].astype(bool)           # a boolean column even when empty (stable table types)
    d_df = pd.DataFrame(daily, columns=AHCCCS_DAILY_LIMIT_COLUMNS)
    d_df["threshold"] = d_df["threshold"].astype("Int64")        # a long column even when empty (stable table types)
    t_df = pd.DataFrame(ptypes, columns=AHCCCS_PTYPE_COLUMNS)
    return p_df, d_df, t_df


def _bfilter(build_id: str | None) -> str:
    return f" WHERE build_id = '{build_id}'" if build_id else ""


def _table_severity_sql(pa_flag: str | None, e: str = "e") -> str:
    """_severity_sql for a batch: the qualified label and the basis come from the edit row. A table rule is a state
    rule, so a PA is evaluated whenever the claims table has a PA column (_pa_applies)."""
    if pa_flag is None:
        return (f"CAST(NULL AS INT) AS pa_present, {e}.finding_severity AS finding_severity, "
                f"{e}.finding_basis AS finding_basis")
    return (f"{pa_flag} AS pa_present,\n"
            f"       CASE WHEN {pa_flag} = 1 THEN '{VERIFY_PA}' ELSE {e}.finding_severity END AS finding_severity,\n"
            f"       {e}.finding_basis AS finding_basis")


def batch_ahcccs_pair_sql(table: str | None = None, build_id: str | None = None) -> str:
    """Every Same Day Disallow pair (policy_ahcccs_pair_edits) in one statement - multiset-equal to compile_code_pair
    of each rule: a payable code_b (row code) line is the finding, the payable code_a (per-diem column code) lines of the
    same member and day - and, for member_provider_day, the same servicing provider; (v2.6) for
    member_servicing_billing_day the same servicing AND billing provider id - are its evidence; a PA on EITHER line ->
    verify_pa; the edit row's window on the finding line. Plan (as batch_ptp_sql, C1-12): the DISTINCT candidate (day,
    code_a, code_b) triples are found first - per member-day, member-provider-day or member-servicing-billing-day as the
    edit row's scope says - against the broadcast edit table, and only matching lines are joined."""
    t = table or AHCCCS_PAIR_EDITS_TABLE
    c = COL
    pa = (f"CASE WHEN {_pa_true('a')} OR {_pa_true('b')} THEN 1 ELSE 0 END" if c["pa_no"] else "CAST(NULL AS INT)")

    def inner(scope: str, cand: str, keys: list) -> str:
        on_a = " AND ".join(f"a.{x} = k.{x}" for x in keys)
        on_b = " AND ".join(f"b.{x} = k.{x}" for x in keys)
        return f"""SELECT /*+ BROADCAST(e) */ {_line_cols('b')}, CAST(NULL AS STRING) AS ncci_edition,
       a.{c['claim_id']} AS col1_claim_id, a.{c['line_no']} AS col1_line_no,
       e.pair_scope AS pair_scope, e.finding AS finding,
       e.finding_severity AS finding_severity_q, e.finding_basis AS finding_basis, {pa} AS pa_flag,
       e.rule_id AS rule_id
FROM {cand} k
JOIN e ON e.pair_scope = '{scope}' AND e.code_a = k.code_a AND e.code_b = k.code_b
JOIN lines a ON {on_a} AND a.{c['proc']} = k.code_a
JOIN lines b ON {on_b} AND b.{c['proc']} = k.code_b AND {_not_same_line()}
WHERE (e.modifier_indicator = '0' OR {_indicator1_flags()}){_table_window('b')}"""
    md, mpd = [c["member"], c["dos"]], [c["member"], c["provider"], c["dos"]]
    # v2.6: member_servicing_billing_day = the same member, servicing provider, BILLING provider id and day. Without a
    # billing provider column no rule of that scope compiles (_billing_id_col), so the statement has no such branch.
    msbd = list(dict.fromkeys([c["member"], c["provider"], c["billing"], c["dos"]])) if c.get("billing") else None
    branches = [("member_day", "cand_md", md), ("member_provider_day", "cand_mpd", mpd)] + \
               ([(MSBD, "cand_msbd", msbd)] if msbd else [])
    union = "\nUNION ALL\n".join(inner(s, cand, keys) for s, cand, keys in branches)

    def cand(name, scope, x, y, keys):
        return (f"{name} AS (SELECT /*+ BROADCAST(e) */ DISTINCT {', '.join(f'{x}.{k}' for k in keys)}, {x}.code_a, "
                f"{y}.code_b\n             FROM {x} JOIN {y} ON {' AND '.join(f'{x}.{k} = {y}.{k}' for k in keys)}\n"
                f"             JOIN e ON e.pair_scope = '{scope}' AND e.code_a = {x}.code_a AND e.code_b = {y}.code_b)")
    # the distinct (day, code) rows of the finest grain first (one pass over the lines), then coarser grains from them
    full = msbd or mpd
    ctes = [f"da AS (SELECT DISTINCT {', '.join(full)}, {c['proc']} AS code_a FROM lines "
            f"WHERE {c['proc']} IN (SELECT code_a FROM e))",
            f"db AS (SELECT DISTINCT {', '.join(full)}, {c['proc']} AS code_b FROM lines "
            f"WHERE {c['proc']} IN (SELECT code_b FROM e))"]
    pa_, pb_ = ("da_p", "db_p") if msbd else ("da", "db")
    if msbd:
        ctes += [f"da_p AS (SELECT DISTINCT {', '.join(mpd)}, code_a FROM da)",
                 f"db_p AS (SELECT DISTINCT {', '.join(mpd)}, code_b FROM db)"]
    ctes += [f"da_m AS (SELECT DISTINCT {', '.join(md)}, code_a FROM da)",
             f"db_m AS (SELECT DISTINCT {', '.join(md)}, code_b FROM db)",
             cand("cand_md", "member_day", "da_m", "db_m", md),
             cand("cand_mpd", "member_provider_day", pa_, pb_, mpd)]
    if msbd:
        ctes.append(cand("cand_msbd", MSBD, "da", "db", msbd))
    return f"""WITH e AS (SELECT rule_id, code_a, code_b, pair_scope, modifier_indicator, effective_date, end_date,
                  finding, finding_severity, finding_basis FROM {t}{_bfilter(build_id)}),
lines AS (SELECT * FROM {DETECT}
          WHERE {PIE_PAYABLE} AND {c['proc']} IN (SELECT code_a FROM e UNION SELECT code_b FROM e)),
{(',' + chr(10)).join(ctes)}
{_pair_rollup(union, keep_rule_id=True)}"""


def batch_ahcccs_daily_sql(table: str | None = None, build_id: str | None = None) -> str:
    """Every AHCCCS daily limit (policy_ahcccs_daily_limits) in one statement - multiset-equal to compile_units_per_day
    of each rule: per rule, member, date - and servicing provider for member_provider_day (rows with no provider not
    counted); (v2.6) servicing AND billing provider id for member_servicing_billing_day (a row missing either not
    counted; the finding's servicing provider is the group's) - the counted rows' units (paid <> 0) are added; a finding
    when the sum is over the threshold and at least one of the rows is payable. The broadcast edit table is joined on
    the code; the threshold is cast to INT so the arithmetic (excess_units, paid_at_risk) has the per-rule SQL's types
    exactly."""
    t = table or AHCCCS_DAILY_LIMITS_TABLE
    c = COL
    thr = "CAST(e.threshold AS INT)"
    per_prov = ", ".join(f"'{s}'" for s in PER_PROVIDER_SCOPES)
    prov = f"CASE WHEN e.daily_scope IN ({per_prov}) THEN a.{c['provider']} END"
    # v2.6: member_servicing_billing_day groups by the billing provider id too (a row with no id is not counted); with
    # no billing provider column no rule of that scope compiles, and a stray edit row of it counts nothing
    bp = c.get("billing")
    bill = f"CASE WHEN e.daily_scope = '{MSBD}' THEN a.{bp} END" if bp else None
    bill_nn = (f"\n  AND (e.daily_scope <> '{MSBD}' OR a.{bp} IS NOT NULL)" if bp
               else f"\n  AND e.daily_scope <> '{MSBD}'")
    pa = f"MAX(CASE WHEN {_pa_true('a')} THEN 1 ELSE 0 END)" if c["pa_no"] else None
    return f"""WITH e AS (SELECT rule_id, code, threshold, daily_scope, effective_date, end_date, finding,
                  finding_severity, finding_basis FROM {t}{_bfilter(build_id)})
SELECT /*+ BROADCAST(e) */ a.{c['member']} AS member_id, {prov} AS servicing_provider,
       {bill or 'CAST(NULL AS STRING)'} AS billing_provider, a.{c['dos']} AS dos,
       {_paid('a', aggregate=True)}, CAST(NULL AS STRING) AS ncci_edition,
       e.finding AS finding,
       SUM(a.{c['units']}) AS observed_units, {thr} AS allowed_units,
       SUM(a.{c['units']}) - {thr} AS excess_units,
       {_paid_at_risk(thr)},
       {_evidence_lines('a')},
       {_daily_cap_case('e.finding_severity', 'e.finding_basis', pa, thr)},
       e.rule_id AS rule_id
FROM {DETECT} a
JOIN e ON a.{c['proc']} = e.code
WHERE (e.daily_scope NOT IN ({per_prov}) OR a.{c['provider']} IS NOT NULL){bill_nn}{_counted('a')}{_table_window('a')}
GROUP BY e.rule_id, e.threshold, e.daily_scope, e.finding, e.finding_severity, e.finding_basis, a.{c['member']},
         {prov},{(' ' + bill + ',') if bill else ''} a.{c['dos']}
HAVING SUM(a.{c['units']}) > {thr} AND MAX(CASE WHEN {_payable('a')} THEN 1 ELSE 0 END) = 1"""


def batch_ahcccs_ptype_sql(table: str | None = None, build_id: str | None = None) -> str:
    """Every B2-matrix provider-type rule (policy_ahcccs_provider_types) in one statement - multiset-equal to
    compile_provider_type_allowed of each rule: a payable line of the code whose provider type (BILLING by default,
    SERVICING for provider_role 'servicing') is KNOWN and not in the allowed list; a line with no type is never a
    finding. The broadcast edit table is joined on the code."""
    t = table or AHCCCS_PTYPE_TABLE
    c = COL
    # v2.6: billing_or_rendering judges a group's line (billing type in config.GROUP_BILLING_PROVIDER_TYPES) on its
    # rendering (servicing) type, and says so in the finding; every other line of that role on its billing type
    grp = f"e.provider_role = '{ROLE_BILLING_OR_RENDERING}' AND {_group_billing_sql('a')}"
    ptype = (f"CASE WHEN e.provider_role = 'servicing' THEN a.{PIE_PROV_TYPE}\n"
             f"            WHEN {grp} THEN a.{PIE_PROV_TYPE} ELSE a.{PIE_BPROV_TYPE} END")
    finding = (f"CASE WHEN {grp}\n"
               f"            THEN CONCAT(e.rendered_prefix, a.{PIE_PROV_TYPE}, ' for a group (', a.{PIE_BPROV_TYPE}, ')', "
               f"e.finding_suffix)\n"
               f"            ELSE CONCAT(e.finding_prefix, {ptype}, e.finding_suffix) END")
    pa = f"CASE WHEN {_pa_true('a')} THEN 1 ELSE 0 END" if c["pa_no"] else None
    return f"""WITH e AS (SELECT rule_id, code, provider_role, allowed_types, effective_date, end_date, finding_prefix,
                  finding_suffix, finding_severity, finding_basis, rendered_prefix FROM {t}{_bfilter(build_id)})
SELECT /*+ BROADCAST(e) */ {_line_cols('a')}, CAST(NULL AS STRING) AS ncci_edition,
       {finding} AS finding,
       a.{c['units']} AS observed_units, 0 AS allowed_units,
       a.{c['units']} AS excess_units, {_paid('a').replace(' AS paid_amt', '')} AS paid_at_risk,
       {_table_severity_sql(pa)},
       e.rule_id AS rule_id
FROM {DETECT} a
JOIN e ON a.{c['proc']} = e.code
WHERE {_payable('a')}
  AND {ptype} IS NOT NULL AND NOT ARRAY_CONTAINS(SPLIT(e.allowed_types, '/'), {ptype}){_table_window('a')}"""


TABLE_BATCH_SQL = {BATCH_AHCCCS_PAIR: batch_ahcccs_pair_sql, BATCH_AHCCCS_DAILY: batch_ahcccs_daily_sql,
                   BATCH_AHCCCS_PTYPE: batch_ahcccs_ptype_sql}


# ------------------------------------------------ utilization signals (not violations)
# The boss's question (2026-10-02): is the Oct-Sep contract year too rigid - could a provider time
# services around the reset? Policy limits are judged on the policy's own window (a 30-visit
# Aug-Nov run can be fully compliant: 15 per contract year). A ROLLING window is therefore a SIGNAL
# for the anomaly work, never a finding: per member, the most units in any rolling window of the
# period's length, and whether the fixed-period check also fired.
ROLLING_DAYS = {"month": 30, "year": 365, "benefit_year": 365}


def compile_rolling_signal(rule: dict, days: int | None = None) -> str | None:
    """SQL: one row per member whose units in some rolling window exceed the rule's threshold
    (max_units_per_period rules only). Columns: member_id, window_start, window_end, rolling_units,
    rolling_paid, allowed_units, rolling_days."""
    p = rule.get("predicate") or {}
    if p.get("type") != "max_units_per_period":
        return None
    codes = [_q(c) for c in (p.get("code_set") or ([p["code"]] if p.get("code") else []))]
    period = p.get("period", "month")
    n = int(days or getattr(config, "ROLLING_WINDOW_DAYS", {}).get(period) or ROLLING_DAYS[period])
    val = int(p["threshold"])
    in_list = ",".join(f"'{c}'" for c in codes)
    route_sql, _ = _routing(("a",), rule)
    paid = f"SUM(a.{COL['paid']})" if COL["paid"] else "CAST(NULL AS DOUBLE)"
    return f"""WITH daily AS (
  SELECT a.{COL['member']} AS member_id, a.{COL['dos']} AS dos, SUM(a.{COL['units']}) AS u, {paid} AS d
  FROM {DETECT} a
  WHERE a.{COL['proc']} IN ({in_list}){_counted('a')}{route_sql}{_window('a', rule)}{_age_clause('a', p)}
  GROUP BY a.{COL['member']}, a.{COL['dos']}
),
roll AS (
  SELECT member_id, dos AS window_end, DATE_SUB(dos, {n - 1}) AS window_start,
         SUM(u) OVER (PARTITION BY member_id ORDER BY UNIX_DATE(dos)
                      RANGE BETWEEN {n - 1} PRECEDING AND CURRENT ROW) AS rolling_units,
         SUM(d) OVER (PARTITION BY member_id ORDER BY UNIX_DATE(dos)
                      RANGE BETWEEN {n - 1} PRECEDING AND CURRENT ROW) AS rolling_paid
  FROM daily
),
ranked AS (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY member_id ORDER BY rolling_units DESC, window_end) AS rk
  FROM roll WHERE rolling_units > {val}
)
SELECT member_id, window_start, window_end, rolling_units, rolling_paid, {val} AS allowed_units,
       {n} AS rolling_days
FROM ranked WHERE rk = 1"""


# ---------------------------------------------------------------- driver
def _qualifier_label(rule: dict) -> str | None:
    p = rule.get("predicate") or {}
    bits = []
    if p.get("type") == "max_units_per_day" and daily_scope(rule) == "member_provider_day":
        bits.append("units per member and servicing provider per day")      # 2026-10-04 (v5.2): the scope is signed
    elif p.get("type") == "max_units_per_day" and daily_scope(rule) == MSBD:
        bits.append("units per member, servicing provider and billing provider per day")          # v2.6
    if p.get("type") == "provider_type_allowed" and \
            str(p.get("provider_role") or "").strip().lower() == ROLE_BILLING_OR_RENDERING:
        bits.append("billing provider type; a group's line (billing type "
                    f"{'/'.join(_group_billing_types_or_none()) or 'none configured'}) judged on its rendering "
                    "provider's type")                                                            # v2.6
    if p.get("type") == "code_pair_prohibited" and _both_ways(rule):
        bits.append("pair disallowed both ways (AHCCCS would deny one of the two lines)")        # v2.6
    if p.get("age"):
        bits.append(schema.age_label(p["age"]))
    if str(p.get("exception") or "").strip():
        bits.append(f"exception: {str(p['exception']).strip()[:120]}")
    if p.get("discretionary") is True:
        bits.append("discretionary (text says may)")
    return "; ".join(bits) or None


def build_detectors(rules: list[dict], batch_ncci: bool = False, batch_tables: bool = False) -> list[dict]:
    """batch_ncci=True: NCCI PTP / per-line MUE rules get a row with compiled=True,
    batch='ncci_ptp'|'ncci_mue' and NO per-rule SQL - they run through batch_*_sql().
    batch_tables=True (2026-10-04, v5.2): AHCCCS table rules (origin 'ahcccs_table') the table batches can express get
    compiled=True, batch='ahcccs_same_day'|'ahcccs_daily_max'|'ahcccs_provider_type' and NO per-rule SQL - they run
    through batch_ahcccs_*_sql(). Every other rule, and every rule with the switches off, keeps its per-rule SQL."""
    out = []
    for r in rules:
        p = r.get("predicate") or {}
        t = p.get("type")
        row = {
            "rule_id": r.get("rule_id"),
            "extraction_key": r.get("extraction_key"),   # stable join back to the review decision
            "origin": r.get("origin"),
            "plane": r.get("plane"),
            "predicate_type": t,
            "service_category": p.get("service_category"),
            "ncci_edition": p.get("ncci_edition"),
            "pair_scope": pair_scope(r) if t == "code_pair_prohibited" else None,
            "conditions": _qualifier_label(r),
            "statement": r.get("statement"),
            "source_doc": r.get("source_doc"),
            "source_locator": r.get("source_locator"),
            "source_url": r.get("source_url"),
            "doc_version": r.get("doc_version"),
            "doc_hash": r.get("doc_hash"),
            "effective_date": r.get("effective_date"),
            "end_date": r.get("end_date"),
            "routing": None,
            "compiled": False,
            "batch": None,
            "sql": None,
            "sql_sha256": None,
            # period limits only: the rolling-window utilization SIGNAL query (not a finding), stored and hashed at
            # build time like every other query so 08 runs exactly what was built and validated (v06)
            "signal_sql": None,
            "signal_sql_sha256": None,
            "finding_severity": None,
            "reason": None,
        }
        if r.get("deactivated"):
            row["reason"] = "deactivated"
            out.append(row)
            continue
        if not r.get("machine_checkable", True) or t == "not_checkable":
            row["reason"] = r.get("not_checkable_reason") or p.get("reason") or "not_checkable"
            out.append(row)
            continue
        fn = _COMPILERS.get(t)
        if fn is None:
            row["reason"] = f"predicate '{t}' not in grammar"
            out.append(row)
            continue
        ok, why = schema.validate_predicate(p, origin=r.get("origin"))
        if not ok:
            row["reason"] = f"invalid predicate: {why}"
            out.append(row)
            continue
        try:
            sql, severity, route = fn(r)
        except Exception as e:  # bad predicate payload -> lead, never a crash
            row["reason"] = f"compile error: {e}"
            out.append(row)
            continue
        kind = (batch_kind(r) if batch_ncci else None) or (table_batch_kind(r) if batch_tables else None)
        row.update(compiled=True, sql=None if kind else sql, batch=kind,
                   sql_sha256=None if kind else sql_sha256(sql),
                   finding_severity=_qualified(r, severity), routing=route)
        if t == "max_units_per_period" and not kind:
            sig = compile_rolling_signal(r)
            row.update(signal_sql=sig, signal_sql_sha256=sql_sha256(sig))
        out.append(row)
    return out


def summarize(detectors: list[dict]) -> dict:
    s = {"compiled": 0, "leads": 0, "unrouted": 0, "batched": 0, "per_rule_sql": 0, "signal_sql": 0,
         "by_predicate": {}, "by_batch": {}, "lead_reasons": {}}
    for d in detectors:
        key = d["predicate_type"]
        s["by_predicate"][key] = s["by_predicate"].get(key, 0) + 1
        if d["compiled"]:
            s["compiled"] += 1
            s["batched"] += bool(d.get("batch"))
            if d.get("batch"):                      # rules per batch statement (NCCI and, v5.2, the AHCCCS tables)
                s["by_batch"][d["batch"]] = s["by_batch"].get(d["batch"], 0) + 1
            s["per_rule_sql"] += bool(d.get("sql"))
            s["signal_sql"] += bool(d.get("signal_sql"))
            if str(d["routing"]).startswith("UNROUTED"):
                s["unrouted"] += 1
        else:
            s["leads"] += 1
            s["lead_reasons"][d["reason"]] = s["lead_reasons"].get(d["reason"], 0) + 1
    return s
