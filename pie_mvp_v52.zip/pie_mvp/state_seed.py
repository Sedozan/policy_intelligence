"""
state_seed.py  -  a self-contained, cited seed of AHCCCS state rules.

These are the real Chapter 10 / Chapter 19 rules from the PoC, transcribed with
their citations. The migration notebook writes them to main.sedo.state_rules so
the build does NOT depend on importing the old hand-authored Python modules
(ingest_ahcccs, demo_*, ch10_full_extract) — which is what failed.

Every rule carries origin='manual'. The grammar upgrades are already applied:
non-covered codes use code_not_covered; the CHW caps are cross-code (code_set)
caps. rule_id is left blank; the build derives a stable one.

Every code pair carries an EXPLICIT scope that matches its source text (the grammar
contract: a state pair without scope compiles to the narrow member_provider_day, so
a wider reading must be written down - and these seeds are only signed once a reviewer
approves them in the workbook, C4-05). Pairs and caps that are this seed's reading
rather than the text's words carry ambiguity_flag=True with the reason.
"""
from __future__ import annotations

from schema import Rule

CH19 = "AHCCCS FFS Provider Billing Manual, Chapter 19 Behavioral Health Services"
CH19_URL = "https://www.azahcccs.gov/PlansProviders/Downloads/FFSProviderManual/FFS_Chap19BehavioralHealth.pdf"
CH10 = "AHCCCS FFS Provider Billing Manual, Chapter 10 Individual Practitioner Services"
CH10_URL = "https://www.azahcccs.gov/PlansProviders/Downloads/FFSProviderManual/FFS_Chap10.pdf"
CH14 = "AHCCCS FFS Provider Billing Manual, Chapter 14 Transportation Services"
CH14_URL = "https://www.azahcccs.gov/PlansProviders/Downloads/FFSProviderManual/FFS_Chap14Transportation.pdf"

_PAIR_FIELDS = ["proc_cd", "member_id", "provider_id", "srvc_bgn_dt", "mod_1", "mod_2", "mod_3", "mod_4"]
_UNIT_FIELDS = ["proc_cd", "units", "member_id", "srvc_bgn_dt"]


def _pair(a, b, svc, doc, url, loc, note, scope="member_day", ambiguous=False, anote=None, eff=None):
    # scope=member_day: a prohibition phrased "for the same member" must catch a pair split
    # across two providers (unlike NCCI, which is per provider). member_provider_day: the text's
    # subject is the billing provider. The finding is reported on code_b's line (detector_gen:
    # line b is the one "billed with" a), so code_b is the code the text says is denied, if it says.
    who = "for the same member" if scope == "member_day" else "by the same provider for the same member"
    return Rule(origin="manual", plane="coverage_scope", binding_status="state_policy",
                statement=f"{a} and {b} may not be billed on the same day {who}.",
                predicate={"type": "code_pair_prohibited", "code_a": a, "code_b": b,
                           "modifier_indicator": "0", "service_category": svc, "scope": scope},
                codes=[a, b], population="all", machine_checkable=True,
                ambiguity_flag=ambiguous, ambiguity_note=anote, effective_date=eff,
                required_claim_fields=_PAIR_FIELDS,
                source_doc=doc, source_locator=loc, source_url=url, notes=note)


def _cap_day(code, n, doc, url, loc, note, ambiguous=False, anote=None, statement=None):
    """A per-member daily unit cap. `code` is one code, or a list = one cap over ALL of them
    combined (code_set) - a combined cap is not three per-code caps (C3-04: 2+2+1 = 5 units
    breaks a 4-unit combined cap while every per-code cap passes)."""
    codes = list(code) if isinstance(code, (list, tuple)) else [code]
    pred = ({"type": "max_units_per_day", "code_set": codes, "threshold": n} if len(codes) > 1 else
            {"type": "max_units_per_day", "code": codes[0], "threshold": n})
    return Rule(origin="manual", plane="coverage_scope", binding_status="state_policy",
                statement=statement or f"{codes[0]}: maximum {n} unit(s) per day.",
                predicate=pred,
                codes=codes, population="all", machine_checkable=True,
                ambiguity_flag=ambiguous, ambiguity_note=anote,
                required_claim_fields=_UNIT_FIELDS,
                source_doc=doc, source_locator=loc, source_url=url, notes=note)


def _cap_dos(code, n, doc, url, loc, note, statement, exception=None, anote=None):
    """A per-member, per-PROVIDER, per-date cap (max_units_per_dos) - the text's subject is one provider / one trip."""
    pred = {"type": "max_units_per_dos", "code": code, "threshold": n}
    if exception:
        pred["exception"] = exception
    return Rule(origin="manual", plane="coverage_scope", binding_status="state_policy", statement=statement,
                predicate=pred, codes=[code], population="all", machine_checkable=True,
                ambiguity_flag=bool(anote), ambiguity_note=anote,
                required_claim_fields=_UNIT_FIELDS + ["provider_id"],
                source_doc=doc, source_locator=loc, source_url=url, notes=note)


def _not_covered(code, doc, url, loc, note):
    return Rule(origin="manual", plane="coverage_scope", binding_status="state_policy",
                statement=f"{code} is not a covered/reimbursable service; a paid claim is a finding.",
                predicate={"type": "code_not_covered", "code": code},
                codes=[code], population="all", machine_checkable=True,
                required_claim_fields=["proc_cd"],
                source_doc=doc, source_locator=loc, source_url=url, notes=note)


def _lead(statement, codes, reason, doc, url, loc, note, ambiguous=False, anote=None):
    return Rule(origin="manual", plane="coverage_scope", binding_status="state_policy",
                statement=statement,
                predicate={"type": "not_checkable", "reason": reason},
                codes=codes, population="all", machine_checkable=False,
                not_checkable_reason=reason, ambiguity_flag=ambiguous, ambiguity_note=anote,
                required_claim_fields=[],
                source_doc=doc, source_locator=loc, source_url=url, notes=note)


# Ch.19 (verbatim, verified 2026-10-02 against the public PDF, where it sits on p.31; the PoC locator
# 'page 30' is kept so the citation matches the transcription): "Providers are prohibited from
# billing S5151 with H0001, H0002, H0004, H0006, H0018 H0025, H0034, H0036, H2012, H2014, H2015, H2017,
# H2019, H2025, H2027, H2033, S5150. T1019. H0031, H0038, H0030 or any other per diem code on the same day."
_S5151_NOTE = ("INTERPRETATION, not the text's words: {b} is not in the listed codes; it is paired here only "
               "because it is a per diem code ('or any other per diem code on the same day'). Scope: the "
               "sentence's subject is the billing provider ('Providers are prohibited from billing S5151 "
               "with ...'), so this seed uses the narrow member_provider_day (a member-level reading is the "
               "reviewer's to decide). The finding is on the S5151 line: S5151 is what the text prohibits.")
# 2026-10-03 (independent re-read, agent S; revision table re-read by Claude): the Ch.19 revision of 07/08/2024 "Added
# Respite Care (Unskilled) section" and "Added Case Management Section", and the previous FFS version (10/01/2021)
# has neither sentence. A rule with no effective date judges EVERY date of service, so these pairs start 2024-07-08
# (an SME may give an earlier date if the rule was in force before, e.g. through the CBHSG).
CH19_RESPITE_CM_FROM = "2024-07-08"
_DATED = (" Effective 2024-07-08: the Ch.19 revision of 07/08/2024 added this section (revision table: 'Added {sec} "
          "section'); the 10/01/2021 version has no such sentence.")


def seed_rules() -> list[Rule]:
    R: list[Rule] = []

    # ---- Chapter 19 (Behavioral Health) ----
    R.append(_cap_day("S5150", 48, CH19, CH19_URL, "page 30",
                      "Unskilled respite: up to 12 hours/day x 4 quarter-hour units = 48. The number 48 is derived, not verbatim.",
                      ambiguous=True,
                      anote=("DERIVED, not verbatim: Ch.19 defines S5150 (per 15 minutes) as respite 'up to 12 hours "
                             "in duration' (S5151 per diem is for more than 12 hours); 12 h x 4 quarter-hour units "
                             "= 48 units/day is this seed's reading - the text states no per-day unit cap. Ch.21 "
                             "(ALTCS) allows more than 12 hours in a 24-hour period when authorized: an over-cap "
                             "line with a PA is verify_pa.")))
    R.append(_pair("H2016", "S5151", "state_bh", CH19, CH19_URL, "page 31",
                   "H2016 is a per-diem code (Ch.19 p.20). Resolved from open class 'or any other per diem code' (p.31)."
                   + _DATED.format(sec="Respite Care (Unskilled)"),
                   scope="member_provider_day", ambiguous=True, anote=_S5151_NOTE.format(b="H2016"),
                   eff=CH19_RESPITE_CM_FROM))
    R.append(_pair("S9485", "S5151", "state_bh", CH19, CH19_URL, "page 31",
                   "S9485 is a per-diem code (Ch.19 p.24). Resolved from open class 'or any other per diem code' (p.31)."
                   + _DATED.format(sec="Respite Care (Unskilled)"),
                   scope="member_provider_day", ambiguous=True, anote=_S5151_NOTE.format(b="S9485"),
                   eff=CH19_RESPITE_CM_FROM))
    # H2025/H2026/H2027 cannot be billed on the same day -> three pairs
    for a, b in [("H2025", "H2026"), ("H2025", "H2027"), ("H2026", "H2027")]:
        R.append(_pair(a, b, "state_bh", CH19, CH19_URL, "page 30",
                       'Verbatim: "Service codes H2025, H2026, and H2027 cannot be billed on the same day." '
                       "Scope: the text names neither member nor provider; member_day (same member, any "
                       "provider) is this seed's reading and is the reviewer's to confirm (the narrow "
                       "alternative is member_provider_day).",
                       scope="member_day"))
    R.append(_lead(
        "Respite services are limited to 600 hours per benefit year (Oct 1 - Sep 30) per member, "
        "inclusive of behavioral health and ALTCS respite.",
        ["S5150", "S5151"], "unit_incommensurability", CH19, CH19_URL, "page 30",
        "Cannot be mechanized: S5150 bills in 15-min units, S5151 per diem with no hours-per-diem conversion in policy. "
        "A policy finding, not a detector.",
        ambiguous=True,
        anote=("S5150 hours are countable (units x 0.25); S5151 per-diem hours are undefined in any AHCCCS source. "
               "The limit was 720 hours in the COVID-19 benefit years (back to 600 from 10/1/2021).")))

    # ---- Chapter 10 (Individual Practitioner) ----
    R.append(_lead(
        "AHCCCS follows Medicare's Correct Coding Initiative (CCI) and performs CCI edits/audits on FFS claims "
        "for the same provider, member, and date of service.",
        [], "policy_reference", CH10, CH10_URL, "page 2",
        "The legal basis that connects the NCCI quarterly ingest to Arizona Medicaid authority. Not itself a detector."))
    # Ch.10 p.9 (verbatim, verified 2026-09-20 and again 2026-10-02 against the public PDF): "Claims can
    # be submitted for a maximum of four units per day, up to 24 units per month per member (total units
    # allowable is inclusive of all 3 billable codes; codes cannot be billed together on the same day for
    # the same member)." / "Medicaid billable service codes for CHW/CHR services are limited to the
    # following: 98960, 98961, and 98962." / "If additional services are medically necessary, prior
    # authorization would be required."
    _PA_NOTE = (" PA exception: 'If additional services are medically necessary, prior authorization "
                "would be required' - an over-limit line with EVENT_PA_NO populated is 'verify_pa', not a violation.")
    _CHW = ["98960", "98961", "98962"]
    # ONE combined daily cap (was three per-code caps, which let 98960 x 3 + 98961 x 2 = 5 units pass):
    # "total units allowable is inclusive of all 3 billable codes"
    R.append(_cap_day(_CHW, 4, CH10, CH10_URL, "page 9",
                      "CHW/CHR daily cap across all three codes combined. Source: 'a maximum of four units per day "
                      "... (total units allowable is inclusive of all 3 billable codes ...)' (Ch.10 p.9)." + _PA_NOTE,
                      statement="CHW/CHR (98960/98961/98962): maximum 4 units per day per member, inclusive of all "
                                "three codes."))
    # all three codes are named in the prohibition -> all three pairs (was 1 of 3)
    for a, b in [("98960", "98961"), ("98960", "98962"), ("98961", "98962")]:
        R.append(_pair(a, b, "practitioner", CH10, CH10_URL, "page 9",
                       "CHW/CHR codes 98960, 98961, 98962 cannot be billed together on the same day for the same member (Ch.10 p.9).",
                       scope="member_day"))
    R.append(Rule(
        origin="manual", plane="coverage_scope", binding_status="state_policy",
        statement="CHW/CHR (98960/98961/98962): maximum 24 units per month per member, inclusive of all three codes.",
        predicate={"type": "max_units_per_period", "code_set": _CHW,
                   "threshold": 24, "period": "month", "service_category": "practitioner"},
        codes=_CHW, population="all", machine_checkable=True,
        required_claim_fields=_UNIT_FIELDS,
        source_doc=CH10, source_locator="page 9", source_url=CH10_URL,
        notes="Monthly cross-code aggregation. Source: 'up to 24 units per month per member (inclusive of all 3 codes)' (Ch.10 p.9)." + _PA_NOTE))
    # Ch.10 p.13 (verbatim, verified 2026-10-02): "Physicians and mid-level practitioners who bill Evaluation
    # and Management (E/M) codes 99238 and 99239 for discharge management should not bill any other evaluation
    # and management code for the same date when submitting claims to AHCCCS." and "If a provider submits a
    # claim for discharge management and another E/M code for the same date, the E/M code will be paid, but
    # the discharge management code will be denied." -> the DENIED line is 99238, so it is code_b (the line
    # the finding is reported on); the seed used to report the paid E/M line. Same provider -> member_provider_day.
    R.append(_pair("99213", "99238", "practitioner", CH10, CH10_URL, "page 13",
                   "Discharge-management same-day prohibition. Sample of the 99201-99499 E/M range (Ch.10 p.13). "
                   "The discharge management code (99238) is the denied line: 'the E/M code will be paid, but the "
                   "discharge management code will be denied'.",
                   scope="member_provider_day", ambiguous=True,
                   anote=("INTERPRETATION, not the text's words: the text bars ANY other E/M code with 99238/99239 "
                          "for the same date; this seed pairs one sample E/M code (99213) with 99238 only. It reads "
                          "'a provider ... for the same date' as same provider, same member, same day "
                          "(member_provider_day), and the text says 'should not bill' (the denial sentence makes it "
                          "a denial, not advice).")))
    R.append(_not_covered("00938", CH10, CH10_URL, "page 6", "Anesthesia for penile prosthesis insertion; non-covered."))
    R.append(_not_covered("99070", CH10, CH10_URL, "page 47", "Supplies/materials by physician; not reimbursed on FFS."))
    R.append(_not_covered("11975", CH10, CH10_URL, "page 17", "Norplant insertion; no longer distributed."))
    R.append(_not_covered("11977", CH10, CH10_URL, "page 17", "Norplant removal-with-reinsertion; no longer distributed."))
    R.append(_lead(
        "Well exams for adults 21+: the source states both 'not covered' and 'coverage reinstated effective 10/1/2013' "
        "in the same section.",
        [], "ambiguous_source", CH10, CH10_URL, "page 22",
        "In-place edit contradiction preserved for the policy owner to resolve.",
        ambiguous=True,
        anote=("Time-scoped, not contradictory (independent re-read 2026-10-03): the second sentence is dated - "
               "'Effective with date of service 10/1/2013 ... re-instated' - so adult well exams are not covered "
               "before 10/1/2013 and covered from that date. Keep only as a reminder to read dated text as dated.")))
    # ================= 2026-10-03: explicit rules the extraction missed (independent policy re-read, agent P).
    # Every quote below was read twice from the live PDFs (agent P, then Claude) - verbatim. They are SEEDS: nothing
    # compiles until a named reviewer approves it in the review workbook (config.COMPILE_LEGACY_SEEDS = False).
    _S5151_TEXT = ("NOTE: Providers are prohibited from billing S5151 with H0001, H0002, H0004, H0006, H0018 H0025, "
                   "H0034, H0036, H2012, H2014, H2015, H2017, H2019, H2025, H2027, H2033, S5150. T1019. H0031, H0038, "
                   "H0030 or any other per diem code on the same day.")
    for b in ("H0001", "H0002", "H0004", "H0006", "H0018", "H0025", "H0034", "H0036", "H2012", "H2014", "H2015",
              "H2017", "H2019", "H2025", "H2027", "H2033", "S5150", "T1019", "H0031", "H0038", "H0030"):
        R.append(_pair(b, "S5151", "state_bh", CH19, CH19_URL, "page 31 (RESPITE CARE (UNSKILLED))",
                       f'Verbatim (Ch.19 p.31): "{_S5151_TEXT}" "Providers are prohibited from billing" = the same '
                       f"provider (member_provider_day). The finding sits on the S5151 line: billing S5151 with {b} "
                       f"is what the text prohibits." + _DATED.format(sec="Respite Care (Unskilled)"),
                       scope="member_provider_day", eff=CH19_RESPITE_CM_FROM))
    _T1016_TEXT = ("Claims with T1016 must not be billed on the same day as H0018, H0014, H0035, H2020, H2018, H2016, "
                   "H2026, H0037, S5109, T1020, S5151, S9480, or H0015 as case management services are included in "
                   "each of the per diem rates.")
    for a in ("H0018", "H0014", "H0035", "H2020", "H2018", "H2016", "H2026", "H0037", "S5109", "T1020", "S5151",
              "S9480", "H0015"):
        R.append(_pair(a, "T1016", "state_bh", CH19, CH19_URL, "page 20 (CASE MANAGEMENT)",
                       f'Verbatim (Ch.19 p.20): "{_T1016_TEXT}" T1016 is the code that must not be billed, so the '
                       f"finding sits on the T1016 line. Scope member_provider_day: the reason given is that case "
                       f"management is included in the per diem provider's rate (the reviewer may widen it)."
                       + _DATED.format(sec="Case Management"),
                       scope="member_provider_day", eff=CH19_RESPITE_CM_FROM))
    R.append(Rule(
        origin="manual", plane="coverage_scope", binding_status="state_policy",
        statement="Respite S5150 (per 15 minutes): no more than 2,400 units (600 hours) per member per benefit year "
                  "(October 1 - September 30), any provider.",
        predicate={"type": "max_units_per_period", "code_set": ["S5150"], "threshold": 2400, "period": "benefit_year"},
        codes=["S5150"], population="all", machine_checkable=True, required_claim_fields=_UNIT_FIELDS,
        effective_date="2021-10-01",
        source_doc=CH19, source_locator="page 31 (RESPITE CARE (UNSKILLED))", source_url=CH19_URL,
        notes=('Verbatim (Ch.19 p.31): "Respite services are limited to 600 hours per benefit year (October 1 through '
               'September 30) per member and are inclusive of both BH and ALTCS respite care." 600 h x 4 = 2,400 '
               "S5150 units. A safe lower bound: S5151 days and facility respite only add hours, so a member over "
               "2,400 S5150 units is over 600 hours; one under it may still be over (not caught). The same 600 hours "
               'is AMPM 1250-D ("cannot exceed 600 hours per benefit year"). Effective 2021-10-01: during COVID-19 the '
               "limit was raised to 720 hours (DES/DDD 06/04/2021: \"Effective October 1, 2021 - Annual limit of "
               "respite hours will return to 600 hours per contract year.\"), so earlier benefit years are not judged.")))
    _AMB = ("In addition, supplies (either BLS routine disposable supplies with code A0382 or ALS routine disposable "
            "supplies with code A0398) and oxygen supplies (for either BLS or ALS in a life sustaining situation "
            "with code A0422) may be charged for only one ground ambulance trip, unless the additional transport is a "
            "separately identifiable service.")
    for code, what in (("A0382", "BLS routine disposable supplies"), ("A0398", "ALS routine disposable supplies")):
        R.append(_cap_dos(code, 1, CH14, CH14_URL, "pages 5-6 (MULTIPLE AMBULANCE TRANSPORTS)",
                          f'Verbatim (Ch.14 p.5-6): "{_AMB}" Per provider per date (the worked examples are the same '
                          f"ambulance); the stated exception makes every finding verify_exception.",
                          statement=f"{code} ({what}) may be charged for only one ground ambulance trip per day by the "
                                    f"same provider, unless the additional transport is a separately identifiable service.",
                          exception="unless the additional transport is a separately identifiable service",
                          anote=("HOLD (2026-10-03, independent re-read): the limit is per TRIP, and the manual's own "
                                 "Example 3 (Ch.14 p.6-7: the same ambulance, two separately identifiable trips) bills "
                                 "supplies for both trips - legal, yet over this 1-unit-a-day cap. The right test "
                                 "(supply units <= base-rate units for the member, provider and day) is not in the "
                                 "grammar yet.")))
    R.append(_cap_dos("S9484", 5, CH19, CH19_URL, "page 24 (FACILITY-BASED CRISIS INTERVENTION SERVICES)",
                      'Verbatim (Ch.19 p.24-25): "S9484 - The billing unit is one hour and may only be billed if the '
                      'services delivered are 5 hours or less in duration within a single crisis episode." and "The ACC '
                      "Plan or other Contractor of enrollment may be billed using either code for services provided to "
                      'members awaiting an inpatient placement after 24 hours in the crisis stabilization facility." '
                      "Same provider and date stand in for the episode (an episode across midnight is not caught).",
                      statement="S9484 (crisis intervention, per hour) may only be billed for 5 hours or less in a "
                                "single crisis episode: more than 5 units for one member by one provider on one date "
                                "is a finding (verify: members awaiting inpatient placement after 24 hours).",
                      exception="The ACC Plan or other Contractor of enrollment may be billed using either code for "
                                "services provided to members awaiting an inpatient placement after 24 hours in the "
                                "crisis stabilization facility."))
    R.append(_pair("99213", "99239", "practitioner", CH10, CH10_URL, "page 13 (DISCHARGE MANAGEMENT)",
                   'Verbatim (Ch.10 p.13): "Physicians and mid-level practitioners who bill Evaluation and Management '
                   '(E/M) codes 99238 and 99239 for discharge management should not bill any other evaluation and '
                   'management code for the same date when submitting claims to AHCCCS." and "If a provider submits a '
                   "claim for discharge management and another E/M code for the same date, the E/M code will be paid, "
                   'but the discharge management code will be denied." Sibling of the 99213 + 99238 seed.',
                   scope="member_provider_day", ambiguous=True,
                   anote="One sample E/M code (99213); the text covers every E/M code (a range the grammar cannot "
                         "express yet)."))
    R.append(Rule(
        origin="manual", plane="coverage_scope", binding_status="state_policy",
        statement="J1055 (Depo-Provera 150 mg) is not billable for dates of service from 1/1/2013 (bill J1050, 1 mg).",
        predicate={"type": "code_not_covered", "code": "J1055"}, codes=["J1055"], population="all",
        machine_checkable=True, required_claim_fields=["proc_cd"], effective_date="2013-01-01",
        source_doc=CH10, source_locator="page 17 (FAMILY PLANNING SERVICES)", source_url=CH10_URL,
        notes=('Verbatim (Ch.10 p.17): "Prior to 1/1/2013 providers must bill for Depo-Provera injections on the CMS '
               '1500 claim form using HCPCS code J1055 - Depo-Provera (150 mg). Effective 1/1/2013 the Depo-Provera '
               'injections should billed with HCPCS code J1050 (1 mg)."')))
    return R


CHAPTER_BY_DOC = {CH19: "19", CH10: "10", CH14: "14"}
