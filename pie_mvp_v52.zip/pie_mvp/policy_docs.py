"""
policy_docs.py  -  Stages 0-2 of chapter extraction: acquire, parse, segment.

  acquire()   download a chapter PDF into PDF_DIR (or read the copy already
              there), hash it, keep a copy of every version under _versions/,
              return an inventory record.
  parse_pdf() PDF -> pages of lines with font size / bold / box, and ruled tables with
              their box and row boxes (PyMuPDF), with a plain-text fallback (pypdf).
  segment()   strip the repeated page header, detect ALL-CAPS section headings,
              and cut the chapter into sections that carry heading + page range;
              a table's rows are copied ("T1016 | 4 units per day") under the
              heading open where its first line is (table_pieces).
  rule_signal() cheap pre-filter: does this text look like it states a billing
              rule? (codes, modifiers, limit/prohibition phrases)
  sentence_spans() / clean_chars()  the ONE sentence splitter and the ONE character
              normalisation that grounding (extract_rules) and the post-checks share.

Layout facts these heuristics were validated against (FFS Chapter 10, rev
04/29/2026):
  * page header:  "04/29/2026 CHAPTER 10 INDIVIDUAL PRACTITIONER SERVICES 1 | 59"
    - date first, page counter varies per page  -> compare with digits removed
  * headings are ALL CAPS and unnumbered: "CORRECT CODING INITIATIVE"
  * limits are often written as words: "a maximum of four units per day"
  * revision history: "REVISION DATES: 04/29/2026; 05/02/2024; ..."
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import statistics
from datetime import datetime

import config

# ------------------------------------------------------------ constants
_HEADER_RE = re.compile(r"^\s*\d{2}/\d{2}/\d{4}\s+CHAPTER\s+\d+[A-Z]?\b.*\b\d+\s*\|\s*\d+\s*$", re.I)
_DATE_RE = re.compile(r"\b(\d{2}/\d{2}/\d{4})\b")
_REVISION_RE = re.compile(r"REVISION\s+DATES?\s*:\s*(.+)", re.I)

CODE_RE = re.compile(r"\b(?:\d{4}[A-Z0-9]|[A-Z]\d{4})\b")          # CPT 5-digit/4+letter, HCPCS letter+4
# C3-11: every dash the PDFs and gpt-oss use (hyphen, non-breaking hyphen, figure dash, en/em dash, bar,
# minus), and "through" / "thru" ranges. HCPCS ranges ("A0425-A0436") count too when both ends share the letter.
_DASHES = "\u002d\u2010\u2011\u2012\u2013\u2014\u2015\u2212"
CODE_RANGE_RE = re.compile(rf"\b(\d{{5}})\s*(?:[{_DASHES}]|\bthrough\b|\bthru\b)\s*(\d{{5}})\b"
                           rf"|\b([A-Z]\d{{4}})\s*(?:[{_DASHES}]|\bthrough\b|\bthru\b)\s*([A-Z]\d{{4}})\b", re.I)
MODIFIER_RE = re.compile(r"\bmodifiers?\b", re.I)
# Plain substrings; chapter_profile counts them with str.count, so they stay strings. rule_signal also
# applies TRIGGER_STEMS (below).
TRIGGER_PHRASES = (
    "maximum", "per day", "per month", "per year", "per benefit year", "per contract year",
    "units", "not covered", "non-covered", "not a covered", "not reimburs", "shall not",
    "cannot be billed", "may not be billed", "must not be billed", "do not bill", "limited to",
    "not to exceed", "prior authorization", "same day", "same date of service", "once per",
    "only when", "only if", "is not an ahcccs", "not an ahcccs-covered", "will be denied",
    "must be billed", "must use", "requires",
)
# C3-17: phrase STEMS for obligations the substrings above miss (first real run: "Hospice services require
# prior authorization.", "PA is required ...", "should not exceed 24 hours", "must be submitted within six
# months", "is not available to nursing facility residents" all scored 0 and a section holding only such
# sentences never reached the model). Deliberately narrow: "requirements", "may be directed", "unit" (the
# customer service unit) and plain "bill" do not match, so narrative sections stay skipped.
TRIGGER_STEMS = tuple(re.compile(p, re.I) for p in (
    r"\brequire[sd]?\b",
    r"\b(?:not|never|cannot|will not|may not|must not|should not|shall not|does not|do not) (?:to )?exceed",
    r"\bexceed(?:s|ing)? (?:a |the )?(?:maximum|limit|\d)",
    r"(?-i:\bPA\b)",                                   # "PA is required" (case-sensitive: not "pa")
    r"\bmust (?:be )?(?:submit|bill|use|includ|report|obtain|regist|enrol|follow|furnish|provid|attach|match)\w*",
    r"\bshould not (?:be )?(?:bill|submit|use|report)\w*",
    r"\b(?:will|may|shall) (?:be )?den(?:y|ied)\b|\bwill deny\b",
    r"\bonce (?:daily|a day|per)\b|\btwice\b",
    r"\bonly (?:for|by|one|once)\b|\bcovered only\b",
    r"\bnot available to\b|\bdoes not (?:cover|allow|bundle|reimburse|pay)\b",
    r"\bun-?processable\b|\bprohibited from\b|\bnot (?:be )?(?:separately )?(?:billable|payable|reimbursable)\b",
    r"\bevery \d+ (?:days|weeks|months|years)\b|\bper \d+ days\b",
    r"\bprovider types?\b",
))

# Number words 1-99 ("twenty-one", "forty eight") plus the hundreds the manual uses. The stub reads limits
# like "a maximum of sixteen units"; grounding compares numbers in quotes and sentences.
_ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve",
         "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
WORD_NUMBERS = {w: i for i, w in enumerate(_ONES) if i}
WORD_NUMBERS.update(_TENS)
WORD_NUMBERS.update({f"{t}-{_ONES[u]}": v + u for t, v in _TENS.items() for u in range(1, 10)})
WORD_NUMBERS.update({"one hundred": 100, "hundred": 100, "two hundred": 200, "three hundred": 300})

# ------------------------------------------------------- shared text normalisation
# C3-11: one table for grounding (extract_rules._norm / _norm_map) and the post-checks. gpt-oss writes U+2011
# (non-breaking hyphen) in "e-mail"; the PDFs use en/em dashes, minus signs, NBSP and thin spaces. A quote that
# differs from its source only in these characters must be an EXACT match (it was dropped as 'quote not found').
# Bullet glyphs are dropped so "covered: • 00938" and "covered: 00938" compare equal.
CHAR_MAP = {c: "-" for c in _DASHES[1:]}
CHAR_MAP.update({"\u2018": "'", "\u2019": "'", "\u02bc": "'", "\u00b4": "'",
                 "\u00a0": " ", "\u2002": " ", "\u2003": " ", "\u2004": " ", "\u2005": " ", "\u2006": " ",
                 "\u2007": " ", "\u2008": " ", "\u2009": " ", "\u200a": " ", "\u202f": " ", "\u205f": " ",
                 "\u3000": " "})
DROP_CHARS = frozenset("\u00ad\u200b\u200c\u200d\ufeff\"\u201c\u201d\u201e\u2022\u00b7\u25aa\u25e6\u25a0\u25a1\u27a2\u25ba")
_TRANS = str.maketrans({**CHAR_MAP, **{c: None for c in DROP_CHARS}})


def clean_chars(s: str | None) -> str:
    """Map dash/quote/space variants to ASCII and drop soft hyphens, zero-width characters, double quotes and
    bullet glyphs. Case and everything else are untouched (callers lower-case when they compare)."""
    return (s or "").translate(_TRANS)


# --------------------------------------------------------- sentence splitting (C3-16)
# A period followed by these is not a sentence end ("e.g. Medicare", "No. 5", "A.R.S. 36-2903", "Ch. 4").
# "etc." is deliberately absent: it ends sentences as often as not, and the lowercase rule below already keeps
# "supplies, etc. are not covered" together.
_ABBREV_RE = re.compile(r"(?:^|[\s(])(?:e\.g|i\.e|vs|no|nos|dr|mr|mrs|ms|inc|st|jr|sr|approx|dept|ch|sec|secs|pp|p|"
                        r"fig|rev|ltd|corp|a\.r\.s|a\.a\.c|u\.s|u\.s\.c|c\.f\.r)\.$", re.I)
_BULLET_GLYPHS = "\u2022\u00b7\u25aa\u25e6\u25a0\u25a1\u27a2\u25ba"
# boundaries: [.;] + whitespace | any newline (segment() joins a paragraph's lines, so a newline in section
# text is a paragraph / bullet boundary) | whitespace before an inline bullet glyph
_BOUNDARY_RE = re.compile(rf"(?<=[.;])\s+|\s*\n\s*|\s+(?=[{_BULLET_GLYPHS}]\s)")
# 2026-10-04: a '.' between two procedure codes of one list is a typo, not a sentence end. Ch.19 p.31 reads "... H2033,
# S5150. T1019. H0031, H0038, H0030 or any other per diem code on the same day." - split there, the engine paired S5151
# with 17 of the 21 listed codes (the grounding window and the pattern extractor both lost T1019, H0031, H0038, H0030).
_CODE_TOK = r"(?:[A-Z]\d{4}|\d{4}[A-Z0-9])"
# 2026-10-04 (critic P51-4): the code before the period must be a LIST item - after ', ' or after another 'CODE. ' (the
# chain 'S5150. T1019.'). Any 'CODE.' fused two real sentences: "... may be billed for T1016." + "T1017, T1019 and H2014
# are limited to a maximum of two units per day." became one, and the pattern extractor gave all four codes the 4-unit cap
_CODE_BEFORE_RE = re.compile(rf"(?:,\s*|\b{_CODE_TOK}\.\s+)\b{_CODE_TOK}\.$")
_CODE_LIST_NEXT_RE = re.compile(rf"{_CODE_TOK}[.,]")
_CODE_BREAK_WINDOW = 24                                    # characters of `before` code_list_break looks at


def code_list_break(before: str, after: str) -> bool:
    """True when a '.' between two codes continues one list: `before` ends with a list item and its period - ', CODE.'
    or 'CODE. CODE.' - and `after` starts with a code followed by ',' or '.'. A new sentence that merely starts with a
    code ('H2014 requires ...') is still a new sentence, and so is the one after a sentence that merely ends with one
    ('... may be billed for T1016.' + 'T1017, T1019 ...')."""
    return bool(_CODE_BEFORE_RE.search(before[-_CODE_BREAK_WINDOW:])) and bool(_CODE_LIST_NEXT_RE.match(after))


def _blank_hash(v) -> bool:
    """None, NaN / NA / NaT, or text that is empty once stripped: no hash."""
    if v is None:
        return True
    try:
        if v != v:                                         # float / numpy NaN, NaT
            return True
    except (TypeError, ValueError):                        # pandas NA: its truth value is ambiguous
        return True
    return not str(v).strip()


def corpus_version(doc_hashes: dict) -> str:
    """One id for the exact document set a run, a build or a metric rests on: sha256 over the sorted
    (document id, document sha256) pairs, first 16 hex characters. 'Recall 0.92' means nothing without it
    (2026-10-04, external review: freeze the corpus so a rate has an unambiguous denominator).
    A document whose hash is blank (None, NaN, whitespace) is missing, as quality.corpus_bar and v03 treat it; a hash
    is compared stripped."""
    import hashlib
    import json
    # 2026-10-04 (critic P51-10): a NaN or whitespace-only hash (an inventory row read from a table with an empty
    # doc_hash) was counted as a document, so the same corpus got two different version ids
    pairs = sorted((str(k), str(v).strip()) for k, v in (doc_hashes or {}).items() if not _blank_hash(v))
    return "corpus-" + hashlib.sha256(json.dumps(pairs).encode("utf-8")).hexdigest()[:16] if pairs else "corpus-empty"


def sentence_spans(text: str) -> list[tuple[int, int]]:
    """(start, end) offsets of the sentences of `text`, stripped. Splits at '.'/';' + whitespace as before, and
    also (C3-16) at every newline and before an inline bullet, so a bullet list without periods no longer glues
    the next paragraph onto a quote (00938's 'not covered' bullet picked up the nerve-block paragraph's 'when'
    and was flagged 'condition omitted'). A '.' after a known abbreviation, or followed by a lowercase letter,
    is not a sentence end. Offsets index `text`, so a caller may slice text.replace('\\n', ' ') with them."""
    text = text or ""
    spans, pos = [], 0
    for m in _BOUNDARY_RE.finditer(text):
        a = m.start()
        if "\n" not in m.group(0) and a > 0 and text[a - 1] == ".":
            nxt = text[m.end():m.end() + 1]
            if _ABBREV_RE.search(text[max(pos, a - 12):a]) or (nxt and nxt.islower()) or \
                    code_list_break(text[max(pos, a - _CODE_BREAK_WINDOW):a], text[m.end():m.end() + 8]):
                continue                                   # not a sentence end: keep scanning
        spans.append((pos, a))
        pos = m.end()
    spans.append((pos, len(text)))
    out = []
    for a, b in spans:
        seg = text[a:b]
        a2, b2 = a + len(seg) - len(seg.lstrip()), b - (len(seg) - len(seg.rstrip()))
        if b2 > a2:
            out.append((a2, b2))
    return out


def sentences(text: str) -> list[str]:
    """The sentences of `text` (newlines inside a sentence become spaces)."""
    t = (text or "").replace("\n", " ")
    return [t[a:b] for a, b in sentence_spans(text or "")]


# --------------------------------------------------------- dates in policy text (C3-06)
_MONTHS = {m: i for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july",
     "august", "september", "october", "november", "december"], 1)}
_MONTHS.update({m[:3]: i for m, i in list(_MONTHS.items())})
_MONTHS["sept"] = 9
# a date, numeric (4/1/2018, 04/01/18) or written (April 1st, 2018 / Apr. 1 2018)
DATE_TOKEN_RE = re.compile(r"\b(\d{1,2})/(\d{1,2})/(\d{4}|\d{2})\b"
                           r"|\b([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b")
# Directional cues, nearest one before the date wins. "date(s) of service" is NOT a cue on its own: in
# "Prior to date of service 10/1/2016, ... not covered" it sits between the real cue and the date, and the old
# parser read the date as an EFFECTIVE date - the rule would flag exactly the wrong period.
_CUE_BEFORE_RE = re.compile(
    r"\b(?P<end_before>prior\s+to|before|until|up\s+to\s+but\s+not\s+including)\b"
    r"|\b(?P<end_through>through|thru|ending|ends|no\s+later\s+than|on\s+or\s+before|on\s+and\s+before)\b"
    r"|\b(?P<start>effective|beginning|begins|starting|starts|as\s+of|on\s+or\s+after|on\s+and\s+after|from|since)\b"
    r"|\b(?P<start_after>after)\b", re.I)
_WEAK_CUES = {"from", "since", "after", "before", "until", "ends", "ending"}
_TIGHT_GAP_RE = re.compile(r"^\s*(?:(?:the\s+)?(?:dates?\s+of\s+service|dos|service\s+dates?)\s*)?$", re.I)
# cues written AFTER the date ("7/1/2023 and after", "1/1/2014 and later", "10/1/2015 and before")
_CUE_AFTER_RE = re.compile(r"^\W{0,3}\s*(?:(?P<start>and\s+(?:after|later|thereafter|forward)|or\s+later|onward|forward)"
                           r"|(?P<end_through>and\s+(?:before|earlier|prior)|or\s+earlier))\b", re.I)


def _iso_date(tok_match) -> "datetime | None":
    g = tok_match.groups()
    try:
        if g[0]:
            y = int(g[2]) + (2000 if len(g[2]) == 2 else 0)
            return datetime(y, int(g[0]), int(g[1]))
        mon = _MONTHS.get(g[3].lower().rstrip("."))
        return datetime(int(g[5]), mon, int(g[4])) if mon else None
    except (TypeError, ValueError):
        return None


def date_cues(text: str) -> list[dict]:
    """Every date in `text` with the direction its cue gives, in text order:
        {"kind": "effective" | "end", "date": "YYYY-MM-DD", "token": "<as written>", "cue": "<cue words>"}
      effective X : 'effective X', 'beginning (with dates of service on and after) X', 'on or after X', 'X and after'
      effective X+1: 'after X' (strictly after)
      end X-1     : 'prior to X', 'before X', 'until X'
      end X       : 'through X', 'on or before X', 'X and before'
    A date with no cue (a revision date, an example) is not returned."""
    from datetime import timedelta
    out = []
    text = text or ""
    for m in DATE_TOKEN_RE.finditer(text):
        d = _iso_date(m)
        if d is None:
            continue
        kind, cue = None, None
        win = text[max(0, m.start() - 70):m.start()]
        cues = list(_CUE_BEFORE_RE.finditer(win))
        if cues:
            c = cues[-1]
            # a WEAK cue ("from", "after", "before", ...) counts only right before the date ("for dates of service
            # before 10/1/2016"); "a letter from AHCCCS dated 1/1/2013" is not an effective date
            if c.group(0).lower() not in _WEAK_CUES or _TIGHT_GAP_RE.match(win[c.end():]):
                kind, cue = c.lastgroup, c.group(0)
        post = _CUE_AFTER_RE.match(text[m.end():m.end() + 25])
        if post and (kind is None or kind == "start"):
            kind, cue = post.lastgroup, post.group(0).strip(" ,")
        if kind == "start":
            out.append({"kind": "effective", "date": d.date().isoformat(), "token": m.group(0), "cue": cue})
        elif kind == "start_after":
            out.append({"kind": "effective", "date": (d + timedelta(days=1)).date().isoformat(), "token": m.group(0),
                        "cue": cue})
        elif kind == "end_before":
            out.append({"kind": "end", "date": (d - timedelta(days=1)).date().isoformat(), "token": m.group(0),
                        "cue": cue})
        elif kind == "end_through":
            out.append({"kind": "end", "date": d.date().isoformat(), "token": m.group(0), "cue": cue})
    return out


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


# --------------------------------------------------------------- acquire
def version_path(pdf_dir: str, chapter: str, doc_hash: str) -> str:
    """Where the exact bytes of one document version are kept: <pdf_dir>/_versions/<chapter>_<hash[:12]>.pdf."""
    return os.path.join(pdf_dir, "_versions", f"{chapter}_{doc_hash[:12]}.pdf")


def _keep_version(pdf_dir: str, chapter: str, data: bytes) -> str:
    """C4-08: an approval binds to a doc_hash, so the exact PDF it was made on must stay readable. Every
    version acquire() sees - downloaded, uploaded by hand, or already in the folder - is copied once to
    _versions/ (not only the one a download replaces). Atomic: a crash never leaves a half file."""
    dest = version_path(pdf_dir, chapter, _sha(data))
    if not os.path.exists(dest):
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        tmp = dest + ".tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, dest)
    return dest


def _archive_previous(path: str, new_bytes: bytes, chapter: str | None = None) -> None:
    """Keep the superseded version before a download replaces it.
    An approval binds to a doc_hash; without the old file that text could never be re-read.
    C4-08: named like every other kept version (<chapter>_<hash[:12]>.pdf) when the chapter is known."""
    if not os.path.exists(path):
        return
    with open(path, "rb") as f:
        old = f.read()
    if _sha(old) == _sha(new_bytes):
        return
    if chapter is not None:
        _keep_version(os.path.dirname(path), chapter, old)
        return
    vdir = os.path.join(os.path.dirname(path), "_versions")
    os.makedirs(vdir, exist_ok=True)
    dest = os.path.join(vdir, f"{_sha(old)[:16]}_{os.path.basename(path)}")
    if not os.path.exists(dest):
        with open(dest, "wb") as f:
            f.write(old)


def acquire(chapter: str, pdf_dir: str | None = None, download: bool = True,
            timeout: int = 60) -> dict:
    """Return an inventory record for one chapter and make sure its PDF is on disk.
    C4-08: the bytes that were hashed are also kept as _versions/<chapter>_<doc_hash[:12]>.pdf
    (record field `version_path`), whatever their source."""
    chapter = str(chapter)
    if chapter not in config.CHAPTERS:
        raise KeyError(f"chapter {chapter!r} not in config.CHAPTERS")
    title, url = config.CHAPTERS[chapter]
    pdf_dir = pdf_dir or config.PDF_DIR
    os.makedirs(pdf_dir, exist_ok=True)
    path = os.path.join(pdf_dir, os.path.basename(url))
    source = "volume"
    if download:
        try:
            import requests
            r = requests.get(url, timeout=timeout, headers={"User-Agent": "policy-kb/1.0"})
            r.raise_for_status()
            if not r.content.startswith(b"%PDF"):
                raise ValueError("response is not a PDF")
            _archive_previous(path, r.content, chapter)
            with open(path, "wb") as f:
                f.write(r.content)
            source = "download"
        except Exception as e:
            if not os.path.exists(path):
                raise RuntimeError(
                    f"chapter {chapter}: download failed ({type(e).__name__}: {e}) and no copy at {path}. "
                    f"Upload the PDF to {pdf_dir} and re-run with download=False.") from e
            print(f"  chapter {chapter}: download failed ({type(e).__name__}); using {path}")
    elif not os.path.exists(path):
        raise FileNotFoundError(f"chapter {chapter}: {path} not found; set download=True or upload it")
    with open(path, "rb") as f:
        data = f.read()
    return {"chapter": chapter, "title": title, "url": url, "path": path,
            "doc_hash": _sha(data), "bytes": len(data), "source": source,
            "fetched_at": datetime.now().isoformat(timespec="seconds"),
            "version_path": _keep_version(pdf_dir, chapter, data)}


# --------------------------------------------------------- stage manifest (C4-08)
STAGE_MANIFEST = "stage_manifest.json"


def write_stage_manifest(pdf_dir: str, records: list[dict]) -> str:
    """Record, next to the staged PDFs, exactly which bytes were staged: one entry per chapter with
    doc_hash / bytes / fetched_at / source / version_path. Entries for chapters NOT staged this time are
    carried over while their file is still on disk (and marked restaged=False), so a partial re-stage does
    not erase what the folder holds. Returns the manifest path."""
    path = os.path.join(pdf_dir, STAGE_MANIFEST)
    prev = read_stage_manifest(pdf_dir)
    now = datetime.now().isoformat(timespec="seconds")
    files = {}
    for ch, e in (prev.get("files") or {}).items():
        if os.path.exists(e.get("path") or ""):
            files[ch] = dict(e, restaged=False)
    for r in records:
        files[str(r["chapter"])] = {"chapter": str(r["chapter"]), "file": os.path.basename(r["path"]),
                                    "path": r["path"], "doc_hash": r["doc_hash"], "bytes": r["bytes"],
                                    "fetched_at": r["fetched_at"], "source": r.get("source"),
                                    "version_path": r.get("version_path"), "url": r.get("url"),
                                    "staged_at": now, "restaged": True}
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"written_at": now, "pdf_dir": pdf_dir, "files": files}, f, indent=1, default=str)
    os.replace(tmp, path)
    return path


def read_stage_manifest(pdf_dir: str) -> dict:
    """{"written_at", "pdf_dir", "files": {chapter: entry}} or {} if 03 has not written one."""
    path = os.path.join(pdf_dir, STAGE_MANIFEST)
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ----------------------------------------------------------------- parse
def parse_pdf(path: str) -> list[dict]:
    """[{page, lines:[{text,size,bold,x0,y0,x1,y1}], tables:[[row,...],...], table_bboxes, table_rows, width, height}]
    (1-based pages). Positions (line boxes, table and row boxes, page size) only with PyMuPDF; the pypdf fallback gives
    text, size 0 and no tables."""
    try:
        import pymupdf as fitz
    except ImportError:
        try:
            import fitz  # older name
        except ImportError:
            fitz = None
    if fitz is not None:
        return _parse_pymupdf(fitz, path)
    return _parse_pypdf(path)


def _r1(box) -> tuple:
    return tuple(round(float(v), 1) for v in box)


def page_tables(page) -> list[tuple]:
    """The ruled tables PyMuPDF's find_tables() reads on one page, as [(bbox, rows, row_boxes)]: rows without a filled
    cell are dropped; row_boxes[r] is the box of rows[r] when that row has 2+ cells - a grid row - and None for a row
    that is ONE cell across the table (a merged row: a group heading inside an exhibit, or a column of text that
    find_tables() read as a 'row' because a column rule touches the table); row_boxes is None when PyMuPDF gives no row
    geometry. Shared by parse_pdf() and page_fidelity.page_geometry(), so both read a page's tables alike."""
    out = []
    try:
        found = page.find_tables().tables
    except Exception:
        return out
    for t in found:
        try:
            raw = [[(c or "").strip() for c in row] for row in t.extract()]
        except Exception:
            continue
        keep = [r for r, row in enumerate(raw) if any(row)]
        if not keep:
            continue
        try:
            # 2026-10-04 (critic P51-5): row boxes, so that only a line inside a grid row is table content
            rows = list(t.rows)
            row_boxes = [_r1(rows[r].bbox) if sum(c is not None for c in rows[r].cells) >= 2 else None for r in keep] \
                if len(rows) == len(raw) else None
        except Exception:
            row_boxes = None
        out.append((_r1(t.bbox), [raw[r] for r in keep], row_boxes))
    return out


def _parse_pymupdf(fitz, path: str) -> list[dict]:
    pages = []
    with fitz.open(path) as doc:
        for i, page in enumerate(doc, 1):
            lines = []
            d = page.get_text("dict")
            for block in d.get("blocks", []):
                for line in block.get("lines", []):
                    spans = line.get("spans", [])
                    text = "".join(s.get("text", "") for s in spans).strip()
                    if not text:
                        continue
                    size = max((s.get("size", 0) for s in spans), default=0)
                    bold = any((s.get("flags", 0) & 16) or "bold" in s.get("font", "").lower() for s in spans)
                    bbox = line.get("bbox") or (0, 0, 0, 0)
                    # x1 / y1 (2026-10-04, critic P51-1): a line is placed by its CENTRE (table content, header band)
                    lines.append({"text": text, "size": round(size, 1), "bold": bool(bold),
                                  "x0": round(bbox[0], 1), "y0": round(bbox[1], 1),
                                  "x1": round(bbox[2], 1), "y1": round(bbox[3], 1)})
            found = page_tables(page)
            # table_bboxes[i] = (x0, y0, x1, y1) of tables[i]: segment() files a table under the heading open WHERE the
            # table is on the page, and never takes a table cell for a heading (2026-10-04, page fidelity check).
            # table_rows[i][r] = the box of grid row r of tables[i], None for a merged row (critic P51-5: table_pieces).
            # width / height: the running-header band (critic P51-9: find_headers)
            pages.append({"page": i, "lines": lines, "tables": [rows for _, rows, _ in found],
                          "table_bboxes": [b for b, _, _ in found], "table_rows": [rb for _, _, rb in found],
                          "width": round(page.rect.width, 1), "height": round(page.rect.height, 1)})
    return pages


def _parse_pypdf(path: str) -> list[dict]:
    from pypdf import PdfReader
    pages = []
    for i, p in enumerate(PdfReader(path).pages, 1):
        text = p.extract_text() or ""
        lines = [{"text": ln.strip(), "size": 0.0, "bold": False}
                 for ln in text.splitlines() if ln.strip()]
        pages.append({"page": i, "lines": lines, "tables": []})
    return pages


# --------------------------------------------------------------- segment
def _norm_header(s: str) -> str:
    return re.sub(r"[\d|]+", "", s).strip().lower()


def is_grid(rows) -> bool:
    """A parsed table that is a real grid: 2+ rows and a row with 2+ filled cells. Lines inside its grid rows are table
    content and never a heading (segment); a one-row or one-column box is not trusted to be a table."""
    rows = list(rows or [])
    return len(rows) >= 2 and max((sum(1 for c in r if str(c or "").strip()) for r in rows), default=0) >= 2


def line_centre(ln: dict):
    """(x, y) centre of a parsed line's box; None without positions (pypdf). A line parsed with only its top-left
    corner (x0, y0) is placed by that corner and its font size."""
    if ln.get("y0") is None:
        return None
    x0, y0, x1, y1 = ln.get("x0") or 0.0, ln["y0"], ln.get("x1"), ln.get("y1")
    return ((x0 + x1) / 2 if x1 is not None else x0,
            (y0 + y1) / 2 if y1 is not None else y0 + 0.7 * (ln.get("size") or 0))


def _holds(box, xy, pad: float = 0.5) -> bool:
    return box[0] - pad <= xy[0] <= box[2] + pad and box[1] - pad <= xy[1] <= box[3] + pad


def table_pieces(page: dict) -> list[dict]:
    """The row copies segment() files for the tables of one parsed page, in table order:
        [{"table": i, "rows": [row, ...], "boxes": [box, ...] | None}]
    A table that is not a grid (is_grid) has none. A grid with row boxes (parse_pdf's table_rows) gives one piece per
    run of grid rows; a merged row (one cell across the table: a group heading in an exhibit, or a text column that
    find_tables() read as a 'row') ends a run and is not copied - its line is text, and may be a heading. A grid without
    row boxes is one piece, boxes = [its bbox]; without table positions (pypdf, or an old parse) boxes = None.
    A line whose centre lies in a piece's boxes is table content, and the piece is filed where its first such line is
    in the page's reading order (segment)."""
    tables = list(page.get("tables") or [])
    bboxes, row_boxes = page.get("table_bboxes"), page.get("table_rows")
    positioned = (isinstance(bboxes, (list, tuple)) and len(bboxes) == len(tables)
                  and all(isinstance(b, (list, tuple)) and len(b) == 4 for b in bboxes))
    with_rows = positioned and isinstance(row_boxes, (list, tuple)) and len(row_boxes) == len(tables)
    out = []
    for i, rows in enumerate(tables):
        if not is_grid(rows):
            continue
        rb = row_boxes[i] if with_rows else None
        if not positioned:
            out.append({"table": i, "rows": list(rows), "boxes": None})
        elif not isinstance(rb, (list, tuple)) or len(rb) != len(rows):
            out.append({"table": i, "rows": list(rows), "boxes": [tuple(bboxes[i])]})
        else:
            run = {"table": i, "rows": [], "boxes": []}
            for row, box in list(zip(rows, rb)) + [(None, None)]:
                if box is None:                            # a merged row (or the end of the table) ends a run
                    if run["rows"]:
                        out.append(run)
                    run = {"table": i, "rows": [], "boxes": []}
                else:
                    run["rows"].append(row)
                    run["boxes"].append(tuple(box))
    return out


def piece_of(ln: dict, pieces: list[dict]):
    """Index of the table piece whose boxes hold the centre of line `ln` (it is table content), else None."""
    xy = line_centre(ln)
    if xy is None:
        return None
    return next((j for j, pc in enumerate(pieces) if pc["boxes"] and any(_holds(b, xy) for b in pc["boxes"])), None)


_SHORT_NUMBER_RE = re.compile(r"\b\d{1,4}\b")             # a page counter, a day, a house number: never a code
# the top and bottom share of a page where running headers and footers sit (critic P51-9: candidates come from there)
HEADER_BAND = 0.12


def _header_key(s: str) -> str:
    """How find_headers() and is_running_header() compare a line from page to page. A line without a procedure code:
    digits and '|' removed (the page counter varies; _norm_header). A line WITH a code: its code tokens kept, only
    numbers of 1-4 digits and '|' removed - exhibit rows that differ only in their codes ("A4206 Syringe with needle" /
    "A4207 Syringe with needle") never match each other, while a footer that repeats but for its page counter ("Form
    AH-10021 Rev. 2025A  Page 3 of 9", "Phoenix, AZ 85034") does. The two kinds of key never collide: only the second
    holds digits."""
    if not CODE_RE.search(s):
        return _norm_header(s)
    return re.sub(r"\s+", " ", _SHORT_NUMBER_RE.sub("", s.replace("|", " "))).strip().lower()


def is_running_header(text: str, headers: set[str]) -> bool:
    """A line segment() drops as a running header/footer: the AHCCCS page header ("04/29/2026 CHAPTER 19 ... 31 | 45"),
    or a line whose _header_key repeats on most pages (find_headers). Shared with page_fidelity.locate() so the check
    reads the page the way segment() does."""
    t = text.strip()
    # 2026-10-04 (critic P51-2): a line holding a code is compared with its codes kept (_header_key) instead of never
    # being a header - footers with a code-shaped token ("Phoenix, AZ 85034", "Form AH-10021 Rev. 2025A") stayed in the
    # text, and inside a code list crossing a page break the pattern extractor paired S5151 with 10021 and 2025A
    return bool(_HEADER_RE.match(t)) or _header_key(t) in headers


def header_candidates(page: dict) -> list[dict]:
    """The lines of a parsed page that may be a running header or footer. With positions (PyMuPDF: the page height and
    each line's box) only a line whose centre lies in the top or bottom HEADER_BAND of the page and outside every grid
    row (table_pieces); without them (pypdf) every line, as before 2026-10-04."""
    h = page.get("height")
    if not h:
        return list(page["lines"])
    pieces = table_pieces(page)
    out = []
    for ln in page["lines"]:
        xy = line_centre(ln)
        if xy is not None and (HEADER_BAND * h < xy[1] < (1 - HEADER_BAND) * h or piece_of(ln, pieces) is not None):
            continue                                       # the body of the page, or a table cell
        out.append(ln)
    return out


def find_headers(pages: list[dict]) -> tuple[set[str], str | None]:
    """Lines that repeat on most pages (compared by _header_key: page counter ignored, codes kept) + the revision date.
    Only header_candidates() count: with positions, lines at the top or bottom of a page and outside every table."""
    n = max(len(pages), 1)
    counts: dict[str, int] = {}
    for p in pages:
        seen = set()
        # 2026-10-04 (critic P51-9): every line used to be a candidate, so on a short document a limit that differs from
        # page to page only in its number ("Maximum: 4 units per day." / "Maximum: 16 units per day.", two table cells
        # "4 units per day" / "16 units per day") was stripped as a 'running header' and never reached the extractor
        for ln in header_candidates(p):
            # 2026-10-04 (page fidelity check, critic P51-2): exhibit rows that differ only in their codes ("A4206 Syringe
            # with needle" / "A4207 Syringe with needle") were stripped as a running header on short documents (equal once
            # digits are removed); _header_key keeps a line's codes, so they never match while a footer that holds a
            # code-shaped token and repeats on every page still does
            k = _header_key(ln["text"])
            if 3 <= len(k) <= 120 and k not in seen:
                seen.add(k)
                counts[k] = counts.get(k, 0) + 1
    headers = {k for k, c in counts.items() if c >= max(2, int(0.5 * n))}
    revision = None
    for p in pages[:3]:
        for ln in p["lines"]:
            if is_running_header(ln["text"], headers):
                m = _DATE_RE.search(ln["text"])
                if m:
                    revision = m.group(1)
                    break
        if revision:
            break
    return headers, revision


def _heading_shape(ln: dict, body_size: float) -> bool:
    """The original heading test: short, not a sentence, ALL CAPS (or bigger and bold)."""
    t = ln["text"].strip()
    letters = re.sub(r"[^A-Za-z]", "", t)
    if len(letters) < 3 or len(t) > 120 or len(t.split()) > 14:
        return False
    if t.endswith((".", ";", ",")) and not t.endswith("..."):
        return False
    if _REVISION_RE.match(t):
        return False
    all_caps = letters.isupper()
    big = body_size and ln["size"] >= body_size + 1.5
    return all_caps or (big and ln["bold"])


# C3-16: lines the shape test accepted in the first real run that are NOT headings (seen as citation headings
# in rules.json): form values and field layouts ("0 = ICD-10-CM", "PAY:  0.00", "MM/DD/CC"), code/ID cells
# ("7. 638FQHC (PTC5)", "N400074115278 ML10", "NTE02"), bare acronyms ("EMG", "ICU") and the tail of a wrapped
# heading ("SERVICES)", "TO MAINTAIN EMPLOYMENT"). A rejected line stays body text (nothing is lost; the
# citation keeps the real heading above it).
_HEAD_TAIL_RE = re.compile(r"^(?:TO|AND|OR|OF|WITH|BY|FROM|AS)\s")
_FORM_VALUE_RE = re.compile(r"=|\b(?:MM|DD|YY|YYYY|CC)/(?:MM|DD|YY|YYYY|CC)\b|:\s*[\d$]")


def _is_heading(ln: dict, body_size: float) -> bool:
    if not _heading_shape(ln, body_size):
        return False
    t = ln["text"].strip()
    if t.count(")") > t.count("(") or t.count("]") > t.count("["):
        return False                                       # "SERVICES)" - tail of a wrapped heading (an unclosed
        #                                                    "(" is a head that continues on the next line: kept)
    if _FORM_VALUE_RE.search(t):
        return False
    toks = t.split()
    if 2 * sum(1 for x in toks if re.search(r"\d", x)) > len(toks):
        return False                                       # mostly codes / numbers / IDs
    words = re.findall(r"\b[A-Za-z]{3,}\b", t)
    if not (any(len(w) >= 4 for w in words) or len(words) >= 2):
        return False                                       # a bare acronym ("ICU", "EMG")
    if _HEAD_TAIL_RE.match(t):
        return False                                       # starts mid-phrase: a wrapped tail
    return True


def segment(pages: list[dict], chapter: str, doc_hash: str) -> tuple[list[dict], dict]:
    """Cut a parsed chapter into sections. Returns (sections, meta)."""
    headers, revision = find_headers(pages)
    sizes = [ln["size"] for p in pages for ln in p["lines"] if ln["size"] > 0]
    body_size = statistics.median(sizes) if sizes else 0.0

    revision_dates: list[str] = []
    sections: list[dict] = []
    cur = {"heading": "PREAMBLE", "page_start": 1, "page_end": 1, "lines": [], "tables": []}
    after_heading = False                    # C3-16: the previous kept line opened a section

    def _close(fallback_page: int):
        text = _join_lines(cur["lines"])
        for tbl in cur["tables"]:
            text += "\n" + "\n".join(" | ".join(r) for r in tbl)
        if text.strip():
            sections.append({"heading": cur["heading"], "page_start": cur["page_start"],
                             "page_end": cur.get("page_end") or fallback_page, "text": text.strip()})

    for p in pages:
        # Only a real grid (2+ rows, a row with 2+ filled cells) gets a row copy ("T1016 | 4 units per day | H0018") and
        # makes lines table content: a one-row or one-column "table" find_tables() reads from a ruled box or a layout
        # table may hold a real heading, and its lines are in the text already (probe, 2026-10-04). The copies are
        # table_pieces(): one per run of grid rows.
        # 2026-10-04 (critic P51-1, P51-5): a line is table content when its CENTRE lies in a GRID ROW - not when its top
        # is within 1pt of the table's box (the box of a heading set right under a table starts at the bottom rule, so
        # CRISIS SERVICES became a table line), and not in a merged row (a group heading inside an exhibit, or a text
        # column find_tables() read as one 'row' because a column rule touches a table).
        # 2026-10-04 (critic P51-3): a piece is filed where its OWN first line is in the page's reading order - filed at
        # the first line below the table's top, a table in the right column of a two-column page (or on a page whose
        # footer is drawn before the body) went under the wrong heading. A piece none of whose lines is reached (no
        # positions: pypdf) is filed at the end of the page, as before 2026-10-04.
        pieces = table_pieces(p)
        placed = [False] * len(pieces)

        def _file(j):
            if not placed[j]:
                cur["tables"].append(pieces[j]["rows"])
                cur["page_end"] = p["page"]
                placed[j] = True

        for ln in p["lines"]:
            t = ln["text"].strip()
            if is_running_header(t, headers):
                continue
            j = piece_of(ln, pieces)
            if j is not None:
                _file(j)                             # before the line: under the section open where the table starts
            in_table = j is not None
            m = _REVISION_RE.match(t)
            if m:
                revision_dates += _DATE_RE.findall(m.group(1))
                continue
            merged = f"{cur['heading']} {t}"
            if in_table:
                # a table cell ("CODE  DESCRIPTION  LIMIT" in capitals) is table content, never a heading: taken for
                # one it split the section and left the lead-in sentence on its own (2026-10-04, page fidelity check)
                cur["lines"].append(t)
                cur["page_end"] = p["page"]
                after_heading = False
                continue
            if (after_heading and not cur["lines"] and not cur["tables"] and _heading_shape(ln, body_size)
                    and len(merged) <= 120 and len(merged.split()) <= 14):
                # C3-16: a heading wrapped onto a second line is ONE heading ("PSYCHOSOCIAL" + "REHABILITATION
                # SERVICES)"), not a new empty section followed by a section named after the tail
                cur["heading"] = merged
                continue
            if _is_heading(ln, body_size):
                _close(p["page"])
                cur = {"heading": t, "page_start": p["page"], "page_end": p["page"],
                       "lines": [], "tables": []}
                after_heading = True
                continue
            cur["lines"].append(t)
            cur["page_end"] = p["page"]              # last page that contributed text
            after_heading = False
        for j in range(len(pieces)):
            _file(j)                                 # no line of it reached (no positions): the end of the page
    _close(pages[-1]["page"] if pages else 1)

    if not revision and revision_dates:
        revision = revision_dates[0]
    for s in sections:
        sig = rule_signal(s["text"])
        s.update({
            "chapter": chapter, "doc_hash": doc_hash,
            "section_id": hashlib.sha256(f"{chapter}|{doc_hash}|{s['heading']}|{s['page_start']}".encode()).hexdigest()[:16],
            "text_hash": hashlib.sha256(s["text"].encode()).hexdigest()[:16],
            "n_chars": len(s["text"]),
            "rule_signal": sig["score"], "codes_seen": sig["codes"],
            "has_rule_signal": sig["score"] > 0,
        })
    meta = {"pages": len(pages), "revision_date": revision, "revision_dates": revision_dates,
            "headers_stripped": sorted(headers), "sections": len(sections),
            "candidate_sections": sum(1 for s in sections if s["has_rule_signal"])}
    return sections, meta


_BULLET_LINE_RE = re.compile(rf"^(?:[{_BULLET_GLYPHS}\-\*]\s|\(?[a-z0-9]{{1,2}}[\.\)]\s)")
# a line that continues an open bullet: starts lowercase, with a digit, or with punctuation ("prosthesis)")
_CONTINUATION_RE = re.compile(r"^[a-z0-9(\[\),;:%$&/]")
# a line that stops inside a code list ("... H0001, H0002," / "... H0002 and") and the line after it that goes on with it
_LIST_OPEN_END_RE = re.compile(rf"\b{_CODE_TOK}\s*(?:,|&|\band/or|\band|\bor)$")
_CODE_START_RE = re.compile(rf"{_CODE_TOK}\b")


def _list_goes_on(text: str, nxt: str) -> bool:
    """`text` (a paragraph read up to the end of a physical line) stops inside a code list that line `nxt` continues:
    a stray period after a list item ('... H2033, S5150.' + 'T1019. H0031, ...': code_list_break) or a code and a
    comma / 'and' / 'or' / '&' ('... H0001, H0002,' + 'H0004, H0006 ...')."""
    text = text[-40:]
    if text.endswith("."):
        return code_list_break(text, nxt)
    return bool(_LIST_OPEN_END_RE.search(text)) and bool(_CODE_START_RE.match(nxt))


def _join_lines(lines: list[str]) -> str:
    """Physical PDF lines -> paragraphs. Keeps bullets on their own line.
    C3-16: a bullet that wraps onto a second physical line keeps its tail ("• The peripheral nerve block was
    performed for the purpose of postoperative pain" + "management;") instead of the tail starting the next
    paragraph. A capitalised line after a bullet still starts a new paragraph (sub-heading or next sentence) - unless
    the bullet's line ends inside a code list that the line goes on with (_list_goes_on)."""
    out, buf, in_bullet, list_open = [], [], False, False
    for i, t in enumerate(lines):
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        if _BULLET_LINE_RE.match(t):
            if buf:
                out.append(" ".join(buf))
            buf, in_bullet = [t], True
        else:
            # 2026-10-04 (critic P51-7): a wrapped bullet whose code list goes on onto this line ('• ... H2033, S5150.' +
            # 'T1019. H0031, ...', or '• ... H0001, H0002,' + 'H0004, ...') keeps it: the capital letter of the code used
            # to end the bullet here, and S5151 lost its pairing with every code on the second line
            if in_bullet and buf and not (_CONTINUATION_RE.match(t) or list_open):
                out.append(" ".join(buf)); buf, in_bullet = [], False
            buf.append(t)
        # 2026-10-04 (page fidelity check): 'S5150.' as the LAST word of a physical line inside a code list ('S5150.' /
        # 'T1019. H0031, ...') is the manual's stray period, not a paragraph end - code_list_break, as inside a line.
        # 2026-10-04 (critic P51-4): it is one only after a list item, which may be on an earlier line ('... H2033,' /
        # 'S5150.'), so the paragraph read so far is the context, not the line alone
        list_open = _list_goes_on(" ".join(buf), nxt)
        if t.endswith((".", ":", ";")) and not list_open:
            out.append(" ".join(buf)); buf, in_bullet = [], False
    if buf:
        out.append(" ".join(buf))
    return "\n".join(re.sub(r"\s+", " ", x).strip() for x in out)


# ------------------------------------------------------------ pre-filter
def code_ranges(text: str) -> list[tuple[str, str]]:
    """[(low, high), ...] code ranges in the text ("99201-99499", "A0425 through A0436")."""
    out = []
    for m in CODE_RANGE_RE.finditer(text or ""):
        lo, hi = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        if lo[0].isalpha() and lo[0].upper() != hi[0].upper():
            continue                                    # "A0425-B1234" is not a range
        out.append((lo.upper(), hi.upper()))
    return out


def rule_signal(text: str) -> dict:
    """Cheap, deterministic 'does this look like a billing rule?' score.
    C3-17: TRIGGER_STEMS count as phrases too (obligations the substrings miss)."""
    codes = sorted(set(CODE_RE.findall(text)))
    ranges = code_ranges(text)
    low = text.lower()
    phrases = [p for p in TRIGGER_PHRASES if p in low]
    phrases += [f"~{rx.pattern}" for rx in TRIGGER_STEMS if rx.search(text)]
    score = len(codes) + 2 * len(ranges) + len(phrases) + (1 if MODIFIER_RE.search(text) else 0)
    return {"score": score, "codes": codes, "ranges": ranges, "phrases": phrases}


def inventory_record(acq: dict, meta: dict) -> dict:
    return {**{k: acq[k] for k in ("chapter", "title", "url", "path", "doc_hash", "bytes", "source", "fetched_at")},
            # C4-08: where the exact bytes of this version are kept (None for records made before versioning)
            "version_path": acq.get("version_path"),
            "pages": meta["pages"], "revision_date": meta["revision_date"],
            "revision_history": "; ".join(meta["revision_dates"]),
            "sections": meta["sections"], "candidate_sections": meta["candidate_sections"]}
