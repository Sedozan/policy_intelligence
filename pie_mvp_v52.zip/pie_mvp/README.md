# PIE — Policy Intelligence Engine (MVP package)

Turns AHCCCS billing policy into checks you can run: federal NCCI edits and the AHCCCS FFS Provider Billing
Manual (its chapters and rule-bearing exhibits) become one cited, versioned, reviewed rule table. That table compiles
to SQL, the SQL runs over paid claims, and every finding traces back to the policy text, the document version and the
person who approved the rule.

**Scope, in words you can repeat.** The state rules come from the documents in `config.CHAPTERS` (36 files: the FFS
manual's chapters and the exhibits with payment rules), identified by a `corpus_version` in the build log, and (v5.2)
from three AHCCCS rule **tables** read cell by cell by a deterministic loader (`00b`): the Same Day Disallow Table, the
HCPCS/CPT daily limits and the B2 behavioral-health matrix — each loaded file is a dated version, and a table's rules
compile only when every reading of it is signed. That is still not all AHCCCS coding policy: the PA guidelines, the
OPFS modifier list, the CBHSG and the RISSNET state NCCI files are listed in `config.CORPUS_PENDING` and not loaded yet.
Say "rules extracted from the configured FFS Provider Billing Manual corpus (corpus_version ...) and the AHCCCS rule
tables loaded (versions ...)", not "the AHCCCS policy rules". The NCCI rules in a build are the CMS edits **executable against this claims population** (both codes paid);
the build log keeps each CMS file's size next to that count (`ncci_source_vs_claims_scope`).

**How far to trust it today.** The SQL is tested against a written contract by an independent oracle and by mutation
testing; that proves the queries do what the rules say. Whether the rules say what the policy says - and whether a rule
was missed - is measured by people: v01 (precision, fidelity, recall with 95% intervals), v05 (regression against the
reviewed answers), v07 (page fidelity). Until v03 shows GO on those bars, use the engine as a controlled rule-discovery
and SME-review workbench, not as a validated, complete extraction of AHCCCS policy.

The LLM only **proposes** state rules. Deterministic grounding checks each proposal against the PDF, a named
reviewer signs it, and only signed rules compile. No model sits in the detection path.

---

## Run order

Copy the whole `pie_mvp` folder into `…/Projects/policy_intelligence/` (overwrite), then import the notebooks
keeping the folder structure. All notebooks find the package on their own. Set `PKB_PACKAGE_DIR` only if you
move them.

| # | notebook | compute | when | what it does | writes |
|---|---|---|---|---|---|
| 00 | `00_acquire_ncci` | CPU + UC | **quarterly** (schedule it monthly) | finds the six CMS Medicaid NCCI zips on the CMS page, archives them, parses, validates, loads one table per file. No egress: drop the zips in `data/ncci_raw/` and set `DOWNLOAD = False` | `main.sedo.medicaid_ncci_edit_*`, `ncci_acquisition_log` |
| 00b | `00b_load_ahcccs_tables` | CPU + UC | when AHCCCS publishes a table (B2 monthly; check the others quarterly) | reads the Same Day Disallow, daily-limits and B2 workbooks (any file name, recognised by layout) from `data/ahcccs_tables/`; each file is a **version** dated by its own "Updated / As of" date; refuses anything it cannot read exactly; archives the original; never replaces a loaded version | `main.sedo.ahcccs_same_day_disallow`, `ahcccs_daily_limits`, `ahcccs_b2_matrix`, `ahcccs_table_log` |
| 01 | `01_preflight_ncci` | CPU + UC | after 00 | read-only GO/NO-GO: NCCI tables (quarter gaps, PTP snapshot assumption, claims date coverage); **which edit file each provider type's lines take** (BProv_Type × SProv_Type code × FORM_TYP, descriptions shown); data shape (reversals, $0 lines, PA fill rate); check T: the AHCCCS table versions loaded, the dates each judges, whether 07 will compile them, and what B2 would flag in your claims before you sign its reading; check F also counts the lines the table readings cannot judge (no billing provider id; a group's line with no rendering type) | — |
| 02 | `02_migrate_state_rules` | CPU + UC | once (safe to re-run) | upserts the 59 hand-authored rules (each with a verbatim quote and page). Since the fresh start they are a **checklist** v05 scores extraction runs against — never sent for review, never compiled (`COMPILE_HAND_AUTHORED`). **Never** deletes drafts or reviews | `main.sedo.state_rules` |
| 03 | `03_stage_inputs` | CPU + UC | each extraction cycle | copies the manual's PDFs (all 36 files: chapters and exhibits) and table snapshots into workspace files for the GPU step | `data/policy_docs/`, `data/snapshots/` |
| 04 | `04_extract_chapters_gpu` | **Serverless GPU** | each extraction cycle | gpt-oss-120b proposes rules; grounding keeps or refuses each one. Files only, no Spark. Default `CHAPTERS_TO_RUN = ["19"]` | `data/extraction_runs/<run_id>/` |
| 05 | `05_persist_extraction` | CPU + UC | after 04 | merges drafts into `state_rules`, appends run telemetry (including every draft of the run, `policy_extraction_drafts`), exports the review workbook | `state_rules`, `policy_extraction_*`, `policy_sections`, `policy_document_inventory`, `data/review/policy_rules_review.xlsx` |
| — | *SME review* | Excel | after 05 | reviewer fills `decision` (Approve / Reject / Fix), `reviewer`, `review_note` in the workbook | — |
| 06 | `06_review_decisions` | CPU + UC | after review | applies signed decisions to pending rows; a decided row changes only with `reopen = yes` and a name | `state_rules`, `policy_review_log` |
| 07 | `07_build_kb` | CPU + UC | after 00, 00b or 06 | gate → normalise → compile; stores every query with its sha256; the AHCCCS table rules (only when every reading is signed; stops if a table no longer holds what 00b loaded); coverage (dollars inside each rule's window); registers; `build_id` + history | `policy_rules`, `policy_detectors`, NCCI and AHCCCS edit tables, `policy_ahcccs_conflicts`, coverage, gap, registers, `*_history`, `policy_build_log` |
| — | `validation/v06_query_validation_pack` | CPU + UC | after 07 | the query validation pack: every query in plain English + its SQL + synthetic claims that must / must not be flagged, run through the stored SQL. A validator signs OK / PROBLEM per query | `data/validation/query_validation_pack_<build>.xlsx`, `policy_query_validation(_tests)` |
| 08 | `08_run_detectors` | CPU + UC | after 07 (and v06) | checks the build and every hash; builds the snapshot; NCCI as two table-driven statements (**only when every provider type code on the claims' CMS-1500 / UB-04 lines has a signed routing row**), the AHCCCS tables as three, state rules one statement each, rolling-window signals; never runs a query a validator marked PROBLEM | `policy_findings`, `policy_detector_runs`, `policy_utilization_signals` |

**The next run (fresh start, 2026-10-04):** only rules from ONE engine version go into the KB.
1. 03 (stages all 36 files) → 04 with `CHAPTERS_TO_RUN = list(config.CHAPTERS)` (prompt v2; the answer cache is keyed
   on prompt, model and reasoning level, so nothing from v1 is reused) → 05.
2. v05: score the run against `policy_rules_review_AI_prereview_v5.xlsx` (the reviewed answers; the hand-written rules
   serve only as a checklist). Gate: DANGER = 0 and no unmatched compiled rule left unadjudicated. For the
   reasoning-effort question, run 04 a second time on the gold chapters with `REASONING = "medium"` and give v05 both
   run folders (`RUN_DIR_B`).
3. v01: score a sample (precision, fidelity, recall); v07: score a sample of pages.
4. Review the new workbook (05 exports it) → 06 → 07 → v06 (validate the queries; a sample first is fine) → sign
   `reference/ncci_provider_type_routing.csv` for the provider types in your claims (01 lists them) → 08.
5. (v5.2) Drop the AHCCCS rule tables — and AHCCCS's **earlier versions** of them, to judge older claims — in
   `data/ahcccs_tables/` → 00b → read and sign `reference/ahcccs_table_readings.csv` (each reading is a sentence about how
   a table is read; the `binds` column ties it to the config value it describes) → 07 → v06 → 08.
The exact definition of every query is `docs/QUERY_SEMANTICS.md`; what changed and how it was verified is
`docs/V5_CHANGES.md`.

**When AHCCCS revises a chapter:** run 03 → 04 → 05. Approved rules from the old PDF drop to `needs_review` with
their `prior_review` kept, and 07 **excludes** them until someone re-signs them against the new text. The old PDF
is kept in `data/policy_docs/_versions/`.

---

## Demos and validation (`notebooks/demos`, `notebooks/validation`)

Read-only unless noted. Each opens with *What this answers / How to read it / Limits*.

| notebook | answers |
|---|---|
| `d01_code_lookup` | everything that governs one procedure code: federal edits, state rules with quotes, leads, overlaps, exposure, findings. Says "No governing authority found" when that is the answer |
| `d02_finding_explainer` | the audit trail for one finding: claim lines, the rule *as it was in that build*, the policy words, the source, the approver, PA status, and a plain-English paragraph |
| `d03_provider_review` | providers by distinct flagged dollars, which rules drive them, flag rate against peers billing the same codes |
| `d04_coverage_gap` | share of paid dollars dated inside the window of a compiled detector of their code (federal / state / none); biggest unchecked dollars; policy text with no detector yet |
| `d05_ambiguity_register` | unclear or unenforceable policy, by category, with quotes. Exports an xlsx for AHCCCS |
| `d06_federal_state_overlaps` | where CMS and AHCCCS rules cover the same code, who is stricter, contradiction **candidates** |
| `d07_policy_change_impact` | document versions, change events, rules waiting for re-sign, stale approvals, orphaned findings |
| `d08_ncci_federal_edits` | NCCI quarters loaded or missing, acquisition log, edition disagreements, top-firing edits |
| `d09_policy_text_search` | keyword search over the manual's sections with page references |
| `v01_extraction_scoring` | exports a scoring sample of the **latest extraction run's own drafts** (before review, rejected ones included); after the SME scores it, computes per chapter and pooled, each stratum weighted by its size, with 95% intervals: precision, **executable-rule precision** (real AND faithful among rules that compile), fidelity, **recall = real rules found ÷ (found + missed)**, and the filter loss (real rules the grounding dropped, DROPPED sheet). Every number carries its population, `corpus_version` and the runs it was drawn from (`sample_runs`); v03 judges it only while those are still the latest (writes `policy_quality_metrics`) |
| `v02_detector_precision` | exports a findings sample; after investigator dispositions, computes precision per rule type (writes `policy_quality_metrics`, `policy_finding_reviews`) |
| `v03_pipeline_health` | the definition-of-done measurement bar: GO / NOT YET per item, pass marks on the **lower** 95% bound (executable-rule precision ≥ 0.95, recall ≥ 0.90, fidelity ≥ 0.95), every executable state rule signed, routing signed for every provider type in the claims, the corpus version and what is not loaded. Nothing says GO without a measured number |
| `v04_chapter_profile` | which chapters the current grammar can handle (code families, rule cues) — run before choosing the next chapter |
| `v05_extraction_regression` | a new extraction run against the reviewed answers: recall, precision, exact match, and DANGER (a rule that would compile but should not) per chapter, with each run's `corpus_version`. Ship gate: DANGER = 0 **and** no unmatched compiled rule (an executable rule the reviewed answers do not have) until someone adjudicates it. `RUN_DIR_B` compares two runs on the same answers (e.g. reasoning low vs medium) |
| `v07_page_fidelity` | what a person sees on a PDF page against what reaches the extractor: lost codes, code lists cut in two, text filed under the wrong heading, rows out of order, table cells taken for headings. Exports a page sample (with the rendered page) to score; the score becomes a page-fidelity rate (documents weighted by length) with a 95% interval; a sheet with duplicate pages or mixed corpus versions is refused |
| `v06_query_validation_pack` | every query of the build in plain English with its SQL and must-flag / must-not-flag scenarios run through the stored SQL; the validator's OK / PROBLEM is bound to the SQL's sha256 and 08 obeys it |

---

## Package

```
config.py              every table name, claims column, switch and path
reference/             ncci_provider_type_routing.csv: AHCCCS provider type code -> CMS Table 2 row (sign it);
                       ahcccs_table_readings.csv: how each AHCCCS rule table is read, one sentence per reading (sign it)
ahcccs_tables.py       the AHCCCS rule tables: deterministic reader, versions and windows, readings gate, table -> rules,
                       conflicts with state rules, load checks (00b, 01 check T, 07)
ncci_routing.py        which NCCI edit file a line takes (provider type x claim form), Python + SQL twins
schema.py              Rule + closed predicate grammar + content-derived ids (NCCI- / EXT- / MAN- / TBL-)
acquire_ncci.py        CMS page → archived zips → validated main.sedo quarter tables
ingest_ncci_tables.py  NCCI tables → rules (latest PTP snapshot; dated MUE runs; fails loudly on bad rows)
policy_docs.py         PDF → sections (acquire + archive old versions, parse, headings, pre-filter)
extract_rules.py       sections → proposals (STUB / HFLOCAL / HYBRID) → grounding → drafts; per-section outcomes
extract_io.py          GPU ⇄ CPU hand-off files; guard against shrinking state_rules
state_rules.py         the reviewed rule table: merge, re-sign on new doc version, review workbook round-trip
state_seed.py          59 hand-authored rules from Ch10/Ch14/Ch19, each with a verbatim quote (a v05 checklist; not compiled)
post_checks.py         extraction post-checks (conditional modifiers, combined caps, pair scope, hub sentences)
regress.py             extraction regression against reviewed answers (v05)
validate_gate.py       clean / patched / downgraded / needs_review / rejected, with reasons
rule_normalize.py      stable ids, planes, NCCI edition collapse (directional, split by window), state duplicate collapse
detector_gen.py        rules → SQL; the detection snapshot; NCCI PTP/MUE and the three AHCCCS tables as table-driven
                       statements; signals
query_pack.py          the query validation pack: plain English + scenarios run through the stored SQL (v06)
run_guard.py           what 08 checks before it runs anything: one build, every hash, the validator's decisions
preflight_sql.py       the read-only checks of 01
gap.py                 coverage: the paid dollars dated inside a compiled detector's window, per code and claim form
registers.py           ambiguity register; federal/state overlaps and contradiction candidates
quality.py             sampling, Wilson intervals, extraction and detector metrics
policy_changes.py      what changed between document versions
kb_io.py               pandas → Delta with explicit types
tests/                 offline tests; Spark 4 SQL tests; the independent oracle; e2e_local_spark.py runs every notebook
docs/                  QUERY_SEMANTICS.md (the contract every query meets), V5_CHANGES.md, earlier change logs
```

## Tables (`main.policy_kb` unless noted)

| table | one row per |
|---|---|
| `main.sedo.state_rules` | state rule, hand-authored or extracted, with `review_status`, `prior_review`, `extraction_source` |
| `main.sedo.medicaid_ncci_edit_*`, `main.sedo.ncci_acquisition_log` | CMS edit row per quarter; acquisition event |
| `main.sedo.ahcccs_same_day_disallow`, `ahcccs_daily_limits`, `ahcccs_b2_matrix`, `ahcccs_table_log` | Same Day cell / daily-limit row / B2 (code, provider type) per table version; load event (with the version's row count and rows hash) |
| `policy_document_inventory`, `policy_sections` | chapter × fetch (doc_hash, revision date); section |
| `policy_extraction_outcomes` | section × run: `skipped_prefilter` / `no_rules` / `proposals` / `failed_retryable` — the recall ledger |
| `policy_extraction_log`, `policy_extraction_drafts`, `policy_extraction_dropped`, `policy_extraction_cache`, `policy_change_log` | run telemetry (with each run's prompt version), every draft a run produced, refused proposals, model cache, change events |
| `policy_review_log` | reviewer decision, the doc_hash it was made against, and whether it was applied |
| `policy_rules`, `policy_rules_history` | rule in the current build / every build (`build_id`, reviewer, quote, jurisdiction) |
| `policy_detectors`, `policy_detectors_history`, `policy_batch_detectors` | rule → SQL or lead reason; the two NCCI batch statements |
| `policy_ncci_ptp_edits`, `policy_ncci_mue_limits` | NCCI edit as data, for the batch statements |
| `policy_ahcccs_pair_edits`, `policy_ahcccs_daily_limits`, `policy_ahcccs_provider_types` | AHCCCS table rule as data, for the three table statements (`both_ways` marks a pair disallowed in both directions) |
| `policy_ahcccs_conflicts` | where a table contradicts or qualifies a state rule, and every table row recorded but not compiled (two daily limits, anesthesia, all-nines maxima) — a list for a person |
| `policy_coverage`, `policy_coverage_summary`, `policy_gap` | paid code × coverage (with the dollars dated inside a federal / state / any rule's window); coverage shares; dollars no state rule judges, by code |
| `policy_ambiguity_register`, `policy_rule_overlaps` | unclear policy entry; federal/state rule pair on a code |
| `policy_build_log` | build: counts, coverage %, stale approvals excluded, register sizes, NCCI quarters |
| `policy_claims_snapshot` | the normalised claims every query reads, rebuilt by 08 (its Delta version is logged per run) |
| `policy_findings`, `policy_detector_runs` | flagged line or member-day (`build_id`, `paid_amt`, `pa_status`, `ncci_edition`, `query_validation`; `billing_provider` on a per-provider daily group); detector execution (`sql_sha256`, `skipped`; the `RUN:snapshot` row also counts the both-ways pair findings and the dollars they count twice) |
| `policy_utilization_signals` | member over a period limit inside a rolling window (anomaly signal, never a finding) |
| `policy_query_validation`, `policy_query_validation_tests` | validator decision per query, bound to the SQL's sha256; scenario results per build |
| `policy_quality_metrics`, `policy_extraction_scores`, `policy_finding_reviews` | measured quality numbers (with `population`, `corpus_version`, `sample_runs`, `unscored`) and the raw scores behind them |

A finding reaches its rule text with `policy_findings JOIN policy_rules_history USING (build_id, rule_id)`.
The same claim line can be flagged by more than one rule (e.g. an NCCI pair and a state pair), so count
**distinct `(claim_id, line_no)`** when adding up dollars.

## Decisions that are yours (config.py)

| switch | default | meaning |
|---|---|---|
| `NCCI_ROUTE_BY` | `"billing_provider_type"` | each line takes the NCCI edit file CMS Table 2 gives its **billing** provider type code (BProv_Type; CMS: "claims from" a type of provider) and claim form; the servicing type (SProv_Type) says whether a rendering practitioner is identified, and is used when the billing type is missing or not in the table. `"provider_type"` = the servicing type picks the row. `"form"` = by claim form only |
| `CLAIM_COLS["billing_type"]` | `"BProv_Type"` | the billing provider type code column (`BILLING_TYPE_DESC_COL` = `"BProv_Type_Desc"`, display only; 01 skips it if absent) |
| `NCCI_OPTIONAL_CATEGORIES_ON` | `()` | CMS's two optional Table 2 rows: `"testing_facility"`, `"other_outpatient"` (FQHCs, clinics, BH outpatient...). Off = their lines take no NCCI file |
| `NCCI_UNMAPPED_PROVIDER_TYPE` | `"none"` | a line neither of whose provider types is in the table: no NCCI (precision first: the edit file is not guessed). `"form"` = A → practitioner, O → outpatient |
| `NCCI_REQUIRE_SIGNED_ROUTING` | `True` | 08 runs the NCCI statements only when every provider type code on the claims' CMS-1500 / UB-04 lines (billing and servicing) has a **signed** row in the routing table; otherwise it records them as not run, with the codes to sign. `False` (or env `PKB_NCCI_REQUIRE_SIGNED_ROUTING=0`) = exploratory run on the proposed mapping; the run log says the routing was unsigned |
| `NCCI_PROVIDER_TYPE_TABLE` | `reference/ncci_provider_type_routing.csv` | the routing table (env `PKB_NCCI_PROVIDER_TYPE_TABLE` points elsewhere) |
| `LLM_REASONING` | `"low"` | the model's reasoning effort (env `PKB_REASONING`); part of the answer-cache key. Compare low and medium with v05 before changing it |
| `RUN_ONLY_VALIDATED_QUERIES` | `False` | `True` = 08 runs only queries a validator signed OK for their current SQL. A PROBLEM never runs either way |
| `STATE_RULES_CLAIMS_SCOPE` | `False` | every signed state rule compiles, paid in this extract or not |
| `COMPILE_HAND_AUTHORED` | `False` | the fresh start: hand-authored rules are a checklist for v05 — not exported for review, never compiled. `True` (env `PKB_COMPILE_HAND_AUTHORED=1`) = exported and compiled once signed |
| `KB_PROMPT_VERSIONS` | `("v2",)` | one engine in the KB: an extracted rule compiles only when the last run that produced it used one of these prompt versions (`policy_extraction_log.prompt_version`); a rule only an older engine produced stays out until the current engine produces it again. `()` (env `PKB_KB_PROMPT_VERSIONS=any`) = any engine |
| `COMPILE_LEGACY_SEEDS` | `False` | (with `COMPILE_HAND_AUTHORED`) hand-authored rules compile only once signed. `True` = the old behaviour (no signature needed) |
| `DOB_FORMAT` | `None` | the layout of date_of_birth if it is text a plain cast cannot read (e.g. `"MM/dd/yyyy"`) |
| `AHCCCS_TABLES_REQUIRE_SIGNED_READINGS` | `True` | an AHCCCS table's rules compile only when every reading of it in `reference/ahcccs_table_readings.csv` is signed and every config value a reading binds is unchanged |
| `AHCCCS_SAME_PROVIDER_SCOPE`, `AHCCCS_DAILY_LIMIT_SCOPE` | `"member_servicing_billing_day"` | "same provider" for an A* pair and a daily limit = the same servicing AND billing provider id until you settle which one AHCCCS means (the A* legend says "service site or residential placement"); `"member_provider_day"` = servicing id only; `"member_day"` = any provider |
| `AHCCCS_B2_PROVIDER_ROLE`, `GROUP_BILLING_PROVIDER_TYPES` | `"billing_or_rendering"`, `("01",)` | B2 judges the billing provider type, except a group's line (01), judged on its rendering type; `"billing"` = always the billing type |
| `AHCCCS_B2_COMPILE_CODES` | `^H[02][0-9]{3}$` | the B2 codes whose provider list is compiled (behavioral-health-only HCPCS); the others are recorded |
| `AHCCCS_DAILY_RECORD_ONLY_CODES`, `AHCCCS_DAILY_PLACEHOLDER_MAX` | anesthesia `^0[01][0-9]{3}$`, `^9{3,}$` | daily-limit rows recorded, not compiled: anesthesia is billed in time units; 999 / 999999 are placeholders |
| `AHCCCS_TABLE_MAX_AGE_DAYS` | B2 / daily 62, Same Day 366 | 01 and 07 warn when the claims outrun a table's newest version by more than this |
| `DAILY_CAP_VERIFY_MODIFIERS` | bilateral / anatomic / repeat / distinct | a daily-cap finding with one of these modifiers on a line is `verify_modifier` (one line alone over the cap: `verify_span`) |
| `NCCI_DELETION_DATE_INCLUSIVE` | `True` | **verified** (TGM App. B): an edit is still in force on its deletion date |
| `NCCI_STRICT` | `True` | bad NCCI rows (modifier not 0/1/9, missing effective date, non-numeric MUE) stop the build instead of being dropped |
| `NCCI_ALLOW_EMPTY` | `False` | no NCCI tables stops the build instead of publishing a state-only KB |
| `NCCI_ALLOW_MUE_GAPS` | `False` | a missing MUE quarter stops the build instead of assuming the old value held |

## How the rules stay honest

| stage | guarantee |
|---|---|
| propose | closed grammar; the model must quote the source; unclear → `not_checkable`, never a guess |
| ground | the quote must be in the section and at least 6 words (or name every code); every code in the section; threshold in the quoted sentence; negation/number drift refused. A quote that drops an "unless…/except…" clause, or codes stated far from the quote, is kept but flagged and capped at 0.5 confidence. The stored quote is the **source** text, not the model's |
| outcomes | every section gets an outcome row, so recall can be measured |
| merge | keyed by meaning. Approved rows are never downgraded by a re-run of the same document. A **new document version** sends them back for re-sign |
| review | a decision needs a named reviewer, the document version it was made on, and a row that is still pending |
| build | only approved rules from the **current** document version compile, and only those the current extraction engine produced (prompt v2; hand-authored rules never — `KB_PROMPT_VERSIONS`, `COMPILE_HAND_AUTHORED`). What was left out, and why, is in the build log |
| validate | every query's plain English, SQL and scenarios go to a validator (v06); OK / PROBLEM is bound to the SQL's sha256 |
| detect | deterministic SQL; 08 refuses edited or unhashed SQL and never runs a PROBLEM query; NCCI ignores PA (CMS: not a bypass); state findings with a PA number are `verify_pa`, never suppressed |

**NCCI routing.** CMS decides which NCCI edit file applies by provider type and claim form (2026 Medicaid NCCI
Technical Guidance Manual §6.0 Table 2), and it applies the methodologies to "claims ... from" a type of provider (§5.3) —
the provider that bills. Each claim line takes ONE file — practitioner, outpatient hospital or DME — from its **BProv_Type
code** (falling back to SProv_Type; a line neither of whose types is in the table takes none) and FORM_TYP, through `reference/ncci_provider_type_routing.csv`;
descriptions are shown, never used. SProv_Type decides only whether a rendering practitioner is identified (it matters for
CMS's optional "other providers" row). Dentists are physician practitioners (TGM footnote 14): a dentist's CMS-1500 takes
the practitioner file, a dental claim none. Files are never merged. Dental, pharmacy, inpatient and long-term-care claims
take none (TGM §5.2). The table is a policy reading: it ships *proposed* and must be signed - 08 does not run NCCI until
every provider type code in your claims' CMS-1500 / UB-04 lines has a signed row (01 shows every billing × servicing type
combination, the file its lines take, and which codes still need a signature). Findings follow the CMS public edit set;
CMS says states must adjudicate with their secure RISSNET files, so Arizona's deactivations and historical MUEs are not
applied until AHCCCS provides them (`config.CORPUS_PENDING`): read NCCI findings as leads, not definitive denials.

**Provider-type rules.** "Must be billed only by the following provider types" compiles (`provider_type_allowed`): a
payable line of the code(s) whose BILLING provider type (or servicing, if the rule says so) is known and not in the list is
a `provider_type_not_allowed` finding; a line with no type is never one. First rule: H0035 partial hospitalization (Ch19),
billed only by B2, B5, 02 or 71, from 2024-07-08. The B2 matrix adds one rule per behavioral-health-only code (H0xxx /
H2xxx); a group (01) billing such a code is judged on its rendering provider's type.

**AHCCCS rule tables (v5.2).** Same Day Disallow: D = the two codes never on one member-day (any provider); A* = not
from the same provider; A = allowed; the row code's line is the finding (`verify_exception`: table note 2 allows
exceptions for medical necessity). Daily limits: the "Procedure Maximum Occurrence" is units per member, provider and day;
anesthesia and all-nines rows are recorded only; one line alone over the cap is `verify_span` (no service end date in
the claims). Each loaded file is a version that judges claims from its own date to the day before the next version; claims
before the oldest loaded version are not judged by the table — load AHCCCS's earlier versions to judge them.

## Testing

```
python -m pytest tests -q                                  # offline, no Spark (~10 s)
python -m pytest tests/test_sql_spark.py -q                # the SQL on Spark 4, ANSI on (needs pyspark 4 + Java)
python -m pytest tests/test_sql_oracle.py -q               # independent oracle vs the SQL on random claims
python -m pytest tests/test_sql_oracle_tables.py -q        # independent oracle for the AHCCCS table rules and statements
python tests/e2e_local_spark.py --demos                    # every notebook, in order, on a local Spark
```
The oracle was written from `docs/QUERY_SEMANTICS.md` alone, by an agent that never read the SQL; it must agree with the
SQL on every finding, label, unit, evidence line and dollar. The end-to-end run uses synthetic claims and NCCI tables with
the real column names, plants known violations and false-positive traps, and checks each (including that a modifier-59
bypass is not flagged, a DME supplier never takes the practitioner file, a PDF revision pulls approvals out of the build,
a half-written build is refused, and a query a validator marked PROBLEM does not run).

## Not verified yet (needs your workspace)

* The provider type routing table against your claims: run 01 and read its billing × servicing type × claim form table.
  Every code in the claims is in the table (SProv_Type 79 codes, 2026-10-03; BProv_Type 70 codes, 2026-10-04 — 01
  group ID only bills); 01 warns on any new one.
* LN_NO's and date_of_birth's column types (both handled; 08 warns when most birth dates do not read).
* That a filled EVENT_PA_NO means an approved PA (findings with one are `verify_pa`, never plain violations).
* The exact layout inside CMS's NCCI text files (the parser finds the header itself and stops if it can't).
* Cluster egress to cms.gov and azahcccs.gov (drop-zone and upload fallbacks exist).

## Upgrading from the previous package (one-time effects)

**v5.2 (2026-10-04, the AHCCCS rule tables)**
* New notebook 00b and tables `main.sedo.ahcccs_*`; 07 writes three more edit tables and `policy_ahcccs_conflicts`;
  `policy_batch_detectors` holds five statements (2 NCCI + 3 AHCCCS) — always five, `rules` = 0 for a table not loaded
  or not signed. Nothing changes until you load a table AND sign its readings.
* Every state daily cap's SQL changed (the `verify_span` / `verify_modifier` labels), and the A* / daily scope and B2
  role are new: re-validate those queries in v06 (their sql_sha256 moved).
* `policy_coverage` gains dated-dollar columns and the coverage percentages in the build log now count only the dollars
  inside each rule's window (lower than before); `policy_rule_overlaps` leaves out the table rules (the conflicts
  table covers them); `policy_findings` gains `billing_provider`.
* The build log gains `ahcccs_*` fields (tables loaded, versions, readings still to sign, rules per statement, stale
  tables, the readings file's sha256).

**v5.1 (2026-10-04, after the external review)**
* 08 no longer runs NCCI until the routing table is signed for the provider types in your claims (see the switch above);
  a line whose provider types are not in the table takes no NCCI file (was: the claim form decided).
* 03 stages 36 files (5 FFS exhibits added). The PDF reader changed (a period ending a PDF line inside a code list;
  a period after a lone code no longer fuses two sentences; exhibit rows no longer stripped as page headers, footers
  with a code-shaped token still are; running headers only from the top / bottom of a page; a table filed where its own
  first line is; only lines in a grid row are table content, so a heading under a table or in a merged row stays a
  heading): section texts change, so the next extraction re-reads them (the fresh start re-extracts everything anyway).
* One engine in the KB (SB's fresh start): hand-authored rules are no longer exported for review or compiled
  (`COMPILE_HAND_AUTHORED`), and 07 compiles an extracted rule only when the last run that produced it used prompt v2
  (`KB_PROMPT_VERSIONS`; the build log lists what it left out, `engine_excluded`). A decided rule the new run produces again
  keeps its decision and names the new run.
* v01 samples the latest run's own drafts (new table `policy_extraction_drafts`, written by 05) and weights strata by
  size; its workbooks have new columns (`real_rules_found`, `population`, `corpus_version`, a DROPPED sheet). An older
  workbook is still ingested, but its recall and executable-rule precision are not computed and v03 does not judge it.
  `policy_quality_metrics` gains `unscored`, `scored_units`, `population`, `corpus_version`, `sample_runs` (a newer
  extraction run of a sampled chapter makes its numbers NOT YET until v01 is re-exported).
* v05's gate also blocks an unmatched compiled rule, counts a reversed code pair as DANGER (the finding lands on the
  other line), and judges each run on all its own chapters; the A/B table is a comparison only.
* v07 GOLD sheets gained `doc_pages`: re-export a sheet exported before this version.
* `policy_findings.ncci_routing` says on every NCCI finding whether its routing was signed. The build log gains
  `corpus_version`, `corpus_pending`, `ncci_rules_scope`, `ncci_source_vs_claims_scope`, `kb_prompt_versions`,
  `compile_hand_authored`, `engine_excluded`.

**v5 (2026-10-03)**
* NCCI rule ids change once: each NCCI rule now names the edit file it comes from (`ncci_edition`). Old findings still
  trace through `policy_rules_history` on (build_id, rule_id).
* New columns are added on the next write: `policy_findings.ncci_edition / query_validation`,
  `policy_detector_runs.query_validation / skipped`, `policy_utilization_signals.query_validation`.
* Hand-authored rules stop compiling until signed (they are in the review workbook, origin `manual`).
* Sign `reference/ncci_provider_type_routing.csv` (put a name in `reviewer` and `signed` in `status`); until then 01 and
  v03 say it is unsigned.
* NCCI routing now reads BProv_Type (the billing provider type): lines billed by a hospital take the outpatient file even
  on a CMS-1500, lines billed by an FQHC / clinic / BH clinic take none while CMS's optional rows are off. A dentist's
  CMS-1500 now takes the practitioner file.

**Earlier**

* **NCCI rule ids change once.** The quarter label left the id, so from now on ids stay the same across quarters.
  Extracted rules now use the `EXT-` prefix. Findings from before this version have no `build_id` and won't join to
  history.
* New columns (`state_rules.prior_review / extraction_source / model_quote`, and new findings and run columns) are
  added on the next write.
* `06_review_decisions` checks that `policy_review_log`'s text columns are text. If an earlier run created them as
  DOUBLE (empty workbook cells), it stops and prints the one-line repair. It changes nothing on its own.
* Notebooks were renamed 00–08. `extract_chapters` (single GPU+UC cluster), `diag_model` (serving-endpoint route) and
  `demo_kb` (now `demos/`) were removed.
