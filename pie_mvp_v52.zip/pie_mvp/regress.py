"""
regress.py  -  score a NEW extraction run against the SIGNED review decisions (C3 critic). Ship gate (ship_gate):
DANGER == 0 AND unmatched_compiled == 0 (2026-10-04: an executable draft nobody reviewed blocks the run too).

Why: a prompt, model, reasoning-effort or post-check change is only an improvement if it reproduces what reviewers
signed - and, above all, if it never proposes a rule that would flag a claim the signed rule does not (a reviewer who
rubber-stamps a draft would compile it).

Gold rows (build with gold_from_state_rules / gold_from_review_log / gold_from_workbook / gold_from_review_json):
  positive  an approved rule: its predicate as signed (for a FIXED rule that is the reviewer's corrected predicate)
  missed    a rule a reviewer listed as missed by the extraction (verbatim + suggested predicate)
  negative  a rejected rule: a run must not produce it again as something that compiles
  excluded  holds, unsigned decisions, rows bound to another document version (counted, not scored)
  {gold_id, kind, chapter, doc_hash, extraction_key, quote, predicate, population, effective_date, end_date,
   reviewer, source}
Drafts: drafts.jsonl rows of a run (extract_io.read_run(run_dir)["drafts"]); predicate / codes may be JSON text.

Matching, per chapter, one-to-one, greedy by score:
  10.0             same extraction_key (always wins: the cap and the pair read from one sentence share a quote)
  2.0 + q + t + c/10  normalised quotes (post_checks.norm): one contains the other or SequenceMatcher ratio >= 0.85
                   (0.80 for missed rules, whose verbatim a reviewer typed) AND compatible codes (either side
                   uncoded / not_checkable, Jaccard >= 0.5, or one code set contains the other); q = quote score,
                   t = 0.2 for the same predicate type, c = code Jaccard - so the right pair of a three-pair
                   sentence, and the cap rather than the pair read from the same sentence, wins
  a leftover draft of the same type that matches an already-matched gold: 'duplicate' when its comparable predicate is
  the gold's (a harmless copy) or wider (DANGER); otherwise 'unreviewed_variant' - another reading of the same text
  nobody signed, counted as unmatched (and unmatched_compiled when it would compile). Any other leftover ->
  'unmatched' (new or wrong - unknown until reviewed); a gold with no draft -> 'missing' (a recall loss)
Scores: exact = same comparable predicate (canon: codes - for a pair, which one is code_a and which code_b -,
  threshold, period, pair scope with default member_provider_day, indicator default "0", age, modifier, provider
  types); labels (exception, discretionary), population and window are reported as label_diffs.
DANGER (wider_reasons) - the draft would flag a claim the signed rule does not:
  * the draft compiles and the gold does not, or the gold is a rejection
  * both compile and the draft is wider: other codes or type, a pair REVERSED (the finding sits on code_b, so it
    flags the other line), a code_set that sums more codes, a lower threshold, another period, member_day where the
    gold is member_provider_day, indicator 0 where the gold is 1, no age (or a wider age band), an earlier start /
    later or missing end, population 'all' where the gold is scoped, or a missing exception / discretionary label the
    gold carries
"""
from __future__ import annotations

import difflib
import json
import re
from collections import defaultdict

import post_checks as pc
import schema

COMPILED = set(schema.PREDICATE_TYPES_COMPILED)
_ALL_POP = ("all", "", "any", "all members", "none", "nan")
_SUMS = {"max_units_per_day", "max_units_per_period", "max_units_per_dos", "max_dollars_per_period"}
_PERIOD_RANK = {"month": 1, "year": 2, "benefit_year": 2}


# ------------------------------------------------------------------ small helpers
def _obj(v):
    if v is None or (isinstance(v, float) and v != v):
        return None
    if isinstance(v, (dict, list)):
        return v
    s = str(v).strip()
    if not s or s.lower() in ("nan", "none"):
        return None
    try:
        return json.loads(s)
    except ValueError:
        try:
            import ast
            return ast.literal_eval(s)                    # reviewers sometimes paste python dicts
        except (ValueError, SyntaxError):
            return None


def _s(v) -> str:
    return "" if v is None or (isinstance(v, float) and v != v) else str(v).strip()


def pred_of(x: dict) -> dict:
    p = _obj(x.get("predicate"))
    return p if isinstance(p, dict) else {}


def codes_of(x: dict) -> set:
    c = _obj(x.get("codes")) or []
    return set(pc.codes_of(pred_of(x))) | {str(v).upper() for v in c if v}


def population(x: dict) -> str:
    return _s(x.get("population")).lower() or "all"


def compiles(p: dict, pop: str = "all") -> bool:
    """Would this predicate become SQL once approved? A compiled type whose population is scoped compiles only when
    an age condition expresses it (schema AGE contract); otherwise the gate keeps it a lead."""
    if not p or p.get("type") not in COMPILED:
        return False
    return (pop or "all").strip().lower() in _ALL_POP or bool(p.get("age"))


def canon(p: dict | None):
    """Comparable predicate. Defaults are explicit, so v1 and v2 spellings compare equal (a pair without scope is the
    narrow member_provider_day, as the reviewer brief and schema.PAIR_SCOPES define it)."""
    if not p:
        return None
    t = p.get("type")
    codes = frozenset(pc.codes_of(p))
    if t == "not_checkable":
        return (t, p.get("reason"))
    age = json.dumps({k: schema.integral(v) for k, v in (p.get("age") or {}).items()}, sort_keys=True)
    if t == "code_pair_prohibited":
        # 2026-10-04 (critic M51-5): ORDERED (code_a, code_b). The compiled finding sits on the code_b line
        # (detector_gen.compile_code_pair), so 97110 -> 97530 and 97530 -> 97110 flag different lines: never "exact"
        return (t, _s(p.get("code_a")).upper(), _s(p.get("code_b")).upper(), p.get("scope") or "member_provider_day",
                schema.normalize_indicator(p.get("modifier_indicator")) or "0", age)
    thr = schema.integral(p.get("threshold")) if "threshold" in p else None
    return (t, codes, thr, p.get("period"), _s(p.get("modifier")).upper(), provider_types(p),
            provider_role(p) if t == "provider_type_allowed" else None, age)


def provider_types(p: dict) -> frozenset:
    """provider_type_allowed's list, cleaned like the claims column (' 2' / 2 / '2.0' -> '02')."""
    import ncci_routing
    return frozenset(t for t in (ncci_routing.norm_type(x) for x in (p.get("provider_types") or [])) if t)


def provider_role(p: dict) -> str:
    return _s(p.get("provider_role")).lower() or "billing"


def _age_band(a) -> tuple[int, int]:
    a = a or {}
    lo, hi = schema.integral(a.get("min")), schema.integral(a.get("below"))
    return (0 if lo is None else lo, 200 if hi is None else hi)


def wider_reasons(d: dict, g: dict) -> list[str]:
    """Why the draft `d` would flag a claim the signed gold `g` does not (both rows; [] = not wider)."""
    dp, gp = pred_of(d), pred_of(g)
    dpop, gpop = population(d), population(g)
    if not compiles(dp, dpop):
        return []
    if g.get("kind") == "negative":
        return ["the signed decision REJECTED this rule"]
    if not compiles(gp, gpop):
        return [f"compiles ({dp.get('type')}) where the signed rule does not ({gp.get('type') or 'no rule'})"]
    out = []
    dt, gt = dp.get("type"), gp.get("type")
    if dt != gt and not (dt == "max_units_per_dos" and gt == "max_units_per_day"):   # per-provider is narrower
        out.append(f"type {gt} -> {dt}")
    dc, gc = set(pc.codes_of(dp)), set(pc.codes_of(gp))
    if dt == "code_pair_prohibited":
        if dc != gc:
            out.append(f"pair {sorted(dc)} vs signed {sorted(gc)}")
        elif gt == dt and _s(dp.get("code_b")).upper() != _s(gp.get("code_b")).upper():
            # 2026-10-04 (critic M51-5): the compiled finding sits on the code_b line (detector_gen.compile_code_pair),
            # so a reversed pair flags the OTHER line - possibly on another claim - which the signed rule never flags.
            # It used to be filed as a label difference ("direction") and passed the gate.
            out.append(f"pair reversed: the finding would sit on the {_s(dp.get('code_b')).upper()} line where the "
                       f"signed rule flags the {_s(gp.get('code_b')).upper()} line")
        if (dp.get("scope") or "member_provider_day") == "member_day" and \
                (gp.get("scope") or "member_provider_day") == "member_provider_day":
            out.append("pair scope member_day (any provider) where the signed rule is member_provider_day")
        if (schema.normalize_indicator(dp.get("modifier_indicator")) or "0") == "0" and \
                (schema.normalize_indicator(gp.get("modifier_indicator")) or "0") == "1":
            out.append("no modifier bypass where the signed rule allows one")
    elif dc - gc:
        out.append(f"codes {sorted(dc - gc)} are not in the signed rule"
                   + (" (the cap sums more codes)" if dt in _SUMS and dc > gc else ""))
    if dt == gt == "provider_type_allowed":
        # every type NOT in the list is flagged: a shorter list, or the other provider's type, flags more
        da, ga = provider_types(dp), provider_types(gp)
        if ga - da:
            out.append(f"allows only {sorted(da)}: the signed rule also allows {sorted(ga - da)}")
        if provider_role(dp) != provider_role(gp):
            out.append(f"checks the {provider_role(dp)} provider type where the signed rule checks the "
                       f"{provider_role(gp)}")
    dthr, gthr = schema.integral(dp.get("threshold")), schema.integral(gp.get("threshold"))
    if dthr is not None and gthr is not None and dthr < gthr:
        out.append(f"threshold {dthr} < signed {gthr}")
    dper, gper = dp.get("period"), gp.get("period")
    if dper != gper and (dper or gper):
        # a longer period accumulates more units (flags more); year vs benefit_year are misaligned windows
        if _PERIOD_RANK.get(dper, 9) >= _PERIOD_RANK.get(gper, 9):
            out.append(f"period {dper} vs signed {gper}")
    if gp.get("age") and not dp.get("age"):
        out.append("no age condition where the signed rule has one")
    elif gp.get("age") and dp.get("age"):
        (dlo, dhi), (glo, ghi) = _age_band(dp["age"]), _age_band(gp["age"])
        if dlo < glo or dhi > ghi:
            out.append(f"age band {dp['age']} is wider than signed {gp['age']}")
    if gpop not in _ALL_POP and dpop in _ALL_POP and not dp.get("age"):
        out.append(f"population 'all' where the signed rule is {gpop!r}")
    ge, de = _s(g.get("effective_date"))[:10], _s(d.get("effective_date"))[:10]
    gn, dn = _s(g.get("end_date"))[:10], _s(d.get("end_date"))[:10]
    if ge and (not de or de < ge):
        out.append(f"starts {de or 'at the beginning'} before the signed {ge}")
    if gn and (not dn or dn > gn):
        out.append(f"ends {dn or 'never'} after the signed {gn}")
    if gp.get("exception") and not dp.get("exception"):
        out.append("no exception label where the signed rule has one (findings would not be verify_exception)")
    if gp.get("discretionary") is True and dp.get("discretionary") is not True:
        out.append("no discretionary label where the signed rule has one")
    return out


def label_diffs(d: dict, g: dict) -> list[str]:
    """Differences that are NOT wider: labels the draft adds, narrower windows / scopes. (A pair's direction is not
    one of them since 2026-10-04, critic M51-5: a reversed pair flags another line - wider_reasons.)"""
    dp, gp = pred_of(d), pred_of(g)
    out = []
    for q in ("exception", "discretionary"):
        if bool(dp.get(q)) != bool(gp.get(q)):
            out.append(f"{q}: draft {dp.get(q)!r} vs signed {gp.get(q)!r}")
    for f in ("effective_date", "end_date"):
        if _s(d.get(f))[:10] != _s(g.get(f))[:10]:
            out.append(f"{f}: draft {_s(d.get(f)) or None} vs signed {_s(g.get(f)) or None}")
    if population(d) != population(g):
        out.append(f"population: draft {population(d)!r} vs signed {population(g)!r}")
    return out


# ------------------------------------------------------------------ gold builders
def _gold_row(gid, kind, chapter, pred, quote, *, doc_hash=None, key=None, pop="all", eff=None, end=None,
              reviewer=None, source=None) -> dict:
    return {"gold_id": gid, "kind": kind, "chapter": _s(chapter), "doc_hash": _s(doc_hash) or None,
            "extraction_key": _s(key) or None, "quote": _s(quote), "predicate": pred or {},
            "population": _s(pop) or "all", "effective_date": _s(eff) or None, "end_date": _s(end) or None,
            "reviewer": _s(reviewer) or None, "source": source}


_QUOTED = (re.compile(r'"([^"]{20,})"'), re.compile(r"'([^']{20,})'"))


def is_curated(r: dict) -> bool:
    """A rule written directly from the manual (origin 'manual', MAN- id; the workbook's 'hand-authored seed'), not
    proposed by the extraction model."""
    return _s(r.get("origin")).lower() == "manual" or _s(r.get("rule_id")).startswith("MAN-")


def curated_quote(r: dict) -> str:
    """The manual's words a curated rule rests on: its verbatim_quote, else the passages its notes quote (double quotes;
    single quotes in older rows). '' = it quotes nothing - such a gold row cannot be matched and is not scored."""
    if _s(r.get("verbatim_quote")):
        return _s(r.get("verbatim_quote"))
    text = _s(r.get("policy_text_and_notes")) or _s(r.get("notes"))
    for rx in _QUOTED:
        parts = rx.findall(text)
        if parts:
            return " ".join(parts)
    return ""


def _finish(out: list[dict], excl: dict) -> list[dict]:
    """Drop a REJECTED row that is the same rule (same chapter, same comparable predicate, overlapping quote) as a kept
    one: it was rejected as a duplicate, not as wrong, and as a negative it would make a correct draft look like a
    resurrected rejection (a false DANGER) whenever the matcher paired the draft with it instead of the kept rule."""
    kept = [g for g in out if g["kind"] != "negative"]
    res = []
    for g in out:
        c = canon(g["predicate"]) if g["kind"] == "negative" else None
        if c is not None and any(k["chapter"] == g["chapter"] and canon(k["predicate"]) == c
                                 and _quote_score(k["quote"], g["quote"], True) for k in kept):
            excl["reject_same_as_a_kept_rule"] += 1
            continue
        res.append(g)
    return res


def gold_from_state_rules(df, current_doc_hash: dict | None = None, require_reviewer: bool = True,
                          report: dict | None = None) -> list[dict]:
    """Signed decisions held in main.sedo.state_rules: approved extracted rows (their predicate is the corrected one
    when the reviewer fixed it) are positives, rejected rows negatives; approved CURATED rows (written from the manual,
    origin 'manual') are 'missed' - rules the extraction must learn to find - scored on the passages their notes quote.
    Rows of another document version are excluded when current_doc_hash {chapter: hash} is given."""
    report = report if report is not None else {}
    out, excl = [], defaultdict(int)
    for r in df.to_dict("records"):
        curated = is_curated(r)
        if _s(r.get("origin")) not in ("extracted", "") and not curated:
            continue
        st = _s(r.get("review_status"))
        if st not in ("approved", "rejected"):
            excl[f"status:{st or 'blank'}"] += 1
            continue
        if require_reviewer and not _s(r.get("reviewer")):
            excl["unsigned"] += 1
            continue
        ch = _s(r.get("chapter"))
        if not curated and current_doc_hash and _s(current_doc_hash.get(ch)) and \
                _s(r.get("doc_hash")) != _s(current_doc_hash.get(ch)):
            excl["other_doc_version"] += 1
            continue
        quote = curated_quote(r) if curated else r.get("verbatim_quote")
        if curated and not quote:
            excl["curated_without_quote"] += 1
            continue
        kind = "negative" if st == "rejected" else ("missed" if curated else "positive")
        out.append(_gold_row(_s(r.get("rule_id")), kind, ch, _obj(r.get("predicate")), quote,
                             doc_hash=r.get("doc_hash"), key=None if curated else r.get("extraction_key"),
                             pop=r.get("population"), eff=r.get("effective_date"), end=r.get("end_date"),
                             reviewer=r.get("reviewer"), source="state_rules"))
    out = _finish(out, excl)
    report["excluded"] = dict(excl)
    return out


def gold_from_review_log(log_df, state_rules_df, require_reviewer: bool = True, report: dict | None = None) -> list[dict]:
    """The LATEST applied decision per extraction_key in policy_review_log (approved / fixed / rejected), with the
    quote, chapter and document version from state_rules; a fix uses the log's corrected_predicate."""
    report = report if report is not None else {}
    rows = {(_s(r.get("extraction_key")) or _s(r.get("rule_id"))): r for r in state_rules_df.to_dict("records")}
    latest = {}
    for r in sorted(log_df.to_dict("records"), key=lambda x: _s(x.get("ingested_at"))):
        if _s(r.get("applied_outcome")) not in ("approved", "fixed", "rejected"):
            continue
        latest[_s(r.get("extraction_key")) or _s(r.get("rule_id"))] = r
    out, excl = [], defaultdict(int)
    for k, r in latest.items():
        sr = rows.get(k)
        if sr is None:
            excl["not_in_state_rules"] += 1
            continue
        if require_reviewer and not _s(r.get("reviewer")):
            excl["unsigned"] += 1
            continue
        outcome = _s(r.get("applied_outcome"))
        pred = _obj(r.get("corrected_predicate")) if outcome == "fixed" else _obj(sr.get("predicate"))
        out.append(_gold_row(_s(sr.get("rule_id")), "negative" if outcome == "rejected" else "positive",
                             sr.get("chapter"), pred or _obj(sr.get("predicate")), sr.get("verbatim_quote"),
                             doc_hash=r.get("doc_hash_reviewed") or sr.get("doc_hash"), key=sr.get("extraction_key"),
                             pop=sr.get("population"), eff=sr.get("effective_date"), end=sr.get("end_date"),
                             reviewer=r.get("reviewer"), source="policy_review_log"))
    out = _finish(out, excl)
    report["excluded"] = dict(excl)
    return out


def gold_from_workbook(path_or_sheets, require_reviewer: bool = True, include_missed: bool = True,
                       report: dict | None = None) -> list[dict]:
    """A filled review workbook (state_rules.export_review_workbook layout, or the consolidated AI pre-review
    workbook): sheet 1 = decisions (approve / fix / reject; fix needs corrected_predicate); an optional
    'missed_rules' sheet (chapter, verbatim, suggested_predicate) adds missed rules. require_reviewer=False scores
    UNSIGNED decisions (e.g. an AI pre-review) - label such a result as not signed.
    2026-10-04: a FIX is scored with its corrected dates / population (corrected_effective_date ...), not the draft's;
    a curated row (origin 'manual': written from the manual, the extraction missed it) is a 'missed' gold row scored on
    the passages its notes quote (it has no verbatim_quote of its own); a missed_rules row whose sentence a curated row
    already covers is not counted twice; a reject that duplicates a kept rule is not a negative (_finish)."""
    report = report if report is not None else {}
    if isinstance(path_or_sheets, dict):
        sheets = path_or_sheets
    else:
        import pandas as pd
        sheets = pd.read_excel(path_or_sheets, sheet_name=None, engine="openpyxl")
    names = list(sheets)
    review = sheets[names[0]]
    out, excl = [], defaultdict(int)
    for r in review.to_dict("records"):
        dec = _s(r.get("decision")).lower()
        if dec not in ("approve", "fix", "reject"):
            excl[f"decision:{dec or 'blank'}"] += 1
            continue
        if require_reviewer and not _s(r.get("reviewer")):
            excl["unsigned"] += 1
            continue
        corrected = lambda c, base: r.get(c) if (dec == "fix" and _s(r.get(c))) else r.get(base)
        if dec == "fix":
            # a Fix may correct only the window / population (corrected_predicate blank): the predicate stands
            pred = _obj(r.get("corrected_predicate")) if _s(r.get("corrected_predicate")) else None
            if pred is None and any(_s(r.get(c)) for c in ("corrected_effective_date", "corrected_end_date",
                                                            "corrected_population")):
                pred = _obj(r.get("predicate"))
            if not isinstance(pred, dict):
                excl["fix_without_predicate"] += 1
                continue
        else:
            pred = _obj(r.get("predicate"))
        curated = is_curated(r)
        quote = curated_quote(r) if curated else r.get("verbatim_quote")
        if curated and not quote:
            excl["curated_without_quote"] += 1
            continue
        kind = "negative" if dec == "reject" else ("missed" if curated else "positive")
        out.append(_gold_row(_s(r.get("rule_id")), kind, r.get("chapter"), pred, quote, doc_hash=r.get("doc_hash"),
                             key=None if curated else r.get("extraction_key"),
                             pop=corrected("corrected_population", "population"),
                             eff=_s(corrected("corrected_effective_date", "effective_date"))[:10] or None,
                             end=_s(corrected("corrected_end_date", "end_date"))[:10] or None,
                             reviewer=r.get("reviewer"), source="workbook"))
    if include_missed and "missed_rules" in sheets:
        curated_rows = [g for g in out if g["kind"] == "missed"]
        for i, r in enumerate(sheets["missed_rules"].to_dict("records")):
            pred = _obj(r.get("suggested_predicate"))
            if not _s(r.get("verbatim")):
                continue
            ch = _s(r.get("chapter"))
            if any(g["chapter"] == ch and _quote_score(g["quote"], _s(r.get("verbatim")), True) for g in curated_rows):
                excl["missed_rule_already_curated"] += 1
                continue
            out.append(_gold_row(f"MISSED-{ch}-{i:03d}", "missed", r.get("chapter"), pred,
                                 r.get("verbatim"), source="workbook:missed_rules"))
    out = _finish(out, excl)
    report["excluded"] = dict(excl)
    return out


def gold_from_review_json(rules: list[dict], reviews: list[dict], missed: list[dict] | None = None,
                          overrides: dict | None = None) -> list[dict]:
    """The AI pre-review JSON of the first run (rules.json + out_*.json 'reviews' / 'missed_rules'). NOT signed:
    use it to measure, never as the ship gate's signature."""
    rv = {x["rule_id"]: x for x in reviews}
    overrides = overrides or {}
    out = []
    for r in rules:
        x = rv.get(r["rule_id"])
        dec = overrides.get(r["rule_id"], (x or {}).get("decision"))
        if dec not in ("approve", "fix", "reject"):
            continue
        pred = _obj(x.get("corrected_predicate")) if dec == "fix" else _obj(r.get("predicate_obj") or r.get("predicate"))
        if not isinstance(pred, dict):
            continue
        import re as _re
        m = _re.search(r"Population: (.*?)\. Found by", r.get("policy_text") or "")
        out.append(_gold_row(r["rule_id"], "negative" if dec == "reject" else "positive", r["chapter"], pred,
                             r.get("verbatim_quote"), doc_hash=r.get("doc_hash"), key=r.get("extraction_key"),
                             pop=m.group(1) if m else "all", source="ai_prereview"))
    for i, m in enumerate(missed or []):
        out.append(_gold_row(f"MISSED-{m.get('chapter')}-{i:03d}", "missed", m.get("chapter"),
                             _obj(m.get("suggested_predicate")), m.get("verbatim"), source="ai_prereview:missed"))
    return out


# ------------------------------------------------------------------ matching
def _quote_score(gq: str, dq: str, missed: bool) -> float:
    a, b = pc.norm(gq), pc.norm(dq)
    if not a or not b:
        return 0.0
    if a in b or b in a:
        return 1.0
    r = difflib.SequenceMatcher(None, a, b).ratio()
    return r if r >= (0.80 if missed else 0.85) else 0.0


def _jaccard(g: dict, d: dict) -> float | None:
    """Code overlap; None = not comparable (an uncoded or not_checkable side) and therefore compatible."""
    gc, dc = codes_of(g), codes_of(d)
    if not gc or not dc or pred_of(g).get("type") == "not_checkable" or pred_of(d).get("type") == "not_checkable":
        return None
    return len(gc & dc) / len(gc | dc)


def _codes_compatible(g: dict, d: dict) -> tuple[bool, float]:
    """(compatible, jaccard). Compatible: either side uncoded / not_checkable, Jaccard >= 0.5, or one code set
    contains the other (a reviewer's fix often ADDS codes: 98960 -> 98960/98961/98962)."""
    j = _jaccard(g, d)
    if j is None:
        return True, 1.0
    gc, dc = codes_of(g), codes_of(d)
    return (j >= 0.5 or gc <= dc or dc <= gc), j


def match(gold: list[dict], drafts: list[dict]) -> list[dict]:
    cand = []
    for gi, g in enumerate(gold):
        for di, d in enumerate(drafts):
            if _s(g["chapter"]) != _s(d.get("chapter")):
                continue
            if g.get("extraction_key") and g["extraction_key"] == _s(d.get("extraction_key")):
                cand.append((10.0, gi, di, "key"))            # a key match always wins over any quote match
                continue
            q = _quote_score(g.get("quote") or "", d.get("verbatim_quote") or "", g["kind"] == "missed")
            if not q:
                continue
            ok, j = _codes_compatible(g, d)
            if not ok:
                continue
            same_type = pred_of(g).get("type") == pred_of(d).get("type")
            exact = canon(pred_of(g)) is not None and canon(pred_of(g)) == canon(pred_of(d))
            # quote first, then the same predicate type (the cap and the pair read from one sentence each find their
            # own signed rule), then the very same predicate (a kept reading beats a rejected alternative of the same
            # sentence - 2026-10-04: a tie went to the earlier gold row, so a correct draft could be scored as a
            # resurrected rejection), then code overlap
            cand.append((2.0 + q + (0.2 if same_type else 0.0) + (0.3 if exact else 0.0) + j / 10, gi, di, "quote"))
    cand.sort(key=lambda c: (-c[0], c[1], c[2]))
    g_used, d_used, pairs = {}, set(), []
    for score, gi, di, how in cand:
        if gi in g_used or di in d_used:
            continue
        g_used[gi] = di
        d_used.add(di)
        pairs.append({"gold": gi, "draft": di, "how": how, "score": round(score, 3)})
    for score, gi, di, how in cand:                       # extra drafts on a matched gold = duplicates
        # only a draft of the SAME predicate type is a second copy; another type from the same sentence is a
        # different rule ('unmatched')
        if di not in d_used and gi in g_used and pred_of(gold[gi]).get("type") == pred_of(drafts[di]).get("type"):
            d_used.add(di)
            pairs.append({"gold": gi, "draft": di, "how": "duplicate", "score": round(score, 3)})
    pairs += [{"gold": None, "draft": di, "how": "unmatched", "score": 0.0} for di in range(len(drafts)) if di not in d_used]
    pairs += [{"gold": gi, "draft": None, "how": "missing", "score": 0.0} for gi in range(len(gold)) if gi not in g_used]
    return pairs


# ------------------------------------------------------------------ compare
_INT_KEYS = ("gold_positive", "gold_negative", "drafts", "tp", "tp_positive", "tp_missed", "fn_positive", "fn_missed",
             "matched_reject", "reject_not_reproduced", "duplicate", "unmatched", "unmatched_compiled", "exact",
             "type_match", "label_diff", "danger", "danger_date_only", "lost_executable")


def _date_only(reasons: list[str]) -> bool:
    """DANGER only because the draft lacks the start / end date the decision carries. Such dates often come from a
    chapter's revision history or a dated notice, not from the sentence a draft quotes: the reviewer's decision must
    carry them (counted apart so a gate failure can be read; it is still DANGER)."""
    return bool(reasons) and all(r.startswith(("starts ", "ends ")) for r in reasons)


def compare(gold: list[dict], drafts: list[dict]) -> tuple[dict, list[dict]]:
    """(summary {"by_chapter": {ch: {...}}, "total": {...}}, detail rows). See the module docstring."""
    pairs = match(gold, drafts)
    by = defaultdict(lambda: {k: 0 for k in _INT_KEYS})
    detail = []
    for g in gold:
        by[_s(g["chapter"])]["gold_negative" if g["kind"] == "negative" else "gold_positive"] += 1
    for d in drafts:
        by[_s(d.get("chapter"))]["drafts"] += 1
    for pr in pairs:
        g = gold[pr["gold"]] if pr["gold"] is not None else None
        d = drafts[pr["draft"]] if pr["draft"] is not None else None
        ch = _s((g or d)["chapter"])
        s = by[ch]
        row = {"chapter": ch, "how": pr["how"], "score": pr["score"], "gold_id": g and g["gold_id"],
               "kind": g and g["kind"], "rule_id": d and d.get("rule_id"), "extraction_key": d and d.get("extraction_key"),
               "gold_predicate": json.dumps(pred_of(g)) if g else None,
               "draft_predicate": json.dumps(pred_of(d)) if d else None,
               "gold_quote": g and g.get("quote"), "draft_quote": d and d.get("verbatim_quote"),
               "exact": None, "danger": False, "danger_reasons": None, "label_diffs": None, "result": None}
        if pr["how"] in ("key", "quote"):
            reasons = wider_reasons(d, g)
            row["danger"] = bool(reasons)
            row["danger_reasons"] = "; ".join(reasons) or None
            s["danger"] += bool(reasons)
            s["danger_date_only"] += _date_only(reasons)
            if g["kind"] == "negative":
                s["matched_reject"] += 1
                row["result"] = "resurrected_reject" + (" (compiles)" if reasons else "")
            else:
                s["tp"] += 1
                s["tp_" + g["kind"]] += 1
                ex = canon(pred_of(d)) == canon(pred_of(g))
                row["exact"] = ex
                s["exact"] += ex
                s["type_match"] += pred_of(d).get("type") == pred_of(g).get("type")
                ld = label_diffs(d, g)
                row["label_diffs"] = "; ".join(ld) or None
                s["label_diff"] += bool(ld)
                s["lost_executable"] += compiles(pred_of(g), population(g)) and not compiles(pred_of(d), population(d))
                row["result"] = "exact" if ex else "changed"
        elif pr["how"] == "duplicate":
            # a second draft for one signed rule: if it is wider and a reviewer approves it, it flags more
            reasons = wider_reasons(d, g)
            same = canon(pred_of(d)) is not None and canon(pred_of(d)) == canon(pred_of(g))
            if reasons or same or g["kind"] == "negative":
                s["duplicate"] += 1
                row["danger"] = bool(reasons)
                s["danger"] += row["danger"]
                s["danger_date_only"] += _date_only(reasons)
                row["danger_reasons"] = ("; ".join(reasons) or None) if row["danger"] else None
                row["result"] = "duplicate"
            else:
                # 2026-10-04 (critic M51-5): a different reading of a signed rule's text (threshold 8 where 4 was
                # signed) is not a copy: approved, it compiles as a second rule nobody decided. Not wider, so not
                # DANGER - but unreviewed, so it counts in unmatched_compiled (and blocks) when it would compile. A
                # wider one stays DANGER above: one draft, one gate reason.
                s["unmatched"] += 1
                s["unmatched_compiled"] += compiles(pred_of(d), population(d))
                row["result"] = "unreviewed_variant"
        elif pr["how"] == "unmatched":
            s["unmatched"] += 1
            s["unmatched_compiled"] += compiles(pred_of(d), population(d))
            row["result"] = "unknown_new_rule"
        else:
            if g["kind"] == "negative":
                s["reject_not_reproduced"] += 1
                row["result"] = "reject_not_reproduced"
            else:
                s["fn_" + g["kind"]] += 1
                row["result"] = "missed_again"
        detail.append(row)
    for s in by.values():
        _rates(s)
    tot = {k: sum(s[k] for s in by.values()) for k in _INT_KEYS}
    _rates(tot)
    return {"by_chapter": {k: dict(v) for k, v in sorted(by.items())}, "total": tot}, detail


def _rates(s: dict) -> None:
    pos = s["gold_positive"]
    s["recall"] = round(s["tp"] / pos, 3) if pos else None
    s["recall_missed"] = (round(s["tp_missed"] / (s["tp_missed"] + s["fn_missed"]), 3)
                          if s["tp_missed"] + s["fn_missed"] else None)
    known = s["tp"] + s["matched_reject"] + s["duplicate"]
    s["precision_known"] = round(s["tp"] / known, 3) if known else None      # among drafts the gold can judge
    s["precision_lb"] = round(s["tp"] / s["drafts"], 3) if s["drafts"] else None   # unmatched counted as wrong
    s["exact_rate"] = round(s["exact"] / s["tp"], 3) if s["tp"] else None


def ship_gate(summary: dict) -> tuple[bool, str]:
    """The run may replace the current extraction only if no matched draft is wider than what was signed (DANGER == 0)
    AND every draft that would compile has a reviewed decision to be judged against (unmatched_compiled == 0).
    2026-10-04 (external review): a run whose NEW executable drafts nobody had reviewed passed - DANGER is measured only
    on drafts the gold matches, so an unreviewed draft that compiles is a risk the gate could not see. Adjudicating them
    (review workbook) turns them into gold; then the run is scored again."""
    t = summary["total"]
    n, u = int(t.get("danger") or 0), int(t.get("unmatched_compiled") or 0)
    why = []
    if n:
        k = t.get("danger_date_only", 0)
        why.append(f"{n} draft(s) would flag claims the signed rules do not (see detail.danger_reasons)"
                   + (f"; {k} of them only lack a start / end date the decision carries" if k else ""))
    if u:
        why.append(f"{u} new executable draft(s) have no reviewed decision: adjudicate them before this run replaces the "
                   f"current extraction (see detail: result unknown_new_rule / unreviewed_variant)")
    if why:
        return False, "BLOCKED: " + " | ".join(why)
    return True, ("OK: no draft is wider than the signed decisions (DANGER == 0) and every executable draft has a "
                  "reviewed decision")


def compare_runs(gold: list[dict], drafts_a: list[dict], drafts_b: list[dict] | None,
                 labels: tuple = ("A", "B"), gates: list | None = None) -> list[dict]:
    """A/B of two extraction runs on the SAME gold (e.g. reasoning_effort low vs medium): one row per run with its
    totals and its ship-gate verdict. Same gold, same matching - only the run differs, so the rows compare like for like
    (as long as both runs read the same documents: v05 checks their corpus_version). drafts_b None = one row (run A).
    gates: [(ok, why) per run] - each run's OWN ship gate, scored on ALL its chapters, to report instead of the gate of
    the drafts compared here. 2026-10-04 (critic M51-4): v05 compares only the chapters both runs extracted, and taking
    the gate of that comparison let a run with an unreviewed executable draft in a chapter the other run lacked pass;
    the comparison is a comparison, never the gate."""
    labels = list(labels) + ["A", "B"][len(labels):]
    rows = []
    for i, (label, drafts) in enumerate(zip(labels, (drafts_a, drafts_b))):
        if drafts is None:
            continue
        summ, _ = compare(gold, drafts)
        t = summ["total"]
        given = gates[i] if gates is not None and i < len(gates) else None
        ok, why = given if given is not None and given[0] is not None else ship_gate(summ)
        rows.append({"run": label, "drafts": t["drafts"], "recall": t["recall"], "recall_missed": t["recall_missed"],
                     "exact_rate": t["exact_rate"], "precision_known": t["precision_known"], "danger": t["danger"],
                     "danger_date_only": t["danger_date_only"], "unmatched_compiled": t["unmatched_compiled"],
                     "ship_gate": "OK" if ok else "BLOCKED", "ship_gate_reason": why})
    return rows


def summary_rows(summary: dict) -> list[dict]:
    """One row per chapter + a TOTAL row, for display / export."""
    rows = [{"chapter": ch, **v} for ch, v in summary["by_chapter"].items()]
    rows.append({"chapter": "TOTAL", **summary["total"]})
    return rows
