"""
rule_normalize.py  -  post-gate, pre-compile normalisation of rule dicts.

Runs on Rule.to_dict() output after validate_gate.gate(). Pure and idempotent.

  stable ids     rule_id is re-derived from CONTENT (origin, source, statement,
                 predicate, dates). The legacy assign_id() collided badly - one
                 id was shared by nine different Chapter 10 rules - which makes
                 policy_rules unusable as a keyed table.
  dedupe         identical content collapses to one row.
  plane          derived deterministically from predicate type; never hand-set,
                 never 'enforcement' (a claims outcome is not a policy plane).
  provenance     source_url / doc_hash filled for NCCI rows if missing.
  edit file      every NCCI coding edit gets predicate['ncci_edition'] = the edit file it comes from
                 (practitioner | outpatient | dme). WHICH claim lines take which file is decided per line
                 in the detection snapshot (ncci_routing.py: CMS TGM s6.0 Table 2, provider type x claim
                 form), so a rule is never copied per form and editions are never merged: a line takes
                 ONE edit file (TGM fn 19: the DME edits are identical inside the PRA and OPH files).
                 2026-10-03; before, rules were routed by claim form alone.
  window merge   overlapping rows of the SAME edition and pair / code collapse per exact date window to the
                 most permissive value, aggregating over ALL rows in force (C2-06).
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Iterable

import config

MEDICAID_NCCI_URL = ("https://www.cms.gov/medicare/coding-billing/"
                     "ncci-medicaid/medicaid-ncci-edit-files")

# ----------------------------------------------------------------- plane
_PLANE_BY_PREDICATE = {
    "code_pair_prohibited":   "coding_edit",
    "max_units_per_line":     "coding_edit",
    "max_units_per_dos":      "coding_edit",
    "max_units_per_day":      "coding_edit",
    "max_units_per_period":   "coverage_scope",
    "max_dollars_per_period": "coverage_scope",
    "frequency_limit":        "coverage_scope",
    "code_not_covered":       "coverage_scope",
}
_PLANE_BY_REASON = {
    "requires_medical_record":   "medical_necessity",
    "requires_member_attribute": "coverage_scope",
    "cross_source_conflict":     "coverage_scope",
    "ambiguous_source":          "coverage_scope",
}


def derive_plane(rule: dict) -> str:
    pred = rule.get("predicate") or {}
    t = pred.get("type")
    if t == "not_checkable":
        reason = pred.get("reason") or rule.get("not_checkable_reason")
        return _PLANE_BY_REASON.get(reason, "coverage_scope")
    return _PLANE_BY_PREDICATE.get(t, "coverage_scope")


# ------------------------------------------------------------- stable id
from schema import content_signature, stable_rule_id, PLANES  # noqa: E402

# C2-03: an MUE run's later_max_threshold / removed_later describe LATER quarters. They change
# whenever a new quarter is loaded, so they are left out of the id: an unchanged run must keep
# its rule_id across quarters (D8) or its old findings orphan.
ID_VOLATILE_PREDICATE_KEYS = ("later_max_threshold", "removed_later")


def id_basis(rule: dict) -> dict:
    p = rule.get("predicate") or {}
    if not any(k in p for k in ID_VOLATILE_PREDICATE_KEYS):
        return rule
    d = dict(rule)
    d["predicate"] = {k: v for k, v in p.items() if k not in ID_VOLATILE_PREDICATE_KEYS}
    return d


def rule_id_for(rule: dict) -> str:
    return stable_rule_id(id_basis(rule))


# ------------------------------------------------------------ provenance
def enrich_provenance(rule: dict) -> dict:
    if rule.get("origin") != "ncci":
        return rule
    if not rule.get("source_url"):
        rule["source_url"] = MEDICAID_NCCI_URL
    if not rule.get("doc_hash"):
        rule["doc_hash"] = content_signature(rule)[:16]
    return rule


# ------------------------------------------------------------ edit-file routing
# C2-01/C2-02 (VERIFIED, CMS 2026 Medicaid NCCI Technical Guidance Manual s5.2, s6.0 Table 2, App. B): the
# PRA file applies to practitioners and ASCs, the OPH file to outpatient hospitals, the DME file to DME
# suppliers - by PROVIDER TYPE and claim form - and NCCI never applies to dental, pharmacy, inpatient or
# residential claims. The old collapse merged all three editions onto every claim: OPH-only pairs and MUEs
# fired on professional claims and the most-permissive merge threw away PRA hard denials and lower PRA MUEs.
# Since 2026-10-03 the routing is per LINE (snapshot column pie_ncci_edition, ncci_routing.py); a rule only
# carries its own edition.
_CANONICAL_EDITIONS = ("practitioner", "outpatient", "dme")


_MUE_TYPES = {"max_units_per_line", "max_units_per_dos", "max_units_per_day"}
_COLLAPSE_LABELS = ("ncci_editions_agree", "ncci_editions_disagree:most_permissive", "single_edition_segment")


def _kind(r: dict) -> str | None:
    """'ptp' | 'mue' for an NCCI coding edit (the rules routed to an edit file), else None."""
    if r.get("origin") != "ncci":
        return None
    t = (r.get("predicate") or {}).get("type")
    return "ptp" if t == "code_pair_prohibited" else "mue" if t in _MUE_TYPES else None


def _int(v) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return int(float(v))


def _value(r: dict, kind: str):
    p = r.get("predicate") or {}
    if kind == "ptp":
        return "1" if str(p.get("modifier_indicator", "0")).strip() in ("1", "1.0") else "0"
    return _int(p.get("threshold", 0))


def _agg(kind: str, vals):
    """Most permissive: PTP '1' if ANY rule allows a bypass; MUE the maximum."""
    vals = list(vals)
    return ("1" if "1" in vals else "0") if kind == "ptp" else max(vals)


def _member_editions(r: dict, kind: str) -> dict:
    p = r.get("predicate") or {}
    eds = p.get("editions")
    if isinstance(eds, dict) and eds:
        return {str(k): ("1" if str(v) == "1" else "0") if kind == "ptp" else _int(v) for k, v in eds.items()}
    return {str(p.get("service_category")): _value(r, kind)}


def _edition_label(eds) -> str:
    return "+".join(eds)


def _statement(kind: str, eds, p: dict) -> str:
    """Same wording as ingest_ncci_tables, naming EVERY contributing edition (C2-25)."""
    ed = _edition_label(eds)
    if kind == "ptp":
        return (f"NCCI PTP ({ed}): {p.get('code_b')} should not be reported with {p.get('code_a')} "
                f"for the same member, provider and date of service "
                f"(modifier indicator {p.get('modifier_indicator')}).")
    per = {"max_units_per_dos": "per date of service", "max_units_per_day": "per day"}.get(p.get("type"),
                                                                                         "per claim line")
    return f"NCCI MUE ({ed}): {p.get('code')} maximum {p.get('threshold')} unit(s) {per}."


def _source_doc(kind: str, eds) -> str:
    return (f"CMS Medicaid NCCI PTP edits ({_edition_label(eds)})" if kind == "ptp"
            else f"CMS Medicaid NCCI MUE values ({_edition_label(eds)})")


def _ordered_editions(eds) -> list[str]:
    return [e for e in _CANONICAL_EDITIONS if e in eds] + sorted(e for e in eds if e not in _CANONICAL_EDITIONS)


def _legacy_members(r: dict, kind: str) -> list[dict]:
    """A collapsed row from an older build (service_category 'ncci' + editions) mixes editions: rebuild one
    member per edition so each runs on its own lines. Any other rule is its own single member."""
    p = r.get("predicate") or {}
    eds = p.get("editions")
    if str(p.get("service_category")) != "ncci" or not isinstance(eds, dict) or not eds:
        return [r]
    out = []
    for ed, v in eds.items():
        q = {k: x for k, x in p.items() if k != "editions"}
        q["service_category"] = ed
        if kind == "ptp":
            q["modifier_indicator"] = "1" if str(v) == "1" else "0"
        else:
            q["threshold"] = _int(v)
        m = dict(r)
        m["predicate"] = q
        m["statement"] = _statement(kind, [ed], q)
        m["source_doc"] = _source_doc(kind, [ed])
        out.append(m)
    return out


def _open_ended(r: dict) -> dict:
    """C2-23: an end date on or after 9999-12-30 means 'no end'."""
    try:
        e = _d(r.get("end_date"), None)
    except ValueError:          # not ISO: left as is; detector_gen turns it into a lead with the reason
        return r
    if e is not None and e >= _OPEN_END:
        r = dict(r)
        r["end_date"] = None
    return r


def route_ncci_rules(rules: list[dict], form_editions: dict | None = None) -> tuple[list[dict], dict]:
    """Give every NCCI coding edit (PTP / MUE) predicate['ncci_edition'] = the edit file it comes from (its
    service_category). One rule per edition row - never copied per form, never merged across editions: which
    lines take which file is decided per line (ncci_routing). A rule whose edition is not practitioner /
    outpatient / dme is not emitted: it is counted (ncci_rules_no_edition) with a few examples. Idempotent;
    non-NCCI rules pass through. (`form_editions` is accepted for old callers and ignored.)"""
    out: list[dict] = []
    per_ed = {e: 0 for e in _CANONICAL_EDITIONS}
    no_ed: list[dict] = []
    n_in = 0
    for r in rules:
        kind = _kind(r)
        if kind is None:
            out.append(r)
            continue
        n_in += 1
        r = _open_ended(r)
        for m in _legacy_members(r, kind):
            p = dict(m.get("predicate") or {})
            ed = str(p.get("ncci_edition") or p.get("service_category") or "").strip().lower()
            if ed not in _CANONICAL_EDITIONS:
                no_ed.append(m)            # counted per edition: nothing leaves without a trace
                continue
            p["ncci_edition"] = ed
            p.pop("form_typ", None)        # routing by form alone ended 2026-10-03
            if isinstance(p.get("editions"), dict):
                p["editions"] = dict(p["editions"])
            if kind == "mue":
                # contract with the detector: every MUE says whether a later quarter relaxed it
                p.setdefault("later_max_threshold", None)
                p.setdefault("removed_later", False)
            c = dict(m)
            c["predicate"] = p
            out.append(c)
            per_ed[ed] += 1
    examples = []
    for r in no_ed[:5]:
        p = r.get("predicate") or {}
        examples.append(f"{r.get('rule_id') or '?'} {p.get('type')} {r.get('codes') or ''} "
                        f"service_category={p.get('service_category')!r}")
    report = {
        "ncci_rules_routed_in": n_in,
        "ncci_rules_by_edition": per_ed,
        "ncci_rules_no_edition": len(no_ed),
        "ncci_no_edition_examples": examples,
    }
    return out, report


# ------------------------------------------------- cross-edition collapse
# NCCI publishes practitioner / outpatient / dme editions separately, and in this
# claims table all three land on FORM_TYP 'A' (form cannot tell them apart). So a
# code that appears in >1 edition would otherwise produce multiple detectors on the
# same 'A' claims, and the stricter one would false-positive the other edition's
# claims. We collapse per (predicate shape + codes + EXACT date window) to the MOST
# PERMISSIVE limit:
#   MUE  -> the maximum threshold  (a finding then violates every edition)
#   PTP  -> indicator 1 if any edition allows a bypass, else 0
# The per-edition values are kept in predicate['editions'] and the note, for audit.
# C2-02 CORRECTION (2026-10-02): the premise above was wrong - editions apply by provider type and claim form
# (CMS TGM s6.0 Table 2), and merging PRA with OPH discarded PRA hard denials and lower PRA MUEs. Since
# 2026-10-03 the EDITION is part of the key: only rows of the same edit file are ever merged (overlapping
# windows / quarters of one file), still to the most permissive value; each line takes one file (ncci_routing).
#
# The date window is PART OF THE KEY (fix, 2026-09-20). Two rules collapse only when
# they cover the SAME effective/end window. This is the guard against the P0 that
# reviewers found: keying by (type, code) alone also merged different TEMPORAL runs
# of the SAME edition — e.g. code A at 2 units Jan-Mar and 4 units Apr-onward would
# collapse to "4 units from Jan", so a February 3-unit claim wrongly passed. It also
# stops the unsafe window-widening (applying a threshold during dates it never held).
# Editions that genuinely share a window still collapse (the intended dedup); editions
# with different windows stay as separate, correctly-windowed detectors. Whether the
# MOST-PERMISSIVE default is right at all is a separate (open) decision; this only
# guarantees the collapse never fabricates or destroys a temporal run.
#
# D3 (2026-09-29): the PTP key is DIRECTIONAL. Column One/Column Two order is the edit:
# CMS denies the Column Two code. Sorting the pair merged A/B (indicator 1) with B/A
# (indicator 0) into one direction, silently losing a hard denial.
# D4 (2026-09-29): editions whose windows OVERLAP without being identical (practitioner
# 4 units from 2020, outpatient 1 unit from 2023) used to compile as two detectors, so
# the STRICTER limit fired from 2023 with no flag - the opposite of the stated policy.
# Now each group is split into elementary date intervals and collapsed per interval.
# (Since C2-02 that example is two edit files, never merged; the same split applies within one file.)
# C2-06: the value of an interval is aggregated over ALL rules in force in it. It used to come
# from a {edition: value} dict, so two overlapping rows of the SAME edition overwrote each other
# and the later (possibly stricter) row won, labelled 'ncci_editions_agree'.
_MIN, _MAX = date.min, date.max
# C2-23: _bounds used to add a day to 9999-12-31 (OverflowError); such ends are open-ended
_OPEN_END = date(9999, 12, 30)


def _group_key(r: dict):
    if r.get("origin") != "ncci":
        return None
    p = r.get("predicate") or {}
    t = p.get("type")
    if t == "code_pair_prohibited":
        return ("ptp", str(p.get("code_a")).upper(), str(p.get("code_b")).upper())
    if t in _MUE_TYPES:
        return (t, str(p.get("code")).upper())
    return None


def _edition_key(r: dict):
    """Kept for callers/tests: the group key plus the rule's own window."""
    k = _group_key(r)
    return None if k is None else k + ((r.get("effective_date"), r.get("end_date")),)


def _d(s, default):
    if s is None or (isinstance(s, float) and s != s):
        return default
    txt = str(s).strip()[:10]
    if txt.lower() in ("", "nan", "nat", "none"):
        return default
    return date.fromisoformat(txt)


def _bounds(r: dict) -> tuple[date, date]:
    """[start, end_exclusive). An end on or after 9999-12-30 is open-ended (C2-23)."""
    end = _d(r.get("end_date"), None)
    hi = _MAX if end is None or end >= _OPEN_END else end + timedelta(days=1)
    return _d(r.get("effective_date"), _MIN), hi


def _join(values) -> str:
    return "; ".join(dict.fromkeys(str(v) for v in values if v not in (None, "")))


def _merge_segment(kind: str, edition, act: list[dict], lo: date, hi: date) -> dict:
    """One elementary window of an (edition, pair|code) group -> one rule, most permissive over ALL
    rules in force in it (C2-06), citing every contributing edition (C2-25)."""
    vals = [_value(m, kind) for m in act]
    chosen = _agg(kind, vals)
    base = act[vals.index(chosen)]
    by_ed: dict[str, list] = {}
    for m in act:
        for ed, v in _member_editions(m, kind).items():
            by_ed.setdefault(ed, []).append(v)
    per_ed = {ed: _agg(kind, vs) for ed, vs in by_ed.items()}
    eds = _ordered_editions(per_ed)

    p = dict(base.get("predicate") or {})
    p["modifier_indicator" if kind == "ptp" else "threshold"] = chosen
    p["service_category"] = eds[0] if len(eds) == 1 else "ncci"
    p["editions"] = {ed: per_ed[ed] for ed in eds}
    if edition is not None:
        p["ncci_edition"] = edition
    if kind == "mue":
        # C2-03 aggregated the permissive way: a finding is 'verify' if ANY contributing edition was
        # raised (to the highest later value) or dropped later
        later = [_int(m["predicate"]["later_max_threshold"]) for m in act
                 if (m.get("predicate") or {}).get("later_max_threshold") is not None]
        p["later_max_threshold"] = max(later) if later else None
        p["removed_later"] = any(bool((m.get("predicate") or {}).get("removed_later")) for m in act)

    w = dict(base)
    w["predicate"] = p
    w["effective_date"] = None if lo == _MIN else lo.isoformat()
    w["end_date"] = None if hi == _MAX else (hi - timedelta(days=1)).isoformat()
    w["statement"] = _statement(kind, eds, p)
    w["source_doc"] = _source_doc(kind, eds)
    # citations in the same edition order as the statement (C2-25)
    rank = {e: i for i, e in enumerate(eds)}
    cited = sorted(act, key=lambda m: min(rank.get(e, len(rank)) for e in _member_editions(m, kind)))
    w["doc_version"] = _join(m.get("doc_version") for m in cited)
    w["doc_hash"] = _join(m.get("doc_hash") for m in cited)
    w["source_url"] = _join(m.get("source_url") for m in cited)

    bits = ", ".join(f"{ed}={per_ed[ed]}" for ed in eds)
    on_form = f" in the {edition} file" if edition is not None else ""
    what = "most-permissive indicator kept" if kind == "ptp" else "maximum (most-permissive) threshold kept"
    cross = len(set(per_ed.values())) > 1
    internal = {ed: sorted(set(map(str, vs))) for ed, vs in by_ed.items() if len(set(vs)) > 1}
    if len(eds) == 1:
        label = "single_edition_segment"
        head = (f"Overlapping {eds[0]} rows merged{on_form} ({bits}); {what}." if len(act) > 1 else
                f"Window clipped where another NCCI rule for the same {'pair' if kind == 'ptp' else 'code'}"
                f"{on_form} starts or ends; one edition in force ({bits}).")
    else:
        label = "ncci_editions_disagree:most_permissive" if cross else "ncci_editions_agree"
        head = f"Collapsed across NCCI editions{on_form} ({bits}); {what}."
        if any(_bounds(m) != (lo, hi) for m in act):
            head += " Window split where editions overlap."
    member_notes = list(dict.fromkeys(m.get("notes") for m in act if m.get("notes")))
    w["notes"] = (head + (" " + " | ".join(member_notes) if member_notes else "")).strip()

    amb = [m.get("ambiguity_note") for m in act if m.get("ambiguity_note")]
    if cross:
        amb.append(f"NCCI editions disagree{on_form} ({bits}); using most permissive.")
    for ed, vs in internal.items():
        amb.append(f"Overlapping {ed} rows disagree ({', '.join(vs)}); using most permissive.")
    w["ambiguity_flag"] = bool(cross or internal or any(m.get("ambiguity_flag") for m in act))
    w["ambiguity_note"] = " ".join(dict.fromkeys(amb)) or None
    # keep labels the members carried (e.g. 'ccmi_changed_across_quarters'); the collapse label is
    # first so prefix readers (registers: startswith('ncci_editions_disagree')) keep working
    other = [x for m in act for x in str(m.get("reconciliation") or "").split(";")
             if x and x not in _COLLAPSE_LABELS]
    w["reconciliation"] = ";".join([label] + list(dict.fromkeys(other)))
    # most permissive also for the switches: a deactivated or uncheckable rule in force here means
    # this window is not enforced at all
    if any(bool(m.get("deactivated")) for m in act):
        w["deactivated"] = True
    if not all(m.get("machine_checkable", True) for m in act):
        w["machine_checkable"] = False
        w["not_checkable_reason"] = next((m.get("not_checkable_reason") for m in act
                                          if m.get("not_checkable_reason")), None)
    if w["ambiguity_flag"] and w.get("validation_status") in ("clean", "patched"):
        w["validation_status"] = "needs_review"      # same rule the gate applies to ambiguous rules
    return w


def collapse_ncci_editions(rules: list[dict], report: dict | None = None) -> tuple[list[dict], int]:
    groups: dict = {}
    out: list[dict] = []
    for r in rules:
        k = _group_key(r)
        if k is None:
            out.append(r)
            continue
        edition = (r.get("predicate") or {}).get("ncci_edition")
        groups.setdefault((edition,) + k, []).append(r)
    collapsed = 0
    labels: dict[str, int] = {}
    empty = 0
    for gk, members in groups.items():
        edition, k = gk[0], gk[1:]
        if len(members) == 1:
            out.append(members[0])
            continue
        kind = "ptp" if k[0] == "ptp" else "mue"
        spans = [_bounds(m) for m in members]
        cuts = sorted({b for s in spans for b in s})
        segs: list[list] = []                     # [lo, hi, active_idx_tuple]
        for lo, hi in zip(cuts, cuts[1:]):
            active = tuple(i for i, (a, b) in enumerate(spans) if a <= lo and b >= hi)
            if not active:
                continue
            if segs and segs[-1][1] == lo and segs[-1][2] == active:
                segs[-1][1] = hi                  # same members active: extend
            else:
                segs.append([lo, hi, active])
        # a rule whose window is empty (deleted before it took effect) is in force on no date
        empty += len(members) - len({i for _, _, act in segs for i in act})
        emitted = 0
        for lo, hi, active in segs:
            act = [members[i] for i in active]
            if len(act) == 1 and _bounds(act[0]) == (lo, hi):
                out.append(act[0]); emitted += 1
                continue
            w = _merge_segment(kind, edition, act, lo, hi)
            lab = w["reconciliation"].split(";")[0]
            labels[lab] = labels.get(lab, 0) + 1
            out.append(w); emitted += 1
        collapsed += len(members) - emitted
    if report is not None:
        report.update(ncci_collapse_labels=labels, ncci_empty_window_rules=empty)
    return out, collapsed


# --------------------------------------------- state duplicates (seed vs extracted)
# The 21 hand-authored seeds and approved extracted rules often state the SAME policy
# (Ch10 CHW pairs, 11975 not covered). Both compiled, so one paid line produced two
# identical findings and double-counted its dollars. Same meaning = same predicate
# (minus routing labels) + codes + population + window. Keep ONE: an approved extracted
# rule (it carries the verbatim quote, page and doc_hash) over a hand-authored seed.
_ROUTING_KEYS = {"service_category", "editions"}


def _state_key(r: dict):
    # only executable, coded rules: two uncoded leads with the same reason are DIFFERENT policy text
    if r.get("origin") == "ncci" or not r.get("machine_checkable", True) or not r.get("codes"):
        return None
    if (r.get("predicate") or {}).get("type") == "not_checkable":
        return None
    p = {k: v for k, v in (r.get("predicate") or {}).items() if k not in _ROUTING_KEYS}
    if p.get("type") == "code_pair_prohibited":
        # compare what COMPILES: the compiler defaults scope and indicator, so the key must too
        from detector_gen import pair_scope
        p["scope"] = pair_scope(r)
        p["modifier_indicator"] = str(p.get("modifier_indicator", "0"))
    import json as _json

    def _d(v):                       # pandas NaN != NaN would make identical rules look different
        return None if v is None or (isinstance(v, float) and v != v) or v == "" else str(v)[:10]
    return (_json.dumps(p, sort_keys=True, default=str), tuple(sorted(str(c).upper() for c in r.get("codes") or [])),
            (r.get("population") or "all").lower(), _d(r.get("effective_date")), _d(r.get("end_date")))


def collapse_state_duplicates(rules: list[dict]) -> tuple[list[dict], int]:
    rank = {"extracted": 0, "manual": 1}
    groups: dict = {}
    out = []
    for r in rules:
        k = _state_key(r)
        (groups.setdefault(k, []).append(r) if k is not None else out.append(r))
    dropped = 0
    for members in groups.values():
        members = sorted(members, key=lambda m: rank.get(m.get("origin"), 2))
        keep = dict(members[0])
        if len(members) > 1:
            gone = [stable_rule_id(m) for m in members[1:]]
            keep["supersedes"] = sorted(set((keep.get("supersedes") or []) + gone))
            keep["reconciliation"] = f"state_duplicate_collapsed:{len(gone)}"
            keep["notes"] = ((keep.get("notes") or "") + f" Supersedes {len(gone)} identical rule(s): {', '.join(gone)}.").strip()
            dropped += len(gone)
        out.append(keep)
    return out, dropped


# ---------------------------------------------------------- orchestrator
def normalize_rules(rules: Iterable[dict], collapse_editions: bool = True) -> tuple[list[dict], dict]:
    rules = [dict(r) for r in rules]
    dropped_enforcement = sum(1 for r in rules
                              if r.get("plane") == "enforcement" or (r.get("predicate") or {}).get("type") == "edit_failure")
    rules = [r for r in rules
             if not (r.get("plane") == "enforcement" or (r.get("predicate") or {}).get("type") == "edit_failure")]
    # every NCCI rule carries its own edit file BEFORE collapsing, so editions never merge (lines are routed to
    # one file each in the snapshot - ncci_routing). Always on: an NCCI rule without an edition never compiles.
    rules, route_report = route_ncci_rules(rules)
    editions_collapsed = 0
    collapse_report: dict = {}
    if collapse_editions:
        rules, editions_collapsed = collapse_ncci_editions(rules, report=collapse_report)
    rules, state_dupes = collapse_state_duplicates(rules)

    out: dict[str, dict] = {}
    collapsed = 0
    id_changed = 0
    for r in rules:
        r = dict(r)
        new_id = rule_id_for(r)
        if r.get("rule_id") != new_id:
            id_changed += 1
        r["rule_id"] = new_id
        r["plane"] = derive_plane(r)
        r = enrich_provenance(r)
        if new_id in out:
            collapsed += 1
            continue
        out[new_id] = r

    rows = list(out.values())
    planes: dict[str, int] = {}
    by_ed: dict[str, int] = {}
    for r in rows:
        planes[r["plane"]] = planes.get(r["plane"], 0) + 1
        e = (r.get("predicate") or {}).get("ncci_edition")
        if _kind(r) and e:
            by_ed[e] = by_ed.get(e, 0) + 1
    report = {
        "rules_out": len(rows),
        "enforcement_rows_dropped": dropped_enforcement,
        "ncci_editions_collapsed": editions_collapsed,
        "state_duplicates_collapsed": state_dupes,
        "duplicate_content_collapsed": collapsed,
        "rule_ids_rederived": id_changed,
        "plane_counts": planes,
        **route_report,
        **collapse_report,
        "ncci_rules_out_by_edition": by_ed,
    }
    return rows, report
