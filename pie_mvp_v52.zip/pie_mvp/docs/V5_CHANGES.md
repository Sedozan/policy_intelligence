# PIE v5 — what changed, and how we know the queries are right (2026-10-03)

## v5.2 (2026-10-04) — the AHCCCS rule tables (Same Day Disallow, daily limits, B2 matrix)

**Why.** AHCCCS publishes some billing rules as data, not prose. SB sent the three workbooks (Same Day Disallow
10/1/2026, HCPCS/CPT daily limits 9/14/26, B2 matrix 10/1/26). They are read by a deterministic reader (`ahcccs_tables.py`,
notebook `00b`), never by the model; every rule cites its sheet and cell or row; each file is a dated version.

**SB's decisions (2026-10-04)** — the readings in `reference/ahcccs_table_readings.csv`, signed before anything compiles:
D = the two codes never on one member-day (any provider), A* = not from the same provider, A = allowed; the ROW code's
line is the finding, table note 2 makes it `verify_exception`; a version judges claims from its date to the day before
the next version (older claims wait for AHCCCS's earlier versions); a daily maximum = units per member + provider + day;
B2 = the complete provider list for the H0xxx / H2xxx codes.

**Independent critic, then fixes (every one verified before accepting; precision first; each a reading SB signs):**

| critic finding (verified) | fix |
|---|---|
| F1 P0: B2 on the billing type flags every behavioral-health line a GROUP (01) bills - 01 bills in the claims, no B2 list names it | provider role `billing_or_rendering`: a group's line is judged on its rendering (servicing) type |
| F2 P0: the daily maximum read as units cannot fit anesthesia (FFS Ch10: "Every 15 minutes or any portion thereof is equal to one unit"; 272 of 274 anesthesia codes have a maximum of 1-2) | anesthesia codes and all-nines maxima (999 on 113 codes, 999999) are recorded, not compiled; listed for SB |
| F3 P0: no service end date in the claims - a multi-day per-diem line puts all its units on its begin date | a daily-cap group over the cap because ONE line alone is over it is `verify_span` (every state daily cap) |
| F4 P1: pairs the table disallows both ways (104) flag both lines; dollars counted twice | `both_ways` on the rule and in the finding text; 08 reports the dollars counted twice |
| F5 P1: "same provider" for A* - AHCCCS corrected its own A* programming in 2026 (memo 3/16/2026); the legend says "(service site or residential placement)" | `member_servicing_billing_day`: the same servicing AND billing provider id - a finding breaks the rule under either reading (some misses); SB to settle |
| F6 P1: a trailing column whose header is not a bare code was dropped silently | the reader refuses any content right of a table's last known column |
| F7 P1: 07 trusted the catalog tables - rows edited there changed rules silently | 00b logs each version's row count and rows hash; 07 stops when the tables no longer match (and the e2e proves it) |
| F8 P2: signatures not bound to the config they describe | readings carry `binds` (e.g. `AHCCCS_SAME_PROVIDER_SCOPE=...`); a changed value un-signs the reading; the readings file's sha256 is in the build log |
| F9 / F10 / F12 P2: v03 counted table rules as unsigned; coverage counted a 10/1/2026 rule for all older dollars (gap table empty); a stale table never warned | sign-off bar reads the readings; coverage counts only the dollars dated inside each rule's window (in Spark); 01 / 07 warn past `AHCCCS_TABLE_MAX_AGE_DAYS` |
| F15 P2: bilateral / repeat modifiers on a daily cap | `verify_modifier` (after `verify_pa` and `verify_span`) |
| F11, F16, F17, F18 | stable table rule ids across versions; a byte-order mark in the readings CSV is read; 00b says which folders it skipped; table rules left out of the overlap register |

**Also found by the independent oracle** (written from the spec alone): a cell or daily code twice in one version, or a
row without its code, built two rules / a rule for no code when a table was edited in the catalog - now refused; a
lower-case Frequency Cd was not a day limit - now upper-cased. And by the lead: two per-provider daily groups that
differ only in billing provider shared a `finding_id` - findings now carry `billing_provider`.

**Verification (final code, after the re-check below):** offline suite 716 passed; Spark SQL tests 94 passed (every
table statement multiset-equal to the per-rule SQL on random claims, incl. the new scope, role and labels); the
independent oracles (spec v2.6) agree with the SQL exactly, 0 mismatches — at 3x on v2.6: general oracle 48 rounds /
62,358 claim rows / 2,356 queries / 7,011 findings, table oracle 60 rounds / 2,412 table rules / 14,878 findings (21
planted oracle defects all caught); after the payable-lines change (N4): general default 2,610 findings, table oracle at
3x 8,015 findings (50,777 claim rows, 2,412 rules), both re-run by Claude on the final code (52 + 74 tests passed); the
end-to-end run of every notebook passes all 160 checks, including 00b loading 4 versions twice, the readings gate (as
shipped: nothing builds; partly signed: those tables only), each planted table violation and trap, and a table edited in
the catalog stopping 07. On the real files (no claims scope): 486 pair rules (208 both-ways), 15,190 daily rules, 32 B2
rules.

**The critic's re-check of the fixes** (on a fresh copy): 13 FIXED, 4 PARTIAL, F13 left to SB (whether the note-2
exception also qualifies behavioral-health daily caps). New points, each verified and handled: N1 a reading could keep
its signature after its binds cell was cleared → `REQUIRED_BINDS` (a reading must bind every config value its words
describe); N2 lines the v2.6 readings cannot judge (no billing provider id; a group's line with no rendering type) were
not counted → counted in 01 (data shape) and in every run log, and 01 check T now shows what B2 would flag in the claims
before anyone signs; N3 `verify_span` also labels an ordinary one-line overuse (FFS Ch5 field 24G: a date's units on one
line) → stated in the reading and the spec (a label, never a dropped finding; an end date in the extract would narrow
it); N4 the span / modifier labels read cancelled lines → payable lines only (spec §3, both oracles updated, 0
mismatches); N5 08's "counted twice" used another base than its summary → per member-day over distinct lines: AHCCCS
keeps one code's lines, so at most (lines − the cheapest code's lines) is at risk; N6 a group type spelled '001' would
not read as 01 (not seen in the claims' codes; noted).

**SQL that changed for existing rules:** every state daily cap (the label CASE: re-validate in v06); nothing else
outside the AHCCCS statements. **Still with SB:** sign the readings (5 carry choices made after the review); which line
AHCCCS denies in a both-ways pair; servicing vs billing for "same provider"; H0035 (Ch19: B2 / the matrix: B6); AHCCCS's
earlier table versions; the 43 places the tables disagree with the reviewed rules (`ahcccs_tables_review_v52.xlsx`).

## v5.1 (2026-10-04) — the external review, two critics, and one engine in the KB

**Why.** SB gave v5 to ChatGPT for a second opinion on how far the extracted rules can be trusted. Its points were
checked against the code and the sources before anything changed; most held. Its conclusion is also ours: the SQL is
tested against a written contract (oracle, mutation testing), but whether the rules say what the policy says, and
whether any were missed, is only measured by people (v01, v05, v07). Until those numbers say GO, PIE is a rule-discovery
and SME-review workbench, not a validated, complete extraction of AHCCCS policy.

| review point | verified? | what changed |
|---|---|---|
| recall counted every draft as found (wrong ones raised it) | yes (quality.py) | recall = real rules found ÷ (found + missed); executable-rule precision (real AND faithful among rules that compile); filter loss (DROPPED sheet); pass marks on the LOWER 95% bound: precision ≥ 0.95, recall ≥ 0.90, fidelity ≥ 0.95 (v01 / v03) |
| the regression gate passed a run with never-reviewed executable rules | yes (regress.ship_gate) | gate = DANGER 0 AND no unadjudicated executable draft; A/B mode (`RUN_DIR_B`) for reasoning low vs medium |
| "AHCCCS policy" overstates the corpus | yes (the FFS page lists chapters AND exhibits; the coding-resources page publishes the Same Day Disallow table etc.) | 5 rule-bearing FFS exhibits added (36 files); `corpus_version` on builds, metrics and runs; `config.CORPUS_PENDING` lists what is not loaded (Same Day Disallow, daily limits, B2 matrix, PA guidelines, OPFS modifiers, CBHSG, RISSNET NCCI files) |
| NCCI count = edits executable against these claims, not the CMS set | yes (07 scopes to paid codes) | build log keeps each CMS file's size next to the scoped count (`ncci_source_vs_claims_scope`, `ncci_rules_scope`) |
| unknown provider types guessed by claim form | yes | default `NCCI_UNMAPPED_PROVIDER_TYPE = "none"` |
| 100% signed routing for observed provider types | not enforced | 08 runs NCCI only when every provider type on the claims' CMS-1500 / UB-04 lines has a signed row (`NCCI_REQUIRE_SIGNED_ROUTING`); every NCCI finding carries `ncci_routing`; a held-back run is `partial_run`; 01 lists the codes to sign |
| PDF layout / table attribution unverified | yes | `page_fidelity.py` + `v07_page_fidelity`: what a person sees on a page vs what reaches the extractor; it found 4 reader defects, fixed |
| states must adjudicate with RISSNET files | yes (CMS 2026 TGM) | stated in README / spec; NCCI findings are leads until AHCCCS provides them |

**Critics on these changes** (two agents that had not written them; every finding reproduced by a test that failed
first, then fixed; each fix planted back and caught):
- **Measurement (M51, 11 findings):** v01 sampled rows an older engine left in `state_rules` → v01 now samples the latest
  run's own drafts (new table `policy_extraction_drafts`, written by 05); pooled rates let small clean strata outvote big
  ones (178/180 pooled said GO, weighted lower bound 0.925) → every rate is stratum-weighted (`quality.stratified_ratio`);
  v03 judged metrics of any population or corpus → each metric row carries `population` and `corpus_version` and v03
  judges only the engine's own sample of the current corpus, drawn from the chapters' latest runs (`sample_runs`: a newer run makes it NOT YET until v01 is re-exported); v05's A/B narrowed run A's gate to shared chapters → each run
  gated on all its chapters; a reversed code pair was a "label difference" though its finding lands on the other line →
  DANGER, and a different unreviewed reading of a signed rule counts as unreviewed; blank scores shrank the denominator
  → NOT YET above 10% unscored; decimals truncated → whole numbers only; v03's run and routing bars aligned with 08.
- **PDF reader (P51, 10 findings):** a heading right under a table was swallowed; footers with a code-shaped token
  ("Phoenix, AZ 85034") were no longer stripped; tables placed by height went under the wrong heading on two-column
  pages; a period after a LONE code fused two sentences ("... billed for T1016." + "T1017, T1019 and H2014 are limited
  to two units" gave all four codes the 4-unit cap); merged rows and column rules swallowed headings; wrapped bullets
  cut their code list; numbers-only differences stripped limits as "headers"; v07 accepted duplicate pages and mixed
  corpora and did not weight documents by length. All fixed; on the fixture chapter and the critics' ordinary test pages the sections are identical to v5.

**One engine in the KB (SB, fresh start).** Hand-authored rules are a checklist v05 scores runs against — never sent
for review, never compiled (`COMPILE_HAND_AUTHORED = False`). An extracted rule compiles only when the last run that
produced it used prompt v2 (`KB_PROMPT_VERSIONS`); a decided rule the new run produces again keeps its decision and
names the new run. The build log lists what was left out (`engine_excluded`).

**Found by the end-to-end run:** 08 crashed on a first run in which NCCI was held back for unsigned routing (the findings
table did not exist yet) — fixed; 08 now creates it empty with its fixed types.

**Baseline the fresh run must beat (re-scored with the stricter v05):** the first model run (prompt v1, 242 drafts)
against the v5 workbook: 81 of 210 kept rules exact (38.6%; was 86 — five per-diem / S9484-S9485 pairs are REVERSED
relative to the reviewed rule, which the old scoring called exact), 0 of 111 missed or hand-written rules found, 30 DANGER
(9 only lack a start date), 2 executable drafts nobody reviewed → BLOCKED.

**Evening update (BProv_Type):** the claims carry the billing provider type, so (1) the NCCI edit file is now picked by
the BILLING provider type — CMS applies NCCI to "claims ... from" a type of provider (TGM §5.3) — and (2) "must be billed
only by these provider types" compiles: H0035 partial hospitalization is the first such query. The review workbook is
**v5**; the numbers below are after v5. What changed with it is marked *(BProv)*.

The question behind this round: **are the detection queries right, and would we know if one were wrong?**

Method, in order: four independent critics (C1 SQL detectors, C2 NCCI federal edits, C3 chapter extraction, C4
governance) → four implementers fixed what they found → an independent **oracle** (agent O) re-computed the expected
findings from the written definition alone (`docs/QUERY_SEMANTICS.md`), never from the SQL → a **policy re-read**
(agent P) of every compiled AHCCCS rule against the live PDFs, then of the 59 hand-authored rules and their dates
(agent S; every source it relied on re-checked by Claude) → a **full simulation** of the next real run (06 → 07 →
08 → v06 on local Spark 4, with the 242 real extracted rules and the hand-authored rules) → **mutation testing**
(realistic bugs planted one at a time; the tests must catch each).

## 1. The numbers

| | |
|---|---|
| Queries after the v5 review workbook is signed | **61** per-rule state queries + **2** NCCI statements (all PTP pairs, all MUEs) = **63 finding queries**; **4** rolling-window signal queries (not findings); **67** stored statements, plus the snapshot statement (v4: 60 + 2 + 4 = 66) |
| State queries by type | 49 code pairs · 5 not covered · 4 period caps · 1 per-provider-day cap · 1 per-member-day cap · **1 provider type allowed** (H0035, *BProv*) |
| State queries by origin | 20 from the model's extraction · 41 from hand-authored rules (each with a verbatim quote and page; they need a signature like any other rule) |
| Dates | 52 of the 61 state queries start on a date taken from the manual's revision history or a dated AHCCCS notice; 9 long-standing rules judge every date of service |
| Scenario tests in the validation pack | 599, all PASS (local simulation, `query_validation_pack_SIMULATED_v5.xlsx`; v4: 579) |
| Independent oracle | spec v2.3, final code: 70 claim sets, 644 queries, 2,184 findings (573 provider-type), 94 signal rows — equal, field by field; larger run in §6 |
| Tests | offline (no Spark) · Spark 4 (same engine as Databricks 17.3, ANSI on) · oracle · end-to-end run of every notebook — see §6 |

Where the queries live (Databricks, `main.policy_kb`): `policy_detectors` (`sql`, `sql_sha256`, `signal_sql`,
`signal_sql_sha256`), `policy_batch_detectors` (the 2 NCCI statements) with their data in `policy_ncci_ptp_edits` /
`policy_ncci_mue_limits`; every build in the `*_history` tables. The validator's workbook: v06 writes
`data/validation/query_validation_pack_<build>.xlsx` (plain English, SQL, scenario results per query); decisions go to
`policy_query_validation`, scenario results to `policy_query_validation_tests`, runs to `policy_detector_runs`.

## 2. What changed in the queries

1. **NCCI edit file by provider type × claim form** (CMS 2026 Medicaid NCCI Technical Guidance Manual §6.0 Table 2).
   Each line takes ONE file — practitioner, outpatient hospital or DME — from the **SProv_Type code** (the description
   is display-only) and FORM_TYP, through `reference/ncci_provider_type_routing.csv` (140 AHCCCS provider types,
   status *proposed*: it is a policy reading and must be signed). Editions are never merged. Dental, pharmacy,
   inpatient and long-term-care forms take no file (TGM §5.2). CMS's two *optional* rows are off by default.
   Before: the edit file was guessed from the claim form, and editions were merged per code.
   Checked against the claims (SB's query, 2026-10-03: 79 distinct SProv_Type codes + NULL): every description matches
   the mapping's source; 5 codes were missing (CF counseling-only facility, CH CHW organization, ES / HA / HO H2O
   housing) and would have fallen back to the practitioner file on a CMS-1500 — added. Column `in_claims_2026_10_03`
   marks the 79 rows a reviewer must sign (the other 61 do not occur in the claims). Of the 79: 25 practitioner, 1 ASC,
   4 hospital, 2 DME, 2 testing (optional), 19 other outpatient (optional: clinics, FQHCs, BH clinics, home health,
   hospice, transport), 26 no NCCI. NULL routes by claim form.
2. **Snapshot** (what every query reads): codes and modifiers trimmed and upper-cased; exact duplicate rows once; blank
   member / provider / PA treated as missing; a reversal row's units always count as negative (oracle R-01); a $0 line
   never counts toward a limit; a line and the reversal that cancels it are never findings.
3. **Pairs**: one finding per Column Two line; NCCI always same provider; Column One must be payable; the full CMS
   modifier logic (24/25/57 on E&M codes only; same anatomic modifier on both lines does not bypass unless
   58/59/78/79/X{EPSU}); evidence distinct and in numeric line order **whatever type the claims table gives LN_NO**
   (new today: a text LN_NO sorted `C1:12` before `C1:3`).
4. **Labels**: PA on file → `verify_pa` (never suppressed) for state rules; NCCI ignores PA and says so
   (`pa_present` NULL = not evaluated); stated exception → `verify_exception`; "may" → `discretionary`; a later CMS
   quarter that raised an MUE → `verify_mue_changed_later`; Column One itself denied → `verify_col1_not_payable`.
5. **Rolling-window signals** for period limits (your boss's question about the October reset): written to
   `policy_utilization_signals`, never findings.
6. **Every signed state rule compiles** (`STATE_RULES_CLAIMS_SCOPE = False`), whether or not this month's claims
   contain its code.
7. *(BProv)* **The billing provider type picks the NCCI row.** `NCCI_ROUTE_BY = "billing_provider_type"`: the BProv_Type
   code picks the Table 2 row; when it is missing or not in the table, SProv_Type does; then the claim form. The
   servicing type says whether a rendering practitioner is identified (an individual practitioner type, not group ID
   01) — it only changes the optional "other providers" row on a CMS-1500. Effect: a hospital billing a physician's
   service takes the outpatient file even on a CMS-1500; an FQHC / clinic / BH clinic billing takes none while CMS's
   optional rows are off. The TGM never says "billing" in so many words; it says "claims ... from" a type of provider,
   which is the provider that submits the claim. `"provider_type"` restores routing by the servicing type.
8. *(BProv)* **Dentists (07) are physician practitioners** (TGM Table 2 footnote 14): a dentist's CMS-1500 (oral surgery,
   E/M) takes the practitioner file; dental claims none. Dental hygienists (54) stay without NCCI.
9. *(BProv)* **Provider-type rules compile** (`provider_type_allowed`): a payable line of the code(s) whose billing (or,
   if the rule says so, servicing) provider type is known and not in the list → `provider_type_not_allowed`. A line with
   no type is never a finding. H0035: B2, B5, 02, 71 from 2024-07-08. A0110 (public transportation passes) is off: the
   manual says the eligible types "include" a list.
10. *(BProv)* **Points the oracle found loose, now fixed in code and spec (QUERY_SEMANTICS v2.3):** the text NONE / NAN /
   NULL in a provider type column is missing, not a code (a provider-type rule would have flagged it); which of two rows
   of one claim line a reversal cancels is now defined (it was arbitrary, so a re-run could flag the other row); a
   state-rule finding is never split by edit file; one-line findings' units are stated.
11. *(BProv)* **A real defect the simulation found:** with 140 provider types inlined into every comparison, the
   snapshot's generated code passed Spark's 64 KB limit; Spark silently falls back to slow interpreted execution. The
   codes are now cleaned once per line and the edit file computed from the cleaned columns (01, 07 and the gap report
   use the same `routed_sql`). Tests, the simulation and the end-to-end run now set `spark.sql.codegen.fallback =
   false`, so a query too big to compile fails them instead of slowing production.

## 3. Governance

- A decided rule changes only with `reopen = yes` and a reviewer's name, on the document version reviewed; the previous
  decision is kept. An approval records the predicate it signed (`approved_predicate_sha256`).
- Hand-authored rules no longer compile unsigned (`COMPILE_LEGACY_SEEDS = False`).
- 08 runs nothing unless the build is complete and **every** stored statement still has, and matches, its sha256
  (new today: a blank hash used to switch the check off). The checks moved to `run_guard.py` and are tested.
- **New today — the validator's decision is binding:** a query marked PROBLEM in v06 for its current SQL is not run;
  `config.RUN_ONLY_VALIDATED_QUERIES = True` runs only queries signed OK. Every finding carries `query_validation`
  (`OK` / `not_validated`), so validating a sample first is honest about the rest.

## 4. Critic findings — disposition

Every finding was re-checked against the code; IDs are cited in code comments next to each fix.

| critic | fixed | by redesign | open / accepted limit |
|---|---|---|---|
| C1 SQL (22) | 01–14, 16–20 | 15 (form switch → edit-file routing), 21 (tests now run on Spark 4 + the oracle, not SQLite) | 22 local-only (pyarrow absent; fallback used) |
| C2 NCCI (25 + 12 confirmed correct) | 01–03, 05–08, 10–12, 14–21, 23–25 | 09 (same as C1-02) | **04** a multi-day line is not divided by days (no service end date column) · **13** Arizona's own MUE deactivations are not applied · **22** MUE compares paid, not billed, units (missed, never false) |
| C3 extraction (20) | 01–12, 14–20 (prompt v2 + `post_checks.py`) | — | **13** recall: 75 missed rules logged; 40 now hand-authored with quotes |
| C4 governance (19) | 01–06, 08, 09, 11–19 | 07 (mutation survivors → oracle + new tests, §5) | **10** partly: the review log now records rule_id and extraction_key; extraction_key is the reliable join from a finding to its review |
| O oracle | R-01 reversal sign; F-01 evidence lost a NULL line; F-02 NCCI `pa_present` 0 → NULL; F-03 stray NCCI scope; F-04 `code` ignored next to `code_set` | S-01…S-06 ambiguities written into QUERY_SEMANTICS v2 | — |
| S hand-authored rules re-read (59 rules: 18 agree, 40 disagree, 1 cannot verify) | workbook **v4**: the S5151/T1016 pairs, H2025–27 and the per-diem pairs start when their Ch.19 sections were added (07/08/2024; 09/15/2026); the 23 S5151 pairs flag the S5151 line; S5150 600 h from 2021-10-01 (720 h in the COVID years); CHW 24/month and the same-day bar from 2024-07-17 (60 in 30 days, combinations allowed in 2023); A0382/A0398/A0422 off (per-trip limit; the manual's Example 3 is legal) | — | real start dates where only a conservative one is given (CHW change date; S5151/T1016 in the CBHSG before 07/08/2024); 99070 |
| O2 oracle, spec v2.2 → v2.3 (*BProv*; written again from the spec alone) | F-05 (a state pair split one line by edit file) → spec v2.3; S07/S08 textual nulls → code + spec; cancellation ties → deterministic order (code + spec); KNOWN type, units of one-line findings, 1–4 character list entries → spec | A13–A24 readings, all confirmed by the SQL | — |
| P policy re-read (21 rules: 9 agree, 11 disagree, 1 cannot verify) | in workbook v3: S9484/S9485 direction; 4 per-diem pairs narrowed to same provider (discretionary kept); H2025–27 narrowed to same provider; A0422 per provider with its exception; T2023 and H0044 effective 2024-10-01; CHW caps' statement carries the PA sentence | CHW PA carve-out: handled by `verify_pa` (a PA on file is never a plain violation) instead of an exception | 99070 (Ch10 p.47 unreadable by the tool — SME to read); Ch19 effective dates (SME) |

## 5. Mutation testing

One realistic defect at a time is planted in a fresh copy of the code (a `>` that becomes `>=`, a dropped filter, a
swapped pair, a modifier missing from a list, a window shifted by a day, a skipped hash check, a pack that accepts a
broken query...). The suite — offline tests, then the oracle, then the Spark tests — must fail on each.

| run | mutants | caught | by | not caught → fixed |
|---|---|---|---|---|
| red team, 2026-10-02 (agent R, before the oracle joined the suite; interrupted) | 91 | 68 | — | 23 survived → all 23 planted again below (Q12 and Q59 as M15 and M16) |
| v5 query semantics (M01–M26) | 26 | **26** | offline 10 · oracle 16 | — |
| the 23 red-team survivors + the v5 changes + the governance guards | 37 | **36** | offline 14 · oracle 19 · Spark 3 | Q34 (batch pair joined the Column Two line across edit files when both files are in the edit table) → new Spark test, verified to fail on the mutant |
| *(BProv)* billing-type routing, the identified rule, the dentist row, `provider_type_allowed`, textual nulls, the linear clean-up, the raw-table path, the cancellation order (B01–B16) | 17 | **16** | offline 5 · oracle 11 | B16 (cancellation by line number as TEXT: the oracle's line numbers are integers, so text order never differed) → new Spark test with a text LN_NO, verified to fail on the mutant |

Along the way the mutants exposed four blind spots, each closed with a test that fails on the planted defect:
a modifier dropped from the CMS lists (Q25–Q27: random claims rarely draw `XU` or `91`; now every CMS modifier is
tested one by one, the lists typed from CMS rather than imported from the code); the validation pack's own judge
(P01–P02: a query that fails to run, or flags too much, could PASS); 08's hash and build checks (R01–R03, now in
`run_guard.py`); the reopen guard (G07, G12). Two real defects were found the same way: with LN_NO held as text, evidence
sorted `C1:12` before `C1:3` (Q67c); and the review workbook and the validation pack were staged through a temp file
named only after the workbook, shared by every process on the machine, so two exports at the same moment (two
notebooks on one cluster driver) could copy each other's file — seen when two mutation runs collided. Both fixed and
pinned by tests.

## 6. Verification status

| check | result (2026-10-03, final code) |
|---|---|
| Offline tests (no Spark) | 459 passed (plus the oracle's pure-Python self-checks) |
| Spark 4 SQL tests (the Databricks 17.3 engine, ANSI on, **generated code that does not compile = failure**) | 72 passed |
| Independent oracle vs the SQL, spec v2.3, final code | default: 43 passed — 70 claim sets, 644 queries, 2,184 findings (573 provider-type), 94 signal rows, equal. Larger: 63 passed — 170 claim sets (45,420 rows), 1,566 queries, 5,398 findings (1,465 provider-type), 211 signal rows, equal; 0 known deviations |
| Simulation of the next run: real notebooks 01 → 02 → 06 → 07 → 08 → v06, the 242 real extracted rules + 59 hand-authored ones, signed as v5 proposes (after v1, and fresh — same result), strict codegen | ALL CHECKS PASSED: 61 state + 2 NCCI + 4 signal queries; every planted case behaves (dates, lines, holds, billing-type routing, H0035, A0110 off); pack: 67 queries, 599 scenarios, all PASS |
| End to end: every notebook, demos and validation notebooks, local Spark 4, strict codegen | ALL CHECKS PASSED (118 checks) — including a half-written build refused, a PROBLEM query not run, and a hospital-billed physician line kept off the practitioner file |
| Not verified | Databricks itself; the routing table against your real BProv_Type values (01 shows them and warns on unknown codes); LN_NO / date_of_birth types; precision on real claims (needs investigators' dispositions, v02) |

**Verification, v5.1 (2026-10-04, final code):**

| check | result |
|---|---|
| Offline tests (no Spark) | 571 passed |
| Spark 4 SQL tests (strict codegen) | 76 passed |
| Independent oracle vs the SQL, spec v2.4 | 46 passed (default scale), 0 deviations |
| End to end: every notebook, demos and validation notebooks, local Spark 4 | ALL CHECKS PASSED (129 checks) — new: NCCI held back on the unsigned table (state rules still run, the run marked partial), run on a signed copy with `ncci_routing = signed` on every NCCI finding; no hand-authored rule compiles; every draft of both extraction runs kept; v01 samples the latest run's own drafts with population and corpus_version |
| Simulation, the v5 rule set (242 v1-run rules + 59 hand-authored, `PKB_COMPILE_HAND_AUTHORED=1`, `PKB_KB_PROMPT_VERSIONS=any`) | ALL CHECKS PASSED (107 checks): NCCI not run on the unsigned table, then run on a signed copy; 61 state + 2 NCCI + 4 signal queries; pack 67 queries, 599 scenarios, all PASS (the SQL did not change) |
| Mutation checks of this round | signed-routing gate 6/6, PDF reader 6/6 + 19/19 (critic fixes), measurement 26/26, one-engine rule 5/5 caught |

## 7. Still needs a person

1. Sign the provider-type routing table (01 lists every billing × servicing provider type combination in the claims with
   the file its lines take). **Since v5.1, 08 does not run NCCI until every provider type code on the claims'
   CMS-1500 / UB-04 lines has a signed row** (status `signed` + a reviewer's name in
   `reference/ncci_provider_type_routing.csv`). All 70 BProv_Type codes in the claims (SB, 2026-10-04) are in it — column
   `billing_in_claims_2026_10_04`; by Table 2 row: 23 practitioner (incl. 01 group ID, which only bills, and 07 dentist),
   4 hospital, 1 ASC, 2 DME, 2 testing (optional), 17 other outpatient (optional), 21 no NCCI. 80 rows matter: the 79
   servicing codes plus 01.
2. Sign the v5 review workbook (decisions are AI pre-review; nothing compiles until a named person signs). Watch the
   dates: a rule without a start date judges every date of service (9 of the 60 after v4); where a rule is newer than
   the oldest claims, choose Fix and set `corrected_effective_date` (the v06 pack's `dates_covered` column says which
   dates each query judges). Where only a conservative date is given (CHW change; S5151/T1016 before 07/08/2024), an SME
   may give the real one.
3. Validate the queries (v06 pack) — a sample first is fine: findings say which queries were validated.
4. Decide CMS's optional NCCI rows (testing facilities; other outpatient providers incl. FQHCs, clinics) — off. With
   billing-type routing these rows now cover every line an FQHC, clinic or BH clinic bills.
4b. A0110: is the "include" list of provider types complete? If yes, approve it (it compiles as a provider-type query).
4c. Re-extract before signing — SB's direction 2026-10-04: a FRESH start, only rules from one engine version in the KB;
   the hand-written rules leave it and serve only as a test checklist. The engine now produces 34 of the 41 hand-written
   queries itself (all 21 S5151 and 13 T1016 pairs, after fixing a sentence split at the manual's stray periods inside the
   S5151 list); S9484 and J1055 depend on the model; 5 are interpretations it cannot and should not produce (S5150 2,400
   units, H2016/S9485 + S5151, 99213 + 99238/99239). The 242 drafts under review come from the FIRST model run (prompt v1); prompt
   v2 and the post-checks have only been replayed on that run's answers. Run 03 → 04 → 05 on all chapters, then v05 with
   `GOLD_SOURCE = "workbook"`, the v5 workbook and `REQUIRE_SIGNATURE = False` (AI pre-review, not signed). v05 now scores
   the curated rules as rules to find (a run that finds one can retire it) and Fixes with their corrected dates.
   Baseline the new run must beat — the first run against the same key, re-scored with v5.1's stricter v05: 81 of 210
   kept rules exact (38.6%); 0 of 111 missed or curated rules found; 30 DANGER (9 only lack a start date taken from a
   revision history; 5 pairs are reversed); 2 executable drafts nobody reviewed. Gate: BLOCKED.
   v5.1 enforces the direction in 07: only rules from prompt-v2 runs compile, the hand-written rules never do.
5. Attach AHCCCS's Same Day Disallow Table (xlsx, 10/01/2026): the largest state rule source not yet loaded.
6. Confirm: EVENT_PA_NO = an approved PA; all_data_C_A is FFS only; LN_NO's type; paid units ≤ billed units.
