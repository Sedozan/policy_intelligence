# What every PIE query does — the precise definition

*Version 2.6 (2026-10-04): NCCI edit file per line by provider type × claim form; reversal units; evidence rules; PA
"not evaluated". Changes from version 1 are marked **(v2)**; **(v2.1)** = evidence order whatever the line-number type,
validator decisions binding in 08, MUE units stated; **(v2.2)** = the BILLING provider type picks the Table 2 row
(the servicing type says whether a rendering practitioner is identified), dentists are physician practitioners, and
the provider-type rule (`provider_type_allowed`); **(v2.3)** = points the independent oracle found loose in v2.2: the
cancellation order of rows of one claim line, the edit file never splits a state-rule finding, what "known" provider
type means, and the units columns of one-line findings; **(v2.4)** = a line whose provider types are both unknown takes
no NCCI file by default (external review); **(v2.5)** = the AHCCCS rule tables (Same Day Disallow, daily limits, B2
matrix) as rules and three table-driven statements (§2b), and the `scope` of a daily cap; **(v2.6)** = after the
independent critic of v5.2: the scope `member_servicing_billing_day`, the provider role `billing_or_rendering`, the
daily-cap labels `verify_span` / `verify_modifier`, and the table readings that use them (§2b).*

This is the contract every detector query must meet. It is written in plain terms so a reviewer can check a
query against it, and it is precise enough that an independent program can compute the expected findings from
the same claims without reading the SQL (that is how the queries are tested — see "How this is verified").

## 1. Which claim lines a query sees (the detection snapshot)

Every query reads one table, the detection snapshot, rebuilt from the claims table at the start of each run.

| Step | Rule |
|---|---|
| Clean-up | Procedure code, modifiers and claim form: spaces trimmed, upper-cased. Member, providers, PA number: spaces trimmed. A blank modifier / PA number / member / provider counts as empty (NULL). **(v2)** Servicing provider type code: trimmed, upper-cased, a lone digit zero-padded (`8` → `08`), a whole number written with decimals read as the number (`8.0` → `08`); blank = missing. **(v2.2)** The billing provider type code (BProv_Type) the same way. **(v2.3)** For both provider type codes the text `NONE`, `NAN` or `NULL` (any case, after trimming) is also missing — what an export writes for an empty cell; no AHCCCS provider type is spelled that way. |
| Duplicates | Rows identical in every column the snapshot keeps are kept once (the place-of-service column is not kept, so two rows differing only in it are one row). |
| Dropped | Rows with no member, no date of service, or no procedure code. |
| Date of birth | Read as a date; anything that does not read as a date is treated as missing. |
| Reversal row | A row with paid amount < 0. **(v2)** Its units are counted as NEGATIVE whatever sign the claims table gives them (units = −\|units\|): a money-back row never adds units. |
| Cancelled line | A row with paid amount > 0 that a reversal row exactly offsets: same member, servicing provider, date, code and the four modifiers (a missing value matching a missing value), units = −(reversal units, as counted above) and paid = −(reversal paid). One reversal cancels one line; when several identical lines exist, the first ones by (claim id, line NUMBER) are cancelled, missing values first. **(v2.3)** Rows of one claim line that tie on both (a data-quality case: the same line booked twice with, say, different billing types) are ordered by claim form, PA number, servicing provider type, billing provider type, billing provider id and date of birth (cleaned values, ascending, missing first), so the same claims always give the same findings. |
| Payable line | paid > 0, units > 0 (or units missing), and not cancelled. |
| Counted row | paid ≠ 0 — the rows whose units count toward a daily or period limit. A reversal row (negative) therefore nets out the line it reverses, and a $0 line (denied or bundled when it was adjudicated) does not count. |
| NCCI edit file **(v2)** | Each line takes at most ONE Medicaid NCCI edit file — practitioner (PRA), outpatient hospital (OPH) or DME — from CMS 2026 Medicaid NCCI Technical Guidance Manual §6.0 Table 2, by provider type and claim form (see §1a). Claim forms other than A and O (dental, pharmacy, inpatient, long-term care) take none. |

### 1a. The edit file a line takes (v2, v2.2)
Provider type codes are looked up in `reference/ncci_provider_type_routing.csv`, which maps every AHCCCS provider type
(140, including all 79 servicing codes in all_data_C_A on 2026-10-03) to one Table 2 row. One code list serves the
billing and the servicing provider alike.

**(v2.2) Which provider.** CMS requires the methodologies for "claims ... from the following types of providers"
(TGM §5.3) and makes them optional for "claims from other types of providers of outpatient services" — FQHCs, RHCs,
community mental health centers (§5.5). So the **billing provider type** (the provider that submits the claim) picks
the row:
1. the billing type code, when it is in the table;
2. otherwise the servicing type code, when it is in the table;
3. otherwise none of them: **(v2.4)** no file (`config.NCCI_UNMAPPED_PROVIDER_TYPE = "none"`, the default since
   2026-10-04: a precision-first release does not guess the edit file); `"form"` = form A → practitioner, form O →
   outpatient (the default until v2.3).

**(v2.2) Rendering practitioner identified** (Table 2's CMS-1500 column) = the line's **servicing** type code is an
individual practitioner: a code in the `practitioner` row other than `01` (a group billing ID is not a person). A
missing or other servicing type = not identified.

| Table 2 row (category) | CMS | form A, rendering identified | form A, not identified | form O (UB-04) |
|---|---|---|---|---|
| Physician / Nonphysician Practitioner (`practitioner`) — incl. dentists **(v2.2, footnote 14)** | mandatory | practitioner | practitioner | outpatient |
| Ambulatory Surgical Center (`asc`) | mandatory | practitioner | practitioner | practitioner |
| Outpatient Services in Hospitals (`outpatient_hospital`) | mandatory | outpatient | outpatient | outpatient |
| Durable/Home Medical Equipment (`dme`) | mandatory | dme | dme | dme |
| Nonhospital-Based Testing Facilities (`testing_facility`) | optional | practitioner | practitioner | practitioner |
| Other Providers of Outpatient Services (`other_outpatient`) | optional | practitioner | outpatient | outpatient |
| (`not_applicable`: dental hygiene, pharmacy, residential, LTC/HCBS, housing, administrative) | — | none | none | none |

- An optional row takes its file only when switched on (`config.NCCI_OPTIONAL_CATEGORIES_ON`); otherwise none.
- `config.NCCI_ROUTE_BY = "provider_type"`: the servicing type picks the row (the billing type is ignored); steps 2–3
  and the identified rule as above. `"form"` ignores provider types: form A → practitioner, form O → outpatient.
- Dental claims (form D) take no file whatever the provider (§5.2).

## 2. The finding queries

Common to all: a rule's own date window is applied to the date of service (effective date and end date both
included); an age condition is tested on the date of service (age ≥ *min* means the date of service is on or
after the birthday at that age; age < *below* means before it; month arithmetic as in Spark `ADD_MONTHS`, so a
29 February birthday falls on 28 February in non-leap years); a line with no usable date of birth never matches
an age condition. **(v2)** An NCCI rule applies only to lines that take ITS edit file (§1a); state rules apply to
every line.

### Code pair (`code_pair_prohibited`: code_a, code_b)
- A finding is a **payable code_b line** for which at least one other **payable code_a line** exists with the same
  member and date of service — and, when the scope is `member_provider_day` (always for NCCI; the default for state
  rules), the same servicing provider (a missing provider never matches); **(v2.6)** when the scope is
  `member_servicing_billing_day`, the same servicing provider AND the same billing provider id (a missing id of
  either never matches). **(v2)** For NCCI both lines must take the
  rule's edit file, and the scope is always `member_provider_day` whatever the rule says. The rule's window and age
  condition are tested on the code_b (finding) line.
- Two different lines of the same claim can form a pair; a line never pairs with itself (same claim id and line
  number, a missing value matching a missing value).
- Modifier indicator `0`: nothing bypasses the pair. Indicator `1`: the pair is bypassed when either line carries
  an NCCI-associated modifier — the anatomic modifiers (E1–E4, FA, F1–F9, TA, T1–T9, LT, RT, LC, LD, RC, LM, RI),
  58, 78, 79, 27, 59, 91, XE, XS, XP, XU, and 24 / 25 / 57 only when that line's code is an E&M code (five digits in
  99202–99499 or 92002–92014) — **except** that it is NOT bypassed when the same anatomic modifier is on both lines
  and neither line has 58, 59, 78, 79, XE, XP, XS or XU.
- One finding per (rule, code_b line). A line is its (claim id, line number): rows of the snapshot that share them but
  differ only in PA number, units, modifiers or provider types are one finding (`pa_present` = 1 if any of them has a
  PA); rows that also differ in paid amount or claim form are separate findings (oracle S-06, a data-quality edge
  case). **(v2.3)** The edit file never splits a finding: an NCCI rule only sees lines of its own edit file, and a
  state rule ignores edit files (v2.2 listed the edit file here; oracle F-05 showed it only ever mattered for state
  rules, where it made two findings of one line).
  **(v2)** Evidence = the matching code_a lines as "claim:line", distinct,
  ordered by claim id then line NUMBER (**(v2.1)** also when the claims table holds line numbers as text: `C1:3`
  before `C1:12`), missing values first, a missing claim id or line number written as empty (`C1:` — never dropped);
  Column One = the first of them. Dollars: paid_amt = paid_at_risk = the code_b line's paid amount.

### Units on one line (`max_units_per_line`: code, threshold) — the NCCI MUE
- A finding is each payable line of the code with units > threshold. Units on different lines are never added.
  **(v2.1)** Units are the PAID units (`QUANTITY_PAID`); CMS applies the MUE to billed units. Paid units are normally at most the
  billed units (to confirm with the data owner), so a line flagged here was also billed over the limit; a line billed
  over but paid at or under the limit is not flagged (missed, never a false flag).
- Dollars at risk = the whole line (a Medicaid MUE denies the line).

### Units per day (`max_units_per_day`: code or code set, threshold) — state daily caps
- Per member and date of service: the sum of units over the **counted rows** of the code(s) (inside the rule's window
  and age condition). A finding when the sum > threshold **and** at least one of those rows is payable.
- `max_units_per_dos` is the same per member, servicing provider and date (rows with no provider are ignored).
- **(v2.5)** `max_units_per_day` takes an optional `scope`: `member_day` (the default, as above) or
  `member_provider_day` = exactly `max_units_per_dos`: per member, **servicing** provider and date; a row with no
  servicing provider is not counted (it is never part of a finding). The finding's servicing provider is the group's
  (none for `member_day`). **(v2.6)** `member_servicing_billing_day`: per member, servicing provider, billing provider
  and date; a row missing either id is not counted; the finding's servicing provider is the group's.
- Evidence = the counted rows of the group as "claim:line", distinct, in the same order and rendering as pair
  evidence **(v2)**. paid_amt = the group's paid total; paid_at_risk = paid total × (sum − threshold) / sum.

### Units per period (`max_units_per_period`: code set, threshold, period)
- Period: calendar month; calendar year; or AHCCCS contract / benefit year = 1 October – 30 September.
- Per member and period: the sum of units over the counted rows of the code(s) inside the rule's window and age
  condition; a finding when the sum > threshold and at least one of those rows is payable. period_start /
  period_end = the period's first and last day. Evidence, paid_amt and paid_at_risk as for daily caps.

### Not covered (`code_not_covered`: code or code set)
- A finding is every payable line of the code(s). **(v2.3)** observed units = the line's units, allowed = 0, excess =
  observed; paid_amt = paid_at_risk = the line's paid amount; no evidence lines.

### Provider type allowed (`provider_type_allowed`: code or code set, provider_types, provider_role) **(v2.2)**
- "Must be billed only by the following provider types": a finding is every payable line of the code(s) (inside the
  rule's window and age condition) whose provider type code is KNOWN and not in `provider_types` (codes compared after
  the §1 normalisation, so `' 2 '` is `02`). `provider_role` = `billing` (default: the provider that submits the claim,
  BProv_Type) or `servicing` (SProv_Type); **(v2.6)** or `billing_or_rendering`: the billing type, except when the
  billing type is a group billing type (`config.GROUP_BILLING_PROVIDER_TYPES`, default `01` "Group-Payment ID",
  compared after the §1 clean-up) — then the servicing (rendering) type is the one judged.
- A line with no provider type (of that role; for `billing_or_rendering`, the type judged) is never a finding: unknown
  is not a violation. **(v2.3)** KNOWN = present
  after the §1 clean-up; a code the routing table does not list (a new AHCCCS type) is known, and flagged when it is
  not in `provider_types`.
- **(v2.3)** The `provider_types` entries are cleaned exactly like the column (`8`, `' 8 '`, `'8.0'` → `08`); an entry
  that is missing after clean-up (blank, `NONE`, `NAN`, `NULL`) or is not 1–4 letters and digits makes the rule a lead
  (never a guess).
- One finding per payable snapshot row; units, dollars and evidence as for Not covered.

## 2b. The AHCCCS rule tables **(v2.5)**

AHCCCS publishes three billing-rule tables as spreadsheets (Medical Coding Resources). `00b_load_ahcccs_tables` reads
them with a deterministic reader (never the model) into three long tables, one row per cell / row, each row carrying
its file's **version date** (the "Updated" / "As of" date in the sheet). Codes are trimmed and upper-cased; B2 provider
types are cleaned as in §1 (`2` → `02`, `8.0` → `08`); indicators and Frequency Cds are trimmed and upper-cased. The
rules below are derived from those rows (SB's readings of 2026-10-04, `reference/ahcccs_table_readings.csv`) and then
run as ordinary state rules (§2, §3).

**Refused, never guessed.** A row without its code(s); the same cell (row × column) or the same daily-limits code twice
in one version (after clean-up); a blank or non-positive maximum; an indicator other than D / A / A*; two files for one
version; **(v2.6)** any content to the right of a table's last known column (a new column AHCCCS adds is never dropped
silently). 00b refuses such a file before loading it; 07 checks the rows read back from the catalog again and stops,
naming the row (a row edited there by hand would otherwise build two rules for one cell, or a rule for no code).

**Versions.** Per table, let its distinct version dates be d1 < d2 < … < dn. Version di judges dates of service from
di to the day before d(i+1), both included; dn is open-ended. A line dated before d1 is not judged by that table at all.
Every rule derived from version di carries that window as its effective / end date, and §2's rule window applies to it.

**Claims scope.** Like NCCI, a table rule is built only when its codes are paid in the claims table (the distinct
trimmed, upper-cased procedure codes of the claims at build time): a pair needs both codes, a daily limit or a B2 rule
its code.

**Same Day Disallow** — each cell (row code R, column code C, indicator I) of a version:
- R = C (the diagonal): no rule (the daily limits table caps a code's units).
- I = `A` (allowable): no rule.
- I = `D` (disallowed): a code pair rule (`code_pair_prohibited`) with code_a = C, code_b = R, scope `member_day`
  (the two lines may come from ANY providers), modifier indicator `0` (no modifier lets the pair through), and an
  exception = table note 2 ("Exceptions to limitations on service frequency or duration may be approved based on
  medical necessity.").
- I = `A*` (allowable for the member, not by the same provider): the same rule with scope
  `config.AHCCCS_SAME_PROVIDER_SCOPE` — **(v2.6)** default `member_servicing_billing_day`: the same servicing AND the
  same billing provider id (the legend says "same provider (service site or residential placement)" and AHCCCS
  corrected its own A* programming in 2026 without publishing it; requiring both ids flags only what breaks the rule
  under either reading); a missing id never matches.
- So the finding is the **row code's** line; the column code's lines are its evidence (§2 Code pair: payable lines,
  same member and date, never a line with itself, one finding per (rule, R line), evidence, Column One, dollars). No
  age condition. When a version marks both R × C and C × R (D or A*), each line is the finding of its own rule;
  **(v2.6)** both rules carry `both_ways` and their finding text says the pair is disallowed both ways (AHCCCS would
  deny one of the two lines: the two findings' dollars are not additive).
- Severity (§3): the base is `hard_denial` (indicator 0, kept as `finding_basis`); the label is `verify_pa` when a PA
  number is on either line, otherwise `verify_exception` — every Same Day finding, because note 2 is an exception.

**Daily limits** — each row (code K, "Procedure Maximum Occurrence" N, Limit 1 / Limit 2 with their Frequency Value
and Frequency Cd) of a version:
- When Limit 1 or Limit 2 has Frequency Cd `D` and Frequency Value `1` and that limit ≠ N, the file states two
  different daily limits for K: **no rule** (a Limit with no value states nothing) (listed for a person in `policy_ahcccs_conflicts`,
  `file_states_two_daily_limits`).
- **(v2.6)** When K fully matches `config.AHCCCS_DAILY_RECORD_ONLY_CODES` (anesthesia CPT 00100–01999: billed in
  15-minute time units, yet most have a maximum of 1–2) or N is all nines (`config.AHCCCS_DAILY_PLACEHOLDER_MAX`: 999,
  999999 — a placeholder for no practical limit): **no rule** (recorded, listed in `policy_ahcccs_conflicts`).
- Otherwise a `max_units_per_day` rule: code K, threshold N, scope = `config.AHCCCS_DAILY_LIMIT_SCOPE` (SB
  2026-10-04: units per member + provider + date of service; **(v2.6)** default `member_servicing_billing_day`, the
  provider read as for A*).
- Every other Limit / Frequency value (Cd W, M, Y, L, or D with a value other than 1) is recorded, never compiled.
- Severity: base `units_over_limit`; `verify_pa` / `verify_span` / `verify_modifier` as §3 (v2.6). No exception.

**B2 matrix** — per version and code K:
- K matching `config.AHCCCS_B2_COMPILE_CODES` as a WHOLE (Python `re.fullmatch` on the cleaned code; the default
  `^H[02][0-9]{3}$`: HCPCS H0xxx / H2xxx, behavioral-health-only codes):
  a `provider_type_allowed` rule: code K, provider_types = every provider type the version lists for K, provider_role
  = `config.AHCCCS_B2_PROVIDER_ROLE` (**(v2.6)** default `billing_or_rendering`: the matrix lists rendering
  practitioner types and no group, so a group's line is judged on its rendering provider's type). A row of K with no provider type leaves the list unknown: the rule keeps a blank entry and is a lead
  (§2, v2.3), never a narrower list.
- Any other code (CPT, S, T, A, J, G — billed outside behavioral health too), places of service and modifiers:
  recorded, no rule.
- Severity: base `provider_type_not_allowed`; `verify_pa` when a PA number is on the line.

**The three statements.** All Same Day rules of a build run as ONE statement (`BATCH:ahcccs_same_day`, reading
`policy_ahcccs_pair_edits`), all daily limits as one (`BATCH:ahcccs_daily_max`, `policy_ahcccs_daily_limits`), all B2
rules as one (`BATCH:ahcccs_provider_type`, `policy_ahcccs_provider_types`). Each statement's findings equal — as a
multiset, value for value — the union of the per-rule queries of the same rules (§2); a column one of them does not
output reads as NULL (the per-rule query of a `member_day` daily cap has no `servicing_provider`; the statement writes
it NULL). Findings carry
`origin = 'ahcccs_table'`, `batch` and the rule's `rule_id` (`TBL-…`). They are state rules: no NCCI edit file, PA
evaluated, never part of the Column One check (§3).

**Governance (not query semantics).** A table's rules are built only when every reading of it in
`reference/ahcccs_table_readings.csv` is signed (status `signed` and a reviewer; `config.
AHCCCS_TABLES_REQUIRE_SIGNED_READINGS`) **(v2.6)** and every config value a reading binds (its `binds` column, e.g.
`AHCCCS_SAME_PROVIDER_SCOPE=member_servicing_billing_day`) still has the signed value; otherwise the build log lists
the readings still to sign and the statement runs with 0 rules. 07 also stops when a table's rows no longer match what
00b logged for each version (row count and rows hash). The NCCI routing gate does not apply to them.

## 3. Severity (how a finding is labelled)
- Base: pair indicator 0 → `hard_denial`; pair indicator 1 → `unbypassed_pair`; unit limits → `units_over_limit`;
  not covered → `not_covered_paid`; **(v2.2)** provider type not allowed → `provider_type_not_allowed`.
- State rules only, in this order (the most cautious label wins): a PA number on any line of the finding →
  `verify_pa`; **(v2.6) daily caps only** (`max_units_per_day`, `max_units_per_dos`): else ONE payable line of the
  group alone has units > threshold → `verify_span` (the claims table has no service end date: that line may cover
  several days); else a payable line of the group carries a modifier in `config.DAILY_CAP_VERIFY_MODIFIERS` (bilateral 50,
  anatomic RT / LT / E1–E4 / FA / F1–F9 / TA / T1–T9 / LC / LD / RC / LM / RI, repeat 76 / 77 / 91, distinct 59 / XE /
  XS / XP / XU; any of the four modifier columns, after the §1 clean-up) → `verify_modifier` (both labels read payable
  lines only: a cancelled line and its reversal net out of the sum and say nothing about the paid day); then for every state
  rule: the predicate states an exception → `verify_exception`; else the policy says "may" → `discretionary`.
  `finding_basis` keeps the base label. NCCI ignores PA (CMS: a PA is not an NCCI bypass).
- `pa_present`: 1 when a PA number is on any line of the finding, 0 when none is, **(v2)** NULL when PA is not
  evaluated (every NCCI finding; a state rule when no PA column is configured).
- NCCI MUE: when a later CMS quarter raised the limit to ≥ the line's units, or removed it →
  `verify_mue_changed_later`.
- After all NCCI findings of a run exist: a pair finding whose Column One lines are ALL themselves denied in that
  run (by an MUE or as the Column Two line of another pair) → `verify_col1_not_payable` (CMS applies a PTP edit only
  when the Column One code is payable).

## 4. The utilization signal (period limits only — NOT a finding)
- For each member: the daily sums of counted units of the code(s) (inside window and age condition); for each date
  with at least one counted row (even one whose units are missing - oracle S-05), the total over that date and the
  preceding (N − 1) days, N = 30 (month) or 365 (year, contract year).
- One row per member whose total exceeds the threshold on some date, for the date with the largest total (the
  earliest such date on a tie): window_start, window_end, rolling_units, rolling_paid.
- Why: a provider timing services around the 1 October reset stays within each contract year's limit (no finding)
  but shows here. It feeds anomaly review; it is never a violation by itself.

## 5. How this is verified

**What these checks prove, and what they do not (2026-10-04, external review).** Items 1, 2 and 4 prove that each query
does exactly what its RULE says — the SQL against the interpreted rule. They do not prove that the rule is the right
reading of the policy, nor that no rule was missed: a wrong reading passes every one of them. That rests on item 3's
human signatures and on the extraction quality measured by v01 (precision, fidelity and recall on a human-scored
sample) and v05 (a run against the signed decisions) — numbers that do not exist until people score them.
1. **Scenario tests (the query validation pack, v06):** for every query of a build, synthetic claims that MUST and
   must NOT be flagged, run through the stored SQL text unchanged; PASS / FAIL per scenario.
2. **Independent reference check (`tests/test_sql_oracle.py`):** a separate Python program, written by a separate
   agent from THIS document and the routing table only (never from the SQL), computes the expected findings on
   random claim sets — whitespace, case, duplicates, reversals booked either sign, $0 lines, missing members, ids and
   birth dates, modifiers, forms, provider types, age and period boundaries — and must agree with the SQL exactly
   (findings, severity, units, evidence, Column One, dollars to the cent, pa_present, period bounds, signals).
   2026-10-03, version 2: 135 claim sets, 1,106 queries, 2,615 findings and 228 signal rows, all equal, including
   rounds with the optional rows on, unmapped types off, and routing by form. Version 1 of the same check found the
   four defects fixed in v2 (evidence with a missing line number; `code` ignored next to `code_set`; NCCI `pa_present`
   0 instead of not-evaluated; a stray NCCI scope honoured) and the reversal-sign risk. **(v2.3)** Rewritten for the
   billing provider type and the provider-type rule by a new agent from this document alone; on the final code: 70
   claim sets (17,799 rows), 644 queries, 2,184 findings (573 provider-type) and 94 signal rows, all equal, plus 29
   fixed hand-computed cases; the larger run: 170 claim sets (45,420 rows), 1,566 queries, 5,398 findings (1,465
   provider-type), 211 signal rows, all equal; routing rounds by billing type, servicing type and form, optional rows on and off,
   unmapped types off. It found the points v2.3 settles (textual nulls, tie order, edit file and findings, units).
   **(v2.5 / v2.6)** `tests/test_sql_oracle_tables.py`, by a separate agent from §2b alone (production as a black box),
   derives the table rules from random table versions and compares rules, the three statements AND each rule's own SQL
   with the expected findings; on the final code (v2.6): 60 rounds, 2,412 table rules, 14,878 findings, and the general
   oracle (updated to v2.6: the new scope, role and daily-cap labels) 48 rounds, 62,358 claim rows, 7,011 findings — all
   equal; 21 defects planted in the oracle copy, all caught. It found the frame-level gaps v2.6 now refuses.
3. **Sign-off:** each query's plain English, SQL and scenario results are signed by a validator; the signature is
   bound to the SQL's sha256, and 08 refuses SQL whose hash changed after the build (**(v2.1)** or that has no hash).
   **(v2.1)** The decision is binding: 08 never runs a query a validator marked PROBLEM for its current SQL; with
   `config.RUN_ONLY_VALIDATED_QUERIES = True` it runs only queries signed OK. Every finding carries `query_validation`
   (`OK` / `not_validated`), so a sample can be validated first and the rest labelled honestly.
   **(v2.4)** The routing table is signed the same way: with `config.NCCI_REQUIRE_SIGNED_ROUTING = True` (default) 08
   runs the two NCCI statements only when every provider type code on the snapshot's form A / O lines (billing and
   servicing; servicing only when routing by servicing type) has a row with `status = signed` and a `reviewer`;
   otherwise both are recorded in `policy_detector_runs.skipped` with the codes still to sign, the run is
   `partial_run`, and the run log (`RUN:snapshot`) says whether the routing was signed. Every NCCI finding carries
   `ncci_routing` = signed | unsigned | form_fallback | form_only (the last three only in an exploratory run with the
   switch off). The form fallback for unmapped types (`NCCI_UNMAPPED_PROVIDER_TYPE = "form"`) counts as unsigned. Routing by form alone has no mapping to sign and does not run
   while the switch is on. This is run governance, not query semantics: what a query finds is unchanged.
4. **Mutation testing (2026-10-03):** single realistic defects planted in the query code one at a time (`>` for `>=`,
   a dropped filter, a swapped pair, a dropped modifier, a shifted window, a skipped hash check...). The test suite
   above must fail on each; see docs/V5_CHANGES.md for the list and the result.

## 6. Known limits (by design, stated so nobody is surprised)
- Same date of service stands in for "within 24 hours" (S9484/S9485): an episode across midnight is missed.
- A limit with an effective date in the middle of a period counts only the lines from that date.
- **(v2.1)** A state rule with no effective date judges EVERY date of service in the claims. The manual rarely dates
  individual rules, so a rule newer than the oldest claims would judge claims from before it existed. In the v4 review
  workbook 51 of the 60 compiled state rules carry a start date from the manual's revision history (the revision that
  added the section) or a dated AHCCCS notice; 9 long-standing rules have none. The validation pack says per query
  which dates it judges (`dates_covered`); the reviewer sets `corrected_effective_date` where a rule is newer.
- MUE units on a multi-day line are not divided by the number of days (the claims table has no service end date).
- Arizona's own NCCI deactivations (state RISSNET files) are not applied; the CMS public files are.
- Reversal matching is a heuristic until the data owner names the claims table's adjustment key. A partial
  recoupment booked with positive units (paid < 0) removes those units (it can hide a service, never invent one).
- The provider type routing table is AHCCCS → CMS Table 2 as proposed on 2026-10-03; it is a policy reading and must be
  signed like the rules (01 shows every provider type in the claims with the file its lines take). **(v2.4)** Until it
  is signed for the provider types in the claims, 08 does not run NCCI (§5, item 3).
- **(v2.4)** The NCCI rules of a build are the CMS edits whose codes are paid in the claims (`policy_build_log.
  ncci_rules_scope = executable_against_claims`): a change in the claims mix changes the count with no change in
  policy. The CMS files' own sizes are in `ncci_source_vs_claims_scope`.
- **(v2.5)** A claim dated before the oldest loaded version of an AHCCCS table is not judged by that table (SB is
  obtaining AHCCCS's earlier versions; each one loaded becomes its own version with its own window).
- **(v2.6)** "Same provider" for an A* pair and for a daily limit is the same servicing (`SProv_ID`) AND billing
  (`BProv_ID`) provider id until SB settles which one AHCCCS means: no false finding from the choice, but a clinician
  billing through two agencies, or two clinicians of one site, are not compared (misses).
- **(v2.6)** A daily-cap finding made by ONE line over the cap is `verify_span`: without a service end date a
  multi-day line (per diem codes) cannot be told from a one-day overuse. AHCCCS asks for all of a date's units on one
  line (FFS Chapter 5, field 24G), so a real one-day overuse is usually ONE line too and is also labelled `verify_span`
  — a label, never a dropped finding; with a service end date in the claims the label could be limited to lines whose
  end date is after their begin date (SB to check the extract).
- **(v2.6)** A column added by hand to a loaded table in the catalog is ignored (00b refuses one in a file; 07's load
  check compares the rows of the known columns).
- **(v2.5)** A pair the Same Day table marks both ways (104 code pairs in the 10/01/2026 file) flags both lines; their
  `paid_at_risk` adds up although AHCCCS would deny at most one of them.
- **(v2.5)** The daily limits file's period limits (per week / month / year / lifetime) are recorded, not compiled:
  their period semantics are undecided.
