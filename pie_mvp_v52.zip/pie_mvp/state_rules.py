"""
state_rules.py  -  the reviewed authoring source for AHCCCS (state) rules.

State rules live in a Delta table, not in Python modules. "Add a chapter" means
"add reviewed rows", never "edit the build notebook". Every row carries a
review_status; the build loads only rows a named human has approved (or the
hand-authored PoC rules migrated as 'legacy_hand_authored').

Table: main.sedo.state_rules  (see STATE_RULE_COLUMNS)

Review round-trip (the human gate, made auditable):
  export_review_workbook()  -> Excel of rows needing a decision (drafts, rows parked or
                               sent back for re-sign, and the hand-authored seeds - C4-05)
  ingest_review_decisions() <- the same file with decision columns filled;
                               appends to policy_review_log and updates
                               review_status on state_rules.

review_status values:
  draft                 extracted, nobody has decided yet
  needs_review          parked (a decision could not be applied) or sent back for re-sign
                        (source document changed / quote rejected before); carries why in review_note
  approved              a named reviewer signed it (Approve or Fix) - compiles while current
  rejected              a named reviewer rejected it - never resurrected by re-extraction
  legacy_hand_authored  a state_seed.py rule nobody has signed; compiles only while
                        config.COMPILE_LEGACY_SEEDS is True
  superseded            kept for audit, never exported, never loaded: an extracted draft the latest run
                        of the same document no longer produces (C3-09), or a seed state_seed.py no
                        longer contains
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from datetime import date, datetime

import pandas as pd

from schema import Rule

RULE_FIELDS = [
    "rule_id", "origin", "plane", "binding_status", "statement", "predicate", "codes",
    "population", "machine_checkable", "not_checkable_reason", "required_claim_fields",
    "ambiguity_flag", "ambiguity_note", "alternates", "source_doc", "source_locator",
    "source_url", "doc_version", "doc_hash", "effective_date", "end_date", "deactivated",
    "supersedes", "notes",
]
_JSON_FIELDS = {"predicate", "codes", "required_claim_fields", "alternates", "supersedes"}
_BOOL_FIELDS = ("machine_checkable", "ambiguity_flag", "deactivated")
REVIEW_FIELDS = ["chapter", "review_status", "reviewer", "reviewed_at", "review_note",
                 # JSON {status, decision, reviewer, reviewed_at, doc_hash, predicate, statement, ...}: the
                 # decision a row carried before it was re-opened - sent back for re-sign because its source
                 # document changed (D5), a quote rejected before (C3-09), or a seed being signed (C4-05).
                 # C4-04: it carries the predicate/statement that decision was about (for a Fix: the
                 # reviewer's corrections), so a re-sign cannot silently revert to the model's predicate.
                 "prior_review",
                 # C4-12: what the applied decision was (approve | fix | reject), the sha256 of the canonical
                 # JSON of the predicate a reviewer signed (Approve / Fix), and where the decision came from
                 # ('workbook'). The build refuses an approved row whose predicate no longer hashes to it.
                 "review_decision", "approved_predicate_sha256", "decision_source"]
# filled only for rows produced by extract_rules (None for hand-authored rows)
EXTRACTION_FIELDS = ["extraction_key", "verbatim_quote", "section_id", "extraction_confidence",
                     "extraction_run_id", "extraction_backend", "grounding",
                     # "pattern" | "model" | "pattern+model" - which method found the rule
                     "extraction_source",
                     # the model's own quote when it differed from the source span stored in verbatim_quote
                     "model_quote"]
STATE_RULE_COLUMNS = RULE_FIELDS + REVIEW_FIELDS + EXTRACTION_FIELDS

LOADABLE_STATUS = ("approved", "legacy_hand_authored")
# C4-05: the hand-authored seeds are reviewable too - a named reviewer can sign them in the workbook
PENDING_STATUS = ("draft", "needs_review", "legacy_hand_authored")
# 2026-10-02: a DECIDED row changes only when the workbook row says reopen = yes (with a reviewer's name).
# Without it, a re-imported old workbook can never flip a decided row (D6).
REOPENABLE_STATUS = ("approved", "rejected")
DECISION_SOURCE = "workbook"
AI_PREREVIEW_PREFIX = "AI pre-review:"


# ------------------------------------------------------------ small helpers
def _is_null(v) -> bool:
    if v is None:
        return True
    if isinstance(v, (list, dict, tuple, set)):
        return False
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _text(v) -> str:
    """A cell / field as clean text: None, NaN, 'nan' and 'none' are empty. Excel hands back an
    empty cell as float NaN, and `str(NaN or "")` is 'nan' (NaN is truthy) - which is how an
    empty review_note used to be stored as the note 'nan'."""
    if _is_null(v):
        return ""
    s = str(v).strip()
    return "" if s.lower() in ("nan", "none", "nat") else s


def _flag(v) -> bool:
    """C4-17: bool(NaN) is True, so a NaN `deactivated` read from a table silently switched a
    rule off. Missing / NaN / None flags are False - for machine_checkable that is fail-closed
    (an unknown rule is a lead, not a detector)."""
    if _is_null(v):
        return False
    if isinstance(v, str):
        return v.strip().lower() in ("true", "t", "1", "yes", "y")
    try:
        return bool(v)
    except (TypeError, ValueError):
        return False


def _json_obj(v, default=None):
    """A JSON column value -> Python (dict/list). Bad / empty -> default."""
    if isinstance(v, (dict, list)):
        return v
    s = _text(v)
    if not s:
        return default
    try:
        return json.loads(s)
    except (TypeError, ValueError):
        return default


def canonical_predicate(p) -> str:
    """The canonical JSON of a predicate (sorted keys, compact). A JSON string is parsed first."""
    if isinstance(p, str):
        p = json.loads(p) if p.strip() else {}
    if _is_null(p):
        p = {}
    return json.dumps(p, sort_keys=True, separators=(",", ":"), default=str)


def predicate_sha256(p) -> str | None:
    """C4-12: sha256 of canonical_predicate(p); None when p is not valid JSON."""
    try:
        return hashlib.sha256(canonical_predicate(p).encode("utf-8")).hexdigest()
    except (TypeError, ValueError):
        return None


_DASHES = dict.fromkeys(map(ord, "‐‑‒–—―−"), "-")


def _norm_quote(s) -> str:
    """Normalised policy text for quote-level memory (C3-09): case, dashes (incl. the U+2011
    non-breaking hyphen gpt-oss emits), quotes and whitespace do not make a different sentence."""
    s = _text(s).translate(_DASHES).replace("’", "'").replace("‘", "'").replace(" ", " ")
    s = re.sub(r"[\"“”]", "", s.lower())
    return re.sub(r"\s+", " ", s).strip().rstrip(".;:")


def _codes_of(row) -> tuple:
    codes = _json_obj(row.get("codes"), []) or []
    return tuple(sorted({str(c).strip().upper() for c in codes if str(c).strip()}))


def _quote_sig(row) -> tuple | None:
    q = _norm_quote(row.get("verbatim_quote"))
    return (q, _codes_of(row)) if q else None


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _chapter_key(v) -> str:
    """'10', 10 and 10.0 are the same chapter (a fail-closed check must not trip on a dtype)."""
    if _is_null(v):
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


# ------------------------------------------------------------ row <-> rule
def rule_to_row(rule, chapter: str, review_status: str = "draft",
                reviewer: str | None = None, review_note: str | None = None) -> dict:
    d = rule.to_dict() if hasattr(rule, "to_dict") else dict(rule)
    row = {}
    for f in RULE_FIELDS:
        v = d.get(f)
        if f in _JSON_FIELDS:
            v = json.dumps(v if v is not None else ([] if f != "predicate" else {}), default=str)
        row[f] = v
    row.update(chapter=chapter, review_status=review_status, reviewer=reviewer,
               reviewed_at=datetime.now().isoformat(timespec="seconds") if reviewer else None,
               review_note=review_note, prior_review=None,
               review_decision=None, approved_predicate_sha256=None, decision_source=None)
    if d.get("extraction_key"):
        row["extraction_key"] = d["extraction_key"]
    for f in ("verbatim_quote", "section_id"):
        if d.get(f):
            row[f] = d[f]
    for f in EXTRACTION_FIELDS:
        row.setdefault(f, None)
    return row


def row_to_rule(row: dict) -> Rule:
    kw = {}
    for f in RULE_FIELDS:
        v = row.get(f)
        if f in _JSON_FIELDS and isinstance(v, str):
            v = json.loads(v) if v else ([] if f != "predicate" else {})
        if f in _BOOL_FIELDS:
            v = _flag(v)                          # C4-17: NaN / None -> False, never bool(NaN) == True
        if isinstance(v, float) and pd.isna(v):
            v = None
        kw[f] = v
    if not kw.get("supersedes"):
        kw["supersedes"] = None
    kw.pop("rule_id", None)              # re-derived by rule_normalize
    ek = row.get("extraction_key")       # stable join key; survives normalization
    kw["extraction_key"] = None if (isinstance(ek, float) and pd.isna(ek)) else (ek or None)
    for f in ("verbatim_quote", "section_id"):
        v = row.get(f)
        kw[f] = None if v is None or (isinstance(v, float) and pd.isna(v)) or v == "" else str(v)
    return Rule(**kw)


# ----------------------------------------------------------------- loading
STALE_REASONS = {
    "doc_changed": "the chapter's current document version is not the one the reviewer signed",
    "no_inventory": "no current inventory row (doc_hash) for the chapter - the version cannot be confirmed",
    "no_doc_hash": "an extracted rule with no document version at all",
    "predicate_changed": "the predicate no longer hashes to the one the reviewer approved (approved_predicate_sha256)",
}


def stale_reasons(df: pd.DataFrame, current_doc_hash: dict | None) -> pd.Series:
    """Why each row's approval no longer binds ('' = it does). D5: an approval binds to the document
    version the reviewer saw.

    C4-03 (fail closed): a row WITH a doc_hash (an extracted rule) is stale when the chapter's current
    doc_hash (latest inventory) differs ('doc_changed') OR when there is no current hash for the chapter
    at all ('no_inventory') - an inventory table that is missing, empty, or has no row for the chapter
    used to switch the check off and compile every old approval. An extracted row with no doc_hash is
    'no_doc_hash'. Hand-authored seeds carry no doc_hash and are never stale by this test (they are
    governed by config.COMPILE_LEGACY_SEEDS, or by a reviewer's signature - C4-05).
    C4-12: a row whose approved_predicate_sha256 is set but no longer matches its predicate (edited
    after sign-off) is 'predicate_changed'."""
    out = pd.Series("", index=df.index, dtype=object)
    if df.empty:
        return out
    cur_map = {_chapter_key(k): _text(v) for k, v in (current_doc_hash or {}).items()}
    ch = df["chapter"].map(_chapter_key) if "chapter" in df else pd.Series("", index=df.index)
    cur = ch.map(lambda c: cur_map.get(c, ""))
    h = df["doc_hash"].map(_text) if "doc_hash" in df else pd.Series("", index=df.index)
    origin = df["origin"].map(_text) if "origin" in df else pd.Series("", index=df.index)
    bound = h != ""
    out[bound & (cur == "")] = "no_inventory"
    out[bound & (cur != "") & (h != cur)] = "doc_changed"
    out[~bound & (origin == "extracted")] = "no_doc_hash"
    if "approved_predicate_sha256" in df and "predicate" in df:
        sha = df["approved_predicate_sha256"].map(_text)
        moved = (out == "") & (sha != "") & (sha != df["predicate"].map(predicate_sha256).map(_text))
        out[moved] = "predicate_changed"
    return out


def stale_mask(df: pd.DataFrame, current_doc_hash: dict | None) -> pd.Series:
    """D5 / C4-03: True where an approval no longer binds (see stale_reasons). Fails CLOSED: with no
    current inventory hash for a chapter, its extracted approvals are stale."""
    return stale_reasons(df, current_doc_hash) != ""


def load_state_rules(spark, table: str, scope_codes: set[str] | None = None,
                     statuses=LOADABLE_STATUS, current_doc_hash: dict | None = None,
                     report: dict | None = None, run_prompt: dict | None = None) -> list[Rule]:
    """current_doc_hash: {chapter: doc_hash of the latest inventory row}. Approved rows from an
    older document version - or from a chapter with no current inventory row - are EXCLUDED
    (never silently compiled) and listed in report['stale'] with a reason.
    run_prompt: {extraction run_id: prompt_version} from policy_extraction_log - the one-engine rule (engine_reasons);
    None = not applied."""
    df = spark.table(table).toPandas()
    return rules_from_frame(df, scope_codes, statuses, current_doc_hash, report, label=table, run_prompt=run_prompt)


ENGINE_REASONS = {
    "hand_authored": "a hand-authored rule: a checklist for v05, not a KB rule (config.COMPILE_HAND_AUTHORED = False)",
    "other_engine": "produced last by a run whose prompt version is not in config.KB_PROMPT_VERSIONS - re-extract it "
                    "with the current engine",
    "engine_unknown": "the run that produced it is not in policy_extraction_log, so its engine cannot be checked",
}


def engine_reasons(df: pd.DataFrame, run_prompt: dict | None) -> pd.Series:
    """Why a row may NOT enter the KB under the one-engine rule (2026-10-04, SB: "keep rules that are extracted using the
    same version of extraction"); '' = it may. A hand-authored row (origin 'manual') only with
    config.COMPILE_HAND_AUTHORED; an extracted row only when the last run that produced it (extraction_run_id) used a
    prompt version in config.KB_PROMPT_VERSIONS (empty = any engine). run_prompt None = the rule is not applied."""
    import config as _cfg
    out = pd.Series("", index=df.index, dtype=object)
    if run_prompt is None:
        return out
    origin = _text_series(df, "origin")
    if not getattr(_cfg, "COMPILE_HAND_AUTHORED", False):
        out[origin == "manual"] = "hand_authored"
    allowed = tuple(getattr(_cfg, "KB_PROMPT_VERSIONS", ()) or ())
    if allowed:
        runs = {_text(k): _text(v) for k, v in (run_prompt or {}).items() if _text(k)}
        for i, run in zip(df.index, _text_series(df, "extraction_run_id")):
            if origin[i] != "extracted":
                continue
            pv = runs.get(run)
            if pv is None:
                out[i] = "engine_unknown"
            elif pv not in allowed:
                out[i] = "other_engine"
    return out


def _text_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series("", index=df.index, dtype=object)
    return pd.Series([_text(v) for v in df[col]], index=df.index, dtype=object)


def rules_from_frame(df: pd.DataFrame, scope_codes=None, statuses=LOADABLE_STATUS,
                     current_doc_hash: dict | None = None, report: dict | None = None,
                     label: str = "state_rules", run_prompt: dict | None = None) -> list[Rule]:
    report = report if report is not None else {}
    report.setdefault("engine_excluded", [])
    if df.empty:
        print(f"  state: {label} is empty")
        report.update(stale=[], legacy=0)
        return []
    import config as _cfg
    if not getattr(_cfg, "COMPILE_LEGACY_SEEDS", True):
        statuses = tuple(s for s in statuses if s != "legacy_hand_authored")
    deact = df["deactivated"].map(_flag) if "deactivated" in df else pd.Series(False, index=df.index)
    df = df[df["review_status"].isin(statuses) & ~deact]
    # one engine in the KB (2026-10-04, SB): hand-authored rules and rules only an older engine produced stay out
    eng = engine_reasons(df, run_prompt)
    if (eng != "").any():
        cols_e = [c for c in ("rule_id", "chapter", "origin", "extraction_run_id") if c in df.columns]
        report["engine_excluded"] = [dict(r, reason=w) for r, w in
                                     zip(df.loc[eng != "", cols_e].to_dict("records"), eng[eng != ""])]
        by = eng[eng != ""].value_counts().to_dict()
        print(f"  state: {int((eng != '').sum())} signed rule(s) NOT compiled under the one-engine rule: "
              + "; ".join(f"{k}={v} ({ENGINE_REASONS[k]})" for k, v in by.items()))
        df = df[eng == ""]
    why = stale_reasons(df, current_doc_hash)
    stale = why != ""
    cols = [c for c in ("rule_id", "chapter", "doc_hash", "reviewer") if c in df.columns]
    report["stale"] = [dict(r, reason=w) for r, w in zip(df.loc[stale, cols].to_dict("records"), why[stale])]
    report["legacy"] = int((df["review_status"] == "legacy_hand_authored").sum())
    if stale.any():
        by = why[stale].value_counts().to_dict()
        print(f"  state: {int(stale.sum())} approved rule(s) are NOT compiled until re-signed / re-verified: "
              + "; ".join(f"{k}={v} ({STALE_REASONS.get(k, k)})" for k, v in by.items())
              + f". e.g. {report['stale'][:5]}")
    df = df[~stale]
    out, skipped_scope = [], 0
    for row in df.to_dict("records"):
        codes = json.loads(row["codes"]) if isinstance(row.get("codes"), str) and row["codes"] else []
        codes = [str(c).strip().upper() for c in codes]
        # a coded rule must touch a paid code; a policy-level rule (no codes) always loads
        if scope_codes and codes and not any(c in scope_codes for c in codes):
            skipped_scope += 1
            continue
        out.append(row_to_rule(row))
    by_ch = df["chapter"].value_counts().to_dict()
    print(f"  state: {len(out)} reviewed rules loaded {by_ch}"
          + (f"; {skipped_scope} out of claims scope" if skipped_scope else ""))
    return out


# ---------------------------------------------------------------- writing
def write_state_rules(spark, table: str, rows: list[dict], mode: str = "overwrite"):
    """C4-18 made kb_io.write_table honour an EMPTY overwrite (it empties the table). That must never
    happen to the reviewed rules table: an empty frame here means the caller's read failed, so it is
    refused (the skip-on-empty that stopped the 2026-09-21 near-miss now lives here)."""
    from kb_io import write_table
    if not rows:
        print(f"  (state_rules: nothing to write - {table} is never replaced by an empty frame)")
        return 0
    pdf = pd.DataFrame(rows, columns=STATE_RULE_COLUMNS)
    for b in _BOOL_FIELDS:
        pdf[b] = pdf[b].map(_flag).astype(bool)
    return write_table(spark, pdf, table, mode)


def _with_columns(df: pd.DataFrame | None) -> pd.DataFrame:
    """A copy with every STATE_RULE_COLUMNS column (older tables lack the newer ones), a 0..n-1 index."""
    cols = STATE_RULE_COLUMNS
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=cols)
    out = df.copy().reset_index(drop=True)
    for c in cols:
        if c not in out.columns:
            out[c] = None
    return out[cols].copy()


# ----------------------------------------------------------------- merge
REVIEWED = ("approved", "legacy_hand_authored")


def _decision_of(row: dict) -> str:
    """The decision behind a row's current status: approve | fix | reject | seed."""
    d = _text(row.get("review_decision")).lower()
    if d:
        return d
    st = _text(row.get("review_status"))
    if st == "legacy_hand_authored":
        return "seed"
    if st == "rejected":
        return "reject"
    if st == "approved":
        # rows fixed before C4-12 carry no review_decision: the Fix path marked grounding / review_note
        g = _json_obj(row.get("grounding"), {})
        if (isinstance(g, dict) and g.get("superseded_by_reviewer")) or \
                "[predicate corrected by reviewer" in _text(row.get("review_note")):
            return "fix"
        return "approve"
    return st


def prior_from_row(row: dict) -> dict:
    """C4-04: the human decision a row carries, as kept in prior_review when the row is re-opened.
    Holds the predicate / statement / window / population that decision was about - for a Fix those
    ARE the reviewer's corrections - so the re-sign workbook can show them (previous_decision)."""
    pop = _text(row.get("population")) or "all"
    return {"status": _text(row.get("review_status")) or None, "decision": _decision_of(row) or None,
            "reviewer": _text(row.get("reviewer")) or None, "reviewed_at": _text(row.get("reviewed_at")) or None,
            "doc_hash": _text(row.get("doc_hash")) or None, "rule_id": _text(row.get("rule_id")) or None,
            "extraction_key": _text(row.get("extraction_key")) or None,
            "statement": _text(row.get("statement")) or None,
            "predicate": _json_obj(row.get("predicate"), None),
            "approved_predicate_sha256": _text(row.get("approved_predicate_sha256")) or None,
            "effective_date": _text(row.get("effective_date")) or None,
            "end_date": _text(row.get("end_date")) or None, "population": pop,
            "review_note": _text(row.get("review_note")) or None}


_DECISION_LABEL = {"approve": "Approve", "fix": "Fix", "reject": "Reject", "seed": "Seed (hand-authored, unsigned)",
                   "approved": "Approve", "rejected": "Reject", "legacy_hand_authored": "Seed (hand-authored, unsigned)"}


def previous_decision_text(prior) -> str:
    """C4-04: prior_review as one line for the workbook, e.g.
    'Fix by SS 2026-10-05: {"type": "max_units_per_day", ...} | on doc 1a2b3c4d'."""
    p = _json_obj(prior, {}) if not isinstance(prior, dict) else prior
    if not p:
        return ""
    dec = _text(p.get("decision") or p.get("status")).lower()
    head = _DECISION_LABEL.get(dec, dec.title() or "Decision")
    if p.get("reviewer"):
        head += f" by {p['reviewer']}"
    if p.get("reviewed_at"):
        head += f" {str(p['reviewed_at'])[:10]}"
    pred = p.get("predicate")
    text = f"{head}: {json.dumps(pred, default=str) if pred else '(predicate not recorded)'}"
    extra = []
    if p.get("effective_date") or p.get("end_date"):
        extra.append(f"window {p.get('effective_date') or 'start'}..{p.get('end_date') or 'open'}")
    if _text(p.get("population")).lower() not in ("", "all"):
        extra.append(f"population: {p['population']}")
    if p.get("matched_on"):
        extra.append(f"matched on {p['matched_on']} of {p.get('rule_id')}")
    if p.get("doc_hash"):
        extra.append(f"on doc {str(p['doc_hash'])[:8]}")
    return text + (" | " + " | ".join(extra) if extra else "")


def _mark_reproduced(old: dict, d: dict) -> int:
    """A DECIDED extracted row (approved / rejected) that the new run produced again - the same extraction_key, i.e.
    the same predicate, quote and dates - now names that run as the last one to produce it; its decision, predicate and
    every review field are untouched. 2026-10-04 (SB, fresh start): 07 compiles an extracted rule only when that run
    used a prompt version in config.KB_PROMPT_VERSIONS, so a rule the current engine reproduces stays in the KB, and one
    only an older engine produced does not. Returns 1 when the row was updated."""
    run = _text(d.get("extraction_run_id"))
    if not run or _text(old.get("origin")) != "extracted" or _text(old.get("extraction_run_id")) == run:
        return 0
    old["extraction_run_id"] = run
    old["extraction_backend"] = d.get("extraction_backend") or old.get("extraction_backend")
    return 1


def merge_drafts(existing: pd.DataFrame | None, drafts: list[dict], rerun: dict | None = None,
                 run_id: str | None = None, completed_sections=None) -> tuple[pd.DataFrame, dict]:
    """Merge freshly extracted drafts into the state_rules table, by extraction_key.

      * a key already reviewed (approved / legacy) is left untouched - never downgraded (its extraction_run_id
        names the new run when the run produced it again: _mark_reproduced, for the one-engine rule of 07)
      * a key previously rejected stays rejected - never resurrected by re-extraction
      * a key already in draft is replaced by the new draft (fresh quote, confidence, run);
        a pending RE-SIGN (prior_review set) stays a re-sign - its human decision is not lost
      * a new key is added as a draft - unless its normalised quote + codes match a REJECTED
        row: then it is added as needs_review with that rejection in prior_review (C3-09)
      * D5: a reviewed / rejected key re-extracted from a NEW document version goes back to
        needs_review; prior_review carries the old decision with the predicate / statement it
        was about (C4-04: a Fix's corrections survive the re-sign)

    C3-09: rerun = {chapter: doc_hash} of the chapters this run extracted. An existing DRAFT /
    needs_review row of that chapter AND document version whose extraction_key the run did NOT
    produce becomes 'superseded' (kept, never deleted, never exported; review_note names the run).
    completed_sections (optional): section_ids the run answered definitively (outcome proposals /
    no_rules); when given, only rows from those sections are superseded - a section the model failed
    on, or the pre-filter skipped, proves nothing about the rules in it. Rows carrying a human
    decision (prior_review) are never superseded.
    Returns (merged_df, counts)."""
    cols = STATE_RULE_COLUMNS
    existing = _with_columns(existing)
    keep_rows = existing.to_dict("records")
    by_key = {r["extraction_key"]: i for i, r in enumerate(keep_rows)
              if isinstance(r["extraction_key"], str) and r["extraction_key"]}
    by_id = {r["rule_id"]: i for i, r in enumerate(keep_rows) if isinstance(r["rule_id"], str) and r["rule_id"]}
    rejected_by_quote = {}
    for r in keep_rows:
        sig = _quote_sig(r) if r.get("review_status") == "rejected" else None
        if sig and sig not in rejected_by_quote:
            rejected_by_quote[sig] = r
    run_id = run_id or next((d.get("extraction_run_id") for d in drafts if d.get("extraction_run_id")), None)
    counts = {"added": 0, "replaced_draft": 0, "kept_reviewed": 0, "kept_rejected": 0, "resign_new_version": 0,
              "kept_resign_pending": 0, "rejected_quote_seen": 0, "superseded": 0, "reproduced_decided": 0}
    idx_to_drop = set()
    new_rows = []
    for d in drafts:
        key = d.get("extraction_key")
        i = by_key.get(key, by_id.get(d.get("rule_id")))
        if i is None:
            hit = rejected_by_quote.get(_quote_sig(d))
            if hit is not None:
                # C3-09: the model re-phrased / re-typed a rule a reviewer already rejected -> new key,
                # same text. Not auto-rejected (the predicate may now be right), but the reviewer sees it.
                prior = dict(prior_from_row(hit), matched_on="verbatim_quote+codes")
                row = dict(d)
                row.update(review_status="needs_review", prior_review=json.dumps(prior, default=str),
                           review_note=(f"the same policy text (quote + codes) was REJECTED before by "
                                        f"{prior['reviewer']} ({prior['rule_id']}): {prior.get('review_note') or ''}"
                                        f" - decide again").strip())
                new_rows.append(row)
                counts["rejected_quote_seen"] += 1
                continue
            new_rows.append(d)
            counts["added"] += 1
            continue
        old = keep_rows[i]
        status = old["review_status"]
        old_hash = _text(old.get("doc_hash"))
        new_hash = _text(d.get("doc_hash"))
        if status in REVIEWED + ("rejected",) and old_hash and new_hash and old_hash != new_hash:
            # D5: same rule (same meaning key) re-extracted from a NEW document version. The old
            # decision bound to the old text; carry it as prior_review and ask for a re-sign.
            prior = prior_from_row(old)
            row = dict(d)
            row.update(review_status="needs_review", prior_review=json.dumps(prior, default=str),
                       review_note=(f"source document changed ({old_hash[:8]} -> {new_hash[:8]}); "
                                    f"previously {status} by {prior['reviewer']} - re-sign against the new text"
                                    + (" (that decision was a FIX - see previous_decision)"
                                       if prior["decision"] == "fix" else "")))
            idx_to_drop.add(i)
            new_rows.append(row)
            counts["resign_new_version"] += 1
        elif status in REVIEWED:
            counts["kept_reviewed"] += 1
            counts["reproduced_decided"] += _mark_reproduced(old, d)
        elif status == "rejected":
            counts["kept_rejected"] += 1
            counts["reproduced_decided"] += _mark_reproduced(old, d)
        else:
            row = dict(d)
            if _text(old.get("prior_review")):
                # a pending re-sign re-extracted again (05 re-run, or another run) keeps its human decision;
                # replacing it with a plain draft lost prior_review and tripped the shrink guard
                row.update(review_status="needs_review", prior_review=old["prior_review"],
                           review_note=old.get("review_note"))
                counts["kept_resign_pending"] += 1
            idx_to_drop.add(i)
            new_rows.append(row)
            counts["replaced_draft"] += 1
    if rerun:
        rr = {_chapter_key(k): _text(v) for k, v in rerun.items() if _text(v)}
        produced = {d.get("extraction_key") for d in drafts if d.get("extraction_key")}
        done = None if completed_sections is None else {str(s) for s in completed_sections}
        for j, r in enumerate(keep_rows):
            if j in idx_to_drop or r.get("review_status") not in ("draft", "needs_review"):
                continue
            if _text(r.get("prior_review")):
                continue                                  # carries a human decision: never superseded silently
            ch, h, k = _chapter_key(r.get("chapter")), _text(r.get("doc_hash")), _text(r.get("extraction_key"))
            if not k or k in produced or ch not in rr or h != rr[ch]:
                continue
            if done is not None and _text(r.get("section_id")) not in done:
                continue
            r["review_status"] = "superseded"
            r["review_note"] = (_text(r.get("review_note")) +
                                f" [superseded by run {run_id or '(unknown)'}: the latest extraction of this "
                                f"document version no longer produces this rule]").strip()
            counts["superseded"] += 1
    merged = [r for j, r in enumerate(keep_rows) if j not in idx_to_drop] + new_rows
    out = pd.DataFrame(merged, columns=cols)
    for b in _BOOL_FIELDS:
        out[b] = out[b].map(_flag).astype(bool)
    return out, counts


def upsert_seed_rows(existing: pd.DataFrame | None, seed_rows: list[dict]) -> tuple[pd.DataFrame, dict]:
    """D6: 02_migrate_state_rules used to OVERWRITE state_rules with the seed, deleting every
    extracted draft and every review. Now seeds are upserted: a seed row replaces only an
    existing legacy_hand_authored row with the same rule_id; everything else is kept.

    C4-05: a seed a reviewer has since decided in the workbook (approved / rejected) keeps that
    decision - re-running 02 never resets a signature (it used to raise on it).
    A legacy row the seed no longer produces (e.g. the three per-code CHW caps folded into one
    combined cap) is RETIRED, not left compiling: status 'superseded', its previous state kept
    in prior_review (audit trail, and the shrink guard still counts it)."""
    cols = STATE_RULE_COLUMNS
    if not seed_rows:
        # with retirement, an empty seed list would retire every legacy seed - that is a broken seed, not a request
        raise ValueError("upsert_seed_rows: no seed rows - refusing to retire every hand-authored seed")
    empty_counts = {"seeded": 0, "replaced_seed": 0, "kept_other": 0, "kept_signed_seed": 0, "retired_seed": 0}
    if existing is None or len(existing) == 0:
        out = pd.DataFrame(seed_rows, columns=cols)
        for b in _BOOL_FIELDS:
            out[b] = out[b].map(_flag).astype(bool)
        return out, dict(empty_counts, seeded=len(out))
    ex = _with_columns(existing)
    seed_ids = {r["rule_id"] for r in seed_rows}
    in_seed = ex["rule_id"].isin(seed_ids)
    st = ex["review_status"]
    # a seed retired by an earlier run that is back in state_seed.py is re-seeded
    replace = in_seed & st.isin(["legacy_hand_authored", "superseded"])
    signed = in_seed & st.isin(["approved", "rejected", "needs_review"]) & (ex["origin"].map(_text) == "manual") \
        & (ex["extraction_key"].map(_text) == "")
    clash = in_seed & ~replace & ~signed
    if clash.any():
        raise RuntimeError(f"seed rule_ids already exist with a non-seed status: "
                           f"{ex.loc[clash, ['rule_id', 'review_status']].to_dict('records')[:5]}")
    retire = (st == "legacy_hand_authored") & ~in_seed
    for i in ex.index[retire]:
        prior = dict(prior_from_row(ex.loc[i].to_dict()), retired_at=_now(),
                     retired_because="no longer produced by state_seed.seed_rules()")
        ex.at[i, "prior_review"] = json.dumps(prior, default=str)
        ex.at[i, "review_status"] = "superseded"
        ex.at[i, "review_note"] = (_text(ex.at[i, "review_note"]) +
                                   " [retired: state_seed.py no longer contains this rule; kept for audit]").strip()
    signed_ids = set(ex.loc[signed, "rule_id"])
    new_seed = [r for r in seed_rows if r["rule_id"] not in signed_ids]
    out = pd.concat([ex[~replace], pd.DataFrame(new_seed, columns=cols)], ignore_index=True)
    for b in _BOOL_FIELDS:
        out[b] = out[b].map(_flag).astype(bool)
    return out, {"seeded": len(new_seed), "replaced_seed": int(replace.sum()),
                 "kept_other": int((~replace & ~signed & ~retire).sum()), "kept_signed_seed": int(signed.sum()),
                 "retired_seed": int(retire.sum())}


# --------------------------------------------------------- review workbook
def _local_tmp(path: str) -> str:
    """A NEW local temp file named after `path`. 2026-10-03: the staging copy used to be <tmp>/<basename>, shared by
    every process on the machine - two notebooks exporting policy_rules_review.xlsx at once (a shared cluster driver;
    two test runs) could copy each other's workbook to their destination."""
    import tempfile
    fd, local = tempfile.mkstemp(prefix="pie_", suffix="_" + os.path.basename(path))
    os.close(fd)
    return local


def _xlsx_write(df: pd.DataFrame, path: str) -> str:
    """openpyxl seeks while writing, which a UC Volume (FUSE) rejects with
    OSError 95. So write to a private local file, then sequential-copy to the destination
    (sequential writes to a Volume are fine). Returns where the file actually is."""
    import shutil
    local = _local_tmp(path)
    df.to_excel(local, index=False, engine="openpyxl")
    try:
        shutil.copyfile(local, path)
    except OSError as e:
        print(f"  could not copy workbook to {path} ({e}); it is at {local}")
        return local
    os.remove(local)
    return path


def _xlsx_read(path: str) -> pd.DataFrame:
    """Read an .xlsx that may live on a UC Volume; fall back to a private local copy."""
    import shutil
    try:
        return pd.read_excel(path, engine="openpyxl")
    except OSError:
        local = _local_tmp(path)
        try:
            shutil.copyfile(path, local)
            return pd.read_excel(local, engine="openpyxl")
        finally:
            os.remove(local)


# Columns a reviewer types into. Everything else in the workbook is display only (edits are not read;
# an edited `predicate` cell parks the decision instead of silently signing the original).
CORRECTION_COLUMNS = ("corrected_rule", "corrected_predicate", "corrected_effective_date",
                      "corrected_end_date", "corrected_population")
EDITABLE_COLUMNS = ("decision", "reopen") + CORRECTION_COLUMNS + ("reviewer", "review_note")
REVIEW_LOG_COLUMNS = ["rule_id", "extraction_key", "origin", "decision", "corrected_rule", "corrected_predicate",
                      "corrected_effective_date", "corrected_end_date", "corrected_population",
                      "reviewer", "review_note", "ingested_at", "doc_hash_reviewed", "applied_outcome",
                      "approved_predicate_sha256", "decision_source", "previous_decision"]
# C4-13: every review-log column is text, whatever this batch's cells happen to hold
REVIEW_LOG_SCHEMA = {c: "string" for c in REVIEW_LOG_COLUMNS}
_STATUS_ORDER = {"needs_review": 0, "draft": 1, "legacy_hand_authored": 2}
# the review workbook, in column order (review_frame fills it)
WORKBOOK_COLUMNS = ["rule_id", "extraction_key", "chapter", "origin", "review_status", "policy_text_and_notes",
                    "proposed_rule", "predicate", "effective_date", "end_date", "population", "age", "scope",
                    "modifier_indicator", "exception", "discretionary", "citation", "source_url", "doc_hash",
                    "verbatim_quote", "confidence", "open_question", "previous_decision", "prior_review",
                    "status_note", "extraction_source", "decision", "reopen", "corrected_rule", "corrected_predicate",
                    "corrected_effective_date", "corrected_end_date", "corrected_population", "reviewer",
                    "review_note"]


def _pred_display(row: dict) -> dict:
    """C3-06: the parts of a predicate a reviewer must SEE to sign it (read-only workbook columns)."""
    import schema
    p = _json_obj(row.get("predicate"), {}) or {}
    p = p if isinstance(p, dict) else {}
    pair = p.get("type") == "code_pair_prohibited"
    origin = _text(row.get("origin")) or None
    if pair:
        mi = schema.normalize_indicator(p.get("modifier_indicator"), origin)
        mi = mi if mi is not None else f"INVALID ({p.get('modifier_indicator')!r})"
        scope = p.get("scope") or "not set -> member_provider_day (narrow default)"
    else:
        mi, scope = "", ""
    try:
        age = schema.age_label(p.get("age")) if p.get("age") else "all ages"
    except Exception:
        age = f"INVALID ({p.get('age')!r})"
    return {"age": age, "scope": scope, "modifier_indicator": mi, "exception": _text(p.get("exception")),
            "discretionary": "yes (text says MAY be denied)" if p.get("discretionary") is True else ""}


def review_frame(df: pd.DataFrame, statuses=PENDING_STATUS) -> pd.DataFrame:
    """The review workbook as a frame (export_review_workbook writes it). Display columns are read
    from the rule/predicate; the reviewer fills only EDITABLE_COLUMNS."""
    df = _with_columns(df)
    need = df[df["review_status"].isin(statuses)].copy()
    rows = []
    for r in need.to_dict("records"):
        disp = _pred_display(r)
        rows.append({
            "rule_id": r["rule_id"],
            "extraction_key": r["extraction_key"],
            "chapter": r["chapter"],
            # C4-05: 'manual' = a hand-authored seed (no doc_hash; the reviewer signs the seed text itself)
            "origin": r["origin"],
            "review_status": r["review_status"],
            "policy_text_and_notes": r["notes"],
            "proposed_rule": r["statement"],
            "predicate": r["predicate"],
            # C3-06: dates, population and the predicate's qualifiers were invisible to the reviewer
            "effective_date": _text(r["effective_date"]),
            "end_date": _text(r["end_date"]),
            "population": _text(r["population"]) or "all",
            **disp,
            "citation": f"{_text(r['source_doc'])} | {_text(r['source_locator'])}",
            "source_url": r["source_url"],
            "doc_hash": r["doc_hash"],                 # version the decision binds to (blank for a seed)
            "verbatim_quote": r["verbatim_quote"],
            "confidence": r["extraction_confidence"],
            "open_question": r["ambiguity_note"],
            # C4-04: the earlier human decision (who, when, WHICH predicate) - re-signing with a plain
            # Approve must not silently revert a Fix to the model's predicate. For a DECIDED row (an export
            # of decided rules, to change one with reopen = yes) it is the decision in force now.
            "previous_decision": (previous_decision_text(prior_from_row(r)) + " (in force)"
                                  if r["review_status"] in REOPENABLE_STATUS
                                  else previous_decision_text(r["prior_review"])),
            # D5: set when the source PDF changed after a decision; shows who decided what, on which version
            "prior_review": r["prior_review"],
            "status_note": r["review_note"],           # why a row is parked / sent back
            "extraction_source": r["extraction_source"],
            "decision": "",                 # Approve | Reject | Fix
            "reopen": "",                   # yes = change a row that is ALREADY approved / rejected (signed)
            "corrected_rule": "",           # Fix: corrected plain-English statement
            "corrected_predicate": "",      # Fix: corrected predicate as JSON (REQUIRED to change the executable rule)
            "corrected_effective_date": "",  # Fix: YYYY-MM-DD, or 'clear'
            "corrected_end_date": "",       # Fix: YYYY-MM-DD (inclusive), or 'clear'
            "corrected_population": "",     # Fix: e.g. 'members under 21' (state it in predicate.age to compile)
            "reviewer": "",
            "review_note": "",
        })
    out = pd.DataFrame(rows, columns=WORKBOOK_COLUMNS)       # an empty export still has the full layout
    if len(out):
        out["_s"] = out["review_status"].map(_STATUS_ORDER).fillna(9)
        out["_c"] = pd.to_numeric(out["confidence"], errors="coerce")
        out = out.sort_values(["_s", "_c"], na_position="last", kind="stable").drop(columns=["_s", "_c"])
    return out


def workbook_has_entries(path: str) -> tuple[bool, str]:
    """C4-11: does the workbook at `path` hold anything a reviewer typed? An unreadable file, or one
    that is not a review workbook, counts as YES (never overwrite what we cannot inspect)."""
    if not os.path.exists(path):
        return False, "no file"
    try:
        wb = _xlsx_read(path)
    except Exception as e:
        return True, f"unreadable ({type(e).__name__})"
    if "decision" not in wb.columns:
        return True, "not a review workbook (no decision column)"
    filled = [c for c in EDITABLE_COLUMNS if c in wb.columns and wb[c].map(lambda v: _text(v) != "").any()]
    return (True, "entries in " + ", ".join(filled)) if filled else (False, "no reviewer entries")


def _free_path(path: str) -> str:
    stem, ext = os.path.splitext(path)
    cand = f"{stem}_{datetime.now().strftime('%Y%m%dT%H%M%S')}{ext or '.xlsx'}"
    n = 2
    while os.path.exists(cand):
        cand = f"{stem}_{datetime.now().strftime('%Y%m%dT%H%M%S')}_{n}{ext or '.xlsx'}"
        n += 1
    return cand


def export_review_workbook(spark, table: str, path: str, statuses=PENDING_STATUS) -> str:
    """Rows needing a decision -> Excel. C4-05: hand-authored seeds (legacy_hand_authored) are exported
    too, so they can be signed - only with config.COMPILE_HAND_AUTHORED since 2026-10-04 (otherwise they are a v05
    checklist and never compile, so they are not exported). C4-11: a workbook at `path` that already holds any reviewer entry is
    NEVER overwritten - the export goes to policy_rules_review_<timestamp>.xlsx next to it instead
    (printed). Returns where the workbook was written."""
    full = spark.table(table).toPandas()
    import config as _cfg
    if not getattr(_cfg, "COMPILE_HAND_AUTHORED", False) and "origin" in full.columns:
        # 2026-10-04 (SB, fresh start): hand-authored rules are a checklist for v05, never compiled - asking a
        # reviewer to sign them would be wasted work (config.COMPILE_HAND_AUTHORED)
        n_manual = int((full["origin"].astype(str) == "manual").sum())
        full = full[full["origin"].astype(str) != "manual"]
        if n_manual:
            print(f"  {n_manual} hand-authored rule(s) not exported: a checklist for v05, never compiled "
                  f"(config.COMPILE_HAND_AUTHORED = False)")
    out = review_frame(full, statuses)
    target = path
    has, why = workbook_has_entries(path)
    if has:
        target = _free_path(path)
        print(f"  {path} already holds reviewer entries ({why}) - NOT overwritten. "
              f"This export -> {target}")
    written = _xlsx_write(out, target)
    by = out["review_status"].value_counts().to_dict() if len(out) else {}
    print(f"  exported {len(out)} rules for review {by} -> {written}")
    return written


def archive_workbook(path: str, archive_dir: str | None = None) -> str | None:
    """After a successful ingest (06): move the ingested workbook to review/ingested/ so the next export
    can use the standard path without overwriting a decided workbook (C4-11). The decisions themselves
    are in policy_review_log. Returns the archive path, or None if the move failed (then the next export
    simply goes to a timestamped file)."""
    import shutil
    if not os.path.exists(path):
        return None
    archive_dir = archive_dir or os.path.join(os.path.dirname(path) or ".", "ingested")
    stem, ext = os.path.splitext(os.path.basename(path))
    dest = os.path.join(archive_dir, f"{stem}_ingested_{datetime.now().strftime('%Y%m%dT%H%M%S')}{ext}")
    try:
        os.makedirs(archive_dir, exist_ok=True)
        try:
            os.replace(path, dest)
        except OSError:
            shutil.copyfile(path, dest)            # Workspace / Volume FUSE: copy, then remove
            os.remove(path)
        return dest
    except OSError as e:
        print(f"  could not archive {path} ({e}); it stays where it is - the next export will not overwrite it")
        return None


# ------------------------------------------------------------- review ingest
_ISO_DATE = re.compile(r"^(\d{4}-\d{2}-\d{2})(?:[ T]00:00(?::00)?)?$")
_CLEAR = ("clear", "none", "null", "-")


def _date_cell(v) -> tuple[bool, str | None, str | None]:
    """A corrected_*_date cell -> (provided, ISO value or None for 'clear', error)."""
    if isinstance(v, str) and v.strip().lower() in _CLEAR:
        return True, None, None
    if _is_null(v) or (isinstance(v, str) and not v.strip()):
        return False, None, None
    if isinstance(v, (datetime, date, pd.Timestamp)):          # Excel turns a typed date into a datetime
        ts = pd.Timestamp(v)
        if ts.hour or ts.minute or ts.second:
            return True, None, f"{v!r} has a time of day; give a date (YYYY-MM-DD)"
        return True, ts.date().isoformat(), None
    m = _ISO_DATE.match(str(v).strip())
    if not m:
        return True, None, f"{v!r} is not an ISO date (YYYY-MM-DD)"
    try:
        return True, date.fromisoformat(m.group(1)).isoformat(), None
    except ValueError:
        return True, None, f"{v!r} is not a real date"


def _differs_from_fix(prior: dict, row: dict) -> list[str]:
    """What a plain Approve would revert, when the previous decision was a Fix (C4-04)."""
    out = []
    if prior.get("predicate") is not None and \
            canonical_predicate(prior["predicate"]) != canonical_predicate(_json_obj(row.get("predicate"), {})):
        out.append("predicate")
    for k in ("effective_date", "end_date"):
        if _text(prior.get(k)) != _text(row.get(k)):
            out.append(k)
    if (_text(prior.get("population")) or "all").lower() != (_text(row.get("population")) or "all").lower():
        out.append("population")
    return out


def _reopen_unchanged(row: dict, rec: dict, decision: str) -> bool:
    """A reopen = yes decision that would leave a decided row exactly as it is (same status, predicate,
    statement, window, population) - e.g. the same signed workbook ingested twice. Nothing is changed."""
    st = _text(row.get("review_status"))
    if decision == "reject":
        return st == "rejected"
    if st != "approved":
        return False
    if decision == "approve":
        return not any(_text(rec.get(c)) for c in CORRECTION_COLUMNS)
    cp = _text(rec.get("corrected_predicate"))
    if cp:
        try:
            if canonical_predicate(json.loads(cp)) != canonical_predicate(row.get("predicate")):
                return False
        except (TypeError, ValueError):
            return False
    stmt = _text(rec.get("corrected_rule"))
    if stmt and stmt != _text(row.get("statement")):
        return False
    for col, field in (("corrected_effective_date", "effective_date"), ("corrected_end_date", "end_date")):
        given, val, err = _date_cell(rec.get(col))
        if given and (err or (val or "") != _text(row.get(field))):
            return False
    pop = rec.get("corrected_population")
    if _text(pop):
        want = "all" if str(pop).strip().lower() in _CLEAR else _text(pop)
        if want.lower() != (_text(row.get("population")) or "all").lower():
            return False
    return True


def _fields_for(pred: dict) -> list[str]:
    from extract_rules import _FIELDS_BY_TYPE
    f = list(_FIELDS_BY_TYPE.get(pred.get("type"), []))
    if pred.get("age") and "dob" not in f:
        f.append("dob")                                  # an age condition reads the member's date of birth
    return f


def ingest_review_decisions(spark, table: str, path: str, log_table: str) -> dict:
    """Apply the decisions of a filled review workbook. Returns {"applied": counts, "outcomes": [...],
    "ai_prereview_notes": n} ({} when the workbook holds no decision)."""
    filled = _xlsx_read(path)
    if "decision" not in filled.columns:
        print(f"  {path} has no 'decision' column - not a review workbook")
        return {}
    filled["decision"] = filled["decision"].map(_text).str.lower()
    filled = filled[filled["decision"].isin(["approve", "reject", "fix"])].copy()
    if filled.empty:
        print("  no decisions found in workbook")
        return {}
    for c in ("extraction_key", "reviewer", "review_note", "doc_hash", "predicate", "reopen") + CORRECTION_COLUMNS:
        if c not in filled.columns:
            filled[c] = None
    filled["ingested_at"] = _now()

    from validate_gate import _codes_from_predicate
    import schema
    df = _with_columns(spark.table(table).toPandas())
    # a column that is all-null in the table comes back as float64; assigning a reviewer name or a
    # status into it raises on pandas >= 3 (and warns on 2.x). Text columns are object, always.
    for c in STATE_RULE_COLUMNS:
        if c not in _BOOL_FIELDS and c != "extraction_confidence":
            df[c] = df[c].astype(object).where(df[c].notna(), None)
    applied = {"approve": 0, "reject": 0, "fix": 0, "fix_deferred": 0, "unmatched": 0,
               "no_reviewer": 0, "stale_version": 0, "not_pending": 0,
               # C3-10 / C4-04 / C4-12: an approval binds to a VALID predicate, the one the reviewer saw,
               # and never silently reverts an earlier Fix
               "invalid_predicate": 0, "approve_reverts_fix": 0, "predicate_mismatch": 0,
               "corrections_need_fix": 0,
               # reopen = yes on a decided row: re-decided / refused (no name, other doc version) / no change
               "reopened": 0, "reopen_refused": 0, "unchanged": 0}
    outcome: list[str] = []
    log_extra: list[dict] = []
    for rec in filled.to_dict("records"):
        m = df["rule_id"] == rec["rule_id"]
        extra = {"approved_predicate_sha256": None, "decision_source": DECISION_SOURCE, "origin": None,
                 "previous_decision": None}
        log_extra.append(extra)
        if not m.any():
            applied["unmatched"] += 1
            outcome.append("unmatched")
            continue
        row = df.loc[m].iloc[0].to_dict()
        extra["origin"] = _text(row.get("origin")) or None
        extra["previous_decision"] = previous_decision_text(row.get("prior_review")) or None
        decision = rec["decision"]
        # C4-12: the note is kept as given (an "AI pre-review:" prefix is how an AI-prefilled note stays
        # distinguishable from a human one); only an empty cell (NaN) becomes "" instead of 'nan'
        note = _text(rec.get("review_note"))
        reviewer = _text(rec.get("reviewer"))
        cur_status = row["review_status"]
        is_seed = cur_status == "legacy_hand_authored"
        origin = _text(row.get("origin")) or None
        reopening = False

        def park(key: str, label: str, msg: str):
            # a parked draft waits as needs_review; a parked SEED - or a decided row being reopened - keeps
            # its status (an unapplied decision has no authority to switch a compiling rule off, or to
            # un-reject one); all carry the reason in review_note
            if reopening:
                df.loc[m, "review_note"] = (_text(row.get("review_note")) + f" [reopen not applied: {msg}]").strip()
            else:
                df.loc[m, "review_status"] = cur_status if is_seed else "needs_review"
                df.loc[m, "review_note"] = (note + f" [{msg}]").strip()
            applied[key] += 1
            outcome.append(label)

        # F07: a decision needs a named human. An unsigned approve/reject/fix is not
        # applied; it is parked so the workbook can be completed and re-imported.
        if cur_status not in PENDING_STATUS:
            # D6: an old workbook re-imported must not flip a row that has since been decided. A reviewer who
            # means to CHANGE a decided rule says so on the row (reopen = yes) and signs it.
            if not (cur_status in REOPENABLE_STATUS and _flag(rec.get("reopen"))):
                applied["not_pending"] += 1
                outcome.append(f"ignored: row is {cur_status}, not pending review")
                continue
            wb_hash, cur_hash = _text(rec.get("doc_hash")), _text(row.get("doc_hash"))
            if not reviewer or (cur_hash and wb_hash != cur_hash):
                applied["reopen_refused"] += 1
                outcome.append("reopen refused: " + ("reviewer name required" if not reviewer else
                                                    f"workbook is for doc {wb_hash[:8]}, rule is from doc "
                                                    f"{cur_hash[:8]}"))
                continue
            if _reopen_unchanged(row, rec, decision):
                applied["unchanged"] += 1
                outcome.append(f"unchanged: already {cur_status} this way")
                continue
            reopening = True
            applied["reopened"] += 1
            extra["previous_decision"] = previous_decision_text(prior_from_row(row)) or None
        if not reviewer:
            park("no_reviewer", "no_reviewer", "decision not applied: reviewer name required")
            continue
        # F07: the decision binds to the document version the reviewer saw. If the
        # rule has been re-extracted from a newer PDF since the export, park it.
        wb_hash = _text(rec.get("doc_hash"))
        cur_hash = _text(row.get("doc_hash"))
        # D5/D6: a row that HAS a document version must be decided against that version. A blank
        # workbook hash (column deleted / cleared) used to skip the check entirely.
        # C4-05: a seed has no doc_hash, so there is no version to check - it is signed as written.
        if cur_hash and wb_hash != cur_hash:
            park("stale_version", "stale_version", f"decision not applied: reviewed doc {wb_hash[:8]} "
                 f"but current rule is from doc {cur_hash[:8]}; re-review")
            continue
        corrections = [c for c in CORRECTION_COLUMNS if _text(rec.get(c))]
        cp_given = bool(_text(rec.get("corrected_predicate")))
        # C4-12: an approval binds to the predicate the reviewer SAW. An edited `predicate` cell used to be
        # ignored - the original predicate was signed while the reviewer believed they signed their edit.
        if decision != "reject" and not (decision == "fix" and cp_given) and _text(rec.get("predicate")):
            try:
                same = canonical_predicate(rec["predicate"]) == canonical_predicate(row["predicate"])
            except (TypeError, ValueError):
                same = False
            if not same:
                park("predicate_mismatch", "predicate_mismatch",
                     "decision not applied: the workbook's predicate cell differs from the rule's predicate; "
                     "to change the executable rule use Fix with corrected_predicate")
                continue

        if decision == "approve":
            if corrections:
                park("corrections_need_fix", "corrections_need_fix",
                     f"decision not applied: {', '.join(corrections)} filled with Approve - corrections are "
                     f"applied only with decision Fix")
                continue
            pred = _json_obj(row.get("predicate"), None)
            ok, why = schema.validate_predicate(pred, strict_reason=True, origin=origin)
            if not ok:
                # C3-10: the approve path used to sign any predicate, valid or not
                park("invalid_predicate", "invalid_predicate",
                     f"approve refused: the rule's predicate is invalid: {why}; use Fix with a valid "
                     f"corrected_predicate")
                continue
            prior = _json_obj(row.get("prior_review"), {}) or {}
            if isinstance(prior, dict) and prior.get("decision") == "fix":
                diff = _differs_from_fix(prior, row)
                if diff:
                    park("approve_reverts_fix", "approve_reverts_fix",
                         f"approve refused: the previous decision was a Fix ({previous_decision_text(prior)}); "
                         f"Approve would sign the new extraction instead ({', '.join(diff)} differ). Use Fix: "
                         f"copy the earlier correction from previous_decision to keep it, or enter the new "
                         f"predicate to accept the change")
                    continue
            sha = predicate_sha256(row["predicate"])
            if is_seed or reopening:
                df.loc[m, "prior_review"] = json.dumps(prior_from_row(row), default=str)
            df.loc[m, "review_status"] = "approved"
            df.loc[m, "review_note"] = note
            df.loc[m, "reviewer"] = reviewer
            df.loc[m, "reviewed_at"] = rec["ingested_at"]
            df.loc[m, "review_decision"] = "approve"
            df.loc[m, "approved_predicate_sha256"] = sha
            df.loc[m, "decision_source"] = DECISION_SOURCE
            extra["approved_predicate_sha256"] = sha
            applied["approve"] += 1
            outcome.append("approved")
            continue
        if decision == "reject":
            if is_seed or reopening:
                df.loc[m, "prior_review"] = json.dumps(prior_from_row(row), default=str)
            df.loc[m, "review_status"] = "rejected"
            df.loc[m, "review_note"] = note
            df.loc[m, "reviewer"] = reviewer
            df.loc[m, "reviewed_at"] = rec["ingested_at"]
            df.loc[m, "review_decision"] = "reject"
            df.loc[m, "approved_predicate_sha256"] = None
            df.loc[m, "decision_source"] = DECISION_SOURCE
            applied["reject"] += 1
            outcome.append("rejected")
            continue

        # decision == "fix": the PREDICATE is what compiles, so a fix must correct the
        # predicate — not just the prose. A prose-only fix must NOT silently approve the
        # old (wrong) predicate; it is parked as needs_review until a predicate is given.
        # C3-06: a Fix may instead correct only the window / population (corrected_predicate blank);
        # then the EXISTING predicate is what gets signed, so it must still validate.
        eff_p, eff_v, eff_err = _date_cell(rec.get("corrected_effective_date"))
        end_p, end_v, end_err = _date_cell(rec.get("corrected_end_date"))
        pop_raw = rec.get("corrected_population")
        pop_p = bool(_text(pop_raw)) or (isinstance(pop_raw, str) and pop_raw.strip().lower() in _CLEAR)
        pop_v = "all" if (isinstance(pop_raw, str) and pop_raw.strip().lower() in _CLEAR) else _text(pop_raw)
        new_pred = None
        if cp_given:
            try:
                new_pred = json.loads(_text(rec.get("corrected_predicate")))
            except (TypeError, ValueError):
                new_pred = None
            if not isinstance(new_pred, dict):
                park("fix_deferred", "fix_deferred", "fix needs a valid corrected_predicate JSON; "
                     "prose alone cannot change the executable rule")
                continue
        elif not (eff_p or end_p or pop_p):
            park("fix_deferred", "fix_deferred", "fix needs a valid corrected_predicate JSON (or corrected "
                 "dates / population); prose alone cannot change the executable rule")
            continue
        if eff_err or end_err:
            park("fix_deferred", "fix_deferred", f"fix rejected: invalid corrected date: {eff_err or end_err}")
            continue
        signed_pred = new_pred if new_pred is not None else _json_obj(row.get("predicate"), None)
        ok, why = schema.validate_predicate(signed_pred, strict_reason=True, origin=origin)
        if not ok:
            park("fix_deferred", "fix_deferred",
                 (f"fix rejected: invalid corrected_predicate: {why}" if new_pred is not None else
                  f"fix rejected: the rule's predicate is invalid ({why}); give a corrected_predicate"))
            continue
        eff = eff_v if eff_p else (_text(row.get("effective_date")) or None)
        end = end_v if end_p else (_text(row.get("end_date")) or None)
        if eff and end and end < eff:
            park("fix_deferred", "fix_deferred", f"fix rejected: end_date {end} is before effective_date {eff}")
            continue
        if is_seed or reopening:
            df.loc[m, "prior_review"] = json.dumps(prior_from_row(row), default=str)
        corr_stmt = _text(rec.get("corrected_rule"))
        if corr_stmt:
            df.loc[m, "statement"] = corr_stmt
        changed = []
        # F07: everything DERIVED from the predicate is re-derived, so `codes`,
        # required fields and the grounding record never describe the old predicate.
        # A predicate that names no code (not_checkable: 69 of the first run's 146 fixes only relabelled
        # its reason) derives no codes - the lead's codes come from the text, and wiping them dropped the
        # lead from every per-code lookup and coverage count. They are kept.
        derived = _codes_from_predicate(signed_pred)
        df.loc[m, "codes"] = json.dumps(derived if derived else (_json_obj(row.get("codes"), []) or []))
        df.loc[m, "required_claim_fields"] = json.dumps(_fields_for(signed_pred))
        if new_pred is not None:
            compiled = new_pred.get("type") in schema.PREDICATE_TYPES_COMPILED
            old_pred_json = row["predicate"]
            df.loc[m, "predicate"] = json.dumps(new_pred, default=str)
            df.loc[m, "machine_checkable"] = compiled
            df.loc[m, "not_checkable_reason"] = None if compiled else new_pred.get("reason")
            if "grounding" in df.columns:
                df.loc[m, "grounding"] = json.dumps({"superseded_by_reviewer": True, "reviewer": reviewer,
                                                     "original_predicate": old_pred_json}, default=str)
            changed.append("predicate corrected by reviewer")
        # (a window/population-only Fix keeps machine_checkable as it was: the reviewer did not
        # change what the rule checks, only when / for whom)
        if eff_p:
            df.loc[m, "effective_date"] = eff
            changed.append(f"effective_date {eff or 'cleared'}")
        if end_p:
            df.loc[m, "end_date"] = end
            changed.append(f"end_date {end or 'cleared'}")
        if pop_p:
            df.loc[m, "population"] = pop_v
            changed.append(f"population {pop_v}")
        sha = predicate_sha256(df.loc[m, "predicate"].iloc[0])
        df.loc[m, "review_status"] = "approved"
        df.loc[m, "reviewer"] = reviewer
        df.loc[m, "reviewed_at"] = rec["ingested_at"]
        df.loc[m, "review_decision"] = "fix"
        df.loc[m, "approved_predicate_sha256"] = sha
        df.loc[m, "decision_source"] = DECISION_SOURCE
        df.loc[m, "review_note"] = (note + f" [{'; '.join(changed)}; codes/fields re-derived]").strip()
        extra["approved_predicate_sha256"] = sha
        applied["fix"] += 1
        outcome.append("fixed")

    filled["applied_outcome"] = outcome
    filled["doc_hash_reviewed"] = filled["doc_hash"]
    for k in ("approved_predicate_sha256", "decision_source", "origin", "previous_decision"):
        filled[k] = [e[k] for e in log_extra]
    # empty Excel columns read as float64 -> the log would be created with DOUBLE columns and the
    # first real note would fail the Delta append with a type conflict. Log text is text (C4-13:
    # and the write pins it with REVIEW_LOG_SCHEMA).
    log = pd.DataFrame({c: filled[c].map(_log_text) if c in filled.columns else None for c in REVIEW_LOG_COLUMNS})
    from kb_io import write_table
    from extract_io import guard_state_rules_merge
    before = spark.table(table).toPandas()
    guard_state_rules_merge(before, df, table)
    # D6: table first, THEN the log - a failed table write must not leave a log saying "approved"
    write_state_rules(spark, table, df.to_dict("records"))
    write_table(spark, log, log_table, mode="append", schema=REVIEW_LOG_SCHEMA)
    ai = int(filled["review_note"].map(lambda v: _text(v).startswith(AI_PREREVIEW_PREFIX)).sum())
    print(f"  applied decisions {applied}; log -> {log_table}"
          + (f"; {ai} decision(s) carried an '{AI_PREREVIEW_PREFIX}' note" if ai else ""))
    return {"applied": applied, "outcomes": outcome, "ai_prereview_notes": ai}


# review_note fragment -> why a row is waiting (06 prints the backlog by reason). First match wins.
_PARKED_PATTERNS = (
    ("reviewer name required", "no_reviewer"),
    ("but current rule is from doc", "stale_version (workbook from an older document version)"),
    ("previous decision was a Fix", "approve_reverts_fix"),
    ("predicate cell differs", "predicate_mismatch (edited predicate cell; use Fix)"),
    ("applied only with decision Fix", "corrections_need_fix"),
    ("the rule's predicate is invalid", "invalid_predicate"),
    ("invalid corrected_predicate", "invalid_corrected_predicate"),
    ("invalid corrected date", "invalid_corrected_date"),
    ("is before effective_date", "invalid_corrected_date"),
    ("fix needs a valid corrected_predicate", "fix_without_predicate"),
    ("source document changed", "resign_new_version"),
    ("was REJECTED before", "rejected_quote_seen"),
)


def parked_reason(note) -> str:
    """Why a needs_review row is waiting, from its review_note."""
    t = _text(note)
    for frag, why in _PARKED_PATTERNS:
        if frag in t:
            return why
    return "other"


def _log_text(v):
    """A log cell as text (None stays None). Dates typed into Excel come back as Timestamps."""
    if _is_null(v):
        return None
    if isinstance(v, (pd.Timestamp, datetime, date)):
        ts = pd.Timestamp(v)
        return ts.date().isoformat() if not (ts.hour or ts.minute or ts.second) else ts.isoformat()
    return str(v)
