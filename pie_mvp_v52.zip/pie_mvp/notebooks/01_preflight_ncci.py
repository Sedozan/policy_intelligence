# Databricks notebook source
# MAGIC %md
# MAGIC # NCCI pre-flight — answer the questions the ingest and the detectors currently ASSUME
# MAGIC
# MAGIC Run once before the first `07_build_kb` after Phase 1.5, and again whenever a new NCCI quarter lands.
# MAGIC Read-only: no tables are written. Prints a go / no-go with the evidence.
# MAGIC
# MAGIC | # | question | why it matters |
# MAGIC |---|---|---|
# MAGIC | 1 | Are the MUE quarters **contiguous** per service? | `mue_history` now refuses a gap (it used to carry the old value across it silently). |
# MAGIC | 2 | Do **older PTP quarters hold pairs absent from the newest**? | The ingest loads only the latest PTP file per service, assuming it is cumulative. If CMS drops old deleted edits, historical claims lose them. |
# MAGIC | 3 | Do the loaded quarters **cover the claims date range**? | A MUE's effective date is the first quarter *you loaded*; claims before it are unchecked. |
# MAGIC | 4 | How often do **editions disagree** on the same code / pair? | Decides the collapse policy (open decision #3) and whether F03 interval-split is worth building. |
# MAGIC | 5 | Any **negative-amount paid lines**? | Closes F09 (paid-only table) fully. *Now part of F.* |
# MAGIC | A | Which **FORM_TYP** values are in the claims, and which of them does NCCI apply to? | C2-01/C2-02: NCCI does not apply to dental (D), pharmacy (C), inpatient / LTC (I, L); an unmapped form value gets no edits. |
# MAGIC | B | Do the claims run **past the newest loaded quarter**? | C2-14: the newest table is carried forward open-ended; later claims keep edits CMS deleted and miss new ones. |
# MAGIC | C | Did the **modifier indicator change** for the same pair and effective date between the oldest and newest PTP quarter? | C2-12: latest-only loading applies today's indicator to every past date of service (1→0 = false hard denials). |
# MAGIC | D | Did an **MUE go up, or disappear**, in a later quarter? | C2-03: public files are undated snapshots; a retroactive raise or deletion is enforced at the old, stricter value. |
# MAGIC | E | How many PTP pairs / MUE codes exist in **one edition only** (among paid codes)? | C2-02: an edition-only edit applied to a form whose route does not include that edition is a false positive. |
# MAGIC | F | **Data shape** of the claims: $0 / negative paid, non-positive units, duplicate line keys, blank member / provider, un-normalised codes / modifiers, date of birth, placeholder members | C1-01..05: each one manufactures false findings or silently drops lines in the detectors. |
# MAGIC | T | Which **AHCCCS rule table versions** (Same Day Disallow, Daily Limits, B2 Matrix) are loaded (`00b`), which dates each judges, how many claim lines fall in each, does each table still hold exactly what `00b` loaded, are the claims past a version's expected life, and would `07` compile them (every reading signed, every bound config value as signed)? | v5.2: a version judges only its own window; claims before the oldest loaded version are not judged by the table; an unsigned table compiles nothing; v5.2b: a row deleted / edited / added in a table outside `00b` FAILs here and stops `07`. |
# MAGIC
# MAGIC Every check runs in its own `try`: a check that cannot run prints **WARN** with the error and the rest go on.
# MAGIC The notebook raises **only when an NCCI table cannot be read**. A FAIL (e.g. an MUE quarter gap, which
# MAGIC `07_build_kb` refuses) or WARN is printed in the summary for you to act on; it does not stop a Job.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook's folder or its parent must contain config.py.
# No hard-coded workspace path; set PKB_PACKAGE_DIR if you keep the notebooks elsewhere.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; run this notebook from inside the pie_mvp folder "
                      f"or set PKB_PACKAGE_DIR")

import importlib, re
import pandas as pd
import config, ingest_ncci_tables as ing, acquire_ncci as acq, preflight_sql as pq
for m in (config, ing, acq, pq):
    importlib.reload(m)

CAT, SCH = config.CATALOG, config.SCHEMA
CLAIMS = config.CLAIMS_TABLE
C = config.CLAIM_COLS
DOS = C["dos"]
PAID = C["paid_amt"]
fc = ing._find_col

# ---- check bookkeeping: one summary row per check, status = the worst line it printed
_RANK = {"PASS": 0, "WARN": 1, "FAIL": 2}
RESULTS: list = []
_cur: dict = {}


def _line(status, msg, minor=False):
    print(f"  {status:5s} {msg}")
    if _RANK[status] > _RANK[_cur["status"]]:
        _cur["status"] = status
    if status != "PASS":
        _cur["msgs"].append((-_RANK[status], minor, msg))


def info(msg):              print(f"  info  {msg}")
def ok(msg):                _line("PASS", msg)
def warn(msg, minor=False): _line("WARN", msg, minor)     # minor: "cannot be sized here", not a finding
def fail(msg):              _line("FAIL", msg)


def run(cid, title, fn):
    global _cur
    _cur = {"id": cid, "check": title, "status": "PASS", "first": "", "msgs": []}
    print(f"\n{cid}. {title}")
    try:
        fn()
    except Exception as e:                                   # a check that cannot run never stops the others
        warn(f"check could not run: {type(e).__name__}: {str(e)[:400]}")
    # the summary shows the most serious line: FAIL before WARN, a finding before a "cannot be sized"
    _cur["first"] = sorted(_cur["msgs"], key=lambda t: (t[0], t[1]))[0][2] if _cur["msgs"] else ""
    print(f"  => {_cur['status']}  [{cid}] {title}")
    RESULTS.append({k: v for k, v in _cur.items() if k != "msgs"})


# ---- NCCI tables: discover, then prove each one can be read (the ONLY condition that fails this notebook)
metas = ing.discover_tables(spark, CAT, SCH)
assert metas, f"no medicaid_ncci_edit_* tables in {CAT}.{SCH}"
TYPES, UNREADABLE = {}, {}
for m in metas:
    try:
        sdf = spark.table(m["fqn"])
        TYPES[m["fqn"]] = {f.name: f.dataType.simpleString() for f in sdf.schema.fields}
        sdf.limit(1).collect()
    except Exception as e:
        UNREADABLE[m["fqn"]] = f"{type(e).__name__}: {str(e)[:300]}"
by = {}
for m in metas:
    if m["fqn"] not in UNREADABLE:
        by.setdefault((m["service"], m["edit_type"]), []).append(m)
for k in by:
    by[k].sort(key=ing.quarter_sort_key)

try:
    CLAIM_TYPES = {f.name: f.dataType.simpleString() for f in spark.table(CLAIMS).schema.fields}
except Exception as e:
    CLAIM_TYPES = {}
    print(f"WARNING: cannot read the schema of {CLAIMS}: {type(e).__name__}: {str(e)[:300]}")


def ctype(col, default="string"):
    """Spark type of a claims column (case-insensitive, as Spark resolves names); None if absent."""
    if not CLAIM_TYPES:
        return default
    for k, v in CLAIM_TYPES.items():
        if k.lower() == str(col).lower():
            return v
    return None


def ptp_src(m):
    return pq.ptp_source(m["fqn"], TYPES[m["fqn"]], fc, m["service"])


def mue_src(m, qi=0):
    return pq.mue_source(m["fqn"], TYPES[m["fqn"]], fc, m["service"], qi)


print("loaded tables:")
for (svc, et), ms in sorted(by.items()):
    print(f"  {svc:12s} {et}  {[m['label'] for m in ms]}")


def _c0():
    for fqn, err in UNREADABLE.items():
        fail(f"cannot read {fqn}: {err}")
    if not UNREADABLE:
        ok(f"all {len(metas)} NCCI tables readable")


run("0", "NCCI tables readable", _c0)

# COMMAND ----------

# MAGIC %md ## 1. Quarter contiguity (MUE is the one that matters; PTP is informational)

# COMMAND ----------


def _c1():
    for (svc, et), ms in sorted(by.items()):
        gaps = ing.quarter_gaps(ms)
        if not gaps:
            ok(f"{svc} {et}: contiguous {ms[0]['label']}..{ms[-1]['label']}")
        elif et == "mue":
            fail(f"{svc} mue: missing quarter(s) starting {gaps} - 07_build_kb refuses; load them, or set "
                 f"config.NCCI_ALLOW_MUE_GAPS=True (runs spanning a gap are then flagged ambiguous)")
        else:
            info(f"{svc} ptp: quarters {gaps} not loaded (harmless if check 2 is clean)")


run("1", "MUE quarter contiguity", _c1)

# COMMAND ----------

# MAGIC %md ## 2. PTP: does the newest file still contain every pair the oldest one had?

# COMMAND ----------


def _c2():
    for (svc, et), ms in sorted(by.items()):
        if et != "ptp":
            continue
        if len(ms) < 2:
            warn(f"{svc} ptp: only {ms[0]['label']} loaded - the latest-only assumption is untestable; "
                 f"load an older quarter to check", minor=True)
            continue
        old, new = ms[0], ms[-1]
        summary, examples = pq.sql_ptp_dropout(ptp_src(old), ptp_src(new))
        r = spark.sql(summary).collect()[0]
        if not r.n_miss:
            ok(f"{svc} ptp: {old['label']} ({r.n_old:,} pairs) is fully contained in {new['label']} ({r.n_new:,}) "
               f"- latest-only is safe")
        else:
            sample = [f"{x.a}/{x.b}" for x in spark.sql(examples).collect()]
            warn(f"{svc} ptp: {r.n_miss:,} pairs in {old['label']} are ABSENT from {new['label']} (e.g. {sample}). "
                 f"Historical claims lose these edits under latest-only loading; ingest should union all quarters "
                 f"by (pair, EffDt).")


run("2", "PTP cumulative-file assumption", _c2)

# COMMAND ----------

# MAGIC %md ## 3 / B. Date coverage: first loaded quarter vs the oldest claims, newest loaded quarter vs the newest claims

# COMMAND ----------

_DATES = {}


def claims_dates():
    """One scan of the claims for checks 3 and B (cached)."""
    if not _DATES:
        firsts = sorted({pd.Timestamp(ms[0]["starts"]).date() for (svc, et), ms in by.items() if et == "mue"})
        ends = sorted({acq.quarter_end(ms[-1]["year"], ms[-1]["quarter"]) for ms in by.values()})
        r = spark.sql(pq.sql_claims_dates(CLAIMS, C, firsts, ends, ctype(DOS, "date") or "date")).collect()[0].asDict()
        _DATES.update({"lo": r["lo"], "hi": r["hi"], "n": r["n"], "no_dos": r["no_dos"],
                       "before": {d: r[f"before_{i}"] for i, d in enumerate(firsts)},
                       "after": {d: r[f"after_{i}"] for i, d in enumerate(ends)}})
    return _DATES


def _c3():
    d = claims_dates()
    info(f"claims: {d['n']:,} lines, DOS {d['lo']} .. {d['hi']}")
    if d["no_dos"]:
        warn(f"{d['no_dos']:,} claim lines have no usable date of service ({DOS}) - no dated edit can apply to them")
    for (svc, et), ms in sorted(by.items()):
        first = pd.Timestamp(ms[0]["starts"]).date()
        if et == "mue":
            unchecked = d["before"].get(first) or 0
            if unchecked:
                warn(f"{svc} mue: earliest loaded quarter starts {first}; {unchecked:,} claim lines are dated before it "
                     f"and get NO MUE check (label this in the run, or load earlier quarters)")
            else:
                ok(f"{svc} mue: earliest quarter {first} covers the whole claims range")
        else:
            m = ms[-1]
            c_eff = fc(list(TYPES[m["fqn"]]), "effective date", "effdt")
            if c_eff:
                e = spark.sql(f"SELECT MIN({pq.ymd_expr(c_eff, TYPES[m['fqn']][c_eff])}) AS lo FROM {m['fqn']}").collect()[0].lo
                info(f"{svc} ptp: earliest EffDt in {m['label']} = {e} (per-pair dates; coverage is by pair, not by file)")


run("3", "Date coverage: oldest claims vs first loaded quarter", _c3)


def _cB():
    d = claims_dates()
    if d["hi"] is None:
        warn("the claims table has no usable date of service - nothing to compare")
        return
    for (svc, et), ms in sorted(by.items()):
        newest = ms[-1]
        end = acq.quarter_end(newest["year"], newest["quarter"])
        after = d["after"].get(end) or 0
        if after:
            warn(f"{svc} {et}: claims run to {d['hi']} but the newest loaded quarter {newest['label']} ends {end}: "
                 f"{after:,} lines are judged by {newest['label']} carried forward (edits CMS deleted since stay live, "
                 f"edits it added are missing) - load the next quarter, or label those findings (C2-14)")
        else:
            ok(f"{svc} {et}: newest quarter {newest['label']} (to {end}) covers the newest claims ({d['hi']})")


run("B", "Date coverage: newest claims vs newest loaded quarter (C2-14)", _cB)

# COMMAND ----------

# MAGIC %md ## 4. Edition disagreement (decides the collapse policy and F03)

# COMMAND ----------


def _c4():
    mue_latest = [mue_src(ms[-1]) for (svc, et), ms in sorted(by.items()) if et == "mue"]
    if len(mue_latest) > 1:
        summary, top = pq.sql_mue_disagreement(mue_latest, CLAIMS, C)
        dis = spark.sql(summary).collect()[0]
        info(f"MUE: {dis.codes_in_multiple_editions:,} codes in >1 edition; {dis.codes_disagreeing:,} disagree on the "
             f"limit; those codes carry {dis.disagreeing_claim_lines or 0:,} paid lines / "
             f"${float(dis.disagreeing_paid_dollars or 0):,.0f}")
        for r in spark.sql(top).collect():
            print(f"      {r.code}: {r.by_edition}")
        if not dis.codes_disagreeing:
            ok("MUE editions never disagree -> collapse policy and F03 are moot for MUE")
        else:
            warn("MUE editions disagree: most-permissive collapse MISSES violations on those codes; "
                 "the same codes are where F03 (unequal windows) can bite. Decide policy with these numbers.")
    else:
        info("only one MUE edition loaded - no cross-edition disagreement possible")
    ptp_latest = [ptp_src(ms[-1]) for (svc, et), ms in sorted(by.items()) if et == "ptp"]
    if len(ptp_latest) > 1:
        d = spark.sql(pq.sql_ptp_disagreement(ptp_latest)).collect()[0]
        info(f"PTP: {d.pairs_multi:,} pairs in >1 edition; {d.pairs_disagree or 0:,} disagree on modifier indicator")


run("4", "Edition disagreement, latest quarter per service", _c4)

# COMMAND ----------

# MAGIC %md ## A. Which NCCI edit file each claim line takes — provider type × claim form (CMS TGM Table 2)
# MAGIC Every (FORM_TYP, BILLING provider type, servicing provider type) in the claims, with the edit file its lines take.
# MAGIC CMS applies NCCI to "claims from" a type of provider (TGM §5.3/5.5), so the billing type picks the Table 2 row; the
# MAGIC servicing type only says whether a rendering practitioner is identified (the 'Other providers' row on a CMS-1500).
# MAGIC Read the description columns to check the mapping (`reference/ncci_provider_type_routing.csv`); the codes decide.

# COMMAND ----------


def _cA():
    import ncci_routing
    fmap = getattr(config, "FORM_TYPE_MAP", {}) or {}
    sm = ncci_routing.summary()
    tbl = ncci_routing.uses_table()
    billing_mode = sm["mode"] == "billing_provider_type"
    info(f"routing: {sm['mode']}" + (f" ({sm['table']}: {sm['types_mapped']} provider types, {sm['types_signed']} "
                                     f"signed; optional Table 2 rows on: {sm['optional_on'] or 'none'}; unmapped type -> "
                                     f"{sm['unmapped_provider_type']})" if tbl else ""))
    if tbl and sm["types_signed"] < sm["types_mapped"]:
        warn(f"the provider-type routing table is PROPOSED ({sm['types_signed']} of {sm['types_mapped']} rows signed): "
             f"have it reviewed before findings are used")
    cols = {k.upper() for k in (CLAIM_TYPES or {})} or None
    if billing_mode and C.get("billing_type") and ctype(C["billing_type"]) is None:
        warn(f"config.CLAIM_COLS['billing_type'] = {C['billing_type']!r} is not in {CLAIMS}: every line is routed by its "
             f"SERVICING provider type")
    desc = getattr(config, "PROV_TYPE_DESC_COL", None)
    desc = desc if desc and ctype(desc) is not None else None
    bdesc = getattr(config, "BILLING_TYPE_DESC_COL", None)
    bdesc = bdesc if bdesc and ctype(bdesc) is not None else None
    rows = spark.sql(pq.sql_route_distribution(CLAIMS, C, desc, bdesc, cols)).collect()
    table = {r["sprov_type"]: r for r in ncci_routing.load_table()} if tbl else {}
    total = sum(r.lines for r in rows) or 1
    by_ed, unmapped_b, unmapped, optional, na_on_ncci_form = {}, {}, {}, {}, {}
    print(f"      {'form':5s} {'billing':8s} {'billing description':26s} {'serv.':6s} {'servicing description':26s} "
          f"{'row (category)':20s} {'edit file':13s} {'lines':>12s} {'paid':>16s}")
    for i, r in enumerate(rows):
        key = (r.bprov_type if billing_mode and r.bprov_type in table else
               r.prov_type if r.prov_type in table else None)
        t = table.get(key)
        cat = t["cms_category"] if t else ("(not in table)" if tbl else "-")
        by_ed[r.ncci_edition or "none"] = by_ed.get(r.ncci_edition or "none", 0) + r.lines
        on_form = r.form_typ in ncci_routing.FORM_KIND
        if on_form and tbl:
            if billing_mode and r.bprov_type is not None and r.bprov_type not in table:
                unmapped_b[r.bprov_type] = unmapped_b.get(r.bprov_type, 0) + r.lines
            if t is None:
                unmapped[f"{r.bprov_type}/{r.prov_type}"] = unmapped.get(f"{r.bprov_type}/{r.prov_type}", 0) + r.lines
            elif cat in ncci_routing.OPTIONAL and cat not in sm["optional_on"]:
                optional[cat] = optional.get(cat, 0) + r.lines
            elif cat == "not_applicable":
                na_on_ncci_form[key] = na_on_ncci_form.get(key, 0) + r.lines
        if i < 60:
            print(f"      {str(r.form_typ):5s} {str(r.bprov_type):8s} {str(r.bprov_type_desc or '')[:26]:26s} "
                  f"{str(r.prov_type):6s} {str(r.prov_type_desc or '')[:26]:26s} {cat:20s} "
                  f"{(r.ncci_edition or 'none'):13s} {r.lines:>12,} {float(r.paid or 0):>16,.0f}")
    if len(rows) > 60:
        print(f"      ... {len(rows) - 60} more (form, billing type, servicing type) rows")
    info("lines by NCCI edit file: " + ", ".join(f"{k} {v:,} ({v / total:.1%})" for k, v in sorted(by_ed.items())))
    unknown_forms = sorted({str(r.form_typ) for r in rows if r.form_typ not in fmap})
    if unknown_forms:
        warn(f"{C['form']} value(s) not in config.FORM_TYPE_MAP: {unknown_forms} - no NCCI edit runs on them")
    if unmapped_b:
        warn(f"{len(unmapped_b)} BILLING provider type code(s) on forms A/O are not in the routing table "
             f"({ {k: v for k, v in sorted(unmapped_b.items(), key=lambda x: -x[1])[:10]} } lines) - their lines fall "
             f"back to the servicing type. Add them to {sm['table']}.")
    if unmapped:
        how = ("NO NCCI on those lines" if sm["unmapped_provider_type"] == "none"
               else "the claim form decides (A -> practitioner, O -> outpatient)")
        warn(f"{len(unmapped)} billing/servicing type combination(s) on forms A/O where neither code is in the routing "
             f"table ({ {k: v for k, v in sorted(unmapped.items(), key=lambda x: -x[1])[:10]} } lines) - "
             f"config.NCCI_UNMAPPED_PROVIDER_TYPE = '{sm['unmapped_provider_type']}': {how}. Add them to {sm['table']}.")
    # signed routing (config.NCCI_REQUIRE_SIGNED_ROUTING): 08 runs NCCI only when every provider type code that decides
    # routing on a CMS-1500 / UB-04 line has a SIGNED row - the same codes as ncci_routing.observed_types_sql
    if tbl:
        obs = {}
        for r in rows:
            if r.form_typ in ncci_routing.FORM_KIND:
                for v in ([r.bprov_type] if billing_mode else []) + [r.prov_type]:
                    if v is not None:
                        obs[v] = obs.get(v, 0) + r.lines
        unsigned = ncci_routing.unsigned_observed(obs, list(table.values()))
        if sm["unmapped_provider_type"] == "form":
            (warn if sm.get("require_signed") else info)(
                "config.NCCI_UNMAPPED_PROVIDER_TYPE = 'form': a line whose provider types are not in the table is routed "
                "by its claim form - a guess nobody signed" + (", so 08 will NOT run the NCCI statements; set it to "
                "'none'" if sm.get("require_signed") else ""))
        if not unsigned:
            info(f"signed routing: all {len(obs)} provider type code(s) on forms A/O have a signed row")
        else:
            top = {k: obs.get(k, 0) for k in sorted(unsigned, key=lambda k: -obs.get(k, 0))[:15]}
            (warn if sm.get("require_signed") else info)(
                f"signed routing: {len(unsigned)} of {len(obs)} provider type code(s) on forms A/O have no SIGNED row "
                f"(lines as billing or servicing type: {top}) - "
                + ("08 will NOT run the NCCI statements until they are signed (config.NCCI_REQUIRE_SIGNED_ROUTING)"
                   if sm.get("require_signed") else
                   "config.NCCI_REQUIRE_SIGNED_ROUTING is off: 08 runs NCCI on this unsigned reading (exploratory)"))
    if optional:
        info(f"CMS-optional provider types left without NCCI (config.NCCI_OPTIONAL_CATEGORIES_ON): {optional} lines")
    if na_on_ncci_form:
        info(f"provider types with no NCCI (dental, pharmacy, residential, LTC/HCBS...) on forms A/O: "
             f"{sum(na_on_ncci_form.values()):,} lines, e.g. {dict(list(na_on_ncci_form.items())[:5])}")
    if not by_ed.get("practitioner") and not by_ed.get("outpatient") and not by_ed.get("dme"):
        warn("no claim line takes any NCCI edit file - check FORM_TYP / BProv_Type / SProv_Type against the routing table")
    # provider-type rules (provider_type_allowed, e.g. H0035) read the codes on EVERY form and flag a known code that is
    # not in the rule's list: a column holding something other than AHCCCS provider type codes would flag every line
    if tbl:
        for label, attr in (("BILLING (BProv_Type)", "bprov_type"), ("SERVICING (SProv_Type)", "prov_type")):
            odd = {}
            for r in rows:
                v = getattr(r, attr)
                if v is not None and v not in table:
                    odd[v] = odd.get(v, 0) + r.lines
            if odd:
                warn(f"{len(odd)} {label} code(s) are not AHCCCS provider types in the routing table "
                     f"({ {k: v for k, v in sorted(odd.items(), key=lambda x: -x[1])[:10]} } lines, all forms): a "
                     f"provider-type rule (e.g. H0035) flags such a line whenever the code is not in its list - confirm "
                     f"the column holds AHCCCS provider type codes, and add real new types to {sm['table']}")


run("A", "Which NCCI edit file each line takes (billing / servicing provider type x form, CMS Table 2)", _cA)

# COMMAND ----------

# MAGIC %md ## C. Modifier-indicator changes between the oldest and newest PTP quarter (C2-12)

# COMMAND ----------


def _cC():
    for (svc, et), ms in sorted(by.items()):
        if et != "ptp":
            continue
        if len(ms) < 2:
            warn(f"{svc} ptp: only {ms[0]['label']} loaded - CCMI changes cannot be sized; load an older quarter",
                 minor=True)
            continue
        old, new = ms[0], ms[-1]
        summary, examples = pq.sql_ccmi_changes(ptp_src(old), ptp_src(new))
        r = spark.sql(summary).collect()[0]
        if not r.changed:
            ok(f"{svc} ptp: {r.joined:,} (pair, EffDt) rows in both {old['label']} and {new['label']}; "
               f"no modifier-indicator change")
            continue
        warn(f"{svc} ptp: {r.changed:,} of {r.joined:,} (pair, EffDt) rows changed modifier indicator "
             f"{old['label']} -> {new['label']}: 1->0 {r.one_to_zero:,} (a past claim with a bypass modifier becomes a "
             f"FALSE hard denial under latest-only loading), 0->1 {r.zero_to_one:,} (missed), ->9 {r.to_nine:,}. "
             f"Store the indicator per quarter and judge each claim by the quarter in force on its DOS, or label them.")
        for x in spark.sql(examples).collect():
            print(f"      {x.a}/{x.b} eff {x.eff}: {x.mi_old} -> {x.mi_new}")


run("C", "Modifier-indicator change, oldest vs newest PTP quarter (C2-12)", _cC)

# COMMAND ----------

# MAGIC %md ## D. MUE values raised, or codes removed, in a later quarter (C2-03)

# COMMAND ----------


def _cD():
    for (svc, et), ms in sorted(by.items()):
        if et != "mue":
            continue
        if len(ms) < 2:
            warn(f"{svc} mue: only {ms[0]['label']} loaded - later raises / removals cannot be sized", minor=True)
            continue
        srcs = [mue_src(m, i) for i, m in enumerate(ms)]
        summary, examples = pq.sql_mue_later_changes(srcs, CLAIMS, C)
        r = spark.sql(summary).collect()[0]
        span = f"{ms[0]['label']}..{ms[-1]['label']}"
        if not (r.codes_raised_later or r.codes_removed_later):
            ok(f"{svc} mue: no value raised and no code removed across {span}")
            continue
        warn(f"{svc} mue ({span}): {r.codes_raised_later:,} codes have a HIGHER value in a later quarter "
             f"({r.lines_on_raised:,} paid lines on them, any date) and {r.codes_removed_later:,} codes were removed in "
             f"a later quarter ({r.lines_on_removed:,} lines). If a raise or removal was retroactive, earlier-quarter "
             f"findings on these codes are enforced at the old, stricter value - label them verify_mue (C2-03).")
        seq = {}
        for x in spark.sql(examples).collect():
            seq.setdefault(x.code, []).append(f"{ms[x.qi]['label']}={x.val}")
        for code, vals in seq.items():
            print(f"      {code}: {' -> '.join(vals)}")


run("D", "MUE raised or removed in a later quarter (C2-03)", _cD)

# COMMAND ----------

# MAGIC %md ## E. Edition-exclusive edits among the codes paid in the claims (C2-02)

# COMMAND ----------


def _cE():
    ptp = [ptp_src(ms[-1]) for (svc, et), ms in sorted(by.items()) if et == "ptp"]
    if len(ptp) > 1:
        for r in spark.sql(pq.sql_ptp_exclusive(ptp, CLAIMS, C)).collect():
            info(f"PTP {r.svc}: {r.pairs_in_claims_scope:,} active pairs with both codes paid in the claims; "
                 f"{r.exclusive_pairs:,} of them exist in the {r.svc} edition only")
    else:
        info("PTP: fewer than two editions loaded - nothing to compare")
    mue = [mue_src(ms[-1]) for (svc, et), ms in sorted(by.items()) if et == "mue"]
    if len(mue) > 1:
        seen = set()
        for r in spark.sql(pq.sql_mue_exclusive(mue, CLAIMS, C)).collect():
            if r.svc not in seen:
                seen.add(r.svc)
                info(f"MUE {r.svc}: {r.codes_in_claims:,} codes paid in the claims; {r.exclusive_codes:,} only in {r.svc}")
            if not r.exclusive_lines:
                continue
            line_file = r.form_typ                     # sql_mue_exclusive returns the LINE's edit file here
            msg = (f"MUE {r.svc}-only codes on lines that take the {line_file or 'no'} edit file: "
                   f"{r.exclusive_lines:,} paid lines (${float(r.exclusive_paid or 0):,.0f})")
            info(msg + (" - these edits apply to them" if line_file == r.svc else
                        f" - the routing keeps the {r.svc}-only edits off them"))
    else:
        info("MUE: fewer than two editions loaded - nothing to compare")


run("E", "Edition-exclusive PTP pairs / MUE codes among paid codes (C2-02)", _cE)

# COMMAND ----------

# MAGIC %md ## F. Claims data shape (C1-01..05; includes the old check 5, negative paid lines)

# COMMAND ----------


def _cF():
    try:
        r = spark.sql(pq.sql_data_shape(CLAIMS, C)).collect()[0].asDict()
        n = r["lines"] or 0
        checks = [
            ("paid_nonpositive", "C1-01", f"lines with {PAID} <= 0 (the snapshot marks them not payable: no line-level "
                                          f"finding uses them; a $0 line never counts toward a daily / period limit)"),
            ("paid_negative", "C1-01", f"lines with {PAID} < 0 (reversals: they net out the line they reverse; "
                                       f"sum ${float(r['paid_negative_sum'] or 0):,.0f})"),
            ("paid_null", "C1-01", f"lines with NULL {PAID}"),
            ("units_nonpositive", "C1-01", f"lines with {C['units']} <= 0"),
            ("units_null", "C1-01", f"lines with NULL {C['units']}"),
            ("proc_blank", "C1-03", f"lines with NULL/blank {C['code']}"),
            ("proc_unnormalised", "C1-03", f"lines whose {C['code']} differs from UPPER(TRIM()) (exact-match SQL misses them)"),
            ("mods_unnormalised", "C1-02", "lines with a modifier that differs from UPPER(TRIM()) (' 59', 'xu' do not bypass)"),
            ("member_missing", "C1-05", f"lines with NULL/blank {C['member']} (grouped as one person)"),
            ("sprov_missing", "C1-05", f"lines with NULL/blank {C['servicing_provider']} (grouped as one provider)"),
            # 2026-10-05 (critic re-check N2): misses of the v2.6 AHCCCS table readings, seen before anyone signs them
            ("bprov_missing", "T-N2", f"lines with NULL/blank {C.get('billing_provider')} (an AHCCCS A* pair / daily "
                                      f"limit compares the billing provider id too: these lines are never paired or "
                                      f"counted - missed, never flagged)"),
            ("group_billed_no_rendering_type", "T-N2", f"lines billed by a group (billing type in "
                                                       f"config.GROUP_BILLING_PROVIDER_TYPES) with no rendering "
                                                       f"(servicing) type: B2 cannot judge them - missed, never "
                                                       f"flagged"),
            ("claim_id_null", "C1-04", f"lines with NULL {C['claim_id']}"),
            ("line_no_null", "C1-04", f"lines with NULL {C['line_no']}"),
            ("reversal_units_positive", "R-01", f"lines with {PAID} < 0 but POSITIVE {C['units']} (the snapshot counts "
                                                f"them as negative units; confirm with the data owner how reversals "
                                                f"and adjustments are booked)"),
        ]
        info(f"{n:,} lines, {r['members']:,} distinct {C['member']}; {C['pa_no']} filled on "
             f"{(r['pa_filled'] or 0):,} lines ({(r['pa_filled'] or 0) / max(n, 1):.1%}) - a filled value labels a state "
             f"finding verify_pa; confirm it means an approved prior authorization")
        if r["reversal_units_negative"]:
            info(f"R-01 {r['reversal_units_negative']:,} reversal rows carry negative units (the convention the "
                 f"reversal matching assumes)")
        for key, fid, what in checks:
            v = r[key] or 0
            (warn if v else ok)(f"{fid} {v:,} {what}" + (f" = {v / n:.2%}" if v and n else ""))
        if r["mods_unnormalised"]:
            for x in spark.sql(pq.sql_modifier_examples(CLAIMS, C)).collect():
                print(f"      modifier {x.modifier}: {x.n:,}")
    except Exception as e:
        warn(f"data-shape scan could not run: {type(e).__name__}: {str(e)[:300]}")
    try:
        d = spark.sql(pq.sql_duplicate_keys(CLAIMS, C)).collect()[0]
        if d.dup_keys:
            warn(f"C1-04 {d.dup_keys:,} ({C['claim_id']}, {C['line_no']}) keys occur more than once ({d.rows_in_dup_keys:,} "
                 f"rows; {d.keys_with_differing_rows:,} keys whose rows differ = versions, not copies) - caps sum "
                 f"them and findings double")
        else:
            ok(f"C1-04 every ({C['claim_id']}, {C['line_no']}) key is unique")
    except Exception as e:
        warn(f"duplicate-key check could not run: {type(e).__name__}: {str(e)[:300]}")
    try:
        rows = spark.sql(pq.sql_top_members(CLAIMS, C)).collect()
        for x in rows:
            print(f"      [{x.member_key}] {x.lines:,} lines, {x.providers:,} servicing providers")
        bad = [x.member_key for x in rows if x.member_key is None or not str(x.member_key).strip()
               or re.match(pq.PLACEHOLDER_KEY_RE, str(x.member_key).strip(), re.I)]
        if bad:
            warn(f"C1-05 placeholder-looking {C['member']} values among the top 10: {bad} - exclude them before detection")
        elif len(rows) >= 10 and rows[0].lines >= 10 * max(rows[-1].lines, 1):
            warn(f"C1-05 the top {C['member']} [{rows[0].member_key}] has {rows[0].lines:,} lines, >=10x the 10th "
                 f"({rows[-1].lines:,}) - confirm it is a real member, not a placeholder")
        else:
            ok(f"C1-05 no placeholder-looking {C['member']} among the 10 busiest")
    except Exception as e:
        warn(f"top-member check could not run: {type(e).__name__}: {str(e)[:300]}")
    try:
        dob_t = ctype(C["dob"])
        if dob_t is None:
            warn(f"claims table has no column {C['dob']} (config.CLAIM_COLS['dob']): age-scoped rules cannot match "
                 f"any line (they can only be missed)")
            return
        r = spark.sql(pq.sql_dob(CLAIMS, C, dob_t, ctype(DOS, "date") or "date")).collect()[0]
        info(f"{C['dob']} is {dob_t}")
        for v, what in ((r.dob_null, "NULL"), (r.dob_unparseable, "not parseable as a date (age rules never match them)"),
                        (r.dob_after_dos, "born AFTER the date of service"),
                        (r.dob_1900_or_before, "on or before 1900-01-01 (placeholder?)")):
            (warn if v else ok)(f"{v or 0:,} lines with {C['dob']} {what}")
        if r.dob_unparseable:
            for x in spark.sql(pq.sql_dob_examples(CLAIMS, C, dob_t)).collect():
                print(f"      unparseable {C['dob']} [{x.dob}]: {x.n:,}")
    except Exception as e:
        warn(f"date-of-birth check could not run: {type(e).__name__}: {str(e)[:300]}")


run("F", "Claims data shape (C1-01..05)", _cF)

# COMMAND ----------

# MAGIC %md ## T. AHCCCS rule tables (00b): versions loaded, the dates each judges, claim lines per version, readings signed
# MAGIC 2026-10-04 (v5.2): every loaded file is a VERSION; it judges claims from its own date to the day before the next
# MAGIC version's date, and claims before the oldest loaded version are not judged by the table (SB: load AHCCCS's earlier
# MAGIC versions to judge them). `07_build_kb` compiles a table only when every reading of it is signed (and every config
# MAGIC value a reading binds is as signed). v5.2b: FAIL when a table no longer holds exactly what `00b` loaded (row count
# MAGIC and rows hash per version - `ahcccs_tables.check_loaded`, the check `07` stops on); WARN when the claims run more
# MAGIC than `config.AHCCCS_TABLE_MAX_AGE_DAYS` past a table's newest version (AHCCCS has probably replaced it).

# COMMAND ----------


def _cT():
    import ahcccs_tables as at
    from datetime import date, timedelta
    log = config.AHCCCS_TABLES_LOG                           # a log that exists but cannot be read stops the check
    log_pdf = spark.table(log).toPandas() if spark.catalog.tableExists(log) else None
    loaded = at.loaded_versions(log_pdf)
    if not any(loaded.values()):
        warn(f"no AHCCCS rule table loaded ({config.AHCCCS_TABLES_LOG} has no 'loaded' row): 07 builds no Same Day "
             f"Disallow / Daily Limits / B2 Matrix rule - run 00b_load_ahcccs_tables")
    # 2026-10-04 (v5.2, critic F7): the tables must hold exactly what 00b loaded - the row count and rows hash of every
    # loaded version, and no version the log never loaded (ahcccs_tables.check_loaded: the check 07 stops on)
    frames = {}
    try:
        frames, _ = at.frames_for_build(spark)
        problems = at.check_loaded(frames, log_pdf)
    except ValueError as e:                                  # a row 07 refuses (no code, one cell twice ...)
        problems = [f"the AHCCCS tables cannot be read as 00b writes them: {e}"]
    for p in problems:
        fail(f"{p} - 07 stops on it")
    if not problems and any(loaded.values()):
        ok("every loaded version's rows are in its table as loaded (row count and rows hash: "
           "ahcccs_tables.check_loaded)")
    max_age = getattr(config, "AHCCCS_TABLE_MAX_AGE_DAYS", None) or {}
    for key in at.TABLE_KEYS:
        vs = loaded[key]
        compiles, why = at.table_compiles(key)
        if not vs:
            if any(loaded.values()):
                warn(f"{key}: no version loaded - 07 builds none of its rules (run 00b_load_ahcccs_tables)")
            info(f"{key}: readings {'signed' if compiles else 'NOT signed'} - {why}")
            continue
        twice = sorted({v["version_date"] for v in vs if sum(x["version_date"] == v["version_date"] for x in vs) > 1})
        if twice:
            fail(f"{key}: version(s) {twice} were loaded from two different files - 07 refuses the table; remove one "
                 f"file's rows from {config.AHCCCS_TABLES[key]['table']}")
        windows = at.version_windows([v["version_date"] for v in vs])
        r = spark.sql(at.claims_window_sql(CLAIMS, DOS, ctype(DOS, "date") or "date", windows)).collect()[0]
        for i, vd in enumerate(sorted(windows)):
            lo, hi = windows[vd]
            v = next(x for x in vs if x["version_date"] == vd)
            info(f"{key} version {vd} ({v['file_name']}, sha256 {v['file_sha256'][:12]}, {v['rows'] or 0:,} rows): "
                 f"judges {lo} .. {hi or 'open-ended'} - {r[f'w_{i}'] or 0:,} claim line(s) in that window")
        # 2026-10-04 (v5.2, critic F12): a version stays in force until the next one is loaded - claims dated more than
        # config.AHCCCS_TABLE_MAX_AGE_DAYS[key] days after the newest version are judged by a table AHCCCS has probably
        # replaced (B2 is published monthly, the daily limits report is a run date)
        newest, days = vs[-1]["version_date"], max_age.get(key)
        hi = None if r["hi"] is None else str(r["hi"])[:10]
        if days and hi:
            last_ok = (date.fromisoformat(newest) + timedelta(days=int(days))).isoformat()
            if hi > last_ok:
                warn(f"{key}: the claims run to {hi}, more than {days} days (config.AHCCCS_TABLE_MAX_AGE_DAYS) after the "
                     f"newest loaded version {newest} - claims after {last_ok} are judged by a version AHCCCS has "
                     f"probably replaced; load its newer version(s) with 00b_load_ahcccs_tables")
        before = r["before_oldest"] or 0
        if before:
            warn(f"{key}: {before:,} claim line(s) (claims {r['lo']} .. {r['hi']}) are dated before the oldest loaded "
                 f"version {vs[0]['version_date']} and are NOT judged by this table - load AHCCCS's earlier version(s)")
        else:
            ok(f"{key}: no claim line is dated before the oldest loaded version {vs[0]['version_date']} "
               f"(claims {r['lo']} .. {r['hi']})")
        (ok if compiles else warn)(f"{key}: 07 {'compiles' if compiles else 'does NOT compile'} its rules - {why}")
    # 2026-10-05 (critic F1 follow-up): what the B2 rules would flag in these claims, BEFORE anyone signs the reading -
    # per code and the provider type its role judges (a group's line: its rendering type)
    if loaded["b2_matrix"] and len(frames.get("b2_matrix", [])):
        sql = at.b2_exposure_sql(CLAIMS, C, frames["b2_matrix"])
        if sql:
            ex = spark.sql(sql).toPandas()
            tot = ex.groupby("status")[["lines", "paid"]].sum()
            for st_ in ("allowed", "flagged", "no_type"):
                if st_ in tot.index:
                    info(f"b2_matrix exposure ({at.b2_provider_role()}): {st_:8s} {int(tot.loc[st_, 'lines']):,} paid "
                         f"line(s), ${float(tot.loc[st_, 'paid'] or 0):,.2f} on the {ex['code'].nunique()} compiled "
                         f"code(s) in the claims (all dates; the rules judge only from their version's date)")
            fl = ex[ex["status"] == "flagged"].sort_values("paid", ascending=False)
            if len(fl):
                warn(f"b2_matrix: once signed, B2 would flag {int(fl['lines'].sum()):,} paid line(s) "
                     f"(${float(fl['paid'].sum() or 0):,.2f}) - read the provider types below before signing reading "
                     f"provider_types (a type you know may bill the code means the matrix is incomplete for it)")
                print(fl.head(20).to_string(index=False))


run("T", "AHCCCS rule tables: versions, the dates each judges, claim lines per version, readings signed (v5.2)", _cT)

# COMMAND ----------

summary = pd.DataFrame(RESULTS, columns=["id", "check", "status", "first"])
verdict = {"go": not any(r["status"] == "FAIL" for r in RESULTS),
           "blockers": [f"[{r['id']}] {r['first']}" for r in RESULTS if r["status"] == "FAIL"],
           "warnings": [f"[{r['id']}] {r['first']}" for r in RESULTS if r["status"] == "WARN"]}
print()
print("=" * 100)
print(f"{'id':3s} {'status':6s} check")
for r in RESULTS:
    print(f"{r['id']:3s} {r['status']:6s} {r['check']}" + (f"\n           {r['first'][:220]}" if r["first"] else ""))
print("=" * 100)
print("GO" if verdict["go"] else "NO-GO", "-", len(verdict["blockers"]), "FAIL,", len(verdict["warnings"]), "WARN")
display(summary.rename(columns={"first": "first finding"}))
if UNREADABLE:
    raise RuntimeError(f"{len(UNREADABLE)} NCCI table(s) cannot be read: {UNREADABLE}")
