# Databricks notebook source
# MAGIC %md
# MAGIC # 00b · Load the AHCCCS rule tables — Same Day Disallow, Daily Limits, B2 Matrix → `main.sedo` tables
# MAGIC
# MAGIC AHCCCS publishes these billing rules as DATA (Medical Coding Resources page). Like the NCCI files (`00_acquire_ncci`)
# MAGIC they are read by a deterministic reader (`ahcccs_tables.py`), never by the model, and every rule built from them
# MAGIC cites the file, sheet and cell (or row) it comes from. Contract v5.2, SB's decisions of 2026-10-04.
# MAGIC
# MAGIC | step | what happens | refuses (status `rejected`, nothing but the log row written) when |
# MAGIC |---|---|---|
# MAGIC | 1 | (optional, `DOWNLOAD = True`) fetch `config.AHCCCS_TABLES` urls into the drop zone — never overwrites a file | the site returns something that is not an .xlsx |
# MAGIC | 2 | every `.xlsx` in `config.AHCCCS_TABLES_DIR` (any name, any sub-folder except the `_versions/` archive and other folders starting with `_` or `.` - each skipped folder and file is printed): recognised by its **header text**, never the file name; its **version date** read from the sheet ("Updated: 10/1/2026", "As of 9/14/26") | unknown layout, no version date, an indicator other than D / A / A*, a code twice in one version, a non-numeric daily maximum, a changed legend or table note 2, anything right of the table's last known column (named) |
# MAGIC | 3 | a file whose sha256 is already loaded is skipped (status `already_loaded`) | another file already holds — or, in this run, also claims — the same table version (a person compares them; a loaded version is never replaced) |
# MAGIC | 4 | the original is archived as `AHCCCS_TABLES_DIR/_versions/<table_key>/<version_date>_<sha12>.xlsx` (a copy), its normalised rows appended to the table's UC table, and a log row to `config.AHCCCS_TABLES_LOG` with the row count and `rows_sha256` (a canonical hash of the version's rows) | the write fails |
# MAGIC | 5 | per table: the versions loaded and the dates each one judges (a version judges claims from its date to the day before the next version's date; claims before the oldest version are not judged); then every loaded version's rows in the UC table are compared with the log (`ahcccs_tables.check_loaded`: row count and rows hash - the check `07_build_kb` stops on) | any file was rejected, or a table no longer holds what the log loaded (rows deleted / edited / added outside 00b, a table dropped) → the notebook ends red (so a scheduled Job alerts) |
# MAGIC
# MAGIC Nothing is ever deleted or overwritten. Loading a table does not make it compile: `07_build_kb` compiles a table's
# MAGIC rules only when every reading of it in `reference/ahcccs_table_readings.csv` is signed
# MAGIC (`config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS`).
# MAGIC
# MAGIC **No egress?** Download the three workbooks by hand from
# MAGIC https://azahcccs.gov/PlansProviders/MedicalCodingResources.html into `config.AHCCCS_TABLES_DIR` (keep `DOWNLOAD = False`).
# MAGIC Earlier versions (to judge older claims) go in the same folder: each file is its own version.
# MAGIC
# MAGIC **Then:** `01_preflight_ncci` (check T) → `07_build_kb`.

# COMMAND ----------

import os, sys
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
import config, ahcccs_tables as at, kb_io
for m in (config, kb_io, at):
    importlib.reload(m)

# ---- parameters
DOWNLOAD   = False                         # True = fetch config.AHCCCS_TABLES urls into the drop zone first
TABLES_DIR = config.AHCCCS_TABLES_DIR      # the drop zone (and its _versions/ archive)
LOG_TABLE  = config.AHCCCS_TABLES_LOG
os.makedirs(TABLES_DIR, exist_ok=True)
print("drop zone:", TABLES_DIR)

# COMMAND ----------

# MAGIC %md ## 1–2. Download (optional) and find the workbooks

# COMMAND ----------

if DOWNLOAD:
    for key, meta in config.AHCCCS_TABLES.items():
        try:
            got = at.download(meta["url"], TABLES_DIR)
            print(f"  {key:18s} {got['status']:22s} {got['path']}")
        except Exception as e:                   # the drop zone may still hold a copy fetched by hand
            print(f"  {key:18s} DOWNLOAD FAILED: {type(e).__name__}: {str(e)[:300]}")
SKIPPED = []                               # 2026-10-04 (v5.2, critic F17): what is NOT read is said
FILES = at.drop_zone_files(TABLES_DIR, skipped=SKIPPED)
print(f"{len(FILES)} workbook(s) in the drop zone:")
for p in FILES:
    print("  ", os.path.relpath(p, TABLES_DIR))
for s_ in SKIPPED:
    print(f"   skipped {s_['kind']} {s_['path']}{'/' if s_['kind'] == 'folder' else ''} ({s_['why']})")

# COMMAND ----------

# MAGIC %md ## 3–4. Parse, archive, append, log

# COMMAND ----------

LOG_BEFORE = kb_io.table_or_none(spark, LOG_TABLE)        # None only when the log does not exist yet
RESULTS = at.load_files(spark, FILES, TABLES_DIR, LOG_BEFORE)
at.write_log(spark, RESULTS, LOG_TABLE)                    # last: a 'loaded' row means its rows are in the table
res = at.log_frame(RESULTS)
display(res[["table_key", "version_date", "status", "rows", "rows_sha256", "file_name", "detail", "archived_path"]])

# COMMAND ----------

# MAGIC %md ## 5. Versions loaded and the dates each one judges

# COMMAND ----------

LOG_AFTER = kb_io.table_or_none(spark, LOG_TABLE)
LOADED = at.loaded_versions(LOG_AFTER)
WINDOWS = {}
for key in at.TABLE_KEYS:
    vs = LOADED[key]
    WINDOWS[key] = at.version_windows([v["version_date"] for v in vs])
    fqn = config.AHCCCS_TABLES[key]["table"]
    if not vs:
        print(f"{key}: no version loaded ({fqn})")
        continue
    print(f"{key}: {len(vs)} version(s) in {fqn}; claims before {vs[0]['version_date']} are NOT judged by it")
    for v in vs:
        lo, hi = WINDOWS[key][v["version_date"]]
        print(f"  version {v['version_date']}  judges {lo} .. {hi or 'open-ended'}   {v['rows'] or 0:>7,} rows   "
              f"{v['file_name']} (sha256 {v['file_sha256'][:12]})")
    ok, why = at.table_compiles(key)
    print(f"  07 compiles it: {'YES' if ok else 'NO'} - {why}")

for status in at.LOG_STATUSES:
    n = int((res["status"] == status).sum()) if len(res) else 0
    if n:
        print(f"{status:15s} {n}")
# 2026-10-04 (v5.2, critic F7): every version the log calls loaded must still be in its table exactly as loaded - row
# count and rows hash (check_loaded, the check 07 stops on). A later run skips a loaded file, so a table dropped, or rows
# deleted / edited / added outside 00b, would otherwise change the rules silently.
REJECTED = res[res["status"] == "rejected"] if len(res) else res
problems = []
if len(REJECTED):
    problems.append(f"{len(REJECTED)} AHCCCS table file(s) rejected (nothing of them was loaded): "
                    + " | ".join(f"{r['file_name']}: {str(r['detail'])[:300]}" for _, r in REJECTED.iterrows()))
try:
    FRAMES, _ = at.frames_for_build(spark)
    TABLE_CHECK = at.check_loaded(FRAMES, LOG_AFTER)
except ValueError as e:                    # a row 07 would refuse (no code, a cell twice ...)
    TABLE_CHECK = [f"the AHCCCS tables cannot be read as 00b writes them: {e}"]
for p_ in TABLE_CHECK:
    print("  TABLE CHECK:", p_)
problems += TABLE_CHECK
if problems:
    raise RuntimeError(" || ".join(problems))
print("table check: every loaded version's rows are in its table as loaded (row count and rows hash)")
print("\nGO: next run 01_preflight_ncci (check T), then 07_build_kb.")
