# Databricks notebook source
# MAGIC %md
# MAGIC # d06 · Where federal and state rules meet
# MAGIC
# MAGIC **What this answers:** codes checked by both a federal NCCI edit and an AHCCCS rule, how the two compare (stricter,
# MAGIC same, measured differently), and the **contradiction candidates** — codes AHCCCS calls not covered while CMS publishes
# MAGIC an edit that assumes the code is payable.
# MAGIC **How to read it:** both rules still run; this list records how they relate. Nothing here decides which authority wins.
# MAGIC **Limits:** only comparable pairs are listed (a state unit cap vs the federal MUE on the same code; a state pair vs a
# MAGIC federal pair on the same two codes; a state "not covered" vs any federal edit on the code). Contradiction candidates
# MAGIC are for human review — many will turn out to be fine (an edit can exist for a code a state does not cover).
# MAGIC NCCI = CMS public edit set, Arizona deactivations not applied.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, re
import pandas as pd
from pyspark.sql import functions as F
import config
importlib.reload(config)

MAX_ROWS = 25           # longest list shown per section (the notebook says how many more there are)

# COMMAND ----------

KB = config.KB


def show(df, what, n=MAX_ROWS):
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}).")


MEANING = {
    "state_stricter": "AHCCCS allows fewer units than the federal limit (same basis).",
    "federal_stricter": "The federal limit is lower than the AHCCCS limit (same basis).",
    "same_limit": "Both set the same limit on the same basis.",
    "different_basis": "Both limit units, but measured differently (e.g. per claim line vs per member per day); not directly comparable.",
    "both_pair_prohibitions": "Both prohibit the same two codes together. Scope can differ: NCCI = same provider; AHCCCS often = same member.",
    "state_not_covered_vs_federal_edit": "CONTRADICTION CANDIDATE: AHCCCS says not covered; CMS publishes an edit that presumes payment.",
    "different_rule_types": "Different kinds of rule on the same code.",
}
BUILD_ID = spark.table(f"{KB}.policy_rules").where("build_id IS NOT NULL").select("build_id").first()[0]
ovl = spark.table(f"{KB}.policy_rule_overlaps").where(F.col("build_id") == BUILD_ID).toPandas()
rules = spark.table(f"{KB}.policy_rules").select("rule_id", "statement", "source_url", "doc_version", "reviewer",
                                               "review_status").toPandas()
fed = rules.add_prefix("federal_").rename(columns={"federal_rule_id": "federal_rule_id"})
st = rules.add_prefix("state_").rename(columns={"state_rule_id": "state_rule_id"})
ovl = ovl.merge(fed, on="federal_rule_id", how="left").merge(st, on="state_rule_id", how="left")


def _quote(v):
    """state_quote falls back to the rule's notes ('Verbatim: "..." Found by: ...'); keep just the policy words."""
    m = re.search(r'Verbatim: "(.*)" Found by:', str(v or ""), re.S)
    return m.group(1) if m else v


if len(ovl):
    ovl["state_quote"] = ovl["state_quote"].map(_quote)
print(f"build {BUILD_ID}: {len(ovl):,} federal/state overlap row(s) on {ovl['code'].nunique() if len(ovl) else 0:,} code(s)")

# COMMAND ----------

# MAGIC %md ## 1. Relationships

# COMMAND ----------

if len(ovl):
    c = ovl.groupby("relationship").agg(rows=("code", "size"), codes=("code", "nunique")).reset_index()
    c["meaning"] = c["relationship"].map(MEANING).fillna("")
    display(c.sort_values("rows", ascending=False))
else:
    print("No federal/state overlaps in this build (no code is checked by both a comparable federal and state rule).")

# COMMAND ----------

# MAGIC %md ## 2. One authority stricter than the other

# COMMAND ----------

for rel in ("state_stricter", "federal_stricter", "same_limit", "different_basis"):
    g = ovl[ovl["relationship"] == rel] if len(ovl) else ovl
    print(f"\n{rel}: {len(g):,} row(s). {MEANING[rel]}")
    if len(g):
        show(g[["code", "federal_type", "federal_limit", "state_type", "state_limit", "state_statement", "state_quote",
                "state_source", "federal_source"]], f"{rel} rows")

# COMMAND ----------

# MAGIC %md ## 3. Contradiction candidates — for human review, with both sources

# COMMAND ----------

cc = ovl[ovl["relationship"] == "state_not_covered_vs_federal_edit"] if len(ovl) else ovl
print(f"{len(cc):,} contradiction candidate(s). Each is a question for a person, not a finding: CMS publishes edits for "
      "codes regardless of whether a given state covers them.")
for r in cc.head(MAX_ROWS).to_dict("records"):
    print(f"\n  code {r['code']}")
    print(f"    AHCCCS: \"{r.get('state_statement')}\"  — {r.get('state_source')}  ({r.get('state_review_status')}, "
          f"reviewer {r.get('state_reviewer') or 'none'})")
    print(f"            policy text: {r.get('state_quote')}")
    print(f"    CMS:    {r.get('federal_type')}; e.g. \"{r.get('federal_statement')}\" — {r.get('federal_source')} "
          f"({r.get('federal_doc_version')})")
if len(cc) > MAX_ROWS:
    print(f"\n  ... {len(cc) - MAX_ROWS:,} more candidate(s) not shown.")
