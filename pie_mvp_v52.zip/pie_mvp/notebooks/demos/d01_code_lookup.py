# Databricks notebook source
# MAGIC %md
# MAGIC # d01 · Everything that governs one procedure code
# MAGIC
# MAGIC **What this answers:** for procedure code `CODE`, every rule the knowledge base holds — federal NCCI edits,
# MAGIC AHCCCS manual rules, open questions, federal/state overlaps — and what it means in paid claims.
# MAGIC **How to read it:** each section says how many items it found. Nothing is cut off without a line saying how many were hidden.
# MAGIC **Limits:** only the authorities loaded so far (NCCI PTP + MUE, and the manual chapters extracted so far).
# MAGIC "Nothing found" means nothing *in this KB* — not that no policy exists. NCCI = CMS public edit set;
# MAGIC Arizona deactivations are not applied. Findings are candidates for review, not confirmed overpayments.
# MAGIC
# MAGIC Read-only. Reads the current build of `policy_*` tables and the latest detector run.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json, re
import pandas as pd
from pyspark.sql import functions as F
import config
importlib.reload(config)

CODE     = "98960"      # the procedure code to look up (CPT / HCPCS)
RUN_ID   = None         # None = the latest detector run
MAX_ROWS = 50           # longest list shown per section; anything longer says how many were hidden

# COMMAND ----------

KB, CC = config.KB, config.CLAIM_COLS
CODE = str(CODE).strip().upper()
assert re.fullmatch(r"[A-Z0-9]{4,7}", CODE), f"CODE {CODE!r} does not look like a procedure code"


def T(name):
    return f"{KB}.{name}"


def have(name):
    return spark.catalog.tableExists(T(name))


def show(df, what="rows", n=None):
    """display up to n rows and say how many were hidden - never truncate silently."""
    n = n or MAX_ROWS
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}). Raise MAX_ROWS to see them.")


for t in ("policy_rules", "policy_detectors"):
    assert have(t), f"{T(t)} missing - run 07_build_kb first"
BUILD_ID = spark.table(T("policy_rules")).where("build_id IS NOT NULL").select("build_id").first()[0]
blog = spark.table(T("policy_build_log")).where(F.col("build_id") == BUILD_ID).toPandas() if have("policy_build_log") else pd.DataFrame()
if RUN_ID is None and have("policy_detector_runs"):
    RUN_ID = spark.table(T("policy_detector_runs")).agg(F.max("run_id")).first()[0]
print(f"code {CODE} | current build {BUILD_ID} | detector run {RUN_ID or '(none yet)'}")
if len(blog) and str(blog.iloc[0]["scope"]) == "claims":
    print("Note: this build loads federal edits only for codes PAID in the claims table "
          f"({blog.iloc[0]['claims_from']} to {blog.iloc[0]['claims_to']}). A code never paid there has no NCCI rows here "
          "even if CMS publishes edits for it.")

# every rule in the current build that names the code
rules = (spark.table(T("policy_rules"))
         .where(F.array_contains(F.from_json("codes", "array<string>"), CODE))
         .toPandas())
rules["ptype"] = rules["predicate"].map(lambda s: json.loads(s).get("type") if isinstance(s, str) else None)
dets = spark.table(T("policy_detectors")).select("rule_id", "compiled", "batch", "routing", "finding_severity", "reason").toPandas()
rules = rules.merge(dets, on="rule_id", how="left")
fed, st_built = rules[rules["origin"] == "ncci"], rules[rules["origin"] != "ncci"]
found_anything = len(rules) > 0

# COMMAND ----------

# MAGIC %md ## 1. Federal — NCCI procedure-to-procedure (PTP) pairs
# MAGIC A PTP edit says two codes should not be paid for the same member, same provider, same day. Column 1 is the
# MAGIC comprehensive code; the **Column 2 line is the one CMS denies**. Modifier indicator 0 = no modifier can bypass;
# MAGIC 1 = an NCCI-associated modifier may bypass when documented.

# COMMAND ----------

ptp = fed[fed["ptype"] == "code_pair_prohibited"].copy()
if len(ptp):
    p = ptp["predicate"].map(json.loads)
    ptp["code_a"], ptp["code_b"] = p.map(lambda d: d.get("code_a")), p.map(lambda d: d.get("code_b"))
    ptp["modifier_indicator"] = p.map(lambda d: d.get("modifier_indicator"))
    ptp["role"] = ptp.apply(lambda r: "column 1 (comprehensive)" if r["code_a"] == CODE else "column 2 (denied line)", axis=1)
    ptp["other_code"] = ptp.apply(lambda r: r["code_b"] if r["code_a"] == CODE else r["code_a"], axis=1)
    print(f"{len(ptp):,} PTP pair(s): {int((ptp['code_a'] == CODE).sum()):,} with {CODE} as column 1, "
          f"{int((ptp['code_b'] == CODE).sum()):,} with {CODE} as column 2; "
          f"{int((ptp['modifier_indicator'] == '0').sum()):,} can never be bypassed (indicator 0).")
    show(ptp.sort_values(["role", "modifier_indicator", "other_code"])[
        ["role", "other_code", "modifier_indicator", "effective_date", "end_date", "doc_version", "reconciliation",
         "compiled", "rule_id"]], "PTP pairs")
else:
    print(f"No NCCI PTP pairs name {CODE} in this build.")

# COMMAND ----------

# MAGIC %md ## 2. Federal — NCCI Medically Unlikely Edit (MUE): the most units per line
# MAGIC MUE values change by quarter; each row is one unbroken period with the same limit.

# COMMAND ----------

mue = fed[fed["ptype"].isin(["max_units_per_line", "max_units_per_dos"])].copy()
if len(mue):
    mue["limit"] = mue["predicate"].map(lambda s: json.loads(s).get("threshold"))
    mue["basis"] = mue["ptype"].map({"max_units_per_line": "per claim line", "max_units_per_dos": "per provider per day"})
    mue["window"] = mue.apply(lambda r: f"{r['effective_date'] or 'start of data'} to {r['end_date'] or 'still in force'}", axis=1)
    cur = mue[mue["end_date"].isna()]
    if len(cur):
        print(f"Current MUE for {CODE}: {', '.join(f'{int(v)} unit(s) {b}' for v, b in zip(cur['limit'], cur['basis']))}.")
    show(mue.sort_values("effective_date")[["limit", "basis", "window", "doc_version", "reconciliation", "notes", "rule_id"]],
         "MUE periods")
else:
    print(f"No NCCI MUE limit for {CODE} in this build.")
print("NCCI = CMS public edit set; Arizona-specific deactivations are NOT applied.")

# COMMAND ----------

# MAGIC %md ## 3. State — AHCCCS manual rules that name the code
# MAGIC From the reviewed rule table (`state_rules`), at every review status. Only **approved** rules (and hand-authored
# MAGIC seeds, if the build allows them) compile. Drafts are machine-proposed and have not been reviewed.

# COMMAND ----------

sr = spark.table(config.STATE_RULES_TABLE).toPandas()


def _codes(row):
    out = set()
    try:
        out |= {str(c).upper() for c in (json.loads(row["codes"]) if isinstance(row["codes"], str) else row["codes"] or [])}
    except Exception:
        pass
    try:
        p = json.loads(row["predicate"]) if isinstance(row["predicate"], str) else (row["predicate"] or {})
        out |= {str(c).upper() for c in ([p.get("code"), p.get("code_a"), p.get("code_b")] + list(p.get("code_set") or [])) if c}
    except Exception:
        pass
    return out


RANGE_RE = re.compile(r"\b(\d{5})\s*(?:-|–|through|to)\s*(\d{5})\b")


def _mentions(text):
    """'text' | 'range' | None: the code appears as a word, or inside a numeric range like 99201-99499."""
    if not isinstance(text, str):
        return None
    if re.search(rf"\b{re.escape(CODE)}\b", text):
        return "text"
    if CODE.isdigit():
        for a, b in RANGE_RE.findall(text):
            if int(a) <= int(CODE) <= int(b):
                return "range"
    return None


sr["_codes"] = [_codes(r) for r in sr.to_dict("records")]
named = sr[sr["_codes"].map(lambda s: CODE in s)].copy()
superseded = set()
all_built = spark.table(T("policy_rules")).select("rule_id", "extraction_key", "supersedes").toPandas()
for s in all_built["supersedes"].dropna():
    try:
        superseded |= set(json.loads(s) if isinstance(s, str) else s)
    except Exception:
        pass
det_by = {**{k: v for k, v in zip(st_built["extraction_key"], st_built.to_dict("records")) if isinstance(k, str)},
          **{k: v for k, v in zip(st_built["rule_id"], st_built.to_dict("records"))}}


def _in_build(r):
    d = det_by.get(r.get("extraction_key")) or det_by.get(r.get("rule_id"))
    if d is not None:
        return "compiled detector" if d.get("compiled") else f"in build as a lead: {d.get('reason')}"
    if r.get("rule_id") in superseded:
        return "not in build: duplicate of an extracted rule (superseded)"
    if r.get("review_status") in ("draft", "needs_review", "rejected", "superseded"):
        return f"not in build: review_status = {r.get('review_status')}"
    return "not in build: approved but excluded (older document version, or outside the claims scope)"


if len(named):
    named["in_current_build"] = named.apply(lambda r: _in_build(r.to_dict()), axis=1)
    print(f"{len(named):,} AHCCCS rule(s) name {CODE}: " + ", ".join(f"{v} {k}" for k, v in named["review_status"].value_counts().items()))
    show(named.sort_values(["review_status", "chapter"])[
        ["review_status", "in_current_build", "statement", "verbatim_quote", "source_doc", "source_locator", "source_url",
         "reviewer", "reviewed_at", "origin", "rule_id"]], "state rules")
else:
    print(f"No AHCCCS manual rule names {CODE} in its codes.")

text_only = sr[~sr.index.isin(named.index)].copy()
text_only["_where"] = [_mentions(q) or _mentions(t) for q, t in zip(text_only["verbatim_quote"], text_only["statement"])]
text_only = text_only[text_only["_where"].notna() & (text_only["review_status"] != "rejected")]
if len(text_only):
    print(f"\n{len(text_only):,} more rule(s) MENTION {CODE} in their text (as a word or inside a code range) without being "
          "tied to it as a code. These do not run against claims for this code; a reviewer should decide whether they apply.")
    show(text_only[["_where", "review_status", "statement", "verbatim_quote", "source_doc", "source_locator", "rule_id"]],
         "text mentions")
found_anything = found_anything or len(named) > 0 or len(text_only) > 0

# COMMAND ----------

# MAGIC %md ## 4. Open questions — ambiguity register entries and federal/state overlaps

# COMMAND ----------

if have("policy_ambiguity_register"):
    amb = (spark.table(T("policy_ambiguity_register"))
           .where(F.array_contains(F.from_json("codes", "array<string>"), CODE)).toPandas())
    if len(amb):
        print(f"{len(amb):,} ambiguity register entr(ies) for {CODE} (policy text that does not resolve to a checkable rule):")
        show(amb[["category", "reason", "review_status", "statement", "verbatim_quote", "source_doc", "source_locator"]],
             "ambiguity entries")
    else:
        print(f"No ambiguity register entries for {CODE}.")
    found_anything = found_anything or len(amb) > 0

if have("policy_rule_overlaps"):
    ovl = spark.table(T("policy_rule_overlaps")).toPandas()
    ovl = ovl[ovl["code"].astype(str).str.split("/").map(lambda parts: CODE in parts)]
    if len(ovl):
        print(f"\n{len(ovl):,} federal/state overlap(s) on {CODE} (both authorities apply; the relationship says how they compare):")
        show(ovl[["code", "relationship", "federal_type", "federal_limit", "state_type", "state_limit", "state_quote",
                  "federal_source", "state_source"]], "overlaps")
    else:
        print(f"No federal/state overlaps recorded for {CODE}.")
    found_anything = found_anything or len(ovl) > 0

# COMMAND ----------

# MAGIC %md ## 5. Claims exposure, detectors and findings
# MAGIC "Covered" means a compiled detector whose effective window overlaps the claims period checks this code.

# COMMAND ----------

cov = spark.table(T("policy_coverage")).where(F.col("code") == CODE).toPandas() if have("policy_coverage") else pd.DataFrame()
if len(cov):
    # one row per claim form the code was paid on (federal edits apply per form since 2026-10-02)
    for c in cov.sort_values("paid_dollars", ascending=False).to_dict("records"):
        print(f"Paid claims for {CODE} on form {c.get('form_typ') or '?'}: {int(c['lines']):,} line(s), "
              f"{float(c['units'] or 0):,.0f} unit(s), ${float(c['paid_dollars'] or 0):,.2f}. Coverage: {c['coverage']} "
              f"({int(c['ncci_rules'])} federal + {int(c['state_rules'])} state compiled rule(s); "
              f"{int(c['state_leads'])} state lead(s) that do not compile).")
else:
    print(f"{CODE} has no paid lines in the claims table for this build's claims window, so it has no exposure or coverage row.")

if len(rules):
    d = rules.groupby(["origin", "ptype", "compiled"], dropna=False).size().reset_index(name="rules")
    print(f"\nDetectors for rules naming {CODE} (NCCI PTP/MUE run as two table-driven statements, shown as batch):")
    show(d, "detector groups")

fcount = pd.DataFrame()
if RUN_ID and have("policy_findings") and len(rules):
    ids = spark.createDataFrame(pd.DataFrame({"rule_id": rules["rule_id"].astype(str)}), "rule_id string")
    f = spark.table(T("policy_findings")).where(F.col("run_id") == RUN_ID).join(ids, "rule_id")
    line = f.where(F.col("claim_id").isNotNull()).select("claim_id", "line_no", "paid_amt").dropDuplicates(["claim_id", "line_no"])
    n_find = f.count()
    agg_n = f.where(F.col("claim_id").isNull()).count()
    dollars = line.agg(F.sum("paid_amt")).first()[0] or 0.0
    print(f"\nLatest run {RUN_ID}: {n_find:,} finding(s) from rules that name {CODE}; "
          f"{line.count():,} distinct flagged claim line(s), ${float(dollars):,.2f} paid on them "
          "(each claim line counted once even when several rules flag it; for a code pair the flagged line is the "
          "Column Two code, which may be the partner code rather than " + CODE + ").")
    if agg_n:
        print(f"  plus {agg_n:,} member-day / member-period finding(s) (daily or period caps) - their lines are listed in "
              "evidence_lines and are not in the line total above.")
    fcount = (f.groupby("origin", "predicate_type", "finding_severity", "pa_status")
               .agg(F.count("*").alias("findings")).orderBy(F.desc("findings")).toPandas())
    show(fcount, "finding groups")
    print("Findings are candidates for review, not confirmed overpayments.")

# COMMAND ----------

# MAGIC %md ## Summary

# COMMAND ----------

if not found_anything:
    print(f"No governing authority found in the KB for {CODE}.")
    print("That means: no NCCI edit, no AHCCCS manual rule, no ambiguity entry and no overlap in THIS knowledge base. "
          "Authorities not loaded yet (AMPM, fee schedule, other federal edit types, the manual chapters not extracted) "
          "may still govern it.")
else:
    print(f"{CODE}: {len(ptp)} NCCI pair(s), {len(mue)} MUE period(s), "
          f"{len(named)} AHCCCS rule(s) naming it ({int((named['review_status'] == 'approved').sum()) if len(named) else 0} approved), "
          f"{len(text_only)} text mention(s).")
