# Databricks notebook source
# MAGIC %md
# MAGIC # d07 · Policy change impact — what happens when AHCCCS revises a chapter
# MAGIC
# MAGIC **What this answers:** which versions of each manual chapter we hold, what changed between them, which approved rules
# MAGIC went back for re-signing because their source changed, which approvals the latest build left out as stale, and which
# MAGIC past findings came from rules that no longer exist in the current build.
# MAGIC **How to read it:** a new PDF version gets a new fingerprint (`doc_hash`). An approval is tied to the version the
# MAGIC reviewer read, so a new version sends it back for re-sign and it stops compiling until someone re-signs it.
# MAGIC **Limits:** change detection is by rule meaning, and only for chapters re-extracted after the revision. Nothing is
# MAGIC deactivated automatically. Old findings stay traceable through `policy_rules_history`.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import functions as F
import config, state_rules
for _m in (config, state_rules):
    importlib.reload(_m)

MAX_ROWS = 25           # longest list shown per section (the notebook says how many more there are)

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def have(name):
    return spark.catalog.tableExists(T(name))


def show(df, what, n=MAX_ROWS):
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}).")


BUILD_ID = spark.table(T("policy_rules")).where("build_id IS NOT NULL").select("build_id").first()[0]
print(f"current build {BUILD_ID}")

# COMMAND ----------

# MAGIC %md ## 1. Document versions per chapter

# COMMAND ----------

current_doc_hash = {}
if have("policy_document_inventory"):
    inv = spark.table(T("policy_document_inventory")).toPandas().sort_values(["chapter", "fetched_at"])
    inv["chapter"] = inv["chapter"].astype(str)
    current_doc_hash = inv.groupby("chapter")["doc_hash"].last().to_dict()
    inv["current"] = inv.apply(lambda r: r["doc_hash"] == current_doc_hash.get(r["chapter"]), axis=1)
    inv["doc_hash_short"] = inv["doc_hash"].astype(str).str[:12]
    v = (inv.drop_duplicates(["chapter", "doc_hash"], keep="last")
         [["chapter", "title", "doc_hash_short", "revision_date", "fetched_at", "pages", "sections", "current"]])
    n_ver = v.groupby("chapter").size()
    print(f"{len(n_ver)} chapter(s) held; {int((n_ver > 1).sum())} with more than one version.")
    show(v, "versions")
else:
    print("No document inventory yet (no chapter has been extracted).")

# COMMAND ----------

# MAGIC %md ## 2. What changed (change log)

# COMMAND ----------

if have("policy_change_log"):
    chg = spark.table(T("policy_change_log")).toPandas()
    display(chg.groupby(["run_id", "chapter", "change_type"]).size().reset_index(name="events")
            .sort_values(["run_id", "chapter"], ascending=[False, True]))
    moved = chg[~chg["change_type"].isin(["rule_unchanged", "document_changed", "document_first_seen"])].sort_values(
        ["run_id", "chapter", "change_type"], ascending=[False, True, True])
    print(f"{len(moved):,} event(s) where a rule was added, removed or changed (unchanged rules and the document event itself are "
          "left out below):")
    show(moved[["run_id", "chapter", "change_type", "statement", "rule_id", "old_doc_hash", "new_doc_hash"]], "events")
else:
    print("No change log yet.")

# COMMAND ----------

# MAGIC %md ## 3. Rules waiting for re-sign, and stale approvals

# COMMAND ----------

sr = spark.table(config.STATE_RULES_TABLE).toPandas()
has_prior = sr["prior_review"].notna() if "prior_review" in sr else pd.Series(False, index=sr.index)
prior = sr[has_prior].copy()
for k in ("status", "reviewer", "reviewed_at", "doc_hash"):
    prior[f"prior_{k}"] = prior["prior_review"].map(lambda s: (json.loads(s) if isinstance(s, str) else {}).get(k))
waiting = prior[prior["review_status"] == "needs_review"]
resigned = prior[prior["review_status"] == "approved"]
print(f"{len(waiting):,} rule(s) are waiting for re-sign because their source document changed; they do not compile until "
      f"re-signed. {len(resigned):,} rule(s) were re-signed after a change.")
show(waiting[["chapter", "statement", "prior_status", "prior_reviewer", "prior_reviewed_at", "prior_doc_hash", "doc_hash",
              "review_note", "rule_id"]], "waiting rules")

stale = sr[state_rules.stale_mask(sr, current_doc_hash) & sr["review_status"].isin(["approved"])]
print(f"\nRight now {len(stale):,} approved rule(s) point at an older document version than the chapter's current one "
      "(the next build will leave them out).")
show(stale[["chapter", "statement", "reviewer", "reviewed_at", "doc_hash", "rule_id"]], "stale approvals")

if have("policy_build_log"):
    bl = spark.table(T("policy_build_log")).select("build_id", "built_at", "state_rules", "stale_approvals_excluded",
                                                 "legacy_seed_rules").orderBy(F.desc("built_at")).toPandas()
    print("\nApprovals each build left out as stale (latest first):")
    show(bl, "builds", 10)

# COMMAND ----------

# MAGIC %md ## 4. Past findings from rules that are not in the current build
# MAGIC Those findings are still explainable: join `policy_rules_history` on `(build_id, rule_id)` (see d02).

# COMMAND ----------

if have("policy_findings"):
    cur = spark.table(T("policy_rules")).select("rule_id").distinct()
    old = spark.table(T("policy_findings")).where(F.col("build_id") != BUILD_ID).join(cur, "rule_id", "left_anti")
    lines = old.where(F.col("claim_id").isNotNull()).dropDuplicates(["claim_id", "line_no"])
    n_old, n_lines = old.count(), lines.count()
    if n_old:
        dollars = lines.agg(F.sum("paid_amt")).first()[0] or 0.0
        hist = spark.table(T("policy_rules_history")).select("build_id", "rule_id", "statement", "source_doc", "source_locator")
        by_rule = (old.groupBy("build_id", "rule_id", "origin", "predicate_type")
                   .agg(F.count("*").alias("findings"), F.countDistinct("run_id").alias("runs"))
                   .join(hist.dropDuplicates(["build_id", "rule_id"]), ["build_id", "rule_id"], "left")
                   .orderBy(F.desc("findings")).toPandas())
        print(f"{n_old:,} finding(s) from earlier builds came from {by_rule['rule_id'].nunique():,} rule(s) that are no longer "
              f"in the current build; {n_lines:,} distinct claim line(s), ${float(dollars):,.2f} paid (each line once).")
        show(by_rule, "rules")
    else:
        print("None: every rule that produced a finding in an earlier build is still in the current build.")
