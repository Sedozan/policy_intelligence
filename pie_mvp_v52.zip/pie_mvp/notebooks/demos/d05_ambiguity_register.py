# Databricks notebook source
# MAGIC %md
# MAGIC # d05 · Ambiguity register — policy text that cannot be checked as written
# MAGIC
# MAGIC **What this answers:** where AHCCCS policy language does not turn into a clear, checkable rule — because it depends on
# MAGIC facts not on a claim, is vague, contradicts itself, or conflicts with another source — grouped by reason, with the
# MAGIC exact words and where they are. Exports a workbook for AHCCCS policy staff.
# MAGIC **How to read it:** this is a **policy-improvement** list, not an enforcement list. Each entry is a place where clearer
# MAGIC wording, a code list, or a data field would let the policy be applied consistently.
# MAGIC **Limits:** entries come only from chapters extracted so far. Entries marked `draft` were proposed by the pipeline and not
# MAGIC yet reviewed by a person. Categories are the pipeline's first reading and can be wrong.
# MAGIC
# MAGIC Read-only, except one file: the export workbook under `data/demos/`.

# COMMAND ----------

# MAGIC %pip install -q openpyxl

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
from pyspark.sql import functions as F
import config, state_rules
for _m in (config, state_rules):
    importlib.reload(_m)

EXAMPLES_PER_CATEGORY = 3       # examples printed per category (all entries go in the workbook)
EXPORT = True                   # write the workbook for AHCCCS
EXPORT_DIR = f"{config.WORKSPACE_DATA_DIR}/demos"

# COMMAND ----------

KB = config.KB
CATEGORY_MEANING = {
    "ambiguous_source": "The text says two different things, or can be read two ways.",
    "cross_source_conflict": "The text conflicts with another authority (for example a federal edit).",
    "requires_member_attribute": "The rule depends on a member fact (age, eligibility group, diagnosis) not on the claim line.",
    "requires_medical_record": "The rule can only be checked by reading the medical record.",
    "no_claim_field": "The rule depends on information the claim does not carry.",
    "missing_claim_field": "The rule needs a claim field that is not in our claims extract.",
    "unit_incommensurability": "The limit is in a unit (hours, visits, days) that cannot be converted from billed units.",
    "policy_reference": "The text points to another policy instead of stating a rule.",
    "monthly_aggregation_not_in_grammar": "A limit over time that the rule language cannot express yet.",
    "predicate_not_in_grammar": "A rule shape the rule language cannot express yet.",
    "process_obligation": "A process duty (keep records, notify) rather than a claim rule.",
    "flagged_ambiguous": "Checkable, but a reviewer or the pipeline flagged the wording as unclear.",
    "ncci_edition_disagreement": "NCCI editions (practitioner / outpatient / DME) give different values for the same code; "
                                 "the most permissive one is used.",
}

BUILD_ID = spark.table(f"{KB}.policy_rules").where("build_id IS NOT NULL").select("build_id").first()[0]
reg = spark.table(f"{KB}.policy_ambiguity_register").where(F.col("build_id") == BUILD_ID).toPandas()
print(f"build {BUILD_ID}: {len(reg):,} register entr(ies)")
if not len(reg):
    print("The register is empty for this build. That is not evidence the policy is clear: it only covers extracted chapters.")

# COMMAND ----------

# MAGIC %md ## 1. How many, by reason

# COMMAND ----------

if len(reg):
    reg["meaning"] = reg["category"].map(lambda c: CATEGORY_MEANING.get(c, "Other reason (see the reason column)."))
    counts = (reg.groupby(["category", "meaning"]).agg(entries=("category", "size"),
                                                       chapters=("chapter", lambda s: ", ".join(sorted({str(x) for x in s.dropna()}))),
                                                       approved=("review_status", lambda s: int((s == "approved").sum())),
                                                       hand_seeds=("review_status", lambda s: int((s == "legacy_hand_authored").sum())),
                                                       not_yet_reviewed=("review_status", lambda s: int(s.isin(["draft", "needs_review"]).sum())))
              .reset_index().sort_values("entries", ascending=False))
    display(counts)
    print("by review status:", reg["review_status"].value_counts().to_dict())
    print("Counts are entries, not distinct policy passages: the same passage can appear twice, once as a hand-authored "
          "seed and once as an extracted rule. Hand seeds have no named reviewer.")

# COMMAND ----------

# MAGIC %md ## 2. Examples — the exact words and where they are

# COMMAND ----------

for cat, g in reg.groupby("category") if len(reg) else []:
    print(f"\n=== {cat}: {len(g)} entr(ies) — {CATEGORY_MEANING.get(cat, '')}")
    for r in g.head(EXAMPLES_PER_CATEGORY).to_dict("records"):
        quote = r.get("verbatim_quote") if isinstance(r.get("verbatim_quote"), str) and r["verbatim_quote"].strip() else None
        print(f"  - {r.get('source_doc')}, {r.get('source_locator')}  [{r.get('review_status')}]")
        print(f"    policy text: \"{quote}\"" if quote else f"    (no verbatim quote stored) reading: {r.get('statement')}")
        print(f"    why flagged: {r.get('reason')}")
    if len(g) > EXAMPLES_PER_CATEGORY:
        print(f"  ... {len(g) - EXAMPLES_PER_CATEGORY} more in the workbook.")

# COMMAND ----------

# MAGIC %md ## 3. Export for AHCCCS

# COMMAND ----------

if EXPORT and len(reg):
    out = reg[["category", "meaning", "chapter", "source_doc", "source_locator", "source_url", "verbatim_quote", "statement",
               "reason", "codes", "review_status", "rule_id", "doc_hash"]].rename(columns={
        "meaning": "what_this_category_means", "statement": "pipeline_reading", "reason": "why_flagged"})
    out.insert(0, "note", "Policy-improvement register: wording that cannot be applied consistently as written. Not an enforcement list.")
    out["suggested_fix"] = None                    # for AHCCCS policy staff
    os.makedirs(EXPORT_DIR, exist_ok=True)
    path = state_rules._xlsx_write(out.sort_values(["category", "chapter"]), f"{EXPORT_DIR}/ambiguity_register_{BUILD_ID}.xlsx")
    print(f"wrote {len(out):,} entr(ies) to {path}")
