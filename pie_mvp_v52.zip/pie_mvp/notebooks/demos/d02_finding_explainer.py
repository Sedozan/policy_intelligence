# Databricks notebook source
# MAGIC %md
# MAGIC # d02 · Explain one finding — the audit trail
# MAGIC
# MAGIC **What this answers:** for one flagged claim line, *why* it was flagged: the claim line(s), the rule exactly as it
# MAGIC stood in the build that produced the finding, the policy words it came from, who approved it, and a one-paragraph
# MAGIC explanation an investigator can read.
# MAGIC **How to read it:** top to bottom — evidence, then rule, then source, then the explanation (assembled from the fields
# MAGIC above by a fixed template; no AI writes it).
# MAGIC **Limits:** a finding is a candidate for review, not a confirmed overpayment. NCCI = CMS public edit set, Arizona
# MAGIC deactivations not applied. A PA number on file means a PA exists, not what it authorized.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json, re
import pandas as pd
from pyspark.sql import functions as F
import config
importlib.reload(config)

# Which finding. None = the highest-paid finding of the run. Otherwise a dict of finding columns to match, e.g.
#   {"claim_id": "c1", "line_no": "2", "rule_id": "NCCI-f43988ac77e1be3d"}
# Daily / period-cap findings have no claim_id: match them with {"rule_id": ..., "member_id": ..., "dos" or "period_start": ...}
FINDING = None
RUN_ID  = None          # None = the latest detector run

# COMMAND ----------

KB, CC = config.KB, config.CLAIM_COLS


def T(name):
    return f"{KB}.{name}"


def _v(x):
    """None for missing values (NaN / None / empty)."""
    if x is None:
        return None
    try:
        if pd.isna(x):
            return None
    except (TypeError, ValueError):
        pass
    return None if isinstance(x, str) and not x.strip() else x


runs = spark.table(T("policy_detector_runs"))
RUN_ID = RUN_ID or runs.agg(F.max("run_id")).first()[0]
assert RUN_ID, "no detector run yet - run 08_run_detectors"
fdf = spark.table(T("policy_findings")).where(F.col("run_id") == RUN_ID)
if FINDING:
    for k, v in FINDING.items():
        fdf = fdf.where(F.col(k).cast("string") == str(v))
cands = fdf.orderBy(F.desc_nulls_last("paid_amt"), "rule_id", "claim_id", "line_no", "member_id", "dos", "period_start").toPandas()
if not len(cands):
    raise ValueError(f"no finding in run {RUN_ID} matches {FINDING}" if FINDING else f"run {RUN_ID} has no findings")
if len(cands) > 1:
    print(f"{len(cands):,} finding rows match; explaining the highest-paid one. Narrow FINDING to pick another.")
f = cands.iloc[0].to_dict()
if _v(f.get("claim_id")):
    same = (spark.table(T("policy_findings"))
            .where((F.col("run_id") == RUN_ID) & (F.col("claim_id") == f["claim_id"]) & (F.col("line_no") == f["line_no"])
                   & (F.col("rule_id") != f["rule_id"])).select("rule_id", "origin", "predicate_type").distinct().toPandas())
    if len(same):
        print(f"Claim {f['claim_id']} line {f['line_no']} is ALSO flagged by {len(same)} other rule(s): "
              + ", ".join(f"{a} ({b}, {c})" for a, b, c in same.itertuples(index=False))
              + ". Its paid amount is at issue once, not once per rule.")
print(f"run {RUN_ID} | build {f['build_id']} | rule {f['rule_id']} | origin {f['origin']} | {f['predicate_type']}")
print(f"finding: {f['finding']}  (severity {f['finding_severity']}, paid ${float(f['paid_amt'] or 0):,.2f})")

# COMMAND ----------

# MAGIC %md ## 1. The claim line(s)
# MAGIC For a code pair, the flagged line is the **Column Two** line (the one CMS denies); the Column One line is shown beside it.
# MAGIC For a daily or period cap, every line that adds up to the over-limit total is listed.

# COMMAND ----------

pairs = []
if _v(f.get("claim_id")):
    pairs.append((str(f["claim_id"]), str(f["line_no"]), "flagged line"))
if _v(f.get("col1_claim_id")):
    pairs.append((str(f["col1_claim_id"]), str(f["col1_line_no"]), "column one line (billed with it)"))
for ev in (_v(f.get("evidence_lines")) or "").split(","):
    m = re.match(r"^(.*):([^:]*)$", ev.strip())
    if m and (m.group(1), m.group(2)) not in {(a, b) for a, b, _ in pairs}:
        pairs.append((m.group(1), m.group(2), "contributes to the total"))

cols = [(k, CC[k]) for k in ("claim_id", "line_no", "member", "servicing_provider", "billing_provider", "dos", "code",
                             "units", "paid_amt", "pos", "form", "pa_no") if isinstance(CC.get(k), str)]
lines = pd.DataFrame()
if pairs:
    keys = spark.createDataFrame(pd.DataFrame(pairs, columns=["k_claim", "k_line", "role"]),
                                  "k_claim string, k_line string, role string")
    claims = spark.table(config.CLAIMS_TABLE)
    lines = (claims.join(keys, (claims[CC["claim_id"]].cast("string") == keys["k_claim"]) &
                         (claims[CC["line_no"]].cast("string") == keys["k_line"]))
             .select("role", *[F.col(p).cast("string").alias(k) for k, p in cols],
                     F.concat_ws(" ", *[F.coalesce(F.col(m), F.lit("")) for m in CC["mods"]]).alias("modifiers"))
             .toPandas())
    missing = len(pairs) - len(lines)
    display(lines)
    if missing > 0:
        print(f"  {missing} referenced line(s) were not found in {config.CLAIMS_TABLE} (claims table changed since the run?).")
else:
    print("This finding lists no claim lines.")

# COMMAND ----------

# MAGIC %md ## 2. The rule, as it stood in the build that produced the finding
# MAGIC Joined from `policy_rules_history` on `(build_id, rule_id)` — not from today's rule table, which may have changed.

# COMMAND ----------

hist = (spark.table(T("policy_rules_history"))
        .where((F.col("build_id") == f["build_id"]) & (F.col("rule_id") == f["rule_id"])).toPandas())
if not len(hist):
    raise RuntimeError(f"rule {f['rule_id']} of build {f['build_id']} is not in policy_rules_history - this finding cannot be "
                       "traced (it predates build_id tracking, or the history table was rebuilt).")
r = hist.iloc[0].to_dict()
dh = (spark.table(T("policy_detectors_history"))
      .where((F.col("build_id") == f["build_id"]) & (F.col("rule_id") == f["rule_id"])).toPandas())
det = dh.iloc[0].to_dict() if len(dh) else {}

quote, quote_from = None, None
m = re.search(r'Verbatim: "(.*)" Found by:', str(r.get("notes") or ""), re.S) or \
    re.search(r'Verbatim: "(.*)"', str(r.get("notes") or ""), re.S)
if m:
    quote, quote_from = m.group(1), "rule notes at that build"
elif r.get("origin") != "ncci" and _v(r.get("extraction_key")):
    s = (spark.table(config.STATE_RULES_TABLE).where(F.col("extraction_key") == r["extraction_key"])
         .select("verbatim_quote").toPandas())
    if len(s) and _v(s.iloc[0]["verbatim_quote"]):
        quote, quote_from = s.iloc[0]["verbatim_quote"], "state_rules today (the build does not store the quote)"

is_ncci = r.get("origin") == "ncci"
rule_view = {
    "rule_id": r["rule_id"], "build_id": r["build_id"], "built_at": r.get("built_at"),
    "statement": r.get("statement"), "predicate": r.get("predicate"),
    "effective window": f"{_v(r.get('effective_date')) or 'start of data'} to {_v(r.get('end_date')) or 'still in force'}",
    "verbatim quote": quote or ("(none - NCCI rows are table data, not prose)" if is_ncci else "(not recorded)"),
    "quote taken from": quote_from,
    "source": r.get("source_doc"), "locator": r.get("source_locator"), "url": r.get("source_url"),
    "doc_version": r.get("doc_version"), "doc_hash": r.get("doc_hash"),
    "reviewer": "federal table" if is_ncci else (_v(r.get("reviewer")) or "(none)"),
    "reviewed_at": _v(r.get("reviewed_at")), "review_status": r.get("review_status"),
    "gate": r.get("validation_status"), "reconciliation": _v(r.get("reconciliation")),
    "detector severity / routing": f"{det.get('finding_severity')} / {det.get('routing')}" if det else None,
    "notes": r.get("notes"),
}
display(pd.DataFrame({"field": list(rule_view), "value": [None if v is None else str(v) for v in rule_view.values()]}))

# COMMAND ----------

# MAGIC %md ## 3. Plain-English explanation (template, no AI)

# COMMAND ----------

PA_MEANING = {
    "not_evaluated": "Prior authorization was not considered: CMS says a PA does not bypass an NCCI edit.",
    "pa_on_file": ("A PA number is on file for this service. The PA may authorize the extra units or the combination, "
                   "so check the PA before treating this as an error."),
    "no_pa_on_file": "No PA number is on file for the lines involved.",
}


def money(x):
    return f"${float(x or 0):,.2f}"


def units(u):
    try:
        return f"{float(u):g}"
    except (TypeError, ValueError):
        return str(u)


def line_text(row):
    return (f"claim {row['claim_id']} line {row['line_no']} ({row.get('code')}, {units(row.get('units'))} unit(s), "
            f"paid {money(row.get('paid_amt'))}, provider {row.get('servicing_provider')}, "
            f"service date {row.get('dos')}" + (f", modifiers {row['modifiers']}" if str(row.get('modifiers') or '').strip() else "") + ")")


flag = lines[lines["role"] == "flagged line"] if len(lines) else pd.DataFrame()
col1 = lines[lines["role"].str.startswith("column one")] if len(lines) else pd.DataFrame()
contrib = lines[lines["role"] == "contributes to the total"] if len(lines) else pd.DataFrame()

what = []
if len(flag):
    what.append(f"The flagged line is {line_text(flag.iloc[0].to_dict())}")
    if len(col1):
        what.append(f"It was billed with {line_text(col1.iloc[0].to_dict())}")
elif len(contrib):
    what.append(f"Member {f.get('member_id')} has {len(contrib)} line(s) that add up to {units(f.get('observed_units'))} unit(s) "
                f"for {_v(f.get('dos')) or _v(f.get('period_start'))}, over the limit of {units(f.get('allowed_units'))}; "
                f"together they were paid {money(f.get('paid_amt'))}")
pred = json.loads(r["predicate"]) if isinstance(r.get("predicate"), str) else {}
if is_ncci:
    who = (f"The CMS Medicaid NCCI edit ({r.get('source_locator')}, loaded from {r.get('doc_version')}) says: "
           f"\"{r.get('statement')}\"")
    if pred.get("type") == "code_pair_prohibited":
        who += (" No modifier can bypass this edit." if str(pred.get("modifier_indicator")) == "0" else
                " An NCCI-associated modifier could bypass it, but none that bypasses it was found on either line.")
    signed = "This is a federal table row; no AHCCCS reviewer signs NCCI edits, and Arizona-specific deactivations are not applied."
else:
    who = (f"AHCCCS policy ({r.get('source_doc')}, {r.get('source_locator')}"
           + (f", {r.get('doc_version')}" if _v(r.get('doc_version')) else "") + f") is read as: \"{r.get('statement')}\"")
    if quote:
        who += f" The policy text says: \"{quote}\""
    if r.get("review_status") == "approved" and _v(r.get("reviewer")):
        signed = f"This reading was approved by {r['reviewer']} on {r.get('reviewed_at')} against document {str(r.get('doc_hash') or '')[:12]}."
    elif r.get("review_status") == "legacy_hand_authored":
        signed = "This is a hand-authored seed rule; no named reviewer has signed it."
    else:
        signed = f"Review status at build time: {r.get('review_status')}."
explanation = " ".join(s if s.endswith((".", '."')) else s + "." for s in what + [who, signed, PA_MEANING.get(f.get("pa_status"), "")] if s) + \
    " This is a candidate for review, not a confirmed overpayment."
print(explanation)
