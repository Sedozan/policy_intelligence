# Databricks notebook source
# MAGIC %md
# MAGIC # d09 · Search the policy text
# MAGIC
# MAGIC **What this answers:** where a phrase (e.g. "prior authorization") appears in the current version of every extracted
# MAGIC manual chapter — chapter, heading, pages, the words around it — and what the pipeline did with that section
# MAGIC (skipped, found no rules, proposed rules) and which rules came from it.
# MAGIC **How to read it:** an exact, case-insensitive phrase match. "skipped_prefilter" means the section never reached rule
# MAGIC extraction because it had no rule signal words; a hit there is worth a human look.
# MAGIC **Limits:** keyword search only — no synonyms, no meaning. Semantic search (embeddings) is a charter item that is not
# MAGIC built yet. Only chapters that have been extracted are searchable.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, re
import pandas as pd
from pyspark.sql import Window, functions as F
import config
importlib.reload(config)

QUERY         = "prior authorization"   # exact phrase, case-insensitive
CHAPTERS      = None                    # None = every extracted chapter; or e.g. ["10", "19"]
MAX_HITS      = 25                      # sections shown (the notebook says how many more matched)
SNIPPET_CHARS = 160                     # characters of context on each side of the first hit

# COMMAND ----------

KB = config.KB
q = str(QUERY or "").strip().lower()
assert q, "set QUERY"

inv = spark.table(f"{KB}.policy_document_inventory").toPandas().sort_values("fetched_at")
current = inv.groupby(inv["chapter"].astype(str))["doc_hash"].last().to_dict()
cur_df = spark.createDataFrame(pd.DataFrame({"chapter": list(current), "doc_hash": list(current.values())}),
                               "chapter string, doc_hash string")
w = Window.partitionBy("chapter", "doc_hash", "section_id").orderBy(F.desc("run_id"))
sec = (spark.table(f"{KB}.policy_sections").withColumn("chapter", F.col("chapter").cast("string"))
       .join(cur_df, ["chapter", "doc_hash"])
       .withColumn("_r", F.row_number().over(w)).where("_r = 1").drop("_r"))
if CHAPTERS:
    sec = sec.where(F.col("chapter").isin([str(c) for c in CHAPTERS]))
n_sec = sec.count()
hits = (sec.where(F.lower("text").contains(q) | F.lower("heading").contains(q))
        .withColumn("occurrences", F.floor((F.length(F.lower("text")) - F.length(F.regexp_replace(F.lower("text"), re.escape(q), "")))
                                           / F.lit(len(q))))
        .select("chapter", "section_id", "doc_hash", "heading", "page_start", "page_end", "occurrences", "text")
        .toPandas())
print(f"'{QUERY}': {len(hits):,} of {n_sec:,} current section(s) match, in {hits['chapter'].nunique() if len(hits) else 0} chapter(s) "
      f"(searched: {', '.join(sorted(current, key=lambda c: (len(c), c))) if not CHAPTERS else ', '.join(map(str, CHAPTERS))}).")

# COMMAND ----------

# MAGIC %md ## Matches, with the extraction outcome of each section

# COMMAND ----------

wo = Window.partitionBy("section_id", "doc_hash").orderBy(F.desc("run_id"))
outc = (spark.table(f"{KB}.policy_extraction_outcomes").withColumn("_r", F.row_number().over(wo)).where("_r = 1")
        .select("section_id", "doc_hash", "outcome", "reason", "n_grounded").toPandas())
sr = spark.table(config.STATE_RULES_TABLE).where(F.col("section_id").isNotNull()).select(
    "section_id", "doc_hash", "review_status", "statement").toPandas()


def snippet(text):
    t = str(text or "")
    i = t.lower().find(q)
    if i < 0:
        return t[: 2 * SNIPPET_CHARS]
    a, b = max(0, i - SNIPPET_CHARS), min(len(t), i + len(q) + SNIPPET_CHARS)
    return ("..." if a else "") + t[a:i] + "[" + t[i:i + len(q)] + "]" + t[i + len(q):b] + ("..." if b < len(t) else "")


if len(hits):
    hits["snippet"] = hits["text"].map(snippet)
    hits["pages"] = hits.apply(lambda r: f"{r['page_start']}" + (f"-{r['page_end']}" if r["page_end"] != r["page_start"] else ""), axis=1)
    hits = hits.merge(outc, on=["section_id", "doc_hash"], how="left")
    rules = (sr.groupby(["section_id", "doc_hash"]).agg(
        rules_from_section=("statement", "size"),
        rule_statuses=("review_status", lambda s: ", ".join(f"{k} {v}" for k, v in s.value_counts().items())))
        .reset_index())
    hits = hits.merge(rules, on=["section_id", "doc_hash"], how="left")
    hits["rules_from_section"] = hits["rules_from_section"].fillna(0).astype(int)
    hits["outcome"] = hits["outcome"].fillna("(no outcome recorded)")
    hits = hits.sort_values(["chapter", "page_start"], key=lambda s: s.map(lambda v: (len(str(v)), str(v))) if s.name == "chapter" else s)
    display(hits[["chapter", "heading", "pages", "occurrences", "snippet", "outcome", "reason", "rules_from_section",
                  "rule_statuses"]].head(MAX_HITS))
    if len(hits) > MAX_HITS:
        print(f"  ... {len(hits) - MAX_HITS:,} more matching section(s) not shown. Raise MAX_HITS or narrow CHAPTERS.")
    print("outcome of matching sections:", hits["outcome"].value_counts().to_dict())
    sk = hits[hits["outcome"].isin(["skipped_prefilter", "no_rules"])]
    if len(sk):
        print(f"{len(sk)} matching section(s) produced no rules (skipped by the pre-filter or no rules found). If the phrase "
              "states a requirement there, that is a possible missed rule - the recall sheet in validation/v01 measures this.")
else:
    print(f"No current section contains '{QUERY}'. Only extracted chapters are searched; try a shorter phrase.")
