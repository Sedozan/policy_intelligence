# Databricks notebook source
# MAGIC %md
# MAGIC # d03 · Provider review — who has the most flagged dollars, and is it unusual?
# MAGIC
# MAGIC **What this answers:** which servicing providers carry the most flagged paid dollars in the latest detector run,
# MAGIC which rules flag them, and whether their share of flagged lines is high compared with other providers billing the same codes.
# MAGIC **How to read it:** dollars count each claim line once, even when several rules flag it. "Peer rate" is what the
# MAGIC provider's flag rate would be if, code by code, they matched the median provider billing that code.
# MAGIC **Limits:** findings are candidates for review, not confirmed overpayments. A high rate can be legitimate (a specialty
# MAGIC practice, a PA on file). For daily/monthly caps every line that adds to the over-limit total is counted in full, so
# MAGIC those dollars overstate the excess. NCCI = CMS public edit set, Arizona deactivations not applied.
# MAGIC
# MAGIC Read-only.

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/demos/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
from pyspark.sql import functions as F
import config
importlib.reload(config)

RUN_ID    = None        # None = the latest detector run
TOP_N     = 20          # providers in the ranking (the notebook says how many more there are)
MIN_PEERS = 5           # a code needs at least this many billing providers to be used in the peer comparison
PROVIDER  = None        # a servicing provider id to drill into; None = the top-ranked provider

# COMMAND ----------

KB, CC = config.KB, config.CLAIM_COLS


def T(name):
    return f"{KB}.{name}"


def show(df, what, n):
    if not len(df):
        print(f"  (no {what})")
        return
    display(df.head(n))
    if len(df) > n:
        print(f"  ... {len(df) - n:,} more {what} not shown (of {len(df):,}).")


RUN_ID = RUN_ID or spark.table(T("policy_detector_runs")).agg(F.max("run_id")).first()[0]
assert RUN_ID, "no detector run yet - run 08_run_detectors"
fdf = spark.table(T("policy_findings")).where(F.col("run_id") == RUN_ID)
claims = spark.table(config.CLAIMS_TABLE).select(
    F.col(CC["claim_id"]).cast("string").alias("k_claim"), F.col(CC["line_no"]).cast("string").alias("k_line"),
    F.col(CC["servicing_provider"]).cast("string").alias("provider"), F.col(CC["code"]).cast("string").alias("code"),
    F.col(CC["paid_amt"]).cast("double").alias("paid"))


def flagged_lines(f):
    """One row per (finding, claim line it concerns). Line findings -> the flagged line (for pairs: the Column Two
    line). Daily / period caps -> every line listed in evidence_lines. Provider, code and paid come from the claims table."""
    keep = ["rule_id", "origin", "predicate_type", "build_id"]
    line = f.where(F.col("claim_id").isNotNull()).select(
        *keep, F.col("claim_id").alias("k_claim"), F.col("line_no").alias("k_line"), F.lit("line").alias("grain"))
    ev = (f.where(F.col("claim_id").isNull() & F.col("evidence_lines").isNotNull())
          .select(*keep, F.explode(F.split("evidence_lines", ",")).alias("ev"))
          .select(*keep, F.regexp_extract(F.trim("ev"), r"^(.*):([^:]*)$", 1).alias("k_claim"),
                  F.regexp_extract(F.trim("ev"), r"^(.*):([^:]*)$", 2).alias("k_line"), F.lit("aggregate").alias("grain")))
    return line.unionByName(ev).join(claims, ["k_claim", "k_line"], "left")


fl = flagged_lines(fdf)          # no .cache(): not supported on serverless compute
n_find = fdf.count()
unmatched = fl.where(F.col("provider").isNull()).count()
distinct_lines = fl.select("k_claim", "k_line", "provider", "paid").dropDuplicates(["k_claim", "k_line"])
tot = distinct_lines.agg(F.count("*").alias("lines"), F.sum("paid").alias("paid")).first()
print(f"run {RUN_ID}: {n_find:,} finding(s) touch {tot['lines']:,} distinct claim line(s), ${float(tot['paid'] or 0):,.2f} paid "
      "(each line counted once).")
if unmatched:
    print(f"  {unmatched:,} finding line(s) could not be matched back to the claims table and have no provider.")

# COMMAND ----------

# MAGIC %md ## 1. Providers ranked by distinct flagged paid dollars

# COMMAND ----------

prov = (distinct_lines.groupBy("provider").agg(F.count("*").alias("flagged_lines"), F.round(F.sum("paid"), 2).alias("flagged_paid"))
        .join(fl.groupBy("provider").agg(F.countDistinct("rule_id").alias("rules"),
                                         F.countDistinct("predicate_type").alias("rule_types")), "provider")
        .join(claims.groupBy("provider").agg(F.count("*").alias("all_lines"), F.round(F.sum("paid"), 2).alias("all_paid")),
              "provider", "left")
        .withColumn("pct_of_paid_flagged", F.round(100 * F.col("flagged_paid") / F.col("all_paid"), 1))
        .orderBy(F.desc("flagged_paid"), "provider").toPandas())
show(prov, "providers", TOP_N)

# COMMAND ----------

# MAGIC %md ## 2. What flags them — by rule type
# MAGIC Within one provider a line flagged by two rule types appears in both rows; the provider total above counts it once.

# COMMAND ----------

top = prov.head(TOP_N)["provider"].tolist()
by_type = (fl.where(F.col("provider").isin(top))
           .dropDuplicates(["provider", "origin", "predicate_type", "k_claim", "k_line"])
           .groupBy("provider", "origin", "predicate_type")
           .agg(F.count("*").alias("lines"), F.round(F.sum("paid"), 2).alias("paid"))
           .orderBy("provider", F.desc("paid")).toPandas())
show(by_type, "provider x rule-type rows", TOP_N * 4)

# COMMAND ----------

# MAGIC %md ## 3. Flag rate compared with peers billing the same codes
# MAGIC For every flagged code: each provider's share of its lines on that code that were flagged, and the **median** of that
# MAGIC share across providers billing the code. A provider's *peer rate* weights those medians by the provider's own mix of codes.
# MAGIC `excess_lines` = flagged lines minus what the peer rate predicts. Medians are often 0 (most providers are never flagged),
# MAGIC so read `excess_lines`, not a ratio.

# COMMAND ----------

codes = fl.select("code").where(F.col("code").isNotNull()).distinct()
vol = claims.join(codes, "code").groupBy("provider", "code").agg(F.count("*").alias("lines"))
flg = (fl.dropDuplicates(["k_claim", "k_line"]).where(F.col("code").isNotNull())
       .groupBy("provider", "code").agg(F.count("*").alias("flagged")))
pc = vol.join(flg, ["provider", "code"], "left").fillna(0, ["flagged"]).withColumn("rate", F.col("flagged") / F.col("lines"))
peer = pc.groupBy("code").agg(F.percentile_approx("rate", 0.5).alias("median_rate"), F.countDistinct("provider").alias("peers"))
pc = pc.join(peer, "code")
thin = pc.where(F.col("peers") < MIN_PEERS).agg(F.countDistinct("code").alias("codes"), F.sum("flagged").alias("flagged")).first()
if thin["codes"]:
    print(f"{thin['codes']:,} flagged code(s) have fewer than {MIN_PEERS} billing providers; their {int(thin['flagged'] or 0):,} "
          "flagged line(s) are left out of the peer comparison (too few peers to call anything unusual).")
cmp_ = (pc.where(F.col("peers") >= MIN_PEERS).groupBy("provider")
        .agg(F.sum("lines").alias("lines_on_flagged_codes"), F.sum("flagged").alias("flagged_lines"),
             F.sum(F.col("lines") * F.col("median_rate")).alias("expected_at_peer_median"),
             F.countDistinct("code").alias("codes_compared"))
        .withColumn("flag_rate", F.round(F.col("flagged_lines") / F.col("lines_on_flagged_codes"), 4))
        .withColumn("peer_rate", F.round(F.col("expected_at_peer_median") / F.col("lines_on_flagged_codes"), 4))
        .withColumn("excess_lines", F.round(F.col("flagged_lines") - F.col("expected_at_peer_median"), 1))
        .orderBy(F.desc("excess_lines"), "provider").toPandas())
if len(cmp_):
    show(cmp_[["provider", "codes_compared", "lines_on_flagged_codes", "flagged_lines", "flag_rate", "peer_rate", "excess_lines"]],
         "providers", TOP_N)
else:
    print("No code has enough billing providers for a peer comparison on this data.")

# COMMAND ----------

# MAGIC %md ## 4. Drill into one provider

# COMMAND ----------

P = PROVIDER or (prov.iloc[0]["provider"] if len(prov) else None)
if P is None:
    print("No flagged providers in this run.")
else:
    mine = fl.where(F.col("provider") == str(P))
    stmts = (spark.table(T("policy_rules_history")).join(mine.select("build_id", "rule_id").distinct(), ["build_id", "rule_id"])
             .select("rule_id", "statement", "source_doc", "source_locator").dropDuplicates(["rule_id"]))
    by_rule = (mine.dropDuplicates(["rule_id", "k_claim", "k_line"]).groupBy("rule_id", "origin", "predicate_type")
               .agg(F.count("*").alias("lines"), F.round(F.sum("paid"), 2).alias("paid"))
               .join(stmts, "rule_id", "left").orderBy(F.desc("paid")).toPandas())
    print(f"provider {P}: {len(by_rule)} rule(s) flag its lines. Rows can overlap when two rules flag the same line.")
    show(by_rule, "rules", TOP_N)
    lines = (mine.groupBy("k_claim", "k_line", "code", "paid")
             .agg(F.collect_set("rule_id").alias("rules"), F.collect_set("predicate_type").alias("rule_types"))
             .orderBy(F.desc("paid"), "k_claim", "k_line").toPandas())
    print(f"its {len(lines):,} flagged line(s), highest paid first (open one with d02_finding_explainer):")
    show(lines, "lines", TOP_N)
