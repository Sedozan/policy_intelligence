# Databricks notebook source
# MAGIC %md
# MAGIC # 08 · Run detectors against paid claims  (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Runs the build in `main.policy_kb` over the **whole** claims table.
# MAGIC
# MAGIC 1. **Build check** — every current table must carry the same `build_id`, the build log must say that build is
# MAGIC    `complete`, and each stored query must carry and still hash to the `sql_sha256` recorded for it. Otherwise nothing
# MAGIC    runs. **Validation:** a query a validator marked `PROBLEM` in v06 (for its current SQL) is not run; with
# MAGIC    `config.RUN_ONLY_VALIDATED_QUERIES = True` only queries signed `OK` run. Every finding carries `query_validation`
# MAGIC    (`OK` / `not_validated`). The checks are `run_guard.py` (tested offline).
# MAGIC 2. **Detection snapshot** — `policy_claims_snapshot` is rebuilt from the claims table: codes / modifiers trimmed
# MAGIC    and upper-cased, exact duplicate rows removed, rows with no member dropped, `$0` / reversal / reversed lines marked
# MAGIC    not payable, date of birth read as a date. Its row counts and Delta version are logged with the run, so any finding
# MAGIC    can be re-produced later by re-running the stored SQL against that snapshot version.
# MAGIC 3. **NCCI** — two table-driven statements (all PTP pairs, all per-line MUEs) for every federal edit at once, each
# MAGIC    on the lines that take its edit file (CMS TGM Table 2: billing provider type code × claim form, the servicing
# MAGIC    type as fallback — the snapshot's `pie_ncci_edition`; never dental, pharmacy, inpatient or residential).
# MAGIC    **Signed routing:** with `config.NCCI_REQUIRE_SIGNED_ROUTING = True` (default) the NCCI statements run only when
# MAGIC    every provider type code on the snapshot's CMS-1500 / UB-04 lines has a signed row in
# MAGIC    `reference/ncci_provider_type_routing.csv`; otherwise they are recorded as not run, with the codes to sign.
# MAGIC    Then (CMS TGM App. B: "Apply the NCCI PTP edit ... only if the Column One code is eligible for payment") a pair
# MAGIC    finding whose Column One lines are ALL themselves denied in this run becomes `verify_col1_not_payable`.
# MAGIC 3b. **AHCCCS rule tables** (v5.2) — three table-driven statements (Same Day Disallow pairs, daily limits, B2-matrix
# MAGIC    provider types), every signed version at once. They are STATE rules: no NCCI edit file, not held back by the NCCI
# MAGIC    routing gate (`ncci_routing` is empty on their findings), a PA on file makes a finding `verify_pa`; a statement a
# MAGIC    validator marked `PROBLEM` (v06) does not run. Findings carry `origin = 'ahcccs_table'`.
# MAGIC 3c. **Same Day pairs disallowed both ways** (v5.2b) — both lines of such a pair are flagged although AHCCCS would deny
# MAGIC    one: the run log keeps those findings and the dollars they count twice.
# MAGIC 4. **State** — one statement per compiled rule.
# MAGIC 5. **Utilization signals** (not findings) — for period limits: the most units per member in any rolling window of the
# MAGIC    period's length, and whether the fixed contract-year check also fired. Written to `policy_utilization_signals`.
# MAGIC
# MAGIC Writes `policy_findings` (one row per finding: a flagged line, a Column Two line of a pair, or a member-day/-period),
# MAGIC `policy_detector_runs` (one row per state detector, per batched NCCI / AHCCCS table rule that fired, one summary row
# MAGIC per batch, one `SIGNAL:` row per utilization-signal query, one `RUN:` row with the snapshot numbers),
# MAGIC `policy_utilization_signals`.
# MAGIC
# MAGIC `pa_status`: `not_evaluated` (NCCI — CMS: PA is not an NCCI bypass) · `pa_on_file` (severity `verify_pa`) · `no_pa_on_file`.
# MAGIC Dollars: `paid_amt` is what the flagged line (or the whole member-day / period group) was paid; `paid_at_risk` is the
# MAGIC part attributable to the units over the limit (whole line for a line edit). Totals below count each claim line once.
# MAGIC
# MAGIC Next: `demos/` and `validation/` (v06 builds the query validation pack).

# COMMAND ----------

import os, sys, time, json, uuid, hashlib
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
from pyspark.sql import functions as F
from pyspark.sql import Window
import config, kb_io, detector_gen, ncci_routing, run_guard
for m in (config, kb_io, detector_gen, ncci_routing, run_guard):
    importlib.reload(m)

KB                    = config.KB
FMT                   = getattr(config, "TABLE_FORMAT", "delta")
RUN_NCCI_BATCH        = True
RUN_AHCCCS_TABLES     = True      # 2026-10-04 (v5.2): the three AHCCCS rule-table statements (state rules)
RUN_STATE             = True
RUN_SIGNALS           = True
MAX_ROWS_PER_DETECTOR = None      # None = keep every finding. If set: the first N per RULE by (claim, line) - deterministic.
INCLUDE_UNROUTED      = False     # UNROUTED detectors (a service category with no form mapping) over-flag
SNAPSHOT              = detector_gen.DETECT

det = spark.table(f"{KB}.policy_detectors").toPandas()
BUILD_ID = str(det["build_id"].dropna().iloc[0]) if "build_id" in det and det["build_id"].notna().any() else None
assert BUILD_ID, "policy_detectors has no build_id - run 07_build_kb with this package version first"
batches = (spark.table(f"{KB}.policy_batch_detectors").toPandas() if (RUN_NCCI_BATCH or RUN_AHCCCS_TABLES)
           else pd.DataFrame())
# 2026-10-04 (v5.2): policy_batch_detectors holds the two NCCI statements and the three AHCCCS table statements
_bk = batches["batch"].astype(str) if len(batches) else pd.Series(dtype=str)
ncci_batches = batches[_bk.isin([detector_gen.BATCH_PTP, detector_gen.BATCH_MUE])] if RUN_NCCI_BATCH and len(batches) \
    else pd.DataFrame()
table_batches = batches[_bk.isin(detector_gen.TABLE_BATCHES)] if RUN_AHCCCS_TABLES and len(batches) else pd.DataFrame()

# COMMAND ----------

# MAGIC %md ## 1. Build check — one complete build, untouched queries

# COMMAND ----------

ids = {"policy_detectors": set(det["build_id"].dropna().astype(str))}
problems = []
if RUN_NCCI_BATCH or RUN_AHCCCS_TABLES:
    ids["policy_batch_detectors"] = set(batches["build_id"].dropna().astype(str)) if len(batches) else set()
_edit_tables = ((["policy_ncci_ptp_edits", "policy_ncci_mue_limits"] if RUN_NCCI_BATCH else [])
                + (list(detector_gen.TABLE_BATCH_EDIT_TABLE.values()) if RUN_AHCCCS_TABLES else []))
for t in _edit_tables:
    try:
        ids[t] = {str(r[0]) for r in spark.sql(f"SELECT DISTINCT build_id FROM {KB}.{t}").collect()}
    except Exception as e:
        problems.append(f"{t} not readable: {type(e).__name__}: {e}")
try:
    blog = spark.table(f"{KB}.policy_build_log").toPandas()
except Exception as e:
    blog = None
    problems.append(f"policy_build_log not readable: {type(e).__name__}: {e}")
# one complete build; every stored statement (state, NCCI batch, AHCCCS table batch, signal) carries its sha256 and still
# matches it
problems += run_guard.build_problems(det, batches if (RUN_NCCI_BATCH or RUN_AHCCCS_TABLES) else None, ids, blog, BUILD_ID)
if problems:
    raise RuntimeError("BUILD CHECK FAILED - nothing was run:\n  - " + "\n  - ".join(problems))
state = det[(det["compiled"] == True) & det["sql"].notna()].copy()
# the validator's decisions (v06) in force for the CURRENT SQL of each query
try:
    _qv = spark.table(f"{KB}.policy_query_validation").toPandas()
except Exception:
    _qv = None                                                  # nothing validated yet
QSTATUS = run_guard.validation_status(_qv, run_guard.current_hashes(det, batches if (RUN_NCCI_BATCH or RUN_AHCCCS_TABLES)
                                                                    else None))
_vc = pd.Series(list(QSTATUS.values())).value_counts().to_dict() if QSTATUS else {}
print(f"query validation (v06) for the current SQL: {_vc}"
      + ("  - RUN_ONLY_VALIDATED_QUERIES: only OK queries run" if run_guard.only_validated() else ""))
for _q, _st in QSTATUS.items():
    if run_guard.skip_reason(_st) and _st == run_guard.PROBLEM:
        print(f"  NOT RUN (validator PROBLEM): {_q}")
if not INCLUDE_UNROUTED:
    state = state[~state["routing"].astype(str).str.startswith("UNROUTED")]
batched_rules = int(det["batch"].notna().sum()) if "batch" in det else 0
table_rules_n = int(det["batch"].isin(detector_gen.TABLE_BATCHES).sum()) if "batch" in det else 0
DET_ELIGIBLE = len(state) + batched_rules
print(f"build {BUILD_ID} OK: {len(state)} per-rule state queries + {batched_rules - table_rules_n:,} NCCI rules in "
      f"{len(ncci_batches)} batch statement(s) + {table_rules_n:,} AHCCCS table rules in {len(table_batches)} "
      f"statement(s)")

run_id = pd.Timestamp.now().strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:6]     # C1-20: never collide
FINDINGS = f"{KB}.policy_findings"

# COMMAND ----------

# MAGIC %md ## 2. Detection snapshot

# COMMAND ----------

t0 = time.time()
SNAPSHOT_SQL = detector_gen.create_snapshot(spark)          # the SELECT it ran (hashed into the run log)
snap = spark.sql(detector_gen.snapshot_stats_sql()).toPandas().iloc[0].to_dict()
snap = {k: (int(v) if v is not None and not pd.isna(v) else None) for k, v in snap.items()}


def _version(fqn):
    try:
        return int(spark.sql(f"DESCRIBE HISTORY {fqn} LIMIT 1").collect()[0]["version"])
    except Exception:
        return None


snap.update(snapshot_version=_version(SNAPSHOT), claims_version=_version(config.CLAIMS_TABLE),
            snapshot_sql_sha256=detector_gen.sql_sha256(SNAPSHOT_SQL), seconds=round(time.time() - t0, 1))
print("snapshot:", json.dumps(snap))
dropped = (snap.get("source_rows") or 0) - (snap.get("snapshot_rows") or 0)
if dropped:
    print(f"  {dropped:,} source row(s) not in the snapshot (exact duplicates, or no member / date / code)")
if snap.get("cancelled_lines") or snap.get("reversal_rows"):
    print(f"  {snap['reversal_rows']:,} reversal row(s) and {snap['cancelled_lines']:,} line(s) they reverse are not "
          f"payable: no line-level finding uses them (aggregates net them out)")
# 2026-10-05 (critic re-check N2): what the v2.6 AHCCCS table readings cannot judge (misses, never findings) - in the
# run log via `snap`
if snap.get("payable_lines_no_billing_id"):
    print(f"  {snap['payable_lines_no_billing_id']:,} payable line(s) have no billing provider id: an AHCCCS A* pair or "
          f"daily limit (same servicing AND billing provider) never pairs or counts them")
if snap.get("payable_group_lines_no_rendering_type"):
    print(f"  {snap['payable_group_lines_no_rendering_type']:,} payable line(s) billed by a group have no rendering "
          f"provider type: a B2 rule (billing_or_rendering) cannot judge them")
if snap.get("snapshot_rows") and (snap.get("dob_missing_lines") or 0) > 0.5 * snap["snapshot_rows"]:
    print(f"  WARNING: {snap['dob_missing_lines']:,} of {snap['snapshot_rows']:,} lines have no usable date of birth - "
          f"age rules cannot match them. If {config.CLAIM_COLS.get('dob')} is text, set config.DOB_FORMAT.")

# NCCI routing must be SIGNED for every provider type that decides it on this snapshot (CMS-1500 / UB-04 lines,
# billing and servicing type): config.NCCI_REQUIRE_SIGNED_ROUTING, run_guard.ncci_routing_gate (2026-10-04)
OBSERVED_TYPES = ([r["t"] for r in spark.sql(ncci_routing.observed_types_sql(SNAPSHOT, detector_gen.COL["form"])).collect()]
                  if ncci_routing.uses_table() else [])
UNSIGNED_TYPES = ncci_routing.unsigned_observed(OBSERVED_TYPES) if ncci_routing.uses_table() else []
NCCI_GATE = run_guard.ncci_routing_gate(OBSERVED_TYPES)
# signed | unsigned | form_fallback | form_only - in the run log and on every NCCI finding (column ncci_routing)
NCCI_ROUTING_KIND = run_guard.ncci_routing_kind(OBSERVED_TYPES)
print(f"NCCI routing ({ncci_routing.mode()}, unmapped types -> {ncci_routing.unmapped_rule()}): "
      f"{len(OBSERVED_TYPES)} provider type code(s) on CMS-1500 / UB-04 lines, {len(UNSIGNED_TYPES)} without a signed "
      f"routing row -> {NCCI_ROUTING_KIND}")
if NCCI_GATE and RUN_NCCI_BATCH:
    print(f"  NCCI NOT RUN - {NCCI_GATE}")
elif NCCI_ROUTING_KIND != "signed" and RUN_NCCI_BATCH:
    print(f"  WARNING: NCCI runs on routing nobody signed ({NCCI_ROUTING_KIND}; config.NCCI_REQUIRE_SIGNED_ROUTING = "
          f"False){': ' + ', '.join(UNSIGNED_TYPES[:20]) if UNSIGNED_TYPES else ''} - exploratory findings, not "
          f"definitive; every NCCI finding of this run says ncci_routing = '{NCCI_ROUTING_KIND}'")

# COMMAND ----------

# One fixed schema. Types match what earlier runs wrote, so appends never hit a type conflict.
_SCHEMA = [("run_id", "string"), ("build_id", "string"), ("finding_id", "string"), ("rule_id", "string"),
           ("extraction_key", "string"), ("origin", "string"), ("predicate_type", "string"), ("batch", "string"),
           ("claim_id", "string"), ("line_no", "string"), ("member_id", "string"), ("servicing_provider", "string"),
           ("form_typ", "string"), ("ncci_edition", "string"), ("dos", "string"), ("period_start", "string"),
           ("period_end", "string"),
           ("finding", "string"), ("observed_units", "double"), ("allowed_units", "int"), ("excess_units", "double"),
           ("finding_severity", "string"), ("finding_basis", "string"), ("pa_present", "int"), ("pa_status", "string"),
           ("paid_amt", "double"), ("paid_at_risk", "double"), ("col1_claim_id", "string"), ("col1_line_no", "string"),
           ("pair_scope", "string"), ("evidence_lines", "string"), ("query_validation", "string"),
           ("ncci_routing", "string"),          # NCCI findings: signed | unsigned | form_fallback | form_only (2026-10-04)
           ("billing_provider", "string")]      # v2.6: the billing provider id of a member_servicing_billing_day group


def normalise(sdf, consts: dict):
    for k, v in consts.items():
        if k not in sdf.columns or v is not None:
            sdf = sdf.withColumn(k, F.lit(v))
    for c, _ in _SCHEMA:
        if c not in sdf.columns:
            sdf = sdf.withColumn(c, F.lit(None))
    sdf = sdf.withColumn("pa_status", F.when((F.col("origin") == "ncci") | F.col("pa_present").isNull(),
                                             F.lit("not_evaluated"))
                                     .when(F.col("pa_present") == 1, F.lit("pa_on_file"))
                                     .otherwise(F.lit("no_pa_on_file")))
    # C4-14: a stable finding key - the same finding in the same run always gets the same id
    key = F.concat_ws("|", *[F.coalesce(F.col(c).cast("string"), F.lit(""))
                             for c in ("run_id", "rule_id", "claim_id", "line_no", "member_id", "servicing_provider",
                                       "dos", "period_start")])
    # v2.6: a daily group per servicing AND billing provider is told apart by its billing provider id (appended only
    # when present, so every other finding keeps exactly the id it had)
    key = F.when(F.col("billing_provider").isNull(), key).otherwise(
        F.concat_ws("|", key, F.col("billing_provider").cast("string")))
    sdf = sdf.withColumn("finding_id", F.substring(F.sha2(key, 256), 1, 24))
    sdf = sdf.select(*[F.col(c).cast(t).alias(c) for c, t in _SCHEMA])
    if MAX_ROWS_PER_DETECTOR:
        # C1-11: the cap is per RULE (it used to cut a whole NCCI batch), on a total order with line numbers as numbers
        w = Window.partitionBy("rule_id").orderBy("claim_id", F.expr("try_cast(line_no AS BIGINT)"), "line_no",
                                                  "member_id", "dos", "period_start", "finding_id")
        sdf = sdf.withColumn("_rn", F.row_number().over(w)).where(F.col("_rn") <= MAX_ROWS_PER_DETECTOR).drop("_rn")
    return sdf


def append(sdf):
    sdf.write.format(FMT).mode("append").option("mergeSchema", "true").saveAsTable(FINDINGS)


def hits_by_rule(where: str) -> dict:
    return {r["rule_id"]: r["n"] for r in spark.sql(
        f"SELECT rule_id, COUNT(*) AS n FROM {FINDINGS} WHERE run_id = '{run_id}' AND {where} GROUP BY rule_id").collect()}


# a first run that writes no finding (NCCI not run for want of signed routing, no state query fires) must still
# leave a readable table with the fixed types: everything below reads it (2026-10-04, found by the end-to-end run)
if not spark.catalog.tableExists(FINDINGS):
    spark.createDataFrame([], ", ".join(f"{c} {t}" for c, t in _SCHEMA)).write.format(FMT).saveAsTable(FINDINGS)

# COMMAND ----------

# MAGIC %md ## 3. NCCI — table-driven, per claim form

# COMMAND ----------

runs = []
PTYPE = {"ncci_ptp": "code_pair_prohibited", "ncci_mue": "max_units_per_line"}
# Both batches land in a per-run STAGING table first: the Column One check below needs every NCCI finding of the run
# before any of them is final, and staging avoids MERGE / persist (both are unavailable on some compute).
STAGE = f"{KB}.policy_findings_stage"
spark.sql(f"DROP TABLE IF EXISTS {STAGE}")
for b in ncci_batches.to_dict("records"):
    t0 = time.time()
    qst = QSTATUS.get(f"BATCH:{b['batch']}", run_guard.NOT_VALIDATED)
    rec = {"run_id": run_id, "build_id": BUILD_ID, "rule_id": f"BATCH:{b['batch']}", "extraction_key": None,
           "predicate_type": PTYPE[b["batch"]], "batch": b["batch"], "origin": "ncci", "hits": None,
           "seconds": None, "error": None, "rules_in_batch": int(b["rules"]), "sql_sha256": b.get("sql_sha256"),
           "query_validation": qst, "skipped": run_guard.skip_reason(qst) or NCCI_GATE}
    try:
        if int(b["rules"]) > 0 and not rec["skipped"]:
            (normalise(spark.sql(b["sql"]), {"run_id": run_id, "build_id": BUILD_ID, "origin": "ncci",
                                             "predicate_type": PTYPE[b["batch"]], "batch": b["batch"],
                                             "extraction_key": None, "query_validation": qst,
                                             "ncci_routing": NCCI_ROUTING_KIND})
             .write.format(FMT).mode("append").option("mergeSchema", "true").saveAsTable(STAGE))
    except Exception as e:
        rec["error"] = f"{type(e).__name__}: {str(e)[:500]}"
    rec["seconds"] = round(time.time() - t0, 1)
    runs.append(rec)

# C2-07 (TGM App. B: "Apply the NCCI PTP edit to the claim only if the Column One code is eligible for payment"):
# a pair finding whose Column One lines are ALL denied in this run (by an MUE, or as the Column Two line of another
# pair) is relabelled verify_col1_not_payable - never dropped.
COL1_RELABELLED = 0
if spark.catalog.tableExists(STAGE):
    stg = spark.table(STAGE)
    # the same rendering as the SQL's evidence_lines: a missing claim id / line number is '' (never dropped)
    denied = stg.select(F.concat(F.coalesce(F.col("claim_id").cast("string"), F.lit("")), F.lit(":"),
                                 F.coalesce(F.col("line_no").cast("string"), F.lit(""))).alias("ln")).distinct()
    ev = stg.where(F.col("batch") == "ncci_ptp").select("finding_id", F.explode(F.split("evidence_lines", ",")).alias("ln"))
    tot = ev.groupBy("finding_id").agg(F.countDistinct("ln").alias("n"))
    den = ev.join(denied, "ln").groupBy("finding_id").agg(F.countDistinct("ln").alias("d"))
    relabel = tot.join(den, "finding_id").where("n = d").select("finding_id").withColumn("_relabel", F.lit(True))
    COL1_RELABELLED = relabel.count()
    final = (stg.join(relabel, "finding_id", "left")
                .withColumn("finding_severity", F.when(F.col("_relabel"), F.lit(detector_gen.VERIFY_COL1))
                                                 .otherwise(F.col("finding_severity")))
                .drop("_relabel").select(*[c for c, _ in _SCHEMA]))
    append(final)
    spark.sql(f"DROP TABLE IF EXISTS {STAGE}")
for rec in [r for r in runs if str(r["rule_id"]).startswith("BATCH:")]:
    per_rule = {} if (rec["error"] or rec["skipped"]) else hits_by_rule(f"batch = '{rec['batch']}'")
    rec["hits"] = int(sum(per_rule.values())) if not (rec["error"] or rec["skipped"]) else None
    for rid, n in per_rule.items():
        runs.append({"run_id": run_id, "build_id": BUILD_ID, "rule_id": rid, "extraction_key": None,
                     "predicate_type": rec["predicate_type"], "batch": rec["batch"], "origin": "ncci", "hits": int(n),
                     "seconds": None, "error": None, "rules_in_batch": None, "sql_sha256": None,
                     "query_validation": rec["query_validation"], "skipped": None})
    print(f"  {rec['batch']}: {rec['rules_in_batch']:,} rules -> {rec['hits']} findings in {rec['seconds']}s"
          + (f"  ERROR {rec['error'][:200]}" if rec["error"] else "") + (f"  {rec['skipped']}" if rec["skipped"] else ""))
print(f"  Column One not payable: {COL1_RELABELLED} pair finding(s) relabelled {detector_gen.VERIFY_COL1}")

# COMMAND ----------

# MAGIC %md ## 3b. AHCCCS rule tables — three table-driven statements (state rules, v5.2)
# MAGIC Same Day Disallow pairs, daily limits and B2-matrix provider types, every built version at once. They are STATE
# MAGIC rules, so - unlike NCCI - they are not held back by the NCCI routing gate, their findings carry no `ncci_routing`,
# MAGIC a PA on file is evaluated (`verify_pa`), and they never take part in the Column One check above (they are appended
# MAGIC straight to the findings). A statement a validator marked PROBLEM for its current SQL (v06) does not run.

# COMMAND ----------

for b in table_batches.to_dict("records"):
    t0 = time.time()
    ptype_ = detector_gen.TABLE_BATCH_PREDICATE[b["batch"]]
    qst = QSTATUS.get(f"BATCH:{b['batch']}", run_guard.NOT_VALIDATED)
    rec = {"run_id": run_id, "build_id": BUILD_ID, "rule_id": f"BATCH:{b['batch']}", "extraction_key": None,
           "predicate_type": ptype_, "batch": b["batch"], "origin": detector_gen.TABLE_ORIGIN, "hits": None,
           "seconds": None, "error": None, "rules_in_batch": int(b["rules"]), "sql_sha256": b.get("sql_sha256"),
           "query_validation": qst, "skipped": run_guard.skip_reason(qst)}
    try:
        if int(b["rules"]) > 0 and not rec["skipped"]:
            append(normalise(spark.sql(b["sql"]), {"run_id": run_id, "build_id": BUILD_ID,
                                                   "origin": detector_gen.TABLE_ORIGIN, "predicate_type": ptype_,
                                                   "batch": b["batch"], "extraction_key": None,
                                                   "query_validation": qst}))
    except Exception as e:
        rec["error"] = f"{type(e).__name__}: {str(e)[:500]}"
    rec["seconds"] = round(time.time() - t0, 1)
    per_rule = {} if (rec["error"] or rec["skipped"]) else hits_by_rule(f"batch = '{b['batch']}'")
    rec["hits"] = None if (rec["error"] or rec["skipped"]) else int(sum(per_rule.values()))
    runs.append(rec)
    for rid, n in per_rule.items():
        runs.append({"run_id": run_id, "build_id": BUILD_ID, "rule_id": rid, "extraction_key": None,
                     "predicate_type": ptype_, "batch": b["batch"], "origin": detector_gen.TABLE_ORIGIN, "hits": int(n),
                     "seconds": None, "error": None, "rules_in_batch": None, "sql_sha256": None,
                     "query_validation": qst, "skipped": None})
    print(f"  {b['batch']}: {int(b['rules']):,} rules -> {rec['hits']} findings in {rec['seconds']}s"
          + (f"  ERROR {rec['error'][:200]}" if rec["error"] else "") + (f"  {rec['skipped']}" if rec["skipped"] else ""))

# COMMAND ----------

# MAGIC %md ## 3c. Same Day pairs disallowed both ways — dollars counted more than once (v5.2b)
# MAGIC When a Same Day Disallow version marks the same two codes D / A* in BOTH directions, each line is the finding of its
# MAGIC own rule (`both_ways` in `policy_ahcccs_pair_edits`), so both lines of a member's day are flagged although AHCCCS
# MAGIC would deny one of the two (critic F4) - and a line disallowed with two codes is flagged twice. Their `paid_at_risk`
# MAGIC is therefore not additive. Per member and date of service, over the DISTINCT lines those findings flag (critic
# MAGIC re-check N5): when lines of two or more codes are flagged, AHCCCS keeps the lines of at least one code, so at most
# MAGIC the lines' paid minus the cheapest code's lines is at risk; the rest of the findings' `paid_at_risk` is counted more
# MAGIC than once. Printed
# MAGIC here and kept in the run log (`RUN:snapshot`: `ahcccs_both_ways_findings`, `ahcccs_both_ways_paid_at_risk`,
# MAGIC `ahcccs_both_ways_at_risk_at_most`, `ahcccs_both_ways_groups`, `ahcccs_dollars_counted_twice` = counted more than
# MAGIC once; null = not evaluated).

# COMMAND ----------

_sd_rec = next((r for r in runs if r.get("rule_id") == f"BATCH:{detector_gen.BATCH_AHCCCS_PAIR}"), None)
_sd_hits = None if _sd_rec is None else _sd_rec.get("hits")   # None: the statement did not run (switch, skip, error)
BOTH_WAYS = {k: (None if _sd_hits is None else 0)
             for k in ("ahcccs_both_ways_findings", "ahcccs_both_ways_paid_at_risk", "ahcccs_both_ways_at_risk_at_most",
                       "ahcccs_both_ways_groups", "ahcccs_dollars_counted_twice")}
_pair_edits = f"{KB}.{detector_gen.TABLE_BATCH_EDIT_TABLE[detector_gen.BATCH_AHCCCS_PAIR]}"
if _sd_hits and "both_ways" not in spark.table(_pair_edits).columns:
    BOTH_WAYS = {k: None for k in BOTH_WAYS}
    print(f"  Same Day pairs both ways: not evaluated - {_pair_edits} has no both_ways column (a build made before "
          f"v5.2b: re-run 07_build_kb)")
elif _sd_hits:
    # the both-ways findings; each flagged LINE once (MAX: one claim line flagged by several rules); then per member +
    # date: lines of 2+ codes flagged -> AHCCCS keeps the lines of at least one code, so at most (the lines' paid - the
    # cheapest code's lines) is at risk
    _BW_SQL = f"""
WITH bw AS (
  SELECT f.member_id, f.dos, f.claim_id, f.line_no, f.paid_at_risk, e.code_b AS code
  FROM {FINDINGS} f
  JOIN {_pair_edits} e ON e.rule_id = f.rule_id
  WHERE f.run_id = '{run_id}' AND f.batch = '{detector_gen.BATCH_AHCCCS_PAIR}' AND e.build_id = '{BUILD_ID}'
    AND LOWER(CAST(e.both_ways AS STRING)) IN ('true', '1')
),
ln AS (
  SELECT member_id, dos, claim_id, line_no, MAX(code) AS code, MAX(paid_at_risk) AS paid
  FROM bw GROUP BY member_id, dos, claim_id, line_no
),
cd AS (
  SELECT member_id, dos, code, SUM(paid) AS code_paid FROM ln GROUP BY member_id, dos, code
),
g AS (
  SELECT COUNT(*) AS codes, SUM(code_paid) AS lines_paid, MIN(code_paid) AS cheapest_code
  FROM cd GROUP BY member_id, dos
)
SELECT (SELECT COUNT(*) FROM bw) AS findings,
       (SELECT ROUND(COALESCE(SUM(paid_at_risk), 0), 2) FROM bw) AS paid_at_risk,
       ROUND(COALESCE(SUM(CASE WHEN codes >= 2 THEN lines_paid - cheapest_code ELSE lines_paid END), 0), 2) AS at_most,
       COALESCE(SUM(CASE WHEN codes >= 2 THEN 1 ELSE 0 END), 0) AS groups_
FROM g"""
    try:
        _bw = spark.sql(_BW_SQL).collect()[0]
        BOTH_WAYS = {"ahcccs_both_ways_findings": int(_bw["findings"]),
                     "ahcccs_both_ways_paid_at_risk": float(_bw["paid_at_risk"]),
                     "ahcccs_both_ways_at_risk_at_most": float(_bw["at_most"]),
                     "ahcccs_both_ways_groups": int(_bw["groups_"]),
                     "ahcccs_dollars_counted_twice": round(float(_bw["paid_at_risk"]) - float(_bw["at_most"]), 2)}
    except Exception as e:                   # a report on findings already written: it never stops the run
        BOTH_WAYS = {**{k: None for k in BOTH_WAYS}, "ahcccs_both_ways_error": f"{type(e).__name__}: {str(e)[:300]}"}
        print(f"  Same Day pairs both ways: not evaluated - {BOTH_WAYS['ahcccs_both_ways_error']}")
if BOTH_WAYS["ahcccs_both_ways_findings"] is not None and _sd_hits:
    print(f"  Same Day pairs disallowed both ways: {BOTH_WAYS['ahcccs_both_ways_findings']:,} finding(s) carry "
          f"${BOTH_WAYS['ahcccs_both_ways_paid_at_risk']:,.2f} paid_at_risk; on "
          f"{BOTH_WAYS['ahcccs_both_ways_groups']:,} member-day(s) lines of two or more such codes are flagged and AHCCCS "
          f"keeps one code's lines, so at most ${BOTH_WAYS['ahcccs_both_ways_at_risk_at_most']:,.2f} is at risk - "
          f"${BOTH_WAYS['ahcccs_dollars_counted_twice']:,.2f} is counted more than once")

# COMMAND ----------

# MAGIC %md ## 4. State — one statement per rule

# COMMAND ----------

if RUN_STATE:
    for i, d in enumerate(state.to_dict("records"), 1):
        t0 = time.time()
        qst = QSTATUS.get(str(d["rule_id"]), run_guard.NOT_VALIDATED)
        rec = {"run_id": run_id, "build_id": BUILD_ID, "rule_id": d["rule_id"], "extraction_key": d.get("extraction_key"),
               "predicate_type": d["predicate_type"], "batch": None, "origin": d["origin"], "hits": None,
               "seconds": None, "error": None, "rules_in_batch": None, "sql_sha256": d.get("sql_sha256"),
               "query_validation": qst, "skipped": run_guard.skip_reason(qst)}
        if rec["skipped"]:
            runs.append(rec)
            continue
        try:
            append(normalise(spark.sql(d["sql"]), {"run_id": run_id, "build_id": BUILD_ID, "rule_id": d["rule_id"],
                                                   "extraction_key": d.get("extraction_key"), "origin": d["origin"],
                                                   "predicate_type": d["predicate_type"], "batch": None,
                                                   "query_validation": qst}))
            rec["hits"] = int(hits_by_rule(f"rule_id = '{d['rule_id']}'").get(d["rule_id"], 0))
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {str(e)[:500]}"
        rec["seconds"] = round(time.time() - t0, 1)
        runs.append(rec)
        if i % 25 == 0:
            print(f"  state {i}/{len(state)}")

# COMMAND ----------

# MAGIC %md ## 5. Utilization signals — rolling windows (NOT violations)
# MAGIC A period limit is judged on the policy's own window (AHCCCS contract year Oct 1 – Sep 30). These rows answer a
# MAGIC different question for the anomaly work: did a member exceed the limit inside ANY rolling window of the same length
# MAGIC (e.g. two back-to-back maximums around the October reset)? `also_fixed_period_violation` says whether the policy
# MAGIC check itself fired for that member in this run.

# COMMAND ----------

SIGNALS = f"{KB}.policy_utilization_signals"
sig_rows = 0
if RUN_SIGNALS:
    # the signal queries are the ones 07 compiled and stored (signal_sql, hash-checked above) - never re-compiled here
    period_rules = [d for d in state.to_dict("records") if isinstance(d.get("signal_sql"), str) and d["signal_sql"]]
    rules_p = spark.table(f"{KB}.policy_rules").where(F.col("rule_id").isin([d["rule_id"] for d in period_rules])) \
        .select("rule_id", "predicate").toPandas() if period_rules else pd.DataFrame(columns=["rule_id", "predicate"])
    _period = {r["rule_id"]: (json.loads(r["predicate"]) if isinstance(r["predicate"], str) else r["predicate"] or {})
               .get("period") for r in rules_p.to_dict("records")}
    fired = spark.table(FINDINGS).where((F.col("run_id") == run_id) & (F.col("predicate_type") == "max_units_per_period")) \
        .select("rule_id", "member_id").distinct().withColumn("also_fixed_period_violation", F.lit(True))
    for r in period_rules:
        sql = r["signal_sql"]
        r["predicate"] = {"period": _period.get(r["rule_id"])}
        t0 = time.time()
        qst = QSTATUS.get(f"SIGNAL:{r['rule_id']}", run_guard.NOT_VALIDATED)
        srec = {"run_id": run_id, "build_id": BUILD_ID, "rule_id": f"SIGNAL:{r['rule_id']}",
                "extraction_key": r.get("extraction_key"), "predicate_type": "rolling_signal", "batch": None,
                "origin": r.get("origin"), "hits": None, "seconds": None, "error": None, "rules_in_batch": None,
                "sql_sha256": r.get("signal_sql_sha256"), "query_validation": qst, "skipped": run_guard.skip_reason(qst)}
        runs.append(srec)
        if srec["skipped"]:
            continue
        try:
            s = (spark.sql(sql).withColumn("rule_id", F.lit(r["rule_id"]))
                 .join(fired, ["rule_id", "member_id"], "left")
                 .withColumn("also_fixed_period_violation", F.coalesce("also_fixed_period_violation", F.lit(False)))
                 .withColumn("signal", F.when(F.col("also_fixed_period_violation"), F.lit("over_limit_in_period_and_rolling"))
                                        .otherwise(F.lit("over_limit_in_rolling_window_only")))
                 .withColumn("run_id", F.lit(run_id)).withColumn("build_id", F.lit(BUILD_ID))
                 .withColumn("period", F.lit(r["predicate"].get("period")))
                 .withColumn("query_validation", F.lit(qst))
                 .select("run_id", "build_id", "rule_id", "period", "member_id",
                         F.col("window_start").cast("string").alias("window_start"),
                         F.col("window_end").cast("string").alias("window_end"),
                         F.col("rolling_units").cast("double").alias("rolling_units"),
                         F.col("rolling_paid").cast("double").alias("rolling_paid"),
                         F.col("allowed_units").cast("int").alias("allowed_units"),
                         F.col("rolling_days").cast("int").alias("rolling_days"),
                         "also_fixed_period_violation", "signal", "query_validation"))
            n = s.count()
            if n:
                s.write.format(FMT).mode("append").option("mergeSchema", "true").saveAsTable(SIGNALS)
                sig_rows += n
            srec["hits"] = int(n)
        except Exception as e:
            srec["error"] = f"{type(e).__name__}: {str(e)[:500]}"
            print(f"  signal for {r['rule_id']} failed: {type(e).__name__}: {str(e)[:300]}")
        srec["seconds"] = round(time.time() - t0, 1)
    print(f"utilization signals: {sig_rows} member row(s) over a limit inside a rolling window "
          f"({len(period_rules)} period rule(s))")

# COMMAND ----------

runs.append({"run_id": run_id, "build_id": BUILD_ID, "rule_id": "RUN:snapshot", "extraction_key": None,
             "predicate_type": None, "batch": None, "origin": None, "hits": None, "seconds": snap.get("seconds"),
             "error": json.dumps({**snap, "col1_relabelled": COL1_RELABELLED, "utilization_signals": sig_rows,
                                  "ncci_routing": NCCI_ROUTING_KIND, "ncci_unsigned_types": UNSIGNED_TYPES,
                                  "ncci_observed_types": len(OBSERVED_TYPES),
                                  "ncci_gate": NCCI_GATE, "ncci_routing_table_sha256":
                                      ncci_routing.table_sha256() if ncci_routing.uses_table() else None,
                                  # v5.2b (critic F4): Same Day pairs disallowed both ways - section 3c
                                  **BOTH_WAYS}),
             "rules_in_batch": None, "sql_sha256": snap.get("snapshot_sql_sha256"), "query_validation": None,
             "skipped": None})
runs_df = pd.DataFrame(runs, columns=["run_id", "build_id", "rule_id", "extraction_key", "predicate_type", "batch",
                                      "origin", "hits", "seconds", "error", "rules_in_batch", "sql_sha256",
                                      "query_validation", "skipped"])
# fixed types: an all-null column in one run must not create the appended table with the wrong type
for c in ("hits", "rules_in_batch"):
    runs_df[c] = pd.to_numeric(runs_df[c]).astype("Int64")
runs_df["seconds"] = pd.to_numeric(runs_df["seconds"]).astype(float)
for c in ("extraction_key", "batch", "error", "sql_sha256", "predicate_type", "origin", "query_validation", "skipped"):
    runs_df[c] = runs_df[c].astype(object)
runs_df["detectors_eligible"] = DET_ELIGIBLE
# partial: a part of the build was not run on purpose - a switch, a row cap, or NCCI held back for unsigned routing
runs_df["partial_run"] = ((not RUN_NCCI_BATCH) or (not RUN_STATE) or (not RUN_AHCCCS_TABLES)
                          or bool(MAX_ROWS_PER_DETECTOR) or bool(RUN_NCCI_BATCH and NCCI_GATE and len(ncci_batches)))
runs_df["snapshot_table"] = SNAPSHOT
runs_df["snapshot_version"] = snap.get("snapshot_version")
kb_io.write_table(spark, runs_df, f"{KB}.policy_detector_runs", mode="append",
                  schema={"snapshot_version": "long", "error": "string", "sql_sha256": "string",
                          "query_validation": "string", "skipped": "string"})
errors = runs_df.loc[~runs_df["rule_id"].astype(str).str.startswith("RUN:"), "error"].notna().sum()
total = spark.table(FINDINGS).where(F.col("run_id") == run_id).count()
n_skipped = int(runs_df["skipped"].notna().sum())
print(f"\nrun {run_id}: {total:,} findings; {int(errors)} detector error(s)"
      + (f"; {n_skipped} quer(ies) not run (validation, or unsigned NCCI routing) - see the `skipped` column of "
         f"policy_detector_runs" if n_skipped else ""))
if errors:
    display(runs_df[runs_df["error"].notna() & ~runs_df["rule_id"].astype(str).str.startswith("RUN:")]
            [["rule_id", "predicate_type", "error"]])

# COMMAND ----------

# MAGIC %md ## What fired (this run) — each claim line's dollars counted once

# COMMAND ----------

# C1-08 / C2-20: one line flagged by several rules (or a pair line with several Column One partners) used to add its
# paid amount once per finding. Line findings are now summed over DISTINCT lines; aggregate findings (member-day /
# period) are summed separately and never added to line dollars.
display(spark.sql(f"""
WITH f AS (SELECT * FROM {FINDINGS} WHERE run_id = '{run_id}'),
line AS (SELECT origin, predicate_type, finding_severity, pa_status, claim_id, line_no,
                MAX(paid_amt) AS paid_amt, MAX(paid_at_risk) AS paid_at_risk, COUNT(*) AS findings, COUNT(DISTINCT rule_id) AS rules
         FROM f WHERE claim_id IS NOT NULL GROUP BY 1, 2, 3, 4, 5, 6)
SELECT origin, predicate_type, finding_severity, pa_status, SUM(findings) AS findings, COUNT(*) AS distinct_lines,
       ROUND(SUM(paid_amt), 2) AS paid_amt_distinct_lines, ROUND(SUM(paid_at_risk), 2) AS paid_at_risk
FROM line GROUP BY 1, 2, 3, 4
UNION ALL
SELECT origin, predicate_type, finding_severity, pa_status, COUNT(*) AS findings, NULL AS distinct_lines,
       ROUND(SUM(paid_amt), 2) AS paid_amt_group, ROUND(SUM(paid_at_risk), 2) AS paid_at_risk
FROM f WHERE claim_id IS NULL GROUP BY 1, 2, 3, 4
ORDER BY paid_at_risk DESC
"""))
print("Distinct flagged claim lines across ALL rules:",
      spark.sql(f"SELECT COUNT(*) AS n, ROUND(SUM(p), 2) AS paid FROM (SELECT claim_id, line_no, MAX(paid_amt) AS p "
                f"FROM {FINDINGS} WHERE run_id = '{run_id}' AND claim_id IS NOT NULL GROUP BY 1, 2)").collect()[0].asDict())
