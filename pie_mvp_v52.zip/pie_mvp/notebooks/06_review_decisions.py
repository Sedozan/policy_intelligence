# Databricks notebook source
# MAGIC %md
# MAGIC # Step 2 of 3 — Apply the human review decisions
# MAGIC
# MAGIC The extraction notebook (`extract_chapters`) lands every extracted rule in
# MAGIC `main.sedo.state_rules` with `review_status = draft` and exports a workbook.
# MAGIC **Nothing reaches the KB until a named human decides.** This notebook applies those
# MAGIC decisions.
# MAGIC
# MAGIC | column the reviewer fills | meaning |
# MAGIC |---|---|
# MAGIC | `decision` | `Approve` — rule is correct as written · `Reject` — not a rule / wrong · `Fix` — right idea, wrong details |
# MAGIC | `corrected_rule` | (Fix) corrected plain-English statement |
# MAGIC | `corrected_predicate` | (Fix) corrected predicate **as JSON** — the predicate is what compiles |
# MAGIC | `corrected_effective_date`, `corrected_end_date` | (Fix) the rule's window, `YYYY-MM-DD` (end inclusive); `clear` removes a date |
# MAGIC | `corrected_population` | (Fix) who the rule applies to, e.g. `members under 21` (state it in `predicate.age` for it to compile) |
# MAGIC | `reviewer`, `review_note` | who decided and why (an AI-prefilled note keeps its `AI pre-review:` prefix) |
# MAGIC | `reopen` | `yes` = change a rule that is ALREADY approved or rejected. Without it a decided rule is never changed (an old workbook re-imported cannot flip it); the decision it replaces is kept in `prior_review` and the log |
# MAGIC
# MAGIC Read-only columns show what is being signed: `predicate`, `effective_date`, `end_date`, `population`, `age`,
# MAGIC `scope`, `modifier_indicator`, `exception`, `discretionary`, the citation and quote, and `previous_decision`
# MAGIC (an earlier decision on the same rule — e.g. `Fix by SS 2026-10-05: {...}` — when the source PDF changed).
# MAGIC Rows with `origin = manual` are the hand-authored seeds (no doc_hash): approving one signs it.
# MAGIC
# MAGIC Safety rules enforced here: an approval can never be silently downgraded later; a
# MAGIC rejected rule is never resurrected by re-extraction; a **Fix without a valid
# MAGIC corrected_predicate (or corrected dates / population) is parked as `needs_review`**, not approved; an
# MAGIC **Approve of an invalid predicate**, of an edited `predicate` cell, or one that would **revert an earlier Fix**
# MAGIC is parked too (the reason is in `review_note`, summarised below). An approval records the sha256 of the
# MAGIC predicate it signed; the build refuses the rule if the predicate changes afterwards.
# MAGIC Every decision is appended to `policy_review_log` (with `extraction_key`, so it joins
# MAGIC to the exact compiled detector). The ingested workbook is then archived under `review/ingested/` and
# MAGIC whatever is still pending is exported to a fresh workbook.
# MAGIC
# MAGIC Next: run `07_build_kb` (step 3) — it loads **only** `approved` / `legacy_hand_authored` rows.

# COMMAND ----------

import os, sys, glob
# ---- find the package: this notebook's folder or its parent must contain config.py.
# No hard-coded workspace path; set PKB_PACKAGE_DIR if you keep the notebooks elsewhere.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; run this notebook from inside the pie_mvp folder "
                      f"or set PKB_PACKAGE_DIR")
import importlib, config, kb_io, state_rules
importlib.reload(config); importlib.reload(kb_io); importlib.reload(state_rules)

STATE_RULES_TBL = config.STATE_RULES_TABLE                      # main.sedo.state_rules
LOG_TBL         = f"{config.OUTPUT_CATALOG}.{config.OUTPUT_SCHEMA}.policy_review_log"
# the workbook 05_persist_extraction exported; the reviewer edits it in place
DEFAULT_WORKBOOK = f"{config.WORKSPACE_DATA_DIR}/review/policy_rules_review.xlsx"
WORKBOOK        = None          # None = DEFAULT_WORKBOOK; or the path of a timestamped export 05 printed
WORKBOOK        = WORKBOOK or DEFAULT_WORKBOOK

assert os.path.exists(WORKBOOK), f"no workbook at {WORKBOOK} - run 05_persist_extraction, then have a reviewer fill it"
# C4-11: 05 never overwrites a workbook in progress; it writes policy_rules_review_<timestamp>.xlsx instead
others = sorted(p for p in glob.glob(os.path.join(os.path.dirname(DEFAULT_WORKBOOK), "policy_rules_review_*.xlsx"))
                if os.path.abspath(p) != os.path.abspath(WORKBOOK))
print(f"ingesting: {WORKBOOK}")
if others:
    print(f"also waiting in the review folder (NOT ingested by this run; set WORKBOOK to ingest one): {others}")

# COMMAND ----------

# MAGIC %md ## Before — what is waiting for a decision

# COMMAND ----------

before = spark.table(STATE_RULES_TBL).toPandas()
print(before["review_status"].value_counts().to_string())

# COMMAND ----------

# MAGIC %md ## Check the review log's column types (one-time repair if an older run created them as DOUBLE)

# COMMAND ----------

TEXT_COLS = ["rule_id", "extraction_key", "decision", "corrected_rule", "corrected_predicate", "reviewer",
             "review_note", "ingested_at", "applied_outcome",
             # C4-12 / C3-06 / C4-04 columns (all text; state_rules.REVIEW_LOG_SCHEMA pins them)
             "doc_hash_reviewed", "origin", "corrected_effective_date", "corrected_end_date", "corrected_population",
             "approved_predicate_sha256", "decision_source", "previous_decision"]
if spark.catalog.tableExists(LOG_TBL):
    bad = {f.name: f.dataType.simpleString() for f in spark.table(LOG_TBL).schema.fields
           if f.name in TEXT_COLS and f.dataType.simpleString() != "string"}
    if bad:
        casts = ", ".join(f"CAST({c} AS STRING) AS {c}" if c in bad else c for c in spark.table(LOG_TBL).columns)
        raise RuntimeError(
            f"{LOG_TBL} has non-text columns {bad} (created by an earlier run whose workbook cells were empty). "
            f"The next append would fail on a type conflict. Nothing was changed. Repair once (values are kept):\n"
            f"  CREATE OR REPLACE TABLE {LOG_TBL} AS SELECT {casts} FROM {LOG_TBL}")
print("review log types OK")

# COMMAND ----------

# MAGIC %md ## Apply decisions

# COMMAND ----------

result = state_rules.ingest_review_decisions(spark, STATE_RULES_TBL, WORKBOOK, LOG_TBL)

# COMMAND ----------

# MAGIC %md ## What happened — parked decisions by reason, AI pre-review notes

# COMMAND ----------

import collections
if result:
    oc = collections.Counter(result["outcomes"])
    applied = {k: oc.pop(k) for k in ("approved", "fixed", "rejected") if k in oc}
    print(f"applied: {applied or 'nothing'}")
    if oc:
        print("NOT applied (parked / ignored) by reason:")
        for k, v in oc.most_common():
            print(f"  {v:5d}  {k}")
    ai = result.get("ai_prereview_notes", 0)
    print(f"\n{ai} of {len(result['outcomes'])} decision row(s) carried an '{state_rules.AI_PREREVIEW_PREFIX}' note "
          f"(an AI-prefilled reading; the decision is the named reviewer's)")
else:
    print("no decisions in the workbook - nothing applied")

# COMMAND ----------

# MAGIC %md ## Archive the ingested workbook; export what is still pending

# COMMAND ----------

if result:
    # C4-11: the decisions are in policy_review_log now; moving the file aside lets the next export use the
    # standard path without ever overwriting a decided workbook
    dest = state_rules.archive_workbook(WORKBOOK)
    print(f"ingested workbook archived -> {dest}" if dest else f"ingested workbook left at {WORKBOOK}")
    after_tbl = spark.table(STATE_RULES_TBL).toPandas()
    pending = after_tbl["review_status"].isin(state_rules.PENDING_STATUS).sum()
    if pending:
        nxt = state_rules.export_review_workbook(spark, STATE_RULES_TBL, DEFAULT_WORKBOOK)
        print(f"{pending} rule(s) still pending (parked, re-sign, unsigned seeds, drafts) -> {nxt}")
    else:
        print("nothing left to review")

# COMMAND ----------

# MAGIC %md ## After — what will load into the KB

# COMMAND ----------

after = spark.table(STATE_RULES_TBL).toPandas()
print(after["review_status"].value_counts().to_string())
loadable = after[after["review_status"].isin(state_rules.LOADABLE_STATUS)]
print(f"\n{len(loadable)} rules will load into the KB on the next 07_build_kb run "
      f"(by chapter: {loadable['chapter'].value_counts().to_dict()}); unsigned seeds among them: "
      f"{int((loadable['review_status'] == 'legacy_hand_authored').sum())} "
      f"(COMPILE_LEGACY_SEEDS={getattr(config, 'COMPILE_LEGACY_SEEDS', True)})")
ai_signed = loadable["review_note"].fillna("").astype(str).str.startswith(state_rules.AI_PREREVIEW_PREFIX)
print(f"{int(ai_signed.sum())} approved rule(s) carry an '{state_rules.AI_PREREVIEW_PREFIX}' note")
parked = after[after["review_status"] == "needs_review"].copy()
if len(parked):
    parked["why"] = parked["review_note"].map(state_rules.parked_reason)
    print(f"\n{len(parked)} waiting as needs_review, by reason (details in review_note):")
    print(parked["why"].value_counts().to_string())
    print(parked[["rule_id", "chapter", "why", "review_note"]].head(20).to_string(index=False))

# COMMAND ----------

# MAGIC %md ## (Optional) Change a rule that is already decided
# MAGIC `EXPORT_DECIDED = True` exports every approved / rejected rule to `review/policy_rules_decided_<time>.xlsx`
# MAGIC (`previous_decision` shows the decision in force). To change one: fill `decision` (and the corrections), put
# MAGIC `yes` in `reopen` and your name in `reviewer`, save the file as `review/policy_rules_review.xlsx` and run this
# MAGIC notebook again. A reopen that would change nothing is reported as `unchanged`; one from another document
# MAGIC version, or without a name, is refused and the rule keeps its decision.

# COMMAND ----------

EXPORT_DECIDED = False
if EXPORT_DECIDED:
    _p = state_rules._free_path(os.path.join(os.path.dirname(DEFAULT_WORKBOOK), "policy_rules_decided.xlsx"))
    _out = state_rules.review_frame(spark.table(STATE_RULES_TBL).toPandas(), statuses=state_rules.REOPENABLE_STATUS)
    print(f"exported {len(_out)} decided rule(s) -> {state_rules._xlsx_write(_out, _p)}")
