# Databricks notebook source
# MAGIC %md
# MAGIC # 07 · Build the Policy Knowledge Base  (CPU cluster with Unity Catalog)
# MAGIC
# MAGIC Rebuilds `main.policy_kb` deterministically. Every build gets a `build_id`; current tables are
# MAGIC overwritten, and `*_history` tables keep every build so a finding can always be traced to the rule
# MAGIC text AND the exact SQL that produced it.
# MAGIC
# MAGIC | step | what | writes |
# MAGIC |---|---|---|
# MAGIC | 0 | preflight: every configured column / table resolves (incl. `date_of_birth`) | — |
# MAGIC | 1 | scope = procedure codes in the paid-claims table; claims date range | — |
# MAGIC | 2 | NCCI PTP + MUE from `main.sedo.medicaid_ncci_edit_*`; warn if claims run past the newest quarter; which edit file each line takes (provider type × form, CMS Table 2) | — |
# MAGIC | 3 | state rules: `approved` (+ unsigned seeds only if `config.COMPILE_LEGACY_SEEDS`) — **approvals from another or an unknown PDF version are excluded** | — |
# MAGIC | 3b | AHCCCS rule tables (Same Day Disallow, daily limits, B2 matrix; v5.2): the rows in the catalog must be exactly what 00b loaded (else the build **stops**); a table's rules only when every reading of it is **signed**; a table not loaded is skipped; a warning when the claims outrun the newest version's max age | — |
# MAGIC | 4 | gate → normalise (every NCCI rule keeps its own edit file; never merged across files; table rules on their own) → compile | — |
# MAGIC | 5 | coverage per (code, form): the paid dollars dated **inside the window** of a compiled detector's rule (v5.2b; computed in Spark) | — |
# MAGIC | 6 | registers: ambiguity + federal/state overlaps + where the AHCCCS tables contradict or qualify a state rule | — |
# MAGIC | 7 | write: **history first**, then current tables, then the `policy_build_log` row with `status = complete` LAST | all tables |
# MAGIC
# MAGIC Why that order (C4-01): 08 refuses to run unless every current table carries the same `build_id` AND the build log
# MAGIC has a `complete` row for it. A build that fails half-way therefore can never be run, and nothing it wrote can be
# MAGIC mistaken for a finished build.
# MAGIC
# MAGIC Where the queries live: `policy_detectors.sql` (one statement per compiled state rule, with `sql_sha256`),
# MAGIC `policy_batch_detectors.sql` (two statements: all NCCI pairs, all NCCI MUEs, which join the edit rows in
# MAGIC `policy_ncci_ptp_edits` / `policy_ncci_mue_limits`; and, v5.2, three for the AHCCCS rule tables: all Same Day
# MAGIC Disallow pairs, all daily limits, all B2-matrix provider types, joining `policy_ahcccs_pair_edits` /
# MAGIC `policy_ahcccs_daily_limits` / `policy_ahcccs_provider_types` - always five rows, `rules` = 0 when a table built
# MAGIC nothing), and `policy_detectors.signal_sql` (period limits only:
# MAGIC the rolling-window utilization signal, with `signal_sql_sha256`). The same SQL, hash and build are appended to
# MAGIC `policy_detectors_history` / `policy_batch_detectors_history` (and the edit rows to `policy_ncci_*_history` /
# MAGIC `policy_ahcccs_*_history`).
# MAGIC Every signed state rule compiles, whether or not its code is paid in the claims table
# MAGIC (`config.STATE_RULES_CLAIMS_SCOPE = False`): one query per signed rule, so the count does not move with the data.
# MAGIC
# MAGIC Next: `08_run_detectors`.

# COMMAND ----------

import os, sys, json, time, hashlib
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
import config
import ingest_ncci_tables, state_rules, validate_gate, rule_normalize, detector_gen, gap, schema, kb_io, registers
import ncci_routing, policy_docs, quality, ahcccs_tables
for m in (config, schema, kb_io, ncci_routing, policy_docs, quality, ingest_ncci_tables, state_rules, validate_gate,
          rule_normalize, detector_gen, gap, registers, ahcccs_tables):
    importlib.reload(m)

SOURCE_CATALOG, SOURCE_SCHEMA = config.CATALOG, config.SCHEMA
KB              = config.KB
CLAIMS          = config.CLAIMS_TABLE
STATE_RULES_TBL = config.STATE_RULES_TABLE
CC              = config.CLAIM_COLS
PAID_COL        = CC.get("paid_amt")
SCOPE           = "claims"            # "claims" (codes paid in the claims table) | "all"
# all_data_C_A is paid-only (SB, 2026-09-20; config.CLAIMS_PAID_ONLY). Zero-dollar and reversal lines are handled
# by the detection snapshot in 08 (detector_gen.snapshot_sql), not here.
PAID_FILTER     = ""

BUILD_ID = "B" + pd.Timestamp.now().strftime("%Y%m%dT%H%M%S")
BUILT_AT = pd.Timestamp.now().isoformat(timespec="seconds")
print("build", BUILD_ID)


def package_sha256(root: str) -> str:
    """Fingerprint of the code that produced this build (every .py under the package, in path order)."""
    h = hashlib.sha256()
    for dp, dns, fns in sorted(os.walk(root)):
        dns[:] = sorted(d for d in dns if d not in ("__pycache__", ".pytest_cache", "data", "tests"))
        for fn in sorted(fns):
            if fn.endswith(".py"):
                p = os.path.join(dp, fn)
                h.update(os.path.relpath(p, root).encode())
                with open(p, "rb") as f:
                    h.update(f.read())
    return h.hexdigest()


def frame_sha256(df: pd.DataFrame) -> str:
    """Content hash of an edit table (rows sorted, so the same content always gives the same hash)."""
    if df is None or not len(df):
        return hashlib.sha256(b"").hexdigest()
    d = df.astype(str).sort_values(list(df.columns)).to_csv(index=False)
    return hashlib.sha256(d.encode()).hexdigest()


def table_version(fqn: str):
    """Delta version of a source table (None on non-Delta / no permission)."""
    try:
        return int(spark.sql(f"DESCRIBE HISTORY {fqn} LIMIT 1").collect()[0]["version"])
    except Exception:
        return None

# COMMAND ----------

# MAGIC %md ## 0. Preflight

# COMMAND ----------

problems = []
claims_cols = {c.upper() for c in spark.table(CLAIMS).columns}
need = [v for k, v in CC.items() if k != "mods" and isinstance(v, str)] + list(CC["mods"])
for c in dict.fromkeys(need):
    if c.upper() not in claims_cols:
        problems.append(f"claims column missing: {c}")

metas = ingest_ncci_tables.discover_tables(spark, SOURCE_CATALOG, SOURCE_SCHEMA)
if not metas and not getattr(config, "NCCI_ALLOW_EMPTY", False):
    problems.append(f"no medicaid_ncci_edit_* tables in {SOURCE_CATALOG}.{SOURCE_SCHEMA} (run 00_acquire_ncci)")
fc = ingest_ncci_tables._find_col
for m in metas:
    cols = spark.table(m["fqn"]).columns
    if m["edit_type"] == "ptp":
        want = {"col1": fc(cols, "column1", "col1", "comprehensive code"), "col2": fc(cols, "column2", "col2", "component code"),
                "modifier": fc(cols, "modifier indicator", "modifier"), "effdt": fc(cols, "effective date", "effdt"),
                "deldt": fc(cols, "deletion date", "deldt")}
    else:
        want = {"code": fc(cols, "hcpcs/cpt code", "hcpcs cpt code", "procedure code", "code"),
                "value": fc(cols, "mue value", "mue values")}
    missing = [k for k, v in want.items() if v is None]
    if missing:
        problems.append(f"{m['table']}: cannot resolve {missing}; columns are {cols}")

try:
    st_cols = set(spark.table(STATE_RULES_TBL).columns)
    miss = [c for c in state_rules.STATE_RULE_COLUMNS if c not in st_cols]
    if miss:
        print(f"  note: {STATE_RULES_TBL} lacks newer columns {miss}; they are added on the next write")
except Exception as e:
    problems.append(f"{STATE_RULES_TBL} not readable: {e}  (run 02_migrate_state_rules first)")

if problems:
    raise RuntimeError("PREFLIGHT FAILED:\n  - " + "\n  - ".join(problems))

# Which NCCI edit file each line takes: CMS TGM s6.0 Table 2 by servicing provider type CODE x claim form
# (ncci_routing; the same expression the 08 snapshot stamps on every line). 01 shows the full cross-tab.
FORM = CC["form"]
forms = spark.sql(f"SELECT UPPER(TRIM(CAST({FORM} AS STRING))) AS f, COUNT(*) AS n FROM {CLAIMS} GROUP BY 1").toPandas()
FORM_COUNTS = {str(r.f): int(r.n) for r in forms.itertuples()}
unknown = {f: n for f, n in FORM_COUNTS.items() if f not in config.FORM_TYPE_MAP}
ROUTING = ncci_routing.summary()
_fn = f"UPPER(TRIM(CAST({FORM} AS STRING)))"
EDITION_COUNTS = {str(r.e): int(r.n) for r in spark.sql(
    f"SELECT {ncci_routing.PIE_EDITION} AS e, COUNT(*) AS n "
    f"FROM {ncci_routing.routed_sql(CLAIMS, CC, cols={c.upper() for c in spark.table(CLAIMS).columns})} x GROUP BY 1").collect()}
print("claim forms:", {f: f"{n:,} ({config.FORM_TYPE_MAP.get(f, '?')})" for f, n in FORM_COUNTS.items()})
print("NCCI edit file per line:", {k: f"{v:,}" for k, v in EDITION_COUNTS.items()}, "| routing:", ROUTING)
if unknown:
    print(f"  WARNING: form value(s) not in config.FORM_TYPE_MAP: {unknown} - no NCCI edit runs on them")
if ROUTING["mode"] in ("billing_provider_type", "provider_type") and ROUTING["types_signed"] < ROUTING["types_mapped"]:
    print(f"  NOTE: the provider-type routing table is PROPOSED ({ROUTING['types_signed']} of {ROUTING['types_mapped']} "
          f"rows signed) - findings depend on it; v03 lists it as NOT YET until it is signed")
print("preflight OK")

# COMMAND ----------

# MAGIC %md ## 1. Scope and claims window

# COMMAND ----------

t0 = time.time()
PROC, DOS = CC["code"], CC["dos"]
rng = spark.sql(f"SELECT CAST(MIN({DOS}) AS DATE) AS lo, CAST(MAX({DOS}) AS DATE) AS hi FROM {CLAIMS}").collect()[0]
CLAIMS_WINDOW = (str(rng["lo"]) if rng["lo"] else None, str(rng["hi"]) if rng["hi"] else None)
if SCOPE == "claims":
    scope_codes = {r.code for r in spark.sql(
        f"SELECT DISTINCT UPPER(TRIM({PROC})) AS code FROM {CLAIMS} WHERE {PROC} IS NOT NULL {PAID_FILTER}").collect()}
    print(f"scope: {len(scope_codes):,} distinct procedure codes; claims dates {CLAIMS_WINDOW}")
else:
    scope_codes = None
    print(f"scope: all codes; claims dates {CLAIMS_WINDOW}")

# COMMAND ----------

# MAGIC %md ## 2. Federal rules — NCCI PTP + MUE

# COMMAND ----------

NCCI_REPORT = {}
ncci_rules = ingest_ncci_tables.ingest_tables(spark, SOURCE_CATALOG, SOURCE_SCHEMA, code_filter=scope_codes,
                                              report=NCCI_REPORT)
ncci_quarters = sorted({(m["service"], m["edit_type"], m["label"]) for m in metas})
# 2026-10-04 (external review): the NCCI rules in this KB are the edits that can touch THIS claims population (both
# codes of a pair / the MUE code paid in the claims), not the size of the CMS edit set - a change in the claims mix
# changes the count without any change in policy. Dashboards should say "NCCI edits executable against these claims".
print("NCCI rules here = edits executable against these claims" if scope_codes else "NCCI rules here = all edits",
      f"({len(ncci_rules):,} rules); the CMS files themselves (see source_vs_claims_scope in the build log):")
for _line in ingest_ncci_tables.scope_lines(NCCI_REPORT.get("source_vs_claims_scope") or [], bool(scope_codes)):
    print("   ", _line)
print("   ", ingest_ncci_tables.route_note())
print(f"NCCI source: {getattr(config, 'NCCI_SOURCE', 'unknown')} - per the CMS public edit set; Arizona-specific "
      f"deactivations (RISSNET state files) are NOT applied.")
# C2-14: claims dated after the newest loaded quarter are judged against that quarter's edits with no evidence they
# still hold. Not an error (CMS may simply not have published yet) - a warning kept in the build log.
NEWEST_Q = ingest_ncci_tables.newest_quarter_end(metas) if hasattr(ingest_ncci_tables, "newest_quarter_end") else {}
NCCI_STALE = {f"{s}/{e}": end for (s, e), end in NEWEST_Q.items() if CLAIMS_WINDOW[1] and CLAIMS_WINDOW[1] > end}
if NCCI_STALE:
    print(f"  WARNING: claims run to {CLAIMS_WINDOW[1]}, past the newest loaded NCCI quarter for {NCCI_STALE} - "
          f"load the newer quarters (00_acquire_ncci) or read those findings as provisional")

# COMMAND ----------

# MAGIC %md ## 3. State rules — reviewed, current document version only

# COMMAND ----------

# each document's current version: the doc_hash of its latest inventory row - quality.current_doc_hash, the recipe v01
# and v03 use too, so the corpus_version below is the one their metrics are stamped with
current_doc_hash = quality.current_doc_hash(kb_io.table_or_none(spark, f"{KB}.policy_document_inventory"))
# the exact document set the state rules were read from (policy_docs.corpus_version; "corpus-empty" when there is
# none): a recall or precision figure measured on this build has an unambiguous denominator; the build log keeps it
# with the documents still to load
CORPUS_VERSION = policy_docs.corpus_version(current_doc_hash)
print(f"policy corpus: {len(current_doc_hash)} document(s), corpus_version {CORPUS_VERSION}; rule sources listed as "
      f"still to load (config.CORPUS_PENDING; an AHCCCS table 00b loaded is counted in step 3b): "
      f"{sorted(getattr(config, 'CORPUS_PENDING', {}))}")
state_report = {}
# 2026-10-02: every signed state rule compiles (a code not paid in this claims extract simply finds nothing). Scoping
# them to paid codes made the query count, and the KB itself, move with the data. NCCI stays scoped (size).
STATE_SCOPE = scope_codes if getattr(config, "STATE_RULES_CLAIMS_SCOPE", False) else None
# one engine in the KB (2026-10-04, SB): an extracted rule compiles only when the last run that produced it used a prompt
# version in config.KB_PROMPT_VERSIONS; hand-authored rules only with config.COMPILE_HAND_AUTHORED
RUN_PROMPT = {}
_log = kb_io.table_or_none(spark, f"{KB}.policy_extraction_log")
if _log is not None and len(_log) and {"run_id", "prompt_version"} <= set(_log.columns):
    RUN_PROMPT = (_log.dropna(subset=["run_id"]).drop_duplicates("run_id", keep="last")
                  .set_index("run_id")["prompt_version"].astype(object).where(lambda v: v.notna(), None).to_dict())
print(f"one engine in the KB: prompt version(s) {list(config.KB_PROMPT_VERSIONS) or 'any'}; hand-authored rules "
      f"{'compile once signed' if config.COMPILE_HAND_AUTHORED else 'never compile (a v05 checklist)'}; "
      f"{len(RUN_PROMPT)} extraction run(s) known")
st_rules = state_rules.load_state_rules(spark, STATE_RULES_TBL, STATE_SCOPE, current_doc_hash=current_doc_hash,
                                        report=state_report, run_prompt=RUN_PROMPT)
state_df = spark.table(STATE_RULES_TBL).toPandas()
print(f"state: {len(st_rules)} loaded; {len(state_report['stale'])} approvals excluded (stale or unverifiable "
      f"document version); {state_report['legacy']} unsigned seed rules "
      f"(COMPILE_LEGACY_SEEDS={getattr(config, 'COMPILE_LEGACY_SEEDS', False)})")

# COMMAND ----------

# MAGIC %md ## 3b. AHCCCS rule tables — Same Day Disallow, daily limits, B2 matrix (v5.2)
# MAGIC
# MAGIC Loaded by `00b_load_ahcccs_tables` (a deterministic reader, never the model): every file is a version that judges
# MAGIC claims from its own date to the day before the next version's date. A table that is not loaded is skipped and said
# MAGIC so. A table's rules are built only when EVERY reading of it in `reference/ahcccs_table_readings.csv` is signed (while
# MAGIC `config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS` is on); the readings still to sign are printed and kept in the build
# MAGIC log. The rules (origin `ahcccs_table`, ids `TBL-…`) are scoped to the codes paid in the claims, like NCCI, and go
# MAGIC through the same gate, normalisation and compiler as every other rule - into three batch statements (step 4).

# COMMAND ----------

TABLE_ORIGIN = detector_gen.TABLE_ORIGIN
# 2026-10-04 (v5.2): a table missing from the catalog (or empty) yields no rules, so a workspace with no table loaded
# builds exactly what it built before the tables existed: 0 table rules, the three batch rows written with rules = 0
_frames_all, AHCCCS_NOTES = ahcccs_tables.frames_for_build(spark)
# 2026-10-04 (v5.2b, critic F7): 07 used to trust the tables in the catalog - a row deleted or edited there by hand silently
# changed the rules, and a dropped table built 0 rules while the load log said loaded. The rows read back must be exactly
# what 00b loaded (per version the logged row count and, when logged, the rows hash): checked BEFORE anything is built
AHCCCS_LOG = kb_io.table_or_none(spark, config.AHCCCS_TABLES_LOG)
_table_problems = ahcccs_tables.check_loaded(_frames_all, AHCCCS_LOG)
if _table_problems:
    raise RuntimeError("AHCCCS TABLE CHECK FAILED - the rule tables in the catalog are not what 00b_load_ahcccs_tables "
                       "loaded; nothing was built (reload the version with 00b, or restore the table):\n  - "
                       + "\n  - ".join(str(p) for p in _table_problems))
AHCCCS_FRAMES = {k: f for k, f in (_frames_all or {}).items() if f is not None and len(f)}
# 2026-10-04 (v5.2b, critic F8): the readings file this build is gated on (its bytes' sha256, read before the gate), kept in
# the build log: a signature binds to the readings file as it was
try:
    AHCCCS_READINGS_SHA256 = ahcccs_tables.readings_sha256()
except FileNotFoundError:                # no readings file: table_compiles says so below; nothing compiles
    AHCCCS_READINGS_SHA256 = None
AHCCCS_STATUS = {}
for key in ahcccs_tables.TABLE_KEYS:
    f = AHCCCS_FRAMES.get(key)
    if f is None:
        AHCCCS_STATUS[key] = {"loaded": False, "versions": [], "compiles": False, "unsigned_readings": [],
                              "reason": f"not loaded ({config.AHCCCS_TABLES.get(key, {}).get('table')} missing or "
                                        f"empty; run 00b_load_ahcccs_tables)"}
        print(f"AHCCCS {key}: {AHCCCS_STATUS[key]['reason']} - skipped")
        continue
    ok, why = ahcccs_tables.table_compiles(key)
    try:
        unsigned = [] if ok else list(ahcccs_tables.unsigned_readings(key))
    except FileNotFoundError:            # no readings file at all: table_compiles said so (why); nothing is signed
        unsigned = ["<no readings file>"]
    AHCCCS_STATUS[key] = {"loaded": True, "compiles": bool(ok), "reason": why,
                          "versions": sorted({str(v)[:10] for v in f["version_date"].dropna()}),
                          "unsigned_readings": unsigned}
    print(f"AHCCCS {key}: {len(f):,} row(s), version(s) {AHCCCS_STATUS[key]['versions']} - "
          + ("rules built" if ok else f"NOT BUILT, reading(s) {AHCCCS_STATUS[key]['unsigned_readings']} not signed")
          + f" ({why})")
for _n in AHCCCS_NOTES or []:
    print("   ", _n)
# 2026-10-04 (v5.2b, critic F12): the newest version stays in force until the next one is loaded - past
# config.AHCCCS_TABLE_MAX_AGE_DAYS[key] days after its date the claims are judged by a table AHCCCS has probably replaced.
# Not an error (a warning kept in the build log, as NCCI_STALE): load the newer version with 00b
AHCCCS_STALE = quality.tables_stale_vs_claims({k: s["versions"] for k, s in AHCCCS_STATUS.items() if s["loaded"]},
                                              CLAIMS_WINDOW[1], getattr(config, "AHCCCS_TABLE_MAX_AGE_DAYS", {}))
for _k in AHCCCS_STALE:
    print(f"  WARNING: claims run to {CLAIMS_WINDOW[1]}, past the max age of the newest loaded AHCCCS {_k} version: "
          f"{quality.stale_tables_text({_k: AHCCCS_STALE[_k]})} - load AHCCCS's newer version (00b_load_ahcccs_tables) "
          f"or read those findings as provisional")
_compiling = {k: f for k, f in AHCCCS_FRAMES.items() if AHCCCS_STATUS[k]["compiles"]}
AHCCCS_REPORT = {}
table_rules = ahcccs_tables.rules_from_frames(_compiling, scope_codes, AHCCCS_REPORT) if _compiling else []
print(f"AHCCCS table rules: {len(table_rules):,} from {sorted(_compiling) or 'no table'}"
      + (" (scoped to the codes paid in the claims, like NCCI)" if scope_codes else ""))

# COMMAND ----------

# MAGIC %md ## 4. Gate → normalise → compile

# COMMAND ----------

rules = ncci_rules + st_rules + table_rules
accepted, rejected = validate_gate.gate(rules)
print("gate:", json.dumps(validate_gate.summarize(accepted, rejected)))
for r in rejected[:10]:
    print("   rejected:", r["reject_reason"], "|", (r.get("statement") or "")[:80])

# 2026-10-04 (v5.2): the AHCCCS table rules are normalised ON THEIR OWN. Fed together, rule_normalize's state-duplicate
# collapse keeps an extracted / hand-authored rule over any other origin with the same predicate, codes and window - a
# table rule would be dropped against it. The table is its own authority (and never NCCI): where it agrees with or
# contradicts a state rule, policy_ahcccs_conflicts (step 6) says so; both rules stay.
tbl_accepted = [r for r in accepted if r.get("origin") == TABLE_ORIGIN]
accepted, norm_report = rule_normalize.normalize_rules([r for r in accepted if r.get("origin") != TABLE_ORIGIN])
print("normalise:", json.dumps({k: v for k, v in norm_report.items() if k != "ncci_no_edition_examples"}))
if norm_report.get("ncci_rules_no_edition"):
    print(f"  {norm_report['ncci_rules_no_edition']:,} NCCI rule(s) carry no known edit file and are not run, "
          f"e.g. {norm_report.get('ncci_no_edition_examples', [])[:3]}")
tbl_accepted, tbl_norm_report = rule_normalize.normalize_rules(tbl_accepted)
if tbl_accepted:
    print("normalise (AHCCCS tables):", json.dumps({k: v for k, v in tbl_norm_report.items()
                                                    if k != "ncci_no_edition_examples"}, default=str))
accepted = accepted + tbl_accepted

# NCCI and (v5.2) the AHCCCS table rules run as batch statements; every other compiled rule has its own statement
detectors = detector_gen.build_detectors(accepted, batch_ncci=True, batch_tables=True)
summary = detector_gen.summarize(detectors)
print("detectors:", json.dumps({k: v for k, v in summary.items() if k != "lead_reasons"}))

# who approved each state rule, joined back by extraction_key (extracted) or rule_id (seeds)
def _lookup(df, key):
    if key not in df:
        return {}
    keep = [c for c in ("reviewer", "reviewed_at", "review_status", "approved_predicate_sha256") if c in df.columns]
    d = df[df[key].notna() & (df[key].astype(str) != "")].drop_duplicates(key, keep="last")
    return d.set_index(key)[keep].to_dict("index")
rev, rev_id = _lookup(state_df, "extraction_key"), _lookup(state_df, "rule_id")
for r in accepted:
    src = rev.get(r.get("extraction_key")) or rev_id.get(r.get("rule_id")) or {}
    # 2026-10-04 (v5.2): an AHCCCS table rule is 'state_table' (a state rule read from a table cell; its sign-off is the
    # table's readings, reference/ahcccs_table_readings.csv) as an NCCI rule is 'federal_table'
    _tab = r.get("origin") == TABLE_ORIGIN
    r.update(build_id=BUILD_ID, built_at=BUILT_AT, reviewer=src.get("reviewer"), reviewed_at=src.get("reviewed_at"),
             review_status=("federal_table" if r.get("origin") == "ncci" else "state_table" if _tab
                            else src.get("review_status")),
             approved_predicate_sha256=(src.get("approved_predicate_sha256") if r.get("origin") != "ncci" and not _tab
                                        else None),
             jurisdiction="federal" if r.get("origin") == "ncci" else "state")
for d in detectors:
    d["build_id"] = BUILD_ID

# only rules that COMPILED as batched detectors become edit rows: a rule that is a lead in policy_detectors must
# never run through the batch statement either
_batched = {d["rule_id"] for d in detectors if d["compiled"] and d.get("batch")}
ptp_edits, mue_limits = detector_gen.ncci_edit_tables([r for r in accepted if r["rule_id"] in _batched])
ptp_edits["build_id"], mue_limits["build_id"] = BUILD_ID, BUILD_ID
PTP_SQL = detector_gen.batch_ptp_sql(build_id=BUILD_ID)
MUE_SQL = detector_gen.batch_mue_sql(build_id=BUILD_ID)
batch_rows = [
    {"batch": detector_gen.BATCH_PTP, "rules": len(ptp_edits), "sql": PTP_SQL,
     "sql_sha256": detector_gen.sql_sha256(PTP_SQL), "edits_sha256": frame_sha256(ptp_edits.drop(columns=["build_id"])),
     "build_id": BUILD_ID},
    {"batch": detector_gen.BATCH_MUE, "rules": len(mue_limits), "sql": MUE_SQL,
     "sql_sha256": detector_gen.sql_sha256(MUE_SQL), "edits_sha256": frame_sha256(mue_limits.drop(columns=["build_id"])),
     "build_id": BUILD_ID},
]
# 2026-10-04 (v5.2): the AHCCCS table rules that compiled as batched detectors become the rows of three edit tables, read
# by three statements compiled for THIS build. The three batch rows are written whatever was built (rules = 0 when a
# table built nothing), so 08 always sees the same five statements.
AHCCCS_EDITS = dict(zip(detector_gen.TABLE_BATCHES,
                        detector_gen.ahcccs_edit_tables([r for r in accepted if r["rule_id"] in _batched])))
_tbl_batched = {d["rule_id"] for d in detectors if d["compiled"] and d.get("batch") in detector_gen.TABLE_BATCHES}
_tbl_edited = {str(x) for df_ in AHCCCS_EDITS.values() for x in df_["rule_id"]}
if _tbl_batched != _tbl_edited:          # a batched rule with no edit row would silently never run - stop the build
    raise RuntimeError(f"AHCCCS table rules batched but without an edit row: {sorted(_tbl_batched - _tbl_edited)[:10]}; "
                       f"edit rows of rules not batched: {sorted(_tbl_edited - _tbl_batched)[:10]}")
N_TABLE_RULES = {}
for kind, df_ in AHCCCS_EDITS.items():
    df_["build_id"] = BUILD_ID
    sql_ = detector_gen.TABLE_BATCH_SQL[kind](build_id=BUILD_ID)
    N_TABLE_RULES[kind] = int(df_["rule_id"].nunique())
    batch_rows.append({"batch": kind, "rules": int(df_["rule_id"].nunique()), "sql": sql_,
                       "sql_sha256": detector_gen.sql_sha256(sql_),
                       "edits_sha256": frame_sha256(df_.drop(columns=["build_id"])), "build_id": BUILD_ID})
N_STATE_SQL = sum(1 for d in detectors if d["compiled"] and d.get("sql"))
N_SIGNAL_SQL = sum(1 for d in detectors if d["compiled"] and d.get("signal_sql"))
print(f"queries in this build: {N_STATE_SQL} per-rule state statement(s) + 2 NCCI batch statements "
      f"({len(ptp_edits):,} PTP edit rows, {len(mue_limits):,} MUE rows; by edit file "
      f"{ptp_edits['ncci_edition'].value_counts().to_dict() if len(ptp_edits) else {}} / "
      f"{mue_limits['ncci_edition'].value_counts().to_dict() if len(mue_limits) else {}})"
      f" + {len(AHCCCS_EDITS)} AHCCCS table batch statements (rules {N_TABLE_RULES})"
      f" = {N_STATE_SQL + 2 + len(AHCCCS_EDITS)} finding queries; plus {N_SIGNAL_SQL} rolling-window utilization-signal "
      f"statement(s) (signals, not findings). Every one is stored with its sql_sha256 in policy_detectors / "
      f"policy_batch_detectors.")

# COMMAND ----------

# MAGIC %md ## 5. Coverage (compiled detectors, only the dollars dated inside each rule's window; NCCI per claim form) and gap

# COMMAND ----------

# 2026-10-04 (v5.2b, critic F10): a rule covers only the paid dollars of lines dated INSIDE its own window - an AHCCCS
# table version dated 2026-10-01 used to "cover" every older dollar of its codes, and the gap table went empty. The
# window test runs in Spark against the live rules' windows (gap.rule_windows, broadcast); summary, gap and the build
# log's pct_paid_covered_* use those dated dollars
coverage = gap.coverage_table(spark, accepted, CLAIMS, PAID_COL, detectors=detectors, claims_window=CLAIMS_WINDOW)
cov_summary = gap.coverage_summary(coverage)
gap_df = gap.gap_rows(coverage)
PCT_PAID_COVERED_ANY, PCT_PAID_COVERED_STATE = gap.coverage_pcts(coverage)
for df_ in (coverage, cov_summary, gap_df):
    df_["build_id"] = BUILD_ID
print("paid dollars by the rules whose date window they fall in (a code can count in several classes):")
print(cov_summary.to_string(index=False))
print(f"{PCT_PAID_COVERED_ANY}% of paid $ inside the window of a compiled rule of its code, {PCT_PAID_COVERED_STATE}% "
      f"inside a state rule's")
print(f"\ngap: {len(gap_df):,} paid code/form row(s) with dollars no state rule judges (no compiled state rule, or "
      f"dated outside every one's window); top 15 by those dollars:")
print(gap_df.head(15).to_string(index=False))

# COMMAND ----------

# MAGIC %md ## 6. Registers — ambiguity, federal/state overlaps

# COMMAND ----------

amb = registers.ambiguity_register(state_df, accepted)
ovl = registers.rule_overlaps(accepted, detectors)
for df_ in (amb, ovl):
    df_["build_id"] = BUILD_ID
print("ambiguity register:", amb["category"].value_counts().to_dict() if len(amb) else "empty")
print("rule overlaps:", ovl["relationship"].value_counts().to_dict() if len(ovl) else "none")
# 2026-10-04 (v5.2): where an AHCCCS table contradicts or qualifies an extracted / hand-authored rule (a pair the table
# allows, a different pair scope, provider list or daily threshold) - a candidate list for a person, never a decision
# which source wins. Every LOADED version counts, signed or not: a disagreement is worth seeing before anyone signs.
AHCCCS_CONFLICT_COLUMNS = list(ahcccs_tables.CONFLICT_COLUMNS)
ahcccs_conflicts = (ahcccs_tables.table_conflicts(AHCCCS_FRAMES, [r for r in accepted
                                                                  if r.get("origin") not in ("ncci", TABLE_ORIGIN)])
                    if AHCCCS_FRAMES else None)
if ahcccs_conflicts is None or not len(ahcccs_conflicts.columns):
    ahcccs_conflicts = pd.DataFrame(columns=AHCCCS_CONFLICT_COLUMNS)
ahcccs_conflicts = ahcccs_conflicts.copy()
ahcccs_conflicts["build_id"] = BUILD_ID
print("AHCCCS table conflicts with state rules:",
      ahcccs_conflicts["relationship"].value_counts().to_dict() if len(ahcccs_conflicts) else "none")
if len(ahcccs_conflicts):
    print(ahcccs_conflicts[["table_key", "version_date", "codes", "rule_id", "relationship"]].head(10).to_string(index=False))

# COMMAND ----------

# MAGIC %md ## 7. Write — history first, current tables next, the `complete` marker last

# COMMAND ----------

from kb_io import write_table

def write(rows, table, mode="overwrite"):
    return write_table(spark, rows, f"{KB}.{table}", mode)

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {KB}")
build_meta = {
    "build_id": BUILD_ID, "built_at": BUILT_AT, "status": "complete", "scope": SCOPE, "claims_table": CLAIMS,
    "claims_from": CLAIMS_WINDOW[0], "claims_to": CLAIMS_WINDOW[1],
    "scope_codes": len(scope_codes) if scope_codes else 0,          # 0 = SCOPE "all"
    "rules": len(accepted), "ncci_rules": sum(r["origin"] == "ncci" for r in accepted),
    "state_rules": sum(r["origin"] not in ("ncci", TABLE_ORIGIN) for r in accepted),
    # 2026-10-04 (v5.2): the AHCCCS rule tables - per table: loaded, versions, built or held back (the readings still to
    # sign), and the reader's counts (cells / rows, rules, scoped out, recorded not compiled); rules per batch statement
    "ahcccs_table_rules": sum(r["origin"] == TABLE_ORIGIN for r in accepted),
    "ahcccs_batch_statements": len(AHCCCS_EDITS),
    "ahcccs_rules_by_batch": json.dumps(N_TABLE_RULES),
    "ahcccs_edit_rows": json.dumps({k: len(df_) for k, df_ in AHCCCS_EDITS.items()}),
    "ahcccs_edits_sha256": json.dumps({b["batch"]: b["edits_sha256"] for b in batch_rows
                                       if b["batch"] in detector_gen.TABLE_BATCHES}),
    "ahcccs_tables": json.dumps({k: {**(AHCCCS_REPORT.get(k) or {}), **AHCCCS_STATUS[k]}
                                 for k in ahcccs_tables.TABLE_KEYS}, default=str),
    "ahcccs_held_back_unsigned": json.dumps({k: s["unsigned_readings"] for k, s in AHCCCS_STATUS.items()
                                             if s["loaded"] and not s["compiles"]}),
    # v5.2b: tables whose claims run past the newest version + config.AHCCCS_TABLE_MAX_AGE_DAYS (critic F12; {} = none),
    # and the sha256 of the readings file the tables were gated on (critic F8; null = no readings file)
    "ahcccs_stale_vs_claims": json.dumps(AHCCCS_STALE),
    "ahcccs_readings_sha256": AHCCCS_READINGS_SHA256,
    "ahcccs_conflict_rows": len(ahcccs_conflicts),
    "ahcccs_normalize": json.dumps({k: v for k, v in tbl_norm_report.items() if k != "ncci_no_edition_examples"},
                                   default=str),
    "detectors_compiled": summary["compiled"], "detectors_batched": summary["batched"], "leads": summary["leads"],
    "state_sql_statements": N_STATE_SQL, "ncci_batch_statements": 2, "signal_sql_statements": N_SIGNAL_SQL,
    "ptp_edit_rows": len(ptp_edits), "mue_limit_rows": len(mue_limits),
    "ptp_edits_sha256": batch_rows[0]["edits_sha256"], "mue_limits_sha256": batch_rows[1]["edits_sha256"],
    "stale_approvals_excluded": len(state_report["stale"]), "legacy_seed_rules": state_report["legacy"],
    "kb_prompt_versions": json.dumps(list(config.KB_PROMPT_VERSIONS)),
    "compile_hand_authored": bool(config.COMPILE_HAND_AUTHORED),
    "engine_excluded": json.dumps(pd.Series([r["reason"] for r in state_report.get("engine_excluded", [])],
                                            dtype=object).value_counts().to_dict()),
    # v5.2b (critic F10): the share of paid $ dated INSIDE the window of a compiled rule of the code (any / state)
    "pct_paid_covered_any": PCT_PAID_COVERED_ANY, "pct_paid_covered_state": PCT_PAID_COVERED_STATE,
    "ambiguity_register_rows": len(amb), "overlap_rows": len(ovl),
    "contradiction_candidates": int((ovl["relationship"] == "state_not_covered_vs_federal_edit").sum()) if len(ovl) else 0,
    "ncci_quarters": json.dumps(ncci_quarters), "ncci_newest_quarter_end": json.dumps({f"{s}/{e}": d for (s, e), d in NEWEST_Q.items()}),
    "ncci_stale_vs_claims": json.dumps(NCCI_STALE), "claim_forms": json.dumps(FORM_COUNTS),
    "ncci_routing": json.dumps(ROUTING), "ncci_lines_by_edition": json.dumps(EDITION_COUNTS),
    "ncci_rules_scope": "executable_against_claims" if scope_codes else "all_edits",
    "ncci_source_vs_claims_scope": json.dumps(NCCI_REPORT.get("source_vs_claims_scope") or []),
    "corpus_version": CORPUS_VERSION, "corpus_documents": len(current_doc_hash),
    # v5.2: an AHCCCS rule table 00b loaded is no longer "to load" (a CORPUS_PENDING key IS the table key; v03's corpus
    # bar reads the load log the same way)
    "corpus_pending": json.dumps(sorted(k for k in getattr(config, "CORPUS_PENDING", {})
                                        if not AHCCCS_STATUS.get(k, {}).get("loaded"))),
    "package_sha256": package_sha256(os.path.dirname(os.path.abspath(config.__file__))),
    "claims_table_version": table_version(CLAIMS), "state_rules_version": table_version(STATE_RULES_TBL),
    "compile_legacy_seeds": bool(getattr(config, "COMPILE_LEGACY_SEEDS", False)),
    "gate": json.dumps(validate_gate.summarize(accepted, rejected)),
    "normalize": json.dumps({k: v for k, v in norm_report.items() if k != "ncci_no_edition_examples"}, default=str),
}

print("writing outputs:")
# 1) history (append-only, keyed by build_id): old findings join here, never to the overwritten current tables.
#    Since 2026-10-02 the history keeps the SQL and its sha256 (C1-09 / C4-02).
write(accepted,   "policy_rules_history", mode="append")
write(detectors,  "policy_detectors_history", mode="append")
write(batch_rows, "policy_batch_detectors_history", mode="append")
if getattr(config, "KEEP_NCCI_EDIT_HISTORY", True):
    write(ptp_edits,  "policy_ncci_ptp_edits_history", mode="append")
    write(mue_limits, "policy_ncci_mue_limits_history", mode="append")
    # 2026-10-04 (v5.2): the AHCCCS table edit rows of every build, so an old finding replays with its exact rows
    for kind, df_ in AHCCCS_EDITS.items():
        name = detector_gen.TABLE_BATCH_EDIT_TABLE[kind]
        write(df_, f"{name}_history", mode="append")
# 2) current tables
write(accepted,   "policy_rules")
write(detectors,  "policy_detectors")
write(ptp_edits,  "policy_ncci_ptp_edits")
write(mue_limits, "policy_ncci_mue_limits")
for kind, df_ in AHCCCS_EDITS.items():     # always written (empty when nothing was built): 08 checks their build_id
    name = detector_gen.TABLE_BATCH_EDIT_TABLE[kind]
    write(df_, name)
write(batch_rows, "policy_batch_detectors")
write(coverage,   "policy_coverage")
write(cov_summary, "policy_coverage_summary")
write(gap_df,     "policy_gap")
write(amb,        "policy_ambiguity_register")
write(ovl,        "policy_rule_overlaps")
write(ahcccs_conflicts, "policy_ahcccs_conflicts")
# 3) the marker 08 requires: written LAST, so its presence means every table above holds this build
write([build_meta], "policy_build_log", mode="append")
print(f"\nbuild {BUILD_ID} finished in {time.time()-t0:,.0f}s")
print(json.dumps({k: v for k, v in build_meta.items() if k not in ("gate", "normalize", "ncci_quarters", "ahcccs_tables",
                                                                   "ahcccs_normalize")}, indent=1))
