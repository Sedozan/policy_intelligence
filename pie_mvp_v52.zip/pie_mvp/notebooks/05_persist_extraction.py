# Databricks notebook source
# MAGIC %md
# MAGIC # Step 1c — Persist a GPU extraction run into Delta (CPU, Unity-Catalog-enabled cluster)
# MAGIC
# MAGIC Reads `RUN_ROOT/<run_id>/` written by `04_extract_chapters_gpu` and loads it:
# MAGIC
# MAGIC | file | table | mode |
# MAGIC |---|---|---|
# MAGIC | `drafts.jsonl` merged into the live table | `main.sedo.state_rules` | overwrite, **guarded** |
# MAGIC | `inventory.jsonl` / `sections.jsonl` / `log.jsonl` / `dropped.jsonl` / `changes.jsonl` | `policy_kb.*` | append, **once per run_id** |
# MAGIC | `outcomes.jsonl` (one row per section: skipped / no rules / proposals / failed) | `policy_kb.policy_extraction_outcomes` | append, **once per run_id** |
# MAGIC | `drafts.jsonl` as the run produced it (the engine's own output, before any review) | `policy_kb.policy_extraction_drafts` | append, **once per run_id** |
# MAGIC | `cache.json` | `policy_kb.policy_extraction_cache` | merged by cache_key, then overwrite |
# MAGIC
# MAGIC `policy_extraction_drafts` (2026-10-04, critic M51-1): `state_rules` keeps the approved / rejected rows of OLDER runs
# MAGIC (a decision is never lost), so it cannot say what the latest run produced; v01 samples the engine's own output
# MAGIC from this table — the drafts of the latest successful run of each chapter's current document version.
# MAGIC
# MAGIC Guards: the merge reads the **live** `state_rules` table (not the snapshot); a read failure stops the run
# MAGIC instead of becoming an empty frame; the overwrite is refused if it would drop a single reviewed row.
# MAGIC Then exports the review workbook. Re-running the same run folder is safe (C4-11): drafts merge by key,
# MAGIC the telemetry rows of this run_id are replaced (never doubled), and a review workbook that already
# MAGIC holds a decision / reviewer / note is **never overwritten** — the new export goes to
# MAGIC `policy_rules_review_<timestamp>.xlsx` next to it (printed below).
# MAGIC
# MAGIC C3-09: drafts of a chapter + document version this run re-extracted that the run no longer produces are
# MAGIC marked `superseded` (kept for audit, never exported) - but only for sections the run actually answered
# MAGIC (outcome `proposals` / `no_rules`); a section the model failed on proves nothing. A new draft whose quote +
# MAGIC codes match a REJECTED rule comes back as `needs_review` with that rejection shown to the reviewer.

# COMMAND ----------

# MAGIC %pip install -q openpyxl

# COMMAND ----------

import os, sys, json, importlib
import pandas as pd
# ---- find the package: this notebook's folder or its parent must contain config.py.
# No hard-coded workspace path; set PKB_PACKAGE_DIR if you keep the notebooks elsewhere.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here)):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here} or its parent; run this notebook from inside the pie_mvp folder "
                      f"or set PKB_PACKAGE_DIR")
import config, extract_io, kb_io, state_rules
for m in (config, extract_io, kb_io, state_rules):
    importlib.reload(m)

RUN_ID = None                                     # None = latest folder under config.RUN_ROOT
ALLOW_UNFINISHED = False                          # True: persist a run whose manifest says finished=False
REVIEW_XLSX = f"{config.WORKSPACE_DATA_DIR}/review/policy_rules_review.xlsx"

KB = f"{config.OUTPUT_CATALOG}.{config.OUTPUT_SCHEMA}"
STATE_RULES_TBL = config.STATE_RULES_TABLE
T_INV, T_SEC, T_LOG = f"{KB}.policy_document_inventory", f"{KB}.policy_sections", f"{KB}.policy_extraction_log"
T_DROP, T_CHG, T_CACHE = f"{KB}.policy_extraction_dropped", f"{KB}.policy_change_log", f"{KB}.policy_extraction_cache"
T_OUT = f"{KB}.policy_extraction_outcomes"          # D11: per-section recall accounting
# 2026-10-04 (critic M51-1): every run's own drafts, keyed by run_id - what v01 samples as "the engine's output"
T_DRAFTS = f"{KB}.policy_extraction_drafts"

run_dir = os.path.join(config.RUN_ROOT, RUN_ID) if RUN_ID else extract_io.latest_run_dir(config.RUN_ROOT)
assert run_dir and os.path.isdir(run_dir), f"no run folder under {config.RUN_ROOT}"
run = extract_io.read_run(run_dir)
man = run["manifest"]
print(f"run folder: {run_dir}")
print(f"manifest: run {man.get('run_id')} | finished={man.get('finished')} | backend {man.get('model_backend')} | "
      f"model calls {man.get('model_calls')} failures {man.get('model_failures')} | counts {man.get('counts')}")
if not man.get("finished") and not ALLOW_UNFINISHED:
    raise RuntimeError("this run did not finish (manifest.finished=False). Re-run 04_extract_chapters_gpu to completion, "
                       "or set ALLOW_UNFINISHED=True to persist the completed chapters only.")
if man.get("model_calls") and man.get("model_failures") == man.get("model_calls"):
    raise RuntimeError("every model call in this run failed - its drafts are regex-only. Not persisting.")

# COMMAND ----------

# MAGIC %md ## Merge drafts into the LIVE state_rules table (read failure = stop; shrink = stop)

# COMMAND ----------

existing_rules = kb_io.table_or_none(spark, STATE_RULES_TBL)      # raises TableAccessError on 403, never None-for-denied
print(f"live state_rules: {'(table does not exist yet)' if existing_rules is None else f'{len(existing_rules)} rows'}")

RUN = str(man.get("run_id") or os.path.basename(os.path.normpath(run_dir)))
# C3-09: which chapter + document version this run re-extracted. A chapter whose extraction FAILED (error in
# the run log) re-extracted nothing; and only sections the run answered definitively can supersede a draft.
failed_chapters = {str(r.get("chapter")) for r in run["log"] if r.get("error")}
rerun = {str(r["chapter"]): r["doc_hash"] for r in run["inventory"]
         if r.get("doc_hash") and str(r.get("chapter")) not in failed_chapters}
completed_sections = {o["section_id"] for o in run["outcomes"]
                      if o.get("section_id") and o.get("outcome") in ("proposals", "no_rules")}
if not run["outcomes"]:
    print("this run has no section outcomes (older than D11): drafts it did not reproduce are NOT superseded")
if failed_chapters:
    print(f"chapters that failed in this run (their drafts are left as they are): {sorted(failed_chapters)}")

merged, counts = state_rules.merge_drafts(existing_rules, run["drafts"], rerun=rerun, run_id=RUN,
                                          completed_sections=completed_sections)
print("merge:", counts)
if counts.get("superseded"):
    print(f"  {counts['superseded']} older draft(s) of the same document version were not produced by run {RUN} and "
          f"are now 'superseded' (kept, not exported)")
if counts.get("rejected_quote_seen"):
    print(f"  {counts['rejected_quote_seen']} new draft(s) quote text a reviewer REJECTED before - they come back as "
          f"needs_review with that rejection in previous_decision")
extract_io.guard_state_rules_merge(existing_rules, merged, STATE_RULES_TBL)
state_rules.write_state_rules(spark, STATE_RULES_TBL, merged.to_dict("records"), mode="overwrite")

# COMMAND ----------

# MAGIC %md ## Append the run's telemetry (once per run_id) and merge the cache

# COMMAND ----------

# C4-13: explicit column types, so one run's content (a failed chapter's log row has no `sections`; an
# all-empty text column) can never turn a bigint into a double or a string into a double. Columns a table
# already has keep the table's type; columns not listed here are inferred (all-null -> string).
S, L, D, B = "string", "long", "double", "boolean"
TELEMETRY_SCHEMAS = {
    T_INV: {"chapter": S, "title": S, "url": S, "path": S, "doc_hash": S, "bytes": L, "source": S, "fetched_at": S,
            "pages": L, "revision_date": S, "revision_history": S, "sections": L, "candidate_sections": L,
            "run_id": S, "archived_path": S},
    T_SEC: {"heading": S, "page_start": L, "page_end": L, "text": S, "chapter": S, "doc_hash": S, "section_id": S,
            "text_hash": S, "n_chars": L, "rule_signal": L, "codes_seen": S, "has_rule_signal": B, "run_id": S},
    T_LOG: {"chapter": S, "doc_hash": S, "run_id": S, "backend": S, "prompt_version": S, "sections": L,
            "sections_candidate": L, "sections_from_cache": L, "sections_skipped_noncandidate": L,
            "sections_no_rules": L, "sections_with_proposals": L, "proposals": L, "grounded": L, "dropped": L,
            "unparseable": L, "model_failed": L, "degraded_patterns_only": L, "started_at": S, "finished_at": S,
            "drafts_unique": L, "model_backend": S, "model_route": S, "model_calls": L, "model_failures": L,
            "model_retries": L, "model_unparseable": L, "last_model_error": S, "patterns_only_allowed": B,
            "checkpoints": L, "retryable_sections": S, "seconds": D, "error": S},
    T_DROP: {"chapter": S, "section_id": S, "heading": S, "statement": S, "predicate": S, "codes": S,
             "verbatim_quote": S, "drop_reason": S, "extraction_source": S, "doc_hash": S, "page_start": L,
             "page_end": L, "run_id": S},
    T_CHG: {"run_id": S, "chapter": S, "change_type": S, "extraction_key": S, "rule_id": S, "statement": S,
            "old_doc_hash": S, "new_doc_hash": S},
    T_OUT: {"chapter": S, "section_id": S, "heading": S, "page_start": L, "page_end": L, "doc_hash": S, "run_id": S,
            "outcome": S, "reason": S, "n_proposals": L, "n_grounded": L, "n_dropped": L, "from_cache": B},
    # 2026-10-04 (critic M51-1): a draft is a state_rules row (state_rules.STATE_RULE_COLUMNS): text, except its three
    # flags and the model's confidence; run_id is stamped by write_run_rows (a draft carries extraction_run_id only)
    T_DRAFTS: {**{c: S for c in state_rules.STATE_RULE_COLUMNS}, "machine_checkable": B, "ambiguity_flag": B,
               "deactivated": B, "extraction_confidence": D, "run_id": S},
}
# C4-11: one run's rows exactly once - rows of this run_id from an earlier persist are replaced, not doubled
# (inventory rows are stamped with the run_id here; they did not carry one)
for key, table in (("inventory", T_INV), ("sections", T_SEC), ("log", T_LOG), ("dropped", T_DROP),
                   ("changes", T_CHG), ("outcomes", T_OUT),       # outcomes: empty for runs older than D11
                   ("drafts", T_DRAFTS)):                         # the run's own drafts, whatever review did since
    kb_io.write_run_rows(spark, run[key], table, RUN, schema=TELEMETRY_SCHEMAS[table])
# the run's cache already contains every snapshot entry it was given plus the new calls. Merged by cache_key
# with the table (C3-20: a concurrent run's entries are kept), and never replaced by an EMPTY cache - since
# C4-18 an empty overwrite really empties a table, and the cache is the expensive artifact.
old_cache = kb_io.table_or_none(spark, T_CACHE)
cache_rows = {} if old_cache is None else {r["cache_key"]: r["proposals"] for r in old_cache.to_dict("records")}
cache_rows.update({k: json.dumps(v) for k, v in run["cache"].items()})
if cache_rows:
    kb_io.write_table(spark, [{"cache_key": k, "proposals": v} for k, v in cache_rows.items()], T_CACHE,
                      mode="overwrite", schema={"cache_key": S, "proposals": S})
else:
    print(f"  (no cache entries in the run or in {T_CACHE}; nothing written)")

# COMMAND ----------

# MAGIC %md ## Export the review workbook (drafts, lowest confidence first)

# COMMAND ----------

os.makedirs(os.path.dirname(REVIEW_XLSX), exist_ok=True)
# C4-11: never overwrites a workbook that already holds reviewer entries (then writes a timestamped one)
wb = state_rules.export_review_workbook(spark, STATE_RULES_TBL, REVIEW_XLSX)
if os.path.abspath(wb) != os.path.abspath(REVIEW_XLSX):
    print(f"\nNOTE: {REVIEW_XLSX} holds a review in progress and was left untouched. This run's export is\n"
          f"      {wb}\n"
          f"      Finish and ingest the first one with 06 (it is archived on ingest), or set WORKBOOK in 06 to the "
          f"new file.")
print(f"STEP 1 done. Next: a reviewer fills decision/reviewer in {wb}, then run 06_review_decisions (step 2), "
      f"then 07_build_kb (step 3).")
