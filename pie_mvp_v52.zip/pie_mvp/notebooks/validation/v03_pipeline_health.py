# Databricks notebook source
# MAGIC %md
# MAGIC # v03 · Pipeline health and the measurement bar
# MAGIC
# MAGIC **What this answers:** is the latest build and detector run sound, are the federal edits current, what did extraction do
# MAGIC with each chapter, what quality numbers exist — and, against the definition-of-done measurement bar, what is **GO** and
# MAGIC what is **NOT YET**, with the reason for each.
# MAGIC **How to read it:** the last table is the summary. A row says GO only when the number it rests on exists and meets the
# MAGIC bar; a missing number is always NOT YET, never assumed. A rate counts as *measured* only when its 95% interval is
# MAGIC narrow enough to state (`MAX_CI_WIDTH`, default ±10 points): 3 of 4 correct is a number, not a measurement.
# MAGIC Pass marks are judged on the **lower** end of the 95% interval: executable-rule precision ≥ 0.95 (real AND faithful
# MAGIC among the rules that become queries), extraction recall ≥ 0.90 (pooled; per-chapter numbers shown), fidelity ≥ 0.95.
# MAGIC An extraction number is judged only when it was measured on the **engine's own output** (v01 with `STATUSES = None`:
# MAGIC metric `population` = `engine_latest_run`) **on the current corpus** (its `corpus_version` = the current document set)
# MAGIC **and on the current latest run of every chapter it covers** (its `sample_runs` = the latest successful run of each
# MAGIC chapter in `policy_extraction_log`: re-running 04 on the same corpus makes a sample stale), and only while no more than
# MAGIC `MAX_UNSCORED_SHARE` (10%) of the sample's drawn units were left unscored; otherwise the row is NOT YET and says why
# MAGIC (2026-10-04, critic M51-3 / M51-6 and the run follow-up). Every v01 number is weighted by stratum size.
# MAGIC Rows marked INFO carry a number without a pass mark (filter loss: dropped candidates that were real rules).
# MAGIC **Limits:** this reports what the tables say. Quality metrics come from human-scored samples (v01, v02); until those
# MAGIC are scored and ingested, extraction precision/recall/fidelity/filter loss and detector precision are unmeasured. The
# MAGIC corpus is the AHCCCS FFS Provider Billing Manual chapters and exhibits — every rate here is about that scope only.
# MAGIC AHCCCS rule tables loaded by `00b` (Same Day Disallow, Daily Limits, B2 Matrix) join the corpus bar's corpus id and
# MAGIC leave its still-to-load list; the extraction rates are judged on the documents alone (the engine does not read them).
# MAGIC
# MAGIC Read-only (one aggregate query of the claims table: the provider type codes 08's NCCI routing gate checks on CMS-1500 /
# MAGIC UB-04 lines - `ncci_routing.observed_types_sql`).

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import Window, functions as F
import config, quality, acquire_ncci, ingest_ncci_tables, ncci_routing, policy_docs, run_guard, ahcccs_tables
for _m in (config, quality, acquire_ncci, ingest_ncci_tables, ncci_routing, policy_docs, run_guard, ahcccs_tables):
    importlib.reload(_m)

FIDELITY_TARGET = 0.95          # pass marks, judged on the lower 95% bound (v01 prints the same bars)
EXEC_PRECISION_TARGET = 0.95    # real AND faithful among sampled rules whose predicate compiles (the rules that become queries)
RECALL_TARGET   = 0.90          # real rules found / (found + missed), pooled over the scored sections
MAX_CI_WIDTH    = 0.20          # a rate counts as "measured" only when its 95% interval is at most this wide
MAX_UNSCORED_SHARE = 0.10       # a bar is NOT YET while more than this share of its sample's drawn units is unscored

# COMMAND ----------

KB = config.KB


def T(name):
    return f"{KB}.{name}"


def have(name):
    return spark.catalog.tableExists(T(name))


def num(v):
    try:
        return None if v is None or pd.isna(v) else v
    except (TypeError, ValueError):
        return v


GO = []            # rows of the final table


def bar(item, ok, reason):
    GO.append({"measurement bar item": item, "status": "GO" if ok else "NOT YET", "reason": reason})


def info(item, reason):
    """A number shown in the summary WITHOUT a pass mark: never GO, never NOT YET."""
    GO.append({"measurement bar item": item, "status": "INFO", "reason": reason})

# COMMAND ----------

# MAGIC %md ## 1. Latest build

# COMMAND ----------

bl = spark.table(T("policy_build_log")).orderBy(F.desc("built_at")).limit(1).toPandas() if have("policy_build_log") else pd.DataFrame()
BUILD_ID = spark.table(T("policy_rules")).where("build_id IS NOT NULL").select("build_id").first()[0] if have("policy_rules") else None
b = bl.iloc[0].to_dict() if len(bl) else {}
if b:
    show_keys = ["build_id", "built_at", "claims_from", "claims_to", "scope_codes", "rules", "ncci_rules", "state_rules",
                 "detectors_compiled", "detectors_batched", "leads", "stale_approvals_excluded", "legacy_seed_rules",
                 "pct_paid_covered_any", "pct_paid_covered_state", "ambiguity_register_rows", "overlap_rows",
                 "contradiction_candidates", "ahcccs_stale_vs_claims", "ahcccs_readings_sha256"]
    display(pd.DataFrame({"field": show_keys, "value": [str(b.get(k)) for k in show_keys]}))
    if BUILD_ID and b.get("build_id") != BUILD_ID:
        print(f"WARNING: the current policy_rules build ({BUILD_ID}) is not the latest build log row ({b.get('build_id')}).")
else:
    print("No build yet - run 07_build_kb.")

# COMMAND ----------

# MAGIC %md ## 2. Latest detector run

# COMMAND ----------

run = {}
if have("policy_detector_runs"):
    runs = spark.table(T("policy_detector_runs"))
    rid = runs.agg(F.max("run_id")).first()[0]
    r = runs.where(F.col("run_id") == rid).toPandas()
    nf = spark.table(T("policy_findings")).where(F.col("run_id") == rid).count() if have("policy_findings") else 0
    # 2026-10-04 (critic M51-8): the RUN:snapshot row keeps the snapshot numbers as JSON in `error` - not a detector
    # error (08 counts the same way); a partial run says why (the `skipped` column of the queries it did not run)
    run_errors, run_problems = quality.run_completeness(r)
    run = {"run_id": rid, "build_id": r["build_id"].dropna().iloc[0] if r["build_id"].notna().any() else None,
           "detector_rows": len(r), "errors": run_errors,
           "partial_run": bool(r["partial_run"].fillna(False).astype(bool).any()) if "partial_run" in r else None,
           "detectors_eligible": int(r["detectors_eligible"].max()) if "detectors_eligible" in r and r["detectors_eligible"].notna().any() else None,
           "findings": nf, "problems": run_problems}
    display(pd.DataFrame({"field": list(run), "value": [str(v) for v in run.values()]}))
    if run["errors"]:
        display(r[r["error"].notna() & ~r["rule_id"].astype(str).str.startswith("RUN:")][["rule_id", "predicate_type", "error"]])
else:
    print("No detector run yet - run 08_run_detectors.")

# COMMAND ----------

# MAGIC %md ## 3. NCCI freshness

# COMMAND ----------

metas = ingest_ncci_tables.discover_tables(spark, config.CATALOG, config.SCHEMA)
cy, cq = acquire_ncci.current_quarter()
fresh = []
for (svc, edit), g in pd.DataFrame(metas).groupby(["service", "edit_type"]) if metas else []:
    loaded = sorted({(int(y), int(q)) for y, q in zip(g["year"], g["quarter"])})
    fresh.append({"service": svc, "edit": edit, "latest": f"{loaded[-1][0]}Q{loaded[-1][1]}",
                  "current": loaded[-1] >= (cy, cq), "missing_up_to_today": ", ".join(acquire_ncci.missing_quarters(loaded)) or "none"})
fresh = pd.DataFrame(fresh)
print(f"today is in {cy}Q{cq}")
display(fresh) if len(fresh) else print("no NCCI tables found")

# COMMAND ----------

# MAGIC %md ## 4. Extraction outcomes by chapter (current document version)

# COMMAND ----------

oc = pd.DataFrame()
if have("policy_extraction_outcomes") and have("policy_document_inventory"):
    cur = quality.current_doc_hash(spark.table(T("policy_document_inventory")).toPandas())
    cur_df = spark.createDataFrame(pd.DataFrame({"chapter": list(cur), "doc_hash": list(cur.values())}),
                                   "chapter string, doc_hash string")
    w = Window.partitionBy("section_id", "doc_hash").orderBy(F.desc("run_id"))
    oc = (spark.table(T("policy_extraction_outcomes")).withColumn("chapter", F.col("chapter").cast("string"))
          .join(cur_df, ["chapter", "doc_hash"]).withColumn("_r", F.row_number().over(w)).where("_r = 1")
          .groupBy("chapter").pivot("outcome").count().fillna(0).toPandas())
    display(oc.sort_values("chapter", key=lambda s: s.map(lambda v: (len(v), v))))
    if have("policy_extraction_log"):
        lg = spark.table(T("policy_extraction_log")).toPandas().sort_values("started_at").groupby("chapter").tail(1)
        print("latest extraction run per chapter (backend = how rules were found; model_failures > 0 needs a look):")
        display(lg[[c for c in ("chapter", "run_id", "backend", "model_backend", "model_calls", "model_failures", "proposals",
                                "grounded", "dropped", "error") if c in lg.columns]])
else:
    print("No extraction outcomes yet (no chapter extracted with this package version).")

# COMMAND ----------

# MAGIC %md ## 5. Latest quality metrics (from v01 / v02)

# COMMAND ----------

# the CURRENT corpus - the exact document set (policy_docs.corpus_version of each document's latest doc_hash, the recipe
# v01 stamps on every sample): 2026-10-04 (critic M51-3) an extraction number is judged only when measured on it
INV_CUR = (quality.current_doc_hash(spark.table(T("policy_document_inventory")).toPandas())
           if have("policy_document_inventory") else {})
CORPUS_VERSION = policy_docs.corpus_version(INV_CUR)
# ... and the CURRENT engine output: the latest successful run of each chapter's current document version (the notion v01
# samples from). 2026-10-04 (follow-up to critic M51-3): re-running 04 on the same corpus (another reasoning effort) left
# the older run's sample judgeable - a number is judged only while the runs its sample_runs names are still the latest.
LATEST_RUNS = quality.latest_runs(spark.table(T("policy_extraction_log")).toPandas()
                                  if have("policy_extraction_log") else None, INV_CUR)
QM_ALL = qm = pd.DataFrame()
if have("policy_quality_metrics"):
    QM_ALL = spark.table(T("policy_quality_metrics")).toPandas()
    qm = QM_ALL.sort_values("computed_at").groupby(["metric", "scope"]).tail(1)
    display(qm.sort_values(["metric", "scope"])[[c for c in (
        "metric", "scope_type", "scope", "n", "value", "ci_low", "ci_high", "unscored", "scored_units", "population",
        "corpus_version", "sample_runs", "sample_id", "computed_at", "notes") if c in qm.columns]])
    print(f"current corpus {CORPUS_VERSION}, latest runs {quality.sample_runs_text(LATEST_RUNS) or 'none'}: an "
          f"extraction number is judged only when measured on the engine's own output (population "
          f"{quality.ENGINE_POPULATION}) of this corpus and of these runs, with at most {MAX_UNSCORED_SHARE:.0%} of its "
          "drawn units unscored")
else:
    print("policy_quality_metrics does not exist: NO quality metric has been measured yet (run v01 / v02 and ingest scored workbooks).")


def precise(m):
    return (m["ci_high"] - m["ci_low"]) <= MAX_CI_WIDTH


def describe(label, m):
    txt = f"{label}: {m['value']:.2f} (95% CI {m['ci_low']:.2f}-{m['ci_high']:.2f}, n={int(m['n'])})"
    if not precise(m):
        need = quality.n_for_ci_width(m["value"], MAX_CI_WIDTH)
        txt += f" too few to state" + (f", ~{need - int(m['n']):,} more needed" if need else "")
    return txt


def metric(name, scope):
    """The metric row a bar may stand on, or None. An extraction number (v01): the latest row measured on the engine's
    own output of the current corpus and of the latest run of every chapter it covers, with n > 0
    (quality.metric_for_bar; why_not says why there is none). 2026-10-04 (critic M51-3 and its run follow-up): the
    latest row of ANY sample was taken - an approved-only one, an old export, another corpus, an older run.
    A detector number (v02): the latest row."""
    if name in quality.EXTRACTION_METRICS:
        return quality.metric_for_bar(QM_ALL, name, scope, CORPUS_VERSION, LATEST_RUNS)[0]
    if not len(qm):
        return None
    m = qm[(qm["metric"] == name) & (qm["scope"].astype(str) == str(scope))]
    return m.iloc[0].to_dict() if len(m) and int(m.iloc[0]["n"] or 0) > 0 else None


def why_not(name, scope, default):
    """Why no row of an extraction metric can be judged: what its latest row was measured on (population, corpus,
    runs, n = 0 and why) - or `default` when there is no row of it at all."""
    m, why = quality.metric_for_bar(QM_ALL, name, scope, CORPUS_VERSION, LATEST_RUNS)
    return default if m is not None or not len(QM_ALL) or why.startswith("no ") else why


def unscored_share(m):
    """The share of a metric's drawn units left unscored (0 for rows ingested before 2026-10-04: none recorded)."""
    u = quality._int_or_none(m.get("unscored")) or 0
    k = quality._int_or_none(m.get("scored_units"))
    k = int(m["n"]) if k is None else k
    return u / (u + k) if u + k else 0.0

# COMMAND ----------

# MAGIC %md ## 6. The measurement bar — GO / NOT YET

# COMMAND ----------

sr = spark.table(config.STATE_RULES_TABLE).toPandas()
ext_chapters = sorted({str(c) for c in sr.loc[sr["origin"] == "extracted", "chapter"].dropna()}, key=lambda v: (len(v), v))

for name, label in (("extraction_precision", "Extraction precision measured per chapter"),
                    ("extraction_recall", "Extraction recall measured per chapter")):
    if not ext_chapters:
        bar(label, False, "no extracted rules yet")
        continue
    ms = {c: metric(name, c) for c in ext_chapters}
    miss = [c for c in ext_chapters if ms[c] is None]
    wide = [c for c in ext_chapters if ms[c] is not None and not precise(ms[c])]
    # 2026-10-04 (critic M51-6): a chapter with too many drawn units left unscored is not measured either
    blank = [c for c in ext_chapters if ms[c] is not None and unscored_share(ms[c]) > MAX_UNSCORED_SHARE]
    vals = "; ".join(describe(f"ch {c}", ms[c]) for c in ext_chapters if ms[c] is not None)
    bar(label, not miss and not wide and not blank,
        (f"{vals}. " if vals else "")
        + (f"no judgeable sample for chapter(s) {', '.join(miss)}: "
           f"{why_not(name, miss[0], 'no scored sample (run v01 with STATUSES = None, score and ingest)')}. "
           if miss else "")
        + (f"more than {MAX_UNSCORED_SHARE:.0%} of the drawn units unscored for chapter(s) {', '.join(blank)}. "
           if blank else "")
        + ("" if miss or wide or blank else "every extracted chapter is measured to within the interval width."))

def per_chapter(name):
    """'; per chapter: ch 10 0.91 (...); ...' for the extracted chapters that have a number (shown, not judged)."""
    vals = [describe(f"ch {c}", metric(name, c)) for c in ext_chapters if metric(name, c) is not None]
    return f"; per chapter: {'; '.join(vals)}" if vals else ""


# 2026-10-04 (external review): pass marks for precision and recall, judged like fidelity on the LOWER 95% bound of the
# pooled number. Precision is judged on the rules that become queries (real AND faithful), because a compiled rule that is
# real but unfaithful produces wrong findings; precision over every draft (leads included) stays a measured number above.
# 2026-10-04 (critic M51-3 / M51-6): metric() gives only a row measured on the engine's own output of the current corpus
# (why_not says what the latest row was measured on otherwise), and a row with more than MAX_UNSCORED_SHARE of its drawn
# units unscored is NOT YET (quality.lower_bound_bar)
ok, why = quality.lower_bound_bar(metric("executable_rule_precision", "all"), EXEC_PRECISION_TARGET,
                                  "scored compiled-type rules",
                                  why_not("executable_rule_precision", "all",
                                          "no scored sample of rules that compile (run v01 and ingest)"),
                                  MAX_UNSCORED_SHARE)
bar(f"Executable-rule precision >= {EXEC_PRECISION_TARGET:.2f} (lower 95% bound): real AND faithful among rules that compile",
    ok, why + per_chapter("executable_rule_precision"))
rc = metric("extraction_recall", "all")
ok, why = quality.lower_bound_bar(rc, RECALL_TARGET, "rules in scored sections",
                                  why_not("extraction_recall", "all", "no scored recall sample (run v01 and ingest; "
                                                                      "real_rules_found and missed_rules)"),
                                  MAX_UNSCORED_SHARE)
bar(f"Extraction recall >= {RECALL_TARGET:.2f} (lower 95% bound, pooled)", ok, why + per_chapter("extraction_recall"))

ok, why = quality.lower_bound_bar(metric("extraction_fidelity", "all"), FIDELITY_TARGET, "scored real rules",
                                  why_not("extraction_fidelity", "all", "no scored fidelity sample (run v01 and ingest)"),
                                  MAX_UNSCORED_SHARE)
bar(f"Extraction fidelity >= {FIDELITY_TARGET} (lower 95% bound)", ok, why)

# real rules the grounding / post-checks dropped (v01 DROPPED sheet): a recall loss no other number sees. No pass mark.
fl = metric("extraction_filter_loss", "all")
info("Extraction filter loss: dropped candidates that were real rules (no pass mark)",
     (describe("pooled", fl) + per_chapter("extraction_filter_loss")
      + (f". {quality._text(fl.get('notes'))}" if quality._text(fl.get("notes")) else ""))
     if fl else "not measured: " + why_not("extraction_filter_loss", "all",
                                           "no scored DROPPED sheet ingested (run v01)"))

if run.get("run_id") and have("policy_findings"):
    strata = (spark.table(T("policy_findings")).where(F.col("run_id") == run["run_id"])
              .select(F.concat_ws(" | ", "origin", "predicate_type").alias("s")).distinct().toPandas()["s"].tolist())
    ms = {x: metric("detector_precision", x) for x in strata}
    miss = [x for x in strata if ms[x] is None]
    wide = [x for x in strata if ms[x] is not None and not precise(ms[x])]
    vals = "; ".join(describe(x, ms[x]) for x in strata if ms[x] is not None)
    bar("Detector precision measured per rule type", bool(strata) and not miss and not wide,
        (f"{vals}. " if vals else "") + (f"no reviewed sample for {', '.join(miss)} (run v02). " if miss else "")
        + ("the latest run has no findings" if not strata else
           "" if miss or wide else "every rule type that fired is measured to within the interval width."))
else:
    bar("Detector precision measured per rule type", False, "no detector run yet")

cov_any, cov_state = num(b.get("pct_paid_covered_any")), num(b.get("pct_paid_covered_state"))
# 2026-10-04 (v5.2b, critic F10): 07 counts a rule only for the paid dollars dated inside its own window
bar("Coverage reported (% of paid $ under an active rule)", cov_any is not None,
    f"{cov_any}% of paid $ is dated inside the window of a compiled rule of its code, {cov_state}% inside a state "
    f"rule's (build {b.get('build_id')}). An upper bound: a rule checks a line only when its other conditions hold too "
    "(the partner code of a pair, the units, the provider type, the age)." if cov_any is not None
    else "no coverage number in the build log")

amb, contra = num(b.get("ambiguity_register_rows")), num(b.get("contradiction_candidates"))
bar("Register sizes reported (ambiguities, contradictions)", amb is not None and contra is not None,
    f"{amb} ambiguity entries, {contra} contradiction candidates (candidates, not confirmed)" if amb is not None and contra is not None
    else "register sizes missing from the build log")

if run.get("run_id"):
    # errors without the RUN:snapshot row; a partial run with the reason its skipped queries record (critic M51-8)
    problems = ([f"run is on build {run['build_id']}, current is {BUILD_ID}"] if run["build_id"] != BUILD_ID else []) + \
               run["problems"]
    bar("Latest detector run complete on the current build", not problems,
        "; ".join(problems) or f"run {run['run_id']}: {run['findings']:,} findings, no errors")
else:
    bar("Latest detector run complete on the current build", False, "no detector run yet")

if len(fresh):
    behind = fresh[~fresh["current"]]
    bar(f"NCCI edits current through {cy}Q{cq}", behind.empty,
        "; ".join(f"{r.service} {r.edit}: latest {r.latest}" for r in behind.itertuples()) or "every loaded edition is current")
else:
    bar(f"NCCI edits current through {cy}Q{cq}", False, "no NCCI tables")

legacy = int(num(b.get("legacy_seed_rules")) or 0)
waiting = int(((sr["review_status"] == "needs_review") & sr["prior_review"].notna()).sum()) if "prior_review" in sr else 0
bar("Nothing compiles without version-bound sign-off", legacy == 0 or not config.COMPILE_LEGACY_SEEDS,
    (f"{legacy} hand-authored seed rule(s) compile without a named reviewer (config.COMPILE_LEGACY_SEEDS = True). "
     if legacy and config.COMPILE_LEGACY_SEEDS else "only signed rules compile. ")
    + f"{int(num(b.get('stale_approvals_excluded')) or 0)} stale approval(s) excluded; {waiting} rule(s) waiting for re-sign.")

# 2026-10-04 (v5.2): the AHCCCS rule tables 00b loaded (a 'loaded' row in config.AHCCCS_TABLES_LOG), read once: the
# sign-off bar judges their rules by their readings (v5.2b) and the corpus bar below counts them
TABLE_LOG = (spark.table(config.AHCCCS_TABLES_LOG).toPandas()
             if spark.catalog.tableExists(config.AHCCCS_TABLES_LOG) else None)
TABLES_LOADED = ahcccs_tables.loaded_versions(TABLE_LOG)


def table_readings(key):
    """{signed, reason} of a loaded table's readings (ahcccs_tables.table_compiles). signed only when the table compiles
    AND none of its readings is unsigned: with config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS off a table compiles
    unsigned, and that is not a signature."""
    try:
        ok_, why_ = ahcccs_tables.table_compiles(key)
        return {"signed": bool(ok_) and not ahcccs_tables.unsigned_readings(key), "reason": why_}
    except Exception as e:                       # read-only health check: say why, never stop
        return {"signed": False, "reason": f"{key}: its readings could not be read ({type(e).__name__}: {e})"}


TABLE_READINGS = {k: table_readings(k) for k, vs in TABLES_LOADED.items() if vs}

# 2026-10-04 (external review): checked on the current build itself, rule by rule - every compiled STATE rule (a query) must
# be approved by a named reviewer; a hand-authored seed compiling unsigned (COMPILE_LEGACY_SEEDS) is NOT YET
# 2026-10-04 (v5.2b, critic F9): an AHCCCS table rule (TBL-, review_status state_table) has no reviewer of its own - it
# was listed as unsigned, so the bar could never be GO. A table's rules are signed through its readings: the bar states,
# per LOADED table, whether its readings are signed (quality.table_readings_bar) and is NOT YET when a table's rules
# compile on readings nobody signed (config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS off)
SIGNOFF_ITEM = "Every executable state rule signed by a named reviewer"
if have("policy_detectors") and have("policy_rules"):
    _pr = spark.table(T("policy_rules"))
    compiled_state = (spark.table(T("policy_detectors")).where("compiled AND (origin IS NULL OR origin <> 'ncci')")
                      .select("rule_id", "origin", "predicate_type").toPandas()
                      .merge(_pr.where("origin IS NULL OR origin <> 'ncci'")
                             .select("rule_id", *[c for c in ("review_status", "reviewer") if c in _pr.columns]).toPandas()
                             .drop_duplicates("rule_id", keep="last"), on="rule_id", how="left"))
    ok, why = quality.signoff_bar(compiled_state)
    ok_t, why_t = quality.table_readings_bar(compiled_state, TABLE_READINGS)
    bar(SIGNOFF_ITEM, ok and ok_t, f"build {BUILD_ID}: {why}" + (f"; {why_t}" if why_t else ""))
else:
    bar(SIGNOFF_ITEM, False, "no build yet (run 07_build_kb)")

# 2026-10-04 (external review): a rate needs an unambiguous denominator - the exact document set (corpus_version, computed
# in section 5: INV_CUR / CORPUS_VERSION) - and the corpus is complete only when every manual chapter is ingested and no
# rule source of config.CORPUS_PENDING is still to load
# 2026-10-04 (v5.2): an AHCCCS rule table 00b loaded (a 'loaded' row in config.AHCCCS_TABLES_LOG) is part of the corpus:
# each loaded version's file sha256 joins the corpus id as "table:<key>:<version_date>" (ahcccs_tables.corpus_entries)
# and the table leaves the "still to load" list (its CORPUS_PENDING key is the table key). The extraction bars above keep
# CORPUS_VERSION - the documents only, the stamp v01 writes: the engine never reads these tables, so loading one must
# not make an extraction sample stale. (TABLE_LOG / TABLES_LOADED: read above, before the sign-off bar.)
CORPUS_WITH_TABLES = policy_docs.corpus_version({**INV_CUR, **ahcccs_tables.corpus_entries(TABLES_LOADED)})
# 2026-10-04 (v5.2b, critic F12): the tables whose claims run past the newest version's max age (the latest build's
# ahcccs_stale_vs_claims, 07) are named in this row - shown, not judged
TABLES_STALE = quality._json(b.get("ahcccs_stale_vs_claims")) or {}
ok, why = quality.corpus_bar(INV_CUR, config.CHAPTERS, getattr(config, "CORPUS_PENDING", {}), CORPUS_WITH_TABLES,
                             loaded_tables=TABLES_LOADED, stale_tables=TABLES_STALE)
bar(f"Corpus frozen and complete for its stated scope ({quality.CORPUS_SCOPE})", ok, why)

# v06: every query of the CURRENT build signed OK by a validator (a decision binds to the exact SQL via its sha256)
cur_sql = {}
if have("policy_detectors"):
    _dt = spark.table(T("policy_detectors"))
    _d = _dt.where("compiled AND sql IS NOT NULL").select("rule_id", "sql_sha256").toPandas()
    cur_sql.update(dict(zip(_d["rule_id"], _d["sql_sha256"])))
    if "signal_sql" in _dt.columns:          # period limits: the rolling-window signal query is validated too
        _s = _dt.where("compiled AND signal_sql IS NOT NULL").select("rule_id", "signal_sql_sha256").toPandas()
        cur_sql.update({f"SIGNAL:{r}": h for r, h in zip(_s["rule_id"], _s["signal_sql_sha256"])})
if have("policy_batch_detectors"):
    _b = spark.table(T("policy_batch_detectors")).toPandas()
    if "sql_sha256" in _b:
        cur_sql.update({f"BATCH:{r['batch']}": r["sql_sha256"] for r in _b.to_dict("records")})
signed_ok = set()
if have("policy_query_validation"):
    _v = spark.table(T("policy_query_validation")).toPandas()
    _v = _v.sort_values("validated_at").drop_duplicates(["query_id", "sql_sha256"], keep="last")
    signed_ok = {(r["query_id"], r["sql_sha256"]) for r in _v.to_dict("records") if r["validator_decision"] == "OK"}
n_ok = sum(1 for q, h in cur_sql.items() if (q, h) in signed_ok)
bar("Every query of the current build validated by a person (v06)", bool(cur_sql) and n_ok == len(cur_sql),
    f"{n_ok} of {len(cur_sql)} current queries signed OK (v06 pack: plain English + SQL + scenario auto-tests)"
    if cur_sql else "no compiled queries in the current build")

# 2026-10-03: which NCCI edit file a line takes depends on the provider-type routing table - a policy reading too.
# 2026-10-04: this bar compared the mode with "provider_type", so once the default became "billing_provider_type" it always
# said "routing by claim form only". It now asks the question 08 asks (config.NCCI_REQUIRE_SIGNED_ROUTING, run_guard):
# 2026-10-04 (critic M51-9) with 08's own reading - the codes ncci_routing.observed_types_sql returns (the servicing type,
# plus the billing type only when routing by billing type, on CMS-1500 'A' / UB-04 'O' lines; v03 used to read both in
# every mode) and run_guard.ncci_routing_kind: GO only when the routing is 'signed' (an unmapped type routed by its claim
# form is a reading nobody signed, whatever the table says)
_rt = ncci_routing.summary()
OBSERVED_TYPES = UNSIGNED_TYPES = None
ROUTING_KIND = None if ncci_routing.uses_table() else run_guard.ncci_routing_kind([])
if ncci_routing.uses_table():
    try:
        _src = ncci_routing.routed_sql(config.CLAIMS_TABLE, config.CLAIM_COLS,
                                       cols={c.upper() for c in spark.table(config.CLAIMS_TABLE).columns})
        OBSERVED_TYPES = sorted({r["t"] for r in spark.sql(
            ncci_routing.observed_types_sql(f"{_src} rc", ncci_routing.PIE_FORM)).collect()})
        UNSIGNED_TYPES = ncci_routing.unsigned_observed(OBSERVED_TYPES)
        ROUTING_KIND = run_guard.ncci_routing_kind(OBSERVED_TYPES)
    except Exception as e:                       # read-only health check: say why the bar cannot be judged, never stop
        print(f"could not read the provider types on {config.CLAIMS_TABLE}: {type(e).__name__}: {e}")
print(f"NCCI routing: {ncci_routing.mode()} -> {ROUTING_KIND or 'unknown'}"
      + (f"; {len(OBSERVED_TYPES)} provider type code(s) observed, {len(UNSIGNED_TYPES)} unsigned"
         if OBSERVED_TYPES is not None else ""))
ok, why = quality.routing_bar(ncci_routing.uses_table(), _rt, OBSERVED_TYPES, UNSIGNED_TYPES, ROUTING_KIND)
bar("NCCI routing table (provider type -> CMS Table 2) signed for every provider type on CMS-1500 / UB-04 lines", ok, why)

go_table = pd.DataFrame(GO)
display(go_table)
_n = go_table["status"].value_counts().to_dict()
print(f"{_n.get('GO', 0)} GO, {_n.get('NOT YET', 0)} NOT YET"
      + (f", {_n.get('INFO', 0)} shown without a pass mark (INFO)" if _n.get("INFO") else "")
      + ". Done is not declarable while any measurement-bar row is NOT YET.")
