# Databricks notebook source
# MAGIC %md
# MAGIC # v01 · Extraction scoring — precision, fidelity, recall and filter loss on a human-scored sample
# MAGIC
# MAGIC **What this measures:** how often an extracted rule is a real rule (*precision*), how often a rule that becomes a query is
# MAGIC real **and** says what the source says (*executable-rule precision*), how often a real rule says what the source says
# MAGIC (*fidelity*), how many of a section's real rules the engine found (*recall*), and how many of the candidates the grounding
# MAGIC or the post-checks dropped were real rules (*filter loss*). Each number comes with a 95% interval and its sample size.
# MAGIC **How it works:** two phases.
# MAGIC 1. **EXPORT** (`EXPORT = True`): draws a stratified sample and writes a workbook for a policy expert.
# MAGIC    Sheet `RULES`: the drafts of the **latest successful run** of each chapter's current document version
# MAGIC    (`policy_extraction_drafts`, written by 05 for every run) — **rejected drafts included**, each with the predicate that
# MAGIC    run produced, so the number is the engine's own precision before review — by chapter × how it was found;
# MAGIC    `review_status` comes from `state_rules`, for information only. Fill `is_real_rule` (Y/N), `faithful_to_source` (Y/N),
# MAGIC    `notes`, `scorer`. (2026-10-04, critic M51-1: the population used to be `state_rules`, which keeps approved / rejected
# MAGIC    rows of older runs, so one sample mixed engine versions. A chapter whose latest run is not in `policy_extraction_drafts`
# MAGIC    — persisted before that table existed; re-running 05 on its run folder fixes it — is left out of all three sheets
# MAGIC    (with `STATUSES` set: of the DROPPED sheet) and **named** in the output and the README.)
# MAGIC    Sheet `RECALL`: sections (including ones the pre-filter skipped and ones with no rules) with the section text and the
# MAGIC    rules that same run extracted from it; fill `real_rules_found` (how many of the listed rules are real, distinct rules of
# MAGIC    the section), `missed_rules` (real rules the list lacks) and `scorer`.
# MAGIC    Sheet `DROPPED`: candidates that run's grounding / post-checks refused, by chapter × drop reason, with the rules it kept
# MAGIC    from the same section; fill `is_real_rule` (Y/N), `notes`, `scorer`.
# MAGIC    Every row of every sheet carries `population` (`engine_latest_run`, or `statuses:approved` with `STATUSES = ["approved"]`),
# MAGIC    `corpus_version` (the exact document set) and `sample_runs` (the latest run of each sampled chapter, JSON
# MAGIC    `{chapter: run_id}`): v03 judges a bar only on the engine's own sample of the current corpus, while those runs are
# MAGIC    still the latest (re-running 04 on the same corpus makes a sample stale - export, score and ingest a new one).
# MAGIC 2. **INGEST** (`SCORED_WORKBOOK = "<path>"`): reads the filled workbook, computes the metrics, appends them to
# MAGIC    `policy_quality_metrics` (with the sheet's `population` / `corpus_version`, and `unscored` / `scored_units`) and the raw
# MAGIC    scores (column `sheet` = RULES / RECALL / DROPPED) to `policy_extraction_scores`.
# MAGIC
# MAGIC **Limits:** until a workbook has been scored and ingested, **extraction precision, fidelity, recall and filter loss are
# MAGIC unmeasured**. A sample measures the chapters, extraction methods and drop reasons it was drawn from, nothing else. Every
# MAGIC number, per chapter and pooled ("all"), weights each stratum by its size (a stratum drawn in full and a stratum of 500
# MAGIC sampled 15 times do not count alike); recall's unit is the section, so its interval reflects how rules cluster in sections.
# MAGIC Pass marks, judged on the **lower** end of the 95% interval (v03 holds the same bars): executable-rule precision ≥ 0.95,
# MAGIC recall ≥ 0.90 (pooled), fidelity ≥ 0.95 — and no more than 10% of the drawn units left unscored
# MAGIC (`quality.MAX_UNSCORED_SHARE`). Precision over every draft and filter loss are shown without a pass mark.
# MAGIC
# MAGIC Writes: the workbook under `data/validation/`, and (INGEST only) appends to the two tables above.

# COMMAND ----------

# MAGIC %pip install -q openpyxl

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import Window, functions as F
import config, kb_io, policy_docs, quality
for _m in (config, kb_io, policy_docs, quality):
    importlib.reload(_m)

EXPORT          = True          # phase 1: draw the sample and write the workbook
STATUSES        = None          # None = the drafts of the LATEST successful run of each chapter's current document version,
                                # REJECTED ones included (the engine's own output, before review - what v03 judges);
                                # ["approved"] = what the definition of done asks: fidelity of APPROVED rules (state_rules;
                                # v03 judges no bar on it)
N_PER_STRATUM   = 15            # rules per chapter x extraction_source (all of them when a stratum is smaller)
N_SECTIONS      = 10            # sections per chapter x outcome on the RECALL sheet
N_DROPPED_PER_STRATUM = 10      # dropped candidates per chapter x drop reason on the DROPPED sheet
INCLUDE_DUPLICATES = False      # True = also sample candidates dropped as a copy of a KEPT draft (the same rule: N by definition)
SEED            = 20260929      # same seed + same data = same sample
SCORED_WORKBOOK = None          # phase 2: path of the filled workbook; None = skip ingest
REINGEST        = False         # True = ingest a sample_id that was already ingested (adds a second set of rows)
FIDELITY_TARGET = 0.95          # pass marks, judged on the lower 95% bound (v03 holds the same values)
EXEC_PRECISION_TARGET = 0.95    # real AND faithful among rules whose predicate compiles (the rules that become queries)
RECALL_TARGET   = 0.90          # pooled over the scored sections

# COMMAND ----------

KB = config.KB
OUT_DIR = f"{config.WORKSPACE_DATA_DIR}/validation"
T_METRICS, T_SCORES = f"{KB}.policy_quality_metrics", f"{KB}.policy_extraction_scores"
T_DROP, T_LOG = f"{KB}.policy_extraction_dropped", f"{KB}.policy_extraction_log"
T_DRAFTS = f"{KB}.policy_extraction_drafts"         # every run's own drafts (05, 2026-10-04 critic M51-1)
SAMPLE_ID = f"v01-{pd.Timestamp.now().strftime('%Y%m%d')}-s{SEED}"
# population / corpus_version: what the sample was drawn from (v03 checks both); sample_runs: the latest run of each
# sampled chapter, JSON {chapter: run_id} (v03 judges a bar only while they are still the latest - a re-extraction of the
# same corpus makes the sample stale); rule_population: the members the rule applies to (state_rules.population - an
# age-less scoped rule stays a lead, regress.compiles); extraction_run_id: the run whose reading is shown
# (2026-10-04, critic M51-1 / M51-3 / M51-11 and the run follow-up)
RULE_COLS = ["sample_id", "population", "corpus_version", "sample_runs", "stratum", "stratum_size", "chapter",
             "extraction_source", "review_status", "statement", "predicate", "predicate_type", "rule_population",
             "reviewer_fix", "verbatim_quote", "source_doc", "source_locator", "source_url", "section_heading",
             "section_text", "rule_id", "extraction_key", "extraction_run_id", "doc_hash", "section_id"]
RULE_SCORE_COLS = ["is_real_rule", "faithful_to_source", "notes", "scorer"]
SEC_COLS = ["sample_id", "population", "corpus_version", "sample_runs", "stratum", "stratum_size", "chapter", "outcome",
            "outcome_reason", "heading", "page_start", "page_end", "section_text", "rules_extracted",
            "rules_extracted_text", "section_id", "doc_hash"]
SEC_SCORE_COLS = ["real_rules_found", "missed_rules", "scorer"]
DROP_COLS = ["sample_id", "population", "corpus_version", "sample_runs", "stratum", "stratum_size", "chapter",
             "drop_class", "drop_reason", "statement", "predicate", "verbatim_quote", "heading", "page_start", "page_end",
             "section_text", "rules_kept_text", "extraction_source", "run_id", "section_id", "doc_hash"]
DROP_SCORE_COLS = ["is_real_rule", "notes", "scorer"]
# columns a workbook exported before 2026-10-04 does not have: it is still ingested, and the notebook says what that costs
ADDED_2026_10_04 = {"RULES": ["predicate_type", "reviewer_fix"], "RECALL": ["real_rules_found"]}
# ... and the columns the critic-M51 export added (a workbook without them is ingested; v03 judges no bar on its metrics)
ADDED_M51 = {"RULES": ["population", "corpus_version", "sample_runs", "rule_population", "extraction_run_id"],
             "RECALL": ["population", "corpus_version", "sample_runs"],
             "DROPPED": ["population", "corpus_version", "sample_runs"]}
README = pd.DataFrame({"how to score": [
    "RULES sheet - one extracted rule per row. Read the verbatim quote in the context of the section text.",
    "  Rejected drafts are in the sample on purpose (it measures the engine before review): score what the text says, not "
    "what review_status says (it is the rule's status in state_rules, shown for information). reviewer_fix filled = a "
    "reviewer changed this rule, or state_rules holds an earlier run's reading of it; the predicate shown is the ENGINE's "
    "own (score that one). rule_population = the members the rule applies to (part of what faithful means).",
    "  is_real_rule: Y if the text states a billing/coverage rule this reading captures; N if it is not a rule (a heading, an example, "
    "a process duty mis-read as a limit, a duplicate).",
    "  faithful_to_source: only when is_real_rule = Y. Y if statement + predicate say exactly what the text says (codes, limits, "
    "conditions, exceptions); N if anything is wrong, missing or invented. predicate_type says whether the rule becomes a query "
    "(code_not_covered, max_units_..., code_pair_prohibited ...) or stays a lead (not_checkable ...): a real but unfaithful rule "
    "that becomes a query produces wrong findings.",
    "RECALL sheet - one policy section per row, with the rules the pipeline took from it (rules_extracted_text).",
    "  real_rules_found: how many of the rules in rules_extracted_text are REAL, DISTINCT rules this section states (0 if none). "
    "A non-rule counts 0; two copies of the same rule count once. Pre-filled 0 where nothing was extracted.",
    "  missed_rules: how many rules the section states that are NOT in rules_extracted_text (0 if none). Count each distinct limit, "
    "pair, exclusion or requirement once.",
    "  Fill both on a row, or neither: a section counts only when both are filled.",
    "DROPPED sheet - one candidate the grounding or the post-checks refused, with why (drop_reason) and the rules the pipeline "
    "kept from the same section (rules_kept_text).",
    "  is_real_rule: the same test as on RULES - Y if the text states a billing/coverage rule this candidate captures (even with "
    "details wrong) and no rule in rules_kept_text already states it: a real rule the filters lost. N if it is not a rule (a "
    "heading, an example, a process duty mis-read as a limit) or repeats a kept rule.",
    "Fill scorer with your name on every row you score. Leave rows blank rather than guessing - blanks are excluded, not counted "
    "- but a bar stays NOT YET while more than 10% of the drawn rows are blank.",
    "population, corpus_version and sample_runs (every sheet) say what this sample was drawn from: do not edit them.",
    "Do not add, remove or reorder rows or columns.",
]})

# COMMAND ----------

# MAGIC %md ## Phase 1 — export the sample

# COMMAND ----------

def current_sections(cur):
    """Sections of each chapter's CURRENT document version (cur = {chapter: doc_hash}), one row per section."""
    cur_df = spark.createDataFrame(pd.DataFrame({"chapter": list(cur), "doc_hash": list(cur.values())}),
                                   "chapter string, doc_hash string")
    w = Window.partitionBy("chapter", "doc_hash", "section_id").orderBy(F.desc("run_id"))
    return (spark.table(f"{KB}.policy_sections").withColumn("chapter", F.col("chapter").cast("string"))
            .join(cur_df, ["chapter", "doc_hash"]).withColumn("_r", F.row_number().over(w)).where("_r = 1").drop("_r"))


EXPORT_PATH = None
POP_REPORT, NO_RUN_ROWS = {}, {}
if EXPORT:
    # {chapter: doc_hash} of each document's CURRENT version - the recipe v03 uses too, so the corpus stamped here and
    # the corpus v03 checks agree on the same inventory
    CUR = quality.current_doc_hash(spark.table(f"{KB}.policy_document_inventory").toPandas())
    # 2026-10-04 (critic M51-3): every row of every sheet says what the sample was drawn from - its population and the
    # exact document set - and the ingest copies both into each metric row: v03 judges a bar only on the engine's own
    # sample (quality.ENGINE_POPULATION) of the current corpus
    POPULATION = quality.sample_population(STATUSES)
    CORPUS_VERSION = policy_docs.corpus_version(CUR)
    state = spark.table(config.STATE_RULES_TABLE).toPandas()
    LOG = spark.table(T_LOG).toPandas() if spark.catalog.tableExists(T_LOG) else None
    LATEST = quality.latest_runs(LOG, CUR)            # {chapter: latest successful run of its current version}
    # 2026-10-04 (critic M51-1): the engine's own output is what that run produced - policy_extraction_drafts, written by
    # 05 for every run. state_rules keeps the approved / rejected rows of OLDER runs (merge_drafts never drops a
    # decision), so sampling it mixed engine versions. These drafts are also the rules RECALL lists per section (default
    # population) and DROPPED lists as kept: the sheets describe one run.
    DRAFTS = spark.table(T_DRAFTS).toPandas() if spark.catalog.tableExists(T_DRAFTS) else None
    run_pop, POP_REPORT = quality.run_population(DRAFTS, CUR, LATEST, state, LOG)
    NO_RUN_ROWS = POP_REPORT["no_run_rows"]
    if DRAFTS is None:
        print(f"{T_DRAFTS} does not exist: no run was persisted by 05 since it records each run's drafts - re-run 05 on "
              "the latest run folder of each chapter (safe: the rows of a run_id are replaced, never doubled).")
    NO_RUN_TEXT = ""
    if NO_RUN_ROWS:
        _runs = ", ".join(f"{c}: {r or 'unknown'}" for c, r in NO_RUN_ROWS.items())
        NO_RUN_TEXT = (f"chapter(s) {', '.join(NO_RUN_ROWS)} "
                       + ("NOT in this sample" if not STATUSES else
                          "not on the DROPPED sheet (the rules its run kept are unknown)")
                       + f": the latest run ({_runs}) has no rows in {T_DRAFTS} (persisted before that table existed) - "
                       "re-run 05 on that run folder, then export again")
        print("WARNING: " + NO_RUN_TEXT)
    if POP_REPORT["empty_latest_run"]:
        print(f"  chapter(s) {', '.join(POP_REPORT['empty_latest_run'])}: the latest run produced no draft")
    if STATUSES:
        sr, rep = quality.scoring_population(state, CUR, STATUSES)
        print(f"population {POPULATION}: {len(sr):,} extracted rule(s) of the current document versions with "
              f"review_status in {STATUSES} (state_rules; the signed predicate is shown; v03 judges no bar on this "
              "sample); left out: " + (", ".join(f"{k} {v:,}" for k, v in rep.items()
                                                  if k in ("superseded", "other_doc_version", "other_status") and v)
                                        or "nothing"))
    else:
        sr = run_pop
        print(f"population {POPULATION}: {len(sr):,} draft(s) of the latest successful run of each chapter's current "
              f"document version ({', '.join(f'{c}: {r}' for c, r in POP_REPORT['chapters'].items()) or 'none'}) - "
              f"REJECTED drafts INCLUDED (the engine before review; review_status is shown for information); left out: "
              f"{POP_REPORT['older_run']:,} of older runs, {POP_REPORT['other_doc_version']:,} of other document versions")
    for c in ("chapter", "extraction_source", "extraction_key", "rule_id", "section_id", "doc_hash", "statement",
              "population", "reviewer_fix"):
        if c not in sr.columns:
            sr[c] = None                              # an empty population still exports a workbook with every column
    n_fix = int(sr["reviewer_fix"].notna().sum())
    if n_fix:
        print(f"  {n_fix} rule(s) carry a reviewer_fix note (a reviewer changed the rule, or state_rules holds another "
              "reading of it): the predicate shown is the one this population defines - see the README")
    corpus_line = f"corpus {CORPUS_VERSION} ({len(CUR)} document(s))"
    print(f"sample {SAMPLE_ID}: population {POPULATION}, {corpus_line}")
    secs = current_sections(CUR).select("section_id", "doc_hash", F.col("heading").alias("section_heading"),
                                        F.col("text").alias("section_text")).toPandas()
    sr["chapter"] = sr["chapter"].astype(str)
    sr["extraction_source"] = sr["extraction_source"].fillna("(unknown)")
    rules = quality.stratified_sample(sr, ["chapter", "extraction_source"], N_PER_STRATUM, SEED, key=["extraction_key", "rule_id"])
    rules = rules.merge(secs, on=["section_id", "doc_hash"], how="left")
    # the rule's own member population moves to rule_population: on every sheet `population` is the SAMPLE's
    rules["rule_population"] = rules["population"]
    rules["sample_id"], rules["population"], rules["corpus_version"] = SAMPLE_ID, POPULATION, CORPUS_VERSION
    for c in RULE_COLS:
        if c not in rules.columns:
            rules[c] = None
    for c in RULE_SCORE_COLS:
        rules[c] = None
    for c in ("section_text", "verbatim_quote", "statement"):
        rules[c] = rules[c].map(quality.clip_text)
    print(f"RULES: {len(rules):,} of {len(sr):,} rule(s) sampled:")
    display(rules.groupby(["stratum", "stratum_size"]).size().reset_index(name="sampled"))
    no_text = int(rules["section_text"].isna().sum())
    if no_text:
        print(f"  {no_text} sampled rule(s) have no section text attached (their section is not in policy_sections for the "
              "current version): score them from the quote and the PDF.")

    # RECALL: sections of the current version, stratified by chapter x outcome, with what was extracted from each
    wo = Window.partitionBy("section_id", "doc_hash").orderBy(F.desc("run_id"))
    outc = spark.table(f"{KB}.policy_extraction_outcomes").withColumn("_r", F.row_number().over(wo)).where("_r = 1").drop("_r")
    s = (current_sections(CUR).join(outc.select("section_id", "doc_hash", "outcome", F.col("reason").alias("outcome_reason")),
                                    ["section_id", "doc_hash"], "left")
         .select("chapter", "section_id", "doc_hash", "heading", "page_start", "page_end", F.col("text").alias("section_text"),
                 "outcome", "outcome_reason").toPandas())
    s["outcome"] = s["outcome"].fillna("(no outcome recorded)")
    if not STATUSES and NO_RUN_ROWS:
        # critic M51-1: what the latest run of these chapters extracted is unknown (reported above) - their sections
        # would all read "nothing extracted", so they are left out rather than counted as missed
        s = s[~s["chapter"].astype(str).isin(list(NO_RUN_ROWS))]
    per = (sr.groupby("section_id").agg(rules_extracted=("statement", "size"),
                                        rules_extracted_text=("statement", lambda x: "\n".join(f"- {t}" for t in x)))
           .reset_index())
    s = s.merge(per, on="section_id", how="left")
    s["rules_extracted"] = s["rules_extracted"].fillna(0).astype(int)
    recall = quality.stratified_sample(s, ["chapter", "outcome"], N_SECTIONS, SEED, key=["section_id", "doc_hash"])
    recall["sample_id"], recall["population"], recall["corpus_version"] = SAMPLE_ID, POPULATION, CORPUS_VERSION
    for c in SEC_SCORE_COLS:
        recall[c] = None
    # nothing extracted -> nothing real found: pre-filled, so the scorer only counts what the section states (missed_rules)
    recall["real_rules_found"] = pd.Series([0 if n == 0 else None for n in recall["rules_extracted"]],
                                           index=recall.index, dtype=object)
    for c in ("section_text", "rules_extracted_text"):
        recall[c] = recall[c].map(quality.clip_text)
    print(f"RECALL: {len(recall):,} of {len(s):,} current section(s) sampled:")
    display(recall.groupby(["stratum", "stratum_size"]).size().reset_index(name="sampled"))

    # DROPPED (2026-10-04, external review): the candidates the grounding / post-checks refused were never looked at, so a
    # real rule a filter threw away was invisible to every number here. The current version's dropped candidates, from
    # the run whose drafts are current, sampled by chapter x drop reason - with the rules THAT run kept (critic M51-1:
    # they used to come from state_rules, older runs' rows included).
    dropped = pd.DataFrame(columns=DROP_COLS + DROP_SCORE_COLS)
    if not spark.catalog.tableExists(T_DROP):
        print(f"DROPPED: {T_DROP} does not exist (no run persisted by 05 yet, or no run dropped a candidate) - the sheet "
              "is empty")
    else:
        dp, drep = quality.current_run_rows(spark.table(T_DROP).toPandas(), CUR, LATEST)
        dp["chapter"] = dp["chapter"].astype(str)
        n_norun = int(dp["chapter"].isin(list(NO_RUN_ROWS)).sum())
        dp = dp[~dp["chapter"].isin(list(NO_RUN_ROWS))]          # the rules their run kept are unknown (see above)
        dp["drop_class"] = [quality.drop_reason_class(r, p) for r, p in
                            zip(dp["drop_reason"], dp["post_checks"] if "post_checks" in dp.columns else [None] * len(dp))]
        n_dup = int((dp["drop_class"] == "duplicate").sum())
        if not INCLUDE_DUPLICATES:
            dp = dp[dp["drop_class"] != "duplicate"]
        kept = (run_pop.groupby("section_id").agg(rules_kept_text=("statement", lambda x: "\n".join(f"- {t}" for t in x)))
                .reset_index() if len(run_pop) else pd.DataFrame(columns=["section_id", "rules_kept_text"]))
        dp = (dp.merge(secs[["section_id", "doc_hash", "section_text"]], on=["section_id", "doc_hash"], how="left")
              .merge(kept, on="section_id", how="left"))
        dropped = quality.stratified_sample(dp, ["chapter", "drop_class"], N_DROPPED_PER_STRATUM, SEED,
                                            key=["run_id", "section_id", "drop_reason", "verbatim_quote", "predicate"])
        dropped["sample_id"], dropped["population"], dropped["corpus_version"] = SAMPLE_ID, POPULATION, CORPUS_VERSION
        for c in DROP_COLS:
            if c not in dropped.columns:
                dropped[c] = None
        for c in DROP_SCORE_COLS:
            dropped[c] = None
        for c in ("section_text", "rules_kept_text", "verbatim_quote", "statement", "drop_reason"):
            dropped[c] = dropped[c].map(quality.clip_text)
        print(f"DROPPED: {len(dropped):,} of {len(dp):,} dropped candidate(s) of the current versions sampled (left out: "
              f"{drep['other_doc_version']:,} of other document versions, {drep['older_run']:,} of older runs"
              + (f", {n_norun:,} of chapter(s) without run rows" if n_norun else "")
              + (f", {n_dup:,} copies of a kept draft (INCLUDE_DUPLICATES = False)" if n_dup and not INCLUDE_DUPLICATES
                 else "") + "):")
        if len(dropped):
            display(dropped.groupby(["stratum", "stratum_size"]).size().reset_index(name="sampled"))

    # 2026-10-04 (follow-up to critic M51-3): the run each sampled chapter's numbers describe - its LATEST successful run
    # (policy_extraction_log; else the run sampled from policy_extraction_drafts) - as one canonical text on every row of
    # every sheet. v03 judges a bar only while these are still the latest runs: re-running 04 on the same corpus (another
    # reasoning effort) made an older run's sample read as the engine's current output.
    _sampled = sorted({quality._text(c) for df_ in (rules, recall, dropped) for c in df_["chapter"]} - {""},
                      key=lambda v: (len(v), v))
    SAMPLE_RUNS = quality.sample_runs_text({c: LATEST.get(c) or POP_REPORT["chapters"].get(c) for c in _sampled})
    for df_ in (rules, recall, dropped):
        df_["sample_runs"] = SAMPLE_RUNS
    print(f"sample runs: {SAMPLE_RUNS or 'none (nothing sampled)'}")
    # the README says what this sample is - and what it is NOT (critic M51-1: a chapter left out is named, not dropped)
    readme = pd.concat([README, pd.DataFrame({"how to score": [
        f"THIS SAMPLE: {SAMPLE_ID}; population {POPULATION}"
        + (" (the drafts of the latest successful run of each chapter's current document version: "
           + (", ".join(f"chapter {c} run {r}" for c, r in POP_REPORT["chapters"].items()) or "none") + ")"
           if not STATUSES else f" (state_rules rows with review_status in {STATUSES})") + f"; {corpus_line}; "
        f"latest run of each sampled chapter {SAMPLE_RUNS}."]
        + ([f"NOTE: {NO_RUN_TEXT}."] if NO_RUN_TEXT else [])})], ignore_index=True)
    os.makedirs(OUT_DIR, exist_ok=True)
    EXPORT_PATH = quality.xlsx_write_sheets(
        {"README": readme, "RULES": rules[RULE_COLS + RULE_SCORE_COLS], "RECALL": recall[SEC_COLS + SEC_SCORE_COLS],
         "DROPPED": dropped[DROP_COLS + DROP_SCORE_COLS]},
        f"{OUT_DIR}/v01_extraction_sample_{SAMPLE_ID}.xlsx")
    print(f"\nwrote {EXPORT_PATH}\nNext: an expert fills it; then set SCORED_WORKBOOK to its path (EXPORT = False) and re-run.")

# COMMAND ----------

# MAGIC %md ## Phase 2 — ingest the scored workbook

# COMMAND ----------

metrics = pd.DataFrame()
if not SCORED_WORKBOOK:
    print("SCORED_WORKBOOK is None - nothing to ingest. Extraction precision, fidelity, recall and filter loss remain "
          "UNMEASURED until a scored workbook is ingested.")
elif not os.path.exists(SCORED_WORKBOOK):
    print(f"SCORED_WORKBOOK {SCORED_WORKBOOK} does not exist - nothing ingested. Extraction quality remains UNMEASURED.")
else:
    book = quality.xlsx_read_sheets(SCORED_WORKBOOK)
    missing = [sh for sh in ("RULES", "RECALL") if sh not in book]
    assert not missing, f"workbook lacks sheet(s) {missing}"
    rs, ss, ds = book["RULES"], book["RECALL"], book.get("DROPPED")
    for sh, df, need in (("RULES", rs, RULE_COLS + RULE_SCORE_COLS), ("RECALL", ss, SEC_COLS + SEC_SCORE_COLS),
                         ("DROPPED", ds, DROP_COLS + DROP_SCORE_COLS)):
        if df is None:
            continue
        lost = [c for c in need if c not in df.columns and c not in ADDED_2026_10_04.get(sh, ())
                and c not in ADDED_M51.get(sh, ())]
        assert not lost, f"sheet {sh} lost column(s) {lost} - re-export rather than editing the layout"
    older = [f"{sh}.{c}" for sh, cols in ADDED_2026_10_04.items() for c in cols if c not in book[sh].columns]
    if older or ds is None:
        lacks = older + ([] if ds is not None else ["DROPPED sheet"])
        print(f"NOTE: this workbook was exported before 2026-10-04 (no {', '.join(lacks)}). "
              + ("Its RULES sample left rejected drafts out and showed reviewers' predicates, so its precision is NOT the "
                 "engine's own before review, and no executable-rule precision is computed from it. "
                 if "RULES.predicate_type" in older else "")
              + ("Recall is NOT computed from it (the old formula counted every draft, wrong ones included, as found). "
                 if "RECALL.real_rules_found" in older else "")
              + ("Filter loss is not measured (no DROPPED sheet). " if ds is None else "")
              + "Re-export to measure them.")
    # 2026-10-04 (critic M51-3): the sample's stamps travel into every metric row; without them v03 judges no bar
    # ... and the run of each sampled chapter (follow-up, same day): v03 judges a bar only while those runs are the latest
    unstamped = [sh for sh, df in (("RULES", rs), ("RECALL", ss), ("DROPPED", ds)) if df is not None and len(df)
                 and not all(c in df.columns and df[c].notna().any()
                             for c in ("population", "corpus_version", "sample_runs"))]
    if unstamped:
        print(f"NOTE: sheet(s) {', '.join(unstamped)} lack a population / corpus_version / sample_runs stamp (exported "
              "before the 2026-10-04 critic-M51 fixes): their metrics are stored without it, and v03 judges no bar on "
              "them.")
    stamps = {(sh, c): sorted({str(v) for v in df[c].dropna()}) for sh, df in (("RULES", rs), ("RECALL", ss),
                                                                             ("DROPPED", ds))
              if df is not None for c in ("population", "corpus_version", "sample_runs") if c in df.columns}
    for (sh, c), vals in stamps.items():
        print(f"  {sh}.{c}: {', '.join(vals) or '(blank)'}" + ("  <- MIXED: rows of different samples" if len(vals) > 1
                                                                 else ""))
    sid = str(rs["sample_id"].dropna().iloc[0]) if rs["sample_id"].notna().any() else str(ss["sample_id"].dropna().iloc[0])
    if spark.catalog.tableExists(T_METRICS) and not REINGEST:
        done = spark.table(T_METRICS).where(F.col("sample_id") == sid).count()
        assert done == 0, f"sample {sid} was already ingested ({done} metric rows). Set REINGEST = True to add it again."
    for sh, df in (("RULES", rs), ("DROPPED", ds)):
        if df is None:
            continue
        bad = df[df["is_real_rule"].map(quality._yn).isna() & df["is_real_rule"].notna()]
        if len(bad):
            print(f"  {len(bad)} {sh} row(s) have an is_real_rule value that is not Y/N - treated as blank: "
                  f"{sorted(bad['is_real_rule'].astype(str).unique())[:5]}")
    for c in ("real_rules_found", "missed_rules", "rules_extracted"):
        if c in ss.columns:
            # 2026-10-04 (critic M51-7): a decimal ("0.5", "2.9") is no longer truncated to a count - it is blank, and
            # named here
            bad = ss[ss[c].map(quality._int_or_none).isna() & ss[c].map(lambda v: not quality._is_blank(v))]
            if len(bad):
                print(f"  {len(bad)} RECALL row(s) have a {c} that is not a whole number >= 0 - treated as blank: "
                      f"{sorted(bad[c].astype(str).unique())[:5]}")
    if "rules_extracted" in ss.columns and "real_rules_found" in ss.columns:
        no_ext = ss[ss["rules_extracted"].map(quality._int_or_none).isna()
                    & ss["real_rules_found"].map(quality._int_or_none).notna()]
        if len(no_ext):
            print(f"  {len(no_ext)} RECALL row(s) have no rules_extracted to check real_rules_found against - excluded "
                  "from recall")
    metrics = quality.extraction_metrics(rs, ss, ds)
    now = pd.Timestamp.now().isoformat(timespec="seconds")
    metrics["sample_id"], metrics["computed_at"] = sid, now
    # every metric column (quality.METRIC_COLUMNS: unscored, scored_units, population, corpus_version ...), notes last
    metrics = metrics[quality.METRIC_COLUMNS[:-1] + ["sample_id", "computed_at", "notes"]]
    display(metrics)

    # raw scores of every sheet, `sheet` saying which (kind is kept for rows ingested before 2026-10-04)
    parts = [rs.assign(kind="rule", sheet="RULES"), ss.assign(kind="section", sheet="RECALL")]
    if ds is not None:
        parts.append(ds.assign(kind="dropped", sheet="DROPPED"))
    raw = pd.concat(parts, ignore_index=True, sort=False)
    raw["sample_id"], raw["ingested_at"], raw["workbook"] = sid, now, SCORED_WORKBOOK
    raw = raw.drop(columns=["section_text"], errors="ignore")         # the text lives in policy_sections
    kb_io.write_table(spark, metrics, T_METRICS, mode="append")
    kb_io.write_table(spark, quality.as_text_frame(raw), T_SCORES, mode="append")

# COMMAND ----------

# MAGIC %md ## Against the pass marks

# COMMAND ----------

if len(metrics):
    for m, target, unit in (("executable_rule_precision", EXEC_PRECISION_TARGET, "scored compiled-type rules"),
                            ("extraction_recall", RECALL_TARGET, "rules in scored sections"),
                            ("extraction_fidelity", FIDELITY_TARGET, "scored real rules")):
        rows = metrics[metrics["metric"] == m].to_dict("records")
        pooled = [r for r in rows if r["scope"] == "all"]
        # the same verdict as v03 (lower bound, and no more than MAX_UNSCORED_SHARE of the drawn units unscored) ...
        ok, why = quality.lower_bound_bar(pooled[0] if pooled else None, target, unit,
                                          missing="UNMEASURED (n=0)" + (f": {pooled[0]['notes']}" if pooled else ""))
        pop = (pooled[0].get("population") if pooled else None) or "(not recorded)"
        print(f"{m} [all]: {why}" + ("" if not pooled or not pooled[0]["n"] else
                                     f" -> {'MEETS' if ok else 'does NOT meet'} the bar (lower bound >= {target:.2f})")
              # ... which v03 applies only to the engine's own sample of the current corpus (critic M51-3)
              + ("" if pop == quality.ENGINE_POPULATION else
                 f" [population {pop}: v03 judges no bar on this sample]"))
        for r in rows:
            if r["scope"] != "all":
                print(f"    [{r['scope_type']} {r['scope']}]: " + ("UNMEASURED (n=0)" if r["n"] == 0 else
                      f"{r['value']:.3f} (95% CI {r['ci_low']:.3f}-{r['ci_high']:.3f}, n={r['n']})"))
    for m in ("extraction_precision", "extraction_filter_loss"):
        for r in metrics[metrics["metric"] == m].to_dict("records"):
            print(f"{m} [{r['scope_type']} {r['scope']}]: " + ("UNMEASURED (n=0)" if r["n"] == 0 else
                  f"{r['value']:.3f} (95% CI {r['ci_low']:.3f}-{r['ci_high']:.3f}, n={r['n']})"))
    print("Pass marks are judged on the POOLED number (per-chapter numbers are shown); v03 judges the same bars. Precision "
          "over every draft and filter loss carry no pass mark: they say where the engine loses quality.")
