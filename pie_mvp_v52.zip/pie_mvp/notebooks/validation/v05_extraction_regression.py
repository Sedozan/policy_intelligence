# Databricks notebook source
# MAGIC %md
# MAGIC # v05 · Extraction regression — a new run against the SIGNED review decisions
# MAGIC
# MAGIC **What this answers:** before a new extraction run (new prompt, model, reasoning effort or post-check change) replaces
# MAGIC the current one, does it reproduce what reviewers signed — and does it propose anything that would flag a claim the signed
# MAGIC rule does not? Per chapter: **recall** (signed rules + reviewer-listed missed rules the run found), **precision**,
# MAGIC **exact match** of the predicate, and **DANGER** — drafts that compile where the signed rule does not, or compile wider
# MAGIC (other codes, a code pair REVERSED — the finding would sit on the other line —, a lower threshold, a longer period,
# MAGIC `member_day` where the signed pair is `member_provider_day`, a missing age, an earlier start, a missing exception label
# MAGIC ...). **Ship gate: DANGER == 0 and no new executable draft without a reviewed decision** (`unmatched_compiled == 0`: a
# MAGIC draft that would compile and that no signed decision covers is a risk DANGER cannot see — including a second, different
# MAGIC reading of a signed rule's sentence, `unreviewed_variant` — adjudicate it, then score the run again; 2026-10-04, critic
# MAGIC M51-5).
# MAGIC
# MAGIC **A/B** (`RUN_DIR_B`): a second run — e.g. reasoning_effort `low` (`RUN_ID`) vs `medium` (`RUN_DIR_B`) — compared on
# MAGIC the SAME gold over the chapters BOTH runs extracted: one row per run (drafts, recall, exact match, precision, DANGER,
# MAGIC unreviewed executable drafts). That table is a **comparison, not a gate**: each run's own ship gate is scored on ALL the
# MAGIC chapters that run extracted (05 persists a whole run folder) against the decisions bound to its own document versions,
# MAGIC exactly as if it were scored alone, and reported next to it (2026-10-04, critic M51-4: the A/B used to narrow run A's
# MAGIC gate to the shared chapters, so an unreviewed executable draft in a chapter run B lacked passed).
# MAGIC Each run's `corpus_version` (the exact document set its `inventory.jsonl` names) is recorded, and
# MAGIC `compared_corpus_version` (the documents of the compared chapters only); a WARNING says when the two runs, or a run and
# MAGIC the gold, rest on different document versions **in the compared chapters** — then the comparison is not like for like.
# MAGIC Documents only one run read, or read outside the comparison, are listed in a separate NOTE (critic M51-10).
# MAGIC
# MAGIC **How it works:** `regress.py` matches each signed rule to the run's drafts by `extraction_key`, then by normalised quote +
# MAGIC compatible codes (one-to-one). Gold comes from `state_rules` (approved = positive with its signed predicate, a fixed rule's
# MAGIC predicate is the reviewer's corrected one; rejected = negative), or from `policy_review_log`, or from a filled review
# MAGIC workbook (its `missed_rules` sheet adds missed rules). **Curated rules** (origin `manual`, the workbook's "hand-authored
# MAGIC seed": written from the manual because the extraction missed them) are *missed* gold, scored on the sentence their
# MAGIC notes quote — a run that finds one can retire it. A Fix is scored with its corrected dates. `danger_date_only` counts the
# MAGIC DANGER rows that only lack a start / end date the decision carries (often from a revision history the sentence does not
# MAGIC state: the decision must carry it).
# MAGIC
# MAGIC **Limits:** only SIGNED decisions are gold (`REQUIRE_SIGNATURE = True`); rules from another document version are excluded
# MAGIC (the text changed) and counted. A draft no signed rule matches is *unknown* (a new rule or a wrong one) — it is listed,
# MAGIC not scored, and if it would compile it blocks the gate. An AI pre-review workbook can be scored with
# MAGIC `REQUIRE_SIGNATURE = False`, but that result is **not signed**.
# MAGIC
# MAGIC Read-only: reads `state_rules` / `policy_review_log` / `policy_document_inventory` and one or two run folders; writes only
# MAGIC an `.xlsx` under `data/validation/`.

# COMMAND ----------

# MAGIC %pip install -q openpyxl

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
import config, policy_docs, extract_io, kb_io, quality, post_checks, regress
for _m in (config, policy_docs, extract_io, kb_io, quality, post_checks, regress):
    importlib.reload(_m)

RUN_ID               = None          # None = the latest folder under config.RUN_ROOT (04_extract_chapters_gpu output)
RUN_DIR_B            = None          # optional SECOND run scored on the SAME gold (an A/B, e.g. reasoning_effort "low" in
                                     # RUN_ID vs "medium" here): a run folder path, or a run id under config.RUN_ROOT
GOLD_SOURCE          = "state_rules" # "state_rules" | "review_log" | "workbook"
GOLD_WORKBOOK        = None          # GOLD_SOURCE = "workbook": path of a filled review workbook (.xlsx)
REQUIRE_SIGNATURE    = True          # only decisions with a reviewer name are gold. False = score an UNSIGNED workbook
INCLUDE_MISSED       = True          # workbook gold: add the 'missed_rules' sheet (rules reviewers said were not extracted)
CURRENT_VERSION_ONLY = True          # exclude gold rows bound to another document version than the run read
CHAPTERS             = None          # the chapters the A/B COMPARISON covers: None = every chapter the run extracted (with
                                     # RUN_DIR_B: every chapter BOTH runs extracted); or e.g. ["10", "19"]. Each run's
                                     # SHIP GATE always covers ALL the chapters it extracted.

# COMMAND ----------

KB = config.KB
OUT_DIR = f"{config.WORKSPACE_DATA_DIR}/validation"
_chapter_order = lambda v: (len(v), v)


def run_chapters_of(r):
    return sorted({str(x["chapter"]) for x in r["inventory"]} | {str(d["chapter"]) for d in r["drafts"]}, key=_chapter_order)


run_dir = os.path.join(config.RUN_ROOT, RUN_ID) if RUN_ID else extract_io.latest_run_dir(config.RUN_ROOT)
assert run_dir and os.path.isdir(run_dir), f"no run folder under {config.RUN_ROOT}"
run = extract_io.read_run(run_dir)
man = run["manifest"]
drafts_all = run["drafts"]                    # run A's ship gate is scored on ALL of them (critic M51-4)
run_chapters = run_chapters_of(run)
# the document version each chapter was extracted from: gold bound to another version cannot be compared
run_hash = {str(r["chapter"]): r["doc_hash"] for r in run["inventory"]}
# 2026-10-04 (external review): "recall 0.92" means nothing without the exact document set it was measured on
CORPUS_A = policy_docs.corpus_version(run_hash)

run_b, man_b, drafts_b_all, run_dir_b, run_hash_b, CORPUS_B, run_chapters_b = None, {}, None, None, {}, None, []
if RUN_DIR_B:
    run_dir_b = str(RUN_DIR_B) if os.path.isdir(str(RUN_DIR_B)) else os.path.join(config.RUN_ROOT, str(RUN_DIR_B))
    assert os.path.isdir(run_dir_b), f"RUN_DIR_B {RUN_DIR_B!r} is not a run folder (a path, or a run id under {config.RUN_ROOT})"
    assert os.path.abspath(run_dir_b) != os.path.abspath(run_dir), "RUN_DIR_B is run A's own folder"
    run_b = extract_io.read_run(run_dir_b)
    man_b, drafts_b_all = run_b["manifest"], run_b["drafts"]
    run_chapters_b = run_chapters_of(run_b)
    run_hash_b = {str(r["chapter"]): r["doc_hash"] for r in run_b["inventory"]}
    CORPUS_B = policy_docs.corpus_version(run_hash_b)

# the chapters the A/B COMPARISON covers - never the gate (2026-10-04, critic M51-4: narrowing run A's gate to the chapters
# run B also extracted let an unreviewed executable draft in a chapter B lacked through). Each run's gate: all its chapters.
if CHAPTERS:
    chapters = [str(c) for c in CHAPTERS]
elif run_b is not None:
    # an A/B compares the chapters BOTH runs extracted: a chapter only one run read would count as missed by the other
    chapters = [c for c in run_chapters if c in set(run_chapters_b)]
    _one = sorted(set(run_chapters) ^ set(run_chapters_b), key=_chapter_order)
    if _one:
        print(f"A/B comparison on the {len(chapters)} chapter(s) both runs extracted; outside the comparison (extracted "
              f"by one run only): {_one} - each run's ship gate still covers its own")
else:
    chapters = run_chapters
drafts = [d for d in drafts_all if str(d["chapter"]) in chapters]                    # compared
drafts_b = [d for d in drafts_b_all if str(d["chapter"]) in chapters] if drafts_b_all is not None else None
print(f"run A {man.get('run_id')} | prompt {man.get('prompt_version')} | backend {man.get('backend')} | reasoning "
      f"{man.get('reasoning')} | finished={man.get('finished')} | {len(drafts_all)} drafts in chapters {run_chapters} "
      f"({len(drafts)} in the compared chapter(s) {chapters}) | {CORPUS_A}")
if run_b is not None:
    print(f"run B {man_b.get('run_id')} | prompt {man_b.get('prompt_version')} | backend {man_b.get('backend')} | reasoning "
          f"{man_b.get('reasoning')} | finished={man_b.get('finished')} | {len(drafts_b_all)} drafts in chapters "
          f"{run_chapters_b} ({len(drafts_b)} compared) | {CORPUS_B}")

# COMMAND ----------

# MAGIC %md ## Gold: the signed decisions

# COMMAND ----------

if GOLD_SOURCE == "state_rules":
    sr = kb_io.table_or_none(spark, config.STATE_RULES_TABLE)
    assert sr is not None, f"{config.STATE_RULES_TABLE} does not exist - nothing has been reviewed yet"
elif GOLD_SOURCE == "review_log":
    sr = kb_io.table_or_none(spark, config.STATE_RULES_TABLE)
    log = kb_io.table_or_none(spark, f"{KB}.policy_review_log")
    assert sr is not None and log is not None, "state_rules or policy_review_log does not exist"
elif GOLD_SOURCE == "workbook":
    assert GOLD_WORKBOOK and os.path.exists(GOLD_WORKBOOK), f"GOLD_WORKBOOK {GOLD_WORKBOOK!r} not found"
    gold_book = quality.xlsx_read_sheets(GOLD_WORKBOOK)
else:
    raise ValueError(f"unknown GOLD_SOURCE {GOLD_SOURCE!r}")


def gold_for(hashes):
    """(the signed decisions, report) - with CURRENT_VERSION_ONLY, only those bound to the document versions a run read
    (`hashes` {chapter: doc_hash}): each run is judged against the decisions made on the text it read."""
    rep_ = {}
    if GOLD_SOURCE == "state_rules":
        return regress.gold_from_state_rules(sr, hashes if CURRENT_VERSION_ONLY else None,
                                             require_reviewer=REQUIRE_SIGNATURE, report=rep_), rep_
    if GOLD_SOURCE == "review_log":
        g_ = regress.gold_from_review_log(log, sr, require_reviewer=REQUIRE_SIGNATURE, report=rep_)
    else:
        g_ = regress.gold_from_workbook(gold_book, require_reviewer=REQUIRE_SIGNATURE, include_missed=INCLUDE_MISSED,
                                        report=rep_)
    if CURRENT_VERSION_ONLY:
        before = len(g_)
        g_ = [g for g in g_ if not hashes.get(g["chapter"]) or not g["doc_hash"] or g["doc_hash"] == hashes[g["chapter"]]]
        rep_.setdefault("excluded", {})["other_doc_version"] = before - len(g_)
    return g_, rep_


gold_v, rep = gold_for(run_hash)                      # bound to run A's document versions
gold_a = [g for g in gold_v if g["chapter"] in run_chapters]          # run A's ship gate: every chapter it extracted
gold = [g for g in gold_v if g["chapter"] in chapters]                # the A/B comparison: the compared chapters
gold_b = rep_b = None
if run_b is not None:                                 # run B's ship gate: its chapters, decisions bound to ITS versions
    gold_b, rep_b = gold_for(run_hash_b)
    gold_b = [g for g in gold_b if g["chapter"] in run_chapters_b]
kinds = pd.Series([g["kind"] for g in gold_a]).value_counts().to_dict() if gold_a else {}
print(f"gold from {GOLD_SOURCE}: {len(gold_a)} rows for run A's chapters {kinds} ({len(gold)} in the compared chapters) | "
      f"excluded {rep.get('excluded')}"
      + (f" | run B: {len(gold_b)} rows bound to its document versions" if gold_b is not None else ""))
if not REQUIRE_SIGNATURE:
    print("NOTE: REQUIRE_SIGNATURE = False - unsigned decisions are scored. This result is a measurement, NOT a signed gate.")
if not gold_a:
    print("No signed decisions for run A's chapters: recall / precision / DANGER are UNMEASURED, and every draft that would "
          "compile is an unreviewed executable draft (the gate fails).")

# what the gold rests on: the document version each chapter's signed rows were decided against (rows without one - curated
# rules, workbook missed_rules - are not bound to a version)
_gold_versions = {}
for g in gold:
    if g.get("doc_hash"):
        _gold_versions.setdefault(g["chapter"], set()).add(g["doc_hash"])
gold_hash = {c: next(iter(h)) for c, h in _gold_versions.items() if len(h) == 1}
CORPUS_GOLD = policy_docs.corpus_version(gold_hash)
# 2026-10-04 (critic M51-10): the A/B is like for like when the runs read the same documents IN THE COMPARED CHAPTERS - the
# warning used to compare the whole inventories, so a chapter only one run extracted (and that is not compared) raised it.
# Documents outside the comparison are listed apart, as a NOTE.
_cmp_a = {c: run_hash[c] for c in chapters if run_hash.get(c)}
_cmp_b = {c: run_hash_b[c] for c in chapters if run_hash_b.get(c)}
COMPARED_CORPUS_A = policy_docs.corpus_version(_cmp_a)
COMPARED_CORPUS_B = policy_docs.corpus_version(_cmp_b) if run_b is not None else None
CORPUS_WARNINGS, CORPUS_NOTES = [], []
if run_b is not None:
    _diff = quality.corpus_differences(_cmp_a, _cmp_b, "A", "B")
    if _diff:
        CORPUS_WARNINGS.append(f"runs A and B rest on different corpus versions in the compared chapter(s) "
                               f"({COMPARED_CORPUS_A} vs {COMPARED_CORPUS_B}): " + "; ".join(_diff[:12]))
    _rest = quality.corpus_differences({c: h for c, h in run_hash.items() if c not in chapters},
                                       {c: h for c, h in run_hash_b.items() if c not in chapters}, "A", "B")
    if _rest:
        CORPUS_NOTES.append(f"outside the comparison (not compared; each run's own gate covers them): "
                            + "; ".join(_rest[:12]) + f" - whole runs: {CORPUS_A} vs {CORPUS_B}")
for _label, _hashes in (("A", run_hash), ("B", run_hash_b if run_b is not None else None)):
    if _hashes is None:
        continue
    _diff = [c for c in chapters if c in gold_hash and _hashes.get(c) and _hashes[c] != gold_hash[c]]
    if _diff:
        CORPUS_WARNINGS.append(f"the gold rests on another document version than run {_label} in chapter(s) "
                               f"{', '.join(_diff)}: its decisions were made on other text, so those chapters do not "
                               f"compare like for like")
_mixed = sorted((c for c, h in _gold_versions.items() if len(h) > 1), key=_chapter_order)
if _mixed:
    CORPUS_WARNINGS.append(f"the gold mixes document versions in chapter(s) {', '.join(_mixed)} "
                           f"(CURRENT_VERSION_ONLY = {CURRENT_VERSION_ONLY})")
print(f"corpus: run A {CORPUS_A}" + (f" | run B {CORPUS_B}" if run_b is not None else "")
      + f" | gold {CORPUS_GOLD} (over the {len(gold_hash)} chapter(s) its signed rows are bound to)")
for _w in CORPUS_WARNINGS:
    print("WARNING: " + _w)
for _n in CORPUS_NOTES:
    print("NOTE: " + _n)

# COMMAND ----------

# MAGIC %md ## Compare and gate

# COMMAND ----------

# 2026-10-04 (critic M51-4): run A's SHIP GATE is scored on ALL the chapters run A extracted - the run folder 05 would
# persist - against the decisions bound to its own document versions, exactly as if it were scored alone. The A/B below
# compares chapters both runs extracted and is never the gate.
# no gold = nothing signed: compare() then counts every draft that would compile as an unreviewed executable draft
summary, detail = regress.compare(gold_a, drafts_all)
cols = ["chapter", "gold_positive", "gold_negative", "drafts", "tp", "tp_missed", "fn_positive", "fn_missed", "recall",
        "recall_missed", "precision_known", "precision_lb", "exact", "exact_rate", "matched_reject", "duplicate", "unmatched",
        "unmatched_compiled", "lost_executable", "danger", "danger_date_only"]
summary_df = pd.DataFrame(regress.summary_rows(summary))
summary_df = summary_df[[c for c in cols if c in summary_df.columns]]
display(summary_df)
detail_df = pd.DataFrame(detail)
ok, why = regress.ship_gate(summary)
GATE_LABEL = "SHIP GATE" if REQUIRE_SIGNATURE else "GATE (UNSIGNED)"
print(f"{GATE_LABEL} (run A, all {len(run_chapters)} chapter(s) it extracted: {', '.join(run_chapters)}): {why}")
summary_b = detail_b = summary_b_df = detail_b_df = None
ok_b = why_b = None
if run_b is not None:                                 # run B's own gate, the same way
    summary_b, detail_b = regress.compare(gold_b, drafts_b_all)
    summary_b_df = pd.DataFrame(regress.summary_rows(summary_b))
    summary_b_df = summary_b_df[[c for c in cols if c in summary_b_df.columns]]
    detail_b_df = pd.DataFrame(detail_b)
    ok_b, why_b = regress.ship_gate(summary_b)
    print(f"{GATE_LABEL} (run B, all {len(run_chapters_b)} chapter(s) it extracted: {', '.join(run_chapters_b)}): {why_b}")

# COMMAND ----------

# MAGIC %md ## A/B — both runs on the same gold (`RUN_DIR_B`): a comparison, not a gate

# COMMAND ----------

labels = (f"A {man.get('run_id') or os.path.basename(os.path.normpath(run_dir))} (reasoning {man.get('reasoning') or '?'})",
          f"B {man_b.get('run_id') or os.path.basename(os.path.normpath(run_dir_b or 'B'))} "
          f"(reasoning {man_b.get('reasoning') or '?'})")
# the numbers: both runs on the SAME gold over the compared chapters; ship_gate / ship_gate_reason: each run's OWN gate
runs_df = pd.DataFrame(regress.compare_runs(gold, drafts, drafts_b, labels=labels, gates=[(ok, why), (ok_b, why_b)]))
_meta = [(run_dir, man, CORPUS_A, COMPARED_CORPUS_A, run_chapters)] + (
    [(run_dir_b, man_b, CORPUS_B, COMPARED_CORPUS_B, run_chapters_b)] if run_b is not None else [])
for _i, (_c, _vals) in enumerate((("corpus_version", [m[2] for m in _meta]),
                                  ("compared_corpus_version", [m[3] for m in _meta]),
                                  ("compared_chapters", [", ".join(chapters)] * len(_meta)),
                                  ("gate_chapters", [", ".join(m[4]) for m in _meta]),
                                  ("prompt_version", [m[1].get("prompt_version") for m in _meta]),
                                  ("backend", [m[1].get("backend") for m in _meta]),
                                  ("reasoning", [m[1].get("reasoning") for m in _meta]),
                                  ("run_folder", [m[0] for m in _meta]))):
    runs_df.insert(1 + _i, _c, _vals)
if run_b is not None:
    print(f"A/B on chapter(s) {', '.join(chapters)}, both runs on the same gold - a comparison, not a gate (ship_gate is "
          f"each run's own gate over all the chapters it extracted):")
display(runs_df)
if run_b is not None:
    for r in runs_df.to_dict("records"):
        print(f"{r['run']}: {r['ship_gate_reason']}")
    if CORPUS_WARNINGS:
        print("The runs or the gold rest on different document versions (see the WARNINGs above): read the A/B with that in "
              "mind.")
else:
    print("RUN_DIR_B is None - one run only (set it to compare two runs on the same gold).")

# COMMAND ----------

# MAGIC %md ## What to look at first

# COMMAND ----------

if len(detail_df):
    dang = detail_df[detail_df["danger"]]
    print(f"{len(dang)} DANGER row(s): a draft that, approved as extracted, would flag claims the signed rule does not")
    if len(dang):
        display(dang[["chapter", "result", "gold_id", "rule_id", "danger_reasons", "gold_predicate", "draft_predicate",
                      "gold_quote"]])
    lost = detail_df[detail_df["result"] == "missed_again"]
    print(f"{len(lost)} signed / missed rule(s) the run did not produce (recall loss):")
    if len(lost):
        display(lost[["chapter", "kind", "gold_id", "gold_predicate", "gold_quote"]])
    # unreviewed_variant: another reading of a signed rule's text (critic M51-5) - unreviewed like a new rule
    new = detail_df[detail_df["result"].isin(["unknown_new_rule", "unreviewed_variant"])]
    print(f"{len(new)} draft(s) no signed decision covers (new, wrong, or another reading of a signed rule - review them "
          f"like any draft); {summary['total'].get('unmatched_compiled', 0)} of them would compile and block the gate "
          f"until adjudicated")

# COMMAND ----------

# MAGIC %md ## Export (read-only otherwise)

# COMMAND ----------

os.makedirs(OUT_DIR, exist_ok=True)
stamp = pd.Timestamp.now().strftime("%Y%m%dT%H%M%S")
readme = pd.DataFrame({"v05 extraction regression": [
    f"run A: {run_dir} (prompt {man.get('prompt_version')}, backend {man.get('backend')}, reasoning {man.get('reasoning')}); "
    f"corpus {CORPUS_A}",
    (f"run B: {run_dir_b} (prompt {man_b.get('prompt_version')}, backend {man_b.get('backend')}, reasoning "
     f"{man_b.get('reasoning')}); corpus {CORPUS_B}" if run_b is not None else "run B: none (RUN_DIR_B = None)"),
    f"gold: {GOLD_SOURCE}{' ' + GOLD_WORKBOOK if GOLD_WORKBOOK else ''}; signed only: {REQUIRE_SIGNATURE}; "
    f"current document version only: {CURRENT_VERSION_ONLY}; excluded: {json.dumps(rep.get('excluded'))}; "
    f"corpus {CORPUS_GOLD} (over the chapters its signed rows are bound to)",
    f"chapters compared (A/B): {', '.join(chapters)}",
    "corpus warnings: " + (" | ".join(CORPUS_WARNINGS) if CORPUS_WARNINGS else "none (same document versions)"),
    "corpus notes: " + (" | ".join(CORPUS_NOTES) if CORPUS_NOTES else "none"),
    f"gate (run A, all its chapters: {', '.join(run_chapters)}): {why}",
    (f"gate (run B, all its chapters: {', '.join(run_chapters_b)}): {why_b}" if run_b is not None else "gate (run B): -"),
    "summary: one row per chapter + TOTAL - run A scored on ALL its chapters (its gate); summary_B: run B the same way. "
    "recall = (signed + missed rules found) / (signed + missed rules); precision_known = found / drafts the gold can judge; "
    "precision_lb counts unmatched drafts as wrong; unmatched_compiled = drafts that would compile and that no signed "
    "decision covers (they block the gate).",
    "runs: the A/B - one row per run on the same gold over the compared chapters (regress.compare_runs): a comparison, "
    "not a gate; ship_gate / ship_gate_reason are each run's own gate over gate_chapters; corpus_version = the run's "
    "whole document set, compared_corpus_version = the compared chapters' documents.",
    "detail: one row per gold / draft pairing. result = exact | changed | resurrected_reject | duplicate | "
    "unreviewed_variant | missed_again | reject_not_reproduced | unknown_new_rule; danger_reasons says why a draft is "
    "wider (a reversed pair flags the other line); unreviewed_variant = another reading of a signed rule's text, "
    "counted as unmatched.",
]})
sheets = {"README": readme, "summary": summary_df, "runs": runs_df,
          "detail": quality.as_text_frame(detail_df) if len(detail_df) else detail_df}
if run_b is not None:
    sheets["summary_B"] = summary_b_df
    sheets["detail_B"] = quality.as_text_frame(detail_b_df) if len(detail_b_df) else detail_b_df
_name = (man.get('run_id') or 'run') + (f"_vs_{man_b.get('run_id') or 'B'}" if run_b is not None else "")
path = quality.xlsx_write_sheets(sheets, f"{OUT_DIR}/v05_extraction_regression_{_name}_{stamp}.xlsx")
print(f"wrote {path}")
