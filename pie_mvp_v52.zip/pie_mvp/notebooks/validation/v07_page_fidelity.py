# Databricks notebook source
# MAGIC %md
# MAGIC # v07 · Page fidelity — does what a person sees on a PDF page reach the extractor?
# MAGIC
# MAGIC **What this answers:** on a small gold set of pages — known-ugly pages (tables between headings, code lists,
# MAGIC wrapped headings, multi-page lists, footnotes, multi-column pages) plus random pages of every document for a fair
# MAGIC rate — is the text that reaches the extractor what a person sees on the page: nothing lost, under the right heading,
# MAGIC in an order that keeps its meaning? Sections are built exactly as `04_extract_chapters_gpu` builds them
# MAGIC (`policy_docs.parse_pdf` → `policy_docs.segment`, on the PDFs `03_stage_inputs` staged), so the middle column of the
# MAGIC report is what the model receives.
# MAGIC
# MAGIC **How it works:** two phases.
# MAGIC 1. **EXPORT** (`EXPORT = True`): runs the automatic checks on every page of the documents (no images), picks the
# MAGIC    pages (the seeds + `N_RANDOM_PER_DOC` random pages per document + up to `MAX_FLAGGED` flagged pages) and writes
# MAGIC    `data/validation/v07_page_fidelity_<sample>.html` (page image | text that reached the extractor | automatic flags,
# MAGIC    side by side) and `v07_page_fidelity_<sample>.xlsx`: sheet `GOLD` — fill `page_ok` (Y/N), `missing_text`,
# MAGIC    `misattributed_text`, `notes`, `scorer`; sheet `SCREEN` — the automatic checks on every page.
# MAGIC 2. **INGEST** (`SCORED_WORKBOOK = "<path>"`): reads the filled sheet, computes `page_text_fidelity` = pages scored Y /
# MAGIC    pages scored, with its 95% interval, and appends it to `policy_quality_metrics`. Every row's notes state the
# MAGIC    `corpus_version` the pages were drawn from (`policy_docs.corpus_version` of the documents checked). A malformed
# MAGIC    sheet is refused with an error (`page_fidelity.check_gold`): a page scored twice, a blank or mixed `corpus_version`,
# MAGIC    mixed `sample_id`s.
# MAGIC
# MAGIC **Automatic checks** (hints for the scorer, not the score): `code_missing` — a code on the page that reaches the
# MAGIC extractor nowhere; `code_list_split` — one code list cut into two sentences by the splitter grounding uses;
# MAGIC `later_heading` — page text given to a section whose heading comes later (a table between two headings goes to the
# MAGIC second), or a table's row copy under another heading than the one open where the table starts; `row_order` — lines
# MAGIC with 2+ codes out of the page's top-to-bottom order; `heading_in_table` — a table cell taken for a section heading;
# MAGIC `text_missing` — a body line in no section.
# MAGIC
# MAGIC **Limits:** the fair rate is `sample = random`, each document weighted by its page count
# MAGIC (`quality.stratified_ratio`, with its interval: the same number of random pages is drawn from every document, so a
# MAGIC pooled rate would let a page of a 3-page exhibit count as much as 20 pages of a 60-page chapter); seed and flagged
# MAGIC pages are picked because they are hard. The checks cannot judge meaning — a borderless table read column by column,
# MAGIC two columns read across, a footnote read mid-sentence, a lead-in sentence cut off from its list: the person scoring
# MAGIC decides. A table ruled with horizontal lines only is invisible to the PDF reader's table finder (read as plain
# MAGIC lines). Until a scored sheet is ingested, **page text fidelity is unmeasured**.
# MAGIC
# MAGIC Read-only: reads the staged PDFs; writes the two files under `data/validation/` and (INGEST only) appends to
# MAGIC `policy_quality_metrics`.

# COMMAND ----------

# MAGIC %pip install -q pymupdf openpyxl

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib
import pandas as pd
import config, kb_io, quality, policy_docs, page_fidelity
for _m in (config, kb_io, quality, policy_docs, page_fidelity):
    importlib.reload(_m)

EXPORT           = True          # phase 1: check the pages, write the HTML report and the gold sheet
DOCS             = None          # None = every document in config.CHAPTERS whose PDF is staged; or e.g. ["10", "19", "22-1"]
SEED_PAGES       = page_fidelity.SEED_PAGES   # known-ugly pages: [{"doc_id", "pages": [..] | "all" | "tables", "reason"}]
N_RANDOM_PER_DOC = 2             # random pages per document - the FAIR rate (seeded hash: same documents + seed = same pages)
SEED             = 20261004
SCREEN_ALL_PAGES = True          # run the automatic checks on every page of DOCS (no images) -> SCREEN sheet
MAX_FLAGGED      = 15            # flagged pages not already picked that are added to the report, most flags first; 0 = none
ONLY_CANDIDATES  = True          # as in 04: a section without a rule signal never reaches the model
DPI              = 100           # page image resolution in the HTML
PDF_DIR          = config.STAGE_PDF_DIR       # where 03_stage_inputs put the PDFs; 04 reads them from here
SCORED_WORKBOOK  = None          # phase 2: path of the filled workbook; None = skip ingest
REINGEST         = False         # True = ingest a sample_id that was already ingested (adds a second set of rows)

# COMMAND ----------

KB = config.KB
OUT_DIR = f"{config.WORKSPACE_DATA_DIR}/validation"
T_METRICS = f"{KB}.policy_quality_metrics"
SAMPLE_ID = f"v07-{pd.Timestamp.now().strftime('%Y%m%d')}-s{SEED}"

# COMMAND ----------

# MAGIC %md ## Phase 1 — the documents, as 04 reads them

# COMMAND ----------

docs = {}
if EXPORT:
    want = [str(d) for d in DOCS] if DOCS else list(config.CHAPTERS)
    not_staged = []
    for d in want:
        path = page_fidelity.pdf_path(d, PDF_DIR)          # 04's path: <PDF_DIR>/<file name of the chapter's URL>
        if not os.path.exists(path):
            not_staged.append(d)
            continue
        docs[d] = page_fidelity.load_document(d, path, only_candidates=ONLY_CANDIDATES)
        m = docs[d]["meta"]
        print(f"  doc {d:>4}  {m['pages']:>3} pages  {m['sections']:>3} sections ({m['candidate_sections']} reach the model)  "
              f"{docs[d]['doc_hash'][:12]}  {os.path.basename(path)}")
    if not_staged:
        print(f"not staged in {PDF_DIR} (skipped): {not_staged}")
    if not docs:
        raise RuntimeError(f"no staged PDF in {PDF_DIR} for {want}. Run 03_stage_inputs first (or set PDF_DIR / DOCS).")
    stage = policy_docs.read_stage_manifest(PDF_DIR)
    staged = {d: e.get("doc_hash") for d, e in (stage.get("files") or {}).items()}
    changed = [d for d, doc in docs.items() if staged.get(d) not in (None, doc["doc_hash"])]
    if changed:
        print(f"NOTE: the PDF of {changed} differs from the one 03 recorded in the stage manifest - this checks the file on disk")
    # the exact document set the pages are drawn from: a rate means nothing without its denominator
    CORPUS_VERSION = policy_docs.corpus_version({d: doc["doc_hash"] for d, doc in docs.items()})
    print(f"corpus {CORPUS_VERSION}: {len(docs)} document(s)")

# COMMAND ----------

# MAGIC %md ## Screen every page (automatic checks, no images)

# COMMAND ----------

screen = pd.DataFrame(columns=["doc_id", "page", "n_flags", *page_fidelity.CHECKS, "codes_missing", "detail"])
if EXPORT and SCREEN_ALL_PAGES:
    screen = pd.concat([page_fidelity.screen(doc) for doc in docs.values()], ignore_index=True)
    flagged = screen[screen["n_flags"] > 0]
    print(f"screen: {len(flagged)} of {len(screen)} page(s) have an automatic flag")
    per_doc = screen.groupby("doc_id", sort=False).agg(pages=("page", "size"),
                                                       flagged_pages=("n_flags", lambda s: int((s > 0).sum())),
                                                       **{c: (c, "sum") for c in page_fidelity.CHECKS}).reset_index()
    display(per_doc)

# COMMAND ----------

# MAGIC %md ## Pick the pages, write the report and the gold sheet

# COMMAND ----------

EXPORT_PATH = HTML_PATH = None
records = []
if EXPORT:
    picks = {}                                             # (doc, page) -> {"how": set, "reasons": []}

    def pick(d, p, how, reason=None):
        e = picks.setdefault((str(d), int(p)), {"how": set(), "reasons": []})
        e["how"].add(how)
        if reason:
            e["reasons"].append(reason)

    for s in SEED_PAGES:
        d = str(s["doc_id"])
        if d not in docs:
            print(f"  seed doc {d} {s['pages']}: not loaded (not staged or not in DOCS) - skipped")
            continue
        got, beyond = page_fidelity.expand_seed(docs[d], s["pages"])
        if beyond:
            print(f"  seed doc {d}: page(s) {beyond} beyond its {len(docs[d]['pages'])} pages - skipped "
                  f"(has the document changed?)")
        for p in got:
            pick(d, p, "seed", s.get("reason"))
    rnd = page_fidelity.random_pages({d: len(doc["pages"]) for d, doc in docs.items()}, N_RANDOM_PER_DOC, SEED)
    for r in rnd.itertuples():
        pick(r.doc_id, r.page, "random")
    if MAX_FLAGGED and len(screen):
        worst = screen[screen["n_flags"] > 0].sort_values(["n_flags", "doc_id", "page"], ascending=[False, True, True])
        extra = [(str(r.doc_id), int(r.page)) for r in worst.itertuples() if (str(r.doc_id), int(r.page)) not in picks]
        for d, p in extra[:MAX_FLAGGED]:
            pick(d, p, "flagged")

    order = list(docs)
    for (d, p), e in sorted(picks.items(), key=lambda kv: (order.index(kv[0][0]), kv[0][1])):
        rec = page_fidelity.page_record(docs[d], p, DPI)
        rec["selection"] = "+".join(h for h in ("seed", "random", "flagged") if h in e["how"])
        rec["seed_reason"] = "; ".join(dict.fromkeys(e["reasons"])) or None
        records.append(rec)
    by_how = pd.Series([r["selection"] for r in records]).value_counts().to_dict()
    print(f"{len(records)} page(s) in the report: {by_how}; {sum(1 for r in records if r['n_flags'])} with an automatic flag")

    os.makedirs(OUT_DIR, exist_ok=True)
    HTML_PATH = f"{OUT_DIR}/v07_page_fidelity_{SAMPLE_ID}.html"
    notes = [f"Sample {SAMPLE_ID}: {len(records)} page(s) of {len(docs)} document(s) staged in {PDF_DIR} "
             f"(seed {SEED}, {N_RANDOM_PER_DOC} random page(s) per document); corpus {CORPUS_VERSION}.",
             f"Sections built as 04 builds them (policy_docs.parse_pdf -> policy_docs.segment); ONLY_CANDIDATES = "
             f"{ONLY_CANDIDATES}: a grey section is skipped by the pre-filter and never reaches the model.",
             "Documents: " + ", ".join(f"{d} ({doc['doc_hash'][:12]})" for d, doc in docs.items()),
             "Score every page in the GOLD sheet of the workbook with the same name. The flags are hints, not the score."]
    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(page_fidelity.html_report(records, f"v07 page fidelity - {SAMPLE_ID}", notes))
    gold = page_fidelity.gold_frame(records, SAMPLE_ID, CORPUS_VERSION)
    readme = pd.DataFrame({"how to score": page_fidelity.GOLD_README + [f"Report: {HTML_PATH}"]})
    EXPORT_PATH = quality.xlsx_write_sheets({"README": readme, "GOLD": gold, "SCREEN": screen},
                                            f"{OUT_DIR}/v07_page_fidelity_{SAMPLE_ID}.xlsx")
    display(gold[["doc_id", "page", "selection", "auto_flags", "sections"]])
    print(f"\nwrote {HTML_PATH}\nwrote {EXPORT_PATH}\nNext: a person scores the GOLD sheet with the report open; then set "
          f"SCORED_WORKBOOK to its path (EXPORT = False) and re-run.")

# COMMAND ----------

# MAGIC %md ## Phase 2 — ingest the scored sheet

# COMMAND ----------

metrics = pd.DataFrame()
if not SCORED_WORKBOOK:
    print("SCORED_WORKBOOK is None - nothing to ingest. Page text fidelity remains UNMEASURED until a scored sheet is ingested.")
elif not os.path.exists(SCORED_WORKBOOK):
    print(f"SCORED_WORKBOOK {SCORED_WORKBOOK} does not exist - nothing ingested. Page text fidelity remains UNMEASURED.")
else:
    book = quality.xlsx_read_sheets(SCORED_WORKBOOK)
    assert "GOLD" in book, "workbook has no GOLD sheet"
    gs = book["GOLD"]
    lost = [c for c in page_fidelity.GOLD_COLUMNS if c not in gs.columns]
    assert not lost, f"sheet GOLD lost column(s) {lost} - re-export rather than editing the layout"
    # 2026-10-04 (critic P51-8): a malformed sheet is refused (ValueError): a page scored twice, a blank or mixed
    # corpus_version, mixed sample ids - each would make the rate mean something else than it says
    gold_info = page_fidelity.check_gold(gs)
    sid = gold_info["sample_id"]
    print(f"sample {sid}: {gold_info['pages']} page(s) of corpus {gold_info['corpus_version']}")
    if spark.catalog.tableExists(T_METRICS) and not REINGEST:
        from pyspark.sql import functions as F
        done = spark.table(T_METRICS).where(F.col("sample_id") == sid).count()
        assert done == 0, f"sample {sid} was already ingested ({done} metric rows). Set REINGEST = True to add it again."
    ok = gs["page_ok"].map(quality._yn)
    bad = gs[ok.isna() & gs["page_ok"].map(lambda v: not quality._is_blank(v))]
    if len(bad):
        print(f"  {len(bad)} row(s) have a page_ok that is not Y/N - treated as blank: "
              f"{sorted(bad['page_ok'].astype(str).unique())[:5]}")
    unsigned = int((ok.notna() & gs["scorer"].map(quality._is_blank)).sum())
    if unsigned:
        print(f"  {unsigned} scored page(s) have no scorer name - counted, but fill the scorer column")
    metrics = page_fidelity.page_text_fidelity(gs)
    now = pd.Timestamp.now().isoformat(timespec="seconds")
    metrics["sample_id"], metrics["computed_at"] = sid, now
    metrics = metrics[quality.METRIC_COLUMNS[:-1] + ["sample_id", "computed_at", "notes"]]
    display(metrics)
    for r in metrics.to_dict("records"):
        print(f"page_text_fidelity [{r['scope_type']}={r['scope']}]: " + ("UNMEASURED (n=0)" if r["n"] == 0 else
              f"{r['value']:.3f} (95% CI {r['ci_low']:.3f}-{r['ci_high']:.3f}, n={r['n']})"))
    kb_io.write_table(spark, metrics, T_METRICS, mode="append")
    print("The fair rate is sample=random (each document weighted by its page count). The definition of done sets no "
          "numeric bar for page fidelity yet; it is measured and stated.")
