# Databricks notebook source
# MAGIC %md
# MAGIC # v06 · Query validation pack — is every query right?
# MAGIC
# MAGIC **What this answers:** for every SQL query the current build runs (one per compiled state rule, the two NCCI
# MAGIC statements that cover every federal edit, and one rolling-window signal query per period limit), what it does in
# MAGIC plain English, the exact stored SQL with its sha256, the
# MAGIC policy words and page it comes from, who signed the rule — and whether the stored SQL, run unchanged on small synthetic
# MAGIC claims, flags exactly the cases it must and none of the cases it must not (`auto_test` PASS / FAIL per scenario).
# MAGIC
# MAGIC **How it works:** two phases.
# MAGIC 1. **EXPORT** (`EXPORT = True`): builds the scenarios, runs every stored query against SCRATCH tables
# MAGIC    (`<KB>.qv_*`, never the production snapshot or edit tables; only the table names in the SQL text are swapped),
# MAGIC    writes `data/validation/query_validation_pack_<build>.xlsx` and appends the scenario results to
# MAGIC    `policy_query_validation_tests`. The NCCI statements are tested on a stratified sample of their edit rows
# MAGIC    (by claim form, modifier indicator, end date / later MUE change).
# MAGIC 2. **INGEST** (`SIGNED_WORKBOOK = "<path>"`): a validator fills `validator`, `validator_decision` (`OK` / `PROBLEM`)
# MAGIC    and `validator_note` on the QUERIES sheet; each decision is appended to `policy_query_validation`, bound to the
# MAGIC    query's `sql_sha256`. A decision whose hash no longer matches the current build's SQL is refused (the query changed
# MAGIC    after it was validated). v03 shows how many current queries are signed OK.
# MAGIC
# MAGIC **Limits:** scenarios test what the SQL does on chosen cases; they do not prove the policy reading is right — that
# MAGIC is the rule's reviewer signature, shown next to the SQL. The NCCI statements are tested on a sample of edit rows, not
# MAGIC every row (every row runs through the same statement).
# MAGIC
# MAGIC Writes: the workbook under `data/validation/`, `policy_query_validation_tests` (EXPORT), `policy_query_validation`
# MAGIC (INGEST); creates and drops the scratch tables `<KB>.qv_*`.

# COMMAND ----------

# MAGIC %pip install -q openpyxl

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, json
import pandas as pd
from pyspark.sql import functions as F
import config, kb_io, quality, detector_gen, query_pack, run_guard
for _m in (config, kb_io, quality, detector_gen, query_pack, run_guard):
    importlib.reload(_m)

EXPORT          = True          # phase 1: build + run the scenarios, write the workbook
N_PTP_SAMPLE    = 12            # NCCI PTP edit rows tested through the batch statement
N_MUE_SAMPLE    = 8             # NCCI MUE rows tested through the batch statement
SEED            = 20261002
SIGNED_WORKBOOK = None          # phase 2: path of the workbook a validator filled in; None = skip ingest

KB = config.KB
OUT_DIR = f"{config.WORKSPACE_DATA_DIR}/validation"
T_TESTS, T_SIGN = f"{KB}.policy_query_validation_tests", f"{KB}.policy_query_validation"
query_pack.SCRATCH_SCHEMA = KB

det = spark.table(f"{KB}.policy_detectors").toPandas()
BUILD_ID = str(det["build_id"].dropna().iloc[0])
batch = spark.table(f"{KB}.policy_batch_detectors").toPandas()
assert set(batch["build_id"].astype(str)) <= {BUILD_ID}, "policy_batch_detectors is from another build - re-run 07"


def _rules(df):
    out = []
    for r in df.to_dict("records"):
        r = {k: (None if isinstance(v, float) and v != v else v) for k, v in r.items()}     # NaN -> None
        for k in ("predicate", "codes"):
            if isinstance(r.get(k), str):
                try:
                    r[k] = json.loads(r[k])
                except Exception:
                    pass
        out.append(r)
    return out

# COMMAND ----------

# MAGIC %md ## 1. EXPORT — scenarios, auto-test, workbook

# COMMAND ----------

EXPORT_PATH = None
if EXPORT:
    compiled_ids = list(det.loc[(det["compiled"] == True) & det["sql"].notna(), "rule_id"])
    st = _rules(spark.table(f"{KB}.policy_rules").where(F.col("rule_id").isin(compiled_ids)).toPandas()) if compiled_ids else []
    nc = _rules(spark.table(f"{KB}.policy_rules").where("origin = 'ncci'").toPandas())
    ptp_s, mue_s = query_pack.sample_ncci(nc, N_PTP_SAMPLE, N_MUE_SAMPLE, seed=SEED)
    # 2026-10-04 (v5.2): the three AHCCCS table statements (Same Day Disallow pairs, daily limits, B2 provider types)
    # are tested on a stratified sample of their rules, like the NCCI statements
    tb = _rules(spark.table(f"{KB}.policy_rules").where("origin = 'ahcccs_table'").toPandas())
    tbl_s = query_pack.sample_tables(tb, seed=SEED) if tb else []
    dets = det.to_dict("records")
    q, s = query_pack.build_pack(spark, st, dets, batch.to_dict("records"), ptp_s, mue_s, build_id=BUILD_ID,
                                 table_sample=tbl_s)
    for t in query_pack.SCRATCH_TABLES:
        spark.sql(f"DROP TABLE IF EXISTS {query_pack._qv(t)}")
    q.insert(0, "build_id", BUILD_ID)
    s.insert(0, "build_id", BUILD_ID)
    tested_at = pd.Timestamp.now().isoformat(timespec="seconds")
    s["tested_at"] = tested_at
    readme = pd.DataFrame({"how to validate": [
        f"Build {BUILD_ID}: {len(q)} queries - {int(q['query_kind'].str.startswith('state').sum())} state-rule finding "
        f"queries, {int(q['query_id'].str.startswith('BATCH:ncci').sum())} NCCI batch statements (tested on {len(ptp_s)} PTP + "
        f"{len(mue_s)} MUE sampled edit rows), {int(q['query_id'].str.startswith('BATCH:ahcccs').sum())} AHCCCS table "
        f"statements (tested on {len(tbl_s)} sampled table rules), "
        f"{int(q['query_id'].str.startswith('SIGNAL:').sum())} utilization-signal "
        f"queries (not findings). Auto-test: {int((q['auto_test'] == 'PASS').sum())} PASS, "
        f"{int((q['auto_test'] != 'PASS').sum())} not PASS.",
        "QUERIES: one row per query. Read `statement`, `verbatim_quote` and `source` (the policy), `what_it_does` (plain "
        "English), then `sql` (the exact text that runs; `sql_sha256` is checked before every run).",
        "SCENARIOS: the synthetic cases each query was run on - what it MUST flag (expected_findings 1) and must NOT flag "
        "(0) - and what the stored SQL actually did. pass = TRUE means the SQL behaved as the policy reading says.",
        "Sign: put your name in `validator`, OK or PROBLEM in `validator_decision`, and a note for any PROBLEM. Save, then "
        "run this notebook with SIGNED_WORKBOOK = '<path>' to record it (bound to the query's sql_sha256).",
        "`dates_covered`: the dates of service a query judges. 'every date of service' means the manual gives no start "
        "date for the rule; if the rule is newer than the oldest claims, mark PROBLEM and give the date.",
        "A sample is fine: e.g. every state query plus the NCCI and AHCCCS table statements; record which ones you checked. 08 never runs "
        "a query marked PROBLEM; findings of queries not yet signed OK are labelled query_validation = not_validated.",
    ]})
    os.makedirs(OUT_DIR, exist_ok=True)
    EXPORT_PATH = quality.xlsx_write_sheets({"README": readme, "QUERIES": q, "SCENARIOS": s},
                                            f"{OUT_DIR}/query_validation_pack_{BUILD_ID}.xlsx")
    kb_io.write_table(spark, s, T_TESTS, mode="append", schema={"pass": "boolean", "expected_findings": "long"})
    print(f"pack written: {EXPORT_PATH}")
    display(q[["query_id", "query_kind", "origin", "predicate_type", "auto_test", "scenarios", "scenarios_passed",
               "reviewer", "conditions"]])
    if (q["auto_test"] != "PASS").any():
        display(s[~s["pass"]])
        print("AT LEAST ONE QUERY FAILED ITS SCENARIOS - do not run 08 until it is understood.")

# COMMAND ----------

# MAGIC %md ## 2. INGEST — record the validator's decisions

# COMMAND ----------

if SIGNED_WORKBOOK:
    book = quality.xlsx_read_sheets(SIGNED_WORKBOOK)
    sq = book["QUERIES"]
    sq = sq[sq["validator_decision"].astype(str).str.strip().str.upper().isin(["OK", "PROBLEM"])
            & sq["validator"].notna() & (sq["validator"].astype(str).str.strip() != "")].copy()
    cur = run_guard.current_hashes(det, batch)          # the same query ids and hashes 08 checks before it runs
    sq["current_sql_sha256"] = sq["query_id"].map(cur)
    stale = sq[sq["current_sql_sha256"] != sq["sql_sha256"]]
    if len(stale):
        print(f"REFUSED {len(stale)} decision(s): the query's SQL changed since it was validated "
              f"(or it is not in the current build): {list(stale['query_id'])[:10]}")
    ok = sq[sq["current_sql_sha256"] == sq["sql_sha256"]]
    rows = ok.assign(validator_decision=ok["validator_decision"].astype(str).str.strip().str.upper(),
                     validated_at=pd.Timestamp.now().isoformat(timespec="seconds"),
                     workbook=os.path.basename(SIGNED_WORKBOOK))[
        ["build_id", "query_id", "sql_sha256", "auto_test", "validator", "validator_decision", "validator_note",
         "validated_at", "workbook"]]
    if len(rows):
        kb_io.write_table(spark, rows, T_SIGN, mode="append", schema={c: "string" for c in rows.columns})
    print(f"recorded {len(rows)} decision(s): {rows['validator_decision'].value_counts().to_dict()}")
