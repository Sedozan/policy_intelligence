# Databricks notebook source
# MAGIC %md
# MAGIC # v02 · Detector precision — how many findings are real violations?
# MAGIC
# MAGIC **What this measures:** for each kind of detector (origin × rule type), the share of findings an investigator confirms
# MAGIC as a true violation, with a 95% interval and sample size.
# MAGIC **How it works:** two phases.
# MAGIC 1. **EXPORT** (`EXPORT = True`): a stratified sample of the latest run's findings, with the evidence an investigator
# MAGIC    needs on one row — the claim line, the partner line for a pair, the rule, the policy words and source, paid amount,
# MAGIC    PA status. The reviewer fills `disposition` (`true_violation` / `false_positive` / `cannot_tell`), `reviewer`, `note`.
# MAGIC 2. **INGEST** (`SCORED_WORKBOOK = "<path>"`): precision per stratum → `policy_quality_metrics`; raw rows →
# MAGIC    `policy_finding_reviews`.
# MAGIC
# MAGIC **Precision = true_violation / (true_violation + false_positive).** `cannot_tell` is left out of precision (it is
# MAGIC neither right nor wrong) but reported as its own share: a high share means the evidence is not enough to decide.
# MAGIC **Limits:** until a workbook has been reviewed and ingested, **detector precision is unmeasured**. A "true violation"
# MAGIC here means the claim breaks the rule as written; it is still not a confirmed overpayment (that needs records review and
# MAGIC due process). NCCI = CMS public edit set, Arizona deactivations not applied.
# MAGIC
# MAGIC Writes: the workbook under `data/validation/`, and (INGEST only) appends to the two tables above.

# COMMAND ----------

# MAGIC %pip install -q openpyxl

# COMMAND ----------

import os, sys
# ---- find the package: this notebook is two levels below it (notebooks/validation/). Set PKB_PACKAGE_DIR to override.
_here = os.getcwd()
for _cand in (os.environ.get("PKB_PACKAGE_DIR"), _here, os.path.dirname(_here), os.path.dirname(os.path.dirname(_here))):
    if _cand and os.path.exists(os.path.join(_cand, "config.py")):
        sys.path.insert(0, _cand); break
else:
    raise ImportError(f"config.py not found in {_here}, its parent or grandparent; set PKB_PACKAGE_DIR")

import importlib, re
import pandas as pd
from pyspark.sql import Window, functions as F
import config, kb_io, quality
for _m in (config, kb_io, quality):
    importlib.reload(_m)

EXPORT          = True          # phase 1: draw the sample and write the workbook
RUN_ID          = None          # None = the latest detector run
N_PER_STRATUM   = 20            # findings per origin x predicate_type (all of them when a stratum is smaller)
SEED            = 20260929      # same seed + same run = same sample
SCORED_WORKBOOK = None          # phase 2: path of the reviewed workbook; None = skip ingest
REINGEST        = False         # True = ingest a sample_id that was already ingested

# COMMAND ----------

KB, CC = config.KB, config.CLAIM_COLS
OUT_DIR = f"{config.WORKSPACE_DATA_DIR}/validation"
T_METRICS, T_REVIEWS = f"{KB}.policy_quality_metrics", f"{KB}.policy_finding_reviews"
KEY = ["rule_id", "claim_id", "line_no", "member_id", "dos", "period_start"]     # one finding
PA_MEANING = {"not_evaluated": "PA not considered (NCCI: a PA does not bypass an edit)",
              "pa_on_file": "a PA number is on file - check whether it authorizes this",
              "no_pa_on_file": "no PA number on file"}
REVIEW_COLS = ["disposition", "reviewer", "note"]
README = pd.DataFrame({"how to review": [
    "One finding per row: a claim line (or a member-day / member-month total) that a rule flagged.",
    "disposition: true_violation = the claim breaks the rule as written; false_positive = it does not (say why in note: "
    "modifier, PA covers it, rule misread, data error...); cannot_tell = the evidence here is not enough to decide.",
    "A true_violation is not a confirmed overpayment: it still needs records review and due process.",
    "Fill reviewer with your name. Leave rows blank rather than guessing - blanks are excluded.",
    "Do not add, remove or reorder rows or columns.",
]})

RUN_ID = RUN_ID or spark.table(f"{KB}.policy_detector_runs").agg(F.max("run_id")).first()[0]
assert RUN_ID, "no detector run yet - run 08_run_detectors"
SAMPLE_ID = f"v02-{RUN_ID}-s{SEED}"
print(f"run {RUN_ID} | sample {SAMPLE_ID}")

# COMMAND ----------

# MAGIC %md ## Phase 1 — export the sample

# COMMAND ----------

EXPORT_PATH = None
f = spark.table(f"{KB}.policy_findings").where(F.col("run_id") == RUN_ID)
if EXPORT and f.limit(1).count() == 0:
    print(f"run {RUN_ID} has no findings - nothing to sample.")
elif EXPORT:
    # Pre-select in Spark with the SAME hash quality.stratified_sample uses, so millions of findings never reach pandas
    # and the sample is exactly what stratified_sample would draw from the whole run.
    w = Window.partitionBy("origin", "predicate_type").orderBy(F.expr(quality.sample_hash_sql(KEY, SEED)))
    pre = (f.withColumn("_rank", F.row_number().over(w))
            .withColumn("_size", F.count(F.lit(1)).over(Window.partitionBy("origin", "predicate_type")))
            .where(F.col("_rank") <= N_PER_STRATUM).drop("_rank").toPandas())
    sizes = pre.set_index(pre["origin"].fillna("(none)").astype(str) + " | "
                          + pre["predicate_type"].fillna("(none)").astype(str))["_size"].to_dict()
    samp = quality.stratified_sample(pre.drop(columns=["_size"]), ["origin", "predicate_type"], N_PER_STRATUM, SEED, key=KEY)
    samp["stratum_size"] = samp["stratum"].map(sizes).astype(int)
    print(f"{len(samp):,} finding(s) sampled:")
    display(samp.groupby(["stratum", "stratum_size"]).size().reset_index(name="sampled"))

    # evidence: the flagged line, the partner (Column One) line, the rule as it stood at the finding's build
    keys = pd.concat([samp[["claim_id", "line_no"]].rename(columns={"claim_id": "k_claim", "line_no": "k_line"}),
                      samp[["col1_claim_id", "col1_line_no"]].rename(columns={"col1_claim_id": "k_claim", "col1_line_no": "k_line"})])
    keys = keys.dropna().drop_duplicates().astype(str)
    cl = pd.DataFrame(columns=["k_claim", "k_line", "code", "units", "modifiers", "servicing_provider", "pa_no", "pos"])
    if len(keys):
        c = spark.table(config.CLAIMS_TABLE)
        kdf = spark.createDataFrame(keys, "k_claim string, k_line string")
        cl = (c.join(kdf, (c[CC["claim_id"]].cast("string") == kdf["k_claim"]) & (c[CC["line_no"]].cast("string") == kdf["k_line"]))
              .select("k_claim", "k_line", F.col(CC["code"]).cast("string").alias("code"),
                      F.col(CC["units"]).cast("double").alias("units"),
                      F.concat_ws(" ", *[F.coalesce(F.col(m), F.lit("")) for m in CC["mods"]]).alias("modifiers"),
                      F.col(CC["servicing_provider"]).cast("string").alias("servicing_provider"),
                      (F.col(CC["pa_no"]).cast("string") if CC.get("pa_no") else F.lit(None).cast("string")).alias("pa_no"),
                      F.col(CC["pos"]).cast("string").alias("pos"))
              .toPandas())
    line = cl.add_prefix("line_").rename(columns={"line_k_claim": "claim_id", "line_k_line": "line_no"})
    col1 = cl[["k_claim", "k_line", "code", "units", "modifiers"]].add_prefix("col1_").rename(
        columns={"col1_k_claim": "col1_claim_id", "col1_k_line": "col1_line_no"})
    rb = samp[["build_id", "rule_id"]].drop_duplicates()
    hist = (spark.table(f"{KB}.policy_rules_history").join(spark.createDataFrame(rb.astype(str), "build_id string, rule_id string"), ["build_id", "rule_id"])
            .select("build_id", "rule_id", "statement", "notes", "source_doc", "source_locator", "source_url", "doc_version",
                    "reviewer", "review_status").dropDuplicates(["build_id", "rule_id"]).toPandas())
    hist["policy_quote"] = hist["notes"].map(
        lambda s: (re.search(r'Verbatim: "(.*)" Found by:', str(s or ""), re.S) or re.search(r'Verbatim: "(.*)"', str(s or ""), re.S) or [None, None])[1])
    hist["policy_quote"] = [q or ("(federal table row - no prose)" if str(rid).startswith("NCCI") else None)
                            for q, rid in zip(hist["policy_quote"], hist["rule_id"])]
    out = (samp.merge(line, on=["claim_id", "line_no"], how="left")
               .merge(col1, on=["col1_claim_id", "col1_line_no"], how="left")
               .merge(hist.drop(columns=["notes"]), on=["build_id", "rule_id"], how="left"))
    out["pa_meaning"] = out["pa_status"].map(PA_MEANING)
    out["sample_id"] = SAMPLE_ID
    cols = ["sample_id", "stratum", "stratum_size", "origin", "predicate_type", "finding", "finding_severity", "paid_amt",
            "pa_status", "pa_meaning", "claim_id", "line_no", "member_id", "servicing_provider", "dos", "period_start",
            "line_code", "line_units", "line_modifiers", "line_pa_no", "line_pos", "observed_units", "allowed_units",
            "col1_claim_id", "col1_line_no", "col1_code", "col1_units", "col1_modifiers", "pair_scope", "evidence_lines",
            "statement", "policy_quote", "source_doc", "source_locator", "source_url", "doc_version", "reviewer",
            "review_status", "rule_id", "build_id", "run_id"]
    out = out[cols].rename(columns={"reviewer": "rule_approved_by", "review_status": "rule_review_status"})
    for c in ("policy_quote", "statement", "evidence_lines"):
        out[c] = out[c].map(quality.clip_text)
    os.makedirs(OUT_DIR, exist_ok=True)
    EXPORT_PATH = quality.xlsx_write_sheets({"README": README, "FINDINGS": out.assign(**{c: None for c in REVIEW_COLS})},
                                            f"{OUT_DIR}/v02_finding_sample_{SAMPLE_ID}.xlsx")
    print(f"wrote {EXPORT_PATH}\nNext: an investigator fills disposition / reviewer / note; then set SCORED_WORKBOOK to its "
          "path (EXPORT = False) and re-run.")

# COMMAND ----------

# MAGIC %md ## Phase 2 — ingest the reviewed workbook

# COMMAND ----------

metrics = pd.DataFrame()
if not SCORED_WORKBOOK:
    print("SCORED_WORKBOOK is None - nothing to ingest. Detector precision remains UNMEASURED until a reviewed workbook "
          "is ingested.")
elif not os.path.exists(SCORED_WORKBOOK):
    print(f"SCORED_WORKBOOK {SCORED_WORKBOOK} does not exist - nothing ingested. Detector precision remains UNMEASURED.")
else:
    book = quality.xlsx_read_sheets(SCORED_WORKBOOK)
    assert "FINDINGS" in book, "workbook has no FINDINGS sheet"
    fs = book["FINDINGS"]
    lost = [c for c in ["sample_id", "stratum", "origin", "predicate_type", "rule_id"] + REVIEW_COLS if c not in fs.columns]
    assert not lost, f"FINDINGS lost column(s) {lost} - re-export rather than editing the layout"
    sid = str(fs["sample_id"].dropna().iloc[0])
    if spark.catalog.tableExists(T_METRICS) and not REINGEST:
        done = spark.table(T_METRICS).where(F.col("sample_id") == sid).count()
        assert done == 0, f"sample {sid} was already ingested ({done} metric rows). Set REINGEST = True to add it again."
    d = fs["disposition"].map(lambda v: str(v).strip().lower() if isinstance(v, str) and v.strip() else None)
    bad = d.notna() & ~d.isin(quality.DISPOSITIONS)
    if bad.any():
        print(f"  {int(bad.sum())} row(s) have a disposition that is not one of {quality.DISPOSITIONS} - treated as blank: "
              f"{sorted(d[bad].unique())[:5]}")
    metrics = quality.detector_metrics(fs)
    now = pd.Timestamp.now().isoformat(timespec="seconds")
    # every metric column, in the one order v01 / v07 write too (quality.METRIC_COLUMNS, notes last): a table that holds
    # columns in another order or number refuses the append on some formats (parquet) - 2026-10-04
    metrics = metrics.reindex(columns=quality.METRIC_COLUMNS)
    metrics["sample_id"], metrics["computed_at"] = sid, now
    metrics = metrics[quality.METRIC_COLUMNS[:-1] + ["sample_id", "computed_at", "notes"]]
    display(metrics)
    for r in metrics[metrics["metric"] == "detector_precision"].to_dict("records"):
        print(f"precision [{r['scope']}]: " + ("UNMEASURED (n=0 decided findings)" if r["n"] == 0 else
              f"{r['value']:.3f} (95% CI {r['ci_low']:.3f}-{r['ci_high']:.3f}, n={r['n']})") + f"  {r['notes']}")
    raw = fs.assign(ingested_at=now, workbook=SCORED_WORKBOOK)
    kb_io.write_table(spark, metrics, T_METRICS, mode="append")
    kb_io.write_table(spark, quality.as_text_frame(raw, keep_numeric=("paid_amt", "observed_units", "allowed_units")),
                      T_REVIEWS, mode="append")
    print("The definition of done asks for precision per rule type to be measured and false positives bounded; it sets no "
          "numeric target yet.")
