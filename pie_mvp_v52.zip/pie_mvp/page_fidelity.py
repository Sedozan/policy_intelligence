"""
page_fidelity.py  -  page-level PDF fidelity check: what a person sees on a page against what reaches the extractor.

External review, 2026-10-04: "Fix PDF layout/table attribution before the new full run. Build a small page-level gold
set containing ugly pages: tables between headings, multi-page lists, wrapped headings, code lists, footnotes and
multi-column layouts. Confirm what reaches the extractor against what a human sees in the PDF."
The case that started it (Ch.19 p.31): "... H2033, S5150. T1019. H0031, H0038, H0030 or any other per diem code" was
cut at the stray periods, so four codes never reached the rule (fixed by policy_docs.code_list_break, which
sentence_spans and _join_lines both ask). The checks below look for that kind of loss on any page. Four defects they
found on 2026-10-04 are fixed in policy_docs (stray period at the END of a PDF line; exhibit rows stripped as a
running header; a table filed under a later heading; a table header cell taken for a heading); the tests plant each
one back and the check must catch it. Critic P51 (2026-10-04) found more, fixed in policy_docs and tested in
tests/test_page_fidelity.py: a heading right under a table taken for a table line; a merged row of a grid (a group
heading, or a text column read as a 'row') taken for table content; a table filed at the first line below its top
rather than at its own first line (two-column pages, footers drawn first); footers holding a code-shaped token no
longer stripped; limits that differ only in their number stripped as a running header; a sentence ending in a code
fused with the next one; a wrapped bullet cut inside its code list.

Known limit: a table ruled with horizontal lines only (no column rules) is invisible to PyMuPDF's find_tables(), so
segment() reads it as plain lines - no row copy, and an ALL-CAPS header row may become a heading. heading_in_table
cannot see it (no table box); the person scoring the page does.

For one page of one document:
  (a) render_png()       the page as a PNG (PyMuPDF): what a person sees
  (b) raw text layer      the text the PDF holds for the page (page.get_text())
  (c) sections            what the pipeline built from the page: heading + the text that reaches the extractor. Made
                          by the SAME calls 04_extract_chapters_gpu makes - policy_docs.parse_pdf() then
                          policy_docs.segment() - on the same staged file. extract_rules.propose() sends a section's
                          heading and text to the model; extract_chapter() skips a section without a rule signal
                          (ONLY_CANDIDATES), so such a section does NOT reach the extractor.
  (d) automatic checks    severity "flag" counts against the page; "info" is shown, never counted
        code_missing      a CPT/HCPCS token on the page's text layer (policy_docs.CODE_RE) that is in none of the
                          text reaching the extractor from this page; says why (header strip, no section, pre-filter).
                          Info, not counted, for a token in a running header/footer at the top or bottom of the page
                          ("Phoenix, AZ 85034", "Form AH-10021"): stripped on purpose
        code_list_split   one code list cut into two sentences by policy_docs.sentence_spans() - the split grounding
                          and the post-checks share (policy_docs.sentences() is the same split; the pattern extractor
                          cuts at the same line breaks and uses the same code_list_break); also a section whose text
                          ends inside a list ("H0001, H0002,"), its rest under the next heading
        later_heading     text from the page given to a section whose heading comes LATER. Until 2026-10-04
                          segment() appended a page's tables to the section open at the END of the page, so a table
                          between two headings went to the second one; it now files a table where the table's own first
                          line is (parse_pdf keeps table positions). Also a row copy under an EARLIER heading than the
                          one open where the table starts in the reading order (critic P51-3). The pypdf fallback has
                          no positions and still appends at the end of the page - this check is how that shows
        row_order         lines holding 2+ codes that reach the extractor out of the page's top-to-bottom order
                          (inside a ruled table: row by row; elsewhere: within one column)
        heading_in_table  a table cell taken for a section heading ("CODE" "DESCRIPTION" ...): the rows after it
                          reach the extractor under that "heading" (info when the heading only shares its row, sits in
                          a one-row / one-column box, or is a merged row of a grid - a group heading)
        text_missing      a body line of the page that reached no section at all (info for a mid-page line stripped
                          as a running header, and for a heading with nothing under it)
        footnote_in_flow  (info) small print with the section's text going on after it: read in mid-sentence
A person scores each page (GOLD_SCORE_COLUMNS: page_ok, missing_text, misattributed_text, notes, scorer);
page_text_fidelity() turns the scores into rates: the fair one (random pages) weighted by document length with
quality.stratified_ratio's interval, the others pooled with quality.wilson's. check_gold() refuses a malformed sheet.

Pure functions: no Spark, and nothing is written next to the PDFs (acquire() is not called - it keeps a version copy).
Used by notebooks/validation/v07_page_fidelity.py; tested offline by tests/test_page_fidelity.py.
"""
from __future__ import annotations

import base64
import bisect
import hashlib
import html
import os
import re
import statistics
from collections import Counter

import pandas as pd

import config
import policy_docs
import quality
from policy_docs import CODE_RE

# ------------------------------------------------------------------ the pages to look at
# Known-ugly pages (SB + external review, 2026-10-04). Page numbers are 1-based PDF pages, as segment() reports them.
# "all" = every page of the document; "tables" = the pages where the parser found a ruled table. Both are capped at
# SEED_MAX_PAGES (the first pages win).
SEED_PAGES = [
    {"doc_id": "19", "pages": [31], "reason": "S5151 per-diem code list with stray periods (H2033, S5150. T1019. ...)"},
    {"doc_id": "19", "pages": [20], "reason": "T1016 code list"},
    {"doc_id": "10", "pages": list(range(46, 60)), "reason": "dense tables"},
    {"doc_id": "14", "pages": [5, 6, 7], "reason": "worked examples"},
    {"doc_id": "22-1", "pages": "all", "reason": "exhibit: code table"},
    {"doc_id": "22-2", "pages": "all", "reason": "exhibit: code table"},
    {"doc_id": "13", "pages": "tables", "reason": "tables"},
]
SEED_MAX_PAGES = 10


def _fitz():
    """PyMuPDF under either of its import names, as policy_docs.parse_pdf finds it."""
    try:
        import pymupdf as fitz
    except ImportError:
        import fitz                      # older name. ImportError here: pip install pymupdf
    return fitz


# ------------------------------------------------------------------ documents
def pdf_path(doc_id, pdf_dir: str | None = None) -> str:
    """The staged file of a document, found the way 04_extract_chapters_gpu finds it: <pdf_dir>/<file name of its
    URL in config.CHAPTERS>. pdf_dir defaults to config.STAGE_PDF_DIR, where 03_stage_inputs puts the PDFs."""
    return os.path.join(pdf_dir or config.STAGE_PDF_DIR, os.path.basename(config.CHAPTERS[str(doc_id)][1]))


def load_document(doc_id, path: str | None = None, pdf_dir: str | None = None, only_candidates: bool = True) -> dict:
    """Parse and segment one staged PDF exactly as 04 does: policy_docs.parse_pdf(), then policy_docs.segment() with
    the file's sha256 as doc_hash (what acquire() records). Then follow every line of every page into the sections
    (locate()). only_candidates mirrors 04's ONLY_CANDIDATES: True = a section without a rule signal never reaches
    the model."""
    doc_id = str(doc_id)
    path = path or pdf_path(doc_id, pdf_dir)
    with open(path, "rb") as f:
        doc_hash = hashlib.sha256(f.read()).hexdigest()
    pages = policy_docs.parse_pdf(path)
    sections, meta = policy_docs.segment(pages, doc_id, doc_hash)
    sizes = [ln["size"] for pg in pages for ln in pg["lines"] if ln.get("size")]
    return {"doc_id": doc_id, "path": path, "doc_hash": doc_hash, "pages": pages, "sections": sections,
            "meta": meta, "only_candidates": bool(only_candidates), "loc": locate(pages, sections),
            "body_size": statistics.median(sizes) if sizes else 0.0}     # segment()'s body font size


def _ws(s: str) -> str:
    """Whitespace collapsed the way segment() joins a paragraph's lines."""
    return re.sub(r"\s+", " ", s or "").strip()


def _is_line_at(text: str, a: int, needle: str) -> bool:
    """`needle` sits at text[a:] as a whole line: segment() puts a space, a line break or nothing around a line."""
    b = a + len(needle)
    return text.startswith(needle, a) and (a == 0 or text[a - 1].isspace()) and (b == len(text) or text[b].isspace())


def _next_line(text: str, pos: int, needle: str) -> int | None:
    """Start of `needle` if it is the next thing in `text` after `pos` (only whitespace between), else None."""
    while pos < len(text) and text[pos].isspace():
        pos += 1
    return pos if needle and _is_line_at(text, pos, needle) else None


def _find_line(text: str, needle: str, start: int = 0) -> int:
    """First place at or after `start` where `needle` sits as a whole line; -1 if none."""
    a = text.find(needle, start)
    while a >= 0 and not _is_line_at(text, a, needle):
        a = text.find(needle, a + 1)
    return a


def table_copy_text(rows: list) -> str:
    """The text segment() appends to a section for one table: one row per line, cells joined by ' | '."""
    return "\n".join(" | ".join(r) for r in rows)


def locate(pages: list[dict], sections: list[dict]) -> dict:
    """Follow segment()'s output back to the page lines. Returns
        lines[page]      one entry per parsed line, in parse order: status header | revision | heading | body | lost,
                         the section index it went to and its (start, end) in that section's text
        tables[page]     one entry per parsed table: the section its row copy was appended to, and that span
        heading_pos[k]   (page, line index) of section k's heading line; (0, -1) for a PREAMBLE section
        text_end[k]      where section k's lines end in its text (its table row copies come after)
    The sections are read as they are: a line counts as 'body' only where its text actually sits in a section's
    text, in order. Whatever segment() dropped shows up as 'lost', whatever it moved as out of sequence."""
    headers, _ = policy_docs.find_headers(pages)
    texts = [s["text"] for s in sections]
    lines, tables, heading_pos = {}, {}, {}
    k, cursor, head = -1, 0, None        # open section, how far its text is matched, (section, heading read so far)
    if sections and sections[0]["heading"] == "PREAMBLE":
        k, heading_pos[0] = 0, (0, -1)   # text before the first heading: segment() opened a PREAMBLE section
    for pg in pages:
        p, out = pg["page"], []
        for i, ln in enumerate(pg["lines"]):
            t = ln["text"].strip()
            # the two kinds of line segment() skips, tested with segment()'s own patterns (read-only use)
            if policy_docs.is_running_header(t, headers):
                out.append({"status": "header"})
                continue
            if policy_docs._REVISION_RE.match(t):
                out.append({"status": "revision"})
                continue
            nt = _ws(t)
            # the tail of a heading wrapped onto the next line: segment() made the two lines one heading
            if head is not None:
                j, got = head
                h = sections[j]["heading"]
                if h == f"{got} {t}" or h.startswith(f"{got} {t} "):
                    head = (j, f"{got} {t}")
                    out.append({"status": "heading", "section": j})
                    continue
                head = None
            # the next line of the open section's text
            if k >= 0:
                a = _next_line(texts[k], cursor, nt)
                if a is not None:
                    cursor = a + len(nt)
                    out.append({"status": "body", "section": k, "span": (a, cursor)})
                    continue
            # the heading of a later section that starts on this page (the nearest one)
            j = next((j for j in range(k + 1, len(sections)) if sections[j]["page_start"] == p
                      and (sections[j]["heading"] == t or sections[j]["heading"].startswith(t + " "))), None)
            if j is not None:
                k, cursor, heading_pos[j] = j, 0, (p, i)
                head = (j, t) if sections[j]["heading"] != t else None
                out.append({"status": "heading", "section": j})
                continue
            # anywhere else: further on in the open section, or in a later section that holds text from this page
            hit = None
            if len(nt) >= 4:
                later = [j for j in range(k + 1, len(sections)) if sections[j]["page_start"] <= p <= sections[j]["page_end"]]
                for j in ([k] if k >= 0 else []) + later:
                    a = _find_line(texts[j], nt, cursor if j == k else 0)
                    if a >= 0:
                        hit = (j, a)
                        break
            if hit:
                j, a = hit
                if j == k:
                    cursor = a + len(nt)
                out.append({"status": "body", "section": j, "span": (a, a + len(nt)), "out_of_sequence": True})
                continue
            out.append({"status": "lost"})
        lines[p] = out
        # 2026-10-04 (critic P51-5): one entry per row copy segment() files (policy_docs.table_pieces: a run of grid
        # rows) and one per table that is not a grid (a box: no copy, its lines are in the section text already).
        # open_at_end: the section open at the END of the page, where segment() files a piece none of whose lines it
        # reached (no positions: pypdf)
        pieces = policy_docs.table_pieces(pg)
        bboxes = pg.get("table_bboxes") or []
        tables[p] = []
        for i, rows in enumerate(pg.get("tables") or []):
            mine = [pc for pc in pieces if pc["table"] == i]
            for pc in mine or [{"rows": list(rows), "boxes": None}]:
                tables[p].append({"section": None, "span": None, "rows": pc["rows"], "open_at_end": k if k >= 0 else None,
                                  "copy": bool(mine), "table": i, "boxes": pc["boxes"],
                                  "table_bbox": tuple(bboxes[i]) if i < len(bboxes) else None})
    # where each section's lines end (its table row copies come after them: segment()'s _close())
    text_end = {}
    for out in lines.values():
        for x in out:
            if x.get("span"):
                text_end[x["section"]] = max(text_end.get(x["section"], 0), x["span"][1])
    # each row copy is looked up where it actually is, in page order: the first section holding text from the page
    # whose remaining text has it. segment() files a table under the heading open where the table starts on the page
    # (2026-10-04; parse_pdf keeps the table's position) - the check reads the result, it does not assume the rule
    nxt = dict(text_end)
    for p in sorted(tables):
        for t in tables[p]:
            if not t["copy"]:
                continue
            copy = table_copy_text(t["rows"])
            for j in (j for j in range(len(sections)) if sections[j]["page_start"] <= p <= sections[j]["page_end"]):
                a = texts[j].find(copy, nxt.get(j, 0))
                if a >= 0:
                    t["section"], t["span"], nxt[j] = j, (a, a + len(copy)), a + len(copy)
                    break
            else:
                t["section"] = t["open_at_end"]          # not found anywhere: reported as 'not in' that section
    return {"lines": lines, "tables": tables, "heading_pos": heading_pos, "text_end": text_end}


# ------------------------------------------------------------------ the page itself
def page_geometry(path: str, page_no: int, with_tables: bool = True) -> dict:
    """Positions on one page, read with PyMuPDF in the order policy_docs._parse_pymupdf reads it:
        lines     [(text, bbox)]: blocks -> lines, spans joined, empty lines skipped (parse_pdf()'s order)
        tables    [(bbox, rows, row_boxes)]: policy_docs.page_tables() - the call parse_pdf() makes
        raw_text  page.get_text(): the page's text layer
        size      (width, height) in points
    The text the checks compare is parse_pdf()'s; page_checks() verifies the two readings agree before it uses these
    positions."""
    fitz = _fitz()
    with fitz.open(path) as d:
        page = d[int(page_no) - 1]
        lines = []
        for block in page.get_text("dict").get("blocks", []):
            for line in block.get("lines", []):
                text = "".join(s.get("text", "") for s in line.get("spans", [])).strip()
                if text:
                    lines.append((text, tuple(line["bbox"])))
        tables = policy_docs.page_tables(page) if with_tables else []
        return {"lines": lines, "tables": tables, "raw_text": page.get_text(),
                "size": (page.rect.width, page.rect.height)}


def render_png(path: str, page_no: int, dpi: int = 100) -> bytes:
    """The page as a PNG: what a person sees."""
    fitz = _fitz()
    with fitz.open(path) as d:
        return d[int(page_no) - 1].get_pixmap(dpi=int(dpi)).tobytes("png")


# ------------------------------------------------------------------ code lists
# What may stand between two codes of ONE list, as a reader sees it: spaces and line breaks, , ; . & /, a range dash
# (any of policy_docs._DASHES) or 'through' / 'to', 'and' / 'or', and a short descriptor in parentheses
# ("H0031 (assessment), H0038 (peer support)").
_GAP_PIECE_RE = re.compile(rf"\s+|[,;.&/]|[{policy_docs._DASHES}]|\band/or\b|\band\b|\bor\b|\bthrough\b|\bthru\b"
                           r"|\bto\b|\([^()\n]{0,80}\)", re.I)
_LIST_MARK_RE = re.compile(r",|&|/|\band/or\b|\band\b|\bor\b", re.I)
# after a code: it is a list item when a list mark follows (optionally after a descriptor in parentheses)
_ITEM_END_RE = re.compile(r"(?:\s*\([^()\n]{0,80}\))?\s*(?:[,.;)&]|(?:and/or|and|or)\b|\Z)", re.I)
# after the code that follows a '.' or ';': the list goes on only when ',' or '.' comes next ('S5150. T1019. H0031,'),
# not 'and' / 'or' ('H0001, H0002. H0004 or H0006 require PA' is two sentences)
_STOP_ITEM_END_RE = re.compile(r"(?:\s*\([^()\n]{0,80}\))?\s*[,.]")
# text that stops in the middle of a list: a code, then a comma or 'and' / 'or' / '&', then nothing
_OPEN_LIST_RE = re.compile(rf"(?:{CODE_RE.pattern})\s*(?:,|&|\band/or|\band|\bor)\s*\Z")


def _gap(gap: str):
    """For the text between two codes: (is a list gap, holds '.' or ';', holds a line break, holds a list mark, holds a
    comma). Not a list gap when anything else stands there (a word, a colon, a bullet, a digit). Punctuation inside a
    descriptor in parentheses does not count."""
    pos, stop, newline, mark, comma = 0, False, False, False, False
    while pos < len(gap):
        m = _GAP_PIECE_RE.match(gap, pos)
        if not m or not m.group(0):
            return False, False, False, False, False
        piece = m.group(0)
        if not piece.startswith("("):
            stop = stop or piece in (".", ";")
            newline = newline or "\n" in piece
            mark = mark or bool(_LIST_MARK_RE.fullmatch(piece))
            comma = comma or piece == ","
        pos = m.end()
    return True, stop, newline, mark, comma


def code_lists(text: str) -> list[dict]:
    """The code lists in `text` as a reader sees them: runs of 2+ CPT/HCPCS codes joined only by list punctuation
    (see _GAP_PIECE_RE), with at least one comma or 'and' / 'or' / '&' / '/'. A '.' or ';' between two codes continues
    the list only INSIDE a comma list: the code before it was joined to the list by a comma (or by another stray period)
    and the code after it is followed by ',' or '.' - 'H2033, S5150. T1019. H0031,' is one list; 'Do not bill 99070.
    H2014 requires PA.', 'Do not bill H0031. H0038 and H0039 ...', '99201-99205. 99211, 99212 ...' and 'H0031/H0038.
    H0039, H0040 ...' are two sentences. A bare line break continues it only when the code after it is followed by a list
    mark; a comma before a line break always does ('H0018, H0014,' + 'H0015' in a table cell). Deliberately NOT
    policy_docs.code_list_break (the same reading, written separately), so this check can catch that function (or the
    splitter) going wrong. Returns [{"codes": [...], "starts": [...], "ends": [...]}] in text order."""
    out, cur, joins, marked = [], [], [], False      # joins[i]: how cur[i] joined the list (start / comma / stop / other)

    def close():
        if len(cur) >= 2 and marked:
            out.append({"codes": [c for c, _, _ in cur], "starts": [a for _, a, _ in cur], "ends": [b for _, _, b in cur]})

    for m in CODE_RE.finditer(text or ""):
        tok, join = (m.group(0), m.start(), m.end()), "start"
        if cur:
            ok, stop, newline, mark, comma = _gap(text[cur[-1][2]:m.start()])
            if ok and stop:
                # 2026-10-04 (critic P51-6): any code followed by a list mark used to carry the list across a '.', so a
                # page that reads fine ('Do not bill H0031. H0038 and H0039 are covered') was flagged code_list_split.
                # A stray period sits inside a comma list: the code before it is a comma-list item (or follows another
                # stray period: 'S5150. T1019.'), and ',' or '.' follows the code after it
                ok = joins[-1] in ("comma", "stop") and bool(_STOP_ITEM_END_RE.match(text, m.end()))
            elif ok and newline and not mark and not _ITEM_END_RE.match(text, m.end()):
                ok = False                                 # a bare line break, and no list mark after the next code
            if ok:
                marked = marked or mark
                join = "stop" if stop else "comma" if comma else "other"
            else:
                close()
                cur, joins, marked = [], [], False
        cur.append(tok)
        joins.append(join)
    close()
    return out


def split_code_lists(text: str, within: list | None = None) -> list[dict]:
    """The code lists of `text` that policy_docs.sentence_spans() cuts into more than one sentence. With `within`
    [(start, end), ...], only lists with a code inside one of those spans. One entry per cut list:
        {"codes": [...], "sentences": [[codes in sentence 1], [codes in sentence 2], ...], "breaks": ["S5150.\\nT1019"],
         "break_at": [offset where each new sentence starts]}"""
    return [x for x in list_sentences(text, within) if len(x["sentences"]) > 1]


def list_sentences(text: str, within: list | None = None) -> list[dict]:
    """Every code list of `text` (with a code inside `within`, when given) and how policy_docs.sentence_spans()
    splits it: "sentences" has one group of codes per sentence the list falls in (one group = kept whole)."""
    spans = policy_docs.sentence_spans(text or "")
    firsts = [a for a, _ in spans]
    out = []
    for lst in code_lists(text):
        if within is not None and not any(a <= s < b for s in lst["starts"] for a, b in within):
            continue
        idx = [bisect.bisect_right(firsts, s) - 1 for s in lst["starts"]]     # the sentence each code sits in
        groups, breaks, at = [[lst["codes"][0]]], [], []
        for n in range(1, len(idx)):
            if idx[n] != idx[n - 1]:
                groups.append([])
                breaks.append(text[lst["starts"][n - 1]:lst["ends"][n]])
                at.append(spans[idx[n]][0])                # where the new sentence starts
            groups[-1].append(lst["codes"][n])
        out.append({"codes": lst["codes"], "sentences": groups, "breaks": breaks, "break_at": at})
    return out


# ------------------------------------------------------------------ the checks
def _inside(box, region, pad: float = 1.0) -> bool:
    """The centre of `box` lies inside `region` (both (x0, y0, x1, y1))."""
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    return region[0] - pad <= cx <= region[2] + pad and region[1] - pad <= cy <= region[3] + pad


def _union(boxes) -> tuple:
    """The smallest box around `boxes`."""
    return (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))


def _in_order(seq: list, stream: list) -> int | None:
    """None if the items of `seq` that occur in `stream` occur there in the same order (other items may come
    between); else the index in `seq` of the first item that comes out of order. An item missing from `stream`
    altogether is skipped: that is a presence problem (code_missing), not an order problem."""
    pos = 0
    for n, x in enumerate(seq):
        if x not in stream:
            continue
        try:
            pos = stream.index(x, pos) + 1
        except ValueError:
            return n
    return None


def _short(s: str, n: int = 90) -> str:
    s = _ws(s)
    return s if len(s) <= n else s[: n - 3] + "..."


def _next_in_section(doc: dict, p: int, x: dict):
    """Font size of the line that follows line `x` (page p) in its section's text - looked up on this page and the
    next one - or None when nothing follows there."""
    best = None
    for q in (p, p + 1):
        if q > len(doc["pages"]):
            break
        for ln, y in zip(doc["pages"][q - 1]["lines"], doc["loc"]["lines"][q]):
            if y["status"] == "body" and y.get("section") == x["section"] and y["span"][0] >= x["span"][1]:
                if best is None or y["span"][0] < best[0]:
                    best = (y["span"][0], ln.get("size") or 0)
    return best[1] if best else None


def page_checks(doc: dict, page_no: int) -> dict:
    """Everything about one page except its image: the page's text layer, each parsed line with where it went, the
    sections built from the page (heading, pages, whether the model gets it, the page's part of the text, the table
    row copies), and the automatic checks in `flags` ({check, severity, codes, detail})."""
    p = int(page_no)
    pages, secs, loc = doc["pages"], doc["sections"], doc["loc"]
    if not 1 <= p <= len(pages):
        raise ValueError(f"document {doc['doc_id']} has {len(pages)} pages; there is no page {p}")
    pg = pages[p - 1]
    geo = page_geometry(doc["path"], p, with_tables=bool(pg.get("tables")))
    flags = []

    def flag(check, detail, codes=(), severity="flag"):
        flags.append({"check": check, "severity": severity, "codes": list(codes), "detail": detail})

    # positions: only when PyMuPDF reads the page the way parse_pdf() did (same lines, same tables, same order)
    boxes = [b for _, b in geo["lines"]] if [t for t, _ in geo["lines"]] == [ln["text"] for ln in pg["lines"]] else None
    tboxes = [b for b, _, _ in geo["tables"]] if [r for _, r, _ in geo["tables"]] == list(pg.get("tables") or []) else None
    if boxes is None or (pg.get("tables") and tboxes is None):
        flag("positions", "PyMuPDF's positions do not line up with the parsed page here; the order checks were skipped",
             severity="info")

    reaches = [bool(s.get("has_rule_signal")) or not doc["only_candidates"] for s in secs]
    lines = []
    for i, (ln, x) in enumerate(zip(pg["lines"], loc["lines"][p])):
        lines.append({"i": i, "text": ln["text"], "size": ln.get("size"), "status": x["status"],
                      "section": x.get("section"), "span": x.get("span"), "out_of_sequence": bool(x.get("out_of_sequence")),
                      "bbox": boxes[i] if boxes else None})
    # one entry per row copy (a run of grid rows: policy_docs.table_pieces) and per box that is not a grid. Its bbox:
    # the box of its grid rows; without row boxes (an old parse, or a parse without table positions) the table's box
    ptables = []
    for n, t in enumerate(loc["tables"][p]):
        rows_at = [tuple(b) for b in t["boxes"]] if tboxes is not None and t.get("boxes") else None
        tb = tboxes[t["table"]] if tboxes is not None else None
        ptables.append(dict(t, n=n, bbox=_union(rows_at) if rows_at else tb, table_bbox=tb,
                            row_boxes=rows_at or ([tb] if tb else None)))

    # (c) the sections built from this page, and the part of each that came from it
    ks = sorted({x["section"] for x in lines if x["section"] is not None}
                | {t["section"] for t in ptables if t["section"] is not None})
    views = []
    for k in ks:
        s = secs[k]
        body = [x["span"] for x in lines if x["status"] == "body" and x["section"] == k]
        views.append({"k": k, "heading": s["heading"], "page_start": s["page_start"], "page_end": s["page_end"],
                      "section_id": s.get("section_id"), "reaches_model": reaches[k], "rule_signal": s.get("rule_signal"),
                      "heading_here": loc["heading_pos"].get(k, (None,))[0] == p,
                      "slice": (min(a for a, _ in body), max(b for _, b in body)) if body else None,
                      "tables": [t["span"] for t in ptables if t["section"] == k and t["span"]],
                      "text": s["text"]})

    # (d1) codes on the page's text layer against the text that reaches the extractor from this page
    page_codes = Counter(CODE_RE.findall(geo["raw_text"]))
    in_text, in_heading = set(), set()
    heads = {x["section"] for x in lines if x["status"] == "heading"}    # a heading (or its wrapped tail) on this page
    for v in views:
        if not v["reaches_model"]:
            continue
        if v["k"] in heads:
            in_heading |= set(CODE_RE.findall(v["heading"]))
        for a, b in ([v["slice"]] if v["slice"] else []) + v["tables"]:
            in_text |= set(CODE_RE.findall(v["text"][a:b]))
    missing = sorted(c for c in page_codes if c not in in_text and c not in in_heading)
    heading_only = sorted(c for c in page_codes if c not in in_text and c in in_heading)
    why = {"header": "stripped as a running header/footer (it repeats on most pages, page counter aside)",
           "revision": "in the REVISION DATES line, which segment() skips",
           "lost": "the line reached no section", "heading": "only in a heading",
           "body": "its section is skipped by the pre-filter (no rule signal)"}
    height = geo["size"][1] or 792.0

    def in_band(x):                      # in the top / bottom band of the page, where running headers and footers sit
        cy = (x["bbox"][1] + x["bbox"][3]) / 2 if x["bbox"] else None
        return cy is not None and not policy_docs.HEADER_BAND * height < cy < (1 - policy_docs.HEADER_BAND) * height

    by_reason = {}
    for c in missing:
        holders = [x for x in lines if re.search(rf"\b{c}\b", x["text"])]
        if not holders:
            by_reason.setdefault(("not in the parsed lines of the page (the text layer has it)", "", "flag"), []).append(c)
        for x in holders:
            reason, severity = why.get(x["status"], x["status"]), "flag"
            if x["status"] in ("body", "heading") and x["section"] is not None and not reaches[x["section"]]:
                reason = f"its section '{secs[x['section']]['heading'][:60]}' is skipped by the pre-filter (no rule signal)"
            if x["status"] == "header" and in_band(x):
                # 2026-10-04 (critic P51-2): a footer holding a code-shaped token ("Phoenix, AZ 85034", "Form AH-10021")
                # is stripped on purpose now that a line with a code may be a running header - shown, not counted
                reason = "in a running header/footer at the top or bottom of the page, stripped on purpose (it repeats " \
                         "on most pages with the same codes)"
                severity = "info"
            by_reason.setdefault((reason, x["text"], severity), []).append(c)
    for (reason, text, severity), codes in by_reason.items():
        flag("code_missing", f"{', '.join(dict.fromkeys(codes))}: {reason}" + (f" - line '{_short(text)}'" if text else ""),
             dict.fromkeys(codes), severity=severity)
    if heading_only:
        flag("code_missing", f"{', '.join(heading_only)}: only in a section heading - the model sees it, grounding "
                             f"(section text only) cannot", heading_only, severity="info")

    # (d2) code lists cut into two sentences by the shared splitter. A table's row copy keeps a cell's own line breaks,
    # so a list in a multi-line cell is cut there; that counts only if the page's text (the same cells read as lines)
    # does not keep the list whole somewhere.
    whole = [set(x["codes"]) for v in views if v["slice"] for x in list_sentences(v["text"], [v["slice"]])
             if len(x["sentences"]) == 1]
    for v in views:
        for where, within in (("text", [v["slice"]] if v["slice"] else []), ("table row copy", v["tables"])):
            for cut in (split_code_lists(v["text"], within) if within else []):
                kept = where != "text" and any(set(cut["codes"]) <= w for w in whole)
                flag("code_list_split",
                     f"list of {len(cut['codes'])} codes in '{v['heading'][:60]}' ({where}) cut into "
                     f"{len(cut['sentences'])} sentences at " + "; ".join(repr(b) for b in cut["breaks"]) + " - "
                     + " | ".join(", ".join(g) for g in cut["sentences"])
                     + (" (the page's text keeps this list whole)" if kept else ""),
                     cut["codes"], severity="info" if kept else "flag")
                v.setdefault("breaks", []).extend(cut["break_at"])
        # a section whose text ENDS inside a list ("... H0001, H0002,"): a heading-like line (or a page break that
        # opened a new section) cut the list, and its other half reaches the extractor under another heading
        end = loc["text_end"].get(v["k"])
        tail = _OPEN_LIST_RE.search(v["text"][:end]) if v["slice"] and v["slice"][1] == end else None
        if tail:
            nxt = secs[v["k"] + 1]["heading"][:60] if v["k"] + 1 < len(secs) else None
            flag("code_list_split", f"the text of '{v['heading'][:60]}' ends inside a code list "
                                    f"('{_short(tail.group(0), 40)}'): "
                                    + (f"the rest of the list goes to '{nxt}'" if nxt else "nothing follows it"),
                 CODE_RE.findall(tail.group(0)))

    # (d3) text given to a section whose heading comes later
    def name(k):
        return secs[k]["heading"][:60]

    for x in lines:
        if x["status"] == "body" and x["section"] is not None:
            hp = loc["heading_pos"].get(x["section"])
            if hp is not None and hp > (p, x["i"]):
                flag("later_heading", f"line '{_short(x['text'])}' went to '{name(x['section'])}', whose heading comes "
                                      f"later (page {hp[0]}, line {hp[1] + 1})", CODE_RE.findall(x["text"]))
        if x["out_of_sequence"]:
            flag("later_heading", f"line '{_short(x['text'])}' sits out of sequence in '{name(x['section'])}'",
                 severity="info")
    for t in ptables:
        if not t.get("copy", True):
            continue                                    # a box, not a grid: no row copy to file (its lines are text)
        first, codes = _short(" | ".join(t["rows"][0]), 70), CODE_RE.findall(table_copy_text(t["rows"]))
        if t["section"] is None:
            flag("later_heading", f"table (first row '{first}') went to no section", codes)
            continue
        if t["span"] is None:
            flag("later_heading", f"the row copy of table (first row '{first}') is not in '{name(t['section'])}'",
                 severity="info")
        hp = loc["heading_pos"].get(t["section"])
        top = None
        if t["bbox"] and boxes:
            inside = [x["i"] for x in lines if x["bbox"] and any(_inside(x["bbox"], b) for b in t["row_boxes"])]
            # where the table starts in the page's reading order: its first line, else the first line below its top
            below = (x["i"] for x in lines if x["bbox"] and x["bbox"][1] >= t["bbox"][1])
            top = min(inside) if inside else next(below, len(lines))
        # the section open where the table starts in the reading order: the last heading before its first line
        opened = [k for k, at in loc["heading_pos"].items() if top is not None and at < (p, top)]
        want = max(opened) if opened else None
        if hp is not None and top is not None and hp > (p, top):
            flag("later_heading", f"table rows (first row '{first}') are appended to '{name(t['section'])}', whose "
                                  f"heading comes after the table (page {hp[0]}, line {hp[1] + 1}; the table starts at "
                                  f"line {top + 1}) - a table filed without its position on the page goes to the section "
                                  f"open at the END of the page", codes)
            if t["span"]:
                next(v for v in views if v["k"] == t["section"]).setdefault("late_tables", []).append(t["span"])
        elif hp is not None and want is not None and want != t["section"] and t["span"]:
            # 2026-10-04 (critic P51-3): a row copy under an EARLIER heading than the one open where the table starts - a
            # table in the right column of a two-column page filed at the first line below its top (in the left column),
            # or on a page whose footer is drawn before the body - was not caught: only a later heading was
            flag("later_heading", f"table rows (first row '{first}') are appended to '{name(t['section'])}', but the "
                                  f"table starts (line {top + 1}, in the page's reading order) under '{name(want)}'", codes)
            next(v for v in views if v["k"] == t["section"]).setdefault("late_tables", []).append(t["span"])
        elif hp is not None and top is None and hp[0] == p:
            flag("later_heading", f"table (first row '{first}') went to '{name(t['section'])}', which starts on this "
                                  f"page; its position is unknown, so check by eye", severity="info")

    # a table cell taken for a heading: the rows after it then reach the extractor under that "heading"
    done = set()
    for x in lines:
        if x["status"] != "heading" or not x["bbox"] or x["section"] in done:
            continue
        box = x["bbox"]
        holder = [t for t in ptables if t["table_bbox"] and _inside(box, t["table_bbox"])]
        if any(t["copy"] and t["row_boxes"] and any(_inside(box, b) for b in t["row_boxes"]) for t in ptables):
            done.add(x["section"])
            flag("heading_in_table", f"table cell '{_short(x['text'], 40)}' became the section heading "
                                     f"'{name(x['section'])}': the table rows after it reach the extractor under that "
                                     f"heading", CODE_RE.findall(x["text"]))
        elif any(t["copy"] for t in holder):
            # 2026-10-04 (critic P51-5): a merged row - one cell across a grid - is text, and may be a heading (a group
            # heading inside an exhibit; a text column find_tables() read as one 'row' because a column rule touches a table)
            done.add(x["section"])
            flag("heading_in_table", f"heading '{name(x['section'])}' is a merged row of a table (one cell across it: a "
                                     f"group heading, or a column of text read as a table): kept as a heading - check by "
                                     f"eye", severity="info")
        elif holder:
            done.add(x["section"])
            flag("heading_in_table", f"heading '{name(x['section'])}' sits inside a one-row / one-column box the PDF "
                                     f"reader calls a table (a layout box?): kept as a heading - check by eye",
                 severity="info")
        elif any(y is not x and y["bbox"] and y["status"] not in ("header", "revision")
                 and min(box[3], y["bbox"][3]) - max(box[1], y["bbox"][1]) > 0.5 * (box[3] - box[1])      # same row
                 and (y["bbox"][0] >= box[2] or y["bbox"][2] <= box[0]) for y in lines):                  # side by side
            done.add(x["section"])
            flag("heading_in_table", f"heading '{name(x['section'])}' shares its line of the page with other text (a "
                                     f"table header cell, or a column?)", severity="info")

    # small print at the foot of the page (a footnote?) with the section's text going on after it: the model reads
    # it in mid-sentence. Only the bottom quarter: tables are often set smaller than the body text too.
    body_size, height = doc.get("body_size") or 0, geo["size"][1] or 792.0
    for x in lines:
        if (body_size and x["status"] == "body" and x["size"] and x["size"] <= body_size - 1.5 and x["bbox"]
                and x["bbox"][1] > 0.75 * height):
            nxt = _next_in_section(doc, p, x)
            if nxt is not None and nxt > body_size - 1.5:
                flag("footnote_in_flow", f"small print '{_short(x['text'], 60)}' sits inside the text of "
                                         f"'{name(x['section'])}' with normal text after it: the model reads it in "
                                         f"mid-flow", CODE_RE.findall(x["text"]), severity="info")

    # (d4) lines holding 2+ codes, in the page's top-to-bottom order
    def key(x):                          # where a line reaches the extractor: section, then place in its text
        return (x["section"], x["span"][0])

    placed = [x for x in lines if x["status"] == "body" and x["span"] and x["bbox"]]
    for t in ptables:
        if not t["bbox"]:
            continue
        row_codes = [CODE_RE.findall(" ".join(row)) for row in t["rows"]]
        seq = [c for codes in row_codes if len(codes) >= 2 for c in codes]          # rows with 2+ codes, row by row
        stream = [c for x in sorted((x for x in placed if _inside(x["bbox"], t["bbox"])), key=key)
                  for c in CODE_RE.findall(x["text"])]
        bad = _in_order(seq, stream) if seq else None
        if bad is not None:
            row = next(r for r in t["rows"] if seq[bad] in CODE_RE.findall(" ".join(r)))
            flag("row_order", f"table rows with 2+ codes do not reach the extractor row by row: '{seq[bad]}' (row "
                              f"'{_short(' | '.join(row), 70)}') comes out of order in the text read off the page",
                 [seq[bad]])
    outside = [x for x in placed if len(CODE_RE.findall(x["text"])) >= 2
               and not any(t["bbox"] and _inside(x["bbox"], t["bbox"]) for t in ptables)]
    pairs = 0
    for a in outside:
        for b in outside:
            # b is above a in the same column, but reaches the extractor after it
            same_col = min(a["bbox"][2], b["bbox"][2]) > max(a["bbox"][0], b["bbox"][0])
            if key(a) < key(b) and same_col and b["bbox"][3] <= a["bbox"][1] + 1 and pairs < 3:
                pairs += 1
                flag("row_order", f"line '{_short(b['text'], 60)}' is above '{_short(a['text'], 60)}' on the page but "
                                  f"reaches the extractor after it", CODE_RE.findall(b["text"]))

    # text that reached no section
    for x in lines:
        if x["status"] == "lost":
            heading_like = not re.search(r"[a-z]", x["text"])
            flag("text_missing", f"line '{_short(x['text'])}' reached no section"
                 + (" (a heading with no text under it: segment() drops an empty section)" if heading_like else ""),
                 CODE_RE.findall(x["text"]), severity="info" if heading_like else "flag")
        elif x["status"] == "header" and x["bbox"] and not in_band(x):
            # 2026-10-04 (critic P51-9): segment() takes running headers from the top / bottom band of a page only
            # (policy_docs.HEADER_BAND); a body line is stripped only when its text equals one of them
            flag("text_missing", f"line '{_short(x['text'])}' in the body of the page was stripped as a running header "
                                 f"(its text repeats at the top or bottom of most pages, page counter aside)",
                 CODE_RE.findall(x["text"]), severity="info")

    return {"doc_id": doc["doc_id"], "page": p, "n_pages": len(pages), "doc_hash": doc["doc_hash"], "path": doc["path"],
            "raw_text": geo["raw_text"], "page_codes": dict(page_codes), "codes_missing": missing,
            "lines": lines, "tables": ptables, "sections": views, "flags": flags,
            "n_flags": sum(1 for f in flags if f["severity"] == "flag")}


def page_record(doc: dict, page_no: int, dpi: int = 100) -> dict:
    """page_checks() plus the page image (base64 PNG) for the report."""
    rec = page_checks(doc, page_no)
    rec["png_b64"] = base64.b64encode(render_png(doc["path"], page_no, dpi)).decode("ascii")
    return rec


CHECKS = ("code_missing", "code_list_split", "later_heading", "row_order", "heading_in_table", "text_missing")


def flag_summary(rec: dict) -> str:
    """'code_missing:2; later_heading:1' over the counted flags; '' when there are none."""
    n = Counter(f["check"] for f in rec["flags"] if f["severity"] == "flag")
    return "; ".join(f"{c}:{k}" for c, k in sorted(n.items()))


def screen(doc: dict) -> pd.DataFrame:
    """The automatic checks on every page of a document (no images): one row per page, a count per check."""
    rows = []
    for p in range(1, len(doc["pages"]) + 1):
        rec = page_checks(doc, p)
        n = Counter(f["check"] for f in rec["flags"] if f["severity"] == "flag")
        rows.append({"doc_id": doc["doc_id"], "page": p, "n_flags": rec["n_flags"], **{c: n.get(c, 0) for c in CHECKS},
                     "codes_missing": ", ".join(rec["codes_missing"]),
                     "detail": quality.clip_text(" || ".join(f["detail"] for f in rec["flags"] if f["severity"] == "flag"))})
    return pd.DataFrame(rows, columns=["doc_id", "page", "n_flags", *CHECKS, "codes_missing", "detail"])


# ------------------------------------------------------------------ choosing pages
def expand_seed(doc: dict, spec, cap: int = SEED_MAX_PAGES) -> tuple[list[int], list[int]]:
    """(pages of the document a seed names, pages it names that the document does not have). spec: a list of page
    numbers, "all", or "tables" (pages where the parser found a ruled table)."""
    n = len(doc["pages"])
    if spec == "all":
        return list(range(1, n + 1))[:cap], []
    if spec == "tables":
        return [pg["page"] for pg in doc["pages"] if pg.get("tables")][:cap], []
    want = [int(x) for x in spec]
    return [x for x in want if 1 <= x <= n], [x for x in want if not 1 <= x <= n]


def random_pages(page_counts: dict, n_per_doc: int, seed: int) -> pd.DataFrame:
    """n_per_doc pages of every document, picked by quality.stratified_sample (a seeded hash of doc_id|page): the same
    pages every time for the same documents and seed. Columns doc_id, page."""
    df = pd.DataFrame([{"doc_id": str(d), "page": p} for d, n in page_counts.items() for p in range(1, int(n) + 1)],
                      columns=["doc_id", "page"])
    if not len(df) or int(n_per_doc) < 1:
        return df.iloc[0:0]
    s = quality.stratified_sample(df, ["doc_id"], int(n_per_doc), seed, key=["doc_id", "page"])
    return s[["doc_id", "page"]].sort_values(["doc_id", "page"]).reset_index(drop=True)


# ------------------------------------------------------------------ the HTML report
_CSS = """
body{font:14px/1.45 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;background:#f4f5f7;color:#1d2330}
header.top{padding:16px 20px;background:#fff;border-bottom:1px solid #d9dce3}
header.top h1{font-size:20px;margin:0 0 6px}
.note{color:#545b6b;font-size:13px;margin:2px 0}
table.idx{border-collapse:collapse;margin:12px 20px;background:#fff;font-size:13px}
table.idx td,table.idx th{border:1px solid #d9dce3;padding:3px 8px;text-align:left;vertical-align:top}
section.pg{background:#fff;margin:16px 12px;border:1px solid #d9dce3;border-radius:6px}
section.pg>h2{font-size:16px;margin:0;padding:10px 14px;border-bottom:1px solid #d9dce3;position:sticky;top:0;
  background:#fff;z-index:1}
.grid{display:grid;grid-template-columns:minmax(320px,42%) minmax(280px,1fr) minmax(240px,26%);gap:12px;padding:12px}
@media (max-width:1100px){.grid{grid-template-columns:1fr}}
.img img{width:100%;border:1px solid #c9cdd6}
.sec{border-left:3px solid #2f6fdf;padding:2px 0 2px 10px;margin:0 0 14px}
.sec.skip{border-left-color:#a0a6b3;color:#6b7180}
.sec h3{font-size:14px;margin:0 0 2px}
.meta{font-size:12px;color:#545b6b;margin-bottom:4px}
.meta.late{color:#b42323;font-weight:600}
pre{white-space:pre-wrap;word-break:break-word;background:#f7f8fa;border:1px solid #e4e6eb;padding:8px;margin:4px 0;
  font:12.5px/1.45 Consolas,Menlo,monospace}
mark.code{background:#fff0a8;padding:0 1px}
mark.miss{background:#ffc9c9;padding:0 1px}
span.brk{color:#fff;background:#d23c3c;border-radius:3px;padding:0 3px;margin:0 1px;font-weight:bold}
.flag{border-left:4px solid #d23c3c;background:#fff4f4;padding:6px 8px;margin:0 0 8px;font-size:13px}
.flag.info{border-left-color:#a0a6b3;background:#f5f6f8}
.flag b{display:block;font-size:12px;letter-spacing:.02em}
.ok{color:#1d7a46;font-weight:600}
.badge{display:inline-block;font-size:11px;padding:1px 6px;border-radius:9px;background:#e7ebf3;margin-left:6px;
  font-weight:normal}
.badge.red{background:#ffd6d6}
details{margin:4px 0}summary{cursor:pointer;color:#2f5fb3;font-size:12.5px}
ul.lines{font-size:12.5px;margin:4px 0 0 16px;padding:0}
"""


def anchor(doc_id, page) -> str:
    return f"p-{re.sub(r'[^A-Za-z0-9]+', '_', str(doc_id))}-{int(page)}"


_BAR = '<span class="brk" title="policy_docs.sentence_spans() starts a new sentence here, inside a code list">||</span>'


def _marked(text: str, a: int = 0, b: int | None = None, breaks=(), miss=()) -> str:
    """text[a:b] as HTML: codes marked (the ones in `miss` in red), a red bar where a code list was cut into two
    sentences (`breaks`: offsets in `text` where the new sentence starts)."""
    b = len(text) if b is None else b
    events = sorted([(x, 0, None) for x in set(breaks) if a <= x <= b]
                    + [(m.start(), 1, m) for m in CODE_RE.finditer(text, a, b)], key=lambda e: (e[0], e[1]))
    out, pos = [], a
    for off, kind, m in events:
        if off < pos:
            continue
        out.append(html.escape(text[pos:off]))
        if kind == 0:
            out.append(_BAR)
            pos = off
        else:
            out.append(f'<mark class="{"miss" if m.group(0) in miss else "code"}">{html.escape(m.group(0))}</mark>')
            pos = m.end()
    out.append(html.escape(text[pos:b]))
    return "".join(out)


def _page_html(rec: dict) -> str:
    """One page of the report: image | text that reached the extractor | flags."""
    title = config.CHAPTERS.get(rec["doc_id"], ("", ""))[0]
    if rec.get("seed_reason"):
        title += " - " + rec["seed_reason"]
    n = rec["n_flags"]
    badge = f'<span class="badge{" red" if n else ""}">{n} flag{"s" if n != 1 else ""}</span>'
    sel = rec.get("selection", "")
    head = (f'<h2 id="{anchor(rec["doc_id"], rec["page"])}">Doc {html.escape(rec["doc_id"])} &middot; page {rec["page"]} '
            f'of {rec["n_pages"]} {badge}<span class="badge">{html.escape(sel)}</span>'
            f'<div class="meta">{html.escape(title)}</div></h2>')
    img = f'<div class="img"><img alt="page {rec["page"]}" src="data:image/png;base64,{rec.get("png_b64", "")}"></div>'
    # middle: what reaches the extractor
    mid = ['<div class="ext">']
    if not rec["sections"]:
        mid.append('<p class="meta">No section was built from this page.</p>')
    for v in rec["sections"]:
        mid.append(f'<div class="sec{"" if v["reaches_model"] else " skip"}"><h3>{html.escape(v["heading"])}</h3>'
                   f'<div class="meta">pages {v["page_start"]}-{v["page_end"]} &middot; '
                   f'{"reaches the model" if v["reaches_model"] else "SKIPPED by the pre-filter (no rule signal)"} &middot; '
                   f'{"heading on this page" if v["heading_here"] else "continues from an earlier page"}</div>')
        brk = v.get("breaks", [])
        if v["slice"]:
            mid.append(f'<pre>{_marked(v["text"], v["slice"][0], v["slice"][1], brk)}</pre>')
        for a, b in v["tables"]:
            late = (a, b) in v.get("late_tables", [])
            mid.append(f'<div class="meta{" late" if late else ""}">table row copy appended to this section (from this page)'
                       f'{" - on the page the table sits under another heading (see the flags)" if late else ""}:</div>'
                       f'<pre>{_marked(v["text"], a, b, brk)}</pre>')
        mid.append(f'<details><summary>whole section text ({len(v["text"]):,} characters)</summary>'
                   f'<pre>{_marked(v["text"], breaks=brk)}</pre></details></div>')
    mid.append("</div>")
    # right: flags, then what did not reach the extractor, then the raw text layer
    right = ['<div class="flags">']
    counted = [f for f in rec["flags"] if f["severity"] == "flag"]
    if not counted:
        right.append('<p class="ok">No automatic flag. Compare the image and the text yourself.</p>')
    for f in counted + [f for f in rec["flags"] if f["severity"] != "flag"]:
        right.append(f'<div class="flag{"" if f["severity"] == "flag" else " info"}"><b>{html.escape(f["check"])}'
                     f'{" (info)" if f["severity"] != "flag" else ""}</b>{html.escape(f["detail"])}</div>')
    gone = [x for x in rec["lines"] if x["status"] in ("header", "revision", "lost")]
    if gone:
        right.append('<details><summary>lines that do not reach the extractor as text '
                     f'({len(gone)})</summary><ul class="lines">'
                     + "".join(f'<li>[{x["status"]}] {html.escape(x["text"])}</li>' for x in gone) + "</ul></details>")
    right.append(f'<details><summary>raw text layer of the page</summary><pre>'
                 f'{_marked(rec["raw_text"], miss=set(rec["codes_missing"]))}</pre></details></div>')
    return f'<section class="pg">{head}<div class="grid">{img}{"".join(mid)}{"".join(right)}</div></section>'


def html_report(records: list[dict], title: str = "Page fidelity", notes: list | None = None) -> str:
    """One self-contained HTML page: an index of the pages, then per page the image | the text that reached the
    extractor | the automatic flags, side by side. Images are inline base64 PNGs; no external resources."""
    idx = ["<table class=idx><tr><th>doc</th><th>page</th><th>selected as</th><th>flags</th><th>sections</th></tr>"]
    for r in records:
        idx.append(f'<tr><td>{html.escape(r["doc_id"])}</td><td><a href="#{anchor(r["doc_id"], r["page"])}">{r["page"]}</a>'
                   f'</td><td>{html.escape(r.get("selection", ""))}</td><td>{html.escape(flag_summary(r)) or "-"}</td>'
                   f'<td>{html.escape(" | ".join(v["heading"][:40] for v in r["sections"]))}</td></tr>')
    idx.append("</table>")
    top = (f'<header class="top"><h1>{html.escape(title)}</h1>'
           + "".join(f'<p class="note">{html.escape(str(x))}</p>' for x in (notes or [])) + "</header>")
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" '
            f'content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><style>{_CSS}</style></head>'
            f'<body>{top}{"".join(idx)}{"".join(_page_html(r) for r in records)}</body></html>')


# ------------------------------------------------------------------ the gold sheet and the metric
# doc_pages (2026-10-04, critic P51-8): the document's page count - the weight of its random pages in the fair rate
GOLD_INFO_COLUMNS = ["sample_id", "corpus_version", "doc_id", "page", "doc_pages", "doc_hash", "selection", "seed_reason",
                     "report_anchor", "sections", "auto_flags", "auto_detail"]
GOLD_SCORE_COLUMNS = ["page_ok", "missing_text", "misattributed_text", "notes", "scorer"]
GOLD_COLUMNS = GOLD_INFO_COLUMNS + GOLD_SCORE_COLUMNS
GOLD_README = [
    "One row per page. Open the HTML report next to this sheet (report_anchor jumps to the page): the page image on the "
    "left, the text that reached the extractor in the middle, the automatic flags on the right.",
    "page_ok: Y if everything a reader needs from this page reaches the extractor, under the right heading, in an order "
    "that keeps its meaning (codes, numbers, which codes belong to which list or table row, conditions, exceptions). "
    "N if anything is lost, moved under another heading, or scrambled.",
    "missing_text: text on the page that does not reach the extractor (a few words of it are enough).",
    "misattributed_text: text that reaches the extractor under the wrong heading or out of order - say where it went.",
    "notes: anything else (a footnote inside a sentence, two columns read across, a list cut at a page break ...).",
    "scorer: your name, on every row you score. Leave page_ok blank rather than guessing - blanks are excluded.",
    "The automatic flags are hints, not answers: score what you see. Running page headers/footers and the REVISION "
    "DATES line are stripped on purpose; a heading with nothing under it is dropped on purpose.",
    "Do not add, remove or reorder rows or columns.",
]


def gold_frame(records: list[dict], sample_id: str, corpus_version: str | None = None) -> pd.DataFrame:
    """The sheet a person fills: one row per page, the page's automatic results, the score columns blank.
    corpus_version: policy_docs.corpus_version() of the documents the pages were drawn from (the rate's denominator);
    page_text_fidelity() refuses a sheet without one. doc_pages: the document's page count (the fair rate's weights)."""
    rows = []
    for r in records:
        rows.append({"sample_id": sample_id, "corpus_version": corpus_version, "doc_id": r["doc_id"],
                     "page": int(r["page"]), "doc_pages": int(r["n_pages"]), "doc_hash": r["doc_hash"],
                     "selection": r.get("selection", ""), "seed_reason": r.get("seed_reason") or None,
                     "report_anchor": "#" + anchor(r["doc_id"], r["page"]),
                     "sections": " || ".join(f"{v['heading']} (pp. {v['page_start']}-{v['page_end']}, to model: "
                                             f"{'Y' if v['reaches_model'] else 'N'})" for v in r["sections"]) or None,
                     "auto_flags": flag_summary(r) or None,
                     "auto_detail": quality.clip_text(" || ".join(f["detail"] for f in r["flags"]
                                                                  if f["severity"] == "flag")),
                     **{c: None for c in GOLD_SCORE_COLUMNS}})
    return pd.DataFrame(rows, columns=GOLD_COLUMNS)


def _selected(gold: pd.DataFrame, what: str) -> pd.Series:
    """Row mask: the page was picked as `what` (seed / random / flagged; 'seed+random' is both)."""
    sel = gold["selection"] if "selection" in gold else pd.Series([None] * len(gold), index=gold.index, dtype=object)
    return pd.Series([not quality._is_blank(v) and what in str(v).split("+") for v in sel], index=gold.index, dtype=bool)


def _doc_key(doc_id) -> str:
    """A document id as the sheet means it: '10', 10 and 10.0 are one document (an xlsx round trip changes the type)."""
    d = str(doc_id).strip()
    return str(int(float(d))) if re.fullmatch(r"\d+(?:\.0+)?", d) else d


def _page_key(doc_id, page) -> tuple:
    try:
        p = int(float(page))
    except (TypeError, ValueError):
        p = str(page).strip()
    return _doc_key(doc_id), p


def check_gold(gold: pd.DataFrame) -> dict:
    """Refuse a malformed GOLD sheet with a ValueError that says what to fix; else {"sample_id", "corpus_version",
    "pages"}. One sample: every row carries the same sample_id. One document set: every row the same corpus_version
    (the rate's denominator). Each page once: no two rows with the same doc_id and page (a duplicated row counted twice).
    2026-10-04 (critic P51-8): the ingest accepted all of these, the mixed ones with only a note."""
    if gold is None or not len(gold):
        raise ValueError("the GOLD sheet has no rows")
    out = {}
    for col, what in (("sample_id", "sample"), ("corpus_version", "document set (policy_docs.corpus_version)")):
        if col not in gold.columns:
            raise ValueError(f"the GOLD sheet has no {col} column: re-export it with v07 (EXPORT = True)")
        vals = ["" if quality._is_blank(v) else str(v).strip() for v in gold[col]]
        blank, distinct = sum(1 for v in vals if not v), sorted({v for v in vals if v})
        if blank:
            raise ValueError(f"{blank} of {len(vals)} row(s) of the GOLD sheet have no {col}: every row names its {what}. "
                             f"Re-export the sheet rather than editing it")
        if len(distinct) > 1:
            raise ValueError(f"the GOLD sheet mixes {len(distinct)} {col} values ({', '.join(distinct[:5])}): ingest one "
                             f"sample of one document set at a time")
        out[col] = distinct[0]
    lost = [c for c in ("doc_id", "page") if c not in gold.columns]
    if lost:
        raise ValueError(f"the GOLD sheet has no {' / '.join(lost)} column: re-export it with v07 (EXPORT = True)")
    keys = [_page_key(d, p) for d, p in zip(gold["doc_id"], gold["page"])]
    dups = sorted((k for k, c in Counter(keys).items() if c > 1), key=str)
    if dups:
        raise ValueError(f"the GOLD sheet has {len(dups)} page(s) more than once ("
                         + ", ".join(f"doc {d} page {p}" for d, p in dups[:10])
                         + "): each page is scored once - a duplicated row would count twice")
    out["pages"] = len(keys)
    return out


def page_text_fidelity(gold: pd.DataFrame) -> pd.DataFrame:
    """page_text_fidelity = pages scored page_ok = Y / pages scored Y or N, with a 95% interval.
    Rows (quality.METRIC_COLUMNS), each only when it has pages (overall and random always):
        overall   | all          every scored page pooled (seed and flagged pages are picked BECAUSE they are hard)
        sample    | random       the FAIR rate: pages drawn at random from each document, each document weighted by its
                                 length (quality.stratified_ratio: stratum = document, its size = doc_pages)
        sample    | seed         the known-ugly seed pages (a stress test, not a rate of the corpus)
        sample    | flagged      pages added because the automatic checks flagged them
        auto_flag | flagged      every scored page with an automatic flag (1 - value: a person also found a problem)
        auto_flag | not_flagged  every scored page without one (1 - value: a problem the checks missed)
        doc_id    | <doc>        the random pages of one document
    The random row's interval is stratified_ratio's; every other row is a plain pool with quality.wilson's interval.
    Blank page_ok is excluded and counted in notes; a value that is not Y/N counts as blank. A malformed sheet is refused
    (check_gold: duplicated pages, a blank or mixed corpus_version, mixed sample ids); its corpus_version (the document
    set the pages were drawn from) is stated in every row's notes."""
    g = gold.copy() if gold is not None and len(gold) else pd.DataFrame(columns=GOLD_COLUMNS)
    corpus = f" Corpus {check_gold(g)['corpus_version']}." if len(g) else ""
    g["_ok"] = g["page_ok"].map(quality._yn) if "page_ok" in g else None
    rows = []

    def row(scope_type, scope, sub, note, weighted=False):
        scored = sub[sub["_ok"].notna()]
        k = int((scored["_ok"] == True).sum())  # noqa: E712
        p, lo, hi = quality.wilson(k, len(scored))
        if weighted:
            # 2026-10-04 (critic P51-8): the same number of random pages from every document, pooled, let a page of a
            # 3-page exhibit count ~20x a page of a 60-page chapter, and the Wilson interval assumed a simple random sample
            sizes = scored["doc_pages"].tolist() if "doc_pages" in scored else [None] * len(scored)
            w = quality.stratified_ratio(pd.DataFrame({"stratum": [_doc_key(d) for d in scored["doc_id"]],
                                                       "stratum_size": pd.to_numeric(pd.Series(sizes, dtype=object),
                                                                                     errors="coerce").tolist(),
                                                       "y": [1 if v else 0 for v in scored["_ok"]], "x": [1] * len(scored)}),
                                         "y", "x")
            p, lo, hi = w["value"], w["ci_low"], w["ci_high"]
            note += f" ({w['notes'] or 'no scored page'}; effective sample size {w['n_eff']:g})."
        blank = len(sub) - len(scored)
        rows.append({"metric": "page_text_fidelity", "scope_type": scope_type, "scope": str(scope), "n": int(len(scored)),
                     "value": p, "ci_low": lo, "ci_high": hi,
                     "notes": (f"{k} of {len(scored)} scored page(s) OK. " + (f"{blank} unscored page(s) excluded. " if blank
                               else "") + note + corpus).strip()})

    rnd = g[_selected(g, "random")]
    row("overall", "all", g, "Pooled over random, seed and flagged pages; seed and flagged pages are chosen because they "
                             "are hard, so this is not a rate of the corpus (use sample=random).")
    row("sample", "random", rnd, "Pages drawn at random (seeded hash) from each document, weighted by document length "
                                 "(quality.stratified_ratio: stratum = document, size = its page count)", weighted=True)
    for what, note in (("seed", "Known-ugly seed pages: a stress test, not a rate of the corpus."),
                       ("flagged", "Pages added because the automatic checks flagged them.")):
        sub = g[_selected(g, what)]
        if len(sub):
            row("sample", what, sub, note)
    flags_col = g["auto_flags"] if "auto_flags" in g else pd.Series([None] * len(g), index=g.index, dtype=object)
    has_flag = pd.Series([not quality._is_blank(v) for v in flags_col], index=g.index, dtype=bool)
    for scope, sub, note in (("flagged", g[has_flag], "Every page with an automatic flag; 1 - value = the share of "
                                                      "flagged pages on which a person also found a problem."),
                             ("not_flagged", g[~has_flag], "Every page without an automatic flag; 1 - value = the share "
                                                           "of unflagged pages with a problem the checks missed.")):
        if len(sub):
            row("auto_flag", scope, sub, note)
    if len(rnd):
        for d, sub in rnd.groupby(rnd["doc_id"].astype(str), sort=True):
            row("doc_id", d, sub, "Random pages of this document.")
    return pd.DataFrame(rows, columns=quality.METRIC_COLUMNS)
