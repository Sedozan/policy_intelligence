# PIE — work log and checklist

## 2026-10-04 — v5.2: the AHCCCS rule tables (Same Day Disallow, daily limits, B2 matrix)

- [x] Reader `ahcccs_tables.py` + notebook 00b: layout by header text (any file name), version date from the sheet, merged cells expanded, red = changed, refuses what it cannot read exactly (incl. content right of the last column); each file a dated version; never replaces a loaded version; archive + log (row count, rows hash)
- [x] SB's readings in `reference/ahcccs_table_readings.csv` (13 + 1 new), proposed; nothing compiles until all of a table's are signed; `binds` ties a reading to the config value it describes
- [x] Rules: Same Day (D any provider, A* same provider, row code = finding, note 2 → verify_exception, diagonal / A no rule), daily limits (units per member + provider + day; two-daily-limit, anesthesia, all-nines rows recorded), B2 (H0xxx / H2xxx complete list); scoped to paid codes; TBL- ids stable across versions
- [x] Query layer: three table-driven statements, each multiset-equal to the per-rule SQL (Spark tests on random claims); 07 / 08 / v06 / v03 / 01 wired; `policy_ahcccs_conflicts`
- [x] QUERY_SEMANTICS v2.5 (§2b) → independent table oracle (0 mismatches; found 4 frame-level gaps, now refused)
- [x] Independent critic of v5.2 (18 findings; reader matched the real files exactly) → v2.6 fixes, each verified first: group billing judged on the rendering type (F1), anesthesia / all-nines maxima not compiled (F2), `verify_span` (F3), both-ways pairs labelled + dollars counted twice reported (F4), same servicing AND billing provider (F5), trailing columns refused (F6), 07 load check (F7), readings bound to config (F8), sign-off bar / dated coverage / stale tables (F9 / F10 / F12), `verify_modifier` (F15), F11 / F16 / F17 / F18
- [x] Lead fix: findings carry `billing_provider` (two daily groups differing only in billing id shared a finding_id); `test_offline` no longer leaves a fake pyspark that silently skipped the oracle Spark tests
- [x] Both oracles updated to v2.6 from the spec (general 7,011 / table 14,878 findings at 3x, 0 mismatches)
- [x] Critic re-check of the fixes: 13 fixed, 4 partial, F13 to SB; N1 required binds, N2 unjudgeable lines counted (01, run log) + B2 exposure in 01 before signing, N3 stated, N4 labels on payable lines (oracles updated, 0 mismatches), N5 both-ways dollars per member-day, N6 noted
- [x] Final: offline 716; Spark 94; oracles 52 + 74 (default) re-run on the final code; e2e 160 checks incl. load, gate, every planted table case, tamper → 07 stops
- [x] SB workbook `ahcccs_tables_review_v52.xlsx`: readings, 43 conflicts with the reviewed rules, 410 rows not compiled, 104 both-ways pairs
- [ ] SB: sign the readings (5 carry post-review choices); which line AHCCCS denies in a both-ways pair; servicing vs billing for "same provider" (ask AHCCCS for the 2/27/2026 A* guidance); H0035 B2 vs B6
- [ ] SB: get AHCCCS's earlier versions of the three tables (claims before 9/14 / 10/1/2026 are not judged by them); 10 of the 14 "table allows" conflicts are cells changed on 10/1/2026
- [ ] Boss: re-validate the state daily caps and the three table statements in v06 (their SQL changed)

## 2026-10-04 — v5.1: the external review (ChatGPT), two critics, one engine in the KB

- [x] Checked every point of ChatGPT's review against the code and the sources before changing anything (most held; see docs/V5_CHANGES.md "v5.1")
- [x] Recall = real rules found ÷ (found + missed); executable-rule precision; filter loss (DROPPED sheet); pass marks on the lower 95% bound (precision ≥ 0.95, recall ≥ 0.90, fidelity ≥ 0.95)
- [x] v05 gate: DANGER 0 AND no unadjudicated executable draft; reversed pair = DANGER; unreviewed variants counted; each run gated on all its chapters; A/B (`RUN_DIR_B`) is a comparison
- [x] Corpus: 5 FFS exhibits (36 files); `corpus_version` on builds, metrics and runs; `CORPUS_PENDING` lists what is not loaded
- [x] NCCI: unmapped provider types → no NCCI; 08 runs NCCI only on signed routing for every observed provider type (`ncci_routing` on every NCCI finding, `partial_run` when held back); 01 lists the codes to sign; build log: CMS file sizes vs edits executable against these claims
- [x] Page fidelity check (`page_fidelity.py`, v07); 4 reader defects it found fixed
- [x] Critic M51 (measurement, 11) and P51 (PDF reader, 10): every finding reproduced by a failing test, fixed, planted back and caught
- [x] One engine in the KB (SB): hand-authored rules = v05 checklist (never exported / compiled); extracted rules compile only from prompt-v2 runs; a decided rule the new run reproduces names that run
- [x] 08 crash on a first run with NCCI held back (findings table missing) — found by the e2e, fixed
- [x] Verified: 571 offline, 76 Spark 4, oracle 46, e2e 129 checks, simulation 107 checks
- [ ] SB: fresh re-extraction (03 → 04 with all 36 files → 05); v05 against the v5 workbook (+ low vs medium on the gold chapters); v01 and v07 scoring samples
- [ ] SB / boss: sign the routing table for the provider types in the claims (01 lists them) — NCCI does not run until then
- [ ] SB: attach the Same Day Disallow table, daily limits and B2 matrix (xlsx); ask AHCCCS for the RISSNET NCCI files
- [ ] Re-check against real PDFs in Databricks: v07 on a page sample (the reader changes were tested on synthetic and LibreOffice-made pages only)

## 2026-10-03 (evening) — v5 with BProv_Type: billing-type routing and provider-type rules

- [x] NCCI routing by the BILLING provider type (BProv_Type; CMS TGM §5.3 "claims ... from" a type of provider), falling back to SProv_Type, then the form; SProv_Type decides "rendering practitioner identified" (Table 2's CMS-1500 column; only the optional "other providers" row uses it); `NCCI_ROUTE_BY = "billing_provider_type"` (default) | `"provider_type"` | `"form"`
- [x] Dentists (07) are physician practitioners (TGM Table 2 footnote 14): a dentist's CMS-1500 takes the practitioner file; dental claims none
- [x] `provider_type_allowed` compiles: "billed only by these provider types" → `provider_type_not_allowed`; billing role by default; unknown type never flagged; list entries cleaned like the column
- [x] The text NONE / NAN / NULL in a provider type column = missing (oracle S07/S08); only spaces trimmed (as SQL TRIM)
- [x] Cancellation order deterministic for rows of one claim line (oracle v2.2 tie case)
- [x] Spark generated code > 64 KB in the snapshot's DISTINCT (simulation): clean-up made linear, codes cleaned once, edit file from the cleaned columns; raw-table callers (01, 07, gap) use `ncci_routing.routed_sql`; tests, simulation and e2e run with `spark.sql.codegen.fallback = false` so it can never come back silently
- [x] QUERY_SEMANTICS v2.2 → v2.3 (billing routing; provider-type rule; points the oracle found loose: F-05 edit file never splits a finding, tie order, KNOWN type, units of one-line findings, textual nulls)
- [x] Independent oracle updated from the spec alone (agent, never read the SQL): green at default and larger scale; re-run by Claude on the final code
- [x] Mutation batch 4 (17 mutants of this change) — `docs/V5_CHANGES.md` §5
- [x] Workbook v5: H0035 Fix (from 2024-07-08: Ch19 revision table "Added Partial Hospitalization Programs (PHP) section"; billing role written out); A0110 Reject for now ("include" may not be the complete list)
- [x] Simulation v5 (strict codegen): 61 state + 2 NCCI + 4 signals = 67 queries; every planted case behaves; pack all PASS
- [x] BProv_Type distinct levels from SB (70 codes + NULL): all in the routing table; column `billing_in_claims_2026_10_04`; 01 group ID only bills, 10 types only render
- [x] v05 regression scoring fixed for a re-extraction against the consolidated workbook: curated rules scored as rules to find (they had no quote and could never match), Fix rows with corrected dates, duplicate rejects no longer false DANGER, provider-type rules compared; baseline of the first run computed
- [x] Engine: a '.' inside a code list no longer ends the sentence (Ch.19's S5151 list has "S5150. T1019. H0031,"): the deterministic list reader now gives all 21 S5151 pairs (was 17) and all 13 T1016 pairs - 34 of the 41 hand-written queries come out of the engine itself
- [ ] FRESH START (SB's direction, 2026-10-04): only rules from one engine version in the KB. SB re-extracts all chapters (03 → 04 → 05); v05 scores the run against the v5 workbook, the hand-written rules serving only as a test checklist; v6 workbook from the fresh run, reviewed dates carried over; hand-written rules leave the KB (5 by-design losses: S5150 2,400 units, H2016/S9485 + S5151, 99213 + 99238/99239)
- [ ] SME: is the A0110 provider type list complete? (then approve; or check which BProv_Type codes bill A0110)

## 2026-10-02 / 03 — v5: are the queries right, and would we know if one were wrong?

### Critique (independent agents) and fixes
- [x] C1 SQL detectors (22 findings), C2 NCCI (25 + 12 confirmed correct), C3 extraction (20), C4 governance (19) — disposition in `docs/V5_CHANGES.md` §4
- [x] Implementers WA (NCCI ingest), X (extraction prompt v2 + post-checks), Y (NCCI acquisition + preflight), Z (review governance); every patch re-tested before merge
- [x] `docs/QUERY_SEMANTICS.md`: the written contract every query meets (v2.1)
- [x] Independent oracle (agent O) from the contract alone: found R-01, F-01..F-04 → fixed; round 2 strict pass (135 claim sets, 1,106 queries, 2,615 findings, 228 signal rows); kept as `tests/test_sql_oracle.py`
- [x] Policy re-read (agent P) of the 21 compiled rules against the live PDFs: 9 agree, 11 disagree, 1 cannot verify → workbook v3
- [x] Independent re-read of the 59 hand-authored rules (agent S): 18 agree, 40 disagree (mostly dates and the flagged line), 1 cannot verify; evidence re-checked by Claude (Ch19 revision table, the 10/01/2021 Ch19, DES/DDD respite notice, AMPM 1250-D, CHW newsletter 04/2023 and FAQ 7/17/24, Ch14 Example 3) → `state_seed.py` corrected, workbook v4
- [x] Mutation testing: 63 planted defects, 62 caught by the suite as it stood; the survivor (Q34) and the earlier survivors got killer tests (`docs/V5_CHANGES.md` §5)

### Query layer
- [x] NCCI edit file per line by SProv_Type CODE × FORM_TYP (CMS TGM Table 2); `reference/ncci_provider_type_routing.csv` (140 types, proposed; checked against the 79 SProv_Type codes in all_data_C_A, 5 added); editions never merged
- [x] Snapshot: reversal units negative; $0 lines never count; duplicates once; blank keys missing; codes/modifiers normalised
- [x] Evidence distinct, numeric line order (also for a text LN_NO); `pa_present` NULL when not evaluated; NCCI scope always per provider
- [x] Rolling-window utilization signals for period limits (not findings)
- [x] Every signed state rule compiles (`STATE_RULES_CLAIMS_SCOPE = False`)
- [x] 40 new hand-authored rules (Ch19 S5151 per-diem and T1016 pairs, S5150 600 h/yr, A0382/A0398/S9484 caps, 99213+99239, J1055), each with a verbatim quote

### Governance
- [x] `reopen = yes` path for decided rules; approvals bound to the predicate signed
- [x] Hand-authored rules need a signature (`COMPILE_LEGACY_SEEDS = False`)
- [x] Every query stored with its sha256 (state, NCCI, signal); 08 refuses edited or UNHASHED SQL (`run_guard.py`)
- [x] Validator decisions binding: PROBLEM never runs; `RUN_ONLY_VALIDATED_QUERIES`; findings carry `query_validation`
- [x] v06 query validation pack (plain English + SQL + scenarios per query); simulated pack: 69 queries, 547 scenarios, all PASS

### Deliverables
- [x] `policy_rules_review_AI_prereview_v4.xlsx` (301 rows: 242 extracted + 59 hand-authored; AI pre-review, unsigned; changes_v4 + changes_v3 sheets)
- [x] `query_validation_pack_SIMULATED_v4.xlsx` (66 queries, 579 scenarios, all PASS — local simulation)
- [x] Deck: age is checked from date_of_birth (slide "Details that decide if a flag is right")

### Open (need SB / the boss)
- [ ] Sign the routing table, the v4 workbook, and the queries (v06; a sample first is fine)
- [ ] Optional NCCI Table 2 rows (testing facilities; other outpatient incl. FQHCs) — off until decided
- [ ] Attach AHCCCS Same Day Disallow Table (xlsx, 10/01/2026)
- [ ] Confirm EVENT_PA_NO = approved PA; all_data_C_A is FFS only; LN_NO type; paid ≤ billed units
- [ ] SME: Ch19 effective dates; 99070 (Ch10 p.47); holds S5150 48/day, T1015, W2404–06
- [ ] Not in the data: service end date (multi-day MUE); Arizona RISSNET deactivations; adjustment key for reversals


## 2026-09-29 — make the pipeline work as expected, clean notebooks, demos

### Pipeline fixes (from GAP_TO_DONE.md)
- [x] D1 HYBRID cached unparseable model output as "no rules" → tolerant parse, retryable, never cached (subagent; verified by probe)
- [x] D2 grounding: min quote length, codes-near-quote flag, truncated-condition flag, source text stored (not model text), word-number drift, no quote overwrite in HYBRID merge (subagent; verified by probe)
- [x] D2b provenance column `extraction_source`; D11 per-section outcomes table `policy_extraction_outcomes`
- [x] D3 PTP direction kept across editions
- [x] D4 overlapping edition windows split into segments, collapsed per segment; `reconciliation` label
- [x] D5 new document version → approvals go to `needs_review` with `prior_review`; build excludes approvals from an older doc_hash
- [x] D6 migrate upserts seeds (never overwrites); review ingest: pending-only, doc_hash required, table written before log, shrink guard
- [x] D7 coverage counts compiled, in-window detectors only; `state_leads` column; summary table saved
- [x] D8 `build_id` on rules/detectors/findings; `*_history` tables; NCCI rule ids stable across quarters
- [x] D9 NCCI ingest fails loudly (no tables, bad modifier, missing eff date, non-numeric MUE); `config.NCCI_STRICT`
- [x] D10 `config.NCCI_DELETION_DATE_INCLUSIVE` switch (semantics still UNVERIFIED — SB to confirm)
- [x] Detection at scale: NCCI PTP + MUE table-driven (2 SQL statements), no 300 cap; equivalence-tested vs per-rule SQL on 5 random seeds
- [x] Findings carry `paid_amt`, `pa_status`, `origin`, `predicate_type`, `extraction_key`, `build_id`
- [x] State pairs evaluate PA on either line; daily caps accept `code_set`
- [x] Seed vs extracted duplicates collapse to the extracted rule (`supersedes` recorded)
- [x] Registers: `policy_ambiguity_register`, `policy_rule_overlaps` (contradiction candidates)
- [x] Superseded PDFs archived to `policy_docs/_versions/`
- [x] Bug found by e2e: all-null reviewer column → float64 → assignment fails (pandas 3); fixed
- [x] Bug found by e2e: `policy_review_log` text columns created as DOUBLE from empty cells → first real note would fail the append; fixed + notebook 06 checks an existing table and prints the repair
- [x] Bugs reported by demo subagent: quote not carried to policy_rules; MUE doc_version cited only the first quarter; v04 stale text/CSV path — fixed and pinned
- [x] Extracted rules get `EXT-` ids (were `MAN-`, read as hand-authored)

### Notebooks
- [x] Removed `extract_chapters` (single-cluster GPU+UC path; SB's GPU cannot write Delta), `diag_model` (serving-endpoint route, unused), `demo_kb` (split into demos/)
- [x] Numbered in run order 00–08; `profile_chapters` → `validation/v04_chapter_profile`
- [x] demos/ (9) and validation/ (v01–v03 new, v04 moved) notebooks + `quality.py` (subagent; re-run and verified)
- [x] README rewritten around the true run order; historical docs → docs/

### Verification
- [x] 148 offline tests
- [x] `tests/e2e_local_spark.py`: every pipeline notebook, in order, on local Spark 3.5 (ANSI on) — ALL CHECKS PASSED
- [x] e2e with `--demos` — ALL CHECKS PASSED (independently re-run)

### Open (need SB)
- [ ] Confirm PTP deletion-date semantics (D10)
- [ ] `COMPILE_LEGACY_SEEDS` — keep the 21 unsigned seeds compiling? (default True = unchanged behaviour)
- [ ] DME service token in existing NCCI table names (`dme` assumed)
- [ ] First real HYBRID run: Ch19 only, then score with validation/v01

## 2026-09-28 — gap audit + NCCI automation
- [x] Four-way audit vs definition-of-done → GAP_TO_DONE.md
- [x] `acquire_ncci.py` + notebook (drop zone / download, archive, validate, log)
