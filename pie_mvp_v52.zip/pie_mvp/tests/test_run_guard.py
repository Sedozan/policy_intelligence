"""What 08 checks before it runs a query (run_guard.py). Three of these checks lived only inside the notebook and
nothing tested them: mutants that switched off the per-rule / batch hash check, the signal hash check, or the
one-build check all survived the red-team run of 2026-10-02 (R01-R03). A statement with NO hash used to skip the
check entirely. Run: cd pie_mvp && python -m pytest tests/test_run_guard.py -q"""
import os
import sys

import numpy as np
import pandas as pd
import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import config  # noqa: E402
import detector_gen as dg  # noqa: E402
import run_guard as rg  # noqa: E402

B = "B20261003T000000"
SQL1, SQL2, SIG, PTP = "SELECT 1 AS a", "SELECT 2 AS a", "SELECT 3 AS s", "SELECT 4 AS p"


def _det(over=None):
    rows = [{"rule_id": "EXT-1", "compiled": True, "sql": SQL1, "sql_sha256": dg.sql_sha256(SQL1),
             "signal_sql": SIG, "signal_sql_sha256": dg.sql_sha256(SIG), "build_id": B},
            {"rule_id": "EXT-2", "compiled": True, "sql": SQL2, "sql_sha256": dg.sql_sha256(SQL2),
             "signal_sql": None, "signal_sql_sha256": None, "build_id": B},
            {"rule_id": "EXT-3", "compiled": False, "sql": None, "sql_sha256": None, "signal_sql": None,
             "signal_sql_sha256": None, "build_id": B}]
    for (i, k), v in (over or {}).items():
        rows[i][k] = v
    return pd.DataFrame(rows)


def _batches(sql=PTP, sha=None):
    return pd.DataFrame([{"batch": "ncci_ptp", "sql": sql, "sql_sha256": dg.sql_sha256(PTP) if sha is None else sha,
                          "rules": 10, "build_id": B}])


LOG = pd.DataFrame([{"build_id": B, "status": "complete"}])
IDS = {"policy_detectors": {B}, "policy_batch_detectors": {B}, "policy_ncci_ptp_edits": {B}}


def test_a_clean_build_has_no_problems():
    assert rg.build_problems(_det(), _batches(), IDS, LOG, B) == []


@pytest.mark.parametrize("over,needle", [
    ({(0, "sql"): SQL1 + " "}, "SQL of EXT-1 does not match"),                    # R02: an edited state query
    ({(0, "signal_sql"): "SELECT 9 AS s"}, "SQL of SIGNAL:EXT-1 does not match"),  # R01: an edited signal query
    ({(1, "sql_sha256"): None}, "EXT-2 has no sql_sha256"),                       # a blank hash switched the check off
    ({(1, "sql_sha256"): "nan"}, "EXT-2 has no sql_sha256"),
    ({(0, "signal_sql_sha256"): ""}, "SIGNAL:EXT-1 has no sql_sha256"),
])
def test_an_edited_or_unhashed_statement_stops_the_run(over, needle):
    probs = rg.build_problems(_det(over), _batches(), IDS, LOG, B)
    assert len(probs) == 1 and needle in probs[0], probs


def test_an_edited_or_unhashed_batch_statement_stops_the_run():
    assert "BATCH:ncci_ptp does not match" in " ".join(rg.build_problems(_det(), _batches(sql=PTP + "--x"), IDS, LOG, B))
    assert "BATCH:ncci_ptp has no sql_sha256" in " ".join(rg.build_problems(_det(), _batches(sha=""), IDS, LOG, B))


def test_mixed_or_unfinished_builds_stop_the_run():                                 # R03 / C4-01
    mixed = dict(IDS, policy_ncci_ptp_edits={B, "B_OLD"})
    assert any("policy_ncci_ptp_edits holds build(s)" in p for p in rg.build_problems(_det(), _batches(), mixed, LOG, B))
    started = pd.DataFrame([{"build_id": B, "status": "started"}])
    for log in (started, pd.DataFrame(columns=["build_id", "status"]), None):
        assert any("no 'complete' row" in p for p in rg.build_problems(_det(), _batches(), IDS, log, B))
    assert rg.build_problems(_det(), _batches(), dict(IDS, policy_ncci_mue_limits=set()), LOG, B) == []   # empty table ok


def test_compiled_flags_read_back_as_numpy_or_text_still_count():
    d = _det({(0, "sql"): SQL1 + " "})
    d["compiled"] = [np.bool_(True), np.bool_(True), np.bool_(False)]
    assert any("EXT-1" in p for p in rg.build_problems(d, None, IDS, LOG, B))
    d["compiled"] = ["true", "true", "false"]
    assert any("EXT-1" in p for p in rg.build_problems(d, None, IDS, LOG, B))


def test_current_hashes_use_the_pack_ids():
    cur = rg.current_hashes(_det(), _batches())
    assert set(cur) == {"EXT-1", "EXT-2", "SIGNAL:EXT-1", "BATCH:ncci_ptp"}
    assert cur["SIGNAL:EXT-1"] == dg.sql_sha256(SIG)


def _qv(rows):
    return pd.DataFrame(rows, columns=["query_id", "sql_sha256", "validator", "validator_decision", "validated_at"])


def test_validation_status_is_the_latest_decision_on_the_current_sql():
    cur = rg.current_hashes(_det(), _batches())
    h1, h2 = cur["EXT-1"], cur["EXT-2"]
    qv = _qv([("EXT-1", h1, "Boss", "OK", "2026-10-03T09:00:00"),
              ("EXT-1", h1, "Boss", "problem", "2026-10-03T10:00:00"),       # latest wins, any case
              ("EXT-2", "0" * 64, "Boss", "PROBLEM", "2026-10-03T11:00:00"),  # older SQL: does not count
              ("EXT-2", h2, "Boss", "OK", "2026-10-02T08:00:00"),
              ("BATCH:ncci_ptp", cur["BATCH:ncci_ptp"], "Boss", "maybe", "2026-10-03T12:00:00"),   # not a decision
              ("EXT-404", h1, "Boss", "OK", "2026-10-03T12:00:00")])          # not in this build
    st = rg.validation_status(qv, cur)
    assert st == {"EXT-1": "PROBLEM", "EXT-2": "OK", "SIGNAL:EXT-1": "not_validated", "BATCH:ncci_ptp": "not_validated"}
    assert rg.validation_status(None, cur) == {q: "not_validated" for q in cur}
    assert rg.validation_status(_qv([]), cur) == {q: "not_validated" for q in cur}


def test_problem_never_runs_and_only_validated_runs_only_ok(monkeypatch):
    monkeypatch.setattr(config, "RUN_ONLY_VALIDATED_QUERIES", False)
    assert rg.skip_reason("PROBLEM") and rg.skip_reason("OK") is None and rg.skip_reason("not_validated") is None
    monkeypatch.setattr(config, "RUN_ONLY_VALIDATED_QUERIES", True)
    assert rg.skip_reason("PROBLEM") and rg.skip_reason("not_validated") and rg.skip_reason("OK") is None


# ------------------------------------------------------------------ signed NCCI routing (2026-10-04 external review)
def _routing(signed):
    """A tiny routing table: 08 physician, 19 clinic, 41 DME; `signed` = the codes with a signed row."""
    rows = [{"sprov_type": "08", "cms_category": "practitioner"}, {"sprov_type": "19", "cms_category": "other_outpatient"},
            {"sprov_type": "41", "cms_category": "dme"}]
    for r in rows:
        ok = r["sprov_type"] in signed
        r.update(status="signed" if ok else "proposed", reviewer="SB" if ok else "")
    return rows


def test_ncci_runs_only_on_signed_routing_for_every_observed_type(monkeypatch):
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    monkeypatch.setattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True)
    assert rg.ncci_routing_gate(["08", "41"], _routing({"08", "41"})) is None              # all observed signed
    assert rg.ncci_routing_gate([], _routing(set())) is None                                # nothing observed
    why = rg.ncci_routing_gate(["08", "19", "41"], _routing({"08", "41"}))
    assert why.startswith("not run: 1 provider type code(s)") and "(19)" in why            # 19 is proposed only
    why = rg.ncci_routing_gate(["08", "77"], _routing({"08"}))
    assert "(77)" in why                                                                     # not in the table at all
    # the codes are read as the table keys them: '8' / '8.0' = 08; blank and NONE / NAN / NULL text are missing
    assert rg.ncci_routing_gate(["8", "8.0", None, "", "NONE", "nan"], _routing({"08"})) is None
    assert "(19)" in rg.ncci_routing_gate([" 19", "08"], _routing({"08"}))
    # a status of 'signed' with no reviewer is not a signature
    t = _routing({"08"})
    t[0]["reviewer"] = " "
    assert "(08)" in rg.ncci_routing_gate(["08"], t)


def test_the_signed_routing_gate_lists_at_most_20_codes_and_can_be_switched_off(monkeypatch):
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    monkeypatch.setattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True)
    many = [f"{i:02d}" for i in range(10, 35)]
    why = rg.ncci_routing_gate(many, _routing(set()))
    assert "25 provider type code(s)" in why and "(+5 more)" in why
    monkeypatch.setattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", False)
    assert rg.ncci_routing_gate(many, _routing(set())) is None


def test_routing_by_form_only_has_nothing_signed(monkeypatch):
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "form")
    monkeypatch.setattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True)
    assert "claim form only" in rg.ncci_routing_gate([], _routing({"08"}))
    assert rg.ncci_routing_kind([], _routing({"08"})) == "form_only"
    monkeypatch.setattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", False)
    assert rg.ncci_routing_gate([], _routing(set())) is None


def test_the_form_fallback_for_unmapped_types_is_a_guess_nobody_signed(monkeypatch):
    """Critic M51-8: with NCCI_UNMAPPED_PROVIDER_TYPE = 'form' a line with NO provider type is routed by its form,
    but observed_types_sql drops NULL types - so a fully signed table let NCCI run on that guess."""
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    monkeypatch.setattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True)
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "form")
    assert rg.ncci_routing_kind(["08"], _routing({"08"})) == "form_fallback"
    assert "NCCI_UNMAPPED_PROVIDER_TYPE = 'form'" in rg.ncci_routing_gate(["08"], _routing({"08"}))
    assert "NCCI_UNMAPPED_PROVIDER_TYPE = 'form'" in rg.ncci_routing_gate([], _routing({"08"}))
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "none")
    assert rg.ncci_routing_kind(["08"], _routing({"08"})) == "signed" and rg.ncci_routing_gate(["08"], _routing({"08"})) is None
    assert rg.ncci_routing_kind(["08", "19"], _routing({"08"})) == "unsigned"


def test_the_shipped_routing_table_is_unsigned_so_ncci_waits_for_a_signature(monkeypatch):
    """The package ships the PROPOSED table: by default 08 does not run NCCI until SB / the boss sign the rows for the
    provider types in the claims (the env switch PKB_NCCI_REQUIRE_SIGNED_ROUTING=0 is for exploratory runs)."""
    import ncci_routing
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    monkeypatch.setattr(config, "NCCI_REQUIRE_SIGNED_ROUTING", True)
    rows = ncci_routing.load_table()
    assert not any(ncci_routing.is_signed(r) for r in rows)
    observed = [r["sprov_type"] for r in rows if (r.get("billing_in_claims_2026_10_04") or "").lower() == "yes"]
    assert len(observed) == 70
    assert "70 provider type code(s)" in rg.ncci_routing_gate(observed)


def test_observed_types_sql_reads_the_ncci_forms_and_the_roles_routing_uses(monkeypatch):
    import ncci_routing
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    sql = ncci_routing.observed_types_sql("snap", "FORM_TYP")
    assert "pie_prov_type" in sql and "pie_bprov_type" in sql and "IN ('A','O')" in sql and "t IS NOT NULL" in sql
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "provider_type")
    sql = ncci_routing.observed_types_sql("snap", "FORM_TYP")
    assert "pie_prov_type" in sql and "pie_bprov_type" not in sql
