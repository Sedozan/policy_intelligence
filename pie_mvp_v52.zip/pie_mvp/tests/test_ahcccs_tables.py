"""AHCCCS rule tables (contract v5.2, 2026-10-04): ahcccs_tables.py, reference/ahcccs_table_readings.csv,
notebooks/00b_load_ahcccs_tables, check T of 01_preflight_ncci and the corpus bar of v03 - offline, no Spark.

  (a) the REAL files AHCCCS published (Same Day Disallow 10/1/2026, Daily Limits 9/14/26, B2 Matrix 10/1/26): every
      number the parse must reproduce. Skipped when /home/claude/ahcccs_tables is absent (env PKB_AHCCCS_REAL_DIR
      points elsewhere).
  (b) small synthetic workbooks built here with openpyxl in each layout (a red cell, merged cells, the report's junk
      last row): parse, refusals, version windows, rules_from_frames (predicates / statements / citations / windows /
      claims scope), the readings gate, table_conflicts.
  (c) notebook 00b run from SOURCE against the in-memory catalog of tests/nbfake_m51.py: a second run of the same file
      is already_loaded, a newer version adds a window, a bad file is rejected with a log row and nothing else written.
  v5.2b (2026-10-04, the independent critic's fixes, contract CONTRACT_v52b_fixes.md role A): A* / daily scope and the
  B2 provider role from config (F5, F1), anesthesia / all-nines daily rows not compiled (F2), both_ways pairs (F4),
  nothing right of a table's last column (F6), rows_sha256 + check_loaded in 00b / 01 check T (F7), readings bound to
  config values (F8), a readings CSV with a byte-order mark (F16), skipped drop-zone folders said (F17).
Run: cd pie_mvp && python -m pytest tests/test_ahcccs_tables.py -q
"""
import ast
import csv
import json
import os
import shutil
import sys
from datetime import datetime, time

import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, PKG)
sys.path.insert(0, HERE)

import openpyxl  # noqa: E402
from openpyxl.styles import Font  # noqa: E402

import ahcccs_tables as at  # noqa: E402
import config  # noqa: E402
import nbfake_m51 as nbf  # noqa: E402
import policy_docs  # noqa: E402
import quality  # noqa: E402
import schema  # noqa: E402
import validate_gate  # noqa: E402

REAL_DIR = os.environ.get("PKB_AHCCCS_REAL_DIR", "/home/claude/ahcccs_tables")
REAL_FILES = {"same_day_disallow": "SameDayDisallowTable.xlsx", "daily_limits": "HCPCSCPTProcedureswithDailyLimits.xlsx",
              "b2_matrix": "B2Matrix.xlsx"}
NBSP, NNBSP = "\xa0", "\u202f"
TBL_LANDED = schema.stable_rule_id({"origin": "ahcccs_table"}).startswith("TBL-")


# ====================================================================================== (a) the real files
_REAL: dict = {}


@pytest.fixture(scope="module")
def real():
    if not all(os.path.exists(os.path.join(REAL_DIR, f)) for f in REAL_FILES.values()):
        pytest.skip(f"the real AHCCCS files are not in {REAL_DIR} (set PKB_AHCCCS_REAL_DIR)")
    if not _REAL:
        for key, fn in REAL_FILES.items():
            _REAL[key] = at.parse_file(os.path.join(REAL_DIR, fn))
    return _REAL


def test_real_files_are_recognised_by_their_headers_and_dated_by_their_own_text(real):
    for key, got in real.items():
        assert got["table_key"] == key                       # recognised by header text, not the file name
    assert (real["same_day_disallow"]["version_date"], real["same_day_disallow"]["sheet"]) == ("2026-10-01",
                                                                                             "1012026 Effective Date")
    assert real["same_day_disallow"]["stats"]["version_text"] == "Updated: 10/1/2026"
    assert (real["daily_limits"]["version_date"], real["daily_limits"]["sheet"]) == ("2026-09-14", "September 2026")
    assert real["daily_limits"]["stats"]["version_text"] == "Report As of 9/14/26"
    assert (real["b2_matrix"]["version_date"], real["b2_matrix"]["sheet"]) == ("2026-10-01", "October 2026")
    assert real["b2_matrix"]["stats"]["version_text"] == "As of 10/1/26"
    for got in real.values():
        assert list(got["frame"].columns) == at.TABLE_COLUMNS[got["table_key"]]
        assert set(got["frame"]["file_sha256"]) == {got["file_sha256"]} and len(got["file_sha256"]) == 64


def test_real_same_day_disallow_numbers(real):
    got = real["same_day_disallow"]
    f, st = got["frame"], got["stats"]
    assert len(f) == 704 and st["cells"] == 704
    assert f["indicator"].value_counts().to_dict() == {"D": 349, "A": 202, "A*": 153}
    assert int(f["changed"].sum()) == 129 and st["changed_by_indicator"] == {"D": 5, "A*": 90, "A": 34}
    cols = ["H0014", "H0015", "H0018", "H0035", "H0037", "H2016", "H2018", "H2020", "H2026", "H2038", "S5140", "S5145",
            "S5151", "S9480", "S9485", "T1020"]
    assert list(dict.fromkeys(f["col_code"])) == cols and f["row_code"].nunique() == 44
    units = f.drop_duplicates("col_code").set_index("col_code")["col_unit"].to_dict()
    assert {c for c, u in units.items() if u == "One Per Day"} == {"H0014", "H0015", "H0035"}
    assert {c for c, u in units.items() if u != "One Per Day"} == set(cols) - {"H0014", "H0015", "H0035"}
    assert set(units.values()) == {"One Per Day", "Per Diem"}
    # the non-breaking spaces (U+00A0 / U+202F) are gone from every code and indicator
    for c in ("row_code", "col_code", "indicator"):
        assert not any(NBSP in v or NNBSP in v or v != v.strip() for v in f[c]), c
    # three numbered notes; note 2 is the medical-necessity exception
    assert sorted(st["notes"]) == ["1", "2", "3"] and st["notes"]["2"].startswith(at.NOTE2)
    assert "(CBHSG Page 5/88)" in st["notes"]["2"]
    assert any("Changed indicators are noted in red" in x for x in st["footnotes"])
    # the diagonal: every column code is also a row code, and each meets itself as D
    diag = f[f["row_code"] == f["col_code"]]
    assert len(diag) == 16 and set(diag["indicator"]) == {"D"}
    cell = f.set_index(["row_code", "col_code"])
    assert cell.loc[("T1016", "H0035"), "indicator"] == "A" and not cell.loc[("T1016", "H0035"), "changed"]
    assert cell.loc[("T1016", "H0035"), "cell"] == "G50"
    assert cell.loc[("H0001", "S5151"), "indicator"] == "A*" and cell.loc[("H0001", "S5151"), "changed"] is True
    assert cell.loc[("H0001", "S5151"), "cell"] == "P9"
    assert cell.loc[("H0004", "H0014"), "row_unit"] == "15 min"


def test_real_daily_limits_numbers(real):
    got = real["daily_limits"]
    f, st = got["frame"], got["stats"]
    assert len(f) == 15600 and f["code"].nunique() == 15600
    assert all(len(c) == 5 for c in f["code"])
    # the last sheet row (row 15608: a print date 2026-09-14 and '10:26:02') is the report's footer, never a code
    assert f["source_row"].max() == 15607 and 15608 not in set(f["source_row"])
    assert st["footer"].startswith("2026-09-14") and "10:26:02" in st["footer"]
    assert f["freq1_cd"].value_counts().to_dict() == {"Y": 739, "M": 668, "L": 531, "D": 359, "W": 130}
    assert int(f["freq1_cd"].notna().sum()) == 2427 and int(f["freq2_cd"].notna().sum()) == 30
    mx = f["daily_max"].value_counts()
    assert mx[1] == 10192 and mx[999] == 113
    assert all(isinstance(v, int) for v in f["daily_max"])
    r = f.set_index("code")
    assert r.loc["98960", "daily_max"] == 4                                     # '000004'
    assert (r.loc["98960", "limit1"], r.loc["98960", "freq1_value"], r.loc["98960", "freq1_cd"]) == (4, 1, "D")
    assert (r.loc["98960", "limit2"], r.loc["98960", "freq2_value"], r.loc["98960", "freq2_cd"]) == (24, 1, "M")
    assert r.loc["S5150", "daily_max"] == 48 and r.loc["H0004", "limit1"] is None
    assert r.loc["81286", "description"].startswith("FXN")                    # its separator is '  -  '
    # surprises worth a reviewer's eye (recorded, not compiled): a 999,999 'maximum' and 22 codes whose own
    # '<n> per 1 day' frequency limit differs from their Procedure Maximum Occurrence
    assert r.loc["J2002", "daily_max"] == 999999 and st["per_day_limit_differs_from_max"] == 22
    assert (r.loc["82435", "daily_max"], r.loc["82435", "limit1"], r.loc["82435", "freq1_cd"]) == (1, 4, "D")


def test_real_b2_matrix_numbers(real):
    got = real["b2_matrix"]
    f, st = got["frame"], got["stats"]
    assert st["merged_ranges"] == 9072
    # 2026-10-04: the brief said 3,410 rows / 364 codes / 38 provider types; its own code breakdown sums to 363. The
    # extra row is the sheet's LAST row - a merged A5107:H5107 holding one space - which has a blank code and is dropped
    assert len(f) == 3409 and f["code"].nunique() == 363 and f["provider_type"].nunique() == 37
    assert st["codes_by_kind"] == {"CPT": 267, "H0xxx/H2xxx": 32, "A": 28, "J": 13, "S": 10, "T": 9, "G": 4}
    assert st["blank_code_rows"] == 3 and st["compile_codes"] == 32
    assert not f.duplicated().any() and not f.duplicated(["code", "provider_type"]).any()
    assert sorted(f.loc[f["code"] == "H0035", "provider_type"]) == ["02", "71", "B5", "B6"]
    # provider type codes stay TEXT ('02', never 2)
    assert all(isinstance(v, str) for v in f["provider_type"]) and "02" in set(f["provider_type"])
    assert set(f["coverage_code"]) == {"01"}
    assert f.loc[f["code"] == "00104", "source_row"].min() == 11


def test_real_rules(real):
    frames = {k: g["frame"] for k, g in real.items()}
    rep = {}
    rules = at.rules_from_frames(frames, report=rep)
    by = {}
    for r in rules:
        by.setdefault(r.predicate["type"], []).append(r)
    assert len(by["code_pair_prohibited"]) == 486 == 333 + 153                 # D off the diagonal + A*
    assert sum(r.predicate["scope"] == "member_day" for r in by["code_pair_prohibited"]) == 333
    # 2026-10-04 (v5.2b, critic F2): 15,600 rows - 274 anesthesia codes (00100-01999, time units) - 114 all-nines
    # maxima (113 x 999, J2002 999999) - the 22 codes stating two daily limits = 15,190 daily rules (was 15,578: only
    # the 22 were left out); no row falls in two exclusions in this version
    assert len(by["max_units_per_day"]) == 15190 == 15600 - 274 - 114 - len(TWO_DAILY_LIMITS)
    assert rep["daily_limits"]["recorded_not_compiled"] == {"period_limit_rows": 2427, "anesthesia_time_units": 274,
                                                            "placeholder_maximum": 114, "two_daily_limits": 22}
    assert len(by["provider_type_allowed"]) == 32
    assert rep["same_day_disallow"]["diagonal_skipped"] == 16 and rep["same_day_disallow"]["allowed_no_rule"] == 202
    assert rep["b2_matrix"]["recorded_not_compiled"]["codes"] == 331
    assert len({r.rule_id for r in rules}) == len(rules)
    pairs = {(r.predicate["code_b"], r.predicate["code_a"]): r for r in by["code_pair_prohibited"]}
    assert ("T1016", "H0035") not in pairs                                     # A: no rule
    assert ("H0014", "H0014") not in pairs                                     # the diagonal: no rule
    h = pairs[("H0001", "S5151")]
    # 2026-10-04 (v5.2b, critic F5): A* = the same servicing AND billing provider (config.AHCCCS_SAME_PROVIDER_SCOPE)
    assert h.predicate == {"type": "code_pair_prohibited", "code_a": "S5151", "code_b": "H0001",
                           "modifier_indicator": "0", "scope": "member_servicing_billing_day", "exception": at.NOTE2,
                           "service_category": "state_bh"}
    assert "cell P9" in h.source_locator and "changed in this version" in h.notes
    assert pairs[("H0001", "H0014")].predicate["scope"] == "member_day"
    d = next(r for r in by["max_units_per_day"] if r.predicate["code"] == "98960")
    assert d.predicate == {"type": "max_units_per_day", "code": "98960", "threshold": 4,
                           "scope": "member_servicing_billing_day"}
    assert "Limit 2: 24 per 1 M" in d.notes and (d.effective_date, d.end_date) == ("2026-09-14", None)
    b = next(r for r in by["provider_type_allowed"] if r.predicate["code_set"] == ["H0035"])
    assert b.predicate["provider_types"] == ["02", "71", "B5", "B6"]
    assert b.predicate["provider_role"] == "billing_or_rendering"            # 2026-10-04 (v5.2b, critic F1)
    assert {r.predicate["code_set"][0][:2] for r in by["provider_type_allowed"]} == {"H0", "H2"}
    # every rule passes the gate as it is - nothing downgraded to a lead
    acc, rej = validate_gate.gate(rules)
    assert not rej and {a["validation_status"] for a in acc} == {"clean"}


# 2026-10-04 (v5.2 follow-up): the codes of the 9/14/26 Daily Limits file whose OWN "N per 1 day" limit (Frequency Cd
# D, Frequency Value 1) differs from their Procedure Maximum Occurrence: {code: (maximum, the 1-day limit)}
TWO_DAILY_LIMITS = {
    "82435": (1, 4), "87070": (3, 4), "87103": (2, 1), "88365": (4, 1), "J0695": (60, 3), "J0841": (20, 24),
    "J0883": (1125, 1), "J0884": (1125, 1), "J1738": (30, 1), "J1955": (11, 3), "J2300": (4, 16), "J2310": (4, 10),
    "J2515": (1, 4), "J2547": (600, 1), "J7210": (22000, 300), "J7211": (22000, 300), "J7313": (38, 2),
    "J9015": (1, 3), "J9120": (5, 1), "J9341": (675, 30), "J9342": (675, 30), "Q9950": (4, 2)}


def test_real_daily_limits_that_state_two_daily_limits_build_no_rule(real):
    """AHCCCS's file states two different daily limits for these codes, so which one its edit applies is unknown: no
    daily rule, a line in the report and a file_states_two_daily_limits row in the conflicts register. A 1-day limit
    EQUAL to the maximum agrees with it (170 codes): their rule stands."""
    f = real["daily_limits"]["frame"]
    two = at.two_daily_limits(f)
    assert {t["code"]: (t["daily_max"], t["limit"]) for t in two} == TWO_DAILY_LIMITS
    assert {t["limit_no"] for t in two} == {"1"} and {t["version_date"] for t in two} == {"2026-09-14"}
    assert real["daily_limits"]["stats"]["per_day_limit_differs_from_max"] == len(TWO_DAILY_LIMITS) == 22
    rep = {}
    daily = {r.predicate["code"]: r for r in at.rules_from_frames({"daily_limits": f}, report=rep)}
    assert len(daily) == 15190 and not set(daily) & set(TWO_DAILY_LIMITS)            # v5.2b: see test_real_rules
    assert rep["daily_limits"]["two_daily_limits"] == {"count": 22, "codes": sorted(TWO_DAILY_LIMITS)}
    assert rep["daily_limits"]["recorded_not_compiled"]["two_daily_limits"] == 22
    agree = [r.code for r in f.itertuples(index=False) if r.code not in TWO_DAILY_LIMITS
             and any(cd == "D" and val == 1 for cd, val in ((r.freq1_cd, r.freq1_value), (r.freq2_cd, r.freq2_value)))]
    # ... except 00604, an anesthesia code (1 per 1 day = its maximum 1): no rule since v5.2b (critic F2)
    assert len(agree) == 170 and [c for c in agree if c not in daily] == ["00604"]
    assert daily["98960"].predicate["threshold"] == 4 and daily["H2016"].predicate["threshold"] == 1
    c = at.table_conflicts({"daily_limits": f}, [])
    assert c["relationship"].value_counts().to_dict() == {"not_compiled_anesthesia_time_units": 274,
                                                          "not_compiled_placeholder_maximum": 114,
                                                          "file_states_two_daily_limits": 22}
    c = c[c["relationship"] == "file_states_two_daily_limits"]
    assert set(c["table_key"]) == {"daily_limits"} and set(c["version_date"]) == {"2026-09-14"}
    row = c.set_index("codes").loc["J7210"]
    assert "Procedure Maximum Occurrence 22000" in row["detail"] and "Limit 1 = 300 per 1 day" in row["detail"]
    assert row["rule_id"] is None and row["rule_origin"] is None
    # the reviewer's reading names the count of this version
    dm = {r["reading_id"]: r["reading"] for r in at.read_readings() if r["table_key"] == "daily_limits"}["daily_max"]
    assert f"{len(TWO_DAILY_LIMITS)} codes" in dm and "82435" in dm


def test_real_same_day_pairs_marked_both_ways(real):
    """Some code pairs carry a D / A* cell in BOTH directions: both lines become findings (each is the row code of one
    cell). The reading the reviewer signs (flagged_line) states how many, for this version."""
    f = real["same_day_disallow"]["frame"]
    both_ways = at.pairs_both_ways(f)
    assert list(both_ways) == ["2026-10-01"] and len(both_ways["2026-10-01"]) == 104
    ind = {(r.row_code, r.col_code): r.indicator for r in f.itertuples(index=False)}
    assert {(ind[(a, b)], ind[(b, a)]) for a, b in both_ways["2026-10-01"]} == {("D", "D"), ("A*", "A*")}
    assert sum(ind[p] == "D" for p in both_ways["2026-10-01"]) == 74
    rep = {}
    rules = at.rules_from_frames({"same_day_disallow": f}, report=rep)
    assert rep["same_day_disallow"]["pairs_both_ways"] == 104
    # 2026-10-04 (v5.2b, critic F4): each of the 208 rules (104 pairs x 2 directions) carries both_ways, no other rule
    both = {(r.predicate["code_b"], r.predicate["code_a"]) for r in rules if r.predicate.get("both_ways")}
    assert rep["same_day_disallow"]["rules_both_ways"] == len(both) == 208
    assert both == {p for a, b in both_ways["2026-10-01"] for p in ((a, b), (b, a))}
    fl = {r["reading_id"]: r["reading"] for r in at.read_readings() if r["table_key"] == "same_day_disallow"}
    assert "104 code pairs" in fl["flagged_line"]


def test_real_rules_pass_the_grammar(real):
    rules = at.rules_from_frames({k: g["frame"] for k, g in real.items()})
    bad = [(r.predicate["type"], why) for r in rules
           for ok, why in [schema.validate_predicate(r.predicate, origin="ahcccs_table")] if not ok]
    if bad and all(t == "max_units_per_day" and "scope" in why for t, why in bad):
        pytest.xfail("schema.validate_predicate does not accept 'scope' on max_units_per_day yet - implementer T2 adds "
                     "it (contract v5.2 'Query layer'); every pair and provider-type rule validates")
    assert not bad, bad[:5]


# ====================================================================================== (b) synthetic workbooks
LEGEND = ("D = Disallowed  A=Allowable  A*= Allowable on same day for the member, cannot be provided/billed by the same "
          "provider (service site or residential placement)")
NOTES = ("1.  Billing practices and compliance with all applicable standards are subject to verification during "
         "standard monitoring and auditing activities conducted by AHCCCS, TRBHAs, and MCOs.                  2.  "
         "Exceptions to limitations on service frequency or duration may be approved based on medical necessity. "
         "Providers shall submit requests for exceptions to the applicable MCO, TRBHA, or AHCCCS and follow the "
         "applicable process for submitting documentation to support a request to exceed a limitation.  (CBHSG Page "
         "5/88)            3.  AHCCCS reserves the right to revert back to D disallow if we find these are being abused.")
SD_COLS = [("H0014", "Alcohol and/or drug services: ambulatory detoxification", "One Per Day"),
           ("H0035", "Mental health partial hospitalization, treatment, less than 24 hours", "One Per Day"),
           ("S5151", "Unskilled respite care NOT HOSPICE", "Per Diem")]
SD_ROWS = [("H0001", "Alcohol and/or drug Assessment", "Assessment", ["D", "A*", "A"]),
           ("H0014", "Alcohol and/or drug services; ambulatory detoxification", "Per Diem", ["D", "D", "A*"]),
           ("T1016", "Case Management", "15 min", ["A", "A", "A*"])]


def same_day_xlsx(path, updated="10/1/2026", rows=None, red=(("H0001", "H0035"),), legend=LEGEND, notes=NOTES,
                  after_grid=None, sheet="1012026 Effective Date", intro=""):
    """The Same Day Disallow layout of the real file: title D1, 'Updated:' A2, legend D5 (merged), column codes D6..
    (with U+00A0), descriptions row 7 (notes in A7), units row 8, then one row per code."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet
    ws["D1"] = "SAME DAY DISALLOW TABLE"
    ws.merge_cells("D1:F1")
    if updated:
        ws["A2"] = f"Updated: {updated}"
        ws.merge_cells("A2:C2")
    # intro: identical content saves to identical bytes; a re-saved "twin" of a version differs only here
    ws["A3"] = "This Table includes the most commonly used per diem, single day, counseling ... code combinations." + intro
    ws["D5"] = legend
    ws.merge_cells("D5:F5")
    ws["A6"] = NNBSP + NBSP
    for j, (code, desc, unit) in enumerate(SD_COLS):
        ws.cell(6, 4 + j, code + NBSP)
        ws.cell(7, 4 + j, desc)
        ws.cell(8, 4 + j, unit)
    ws["A7"] = notes
    ws.merge_cells("A7:C7")
    r = 9
    for code, desc, unit, inds in (rows or SD_ROWS):
        ws.cell(r, 1, code + NBSP)
        ws.cell(r, 2, desc + " ")
        ws.cell(r, 3, unit)
        for j, v in enumerate(inds):
            c = ws.cell(r, 4 + j, v + (NBSP if v == "D" else ""))
            c.font = Font(color="FFFF0000" if (code, SD_COLS[j][0]) in set(red) else "FF000000")
        r += 1
    r += 1
    ws.cell(r, 1, "Footnotes:  10/01/2026 changes")
    ws.cell(r + 1, 1, "(1)")
    ws.cell(r + 1, 2, "Changed indicators are noted in red")
    for (rr, cc), v in (after_grid or {}).items():
        ws.cell(rr, cc, v)
    wb.save(path)
    return str(path)


DAILY_ROWS = [
    ("98960  - EDUCATION AND TRAINING FOR PATIENT SELF-MANAGEMENT, EACH 30 MINUTES         ", "000004", "  4", "  1",
     "D", " 24", "  1", "M"),
    ("H0004  - BEHAVIORAL HEALTH COUNSELING AND THERAPY, PER 15 MINUTES       ", "000032", "   ", "   ", " ", "   ",
     "   ", " "),
    ("S5151  - UNSKILLED RESPITE CARE, NOT HOSPICE; PER DIEM     ", "000001", " 30", "  1", "Y", "   ", "   ", " "),
    ("81286  -  FXN (FRATAXIN) GENE ANALYSIS; FULL GENE SEQUENCE", "000001", "   ", "   ", " ", "   ", "   ", " "),
]


def daily_xlsx(path, as_of="9/14/26", rows=None, footer=True, sheet="September 2026", extra=None):
    """The Daily Limits report layout: merged title block, 'Report As of' A6, header row 7, then one row per code and
    the report's junk last row (print date, page, time - merged A:C, D:F, G:H). extra: {(row, col): value} written
    last."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet
    ws.merge_cells("A1:H4")
    ws["A5"] = "HCPCS CPT Procedures with Daily Limits"
    ws.merge_cells("A5:H5")
    if as_of:
        ws["A6"] = f"Report     As of {as_of}"
        ws.merge_cells("A6:H6")
    for j, h in enumerate(["Procedure Description", "Procedure Maximum Occurrence", "Limit 1", "Frequency 1 Value",
                           "Frequency 1 Cd", "Limit 2", "Frequency 2 Value", "Frequency 2 Cd"]):
        ws.cell(7, 1 + j, h)
    r = 8
    for row in (rows if rows is not None else DAILY_ROWS):
        for j, v in enumerate(row):
            ws.cell(r, 1 + j, v)
        r += 1
    if footer:
        ws.cell(r, 1, datetime(2026, 9, 14))
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
        ws.cell(r, 4, 1)
        ws.merge_cells(start_row=r, start_column=4, end_row=r, end_column=6)
        ws.cell(r, 7, time(10, 26, 2))
        ws.merge_cells(start_row=r, start_column=7, end_row=r, end_column=8)
    for (rr, cc), v in (extra or {}).items():
        ws.cell(rr, cc, v)
    wb.save(path)
    return str(path)


H35 = "MENTAL HEALTH PARTIAL HOSPITALIZATION, TREATMENT, LESS THAN 24 HOURS          "
B2_RECORDS = [
    ("H0035", H35, "02", "HOSPITAL", "01", "47", "52, 99", "HA, HB"),
    ("H0035", H35, "71", "PSYCHIATRIC HOSPITAL", "01", "47", "52, 99", "HA, HB"),
    ("H0035", H35, "B5", "SUBACUTE FACILITY (1-16 BEDS)", "01", "47", "52, 99", "HA, HB"),
    ("H0035", H35, "B6", "SUBACUTE FACILITY (17+BEDS)(IMD)", "01", "47", "52, 99", "HA, HB"),
    ("90791", "PSYCHIATRIC DIAGNOSTIC EVALUATION", 8, "MD-PHYSICIAN", "01", "01", "11, 53", "GT, 95"),
    ("90791", "PSYCHIATRIC DIAGNOSTIC EVALUATION", "11", "PSYCHOLOGIST", "01", "01", "11, 53", "GT, 95"),
]


def b2_xlsx(path, as_of="10/1/26", records=None, junk_last=True, sheet="October 2026", extra=None):
    """The B2 Matrix export: every record spans two sheet rows, merged vertically per column, and a value repeated by
    consecutive records is ONE merged range over all of them (H0035's code: 8 rows; coverage '01': all 12 rows).
    extra: {(row, col): value} written last."""
    records = records if records is not None else B2_RECORDS
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet
    ws.merge_cells("A1:H4")
    ws["A5"] = ("BH Matrix Procedure Codes and Associated Provider Types, Category of Service, Place of Service and "
                "Modifiers")
    ws.merge_cells("A5:H6")
    if as_of:
        ws["A8"] = f"As of {as_of}"
        ws.merge_cells("A8:C8")
    for j, h in enumerate(["Procedure Code", "Procedure Code Description", "Provider Type", "Provider Type Description",
                           "AHCCCS Coverage Code", "Category of Service Aggregated", "Place of Service Aggregated",
                           "Modifer Aggregated"]):
        ws.cell(10, 1 + j, h)
    first = 11
    for c in range(8):
        i = 0
        while i < len(records):
            j = i
            while j + 1 < len(records) and records[j + 1][c] == records[i][c]:
                j += 1
            top, bottom = first + 2 * i, first + 2 * j + 1
            ws.cell(top, 1 + c, records[i][c])
            ws.merge_cells(start_row=top, start_column=1 + c, end_row=bottom, end_column=1 + c)
            i = j + 1
    if junk_last:
        last = first + 2 * len(records) + 2
        ws.cell(last, 1, " ")
        ws.merge_cells(start_row=last, start_column=1, end_row=last, end_column=8)
    for (rr, cc), v in (extra or {}).items():
        ws.cell(rr, cc, v)
    wb.save(path)
    return str(path)


def test_synthetic_same_day_parse(tmp_path):
    got = at.parse_file(same_day_xlsx(tmp_path / "whatever_name.xlsx"))          # the name says nothing
    assert got["table_key"] == "same_day_disallow" and got["version_date"] == "2026-10-01"
    f = got["frame"]
    assert len(f) == 9 and list(f.columns) == at.TABLE_COLUMNS["same_day_disallow"]
    assert f["indicator"].value_counts().to_dict() == {"A*": 3, "A": 3, "D": 3}
    c = f.set_index(["row_code", "col_code"])
    assert c.loc[("H0001", "H0035"), "changed"] is True and int(f["changed"].sum()) == 1
    assert c.loc[("H0001", "H0035"), "cell"] == "E9" and c.loc[("T1016", "S5151"), "cell"] == "F11"
    assert c.loc[("H0001", "H0014"), "indicator"] == "D"                       # 'D\xa0'
    assert c.loc[("T1016", "S5151"), "col_unit"] == "Per Diem" and c.loc[("T1016", "S5151"), "row_unit"] == "15 min"
    assert c.loc[("H0001", "H0014"), "row_description"] == "Alcohol and/or drug Assessment"
    assert got["stats"]["notes"]["2"].startswith(at.NOTE2) and got["stats"]["diagonal"] == 1


@pytest.mark.parametrize("kw, msg", [
    ({"rows": [("H0001", "x", "15 min", ["D", "X", "A"])] + SD_ROWS[1:]}, "not D, A or A*"),
    ({"rows": [("H0001", "x", "15 min", ["D", "", "A"])] + SD_ROWS[1:]}, "not D, A or A*"),
    ({"rows": SD_ROWS + [("H0001", "again", "15 min", ["A", "A", "A"])]}, "appears twice in one version"),
    ({"updated": None}, "no version date"),
    ({"updated": "13/45/2026"}, "not a calendar date"),
    ({"legend": "D = Disallowed  A=Allowable  A*= allowable when the moon is full"}, "legend no longer reads"),
    ({"notes": NOTES.replace("Exceptions to limitations", "Waivers of limits")}, "table note 2 no longer opens"),
    ({"after_grid": {(20, 1): "H0002", (20, 4): "D"}}, "unexpected content at row 20"),
])
def test_synthetic_same_day_refusals(tmp_path, kw, msg):
    with pytest.raises(ValueError, match=msg):
        at.parse_file(same_day_xlsx(tmp_path / "sd.xlsx", **kw))


# 2026-10-04 (v5.2b, critic F6): a column right of the table's last known column - a trailing column header that is not
# a bare code, a header-less column of values, a 9th header - used to be dropped silently. Refused, naming the cell; a
# cell holding only spaces (the files write blanks as spaces) is blank.
@pytest.mark.parametrize("layout, extra, cell", [
    ("same_day", {(6, 7): "T1019*"}, "G6"),                 # a trailing column header that is not a bare code
    ("same_day", {(7, 7): "New service", (8, 7): "Per Diem"}, "G7"),      # its description and unit, no code
    ("same_day", {(10, 7): "D"}, "G10"),                    # an indicator with no column header at all
    ("same_day", {(11, 30): "x"}, "AD11"),                  # far right
    ("daily", {(7, 9): "Limit 3"}, "I7"),                   # a 9th header
    ("daily", {(9, 9): "  3"}, "I9"),                       # a 9th column of values, no header
    ("b2", {(10, 9): "Rate"}, "I10"),
    ("b2", {(13, 9): "HW"}, "I13"),
])
def test_content_right_of_the_last_known_column_is_refused_naming_the_cell(tmp_path, layout, extra, cell):
    build = {"same_day": lambda p, e: same_day_xlsx(p, after_grid=e), "daily": lambda p, e: daily_xlsx(p, extra=e),
             "b2": lambda p, e: b2_xlsx(p, extra=e)}[layout]
    with pytest.raises(ValueError, match=rf"cell {cell} holds .* to the right of the table's last known column"):
        at.parse_file(build(tmp_path / "x.xlsx", extra))
    # spaces only (U+00A0 too) are blank: the file parses exactly as without them
    blank = {k: " " + NBSP for k in extra}
    got = at.parse_file(build(tmp_path / "y.xlsx", blank))["frame"]
    want = at.parse_file(build(tmp_path / "z.xlsx", {}))["frame"]
    pd.testing.assert_frame_equal(got.drop(columns=["file_sha256", "file_name"]),
                                  want.drop(columns=["file_sha256", "file_name"]))


def test_unknown_layout_and_not_a_workbook_are_refused(tmp_path):
    wb = openpyxl.Workbook()
    wb.active["A1"] = "Procedure Code"
    wb.active["B1"] = "Something else"
    wb.save(tmp_path / "other.xlsx")
    with pytest.raises(ValueError, match="not a layout this loader knows"):
        at.parse_file(str(tmp_path / "other.xlsx"))
    (tmp_path / "fake.xlsx").write_bytes(b"<html>blocked</html>")
    with pytest.raises(ValueError, match="not a readable .xlsx workbook"):
        at.parse_file(str(tmp_path / "fake.xlsx"))


def test_synthetic_daily_limits_parse_with_the_junk_last_row(tmp_path):
    got = at.parse_file(daily_xlsx(tmp_path / "d.xlsx"))
    assert got["table_key"] == "daily_limits" and got["version_date"] == "2026-09-14"
    f = got["frame"].set_index("code")
    assert list(f.index) == ["98960", "H0004", "S5151", "81286"]               # the footer row is not a code
    assert got["stats"]["footer"].startswith("2026-09-14") and "10:26:02" in got["stats"]["footer"]
    assert f.loc["98960", "daily_max"] == 4 and f.loc["98960", "limit2"] == 24 and f.loc["98960", "freq2_cd"] == "M"
    assert f.loc["H0004", "limit1"] is None and f.loc["H0004", "freq1_cd"] is None
    assert f.loc["81286", "description"].startswith("FXN") and f.loc["S5151", "source_row"] == 10


@pytest.mark.parametrize("bad, msg", [
    (("H0005  - BH", "00003X", "   ", "   ", " ", "   ", "   ", " "), "is not a whole number"),
    (("H0005  - BH", "000000", "   ", "   ", " ", "   ", "   ", " "), "not a positive whole number"),
    (("98960  - AGAIN", "000001", "   ", "   ", " ", "   ", "   ", " "), "appears twice in one version"),
    (("H0005  - BH", "000001", "  1", "  1", "Q", "   ", "   ", " "), "Frequency 1 Cd 'Q'"),
    (("H0005  - BH", "000001", "  1", "   ", "D", "   ", "   ", " "), "all filled or all blank"),
    (("H0005 BH NO DASH", "000001", "   ", "   ", " ", "   ", "   ", " "), "is not 'CODE - DESCRIPTION'"),
    ((datetime(2026, 9, 14), None, None, 1, None, None, time(1, 2, 3), None), "not the report's last row"),
])
def test_synthetic_daily_limits_refusals(tmp_path, bad, msg):
    with pytest.raises(ValueError, match=msg):
        at.parse_file(daily_xlsx(tmp_path / "d.xlsx", rows=DAILY_ROWS[:2] + [bad] + DAILY_ROWS[2:]))
    with pytest.raises(ValueError, match="no version date"):
        at.parse_file(daily_xlsx(tmp_path / "d2.xlsx", as_of=None))


def test_synthetic_b2_merged_cells_expanded_and_deduplicated(tmp_path):
    got = at.parse_file(b2_xlsx(tmp_path / "b.xlsx"))
    assert got["table_key"] == "b2_matrix" and got["version_date"] == "2026-10-01"
    f = got["frame"]
    assert len(f) == 6 and got["stats"]["duplicate_rows_dropped"] == 6 and got["stats"]["blank_code_rows"] >= 1
    assert list(f["source_row"]) == [11, 13, 15, 17, 19, 21]
    assert sorted(f.loc[f["code"] == "H0035", "provider_type"]) == ["02", "71", "B5", "B6"]
    assert sorted(f.loc[f["code"] == "90791", "provider_type"]) == ["08", "11"]    # a numeric 8 -> '08' (text)
    assert set(f["coverage_code"]) == {"01"} and set(f.loc[f["code"] == "H0035", "code_description"]) == {H35.strip()}
    assert set(f.loc[f["code"] == "90791", "category_of_service"]) == {"01"}       # a 12-row merged range


def test_synthetic_b2_refusals(tmp_path):
    clash = B2_RECORDS + [("H0035", H35, "02", "HOSPITAL", "01", "47", "11", "HA")]   # same code + type, other values
    with pytest.raises(ValueError, match="appears twice in one version"):
        at.parse_file(b2_xlsx(tmp_path / "b1.xlsx", records=clash))
    with pytest.raises(ValueError, match="no version date"):
        at.parse_file(b2_xlsx(tmp_path / "b2.xlsx", as_of=None))
    with pytest.raises(ValueError, match="not a 5-character"):
        at.parse_file(b2_xlsx(tmp_path / "b3.xlsx", records=[("H00351", "x", "02", "H", "01", "47", "52", "HA")]))


def test_version_windows():
    assert at.version_windows(["2026-10-01", "2026-07-01", "2026-10-01"]) == {
        "2026-07-01": ("2026-07-01", "2026-09-30"), "2026-10-01": ("2026-10-01", None)}
    assert at.version_windows([]) == {}
    assert at.version_windows(["2024-03-01", "2024-02-01"])["2024-02-01"] == ("2024-02-01", "2024-02-29")
    with pytest.raises(ValueError):
        at.version_windows(["10/1/2026"])


@pytest.fixture
def frames(tmp_path):
    """Two Same Day versions (7/1/2026 and 10/1/2026), one Daily Limits and one B2 Matrix version."""
    old = at.parse_file(same_day_xlsx(tmp_path / "sd_old.xlsx", updated="7/1/2026", red=()))
    new = at.parse_file(same_day_xlsx(tmp_path / "sd_new.xlsx"))
    d = at.parse_file(daily_xlsx(tmp_path / "d.xlsx"))
    b = at.parse_file(b2_xlsx(tmp_path / "b.xlsx"))
    return {"same_day_disallow": pd.concat([old["frame"], new["frame"]], ignore_index=True),
            "daily_limits": d["frame"], "b2_matrix": b["frame"],
            "_sha": {"sd_old": old["file_sha256"], "sd_new": new["file_sha256"], "d": d["file_sha256"],
                     "b": b["file_sha256"]}}


def _rules(frames, **kw):
    return at.rules_from_frames({k: v for k, v in frames.items() if not k.startswith("_")}, **kw)


def test_rules_from_frames_pairs_predicates_statements_citations_windows(frames):
    rep = {}
    rules = _rules(frames, report=rep)
    pairs = [r for r in rules if r.predicate["type"] == "code_pair_prohibited"]
    # per version: 3 D (one on the diagonal), 3 A* , 3 A -> 2 D pairs + 3 A* pairs; two versions
    assert len(pairs) == 10
    assert rep["same_day_disallow"]["diagonal_skipped"] == 2 and rep["same_day_disallow"]["allowed_no_rule"] == 6
    assert rep["same_day_disallow"]["versions"] == ["2026-07-01", "2026-10-01"]
    new = {(r.predicate["code_b"], r.predicate["code_a"]): r for r in pairs if r.doc_version == "2026-10-01"}
    old = {(r.predicate["code_b"], r.predicate["code_a"]): r for r in pairs if r.doc_version == "2026-07-01"}
    assert set(new) == set(old) == {("H0001", "H0014"), ("H0014", "H0035"), ("H0001", "H0035"), ("H0014", "S5151"),
                                    ("T1016", "S5151")}
    d = new[("H0001", "H0014")]                                  # row H0001 x column H0014 = D
    assert d.predicate == {"type": "code_pair_prohibited", "code_a": "H0014", "code_b": "H0001",
                           "modifier_indicator": "0", "scope": "member_day", "exception": at.NOTE2,
                           "service_category": "state_bh"}
    assert "by any provider" in d.statement and d.statement.startswith("H0001 and H0014")
    a_star = new[("H0001", "H0035")]
    assert a_star.predicate["scope"] == "member_servicing_billing_day" and "by the same provider" in a_star.statement
    assert "changed in this version" in a_star.notes and "changed in this version" not in old[("H0001", "H0035")].notes
    # citations: file, sheet, cell, url, version and hash
    assert d.origin == "ahcccs_table" and d.plane == "coding_edit" and d.binding_status == "state_policy"
    assert d.source_doc == "AHCCCS Same Day Disallow Table (version 2026-10-01)"
    assert d.source_locator == "sheet '1012026 Effective Date' cell D9 (row H0001 x column H0014)"
    assert d.source_url == config.AHCCCS_TABLES["same_day_disallow"]["url"]
    assert (d.doc_version, d.doc_hash) == ("2026-10-01", frames["_sha"]["sd_new"])
    assert old[("H0001", "H0014")].doc_hash == frames["_sha"]["sd_old"]
    # windows: the older version ends the day before the newer one starts; the newest is open-ended
    assert (old[("H0001", "H0014")].effective_date, old[("H0001", "H0014")].end_date) == ("2026-07-01", "2026-09-30")
    assert (d.effective_date, d.end_date) == ("2026-10-01", None)
    assert d.rule_id == schema.stable_rule_id(d.to_dict()) and d.rule_id != old[("H0001", "H0014")].rule_id
    assert d.codes == ["H0014", "H0001"] and machine(d)


def machine(r):
    return r.machine_checkable and not r.ambiguity_flag and r.population == "all"


# 2026-10-04 (v5.2b, critic F5): "same provider" of an A* pair and of a daily limit is config.AHCCCS_SAME_PROVIDER_SCOPE /
# AHCCCS_DAILY_LIMIT_SCOPE - default member_servicing_billing_day - and every statement says the scope in plain words
PAIR_WORDS = {"member_day": "by any provider",
              "member_provider_day": "by the same provider - the same servicing provider id",
              "member_servicing_billing_day": "by the same provider - the same servicing and billing provider ids"}
DAILY_WORDS = {"member_day": "per member per date of service (all providers together)",
               "member_provider_day": "per member, per provider (the same servicing provider id), per date of service",
               "member_servicing_billing_day": ("per member, per provider (the same servicing and billing provider "
                                                "ids), per date of service")}


def test_a_star_and_daily_scopes_come_from_config_and_statements_say_them(frames, monkeypatch):
    assert config.AHCCCS_SAME_PROVIDER_SCOPE == config.AHCCCS_DAILY_LIMIT_SCOPE == "member_servicing_billing_day"
    for scope in schema.PAIR_SCOPES:
        monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", scope)
        monkeypatch.setattr(config, "AHCCCS_DAILY_LIMIT_SCOPE", scope)
        assert at.same_provider_scope() == at.daily_limit_scope() == scope
        rules = _rules(frames)
        pairs = {(r.predicate["code_b"], r.predicate["code_a"]): r for r in rules
                 if r.predicate["type"] == "code_pair_prohibited" and r.doc_version == "2026-10-01"}
        a_star, d = pairs[("H0001", "H0035")], pairs[("H0001", "H0014")]
        assert a_star.predicate["scope"] == scope and d.predicate["scope"] == "member_day"      # D: any provider, always
        assert PAIR_WORDS[scope] in a_star.statement, (scope, a_star.statement)
        assert PAIR_WORDS["member_day"] in d.statement
        assert ("(another provider may bill H0001)" in a_star.statement) == (scope != "member_day")
        daily = next(r for r in rules if r.predicate["type"] == "max_units_per_day" and r.predicate["code"] == "98960")
        assert daily.predicate["scope"] == scope and DAILY_WORDS[scope] in daily.statement, daily.statement
        # the billing provider id is a claim field the rule needs only when the scope compares it
        for r in (a_star, daily):
            assert ("billing_provider_id" in r.required_claim_fields) == (scope == "member_servicing_billing_day")
        assert "billing_provider_id" not in d.required_claim_fields
    monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", "member_servicing_billing_day")
    monkeypatch.setattr(config, "AHCCCS_DAILY_LIMIT_SCOPE", "member_servicing_billing_day")
    a_star = next(r for r in _rules(frames) if r.predicate.get("code_b") == "H0001" and r.predicate.get("code_a") == "H0035"
                  and r.doc_version == "2026-10-01")
    assert "same servicing provider id (SProv_ID) AND the same billing provider id (BProv_ID)" in a_star.notes
    assert "service site or residential placement" in a_star.notes and "missing either id" in a_star.notes
    # a value outside the grammar is refused, never compiled
    monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", "same_site")
    with pytest.raises(ValueError, match="AHCCCS_SAME_PROVIDER_SCOPE must be one of"):
        _rules(frames)


def test_table_conflicts_order_the_three_pair_scopes(frames):
    """The table's A* now reads member_servicing_billing_day: a rule reading the servicing provider only
    (member_provider_day) is WIDER than it; a member_servicing_billing_day rule against a D cell is narrower."""
    fr = {k: v for k, v in frames.items() if not k.startswith("_")}
    rules = [_pair("EXT-mpd", "S5151", "T1016", scope="member_provider_day"),           # table A*
             _pair("EXT-msbd-a", "S5151", "T1016", scope="member_servicing_billing_day"),  # table A*: agrees
             _pair("EXT-msbd-d", "H0014", "H0001", scope="member_servicing_billing_day")]  # table D
    c = at.table_conflicts(fr, rules)
    got = {(r["rule_id"], r["relationship"]) for r in c.to_dict("records") if r["version_date"] == "2026-10-01"}
    assert got == {("EXT-mpd", "pair_scope_differs"), ("EXT-msbd-d", "pair_scope_differs")}
    w = c[(c["rule_id"] == "EXT-mpd") & (c["version_date"] == "2026-10-01")].iloc[0]
    assert "the rule is wider: it flags two providers the table allows" in w["detail"]
    assert "member_servicing_billing_day (by the same provider - the same servicing and billing provider ids)" in \
        w["detail"]
    n = c[(c["rule_id"] == "EXT-msbd-d") & (c["version_date"] == "2026-10-01")].iloc[0]
    assert "the rule is narrower: a pair split across two providers is missed" in n["detail"]


def test_table_conflicts_a_star_read_as_the_servicing_provider(frames, monkeypatch):
    """With A* read as the servicing provider only, a member_servicing_billing_day rule is NARROWER than the table (a
    clinician billing through two agencies is missed) - the old two-scope logic called every non-member_day cell wider."""
    monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", "member_provider_day")
    fr = {k: v for k, v in frames.items() if not k.startswith("_")}
    c = at.table_conflicts(fr, [_pair("EXT-msbd-a", "S5151", "T1016", scope="member_servicing_billing_day"),
                                _pair("EXT-mpd", "S5151", "T1016", scope="member_provider_day")])
    assert set(c["rule_id"]) == {"EXT-msbd-a"} and set(c["relationship"]) == {"pair_scope_differs"}
    assert all("the rule is narrower: a pair split across two providers is missed" in d for d in c["detail"])
    assert all("the table's A* reads member_provider_day (by the same provider - the same servicing provider id)" in d
               for d in c["detail"])


def test_rules_from_frames_daily_and_b2(frames, monkeypatch):
    rep = {}
    rules = _rules(frames, report=rep)
    daily = {r.predicate["code"]: r for r in rules if r.predicate["type"] == "max_units_per_day"}
    assert set(daily) == {"98960", "H0004", "S5151", "81286"}
    assert daily["98960"].predicate == {"type": "max_units_per_day", "code": "98960", "threshold": 4,
                                        "scope": "member_servicing_billing_day"}
    assert DAILY_WORDS["member_servicing_billing_day"] in daily["98960"].statement
    assert daily["98960"].source_locator == "sheet 'September 2026' row 8 (98960)"
    assert "provider_id" in daily["98960"].required_claim_fields
    assert rep["daily_limits"]["recorded_not_compiled"]["period_limit_rows"] == 2       # 98960 and S5151
    ptype = [r for r in rules if r.predicate["type"] == "provider_type_allowed"]
    assert len(ptype) == 1                                       # 90791 (CPT) is recorded, not compiled
    assert ptype[0].predicate == {"type": "provider_type_allowed", "code_set": ["H0035"],
                                  "provider_types": ["02", "71", "B5", "B6"], "provider_role": "billing_or_rendering"}
    assert ptype[0].source_locator == "sheet 'October 2026' procedure code H0035, rows 11-17"
    assert ptype[0].required_claim_fields == ["proc_cd", "billing_type", "prov_type"]
    assert rep["b2_matrix"]["recorded_not_compiled"] == {"codes": 1, "rows": 2}
    # decision 3's scope comes from config; a value outside the grammar is refused, never compiled
    monkeypatch.setattr(config, "AHCCCS_DAILY_LIMIT_SCOPE", "member_day")
    d2 = [r for r in _rules(frames) if r.predicate["type"] == "max_units_per_day"]
    assert {r.predicate["scope"] for r in d2} == {"member_day"} and "all providers together" in d2[0].statement
    monkeypatch.setattr(config, "AHCCCS_DAILY_LIMIT_SCOPE", "member_week")
    with pytest.raises(ValueError, match="AHCCCS_DAILY_LIMIT_SCOPE"):
        _rules(frames)


def test_b2_rules_take_the_provider_role_from_config_and_say_how_a_group_is_judged(frames, monkeypatch):
    """2026-10-04 (v5.2b, critic F1): the B2 Matrix lists rendering practitioner types and no group, so a group billing
    ID (provider type 01) was flagged on every line. provider_role = config.AHCCCS_B2_PROVIDER_ROLE (default
    billing_or_rendering: a group's line is judged on its rendering provider's type), validated like the scopes."""
    assert config.AHCCCS_B2_PROVIDER_ROLE == "billing_or_rendering" and config.GROUP_BILLING_PROVIDER_TYPES == ("01",)
    (r,) = [r for r in _rules(frames) if r.predicate["type"] == "provider_type_allowed"]
    assert r.predicate == {"type": "provider_type_allowed", "code_set": ["H0035"],
                           "provider_types": ["02", "71", "B5", "B6"], "provider_role": "billing_or_rendering"}
    assert r.statement.startswith("H0035 may be billed only by provider types 02, 71, B5, B6; a line billed by a group "
                                  "(billing provider type 01) is judged on its rendering (servicing) provider's type")
    assert "a line whose judged provider type is missing is never a finding" in r.notes
    assert r.required_claim_fields == ["proc_cd", "billing_type", "prov_type"]
    assert schema.validate_predicate(r.predicate, origin="ahcccs_table") == (True, "")
    monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", ("1", "B9"))         # cleaned as the claims column
    (r,) = [r for r in _rules(frames) if r.predicate["type"] == "provider_type_allowed"]
    assert "(billing provider type 01 or B9)" in r.statement
    monkeypatch.setattr(config, "AHCCCS_B2_PROVIDER_ROLE", "billing")
    (r,) = [r for r in _rules(frames) if r.predicate["type"] == "provider_type_allowed"]
    assert r.predicate["provider_role"] == "billing" and r.required_claim_fields == ["proc_cd", "billing_type"]
    assert r.statement.startswith("H0035 may be billed only by billing provider types 02, 71, B5, B6 (")
    monkeypatch.setattr(config, "AHCCCS_B2_PROVIDER_ROLE", "servicing")
    (r,) = [r for r in _rules(frames) if r.predicate["type"] == "provider_type_allowed"]
    assert r.predicate["provider_role"] == "servicing" and r.required_claim_fields == ["proc_cd", "prov_type"]
    assert r.statement.startswith("H0035 may be rendered only by servicing provider types 02, 71, B5, B6 (")
    monkeypatch.setattr(config, "AHCCCS_B2_PROVIDER_ROLE", "rendering")
    with pytest.raises(ValueError, match="AHCCCS_B2_PROVIDER_ROLE must be one of"):
        _rules(frames)


def test_table_conflicts_compare_the_b2_provider_role(frames, monkeypatch):
    """A rule listing the matrix's types but judging the BILLING type flags a group's line the table reading does not:
    provider_role_differs. Same list and role: no row."""
    fr = {k: v for k, v in frames.items() if not k.startswith("_")}
    same = ["02", "71", "B5", "B6"]
    rules = [{"rule_id": "EXT-bill", "origin": "extracted",
              "predicate": {"type": "provider_type_allowed", "code": "H0035", "provider_types": same}},     # billing
             {"rule_id": "EXT-bor", "origin": "extracted",
              "predicate": {"type": "provider_type_allowed", "code": "H0035", "provider_types": same,
                            "provider_role": "billing_or_rendering"}},
             {"rule_id": "EXT-list", "origin": "extracted",
              "predicate": {"type": "provider_type_allowed", "code": "H0035", "provider_types": ["02", "71"],
                            "provider_role": "billing_or_rendering"}}]
    c = at.table_conflicts(fr, rules).set_index("rule_id")
    assert sorted(c.index) == ["EXT-bill", "EXT-list"]
    assert c.loc["EXT-bill", "relationship"] == "provider_role_differs"
    assert c.loc["EXT-bill", "table_reading"] == "billing_or_rendering provider types 02, 71, B5, B6"
    assert c.loc["EXT-bill", "detail"] == (
        "the provider types agree; the rule judges the billing provider's type, the table reading judges the billing "
        "provider's type - for a group (billing provider type 01) the rendering provider's type")
    assert c.loc["EXT-list", "relationship"] == "provider_types_differ"
    assert c.loc["EXT-list", "detail"] == "only in the B2 Matrix: B5, B6"
    monkeypatch.setattr(config, "AHCCCS_B2_PROVIDER_ROLE", "billing")
    c = at.table_conflicts(fr, rules).set_index("rule_id")
    assert c.loc["EXT-bor", "relationship"] == "provider_role_differs" and "EXT-bill" not in c.index


def test_b2_code_with_a_blank_provider_type_is_a_lead_never_a_narrower_list(frames):
    """parse_file refuses a blank provider type; a frame edited in the catalog could still hold one. The complete list
    is then unknown, so the rule keeps a blank entry and compiles as a lead (QUERY_SEMANTICS §2 v2.3) - dropping the
    blank would flag every line of the type nobody can name."""
    import detector_gen as dg
    import rule_normalize
    f = frames["b2_matrix"].copy()
    extra = f[f["code"] == "H0035"].iloc[[0]].copy()
    extra["provider_type"], extra["source_row"] = None, 99
    rules = _rules({"b2_matrix": pd.concat([f, extra], ignore_index=True)})
    ptype = [r for r in rules if r.predicate["type"] == "provider_type_allowed"]
    assert len(ptype) == 1 and ptype[0].predicate["provider_types"] == ["02", "71", "B5", "B6", ""]
    assert "a type the matrix leaves blank" in ptype[0].statement
    acc, rej = validate_gate.gate(ptype)
    acc, _ = rule_normalize.normalize_rules(acc)
    dets = dg.build_detectors(acc, batch_ncci=True, batch_tables=True)
    assert len(dets) == 1 and not dets[0]["compiled"] and not dets[0].get("batch")
    # and with every row typed, the same code compiles into the B2 batch
    acc2, _ = rule_normalize.normalize_rules(validate_gate.gate(_rules({"b2_matrix": f}))[0])
    d2 = [d for d in dg.build_detectors(acc2, batch_ncci=True, batch_tables=True)]
    if len(d2) == 1 and "billing_or_rendering" in str(d2[0].get("reason")):
        pytest.xfail("detector_gen does not compile provider_role 'billing_or_rendering' yet - Role B adds it (contract "
                     "v5.2b B2); the table rule itself is built as config.AHCCCS_B2_PROVIDER_ROLE says")
    assert len(d2) == 1 and d2[0]["compiled"] and d2[0]["batch"] == dg.BATCH_AHCCCS_PTYPE


def _frame_rows(key, rows):
    cols = at.TABLE_COLUMNS[key]
    out = []
    for r in rows:
        d = {c: None for c in cols}
        d.update(version_date="2024-10-01", file_sha256="a" * 64, file_name="f.xlsx", sheet="s")
        d.update(r)
        out.append(d)
    return pd.DataFrame(out, columns=cols)


def test_a_frame_edited_in_the_catalog_is_checked_again(frames):
    """Independent oracle (2026-10-04) G1 / G3 / G6 / G7: parse_file refuses these in a FILE, but 07 reads the frames
    back from the catalog - a row added there by hand built two rules for one cell / code (two findings, the dollars
    counted twice), a rule for a code named None, or dropped a B2 row silently; a lower-case Frequency Cd was not a
    day limit. Now: refused (07 stops, naming the row) / read as upper case."""
    two_cells = _frame_rows("same_day_disallow", [dict(row_code="H0001", col_code="H2014", indicator="D", cell="D9"),
                                                  dict(row_code=" h0001", col_code="H2014", indicator="A*", cell="D10")])
    with pytest.raises(ValueError, match="holds H0001 x H2014 more than once"):
        at.rules_from_frames({"same_day_disallow": two_cells})
    two_rows = _frame_rows("daily_limits", [dict(code="H2014", daily_max=4, source_row=8),
                                            dict(code="h2014 ", daily_max=2, source_row=9)])
    with pytest.raises(ValueError, match="holds H2014 more than once"):
        at.rules_from_frames({"daily_limits": two_rows})
    for key, row in (("same_day_disallow", dict(row_code=None, col_code="H2014", indicator="D", cell="D9")),
                     ("daily_limits", dict(code="  ", daily_max=3, source_row=8)),
                     ("b2_matrix", dict(code=" ", provider_type="02", source_row=9))):
        with pytest.raises(ValueError, match="without"):
            at.rules_from_frames({key: _frame_rows(key, [row])})
    for cd in ("D", " d ", "d"):                      # Limit 1 = 2 per 1 day, the maximum 4: two daily limits, no rule
        f = _frame_rows("daily_limits", [dict(code="H2014", daily_max=4, limit1=2, freq1_value=1, freq1_cd=cd,
                                              source_row=8)])
        assert at.rules_from_frames({"daily_limits": f}) == [], cd
    # a B2 code repeated with the same provider type (spelled two ways) is still ONE type of ONE rule
    b2 = _frame_rows("b2_matrix", [dict(code="H0035", provider_type="2", source_row=9),
                                   dict(code="h0035", provider_type="02", source_row=10)])
    (r,) = at.rules_from_frames({"b2_matrix": b2})
    assert r.predicate["provider_types"] == ["02"]
    # and the shipped synthetic frames are untouched by the checks
    assert len(_rules(frames)) > 0


def test_every_table_rule_passes_the_grammar_and_the_gate(frames):
    rules = _rules(frames)
    assert {r.predicate["type"] for r in rules} == {"code_pair_prohibited", "max_units_per_day",
                                                    "provider_type_allowed"}
    bad = [(r.predicate["type"], why) for r in rules
           for ok, why in [schema.validate_predicate(r.predicate, origin="ahcccs_table")] if not ok]
    if bad and all(t == "max_units_per_day" and "scope" in why for t, why in bad):
        pytest.xfail("schema.validate_predicate does not accept 'scope' on max_units_per_day yet (T2, contract v5.2)")
    assert not bad, bad
    acc, rej = validate_gate.gate(rules)
    assert not rej and all(a["machine_checkable"] for a in acc)


def test_table_rule_ids_carry_the_tbl_prefix(frames):
    if not TBL_LANDED:
        pytest.xfail("schema.stable_rule_id has no 'TBL' prefix for origin 'ahcccs_table' yet - T2 adds it (v5.2)")
    assert all(r.rule_id.startswith("TBL-") for r in _rules(frames))


def test_claims_scope(frames):
    rep = {}
    rules = _rules(frames, scope_codes={"h0001", "H0014", "98960", "S5151"}, report=rep)
    pairs = {(r.predicate["code_b"], r.predicate["code_a"]) for r in rules if r.predicate["type"] == "code_pair_prohibited"}
    assert pairs == {("H0001", "H0014"), ("H0014", "S5151")}       # BOTH codes in scope
    assert rep["same_day_disallow"]["scoped_out"] == 6
    assert {r.predicate["code"] for r in rules if r.predicate["type"] == "max_units_per_day"} == {"98960", "S5151"}
    assert not [r for r in rules if r.predicate["type"] == "provider_type_allowed"]      # H0035 not paid
    assert rep["b2_matrix"]["scoped_out"] == 1 and rep["daily_limits"]["scoped_out"] == 2


def test_a_code_whose_file_states_two_daily_limits_gets_no_rule(tmp_path):
    rows = DAILY_ROWS + [
        ("82435  - CHLORIDE; BLOOD", "000001", "  4", "  1", "D", "   ", "   ", " "),            # max 1, 4 per 1 day
        ("J2350  - INJECTION, OCRELIZUMAB, 1 MG", "000600", "600", " 14", "D", " 50", "  1", "D"),  # Limit 2: 50 a day
        ("H2016  - COMPREHENSIVE COMMUNITY SUPPORT SERVICES, PER DIEM", "000001", "  1", "  1", "D", "   ", "   ", " ")]
    f = at.parse_file(daily_xlsx(tmp_path / "d.xlsx", rows=rows))["frame"]
    assert [(t["code"], t["daily_max"], t["limit_no"], t["limit"]) for t in at.two_daily_limits(f)] == [
        ("82435", 1, "1", 4), ("J2350", 600, "2", 50)]
    rep = {}
    rules = {r.predicate["code"]: r for r in at.rules_from_frames({"daily_limits": f}, report=rep)}
    assert set(rules) == {"98960", "H0004", "S5151", "81286", "H2016"}       # H2016: 1 per 1 day = its maximum
    assert rep["daily_limits"]["two_daily_limits"] == {"count": 2, "codes": ["82435", "J2350"]}
    assert rep["daily_limits"]["rules"] == 5 and rep["daily_limits"]["scoped_out"] == 0
    c = at.table_conflicts({"daily_limits": f}, [])
    assert list(c["codes"]) == ["82435", "J2350"] and set(c["relationship"]) == {"file_states_two_daily_limits"}
    j = c.iloc[1]
    assert "Procedure Maximum Occurrence 600" in j["detail"] and "Limit 2 = 50 per 1 day" in j["detail"]
    assert j["table_reading"] == "Procedure Maximum Occurrence 600 unit(s), row 13"
    assert j["rule_reading"] == "Limit 2 = 50 per 1 day (the same row)"
    # the claims scope never brings one back
    assert not at.rules_from_frames({"daily_limits": f}, scope_codes={"82435", "J2350"})


def test_daily_rows_not_compiled_anesthesia_and_placeholder_maxima(tmp_path, monkeypatch):
    """2026-10-04 (v5.2b, critic F2): anesthesia (config.AHCCCS_DAILY_RECORD_ONLY_CODES, 00100-01999) is billed in
    15-minute TIME units yet most maxima are 1-2, and an all-nines maximum (config.AHCCCS_DAILY_PLACEHOLDER_MAX) is a
    placeholder: neither builds a rule; each row is recorded, counted once - in the FIRST exclusion that applies (code,
    then maximum, then two daily limits) - and listed for SB in policy_ahcccs_conflicts."""
    blank = ("   ", "   ", " ", "   ", "   ", " ")
    rows = DAILY_ROWS + [
        ("00100  - ANESTHESIA FOR PROCEDURES ON SALIVARY GLANDS", "000001") + blank,
        ("01999  - UNLISTED ANESTHESIA PROCEDURE(S)", "000002", "  4", "  1", "D", "   ", "   ", " "),  # + two limits
        ("02000  - NOT AN ANESTHESIA CODE", "000003") + blank,
        ("J7190  - FACTOR VIII (ANTIHEMOPHILIC FACTOR, HUMAN) PER I.U.", "000999") + blank,
        ("A0425  - GROUND MILEAGE, PER STATUTE MILE", "999999") + blank,
        ("J1234  - A DRUG", "000999", "  4", "  1", "D", "   ", "   ", " "),                         # + two limits
        ("J9999  - NINETY-NINE IS NOT A PLACEHOLDER", "000099") + blank,
        ("82435  - CHLORIDE; BLOOD", "000001", "  4", "  1", "D", "   ", "   ", " ")]
    f = at.parse_file(daily_xlsx(tmp_path / "d.xlsx", rows=rows))["frame"]
    assert [at.daily_exclusion(r) for r in f.itertuples(index=False)][4:] == [
        "anesthesia_time_units", "anesthesia_time_units", None, "placeholder_maximum", "placeholder_maximum",
        "placeholder_maximum", None, "two_daily_limits"]
    rep = {}
    rules = {r.predicate["code"]: r for r in at.rules_from_frames({"daily_limits": f}, report=rep)}
    assert set(rules) == {"98960", "H0004", "S5151", "81286", "02000", "J9999"}
    assert rep["daily_limits"]["recorded_not_compiled"] == {"period_limit_rows": 5, "anesthesia_time_units": 2,
                                                            "placeholder_maximum": 3, "two_daily_limits": 1}
    assert rep["daily_limits"]["two_daily_limits"] == {"count": 1, "codes": ["82435"]}
    assert rep["daily_limits"]["rules"] == 6
    c = at.table_conflicts({"daily_limits": f}, [])
    assert [(r["codes"], r["relationship"]) for r in c.to_dict("records")] == [
        ("00100", "not_compiled_anesthesia_time_units"), ("01999", "not_compiled_anesthesia_time_units"),
        ("82435", "file_states_two_daily_limits"), ("A0425", "not_compiled_placeholder_maximum"),
        ("J1234", "not_compiled_placeholder_maximum"), ("J7190", "not_compiled_placeholder_maximum")]
    an = c.set_index("codes").loc["01999"]
    assert an["table_reading"] == "Procedure Maximum Occurrence 2 unit(s), row 13" and an["rule_id"] is None
    assert "15-minute time units" in an["detail"] and "no daily rule is built" in an["detail"]
    ph = c.set_index("codes").loc["A0425"]
    assert "999999" in ph["detail"] and "placeholder" in ph["detail"] and "no daily rule is built" in ph["detail"]
    # the claims scope never brings one back; the patterns are config's, read at call time
    assert set(r.predicate["code"] for r in at.rules_from_frames({"daily_limits": f}, scope_codes={"00100", "J7190"})) \
        == set()
    monkeypatch.setattr(config, "AHCCCS_DAILY_RECORD_ONLY_CODES", r"^00[0-9]{3}$")
    monkeypatch.setattr(config, "AHCCCS_DAILY_PLACEHOLDER_MAX", r"^9{6,}$")
    rules = {r.predicate["code"] for r in at.rules_from_frames({"daily_limits": f})}
    assert {"J7190", "J1234"} & rules == {"J7190"} and "01999" not in rules and "00100" not in rules
    assert "A0425" not in rules     # 999999 is still all nines


def test_pairs_marked_both_ways(tmp_path):
    rows = SD_ROWS + [("H0035", "Mental health partial hospitalization", "One Per Day", ["D", "D", "A"])]
    f = at.parse_file(same_day_xlsx(tmp_path / "sd.xlsx", rows=rows))["frame"]
    assert at.pairs_both_ways(f) == {"2026-10-01": [("H0014", "H0035")]}       # H0014 x H0035 = D and H0035 x H0014 = D
    rep = {}
    pairs = {(r.predicate["code_b"], r.predicate["code_a"])
             for r in at.rules_from_frames({"same_day_disallow": f}, report=rep)}
    assert {("H0014", "H0035"), ("H0035", "H0014")} <= pairs                    # a finding on each line
    assert rep["same_day_disallow"]["pairs_both_ways"] == 1
    assert at.pairs_both_ways(at.parse_file(same_day_xlsx(tmp_path / "sd2.xlsx"))["frame"]) == {"2026-10-01": []}


def test_a_pair_disallowed_both_ways_carries_both_ways_and_says_one_line_would_be_denied(tmp_path):
    """2026-10-04 (v5.2b, critic F4): a version marking the same two codes D / A* in BOTH directions makes each line the
    finding of its own rule; AHCCCS would deny one of the two lines, so the two findings' dollars are not additive. Both
    rules carry predicate both_ways = True (the key is absent on every other rule), and their words say so."""
    rows = SD_ROWS + [("H0035", "Mental health partial hospitalization", "One Per Day", ["D", "D", "A*"]),
                      ("S5151", "Unskilled respite care", "Per Diem", ["A", "D", "D"])]
    f = at.parse_file(same_day_xlsx(tmp_path / "sd.xlsx", rows=rows))["frame"]
    # H0014 x H0035 = D both ways; H0035 x S5151 = A* one way and D the other (both ways too); H0014 x S5151 = A* / A
    assert at.pairs_both_ways(f) == {"2026-10-01": [("H0014", "H0035"), ("H0035", "S5151")]}
    rules = {(r.predicate["code_b"], r.predicate["code_a"]): r for r in at.rules_from_frames({"same_day_disallow": f})}
    both = {k for k, r in rules.items() if "both_ways" in r.predicate}
    assert both == {("H0014", "H0035"), ("H0035", "H0014"), ("H0035", "S5151"), ("S5151", "H0035")}
    assert all(rules[k].predicate["both_ways"] is True for k in both)
    for k, r in rules.items():
        said = "AHCCCS would deny one of the two lines"
        assert (said in r.statement) == (said in r.notes) == (k in both), (k, r.statement)
    r = rules[("H0035", "S5151")]                                # row H0035 x column S5151 = A*, its reverse is D
    assert r.predicate["scope"] == "member_servicing_billing_day"
    assert "the S5151 line is also the finding of the reverse rule" in r.statement
    assert "both ways (cell F12 'A*', reverse cell E13 'D')" in r.notes
    assert schema.validate_predicate(r.predicate, origin="ahcccs_table") == (True, "")
    acc, rej = validate_gate.gate(list(rules.values()))
    assert not rej and all(a["machine_checkable"] for a in acc)
    # the claims scope keeps or drops the two directions together (a pair needs both codes)
    scoped = at.rules_from_frames({"same_day_disallow": f}, scope_codes={"H0035", "S5151"})
    assert {(r.predicate["code_b"], r.predicate["code_a"]) for r in scoped if r.predicate.get("both_ways")} == {
        ("H0035", "S5151"), ("S5151", "H0035")}


def test_two_files_for_one_version_are_refused(frames, tmp_path):
    twin = at.parse_file(same_day_xlsx(tmp_path / "twin.xlsx", intro=" "))   # the same version re-saved: another sha256
    assert twin["file_sha256"] != frames["_sha"]["sd_new"]
    sd = pd.concat([frames["same_day_disallow"], twin["frame"]], ignore_index=True)
    with pytest.raises(ValueError, match="held by two different files"):
        at.rules_from_frames({"same_day_disallow": sd})


# ---------------------------------------------------------------------------------------------------- readings gate
def _readings(tmp_path, signed=(), reviewer="SB", drop=(), name="readings.csv", binds=None, encoding="utf-8",
              header=None):
    """A copy of the shipped readings with the readings of `signed` tables signed; binds: {(table, id): text} replaces
    a reading's binds; header: the header line written instead of the column names (padding, case ...)."""
    rows = [r for r in at.read_readings(os.path.join(PKG, "reference", "ahcccs_table_readings.csv"))]
    cols = at.READING_COLUMNS + [c for c in getattr(at, "READING_OPTIONAL_COLUMNS", []) if any(c in r for r in rows)]
    out = tmp_path / name
    with open(out, "w", newline="", encoding=encoding) as f:
        if header is not None:
            f.write(header + "\r\n")
        w = csv.DictWriter(f, fieldnames=cols)
        if header is None:
            w.writeheader()
        for r in rows:
            if (r["table_key"], r["reading_id"]) in drop:
                continue
            if r["table_key"] in signed:
                r = dict(r, status="signed", reviewer=reviewer, reviewed_at="2026-10-05")
            if binds and (r["table_key"], r["reading_id"]) in binds:
                r = dict(r, binds=binds[(r["table_key"], r["reading_id"])])
            w.writerow(r)
    return str(out)


# 2026-10-04 (v5.2b): what SB decided keeps "SB (2026-10-04)"; what the independent critic's fixes added is marked so
SB_DECIDED = "SB (2026-10-04)"
PROPOSED = "proposed after independent review (2026-10-04); SB to decide"


def test_shipped_readings_are_proposed_sb_decisions_one_row_per_reading():
    rows = at.read_readings()
    assert [(r["table_key"], r["reading_id"]) for r in rows] == [
        (k, rid) for k in at.TABLE_KEYS for rid in at.REQUIRED_READINGS[k]]
    assert at.REQUIRED_READINGS["daily_limits"] == ("daily_max", "not_compiled", "period_limits", "versions")
    by = {(r["table_key"], r["reading_id"]): r for r in rows}
    new_parts = {("same_day_disallow", "A_star"), ("same_day_disallow", "flagged_line"), ("daily_limits", "daily_max"),
                 ("b2_matrix", "provider_types")}
    for k, r in by.items():
        if k == ("daily_limits", "not_compiled"):                         # a new reading: nothing SB decided yet
            assert r["decided_by"] == PROPOSED, k
        elif k in new_parts:                                              # SB's decision + a part added after review
            assert r["decided_by"].startswith(SB_DECIDED + "; ") and r["decided_by"].endswith(PROPOSED), k
        else:
            assert r["decided_by"] == SB_DECIDED, k
    assert {r["status"] for r in rows} == {"proposed"}
    assert all(r["reviewer"] == "" and r["reviewed_at"] == "" and len(r["reading"]) > 40 for r in rows)
    for k in at.TABLE_KEYS:
        assert at.unsigned_readings(k) == list(at.REQUIRED_READINGS[k])
        assert at.table_compiles(k)[0] is False
    # every value a reading binds is config's current value: the shipped file and config agree
    assert {k: r.get("binds", "") for k, r in by.items() if r.get("binds")} == {
        ("same_day_disallow", "A_star"): "AHCCCS_SAME_PROVIDER_SCOPE=member_servicing_billing_day",
        ("daily_limits", "daily_max"): "AHCCCS_DAILY_LIMIT_SCOPE=member_servicing_billing_day",
        ("daily_limits", "not_compiled"): "AHCCCS_DAILY_RECORD_ONLY_CODES=^0[01][0-9]{3}$; "
                                          "AHCCCS_DAILY_PLACEHOLDER_MAX=^9{3,}$",
        ("b2_matrix", "provider_types"): "AHCCCS_B2_COMPILE_CODES=^H[02][0-9]{3}$; "
                                         "AHCCCS_B2_PROVIDER_ROLE=billing_or_rendering; GROUP_BILLING_PROVIDER_TYPES=01"}
    assert all(at.binding_mismatches(k) == [] for k in at.TABLE_KEYS)


def test_readings_say_how_same_provider_is_read_what_is_not_compiled_and_both_ways():
    """2026-10-04 (v5.2b): the reviewer signs words that say (a) 'same provider' is the same servicing AND billing
    provider id until SB settles clinician vs site, and what that misses; (b) a pair marked both ways carries both_ways
    and AHCCCS would deny one of the two lines - the dollars are not additive; (c) the anesthesia codes, the all-nines
    maxima and the codes stating two daily limits are not compiled; (d) a group's B2 line is judged on its rendering
    provider's type. The status stays 'proposed'."""
    rd = {(r["table_key"], r["reading_id"]): r["reading"] for r in at.read_readings()}
    for k in (("same_day_disallow", "A_star"), ("daily_limits", "daily_max")):
        t = rd[k]
        assert "the same servicing provider id (SProv_ID) AND the same billing provider id (BProv_ID)" in t, k
        assert "member_servicing_billing_day" in t and "(service site or residential placement)" in t, k
        assert "a clinician billing through two agencies" in t and "two clinicians of one site" in t, k
        assert "never a false finding from the choice" in t and "SB to settle" in t, k
    assert "corrected its own A* programming" in rd[("same_day_disallow", "A_star")]
    fl = rd[("same_day_disallow", "flagged_line")]
    assert "in both directions" in fl and "both lines of such a pair are findings" in fl and "both_ways" in fl
    assert "AHCCCS would deny one of the two lines" in fl and "not additive" in fl
    dm = rd[("daily_limits", "daily_max")]
    assert "are not compiled" in dm and "Frequency Cd D, Frequency Value 1" in dm and "file_states_two_daily_limits" in dm
    assert "verify_span" in dm
    nc = rd[("daily_limits", "not_compiled")]
    for w in ("00100-01999", "15-minute time units", "274 anesthesia codes, 272 of them with a maximum of 1 or 2",
              "999 on 113 codes", "999999 on J2002", "placeholder", "not_compiled_anesthesia_time_units",
              "not_compiled_placeholder_maximum", "anesthesia code, all-nines maximum, two daily limits"):
        assert w in nc, w
    pt = rd[("b2_matrix", "provider_types")]
    for w in ("01 'Group-Payment ID'", "rendering (servicing) provider's type", "billing_or_rendering",
              "A line whose judged provider type is missing is never a finding"):
        assert w in pt, w
    assert {r["status"] for r in at.read_readings()} == {"proposed"}


def test_readings_bind_config_values(tmp_path, monkeypatch):
    """2026-10-04 (v5.2b, critic F8): a signature is bound to the config values its words describe (column binds,
    'KEY=VALUE; KEY2=VALUE2', a tuple comma-joined). A changed value un-signs the reading - the table does not compile,
    and the reason names the reading, the key, the signed and the current value - until it is signed again."""
    monkeypatch.setattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", True)
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", _readings(tmp_path, signed=at.TABLE_KEYS))
    assert all(at.table_compiles(k)[0] for k in at.TABLE_KEYS)
    monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", "member_provider_day")
    ok, why = at.table_compiles("same_day_disallow")
    assert not ok and ("reading A_star binds AHCCCS_SAME_PROVIDER_SCOPE=member_servicing_billing_day but "
                       "config.AHCCCS_SAME_PROVIDER_SCOPE is 'member_provider_day'") in why, why
    assert at.unsigned_readings("same_day_disallow") == ["A_star"]
    assert at.binding_mismatches("same_day_disallow") == [{"reading_id": "A_star", "key": "AHCCCS_SAME_PROVIDER_SCOPE",
                                                           "signed": "member_servicing_billing_day",
                                                           "current": "member_provider_day"}]
    assert at.table_compiles("daily_limits")[0] and at.table_compiles("b2_matrix")[0]     # other tables unaffected
    monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", "member_servicing_billing_day")
    # a tuple value is compared element by element
    monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", ("01", "B9"))
    ok, why = at.table_compiles("b2_matrix")
    assert not ok and "GROUP_BILLING_PROVIDER_TYPES=01 but config.GROUP_BILLING_PROVIDER_TYPES is '01,B9'" in why
    monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", ["01"])
    assert at.table_compiles("b2_matrix")[0]
    monkeypatch.setattr(config, "AHCCCS_DAILY_PLACEHOLDER_MAX", r"^9{4,}$")
    ok, why = at.table_compiles("daily_limits")
    assert not ok and "reading not_compiled binds AHCCCS_DAILY_PLACEHOLDER_MAX=^9{3,}$" in why
    monkeypatch.setattr(config, "AHCCCS_DAILY_PLACEHOLDER_MAX", r"^9{3,}$")
    # a key config does not have never holds; a malformed binds cell stops the read (never half-read)
    p = _readings(tmp_path, signed=at.TABLE_KEYS, name="r2.csv",
                  binds={("same_day_disallow", "D"): "AHCCCS_SAME_PROVIDER_SCOP=member_day"})
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", p)
    ok, why = at.table_compiles("same_day_disallow")
    assert not ok and "reading D binds AHCCCS_SAME_PROVIDER_SCOP=member_day but config has no AHCCCS_SAME_PROVIDER_SCOP" \
        in why
    for bad, msg in (("AHCCCS_SAME_PROVIDER_SCOPE member_day", "is not KEY=VALUE"),
                     ("scope=member_day", "is not a config attribute name"),
                     ("AHCCCS_SAME_PROVIDER_SCOPE=a; AHCCCS_SAME_PROVIDER_SCOPE=b", "twice")):
        monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", _readings(
            tmp_path, name="bad.csv", binds={("same_day_disallow", "A"): bad}))
        with pytest.raises(ValueError, match=f"same_day_disallow/A: binds .*{msg}"):
            at.read_readings()
    # the switch off compiles whatever the readings say, and names a binding that no longer holds
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", _readings(tmp_path, name="r3.csv"))
    monkeypatch.setattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", False)
    monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", "member_day")
    ok, why = at.table_compiles("same_day_disallow")
    assert ok and "is off" in why and "A_star binds AHCCCS_SAME_PROVIDER_SCOPE=member_servicing_billing_day" in why


def test_a_reading_that_drops_a_required_bind_is_not_signed(tmp_path, monkeypatch):
    """Critic re-check N1 (2026-10-05): binds is optional in the CSV, so clearing A_star's binds cell kept it signed
    while config.AHCCCS_SAME_PROVIDER_SCOPE changed. Every reading whose words describe a config value must bind it
    (REQUIRED_BINDS); one that does not is unsigned, with a reason naming the key."""
    monkeypatch.setattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", True)
    shipped = {(r["table_key"], r["reading_id"]): at.parse_binds(r.get("binds"))
               for r in at.read_readings(os.path.join(PKG, "reference", "ahcccs_table_readings.csv"))}
    for (tk, rid), keys in at.REQUIRED_BINDS.items():                   # the shipped CSV binds every required key
        assert set(keys) <= set(shipped[(tk, rid)]), (tk, rid)
    for (tk, rid), keys in at.REQUIRED_BINDS.items():
        p = _readings(tmp_path, signed=at.TABLE_KEYS, name=f"{tk}_{rid}.csv", binds={(tk, rid): ""})
        monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", p)
        ok, why = at.table_compiles(tk)
        assert not ok and f"reading {rid} does not bind {keys[0]}" in why, why
        assert at.unsigned_readings(tk) == [rid]
        # the other tables are unaffected
        assert all(at.table_compiles(k)[0] for k in at.TABLE_KEYS if k != tk)
    # the same with the whole column gone: every table with a required bind stops compiling
    p = tmp_path / "nobinds.csv"
    rows = at.read_readings(os.path.join(PKG, "reference", "ahcccs_table_readings.csv"))
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=at.READING_COLUMNS, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(dict(r, status="signed", reviewer="SB", reviewed_at="2026-10-05"))
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", str(p))
    assert not any(at.table_compiles(k)[0] for k in at.TABLE_KEYS)


def test_readings_csv_saved_by_excel_with_a_bom_and_padded_headers(tmp_path, monkeypatch):
    """2026-10-04 (v5.2b, critic F16): Excel's 'CSV UTF-8' starts the file with a byte-order mark - the first header
    read as '\ufefftable_key' and the build stopped on 'missing column(s) [table_key]'. Read as utf-8-sig, header
    names stripped."""
    cols = at.READING_COLUMNS + at.READING_OPTIONAL_COLUMNS
    p = _readings(tmp_path, signed=("b2_matrix",), encoding="utf-8-sig", header=",".join(f" {c} " for c in cols))
    assert open(p, "rb").read(3) == b"\xef\xbb\xbf"
    rows = at.read_readings(p)
    assert len(rows) == sum(len(v) for v in at.REQUIRED_READINGS.values()) and rows[0]["table_key"] == "same_day_disallow"
    monkeypatch.setattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", True)
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", p)
    assert at.table_compiles("b2_matrix")[0] and not at.table_compiles("daily_limits")[0]


def test_readings_sha256_is_the_hash_of_the_file_bytes(tmp_path, monkeypatch):
    import hashlib
    shipped = os.path.join(PKG, "reference", "ahcccs_table_readings.csv")
    assert at.readings_sha256() == hashlib.sha256(open(shipped, "rb").read()).hexdigest()
    p = _readings(tmp_path, signed=("b2_matrix",))
    assert at.readings_sha256(p) == hashlib.sha256(open(p, "rb").read()).hexdigest() != at.readings_sha256()
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", p)
    assert at.readings_sha256() == at.readings_sha256(p)


def test_readings_gate(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", True)
    p = _readings(tmp_path, signed=("same_day_disallow",))
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", p)
    ok, why = at.table_compiles("same_day_disallow")
    assert ok and "all 7 reading(s) signed (SB)" in why
    ok, why = at.table_compiles("daily_limits")
    assert not ok and "4 of 4 reading(s) not signed (daily_max, not_compiled, period_limits, versions)" in why
    # signed without a reviewer's name is not signed
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", _readings(tmp_path, signed=("same_day_disallow",), reviewer=""))
    assert at.unsigned_readings("same_day_disallow") == list(at.REQUIRED_READINGS["same_day_disallow"])
    # a reading missing from the file counts as unsigned
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS",
                        _readings(tmp_path, signed=("same_day_disallow",), drop={("same_day_disallow", "diagonal")}))
    assert at.unsigned_readings("same_day_disallow") == ["diagonal"]
    assert not at.table_compiles("same_day_disallow")[0]
    # a malformed governance file is never half-read
    bad = tmp_path / "bad.csv"
    bad.write_text("table_key,reading_id,reading,decided_by,status,reviewer,reviewed_at\n"
                   "same_day_disallow,D,x,SB,approved,SB,\n")
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", str(bad))
    with pytest.raises(ValueError, match="status 'approved'"):
        at.table_compiles("same_day_disallow")
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", str(tmp_path / "missing.csv"))
    assert at.table_compiles("b2_matrix") == (False, f"b2_matrix: no readings file {tmp_path / 'missing.csv'} - "
                                                     f"nothing compiles unsigned")
    # the switch off: compiles on proposed readings, and says so
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", os.path.join(PKG, "reference", "ahcccs_table_readings.csv"))
    monkeypatch.setattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", False)
    ok, why = at.table_compiles("b2_matrix")
    assert ok and "is off" in why


# ---------------------------------------------------------------------------------------------------- conflicts
def _pair(rid, a, b, scope=None, eff=None, end=None, origin="extracted", **kw):
    p = {"type": "code_pair_prohibited", "code_a": a, "code_b": b, "modifier_indicator": "0"}
    if scope:
        p["scope"] = scope
    return dict({"rule_id": rid, "origin": origin, "predicate": p, "effective_date": eff, "end_date": end}, **kw)


ROLE_DIFF = ("the rule judges the billing provider's type, the table reading judges the billing provider's type - for "
             "a group (billing provider type 01) the rendering provider's type")


def test_table_conflicts(frames):
    rules = [
        # Ch.19 (p.20): "Claims with T1016 must not be billed on the same day as ... H0035 ..." - the table marks A
        _pair("EXT-ch19", "H0035", "T1016", scope="member_provider_day", eff="2024-07-08"),
        _pair("EXT-wider", "S5151", "T1016", scope="member_day"),          # table A*: same provider only
        _pair("EXT-narrow", "H0014", "H0001"),                            # no scope = member_provider_day; table D
        _pair("EXT-agrees", "H0035", "H0014", scope="member_day"),        # table D, member_day: no row
        _pair("EXT-old", "H0035", "T1016", end="2026-06-30"),             # ended before the oldest version: no row
        _pair("NCCI-1", "H0035", "T1016", origin="ncci"),                 # never compared
        _pair("EXT-rej", "H0035", "T1016", review_status="rejected"),     # a rejected draft is not a rule
        {"rule_id": "EXT-b2", "origin": "extracted", "effective_date": None, "end_date": None,
         "predicate": json.dumps({"type": "provider_type_allowed", "code_set": ["H0035"],
                                  "provider_types": ["B2", "B5", "02", "71"]})},           # a JSON text predicate
        {"rule_id": "EXT-b2ok", "origin": "manual",
         "predicate": {"type": "provider_type_allowed", "code": "H0035", "provider_types": ["71", "B6", "2", "B5"]}},
        {"rule_id": "EXT-cpt", "origin": "extracted",
         "predicate": {"type": "provider_type_allowed", "code": "90791", "provider_types": ["08"]}},  # recorded only
        {"rule_id": "EXT-chw", "origin": "manual",
         "predicate": {"type": "max_units_per_day", "code_set": ["98960", "98961"], "threshold": 3}},
        {"rule_id": "EXT-s5151", "origin": "extracted",
         "predicate": {"type": "max_units_per_day", "code": "S5151", "threshold": 1}},             # agrees
    ]
    c = at.table_conflicts({k: v for k, v in frames.items() if not k.startswith("_")}, rules)
    assert list(c.columns) == at.CONFLICT_COLUMNS
    got = {(r["rule_id"], r["version_date"], r["relationship"]) for r in c.to_dict("records")}
    assert got == {
        ("EXT-ch19", "2026-07-01", "table_allows"), ("EXT-ch19", "2026-10-01", "table_allows"),
        ("EXT-wider", "2026-07-01", "pair_scope_differs"), ("EXT-wider", "2026-10-01", "pair_scope_differs"),
        ("EXT-narrow", "2026-07-01", "pair_scope_differs"), ("EXT-narrow", "2026-10-01", "pair_scope_differs"),
        ("EXT-b2", "2026-10-01", "provider_types_differ"),
        # 2026-10-04 (v5.2b, critic F1): the matrix's own list, judged on the BILLING type (no provider_role): a group's
        # line the table reading judges on its rendering type
        ("EXT-b2ok", "2026-10-01", "provider_role_differs"),
        ("EXT-chw", "2026-09-14", "daily_threshold_differs")}
    row = c[(c["rule_id"] == "EXT-ch19") & (c["version_date"] == "2026-10-01")].iloc[0]
    assert row["codes"] == "H0035/T1016" and row["table_reading"].startswith("A at cell E11")
    assert "the rule prohibits the pair" in row["detail"] and row["rule_origin"] == "extracted"
    b2 = c[c["rule_id"] == "EXT-b2"].iloc[0]
    assert b2["detail"] == "only in the rule: B2; only in the B2 Matrix: B6; " + ROLE_DIFF
    assert b2["table_reading"] == "billing_or_rendering provider types 02, 71, B5, B6"
    w = c[(c["rule_id"] == "EXT-wider") & (c["version_date"] == "2026-10-01")].iloc[0]
    assert "flags two providers the table allows" in w["detail"]
    n = c[(c["rule_id"] == "EXT-narrow") & (c["version_date"] == "2026-10-01")].iloc[0]
    assert "a pair split across two providers is missed" in n["detail"]
    chw = c[c["rule_id"] == "EXT-chw"].iloc[0]
    assert chw["codes"] == "98960" and "stricter" in chw["detail"] and "combined cap" in chw["detail"]
    # a Rule object works as well as a dict
    from schema import Rule
    obj = Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy", statement="s",
               predicate={"type": "code_pair_prohibited", "code_a": "H0035", "code_b": "T1016"}, rule_id="EXT-obj")
    assert len(at.table_conflicts({k: v for k, v in frames.items() if not k.startswith("_")}, [obj])) == 2


def test_table_conflicts_on_the_real_tables(real):
    """The cases SB named: Ch.19's T1016 / H0035 pair against the Same Day table (A), and a B2 list 02/71/B2/B5
    against the matrix's 02/71/B5/B6 for H0035."""
    frames = {k: g["frame"] for k, g in real.items()}
    rules = [_pair("EXT-ch19", "H0035", "T1016", scope="member_provider_day", eff="2024-07-08"),
             {"rule_id": "EXT-h35", "origin": "extracted",
              "predicate": {"type": "provider_type_allowed", "code_set": ["H0035"],
                            "provider_types": ["B2", "B5", "02", "71"], "provider_role": "billing"}}]
    c = at.table_conflicts(frames, rules).set_index("rule_id")
    assert c.loc["EXT-ch19", "relationship"] == "table_allows" and "G50" in c.loc["EXT-ch19", "table_reading"]
    assert c.loc["EXT-h35", "relationship"] == "provider_types_differ"
    assert c.loc["EXT-h35", "detail"] == "only in the rule: B2; only in the B2 Matrix: B6; " + ROLE_DIFF


# ---------------------------------------------------------------------------------------------------- log / corpus
def _log(*rows):
    return pd.DataFrame([dict(zip(at.LOG_COLUMNS, r)) for r in rows])


LOG = _log(("same_day_disallow", "sd.xlsx", "a" * 64, "2026-10-01", 704, "loaded", None, "t", None),
           ("same_day_disallow", "sd0.xlsx", "b" * 64, "2026-07-01", 700, "loaded", None, "t", None),
           ("same_day_disallow", "sd.xlsx", "a" * 64, "2026-10-01", 704, "already_loaded", None, "t2", None),
           ("daily_limits", "d.xlsx", "c" * 64, "2026-09-14", 15600, "loaded", None, "t", None),
           (None, "bad.xlsx", "d" * 64, None, None, "rejected", "boom", "t", None))


def test_loaded_versions_and_corpus_entries():
    lv = at.loaded_versions(LOG)
    assert [v["version_date"] for v in lv["same_day_disallow"]] == ["2026-07-01", "2026-10-01"]
    assert lv["daily_limits"][0]["rows"] == 15600 and lv["b2_matrix"] == []
    assert at.corpus_entries(LOG) == {"table:same_day_disallow:2026-07-01": "b" * 64,
                                      "table:same_day_disallow:2026-10-01": "a" * 64,
                                      "table:daily_limits:2026-09-14": "c" * 64}
    assert at.loaded_versions(None) == {k: [] for k in at.TABLE_KEYS} and at.corpus_entries(None) == {}


# 2026-10-04 (v5.2b, critic F7): 07 trusted the UC tables - a row deleted or edited there silently changed the rules, a
# dropped table built 0 rules while the log said loaded. 00b now logs a canonical hash of each version's rows, and
# check_loaded(frames, log) compares the tables with the log (07 stops, 01 check T fails, 00b ends red).
def test_rows_sha256_is_a_canonical_hash_of_the_normalised_rows(frames):
    f = frames["same_day_disallow"]
    new = f[f["version_date"] == "2026-10-01"].reset_index(drop=True)
    h = at.rows_sha256("same_day_disallow", new)
    assert len(h) == 64 and h == at.rows_sha256("same_day_disallow", new.iloc[::-1])          # row order: no matter
    assert h == at.rows_sha256("same_day_disallow", new.assign(loaded_at="2026-10-04T10:00:00+00:00"))
    # the catalog round trip (text 'true', padded codes, a datetime version) gives the same hash
    rt = new.astype(object).assign(changed=new["changed"].map(lambda b: "true" if b else "false"),
                                   row_code=" " + new["row_code"].str.lower() + " ",
                                   version_date=pd.Timestamp("2026-10-01"))
    assert at.rows_sha256("same_day_disallow", rt) == h
    for i in range(len(new)):                          # any one value of any one row changes the hash
        edited = new.copy()
        edited.loc[i, "indicator"] = "A" if edited.loc[i, "indicator"] != "A" else "D"
        assert at.rows_sha256("same_day_disallow", edited) != h, i
        assert at.rows_sha256("same_day_disallow", new.drop(index=i)) != h, i
    d = frames["daily_limits"]                         # Spark's long with nulls comes back as float: 4.0 / NaN
    dh = at.rows_sha256("daily_limits", d)
    assert at.rows_sha256("daily_limits", d.assign(limit1=[float("nan") if v is None else float(v)
                                                           for v in d["limit1"]])) == dh
    b = frames["b2_matrix"]
    assert at.rows_sha256("b2_matrix", b.assign(provider_type=[t.lstrip("0") for t in b["provider_type"]])) == \
        at.rows_sha256("b2_matrix", b)                 # '2' is '02', as the claims column reads it
    assert at.rows_sha256("daily_limits", at.empty_frame("daily_limits")) == at.rows_sha256("daily_limits", None)


def _loaded_log(frames, sha_of=lambda key, vd, g: g["file_sha256"].iloc[0], rows_sha=True, **over):
    """A log as 00b writes it for the fixture's versions (status loaded, rows, rows_sha256)."""
    out = []
    for key in at.TABLE_KEYS:
        for (vd, sha), g in frames[key].groupby(["version_date", "file_sha256"]):
            out.append({"table_key": key, "file_name": g["file_name"].iloc[0], "file_sha256": sha, "version_date": vd,
                        "rows": len(g), "status": "loaded", "detail": None, "loaded_at": "2026-10-04T10:00:00+00:00",
                        "archived_path": None, **({"rows_sha256": at.rows_sha256(key, g)} if rows_sha else {}),
                        **over})
    return pd.DataFrame(out)


def test_check_loaded_compares_each_loaded_version_with_the_log(frames):
    fr = {k: v for k, v in frames.items() if not k.startswith("_")}
    log = _loaded_log(fr)
    assert at.check_loaded(fr, log) == []
    sd = fr["same_day_disallow"]
    # a row deleted outside 00b
    gone = dict(fr, same_day_disallow=sd.drop(index=sd.index[(sd["version_date"] == "2026-10-01")][0]))
    (p,) = at.check_loaded(gone, log)
    assert p.startswith("same_day_disallow version 2026-10-01 (sd_new.xlsx, sha256 ") and \
        "the log loaded 9 row(s), main.sedo.ahcccs_same_day_disallow holds 8" in p.replace(
            config.AHCCCS_TABLES["same_day_disallow"]["table"], "main.sedo.ahcccs_same_day_disallow")
    # a row edited outside 00b: the same count, another hash
    edited = sd.copy()
    i = edited.index[(edited["version_date"] == "2026-07-01") & (edited["indicator"] == "A")][0]
    edited.loc[i, "indicator"] = "D"
    (p,) = at.check_loaded(dict(fr, same_day_disallow=edited), log)
    assert "same_day_disallow version 2026-07-01" in p and "holds the logged 9 row(s) but not the rows 00b loaded" in p
    assert "edited outside 00b" in p
    # ... which an old log row (no rows_sha256) cannot see: count only
    assert at.check_loaded(dict(fr, same_day_disallow=edited), _loaded_log(fr, rows_sha=False)) == []
    # a row added to a loaded version (B2 holds one row per code + provider type: a new type for H0035)
    b2 = fr["b2_matrix"]
    more = pd.concat([b2, b2.iloc[[0]].assign(provider_type="B9", source_row=99)], ignore_index=True)
    (p,) = at.check_loaded(dict(fr, b2_matrix=more), log)
    assert p.startswith("b2_matrix version 2026-10-01 (b.xlsx, sha256 ") and "the log loaded 6 row(s)" in p
    assert "holds 7 - rows were deleted or added outside 00b" in p
    # a version the log never loaded
    extra = sd[sd["version_date"] == "2026-10-01"].assign(version_date="2027-01-01", file_sha256="e" * 64)
    (p,) = at.check_loaded(dict(fr, same_day_disallow=pd.concat([sd, extra], ignore_index=True)), log)
    assert "version 2027-01-01 (sha256 eeeeeeeeeeee)" in p and "the log never loaded" in p
    # a table dropped or emptied while the log has loaded versions (07 passes only the non-empty frames)
    for gone in ({k: v for k, v in fr.items() if k != "b2_matrix"}, dict(fr, b2_matrix=at.empty_frame("b2_matrix"))):
        (p,) = at.check_loaded(gone, log)
        assert p.startswith("b2_matrix: ") and "holds no row, yet the log has 1 loaded version(s) (2026-10-01)" in p
    # no log at all, rows in the tables: every version is one the log never loaded
    assert len(at.check_loaded(fr, None)) == 4 and at.check_loaded({}, None) == []
    # the LATEST 'loaded' row of a version counts; already_loaded / rejected rows are not loads
    later = log.copy()
    later.loc[0, "rows"] = 99
    later = pd.concat([later, log.iloc[[0]].assign(loaded_at="2026-10-05T00:00:00+00:00"),
                       log.iloc[[1]].assign(status="already_loaded", rows=1, loaded_at="2026-10-06T00:00:00+00:00"),
                       log.iloc[[2]].assign(status="rejected", rows=None, rows_sha256=None)], ignore_index=True)
    assert at.check_loaded(fr, later) == []
    # the log read back from the catalog: rows as float, a missing rows_sha256 as NaN
    assert at.check_loaded(fr, log.assign(rows=log["rows"].astype(float))) == []


def test_corpus_bar_counts_a_loaded_table_and_drops_it_from_the_pending_list():
    chapters = {"1": 0, "10": 0}
    pending = {"same_day_disallow": ("d", "u"), "daily_limits": ("d", "u"), "b2_matrix": ("d", "u"),
               "pa_guidelines": ("d", "u")}
    ok, why = quality.corpus_bar({"1": "a", "10": "b"}, chapters, pending, "corpus-t",
                                 loaded_tables=at.loaded_versions(LOG))
    assert not ok and "2 AHCCCS rule table(s) loaded: daily_limits (2026-09-14), same_day_disallow (2026-07-01, " \
                      "2026-10-01)" in why
    assert "2 rule source(s) still to load before the corpus is complete (config.CORPUS_PENDING): b2_matrix, " \
           "pa_guidelines" in why and "AHCCCS policy" not in why
    full = {k: [{"version_date": "2026-10-01"}] for k in at.TABLE_KEYS}
    assert quality.corpus_bar({"1": "a", "10": "b"}, chapters, {k: pending[k] for k in at.TABLE_KEYS}, "c", full)[0]
    # nothing loaded: exactly the old reason
    assert quality.corpus_bar({"1": "a"}, chapters, pending, "c", at.loaded_versions(None)) == \
        quality.corpus_bar({"1": "a"}, chapters, pending, "c")


def _v03_tables(log):
    t = {config.STATE_RULES_TABLE: pd.DataFrame([{"rule_id": "EXT-1", "origin": "extracted", "chapter": "19",
                                                   "review_status": "draft"}]),
         f"{config.KB}.policy_document_inventory": pd.DataFrame([{"chapter": "19", "doc_hash": "H19",
                                                                 "fetched_at": "2026-10-01T00:00:00"}]),
         f"{config.KB}.policy_extraction_log": pd.DataFrame([{"chapter": "19", "doc_hash": "H19", "run_id": "R2",
                                                             "error": None}])}
    rows = []
    for name in ("executable_rule_precision", "extraction_recall", "extraction_fidelity", "extraction_precision"):
        for st, sc in (("overall", "all"), ("chapter", "19")):
            rows.append({"metric": name, "scope_type": st, "scope": sc, "n": 400, "value": 0.995, "ci_low": 0.98,
                         "ci_high": 0.999, "unscored": 0, "scored_units": 400, "population": "engine_latest_run",
                         "corpus_version": policy_docs.corpus_version({"19": "H19"}), "sample_runs": '{"19": "R2"}',
                         "sample_id": "s1", "computed_at": "2026-10-04T10:00:00", "notes": "weighted by stratum size"})
    t[f"{config.KB}.policy_quality_metrics"] = pd.DataFrame(rows)
    if log is not None:
        t[config.AHCCCS_TABLES_LOG] = log
    return t


def test_v03_a_loaded_table_joins_the_corpus_and_leaves_the_pending_list(monkeypatch):
    nbf.install(monkeypatch)
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "form")              # no claims read
    g = nbf.run_notebook("validation/v03_pipeline_health.py", nbf.FakeSpark(_v03_tables(LOG)))
    bars = {r["measurement bar item"]: (r["status"], r["reason"]) for r in g["go_table"].to_dict("records")}
    st, why = next(v for k, v in bars.items() if k.startswith("Corpus frozen and complete"))
    assert st == "NOT YET" and "2 AHCCCS rule table(s) loaded: daily_limits (2026-09-14)" in why
    assert "same_day_disallow," not in why.split("still to load")[-1] and "b2_matrix" in why.split("still to load")[-1]
    docs_only = policy_docs.corpus_version({"19": "H19"})
    with_tables = policy_docs.corpus_version({"19": "H19", **at.corpus_entries(LOG)})
    assert g["CORPUS_VERSION"] == docs_only and g["CORPUS_WITH_TABLES"] == with_tables != docs_only
    assert f"corpus {with_tables}" in why
    # the extraction bars still stand on the documents-only corpus v01 stamps: loading a table does not stale them
    for k, (s, _) in bars.items():
        if k.startswith(("Executable-rule precision", "Extraction recall >=", "Extraction fidelity")):
            assert s == "GO", (k, bars[k])
    # no log table at all: the bar reads exactly as before v5.2
    g0 = nbf.run_notebook("validation/v03_pipeline_health.py", nbf.FakeSpark(_v03_tables(None)))
    assert g0["CORPUS_WITH_TABLES"] == g0["CORPUS_VERSION"] == docs_only


def _run_check_T(spark, hook_rows):
    """Run check T of 01_preflight_ncci from SOURCE (its _cT function) against `spark`; the claims query answers
    hook_rows. Returns (lines [(status, message)], queries)."""
    src = open(os.path.join(PKG, "notebooks", "01_preflight_ncci.py")).read()
    assert 'run("T", ' in src and src.index('run("T", ') < src.index("summary = pd.DataFrame(RESULTS")
    fn = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == "_cT")
    queries, lines = [], []

    def hook(q):
        queries.append(q)
        return hook_rows
    spark.sql_hook = hook
    g = {"spark": spark, "config": config,
         "CLAIMS": "main.prod_input.all_data_C_A", "DOS": "Svc_Begin_Dt", "ctype": lambda c, d="string": "date",
         "info": lambda m: lines.append(("info", m)), "ok": lambda m: lines.append(("PASS", m)),
         "warn": lambda m, minor=False: lines.append(("WARN", m)), "fail": lambda m: lines.append(("FAIL", m))}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), "01_preflight_ncci.py", "exec"), g)
    g["_cT"]()
    return lines, queries


def test_01_check_T(monkeypatch):
    """Check T of 01_preflight_ncci, run from source with the in-memory catalog: the versions, the dates each judges,
    the claim lines per window and before the oldest version, and whether 07 would compile the table."""
    nbf.install(monkeypatch)
    lines, queries = _run_check_T(nbf.FakeSpark({config.AHCCCS_TABLES_LOG: LOG}), [
        {"lo": "2026-01-02", "hi": "2026-12-30", "n": 100, "no_dos": 0, "before_oldest": 40, "w_0": 25, "w_1": 35}])
    text = "\n".join(f"{s} {m}" for s, m in lines)
    assert len(queries) == 2 and "DATE '2026-07-01'" in queries[0] and "AS w_1" in queries[0]
    assert ("info same_day_disallow version 2026-07-01 (sd0.xlsx, sha256 bbbbbbbbbbbb, 700 rows): judges 2026-07-01 .. "
            "2026-09-30 - 25 claim line(s) in that window") in text
    assert "judges 2026-10-01 .. open-ended - 35 claim line(s)" in text
    assert "WARN same_day_disallow: 40 claim line(s) (claims 2026-01-02 .. 2026-12-30) are dated before the oldest " \
           "loaded version 2026-07-01" in text
    assert "WARN same_day_disallow: 07 does NOT compile its rules" in text
    assert "WARN b2_matrix: no version loaded" in text
    # 2026-10-04 (v5.2b, critic F7): the log says loaded, the catalog holds no table at all - FAIL (07 stops on it)
    fails = [m for s, m in lines if s == "FAIL"]
    assert len(fails) == 2 and all("holds no row, yet the log has" in m and "07 stops on it" in m for m in fails)
    assert fails[0].startswith("same_day_disallow: ") and "2 loaded version(s) (2026-07-01, 2026-10-01)" in fails[0]
    # config.AHCCCS_TABLE_MAX_AGE_DAYS: the claims run to 2026-12-30, past 2026-09-14 + 62 days - WARN; 2026-10-01 +
    # 366 days (Same Day) is not passed
    assert ("WARN daily_limits: the claims run to 2026-12-30, more than 62 days (config.AHCCCS_TABLE_MAX_AGE_DAYS) "
            "after the newest loaded version 2026-09-14") in text
    assert "same_day_disallow: the claims run to" not in text


def test_01_check_T_fails_when_a_table_no_longer_holds_what_00b_loaded(drop, monkeypatch):
    """2026-10-04 (v5.2b, critic F7): check T runs check_loaded - the tables 00b wrote against its log - and FAILs each
    problem (07 stops on the same check)."""
    spark = nbf.FakeSpark()
    same_day_xlsx(drop / "SameDayDisallowTable.xlsx")
    daily_xlsx(drop / "HCPCSCPTProcedureswithDailyLimits.xlsx")
    nbf.run_notebook(NB00B, spark)
    rows = [{"lo": "2026-09-14", "hi": "2026-10-30", "n": 10, "no_dos": 0, "before_oldest": 0, "w_0": 10}]
    lines, _ = _run_check_T(spark, rows)
    assert not [m for s, m in lines if s == "FAIL"]
    assert ("PASS every loaded version's rows are in its table as loaded (row count and rows hash: "
            "ahcccs_tables.check_loaded)") in [f"{s} {m}" for s, m in lines]
    pdf, st = spark.tables[_tbl("same_day_disallow")]
    pdf = pdf.copy()
    pdf.loc[0, "indicator"] = "A" if pdf.loc[0, "indicator"] != "A" else "D"
    spark.tables[_tbl("same_day_disallow")] = (pdf, st)
    lines, _ = _run_check_T(spark, rows)
    (f,) = [m for s, m in lines if s == "FAIL"]
    assert f.startswith("same_day_disallow version 2026-10-01 (SameDayDisallowTable.xlsx, sha256 ")
    assert "a row was edited outside 00b" in f and f.endswith("- 07 stops on it")


def test_claims_window_sql():
    q = at.claims_window_sql("c.t", "Svc_Begin_Dt", "date", at.version_windows(["2026-07-01", "2026-10-01"]))
    assert "SUM(CASE WHEN `Svc_Begin_Dt` < DATE '2026-07-01' THEN 1 ELSE 0 END) AS before_oldest" in q
    assert ("SUM(CASE WHEN `Svc_Begin_Dt` >= DATE '2026-07-01' AND `Svc_Begin_Dt` <= DATE '2026-09-30' THEN 1 ELSE 0 "
            "END) AS w_0") in q
    assert "SUM(CASE WHEN `Svc_Begin_Dt` >= DATE '2026-10-01' THEN 1 ELSE 0 END) AS w_1" in q and q.endswith("FROM c.t")
    assert "TRY_CAST" in at.claims_window_sql("c.t", "D", "string", at.version_windows(["2026-07-01"]))


# ====================================================================================== (c) notebook 00b
NB00B = "00b_load_ahcccs_tables.py"


@pytest.fixture
def drop(tmp_path, monkeypatch):
    nbf.install(monkeypatch)
    d = tmp_path / "ahcccs_tables"
    d.mkdir()
    monkeypatch.setattr(config, "AHCCCS_TABLES_DIR", str(d))
    return d


def _tbl(key):
    return config.AHCCCS_TABLES[key]["table"]


def test_00b_loads_archives_logs_and_is_idempotent(drop, tmp_path):
    spark = nbf.FakeSpark()
    sd = same_day_xlsx(drop / "SameDayDisallowTable.xlsx")
    daily_xlsx(drop / "HCPCSCPTProcedureswithDailyLimits.xlsx")
    os.makedirs(drop / "manual")
    b2_xlsx(drop / "manual" / "B2Matrix.xlsx")                       # any sub-folder of the drop zone
    (drop / "~$SameDayDisallowTable.xlsx").write_bytes(b"lock")      # an Excel lock file is not a workbook to read
    g = nbf.run_notebook(NB00B, spark)
    log = spark.frame(config.AHCCCS_TABLES_LOG)
    assert sorted(log["status"]) == ["loaded"] * 3 and set(log["table_key"]) == set(at.TABLE_KEYS)
    assert len(spark.frame(_tbl("same_day_disallow"))) == 9 and len(spark.frame(_tbl("daily_limits"))) == 4
    b2 = spark.frame(_tbl("b2_matrix"))
    assert len(b2) == 6 and "02" in set(b2["provider_type"]) and "08" in set(b2["provider_type"])
    types = {f.name: f.dataType.typeName() for f in spark.table(_tbl("same_day_disallow")).schema.fields}
    assert types["changed"] == "boolean" and types["indicator"] == "string" and "loaded_at" in types
    dtypes = {f.name: f.dataType.typeName() for f in spark.table(_tbl("daily_limits")).schema.fields}
    assert dtypes["daily_max"] == dtypes["source_row"] == dtypes["limit2"] == "long"
    assert {f.name: f.dataType.typeName() for f in spark.table(config.AHCCCS_TABLES_LOG).schema.fields}["rows"] == "long"
    sha = at.sha256_file(sd)
    arch = drop / "_versions" / "same_day_disallow" / f"2026-10-01_{sha[:12]}.xlsx"
    assert arch.exists() and at.sha256_file(str(arch)) == sha and os.path.exists(sd)   # a copy; the original stays
    assert log.set_index("table_key").loc["same_day_disallow", "archived_path"] == str(arch)
    assert g["WINDOWS"]["same_day_disallow"] == {"2026-10-01": ("2026-10-01", None)}
    # the same files again: already_loaded, nothing appended, nothing archived twice
    n_writes = len(spark.writes)
    nbf.run_notebook(NB00B, spark)
    log = spark.frame(config.AHCCCS_TABLES_LOG)
    assert sorted(log["status"]) == ["already_loaded"] * 3 + ["loaded"] * 3
    assert len(spark.frame(_tbl("same_day_disallow"))) == 9 and len(spark.frame(_tbl("b2_matrix"))) == 6
    assert [w[0] for w in spark.writes[n_writes:]] == [config.AHCCCS_TABLES_LOG]
    assert sorted(os.listdir(drop / "_versions" / "same_day_disallow")) == [arch.name]


def test_00b_a_newer_version_adds_a_window(drop):
    spark = nbf.FakeSpark()
    same_day_xlsx(drop / "SameDayDisallowTable.xlsx")
    nbf.run_notebook(NB00B, spark)
    same_day_xlsx(drop / "SameDayDisallowTable_2027.xlsx", updated="1/1/2027",
                  rows=[("H0001", "Alcohol and/or drug Assessment", "Assessment", ["A", "A*", "A"])] + SD_ROWS[1:],
                  red=(("H0001", "H0014"),))
    g = nbf.run_notebook(NB00B, spark)
    assert g["WINDOWS"]["same_day_disallow"] == {"2026-10-01": ("2026-10-01", "2026-12-31"),
                                                 "2027-01-01": ("2027-01-01", None)}
    t = spark.frame(_tbl("same_day_disallow"))
    assert len(t) == 18 and sorted(t["version_date"].unique()) == ["2026-10-01", "2027-01-01"]
    # 07's view: frames_for_build reads the UC table back, and the old version stops the day before the new one
    frames, notes = at.frames_for_build(spark)
    assert len(frames["same_day_disallow"]) == 18 and len(frames["daily_limits"]) == 0
    assert any("daily_limits" in n and "does not exist" in n for n in notes)
    rules = at.rules_from_frames(frames)
    h = {(r.doc_version, r.end_date) for r in rules if r.predicate.get("code_b") == "H0001"
         and r.predicate.get("code_a") == "H0014"}
    assert h == {("2026-10-01", "2026-12-31")}                     # 2027: H0001 x H0014 is A, so no rule
    # the UC round trip changes nothing the rules depend on
    direct = at.rules_from_frames({"same_day_disallow": pd.concat(
        [at.parse_file(str(drop / f))["frame"] for f in ("SameDayDisallowTable.xlsx", "SameDayDisallowTable_2027.xlsx")],
        ignore_index=True)})
    assert sorted(r.rule_id for r in rules) == sorted(r.rule_id for r in direct)


def test_00b_a_bad_file_is_rejected_with_a_log_row_and_nothing_else_written(drop):
    spark = nbf.FakeSpark()
    same_day_xlsx(drop / "SameDayDisallowTable.xlsx")
    nbf.run_notebook(NB00B, spark)
    before = {k: len(spark.frame(_tbl(k))) for k in ("same_day_disallow",)}
    n_writes = len(spark.writes)
    same_day_xlsx(drop / "broken.xlsx", updated="1/1/2027",
                  rows=[("H0001", "x", "Assessment", ["D", "B", "A"])] + SD_ROWS[1:])
    with pytest.raises(RuntimeError, match="1 AHCCCS table file\\(s\\) rejected"):
        nbf.run_notebook(NB00B, spark)
    log = spark.frame(config.AHCCCS_TABLES_LOG)
    bad = log[log["file_name"] == "broken.xlsx"].iloc[0]
    assert bad["status"] == "rejected" and "cell E9" in bad["detail"] and "not D, A or A*" in bad["detail"]
    assert bad["table_key"] is None and pd.isna(bad["rows"]) and bad["archived_path"] is None
    assert [w[0] for w in spark.writes[n_writes:]] == [config.AHCCCS_TABLES_LOG]       # only the log row
    assert {k: len(spark.frame(_tbl(k))) for k in before} == before
    assert sorted(os.listdir(drop / "_versions" / "same_day_disallow")) == [
        f"2026-10-01_{at.sha256_file(str(drop / 'SameDayDisallowTable.xlsx'))[:12]}.xlsx"]
    assert os.path.exists(drop / "broken.xlsx")                  # never deleted


def test_00b_says_when_a_loaded_version_lost_its_rows(drop):
    """2026-10-04 (v5.2): the log says a version is loaded, but its table no longer holds that file's rows (dropped or
    deleted outside 00b). Re-running 00b skips the file (already_loaded), so nothing would ever notice: it ends red."""
    spark = nbf.FakeSpark()
    same_day_xlsx(drop / "SameDayDisallowTable.xlsx")
    nbf.run_notebook(NB00B, spark)
    spark.tables.pop(_tbl("same_day_disallow"))
    # 2026-10-04 (v5.2b, critic F7): 00b's last step is check_loaded (count + rows hash per loaded version)
    with pytest.raises(RuntimeError, match=r"same_day_disallow: \S+ holds no row, yet the log has 1 loaded version\(s\) "
                                           r"\(2026-10-01\) - the table was dropped or emptied outside 00b"):
        nbf.run_notebook(NB00B, spark)
    assert at.versions_without_rows(spark, at.loaded_versions(spark.frame(config.AHCCCS_TABLES_LOG))) == {
        "same_day_disallow": ["2026-10-01"]}


def test_00b_logs_each_versions_rows_hash_and_ends_red_on_an_edited_row(drop):
    """2026-10-04 (v5.2b, critic F7): the log row of a loaded version carries rows_sha256 = rows_sha256(table_key, its
    rows); the tables read back (frames_for_build, 07's path) match the log; a row edited in the table afterwards -
    same count, another value - makes the next 00b run end red, naming the version."""
    spark = nbf.FakeSpark()
    files = {"same_day_disallow": same_day_xlsx(drop / "SameDayDisallowTable.xlsx"),
             "daily_limits": daily_xlsx(drop / "HCPCSCPTProcedureswithDailyLimits.xlsx"),
             "b2_matrix": b2_xlsx(drop / "B2Matrix.xlsx")}
    nbf.run_notebook(NB00B, spark)
    log = spark.frame(config.AHCCCS_TABLES_LOG)
    assert list(log.columns) == at.LOG_COLUMNS and log["rows_sha256"].notna().all()
    for key, path in files.items():
        assert log.set_index("table_key").loc[key, "rows_sha256"] == at.rows_sha256(key, at.parse_file(path)["frame"])
    frames, _ = at.frames_for_build(spark)
    assert at.check_loaded(frames, log) == []
    # an older log (written before rows_sha256) still appends: the new column merges in, old rows read NULL
    pdf, st = spark.tables[_tbl("daily_limits")]
    pdf = pdf.copy()
    pdf.loc[pdf["code"] == "98960", "daily_max"] = 40                  # edited by hand in the catalog
    spark.tables[_tbl("daily_limits")] = (pdf, st)
    with pytest.raises(RuntimeError, match=r"daily_limits version 2026-09-14 \(HCPCSCPTProcedureswithDailyLimits.xlsx, "
                                           r"sha256 \w{12}\): \S+ holds the logged 4 row\(s\) but not the rows 00b "
                                           r"loaded"):
        nbf.run_notebook(NB00B, spark)


def test_00b_appends_rows_sha256_to_a_log_written_before_it(drop):
    """The log table of a workspace that ran 00b before v5.2b has no rows_sha256 column: the next run appends with the
    new column (kb_io merges the schema); the old rows read NULL and are checked by their count only."""
    spark = nbf.FakeSpark()
    same_day_xlsx(drop / "SameDayDisallowTable.xlsx")
    nbf.run_notebook(NB00B, spark)
    old_log = spark.frame(config.AHCCCS_TABLES_LOG).drop(columns=["rows_sha256"])
    spark.tables.pop(config.AHCCCS_TABLES_LOG)
    import kb_io
    kb_io.write_table(spark, old_log, config.AHCCCS_TABLES_LOG, mode="append",
                      schema={c: t for c, t in at.LOG_SCHEMA.items() if c != "rows_sha256"})
    daily_xlsx(drop / "HCPCSCPTProcedureswithDailyLimits.xlsx")
    nbf.run_notebook(NB00B, spark)                                       # no error: the old row is count-checked
    log = spark.frame(config.AHCCCS_TABLES_LOG)
    got = {r["table_key"]: r["rows_sha256"] for r in log.to_dict("records") if r["status"] == "loaded"}
    assert got["same_day_disallow"] is None and len(got["daily_limits"]) == 64


def test_00b_says_which_sub_folders_and_files_it_skipped(drop, capsys):
    """2026-10-04 (v5.2b, critic F17): 00b skips sub-folders whose name starts with '_' or '.' (the _versions/ archive
    among them) - it used to say nothing, so a workbook saved in '_new/' was never read and nobody knew. drop_zone_files
    reports what it skipped (skipped=list); 00b prints it."""
    spark = nbf.FakeSpark()
    same_day_xlsx(drop / "SameDayDisallowTable.xlsx")
    for sub, build in (("_old", daily_xlsx), (".hidden", b2_xlsx), (os.path.join("manual", "_drafts"), b2_xlsx)):
        os.makedirs(drop / sub)
        build(drop / sub / "t.xlsx")
    (drop / "notes.txt").write_text("x")
    (drop / "B2Matrix.xls").write_bytes(b"an old Excel file")
    (drop / "~$SameDayDisallowTable.xlsx").write_bytes(b"lock")
    skipped = []
    files = at.drop_zone_files(str(drop), skipped=skipped)
    assert [os.path.relpath(p, drop) for p in files] == ["SameDayDisallowTable.xlsx"]
    assert at.drop_zone_files(str(drop)) == files                       # the old call is unchanged
    assert [(s["path"], s["kind"]) for s in skipped] == [
        (".hidden", "folder"), ("_old", "folder"), ("B2Matrix.xls", "file"), ("notes.txt", "file"),
        ("~$SameDayDisallowTable.xlsx", "file"), ("manual/_drafts", "folder")]
    assert {s["path"]: s["why"] for s in skipped}["~$SameDayDisallowTable.xlsx"] == "an Excel lock file"
    nbf.run_notebook(NB00B, spark)
    out = capsys.readouterr().out
    for line in ("skipped folder _old/ (its name starts with '_' or '.' - nothing in it is read)",
                 "skipped folder .hidden/ (its name starts with '_' or '.' - nothing in it is read)",
                 "skipped folder manual/_drafts/", "skipped file B2Matrix.xls (not an .xlsx workbook)"):
        assert line in out, line
    nbf.run_notebook(NB00B, spark)                                      # now the archive exists: said so too
    assert "skipped folder _versions/ (the archive of loaded versions - nothing in it is read)" in capsys.readouterr().out


def test_load_files_refuses_a_second_file_for_a_loaded_or_claimed_version(drop, tmp_path):
    written = []

    def write_rows(frame, key):
        written.append((key, len(frame)))
    first = same_day_xlsx(drop / "a.xlsx")
    res = at.load_files(None, [first], str(drop), None, write_rows=write_rows, existing_hashes=lambda k: set(),
                        log=lambda *a: None)
    assert [r["status"] for r in res] == ["loaded"] and written == [("same_day_disallow", 9)]
    lg = at.log_frame(res)
    # another file, same version (re-saved: other bytes) -> rejected, never a second copy of the version
    twin = same_day_xlsx(drop / "twin.xlsx", intro=" (re-saved)")
    res = at.load_files(None, [first, twin], str(drop), lg, write_rows=write_rows, existing_hashes=lambda k: set(),
                        log=lambda *a: None)
    assert [r["status"] for r in res] == ["already_loaded", "rejected"]
    assert "already loaded from another file (a.xlsx" in res[1]["detail"] and len(written) == 1
    # two NEW files claiming one new version in the same run: both rejected (nothing can tell which is right)
    x = same_day_xlsx(drop / "x.xlsx", updated="1/1/2027")
    y = same_day_xlsx(drop / "y.xlsx", updated="1/1/2027", intro=" (another export)")
    res = at.load_files(None, [x, y], str(drop), lg, write_rows=write_rows, existing_hashes=lambda k: set(),
                        log=lambda *a: None)
    assert [r["status"] for r in res] == ["rejected", "rejected"] and "2 different files" in res[0]["detail"]
    # an earlier run appended the rows and stopped before its log row: the rows are not appended twice
    z = same_day_xlsx(drop / "z.xlsx", updated="2/1/2027")
    zsha = at.sha256_file(z)
    res = at.load_files(None, [z], str(drop), lg, write_rows=write_rows, existing_hashes=lambda k: {zsha},
                        log=lambda *a: None)
    assert res[0]["status"] == "loaded" and "not appended again" in res[0]["detail"] and len(written) == 1

    # a write failure: rejected, with the reason
    def boom(frame, key):
        raise RuntimeError("DELTA_FAILED_TO_MERGE_FIELDS")
    w = same_day_xlsx(drop / "w.xlsx", updated="3/1/2027")
    res = at.load_files(None, [w], str(drop), lg, write_rows=boom, existing_hashes=lambda k: set(), log=lambda *a: None)
    assert res[0]["status"] == "rejected" and "load failed: RuntimeError" in res[0]["detail"]


def test_load_files_an_unexpected_reader_error_is_a_rejected_row_not_a_crash(drop, monkeypatch):
    """2026-10-04 (v5.2): an error the reader did not foresee (openpyxl on an odd workbook) must still leave a log row -
    the run goes on with the other files and the notebook ends red."""
    good = same_day_xlsx(drop / "a.xlsx")
    odd = same_day_xlsx(drop / "b.xlsx", updated="1/1/2027")
    real_parse = at.parse_file

    def parse(path):
        if path.endswith("b.xlsx"):
            raise KeyError("xl/styles.xml")
        return real_parse(path)
    monkeypatch.setattr(at, "parse_file", parse)
    res = at.load_files(None, [odd, good], str(drop), None, write_rows=lambda f, k: None,
                        existing_hashes=lambda k: set(), log=lambda *a: None)
    assert [r["status"] for r in res] == ["rejected", "loaded"]
    assert res[0]["detail"].startswith("KeyError") and res[0]["file_sha256"] == at.sha256_file(odd)


def test_download_never_overwrites(drop, monkeypatch):
    import acquire_ncci

    class R:
        def __init__(self, data):
            self.content, self.status_code = data, 200
    data = open(same_day_xlsx(drop.parent / "src.xlsx"), "rb").read()
    monkeypatch.setattr(acquire_ncci, "_get", lambda session, url, **k: R(data))
    url = config.AHCCCS_TABLES["same_day_disallow"]["url"]
    got = at.download(url, str(drop), session=object())
    assert got["status"] == "downloaded" and got["path"] == str(drop / "SameDayDisallowTable.xlsx")
    assert at.download(url, str(drop), session=object())["status"] == "already_in_drop_zone"
    data2 = open(same_day_xlsx(drop.parent / "src2.xlsx", updated="1/1/2027"), "rb").read()
    monkeypatch.setattr(acquire_ncci, "_get", lambda session, url, **k: R(data2))
    got2 = at.download(url, str(drop), session=object())
    assert got2["path"] != got["path"] and os.path.exists(got["path"]) and os.path.basename(got2["path"]).startswith(
        "SameDayDisallowTable_")
    monkeypatch.setattr(acquire_ncci, "_get", lambda session, url, **k: R(b"<html>WAF</html>"))
    with pytest.raises(ValueError, match="did not return an .xlsx"):
        at.download(url, str(drop), session=object())


def test_00b_notebook_keeps_the_databricks_format():
    src = open(os.path.join(PKG, "notebooks", NB00B)).read()
    compile(src, NB00B, "exec")
    assert src.startswith("# Databricks notebook source\n# MAGIC %md") and "\n# COMMAND ----------\n" in src
    assert "PKB_PACKAGE_DIR" in src and "DOWNLOAD   = False" in src
    assert "    importlib.reload(m)" in src                          # the offline harness switches reloads off
