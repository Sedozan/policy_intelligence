"""
tests/test_sql_oracle_tables.py - independent reference check of the AHCCCS rule-table queries (QUERY_SEMANTICS.md
version 2.6, §2b: Same Day Disallow, daily limits, B2 matrix), the three table batch statements and every table rule's
own SQL.

The ORACLE was written from docs/QUERY_SEMANTICS.md (§1, §2 "Code pair" / "Units per day" incl. the `scope` /
"Provider type allowed", §2b, §3) ONLY. The §2b RULES - and the frames §2b refuses - are derived here, from the table
frames this file generates (refusals, derive_rules). The §1 / §2 / §3 pieces are reused from tests/test_sql_oracle.py
(snapshot, oracle_pair, oracle_units_per_day, oracle_provider_type_allowed, severity incl. the v2.6 daily-cap labels,
evidence, the claims generator's hard cases incl. billing provider ids, and the Spark harness). Used as BLACK BOXES
only, never read: ahcccs_tables.rules_from_frames (+ normalise_frame on the pre-normalised rounds, the frames_for_build
path), validate_gate.gate, rule_normalize.normalize_rules, detector_gen.build_detectors / ahcccs_edit_tables /
TABLE_BATCH_SQL / create_snapshot. The SQL is run UNCHANGED on Spark 4 (ANSI on, local[2]).

Version 2.6 (2026-10-05, the spec after the independent critic of v5.2): A* scope = config.AHCCCS_SAME_PROVIDER_SCOPE and
the daily scope = config.AHCCCS_DAILY_LIMIT_SCOPE (default member_servicing_billing_day: the same servicing AND billing
provider id); both_ways pairs and their finding text; anesthesia codes (config.AHCCCS_DAILY_RECORD_ONLY_CODES) and
all-nines maxima (config.AHCCCS_DAILY_PLACEHOLDER_MAX) build no daily rule; B2 role = config.AHCCCS_B2_PROVIDER_ROLE
(default billing_or_rendering: a group's line judged on its rendering type); indicators and Frequency Cds trimmed and
upper-cased; §3's daily-cap labels (verify_pa > verify_span > verify_modifier); the frame-level refusals (a row without
its code, the same cell or daily code twice in one version, a blank / non-positive maximum, an indicator other than D /
A / A*, two files for one version) - the v2.5 gaps G1 / G3 / G7 are refused now.
N4 (2026-10-05, §3 as amended after the critic's re-check): the daily-cap labels verify_span / verify_modifier read the
group's PAYABLE lines only (a cancelled line and its reversal still count in the sum, never in the label) - the shared
§3 oracle (test_sql_oracle A27) and its claims generator (sc_daily_cancelled_long_line: a cancelled LONG line with
listed modifiers + its exact reversal + other payable lines over the cap) carry it; FIX_* members M14-M18 pin it by
hand. G9 is stated now (§6: a column added to a loaded table is ignored) and asserted.

One round = random table frames (1-3 versions per table, version dates around the claims' dates, messy code /
indicator / Frequency Cd / provider-type spellings, D / A* / A / diagonal / both-ways cells, every Limit / Frequency
combination, anesthesia codes and 9 / 99 / 999 / 9999 / 999999 maxima, B2 rows for H0xxx / H2xxx and other codes, rare
blank / NONE / odd provider types) + random claims full of the §1 hard cases built on the table codes (billing provider
ids equal / other / padded / missing, group billing types '1' / ' 01 ' / '01.0', daily-cap modifiers; some table codes
never billed: scoped out). Then, exactly (dollars to the cent):
  0. the snapshot, row by row (sanity - test_sql_oracle checks it in depth);
  1. RULES: rules_from_frames(frames, claims scope) -> gate -> normalise (table rules on their own, as notebook 07) vs
     the oracle's §2b derivation: the multiset of rules (kind, codes, scope / both_ways / threshold / provider list +
     role, window), which are leads, predicate details (indicator '0', note 2, no age), every table rule batched, built /
     lead counts per kind and version (report counts: informational, R-T15);
  2. the three BATCH statements (edit tables written as notebook 07 writes them) with build_id=None, and again with a
     decoy build in the same tables and build_id='BX' (must give the same rows), vs the oracle: the findings multiset
     and every column (severity, basis, pa_present, observed / allowed / excess, evidence, Column One, paid_amt,
     paid_at_risk, pair_scope, both-ways text, servicing / billing provider, group text, member, date);
  3. every compiled table rule's OWN SQL (build_detectors(batch_tables=False)) vs the oracle, per rule - SQL rules are
     matched to oracle rules semantically (kind + codes + scope / threshold / list + window), never by rule_id;
  4. each batch statement vs the union of the per-rule SQL of its rules, value for value (§2b: a column one of them does
     not output reads as NULL).
Plus refusal cases (pure Python + black box): every frame §2b refuses raises ValueError, and the controls do not.

Run:       cd pie_mvp && python -m pytest -q tests/test_sql_oracle_tables.py      (~4.5 min on 2 CPUs; v2.6 + N4,
           2026-10-05: 20 rounds, 16,660 claim rows, 754 rules (50 both-ways pairs, 25 leads), 729 per-rule queries +
           120 batch statements, 2,532 findings (1,105 Same Day, 288 daily - 91 labelled otherwise than the pre-N4
           counted-row reading would -, 1,139 B2), all equal; 23 refusal cases x 2 paths, all as the spec says)
           3x: PIE_TBL_ORACLE_ROUNDS=24 PIE_TBL_ORACLE_VARIANT_REPEATS=3 python -m pytest -q tests/test_sql_oracle_tables.py
           (~11.5 min; v2.6 + N4: 60 rounds, 50,777 claim rows, 2,412 rules (186 both-ways), 2,334 per-rule queries +
           359 batch statements, 8,015 findings (3,823 Same Day, 828 daily - 256 labelled otherwise than the pre-N4
           reading -, 3,364 B2), all equal)
Scale:     PIE_TBL_ORACLE_ROUNDS (default 8) seeded rounds x PIE_TBL_ORACLE_SETS (default 4) claim sets per round,
           plus PIE_TBL_ORACLE_VARIANT_REPEATS (default 1) rounds per variant (VARIANTS: the three A* scopes, the three
           daily scopes, B2 role billing, wider / no record-only patterns, other group types, two other B2 compile
           patterns, no claims scope, a combined pre-normalised round). Odd rounds pass the frames through
           ahcccs_tables.normalise_frame first (the production path, frames_for_build), even rounds give
           rules_from_frames the raw messy frames.
Optional:  PIE_TBL_ORACLE_REPORT=<file.json> writes counts, the hard-case coverage, the readings, the refusal results and
           every mismatch; PIE_TBL_ORACLE_TMP=<dir> is where the throw-away Spark warehouse goes (default: system temp).
Without pyspark only the pure-Python oracle self-checks and the refusal cases run.

ORACLE_READINGS lists every point where §2b is silent or loose and which reading the oracle takes: R-T* chosen BEFORE
the comparison they govern was run (R-T17..R-T21 for v2.6); S-T* adopted after the SQL showed a different but
defensible reading (reported as SPEC AMBIGUITY) - S-T1 is spec text since v2.6. SPEC_GAPS_OBSERVED records what
production does on inputs the generator avoids on purpose, probed through the black boxes.
"""
from __future__ import annotations

import contextlib
import datetime as dt
import hashlib
import io
import json
import os
import random
import re
import shutil
import sys
import tempfile
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
for _p in (PKG, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import config  # noqa: E402
import detector_gen as dg  # noqa: E402
import test_sql_oracle as O  # noqa: E402   (§1 / §2 / §3 oracle, claims generator, Spark harness)

D = dt.date
DAY = dt.timedelta(days=1)

# ===================================================================================== readings
ORACLE_READINGS = {
    "R-T1": "Versions: per table, the distinct version_date values (ISO text, date part) d1 < ... < dn; version di judges "
            "dates of service di .. d(i+1)-1 day (both included), dn open (end_date NULL); the rule carries them as "
            "effective_date / end_date (ISO). A table's windows never depend on another table's versions; two "
            "consecutive calendar dates make a ONE-DAY window (generated on purpose).",
    "R-T2": "Codes in the frames are cleaned (surrounding whitespace trimmed, upper-cased) BEFORE every test: the diagonal "
            "R = C (' H2014' x 'h2014' is the diagonal), the claims scope, the B2 pattern, the record-only pattern, the "
            "grouping of a version's B2 rows per code, the duplicate checks, and in the rule's predicate.",
    "R-T3": "Claims scope = the set the caller passes (here, as notebook 07 with PAID_FILTER = '': the distinct "
            "UPPER(TRIM(code)) of every claim row with a code); a rule is built only when all its CLEANED codes are in "
            "it (pair: both). scope None = no scoping (variant 'claims_scope_none'; the spec does not name None).",
    "R-T4": "(v2.6) Same Day: one rule per (version, cell) with indicator D or A* (trimmed + upper-cased - STATED v2.6: "
            "' d ', 'a*' count) and R != C: code_pair_prohibited, code_a = C (column), code_b = R (row), "
            "modifier_indicator '0', scope member_day (D) / config.AHCCCS_SAME_PROVIDER_SCOPE (A*; read when "
            "rules_from_frames is called), exception = note 2 verbatim, no age, not discretionary. A / diagonal: no rule.",
    "R-T5": "Same Day severity: verify_pa when a PA number is on the finding (row-code) line OR ANY of its evidence "
            "(column-code) lines ('either line', existing oracle A5); otherwise verify_exception; basis hard_denial; "
            "pa_present 0 / 1 (PA evaluated).",
    "R-T6": "(v2.6) Daily limits: per (version, row), after R-T19: NO rule when Limit 1 or Limit 2 has Frequency Cd 'D' "
            "(trimmed + upper-cased - STATED v2.6), Frequency Value 1 and a limit value present and != N (STATED v2.6: 'a "
            "Limit with no value states nothing'); otherwise max_units_per_day(code K, threshold N, scope = "
            "config.AHCCCS_DAILY_LIMIT_SCOPE read when rules_from_frames is called). A D/1 limit equal to N, a D limit "
            "with value != 1 and Cd W / M / Y / L never block the rule nor change the threshold.",
    "R-T7": "(v2.6) Daily findings: §2 Units per day with the rule's scope (test_sql_oracle A26: member_day / "
            "member_provider_day / member_servicing_billing_day - a row missing the scope's id(s) not counted; "
            "servicing_provider / billing_provider = the group's, NULL where the scope has none) and §3's daily-cap "
            "labels (A27: verify_pa > verify_span > verify_modifier > units_over_limit; no exception) - (N4, "
            "2026-10-05) span and modifier read the group's PAYABLE lines only: a cancelled line, any reversal row and "
            "a paid line with units <= 0 count in the sum / evidence / dollars, never in those two labels.",
    "R-T8": "B2: per (version, cleaned code K) with re.fullmatch(config.AHCCCS_B2_COMPILE_CODES, K) (S-T1, STATED v2.6): "
            "provider_type_allowed, code K, provider_types = the set of the cleaned types of EVERY row of K in that "
            "version, role = config.AHCCCS_B2_PROVIDER_ROLE (R-T10). A row whose type is missing after the §1 clean-up "
            "(None, '', spaces, NONE / NAN / NULL, a float NaN) or is not 1-4 letters and digits after it ('8.5', 'C-2', "
            "'ABCDE') makes the rule a LEAD (§2 v2.3): built, not compiled, no edit row, no findings - never a narrower "
            "list. Codes not matching: recorded, no rule (a blank type there changes nothing).",
    "R-T9": "B2 provider types are cleaned exactly like the §1 column (test_sql_oracle.clean_entry on str(value)): 2 -> "
            "02, 8.0 -> 08, ' 02' -> 02, '2.0' -> 02, 'b6' -> B6, 77.0 -> 77.",
    "R-T10": "(v2.6) B2 findings: §2 provider_type_allowed with role config.AHCCCS_B2_PROVIDER_ROLE (default "
             "billing_or_rendering: test_sql_oracle A28 - a line billed under a type of config.GROUP_BILLING_PROVIDER_"
             "TYPES (cleaned like the column) is judged on its servicing type; a missing billing type is never a "
             "finding) and its group finding text (A29); verify_pa when the line has a PA, else "
             "provider_type_not_allowed; no exception.",
    "R-T11": "Statements: a batch statement's findings = the union of the oracle findings of the COMPILED rules of its "
             "kind; every table rule that compiles is expected to be batched (§2b gives table rules no age condition).",
    "R-T12": "A cell / row identical in two versions gives two rules with adjacent windows (§2b: 'every rule derived "
             "from version di carries that window'); the oracle never merges them.",
    "R-T13": "(v2.6) Pair finding text: a both_ways rule's text is exactly '{code_b} billed with {code_a} (pair "
             "disallowed both ways: AHCCCS would deny one of the two lines)' (coordinator's output contract); any other "
             "pair finding's text must not carry the both-ways clause (its exact wording is not stated: compared batch "
             "vs per-rule only). Pair observed / allowed / excess units: batch vs per-rule only.",
    "R-T14": "pa_present for a daily group looks at every COUNTED row of the group (paid != 0, inside the window, with the "
             "ids its scope needs) - reversal rows included (existing oracle A5).",
    "R-T15": "Counts: built = rules rules_from_frames returns (leads included); scoped_out = would-be rules (after the "
             "diagonal / A / record-only / placeholder / two-daily-limits / pattern tests) whose codes are not all in "
             "scope; excluded = diagonal cells, A cells, record-only rows, placeholder maxima, two-daily-limits rows, "
             "non-compiled B2 codes, counted whatever the scope (a row matching several counts once, in that order). The "
             "report's own counters are compared as information only (their counting convention is not query semantics).",
    "R-T16": "(v2.6) 'Same provider': member_provider_day = the cleaned servicing provider id (trimmed, case kept: 'p1' != "
             "'P1'); member_servicing_billing_day = the cleaned servicing AND billing provider ids (' B1 ' = 'B1', 'b1' "
             "!= 'B1'); a missing id never matches (test_sql_oracle A25).",
    "S-T1": "STATED v2.6 (§2b 'K matching ... as a WHOLE (Python re.fullmatch on the cleaned code)'); was a SPEC "
            "AMBIGUITY found by this oracle in v2.5 (R-T8 had chosen re.search before the first run). The variant "
            "'b2_pattern_unanchored_probe' keeps codes on which search / match / fullmatch differ.",
    # chosen for v2.6 (2026-10-05) BEFORE running
    "R-T17": "(v2.6) both_ways: a rule from cell (R, C) of version v carries both_ways = True exactly when (C, R) is also "
             "D or A* in the SAME version (R != C, after clean-up); a mirror cell A, absent, or in another version -> "
             "no both_ways (absent or False). Both rules of a both-ways pair flag their own lines independently.",
    "R-T18": "(v2.6) Refused, never guessed (frame level): rules_from_frames raises ValueError (or normalise_frame does, "
             "on the pre-normalised path) for: a row with a blank code after clean-up (Same Day row or column code, daily "
             "code, B2 code); the same cleaned (R, C) twice in one version (whatever the indicators); the same cleaned "
             "daily code twice in one version (whatever the maxima); a blank or non-positive maximum; an indicator other "
             "than D / A / A* after clean-up (blank included); two file_sha256 for one version. A B2 code on several rows "
             "of one version, the same cell in two versions and a both-ways pair are NOT refused. A refusal in any table "
             "stops the whole call. The random rounds never contain a refusal (tested by REFUSAL_CASES).",
    "R-T19": "(v2.6) No daily rule (recorded) when the cleaned code fully matches config.AHCCCS_DAILY_RECORD_ONLY_CODES "
             "(default anesthesia 00100-01999) or N's decimal text (an integer, no padding) fully matches "
             "config.AHCCCS_DAILY_PLACEHOLDER_MAX (default 999, 9999, ... - 9 and 99 are real maxima); whatever the "
             "limits, the scope or the claims.",
    "R-T20": "(v2.6) The daily-limits row's Frequency Value is compared as a whole number (1 / '1' / 1.0 are 1).",
    "R-T21": "(v2.6) Both scope settings are read when rules_from_frames is called and carried by the rule; the oracle "
             "reads config at the same moment (variants patch config before the round).",
}

# What production does where §2b is silent, or was in an earlier version - probed through the black boxes.
SPEC_GAPS_OBSERVED = {
    "G1": "v2.5: one version marking the same cleaned cell twice with DIFFERENT indicators built both rules (two "
          "findings of one line). RESOLVED 2026-10-04 (lead): normalise_frame refuses the same cell twice in one "
          "version (spec 'Refused, never guessed'); v2.6 re-checked here: REFUSAL_CASES (raw frames and the "
          "normalise_frame path) - see the report's 'refusals'.",
    "G2": "v2.5: the same cleaned cell twice with the SAME indicator gave two identical rules that normalize_rules "
          "collapsed. v2.6: refused like G1 (REFUSAL_CASES).",
    "G3": "v2.5: one code twice in one daily-limits version with different maxima built two rules (two findings of one "
          "group). RESOLVED 2026-10-04: refused (one daily-limits row per code per version) - REFUSAL_CASES.",
    "G4": "A limit with Frequency Cd D and Value 1 but a BLANK limit value: no 'two daily limits' (the rule is built "
          "with N). STATED v2.6 ('a Limit with no value states nothing'); REFUSAL_CASES control.",
    "G5": "A blank or non-positive 'Procedure Maximum Occurrence': ValueError (the whole build stops). STATED v2.6 "
          "(refused); REFUSAL_CASES.",
    "G6": "v2.5: Frequency Cd trimmed but NOT upper-cased ('d' was not D). RESOLVED 2026-10-04 and STATED v2.6 "
          "('indicators and Frequency Cds are trimmed and upper-cased'); the generator writes 'd', ' D ', 'w' ...",
    "G7": "v2.5: a blank Same Day row code became the literal code 'NONE' in a lead rule; a blank B2 code row was dropped. "
          "RESOLVED 2026-10-04: a row without its code(s) is refused in every table - REFUSAL_CASES.",
    "G8": "Indicators ' d ' / 'a*' are D / A* (STATED v2.6); 'X' and a blank indicator are refused; a version held by two "
          "file_sha256 is refused; '2025-1-1' is not an ISO date -> ValueError.",
    "SCHEMA-1": "v2.5: the per-rule SQL of a member_day daily rule outputs no servicing_provider column, the batch "
                "outputs it NULL. STATED v2.6 (§2b 'a column one of them does not output reads as NULL'): step 4 "
                "compares values over the union of columns; the same holds for billing_provider (output contract). The "
                "column-set differences seen are listed in the report ('schema_notes'), not failures.",
    "G9": "Frame-level 'content to the right of a table's last known column' (v2.6): §2b refuses it at load (00b). "
          "Reported 2026-10-05 as a SPEC GAP (a frame with an extra column holding content was accepted by "
          "rules_from_frames and normalise_frame, the column ignored; the spec did not say what 07 does). STATED since "
          "(§6 v2.6: 'A column added by hand to a loaded table in the catalog is ignored (00b refuses one in a file; "
          "07's load check compares the rows of the known columns)'): asserted by test_extra_frame_column_is_ignored "
          "(the rules built equal the oracle's from the known columns, content or not, raw and normalised paths).",
}

# ===================================================================================== the §2b ORACLE (rules)
NOTE2 = "Exceptions to limitations on service frequency or duration may be approved based on medical necessity."
BOTH_WAYS_CLAUSE = " (pair disallowed both ways: AHCCCS would deny one of the two lines)"
TABLE_KEYS = ("same_day_disallow", "daily_limits", "b2_matrix")
KIND_OF_TABLE = {"same_day_disallow": "pair", "daily_limits": "daily", "b2_matrix": "b2"}
KIND_OF_TYPE = {"code_pair_prohibited": "pair", "max_units_per_day": "daily", "provider_type_allowed": "b2"}
MSB = "member_servicing_billing_day"
DA = ("D", "A*")
TCOVER = Counter()          # table hard cases seen (frames, rules, findings) - reported
STATS = Counter()
MISMATCHES: list = []
ROUND_LOG: list = []
REFUSAL_LOG: list = []
PROBES: dict = {}


def clean_code(v):
    """R-T2: trimmed (whitespace) and upper-cased; blank -> None."""
    if v is None or (isinstance(v, float) and v != v):
        return None
    s = str(v).strip().upper()
    return s or None


clean_flag = clean_code            # (v2.6) indicators and Frequency Cds: trimmed and upper-cased, blank -> None


def vdate(v) -> dt.date:
    return D.fromisoformat(str(v).strip()[:10])


def version_windows_oracle(values) -> dict:
    """R-T1: {version date: (effective ISO, end ISO or None)}."""
    ds = sorted({vdate(v) for v in values if v is not None})
    out = {}
    for i, d in enumerate(ds):
        end = ds[i + 1] - DAY if i + 1 < len(ds) else None
        out[d] = (d.isoformat(), None if end is None else end.isoformat())
    return out


def _int(v):
    if v is None or (isinstance(v, float) and v != v):
        return None
    if isinstance(v, str):
        v = v.strip()
        return int(Decimal(v)) if v else None
    return int(v)


def two_daily_limits_of(row: dict, n) -> list:
    """R-T6: the row's limits with Frequency Cd D (cleaned), Frequency Value 1 and a limit value != N."""
    out = []
    for i in (1, 2):
        lim, val, cd = _int(row[f"limit{i}"]), _int(row[f"freq{i}_value"]), clean_flag(row[f"freq{i}_cd"])
        if cd == "D" and val == 1 and lim is not None and lim != n:
            out.append((i, lim))
    return out


def recorded_limits_of(row: dict) -> list:
    """The row's limits that are recorded, never compiled (Cd W / M / Y / L, or D with a value other than 1)."""
    out = []
    for i in (1, 2):
        val, cd = _int(row[f"freq{i}_value"]), clean_flag(row[f"freq{i}_cd"])
        if cd in ("W", "M", "Y", "L") or (cd == "D" and val is not None and val != 1):
            out.append((i, cd, val))
    return out


def entry_key(e):
    return (e is not None, e or "")


def _iso(v):
    if v is None or (isinstance(v, float) and v != v):
        return None
    return str(v)[:10]


def rule_sig(rule: dict) -> tuple:
    """The semantic identity of a table rule (both sides): kind, codes, scope + both_ways / threshold + scope / cleaned
    provider list + role, window. Never the rule_id."""
    p = rule["predicate"]
    t = p.get("type")
    eff, end = _iso(rule.get("effective_date")), _iso(rule.get("end_date"))
    if t == "code_pair_prohibited":
        return ("pair", O.norm_code(p["code_a"]), O.norm_code(p["code_b"]), p.get("scope"), bool(p.get("both_ways")),
                eff, end)
    if t == "max_units_per_day":
        return ("daily", tuple(sorted(O.rule_codes(p))), int(p["threshold"]), p.get("scope"), eff, end)
    if t == "provider_type_allowed":
        types = tuple(sorted({O.clean_entry(v) for v in (p.get("provider_types") or [])}, key=entry_key))
        return ("b2", tuple(sorted(O.rule_codes(p))), types, O.pta_role(p), eff, end)
    return ("other", t, json.dumps(p, sort_keys=True, default=str), eff, end)


def sig_str(s) -> str:
    return "|".join("-" if x is None else ("/".join("<blank>" if y is None else str(y) for y in x)
                                          if isinstance(x, tuple) else str(x)) for x in s)


def _xrule(kind, version, window, pred, src, lead=False):
    r = {"rule_id": "", "origin": "ahcccs_table", "machine_checkable": True, "effective_date": window[0],
         "end_date": window[1], "predicate": pred, "kind": kind, "version": version.isoformat(), "lead": lead,
         "src": src}
    r["sig"] = rule_sig(r)
    r["rule_id"] = "X:" + sig_str(r["sig"])
    return r


def table_config() -> dict:
    """R-T21: the §2b settings, read now (as rules_from_frames reads them when it is called)."""
    return {"same_provider_scope": config.AHCCCS_SAME_PROVIDER_SCOPE, "daily_scope": config.AHCCCS_DAILY_LIMIT_SCOPE,
            "b2_pattern": config.AHCCCS_B2_COMPILE_CODES, "b2_role": config.AHCCCS_B2_PROVIDER_ROLE,
            "record_only": config.AHCCCS_DAILY_RECORD_ONLY_CODES, "placeholder": config.AHCCCS_DAILY_PLACEHOLDER_MAX}


def refusals(frames: dict) -> list:
    """R-T18 (§2b 'Refused, never guessed', frame level): every reason these frames must be refused (empty = accepted)."""
    out = []
    for key in TABLE_KEYS:
        df = frames.get(key)
        if df is None or not len(df):
            continue
        recs = df.to_dict("records")
        shas = defaultdict(set)
        for r in recs:
            shas[vdate(r["version_date"])].add(r["file_sha256"])
        out += [(key, "two files for one version", v.isoformat()) for v, s in shas.items() if len(s) > 1]
        seen = Counter()
        if key == "same_day_disallow":
            for r in recs:
                R, C = clean_code(r["row_code"]), clean_code(r["col_code"])
                if R is None or C is None:
                    out.append((key, "a row without its code(s)", r.get("cell")))
                    continue
                if clean_flag(r["indicator"]) not in ("D", "A", "A*"):
                    out.append((key, "an indicator other than D / A / A*", r["indicator"]))
                seen[(vdate(r["version_date"]), R, C)] += 1
            out += [(key, "the same cell twice in one version", k) for k, n in seen.items() if n > 1]
        elif key == "daily_limits":
            for r in recs:
                K = clean_code(r["code"])
                if K is None:
                    out.append((key, "a row without its code", r.get("source_row")))
                    continue
                n = _int(r["daily_max"])
                if n is None or n <= 0:
                    out.append((key, "a blank or non-positive maximum", (K, r["daily_max"])))
                seen[(vdate(r["version_date"]), K)] += 1
            out += [(key, "the same daily-limits code twice in one version", k) for k, n in seen.items() if n > 1]
        else:
            out += [(key, "a row without its code", r.get("source_row")) for r in recs if clean_code(r["code"]) is None]
    return out


def derive_rules(frames: dict, scope, cfg: dict | None = None) -> dict:
    """§2b, from the frames: {'built': [...], 'scoped_out': [...], 'excluded': Counter, 'excluded_detail': {...},
    'windows': {table: {...}}, 'recorded': Counter, 'refused': [...]}. Each rule is a dict the §2 oracle functions take,
    plus kind, version, lead, sig, src (the frame rows it comes from). Refused frames build nothing (R-T18)."""
    cfg = cfg or table_config()
    res = {"built": [], "scoped_out": [], "excluded": Counter(), "excluded_detail": defaultdict(list),
           "windows": {}, "recorded": Counter(), "refused": refusals(frames)}
    if res["refused"]:
        return res

    def place(r, codes):
        ok = scope is None or set(codes) <= scope
        (res["built"] if ok else res["scoped_out"]).append(r)

    sd = frames.get("same_day_disallow")
    if sd is not None and len(sd):
        win = version_windows_oracle(sd["version_date"])
        res["windows"]["same_day_disallow"] = win
        recs = sd.to_dict("records")
        marks = defaultdict(dict)                      # version -> {(R, C): cleaned indicator}
        for row in recs:
            marks[vdate(row["version_date"])][(clean_code(row["row_code"]), clean_code(row["col_code"]))] = \
                clean_flag(row["indicator"])
        for row in recs:
            v = vdate(row["version_date"])
            R, C, ind = clean_code(row["row_code"]), clean_code(row["col_code"]), clean_flag(row["indicator"])
            if R == C:
                res["excluded"]["pair:diagonal"] += 1
                res["excluded_detail"]["pair:diagonal"].append((v.isoformat(), R, C, ind))
                continue
            if ind == "A":
                res["excluded"]["pair:A"] += 1
                res["excluded_detail"]["pair:A"].append((v.isoformat(), R, C))
                continue
            pred = {"type": "code_pair_prohibited", "code_a": C, "code_b": R, "modifier_indicator": "0",
                    "scope": "member_day" if ind == "D" else cfg["same_provider_scope"], "exception": NOTE2}
            if marks[v].get((C, R)) in DA:                                       # R-T17
                pred["both_ways"] = True
            place(_xrule("pair", v, win[v], pred, [dict(row)]), (R, C))
    dl = frames.get("daily_limits")
    if dl is not None and len(dl):
        win = version_windows_oracle(dl["version_date"])
        res["windows"]["daily_limits"] = win
        for row in dl.to_dict("records"):
            v = vdate(row["version_date"])
            K, N = clean_code(row["code"]), _int(row["daily_max"])
            if recorded_limits_of(row):
                res["recorded"]["daily:rows_with_a_recorded_period_limit"] += 1
            if re.fullmatch(cfg["record_only"], K):                             # R-T19
                res["excluded"]["daily:record_only_code"] += 1
                res["excluded_detail"]["daily:record_only_code"].append((v.isoformat(), K, N))
                continue
            if re.fullmatch(cfg["placeholder"], str(N)):
                res["excluded"]["daily:placeholder_maximum"] += 1
                res["excluded_detail"]["daily:placeholder_maximum"].append((v.isoformat(), K, N))
                continue
            two = two_daily_limits_of(row, N)
            if two:
                res["excluded"]["daily:two_daily_limits"] += 1
                res["excluded_detail"]["daily:two_daily_limits"].append((v.isoformat(), K, N, two))
                continue
            pred = {"type": "max_units_per_day", "code": K, "threshold": N, "scope": cfg["daily_scope"]}
            place(_xrule("daily", v, win[v], pred, [dict(row)]), (K,))
    b2 = frames.get("b2_matrix")
    if b2 is not None and len(b2):
        win = version_windows_oracle(b2["version_date"])
        res["windows"]["b2_matrix"] = win
        groups = defaultdict(list)
        for row in b2.to_dict("records"):
            groups[(vdate(row["version_date"]), clean_code(row["code"]))].append(row)
        for (v, K), rows in sorted(groups.items()):
            if not re.fullmatch(cfg["b2_pattern"], K):                          # S-T1 (stated v2.6)
                res["excluded"]["b2:code_not_compiled"] += 1
                res["excluded_detail"]["b2:code_not_compiled"].append((v.isoformat(), K))
                continue
            raw = [r["provider_type"] for r in rows]
            entries = sorted({O.clean_entry(t) for t in raw}, key=entry_key)
            lead = bool(O.bad_entries({"provider_types": raw}))
            pred = {"type": "provider_type_allowed", "code": K, "provider_types": entries,
                    "provider_role": cfg["b2_role"]}
            place(_xrule("b2", v, win[v], pred, [dict(r) for r in rows], lead=lead), (K,))
    return res


# ===================================================================================== the §2 / §3 ORACLE (findings)
def expected_findings(x: dict, by_code: dict) -> list:
    """The oracle findings of one derived rule (§2 + §3 via test_sql_oracle), on the snapshot rows of its codes."""
    p = x["predicate"]
    if x["kind"] == "pair":
        snap = by_code.get(p["code_a"], []) + (by_code.get(p["code_b"], []) if p["code_b"] != p["code_a"] else [])
        return O.oracle_pair(x, snap)
    if x["kind"] == "daily":
        return O.oracle_units_per_day(x, by_code.get(p["code"], []))       # scope, labels, ids: test_sql_oracle A26/A27
    return O.oracle_provider_type_allowed(x, by_code.get(p["code"], []))


def pair_text_form(text, code_a, code_b) -> str:
    """R-T13: 'both_ways_text' for the exact both-ways text, 'plain' for a text without the both-ways clause."""
    if text == f"{code_b} billed with {code_a}{BOTH_WAYS_CLAUSE}":
        return "both_ways_text"
    if text and "both ways" in text:
        return "MALFORMED_both_ways_text:" + text
    return "plain"


FIELDS = {
    "pair": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk", "evidence", "col1",
             "servicing_provider", "form_typ", "pair_scope", "text_form"),
    "daily": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk", "observed_units",
              "allowed_units", "excess_units", "evidence", "servicing_provider", "billing_provider"),
    "b2": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk", "observed_units",
           "allowed_units", "excess_units", "servicing_provider", "form_typ", "has_evidence", "finding_form"),
}


def exp_record(x: dict, f: dict):
    kind, sig = x["kind"], x["sig"]
    v = {"finding_severity": f["finding_severity"], "finding_basis": f["finding_basis"],
         "pa_present": f["pa_present"], "paid_amt": O._q2(f["paid_amt"]), "paid_at_risk": O._q2(f["paid_at_risk"])}
    if kind == "pair":
        key = (sig,) + tuple(f["key"])                                     # claim, line, member, dos
        v.update(evidence=tuple(O.ev_str(e) for e in f["evidence"]), col1=f["col1"],
                 servicing_provider=f["servicing_provider"], form_typ=f["form_typ"], pair_scope=f["pair_scope"],
                 text_form="both_ways_text" if x["predicate"].get("both_ways") else "plain")
    elif kind == "daily":
        m, sp, bp, d = f["key"]                                            # test_sql_oracle: (member, sprov, bprov, dos)
        key = (sig, m, sp, bp, d)
        v.update(observed_units=O._num(f["observed_units"]), allowed_units=O._num(f["allowed_units"]),
                 excess_units=O._num(f["excess_units"]), evidence=tuple(O.ev_str(e) for e in f["evidence"]),
                 servicing_provider=f["servicing_provider"], billing_provider=f["billing_provider"])
    else:
        key = (sig,) + tuple(f["key"])
        v.update(observed_units=O._num(f["observed_units"]), allowed_units=O._num(f["allowed_units"]),
                 excess_units=O._num(f["excess_units"]), servicing_provider=f["servicing_provider"],
                 form_typ=f["form_typ"], has_evidence=False, finding_form=f["finding_form"])
    return key, v


def sql_record(kind: str, sig: tuple, row: dict):
    v = {"finding_severity": row.get("finding_severity"), "finding_basis": row.get("finding_basis"),
         "pa_present": None if row.get("pa_present") is None else bool(row["pa_present"]),
         "paid_amt": O._q2(row.get("paid_amt")), "paid_at_risk": O._q2(row.get("paid_at_risk"))}
    ev = O.parse_evidence(row.get("evidence_lines"))
    if kind == "pair":
        key = (sig, row["claim_id"], row["line_no"], row["member_id"], row["dos"])
        v.update(evidence=ev, col1=(row.get("col1_claim_id"), row.get("col1_line_no")),
                 servicing_provider=row.get("servicing_provider"), form_typ=row.get("form_typ"),
                 pair_scope=row.get("pair_scope"), text_form=pair_text_form(row.get("finding"), sig[1], sig[2]))
    elif kind == "daily":
        sc = sig[3]
        key = (sig, row["member_id"], row.get("servicing_provider") if sc != "member_day" else None,
               row.get("billing_provider") if sc == MSB else None, row["dos"])
        v.update(observed_units=O._num(row.get("observed_units")), allowed_units=O._num(row.get("allowed_units")),
                 excess_units=O._num(row.get("excess_units")), evidence=ev,
                 servicing_provider=row.get("servicing_provider"), billing_provider=row.get("billing_provider"))
    else:
        key = (sig, row["claim_id"], row["line_no"], row["member_id"], row["dos"])
        v.update(observed_units=O._num(row.get("observed_units")), allowed_units=O._num(row.get("allowed_units")),
                 excess_units=O._num(row.get("excess_units")), servicing_provider=row.get("servicing_provider"),
                 form_typ=row.get("form_typ"), has_evidence=bool(ev),
                 finding_form=O.finding_form(row.get("finding"), list(sig[1])))
    return key, v


def compare_findings(where: str, kind: str, exp_pairs, got_rows, sig_of_row) -> list:
    """Multiset of findings keyed by (rule sig, natural key), then field by field."""
    fields = FIELDS[kind]
    exp, got = defaultdict(list), defaultdict(list)
    for x, f in exp_pairs:
        k, v = exp_record(x, f)
        exp[k].append(v)
    out = []
    for row in got_rows:
        sig = sig_of_row(row)
        if sig is None:
            out.append({"phase": where, "type": "unknown_rule_id", "kind": kind, "key": row.get("rule_id"),
                        "sql": {k: row.get(k) for k in ("claim_id", "line_no", "member_id", "dos")}})
            continue
        k, v = sql_record(kind, sig, row)
        got[k].append(v)
    for k in sorted(set(exp) | set(got), key=repr):
        e, g = exp.get(k, []), got.get(k, [])
        if len(e) != len(g):
            out.append({"phase": where, "type": "count", "kind": kind, "key": k, "oracle": len(e), "sql": len(g),
                        "oracle_rows": e, "sql_rows": g})
            continue
        es = sorted(([x.get(f) for f in fields] for x in e), key=repr)
        gs = sorted(([x.get(f) for f in fields] for x in g), key=repr)
        for ev_, gv in zip(es, gs):
            for f, a, b in zip(fields, ev_, gv):
                if a != b:
                    out.append({"phase": where, "type": "field", "kind": kind, "key": k, "field": f, "oracle": a,
                                "sql": b})
    STATS["findings_compared"] += sum(len(v) for v in exp.values())
    return out


# ===================================================================================== the GENERATOR (frames)
SD_POOL = ["H0001", "H0004", "H0015", "H0017", "H0018", "H0019", "H2014", "H2016", "H2017", "H2019", "H2020",
           "S9484", "S9485", "T1016", "90791", "90832", "90834", "90837", "99213", "T1019"]
ANESTHESIA_CODES = ["00100", "00790", "01402", "01996"]           # CPT 00100-01999: recorded only (v2.6, R-T19)
DL_POOL = (["H2014", "H0004", "97110", "T1019", "S5125", "90837", "H0015", "99213", "A0425", "J1100", "G0151",
            "H2017", "H0038"] + ANESTHESIA_CODES + ["0213T"])     # 0213T: starts with 0, not anesthesia
B2_COMPILE_POOL = ["H0001", "H0004", "H0015", "H0031", "H0038", "H2011", "H2014", "H2017", "H2019", "H2027"]
B2_OTHER_POOL = ["90834", "90837", "T1016", "T1019", "S9484", "J3490", "G0466", "99213", "H1000", "H1005"]
B2_TYPES = ["77", "B1", "B2", "B3", "B5", "B6", "B7", "B8", "IC", "08", "31", "19", "85", "86", "87", "A4", "C2",
            "02", "05", "29"]
B2_BLANKS = [None, "", " ", "NONE", "None", "nan", " NULL ", float("nan")]
B2_ODD = ["8.5", "C-2", "ABCDE", "0.5"]
VD_CANDIDATES = [D(2024, 7, 1), D(2024, 10, 1), D(2024, 12, 15), D(2025, 1, 1), D(2025, 2, 28), D(2025, 3, 1),
                 D(2025, 7, 1), D(2025, 10, 1)]
LIMIT_KINDS = ["none"] * 8 + ["D1_equal"] * 3 + ["D1_diff"] * 2 + ["D2"] * 2 + ["W", "M", "Y", "L"]


def code_spelling(rng, c, p=0.3):
    """A raw frame spelling of a cleaned code (R-T2): spaces around, lower case."""
    if rng.random() >= p:
        return c
    TCOVER["frame:messy_code_spelling"] += 1
    return rng.choice([" " + c, c + " ", c.lower(), " " + c.lower() + " ", "  " + c, c.lower() + "  "])


def flag_spelling(rng, f, p=0.2):
    """(v2.6) a raw spelling of an indicator / Frequency Cd that trimming + upper-casing cleans back to f."""
    if f is None or rng.random() >= p:
        return f
    TCOVER["frame:messy_indicator_or_frequency_cd_spelling"] += 1
    return rng.choice([f.lower(), " " + f, f + " ", " " + f.lower() + " "])


def b2_type_spelling(rng, t):
    """A raw B2 spelling of a cleaned provider type that §1 cleans back to t (R-T9)."""
    if rng.random() < 0.45:
        return t
    if t.isdigit():
        n = int(t)
        v = [" " + t, t + " ", f"{n}.0", f"{t}.00", n, float(n), f" {n} ", f"{t}.0"]
        if t[0] == "0":
            v += [str(n), str(n), f" {n}"]
        s = rng.choice(v)
    else:
        s = rng.choice([t.lower(), " " + t, t + " ", " " + t.lower() + " "])
    TCOVER["b2_type_spelled:" + O._entry_kind(s)] += 1
    return s


def _sha(*parts) -> str:
    return hashlib.sha256("|".join(map(str, parts)).encode()).hexdigest()


def _frame(key, records, extra_cols=()):
    import pandas as pd
    cols = __import__("ahcccs_tables").TABLE_COLUMNS[key] + list(extra_cols)
    return pd.DataFrame({c: pd.Series([r.get(c) for r in records], dtype=object) for c in cols})


def gen_same_day(rng, versions, seed):
    rows, grid = [], None
    for vi, v in enumerate(versions):
        if grid is None:
            rs = rng.sample(SD_POOL, rng.randint(4, 6))
            others = [c for c in SD_POOL if c not in rs]
            cs = rng.sample(rs, rng.randint(2, 3)) + rng.sample(others, rng.randint(1, 2))
            grid = {(r, c): rng.choices(["D", "A*", "A"], weights=[4, 3, 3])[0] for r in rs for c in cs}
        else:
            grid = dict(grid)
            for k in list(grid):
                if rng.random() < 0.2:
                    grid[k] = rng.choice(["D", "A*", "A"])
            rs = sorted({k[0] for k in grid})
            cs = sorted({k[1] for k in grid})
            if rng.random() < 0.35 and len(rs) > 3:                  # a row code leaves the grid
                gone = rng.choice(rs)
                grid = {k: x for k, x in grid.items() if k[0] != gone}
            if rng.random() < 0.35:                                  # a row code joins it
                new = rng.choice([c for c in SD_POOL if c not in rs])
                for c in cs:
                    grid[(new, c)] = rng.choices(["D", "A*", "A"], weights=[4, 3, 3])[0]
        sha = _sha("sd", seed, v)
        rcodes = sorted({k[0] for k in grid})
        ccodes = sorted({k[1] for k in grid})
        for (r, c), ind in sorted(grid.items()):
            rows.append({"version_date": v.isoformat(), "file_sha256": sha, "file_name": f"SameDay_{v}.xlsx",
                         "sheet": "Same Day Disallow", "row_code": code_spelling(rng, r), "row_description": f"desc {r}",
                         "row_unit": rng.choice(["per diem", "15 min", "per session", None]),
                         "col_code": code_spelling(rng, c), "col_unit": rng.choice(["per diem", "per session"]),
                         "indicator": flag_spelling(rng, ind), "changed": rng.random() < 0.1,
                         "cell": f"{chr(68 + ccodes.index(c))}{12 + rcodes.index(r)}"})
    return rows


def _limit(rng, kind, n):
    if kind == "none":
        return None, None, rng.choice([None, None, None, ""])
    if kind == "D1_equal":
        return n, 1, flag_spelling(rng, "D")
    if kind == "D1_diff":
        return rng.choice([x for x in range(1, 13) if x != n]), rng.choice([1, 1, "1", 1.0]), flag_spelling(rng, "D")
    if kind == "D2":
        return rng.randint(1, 20), rng.choice([2, 3, 7]), flag_spelling(rng, "D")
    return rng.randint(1, 60), rng.choice([1, 1, 2, 3]), flag_spelling(rng, kind)


def _max(rng):
    """(v2.6, R-T19) a 'Procedure Maximum Occurrence': mostly 1-10, sometimes 9 / 99 (real) or all nines (placeholder)."""
    if rng.random() < 0.85:
        return rng.randint(1, 10)
    v = rng.choice([9, 99, 999, 9999, 999999, 12, 99, 999])
    TCOVER[f"daily_max_drawn:{v}"] += 1
    return v


def _daily_row(rng, code, n):
    k1 = rng.choice(LIMIT_KINDS)
    k2 = rng.choice(LIMIT_KINDS) if rng.random() < 0.5 else "none"
    TCOVER[f"daily_limit1:{k1}"] += 1
    TCOVER[f"daily_limit2:{k2}"] += 1
    l1, v1, c1 = _limit(rng, k1, n)
    l2, v2, c2 = _limit(rng, k2, n)
    return {"code": code, "daily_max": n, "limit1": l1, "freq1_value": v1, "freq1_cd": c1, "limit2": l2,
            "freq2_value": v2, "freq2_cd": c2}


def gen_daily(rng, versions, seed):
    rows, cur = [], None
    for vi, v in enumerate(versions):
        if cur is None:
            cur = {c: _daily_row(rng, c, _max(rng)) for c in rng.sample(DL_POOL, rng.randint(6, 9))}
        else:
            cur = {c: dict(r) for c, r in cur.items()}
            for c in list(cur):
                x = rng.random()
                if x < 0.15:
                    cur[c] = _daily_row(rng, c, _max(rng))              # new maximum and limits
                elif x < 0.25:
                    cur[c]["daily_max"] = _max(rng)                     # new maximum only (limits may now differ)
                elif x < 0.3 and len(cur) > 4:
                    del cur[c]
            if rng.random() < 0.4:
                new = [c for c in DL_POOL if c not in cur]
                if new:
                    c = rng.choice(new)
                    cur[c] = _daily_row(rng, c, _max(rng))
        sha = _sha("dl", seed, v)
        for i, (c, r) in enumerate(sorted(cur.items())):
            rows.append(dict(r, code=code_spelling(rng, c), version_date=v.isoformat(), file_sha256=sha,
                             file_name=f"DailyLimits_{v}.xlsx", sheet="Sheet1", description=f"{c} - desc",
                             source_row=8 + i))
    return rows


def gen_b2(rng, versions, seed, force=()):
    rows, cur = [], None
    for vi, v in enumerate(versions):
        if cur is None:
            codes = rng.sample(B2_COMPILE_POOL, rng.randint(4, 6)) + rng.sample(B2_OTHER_POOL, rng.randint(2, 4))
            codes += [c for c in force if c not in codes]
            cur = {}
            for c in codes:
                x = rng.random()
                extra = "blank" if x < 0.08 else "odd" if x < 0.12 else None
                cur[c] = (rng.sample(B2_TYPES, rng.randint(1, 4)), extra)
        else:
            nxt = {}
            for c, (types, extra) in cur.items():
                types = list(types)
                x = rng.random()
                if x < 0.2:
                    types.append(rng.choice([t for t in B2_TYPES if t not in types]))
                elif x < 0.35 and len(types) > 1:
                    types.remove(rng.choice(types))
                elif x < 0.42:
                    extra = None if extra else rng.choice(["blank", "odd"])
                elif x < 0.47:
                    continue                                          # the code leaves the matrix
                nxt[c] = (types, extra)
            if rng.random() < 0.4:
                new = [c for c in B2_COMPILE_POOL + B2_OTHER_POOL if c not in nxt]
                if new:
                    nxt[rng.choice(new)] = (rng.sample(B2_TYPES, rng.randint(1, 3)), None)
            cur = nxt
        sha = _sha("b2", seed, v)
        k = 0
        for c, (types, extra) in sorted(cur.items()):
            vals = []
            for t in types:
                for _ in range(rng.choice([1, 1, 2, 3])):                # merged ranges: one row per POS / modifier set
                    vals.append(b2_type_spelling(rng, t))
            if extra == "blank":
                vals.insert(rng.randint(0, len(vals)), rng.choice(B2_BLANKS))
            elif extra == "odd":
                vals.insert(rng.randint(0, len(vals)), rng.choice(B2_ODD))
            for t in vals:
                k += 1
                rows.append({"version_date": v.isoformat(), "file_sha256": sha, "file_name": f"B2Matrix_{v}.xlsx",
                             "sheet": "B2 Matrix", "code": code_spelling(rng, c), "code_description": f"{c} desc",
                             "provider_type": t, "provider_type_description": "type desc",
                             "coverage_code": rng.choice(["C", "CR", None]),
                             "category_of_service": rng.choice(["47", "01", None]),
                             "places_of_service": rng.choice(["11", "11,12", "02,10,11", None]),
                             "modifiers": rng.choice(["", "HO", "HN,HO", None]), "source_row": 5 + k})
    return rows


def gen_frames(rng, seed, force_b2=()) -> tuple:
    versions = {}
    for key in TABLE_KEYS:
        n = rng.choice([1, 2, 2, 3, 3])
        versions[key] = sorted(rng.sample(VD_CANDIDATES, n))
        TCOVER[f"versions_per_table:{n}"] += 1
        if any(b - a == DAY for a, b in zip(versions[key], versions[key][1:])):
            TCOVER["version_windows:one_day_window(consecutive version dates)"] += 1
    frames = {"same_day_disallow": _frame("same_day_disallow", gen_same_day(rng, versions["same_day_disallow"], seed)),
              "daily_limits": _frame("daily_limits", gen_daily(rng, versions["daily_limits"], seed)),
              "b2_matrix": _frame("b2_matrix", gen_b2(rng, versions["b2_matrix"], seed, force_b2))}
    return frames, versions


# ===================================================================================== the GENERATOR (claims)
def scenario_catalogue(frames, claimed: set, cfg: dict) -> dict:
    """Pseudo-rules the claims are built on: every Same Day cell (A and diagonal included), every daily row (two-limit,
    record-only and placeholder rows included), every B2 (version, code) - whether or not it makes a rule - restricted to
    the billed codes. Each carries 'active': the version windows in which it DOES make a (compiling) rule, so most
    visits hit a live rule. B2 pseudo-rules carry the configured role (group lines are generated for billing_or_rendering)."""
    cat = {"pair": {}, "day": {}, "pta": {}}
    wins = {k: version_windows_oracle(frames[k]["version_date"]) for k in TABLE_KEYS if len(frames[k])}

    def entry(kind, key, rule, live, v, table):
        e = cat[kind].setdefault(key, dict(rule, active=[]))
        if live:
            eff, end = wins[table][vdate(v)]
            e["active"].append((D.fromisoformat(eff), None if end is None else D.fromisoformat(end)))

    for r in frames["same_day_disallow"].to_dict("records"):
        R, C = clean_code(r["row_code"]), clean_code(r["col_code"])
        if {R, C} <= claimed:
            entry("pair", (C, R), {"rule_id": f"SC-PAIR-{C}-{R}", "origin": "ahcccs_table",
                                   "predicate": {"type": "code_pair_prohibited", "code_a": C, "code_b": R,
                                                 "modifier_indicator": "0"}},
                  R != C and clean_flag(r["indicator"]) in DA, r["version_date"], "same_day_disallow")
    for r in frames["daily_limits"].to_dict("records"):
        K, N = clean_code(r["code"]), _int(r["daily_max"])
        if K in claimed:
            live = not (two_daily_limits_of(r, N) or re.fullmatch(cfg["record_only"], K)
                        or re.fullmatch(cfg["placeholder"], str(N)))
            entry("day", (K, N), {"rule_id": f"SC-DAY-{K}-{N}", "origin": "ahcccs_table",
                                  "predicate": {"type": "max_units_per_day", "code": K, "threshold": min(N, 120)}},
                  live, r["version_date"], "daily_limits")
    groups = defaultdict(list)
    for r in frames["b2_matrix"].to_dict("records"):
        groups[(r["version_date"], clean_code(r["code"]))].append(r["provider_type"])
    for (v, K), raw in groups.items():
        types = {O.clean_entry(t) for t in raw}
        listable = sorted(t for t in types if t is not None and not O.bad_entries({"provider_types": [t]}))
        if K in claimed:
            entry("pta", (K, tuple(listable)), {"rule_id": f"SC-PTA-{K}", "origin": "ahcccs_table",
                                                "predicate": {"type": "provider_type_allowed", "code": K,
                                                              "provider_types": listable or ["ZZ"],
                                                              "provider_role": cfg["b2_role"]}},
                  bool(re.fullmatch(cfg["b2_pattern"], K)) and not O.bad_entries({"provider_types": raw}), v,
                  "b2_matrix")
    return {k: list(v.values()) for k, v in cat.items()}


def _active_on(e, d) -> bool:
    return any(a <= d and (b is None or d <= b) for a, b in e["active"])


def _pick(rng, entries, d):
    live = [e for e in entries if _active_on(e, d)]
    return rng.choice(live) if live and rng.random() < 0.7 else rng.choice(entries)


SCEN = [("pair", 6), ("day", 6), ("pta", 4), ("tie", 1), ("noise", 1)]


def _postprocess(b, rng, base):
    """The §1 hard cases of test_sql_oracle.gen_claimset, applied to this generator's rows (same proportions)."""
    out = list(base)
    for r in base:                                           # reversals (most exact, some not)
        if r["paid"] is not None and r["paid"] > 0 and r["code"] and rng.random() < 0.14:
            out.append(O._reversal(b, rng, r, exact=rng.random() < 0.72))
    for r in base:                                           # several identical lines + one (or two) reversals
        if r["paid"] is not None and r["paid"] > 0 and r["code"] and rng.random() < 0.05:
            for _ in range(rng.randint(1, 2)):
                twin = dict(r)
                x = rng.random()
                if x < 0.45:
                    twin["claim"], twin["line"] = b.claim(), rng.choice([1, 2, None])
                elif x < 0.85:
                    twin["line"] = rng.choice([None, 10, 12, 1, 3]) if r["line"] is not None else rng.choice([1, 2, 10])
                else:
                    twin["claim"], twin["line"] = None, rng.choice([1, None])
                twin["pa"] = rng.choice(O.PA_RAW)
                twin["form"] = rng.choice([r["form"], "A", "O"])
                if rng.random() < 0.3:
                    twin["btype"] = O._ptype_raw(rng, rng.choice(O.BILLING_ALT))
                if rng.random() < 0.15:                      # (v2.6) the twin under another billing provider id
                    twin["bprov"] = rng.choice(["B2", "b1", None, " B1 "])
                out.append(twin)
            for _ in range(1 if rng.random() < 0.75 else 2):
                out.append(O._reversal(b, rng, r, exact=True))
    for r in list(out):                                      # exact duplicates
        if rng.random() < 0.06:
            out.append(dict(r))
    for r in list(out):                                      # duplicates after clean-up only
        if rng.random() < 0.04:
            nd = dict(r)
            nd["code"] = O._vary(rng, O._upper(O._trim(r["code"])), 1.0)
            nd["mods"] = tuple(O._vary(rng, O._upper(O._blank_null(m)), 0.6) if O._blank_null(m)
                               else rng.choice([None, "", " "]) for m in r["mods"])
            nd["form"] = O._vary(rng, O._upper(O._trim(r["form"])), 0.6)
            nd["member"] = O._pad(rng, O._blank_null(r["member"]), 0.6) if O._blank_null(r["member"]) else r["member"]
            nd["sprov"] = O._pad(rng, O._blank_null(r["sprov"]), 0.6) if O._blank_null(r["sprov"]) else rng.choice([None, ""])
            nd["bprov"] = O._pad(rng, O._blank_null(r["bprov"]), 0.6) if O._blank_null(r["bprov"]) else rng.choice([None, ""])
            nd["pa"] = O._pad(rng, O._blank_null(r["pa"]), 0.6) if O._blank_null(r["pa"]) else rng.choice([None, "", " "])
            nd["ptype"] = O._ptype_raw(rng, O.clean_prov_type(r.get("ptype")), 0.8)
            nd["btype"] = O._ptype_raw(rng, O.clean_prov_type(r.get("btype")), 0.8)
            out.append(nd)
    for r in list(out):                                      # the same row with ANOTHER billing type (a kept column)
        if rng.random() < 0.03:
            nd = dict(r)
            cur = O.clean_prov_type(r.get("btype"))
            nd["btype"] = O._ptype_raw(rng, rng.choice([c for c in O.BILLING_ALT if c != cur]))
            out.append(nd)
    for r in list(out):                                      # same row, different POS (POS is not kept)
        if rng.random() < 0.01:
            nd = dict(r)
            nd["pos"] = " 11" if r["pos"] != " 11" else "99"
            out.append(nd)
    rng.shuffle(out)
    assert not O.unresolved_cancellation_ties(out), "rows tie on every column of the v2.3 cancellation order"
    return out


def gen_claimset(seed: int, prefix: str, cat: dict, date_pool: list) -> list:
    rng = random.Random(seed)
    b = O._Builder(rng, prefix)
    kinds = [k for k, _ in SCEN if k in ("tie", "noise") or cat.get(k)]
    weights = [w for k, w in SCEN if k in kinds]
    tie_rules = [r for r in cat["pair"] + cat["pta"]]
    for i in range(rng.randint(4, 7)):
        provs = rng.sample(["P1", "P2", "P3"], k=rng.randint(1, 2))
        if rng.random() < 0.12:
            provs.append("p1")                               # a DIFFERENT provider id (ids are not upper-cased)
        agencies = rng.sample(["B1", "B2", "B3"], k=rng.randint(1, 2))     # (v2.6) the member's billing provider ids
        dates = rng.sample(date_pool, k=min(len(date_pool), rng.randint(3, 6)))
        dob = O.pick_dob(rng)
        member = f"{prefix}M{i}" if rng.random() > 0.08 else f"{prefix}m{i}"
        for d in sorted(dates):
            for _ in range(rng.randint(1, 3)):
                ctx = {"member": member if rng.random() > 0.1 else f"{prefix}M{i}", "dob": dob, "dos": d,
                       "prov": rng.choice(provs), "bprov": rng.choice(agencies)}
                if rng.random() < 0.015 and tie_rules:
                    O.sc_orphan_reversal(b, rng, ctx, rng.choice(tie_rules))
                    continue
                kind = rng.choices(kinds, weights=weights)[0]
                if kind == "pair":
                    O.sc_pair(b, rng, ctx, _pick(rng, cat["pair"], d))
                elif kind == "day":
                    O.sc_units_group(b, rng, ctx, _pick(rng, cat["day"], d), rng.random() < 0.5)
                elif kind == "pta":
                    O.sc_pta(b, rng, ctx, _pick(rng, cat["pta"], d))
                elif kind == "tie" and O._tie_candidates(tie_rules):
                    O.sc_tie(b, rng, ctx, tie_rules)
                else:
                    O.sc_noise(b, rng, ctx, [])
    return _postprocess(b, rng, list(b.rows))


def claims_scope(raw) -> set:
    """R-T3: the distinct UPPER(TRIM(code)) of every claim row with a code (notebook 07, PAID_FILTER = '')."""
    return {r["code"].strip(" ").upper() for r in raw if r["code"] is not None}


def build_round(seed: int, n_sets: int, *, scope_none=False, pre_normalise=None, force_b2=()) -> dict:
    rng = random.Random(seed * 104729 + 17)
    frames, versions = gen_frames(rng, seed, tuple(force_b2))
    assert not refusals(frames), refusals(frames)            # R-T18: the random rounds never hold a refusal
    all_codes = set()
    for key, col in (("same_day_disallow", "row_code"), ("same_day_disallow", "col_code"), ("daily_limits", "code"),
                     ("b2_matrix", "code")):
        all_codes |= {clean_code(v) for v in frames[key][col]}
    unclaimed = set(rng.sample(sorted(all_codes), k=max(1, len(all_codes) // 7))) - set(force_b2)
    claimed = all_codes - unclaimed
    cat = scenario_catalogue(frames, claimed, table_config())
    vds = sorted({d for vs in versions.values() for d in vs})
    pool = set()
    for d in vds:
        pool |= {d - DAY, d, d + DAY}
    pool |= {vds[0] - 15 * DAY, vds[-1] + 30 * DAY, vds[-1] + 200 * DAY}
    pool |= {vds[0] - 60 * DAY + rng.randint(0, 600) * DAY for _ in range(3)}
    date_pool = sorted(pool)
    raw = []
    for k in range(n_sets):
        raw += gen_claimset(seed * 1000 + k, f"t{seed}s{k}", cat, date_pool)
    scope = None if scope_none else claims_scope(raw)
    return {"seed": seed, "frames": frames, "versions": versions, "raw": raw, "scope": scope, "unclaimed": unclaimed,
            "pre_normalise": (seed % 2 == 1) if pre_normalise is None else pre_normalise}


# ===================================================================================== coverage of the table hard cases
def cover_frames(frames, xp, scope, cfg):
    sd = frames["same_day_disallow"]
    marks = defaultdict(dict)
    for r in sd.to_dict("records"):
        R, C, ind = clean_code(r["row_code"]), clean_code(r["col_code"]), clean_flag(r["indicator"])
        marks[r["version_date"]][(R, C)] = ind
        if R == C and (r["row_code"] != r["col_code"]):
            TCOVER["same_day:diagonal_spelled_two_ways(' H2014' x 'h2014')"] += 1
        if r["indicator"] != ind:
            TCOVER[f"same_day:indicator_spelled_{r['indicator']!r}_cleaned_to_{ind}"] += 1
        TCOVER[f"same_day:cell:{'diagonal' if R == C else ind}"] += 1
    for v, cells in marks.items():
        for (R, C), ind in cells.items():
            if R < C and (C, R) in cells and ind in DA and cells[(C, R)] in DA:
                TCOVER["same_day:pair_marked_both_ways:" + "/".join(sorted((ind, cells[(C, R)])))] += 1
            if R != C and ind in DA and cells.get((C, R)) == "A":
                TCOVER["same_day:mirror_cell_is_A(no both_ways)"] += 1
    for r in frames["daily_limits"].to_dict("records"):
        for i in (1, 2):
            cd = r[f"freq{i}_cd"]
            if cd not in (None, "") and cd != clean_flag(cd):
                TCOVER["daily:frequency_cd_spelled_messy(cleaned)"] += 1
                if clean_flag(cd) == "D" and _int(r[f"freq{i}_value"]) == 1 and _int(r[f"limit{i}"]) != _int(r["daily_max"]):
                    TCOVER["daily:two_daily_limits_via_a_LOWER_CASE/padded_D(v2.6)"] += 1
        if clean_code(r["code"]) in ANESTHESIA_CODES:
            TCOVER["daily:anesthesia_code_row"] += 1
    pat = cfg["b2_pattern"]
    for v, k in {(r["version_date"], clean_code(r["code"])) for r in frames["b2_matrix"].to_dict("records")}:
        verdicts = (bool(re.search(pat, k)), bool(re.match(pat, k)), bool(re.fullmatch(pat, k)))
        if len(set(verdicts)) > 1:
            TCOVER["b2_pattern:search/match/fullmatch_disagree_on_a_code(S-T1):search=%s,match=%s,full=%s"
                   % verdicts] += 1
    for x in xp["scoped_out"]:
        codes = O.rule_codes(x["predicate"]) | ({x["predicate"]["code_a"], x["predicate"]["code_b"]}
                                                 if x["kind"] == "pair" else set())
        if scope is not None and len(codes) == 2 and len(codes & scope) == 1:
            TCOVER["scope:pair_with_ONE_code_in_scope(scoped out)"] += 1
        TCOVER[f"scope:scoped_out:{x['kind']}"] += 1
    for x in xp["built"]:
        p = x["predicate"]
        TCOVER[f"rule_built:{x['kind']}" + (":LEAD" if x["lead"] else "")] += 1
        if x["kind"] == "pair":
            TCOVER[f"rule_built:pair:scope={p['scope']}" + (":both_ways" if p.get("both_ways") else "")] += 1
        if x["kind"] == "b2" and x["lead"]:
            bad = O.bad_entries({"provider_types": [r["provider_type"] for r in x["src"]]})
            TCOVER["b2_lead_because:" + ("blank/null" if any(O.clean_entry(v) is None for v in bad) else "odd")] += 1
        if x["kind"] == "b2":
            k = p["code"]
            if not (re.match(pat, k) and re.search(pat, k)):
                TCOVER["b2_pattern:search/match_disagree_with_fullmatch_on_a_BUILT_rule's_code"] += 1
            if not re.search(r"^H[02]", k):
                TCOVER["b2:rule_on_a_code_outside_H0/H2(variant pattern)"] += 1
            TCOVER[f"b2:rule_role={p['provider_role']}"] += 1
        if x["kind"] == "b2" and len({str(r["code"]) for r in x["src"]}) > 1:
            TCOVER["b2:rows_of_one_code_spelled_differently_grouped"] += 1
        if x["kind"] == "daily":
            row = x["src"][0]
            if any(clean_flag(row[f"freq{i}_cd"]) == "D" and _int(row[f"freq{i}_value"]) == 1 for i in (1, 2)):
                TCOVER["daily:rule_with_a_D/1_limit_EQUAL_to_N"] += 1
            if recorded_limits_of(row):
                TCOVER["daily:rule_with_a_recorded_period_limit(W/M/Y/L/D!=1)"] += 1
            if int(p["threshold"]) in (9, 99):
                TCOVER[f"daily:rule_with_maximum_{p['threshold']}(not a placeholder)"] += 1
            TCOVER[f"daily:rule_scope={p['scope']}"] += 1
    for k, n in xp["excluded"].items():
        TCOVER[f"excluded:{k}"] += n


def cover_findings(xp, findings, snap):
    first = {}
    for key, win in xp["windows"].items():
        first[KIND_OF_TABLE[key]] = min(win)
    for x in xp["built"]:
        if x["lead"]:
            continue
        eff, end = _iso(x["effective_date"]), _iso(x["end_date"])
        for f in findings.get(x["sig"], []):
            d = f["key"][-1]
            if d.isoformat() == eff:
                TCOVER[f"finding_on_version_date(effective):{x['kind']}"] += 1
            if end is not None and d.isoformat() == end:
                TCOVER[f"finding_on_day_before_next_version(end):{x['kind']}"] += 1
            if end is None and d > vdate(eff) + 25 * DAY:
                TCOVER[f"finding_after_last_version_date(open window):{x['kind']}"] += 1
            if x["kind"] == "pair":
                TCOVER[f"finding:pair:{x['predicate']['scope']}" + (":both_ways" if x["predicate"].get("both_ways")
                                                                     else "")] += 1
                if f["pa_present"]:
                    TCOVER["finding:pair:verify_pa"] += 1
            elif x["kind"] == "daily":
                TCOVER[f"finding:daily:{x['predicate']['scope']}:{f['finding_severity']}"] += 1
            else:
                TCOVER[f"finding:b2:{f['finding_form'][0]}_text:{f['finding_severity']}"] += 1
    codes_of = defaultdict(set)
    for x in xp["built"] + xp["scoped_out"]:
        codes_of[x["kind"]] |= O.rule_codes(x["predicate"]) | (
            {x["predicate"]["code_a"], x["predicate"]["code_b"]} if x["kind"] == "pair" else set())
    for kind, d1 in first.items():
        n = sum(1 for r in snap if r["code"] in codes_of[kind] and r["payable"] and r["dos"] < d1)
        TCOVER[f"payable_lines_dated_BEFORE_the_oldest_version(not judged):{kind}"] += n
    excluded_codes = {d[1] for k in ("daily:record_only_code", "daily:placeholder_maximum")
                      for d in xp["excluded_detail"].get(k, [])}
    TCOVER["payable_lines_of_record_only_or_placeholder_codes(no daily rule)"] += sum(
        1 for r in snap if r["code"] in excluded_codes and r["payable"])


# ===================================================================================== the SPARK side (black box)
EDIT_FQN = {k: f"spark_catalog.policy_kb.{dg.TABLE_BATCH_EDIT_TABLE[k]}" for k in dg.TABLE_BATCHES}
BUILD_ID = "BX"


def make_spark(warehouse):
    from pyspark.sql import SparkSession
    return (SparkSession.builder.master("local[2]").appName("pie-sql-oracle-tables")
            .config("spark.driver.memory", "1500m")
            .config("spark.sql.shuffle.partitions", "1")
            .config("spark.default.parallelism", "2")
            .config("spark.sql.ansi.enabled", "true")
            .config("spark.sql.session.timeZone", "UTC")
            .config("spark.ui.enabled", "false")
            .config("spark.ui.showConsoleProgress", "false")
            .config("spark.sql.execution.arrow.pyspark.enabled", "false")
            .config("spark.sql.warehouse.dir", warehouse)
            .config("spark.local.dir", os.path.join(warehouse, "_local"))
            .config("spark.driver.extraJavaOptions", "-XX:+UseSerialGC -Dderby.system.home=" + warehouse)
            .getOrCreate())


def run_sql(spark, sql):
    return [r.asDict(recursive=True) for r in spark.sql(sql).collect()]


def _normv(v):
    if isinstance(v, bool) or v is None:
        return v
    if isinstance(v, (int, float, Decimal)):
        return Decimal(str(v)).normalize() + 0
    return v


def _row_tuple(row: dict, cols) -> tuple:
    return tuple((c, _normv(row.get(c))) for c in cols)


def write_edit_table(spark, df, fqn):
    """As notebook 07 writes an edit table: every frame (empty ones too) carries the build_id column."""
    import kb_io
    if "build_id" not in df.columns:
        df = df.copy()
        df["build_id"] = BUILD_ID
    with contextlib.redirect_stdout(io.StringIO()):
        kb_io.write_table(spark, df, fqn, "overwrite")


def production_rules(frames, scope, pre_normalise):
    """notebook 07 steps 3b-4 for the table rules alone: rules_from_frames -> gate -> normalise (on their own) ->
    build_detectors (batch_tables=True, and False for the per-rule SQL)."""
    import ahcccs_tables
    import rule_normalize
    import validate_gate
    if pre_normalise:
        frames_in = {k: ahcccs_tables.normalise_frame(k, df.copy()) for k, df in frames.items()}
    else:
        frames_in = {k: df.copy() for k, df in frames.items()}
    report = {}
    rules = ahcccs_tables.rules_from_frames(frames_in, scope, report)
    built = [r.to_dict() for r in rules]
    accepted, rejected = validate_gate.gate(rules)
    accepted, nrep = rule_normalize.normalize_rules(accepted)
    dets_b = dg.build_detectors(accepted, batch_ncci=True, batch_tables=True)
    dets_p = dg.build_detectors(accepted, batch_tables=False)
    return {"built": built, "report": report, "accepted": accepted, "rejected": rejected, "norm_report": nrep,
            "dets_b": dets_b, "dets_p": dets_p}


def compare_rules(where, xp, pr) -> list:
    """Step 1: the rules (multiset of sigs), leads, predicate details, batching, counts per kind and version."""
    mism = []
    exp_b = Counter(x["sig"] for x in xp["built"])
    got_b = Counter(rule_sig(r) for r in pr["built"])
    x_by_sig = {x["sig"]: x for x in xp["built"]}
    for s in sorted(set(exp_b) | set(got_b), key=repr):
        if exp_b[s] != got_b[s]:
            x = x_by_sig.get(s)
            mism.append({"phase": where + ":rules", "type": "rule_multiset", "kind": s[0], "key": sig_str(s),
                         "oracle": exp_b[s], "sql": got_b[s], "src": (x or {}).get("src")})
    STATS["rules_compared"] += sum(exp_b.values())
    # gate / normalise must keep every table rule (the spec has no reason to drop one)
    for r in pr["rejected"]:
        mism.append({"phase": where + ":rules", "type": "gate_rejected", "kind": KIND_OF_TYPE.get(
            r.get("predicate", {}).get("type")), "key": sig_str(rule_sig(r)), "sql": r.get("reject_reason")})
    if Counter(rule_sig(r) for r in pr["accepted"]) != got_b:
        lost = got_b - Counter(rule_sig(r) for r in pr["accepted"])
        mism.append({"phase": where + ":rules", "type": "normalise_changed_the_rules", "key": [sig_str(s) for s in lost],
                     "sql": pr["norm_report"]})
    # predicate details, origin, rule id (scope, both_ways, threshold, list and role are in the sig)
    for r in pr["accepted"]:
        p, s = r["predicate"], rule_sig(r)
        kind = KIND_OF_TYPE.get(p.get("type"))
        bad = []
        if r.get("origin") != "ahcccs_table":
            bad.append(("origin", r.get("origin")))
        if not str(r.get("rule_id", "")).startswith("TBL-"):
            bad.append(("rule_id", r.get("rule_id")))
        if p.get("age"):
            bad.append(("age", p.get("age")))
        if p.get("discretionary") is True:
            bad.append(("discretionary", True))
        if kind == "pair":
            if O.indicator_of(p) != "0":
                bad.append(("modifier_indicator", p.get("modifier_indicator")))
            if (p.get("exception") or "").strip() != NOTE2:
                bad.append(("exception", p.get("exception")))
            if p.get("both_ways") not in (None, False, True):
                bad.append(("both_ways", p.get("both_ways")))
        elif kind in ("daily", "b2") and (p.get("exception") or "").strip():
            bad.append(("exception", p.get("exception")))
        if bad:
            mism.append({"phase": where + ":rules", "type": "predicate_detail", "kind": kind, "key": sig_str(s),
                         "sql": bad})
    # leads and batching
    by_id = {r["rule_id"]: r for r in pr["accepted"]}
    exp_lead = {x["sig"] for x in xp["built"] if x["lead"]}
    exp_comp = {x["sig"] for x in xp["built"] if not x["lead"]}
    got_lead, got_comp, unbatched = set(), set(), []
    for d in pr["dets_b"]:
        s = rule_sig(by_id[d["rule_id"]])
        if d.get("compiled"):
            got_comp.add(s)
            if d.get("batch") not in dg.TABLE_BATCHES:
                unbatched.append(sig_str(s))
        else:
            got_lead.add(s)
    for s in sorted((exp_lead ^ got_lead) & set(exp_b) & set(got_b), key=repr):   # existence: rule_multiset
        mism.append({"phase": where + ":rules", "type": "lead", "kind": s[0], "key": sig_str(s),
                     "oracle": "lead" if s in exp_lead else "compiles", "sql": "lead" if s in got_lead else "compiles"})
    if unbatched:
        mism.append({"phase": where + ":rules", "type": "compiled_but_not_batched", "key": unbatched})
    for d in pr["dets_p"]:
        s = rule_sig(by_id[d["rule_id"]])
        if bool(d.get("compiled") and d.get("sql")) != (s in exp_comp):
            mism.append({"phase": where + ":rules", "type": "per_rule_sql_presence", "kind": s[0], "key": sig_str(s),
                         "oracle": s in exp_comp, "sql": d.get("reason") or "compiled"})
    # counts per kind and version (built / lead), and per table (scoped out / excluded: informational, R-T15)
    def per_version(rules, lead_sigs):
        c = Counter()
        for r in rules:
            s = rule_sig(r)
            c[(s[0], _iso(r.get("effective_date")), "built")] += 1
            if s in lead_sigs:
                c[(s[0], _iso(r.get("effective_date")), "lead")] += 1
        return c
    ce = per_version(xp["built"], exp_lead)
    cg = per_version(pr["built"], got_lead)
    for k in sorted(set(ce) | set(cg)):
        if ce[k] != cg[k]:
            mism.append({"phase": where + ":rules", "type": "count_per_kind_version", "key": k, "oracle": ce[k],
                         "sql": cg[k]})
    rep = pr["report"]
    info = {}
    for key in TABLE_KEYS:
        kind = KIND_OF_TABLE[key]
        r = rep.get(key) or {}
        mine = {"rules": sum(1 for x in xp["built"] if x["kind"] == kind),
                "scoped_out": sum(1 for x in xp["scoped_out"] if x["kind"] == kind)}
        theirs = {"rules": r.get("rules"), "scoped_out": r.get("scoped_out")}
        if kind == "pair":
            mine.update(diagonal=xp["excluded"]["pair:diagonal"], A=xp["excluded"]["pair:A"])
            theirs.update(diagonal=r.get("diagonal_skipped"), A=r.get("allowed_no_rule"))
        elif kind == "daily":
            mine.update(two_daily_limits=xp["excluded"]["daily:two_daily_limits"],
                        record_only=xp["excluded"]["daily:record_only_code"],
                        placeholder=xp["excluded"]["daily:placeholder_maximum"])
            rnc = r.get("recorded_not_compiled") or {}
            theirs.update(two_daily_limits=(r.get("two_daily_limits") or {}).get("count"),
                          record_only={k: v for k, v in rnc.items() if "anest" in k or "record_only" in k} or None,
                          placeholder={k: v for k, v in rnc.items() if "placeholder" in k or "nines" in k} or None)
        else:
            mine.update(not_compiled_codes=xp["excluded"]["b2:code_not_compiled"])
            theirs.update(not_compiled_codes=(r.get("recorded_not_compiled") or {}).get("codes"))
        if rep.get(key) is not None and mine != theirs:
            info[key] = {"oracle": mine, "report": theirs}
        if mine["rules"] != theirs["rules"] and rep.get(key) is not None:
            mism.append({"phase": where + ":rules", "type": "report_rule_count", "key": key, "oracle": mine["rules"],
                         "sql": theirs["rules"]})
    if info:
        TCOVER["report_counts_differ(informational)"] += 1
        ROUND_LOG.append({"where": where, "report_counts_informational": info})
    return mism


SCHEMA_NOTES = Counter()      # column-set differences between a batch statement and the per-rule SQL (spec: = NULL)


def _ncci_edition_null(where, kind, rows) -> list:
    """§2b: table rules are state rules - no NCCI edit file on any finding."""
    bad = [r for r in rows if r.get("ncci_edition") is not None]
    return [{"phase": where, "type": "ncci_edition_not_null", "kind": kind, "key": len(bad),
             "sql": sorted({r.get("ncci_edition") for r in bad})}] if bad else []


def run_round(spark, data, label) -> list:
    t0 = time.time()
    raw, frames, scope = data["raw"], data["frames"], data["scope"]
    O.write_claims(spark, raw)
    with contextlib.redirect_stdout(io.StringIO()):
        dg.create_snapshot(spark, source=dg.CLAIMS, target=dg.DETECT, fmt="parquet")
    snap = O.build_snapshot(raw)
    mism = [dict(m, phase=label + ":snapshot") for m in O.compare_snapshot(spark, snap)]
    tm = {"snapshot": time.time() - t0}
    cfg = table_config()
    xp = derive_rules(frames, scope, cfg)
    cover_frames(frames, xp, scope, cfg)
    pr = production_rules(frames, scope, data["pre_normalise"])
    mism += compare_rules(label, xp, pr)
    # ---- the oracle's findings
    by_code = defaultdict(list)
    for r in snap:
        by_code[r["code"]].append(r)
    xfind = {x["sig"]: expected_findings(x, by_code) for x in xp["built"] if not x["lead"]}
    cover_findings(xp, xfind, snap)
    x_by_sig = {x["sig"]: x for x in xp["built"]}
    sig_of = {r["rule_id"]: rule_sig(r) for r in pr["accepted"]}
    kind_of_batch = {b: KIND_OF_TYPE[dg.TABLE_BATCH_PREDICATE[b]] for b in dg.TABLE_BATCHES}
    tm["rules+oracle"] = time.time() - t0 - sum(tm.values())
    # ---- step 2: the three batch statements
    batched = {d["rule_id"] for d in pr["dets_b"] if d.get("compiled") and d.get("batch")}
    edits = dg.ahcccs_edit_tables([r for r in pr["accepted"] if r["rule_id"] in batched])
    batch_rows = {}
    for b, df in zip(dg.TABLE_BATCHES, edits):
        kind = kind_of_batch[b]
        STATS[f"edit_rows:{b}"] += len(df)
        write_edit_table(spark, df, EDIT_FQN[b])
        rows = run_sql(spark, dg.TABLE_BATCH_SQL[b](table=EDIT_FQN[b], build_id=None))
        batch_rows[b] = rows
        # every compiled oracle rule of the kind - one production did not batch still expects its findings here
        exp = [(x_by_sig[s], f) for s, fs in xfind.items() if x_by_sig[s]["kind"] == kind for f in fs]
        mism += compare_findings(f"{label}:BATCH:{b}", kind, exp, rows, lambda row: sig_of.get(row.get("rule_id")))
        mism += _ncci_edition_null(f"{label}:BATCH:{b}", kind, rows)
        STATS["statements_run"] += 1
        STATS[f"findings:{b}"] += len(rows)
        STATS[f"findings_oracle:{b}"] += len(exp)
        # the same statement filtered on a build, with a decoy build's rows in the same edit table
        if len(df):
            real, decoy = df.copy(), df.copy()
            real["build_id"], decoy["build_id"] = BUILD_ID, "BY"
            decoy["rule_id"] = "Y" + decoy["rule_id"].astype(str)
            import pandas as pd
            write_edit_table(spark, pd.concat([real, decoy], ignore_index=True), EDIT_FQN[b])
            rows2 = run_sql(spark, dg.TABLE_BATCH_SQL[b](table=EDIT_FQN[b], build_id=BUILD_ID))
            STATS["statements_run"] += 1
            cols = sorted(set(rows[0]) if rows else set(rows2[0]) if rows2 else set())
            c1, c2 = Counter(_row_tuple(r, cols) for r in rows), Counter(_row_tuple(r, cols) for r in rows2)
            if c1 != c2:
                mism.append({"phase": f"{label}:BATCH:{b}:build_filter", "type": "decoy_build_changes_rows",
                             "oracle": len(rows), "sql": len(rows2),
                             "key": [dict(t) for t in list((c1 - c2) + (c2 - c1))[:5]]})
    tm["batches"] = time.time() - t0 - sum(tm.values())
    # ---- step 3: every compiled rule's own SQL
    jobs = [d for d in pr["dets_p"] if d.get("compiled") and d.get("sql")]
    with ThreadPoolExecutor(max_workers=2) as ex:
        results = list(ex.map(lambda d: run_sql(spark, d["sql"]), jobs))
    per_rule_rows = defaultdict(list)
    for d, rows in zip(jobs, results):
        s = sig_of[d["rule_id"]]
        x = x_by_sig.get(s)
        exp = [(x, f) for f in xfind.get(s, [])] if x is not None else []
        mism += compare_findings(f"{label}:RULE", s[0], exp, rows, lambda row, s=s: s)
        mism += _ncci_edition_null(f"{label}:RULE", s[0], rows)
        STATS["per_rule_queries"] += 1
        STATS[f"per_rule_findings:{s[0]}"] += len(rows)
        b = next(k for k, v in kind_of_batch.items() if v == s[0])
        per_rule_rows[b] += [dict(row, rule_id=d["rule_id"]) for row in rows]
    tm["per_rule"] = time.time() - t0 - sum(tm.values())
    # ---- step 4: batch statement == union of the per-rule SQL, value for value; a column one side does not output
    # reads as NULL (§2b v2.6). Column-set differences are listed in SCHEMA_NOTES (information).
    for b, rows in batch_rows.items():
        mine = per_rule_rows.get(b, [])
        cols_b = set().union(*(set(r) for r in rows)) if rows else set()
        cols_r = set().union(*(set(r) for r in mine)) if mine else set()
        if rows and mine and cols_b != cols_r:
            SCHEMA_NOTES[(b, "batch_only_columns=" + ",".join(sorted(cols_b - cols_r)),
                          "per_rule_only_columns=" + ",".join(sorted(cols_r - cols_b)))] += 1
        cols = sorted(cols_b | cols_r)
        got = Counter(_row_tuple(r, cols) for r in rows)
        want = Counter(_row_tuple(r, cols) for r in mine)
        if got != want:
            extra, missing = got - want, want - got
            mism.append({"phase": f"{label}:BATCH_vs_RULES:{b}", "type": "batch_differs_from_per_rule_union",
                         "oracle": sum(want.values()), "sql": sum(got.values()),
                         "key": {"batch_only": [dict(t) for t in list(extra)[:3]],
                                 "per_rule_only": [dict(t) for t in list(missing)[:3]]}})
        STATS["batch_vs_rule_rows_compared"] += sum(got.values())
    # ---- stats
    STATS["claim_rows"] += len(raw)
    STATS["snapshot_rows"] += len(snap)
    for key in TABLE_KEYS:
        STATS[f"table_rows:{key}"] += len(frames[key])
    for x in xp["built"]:
        STATS[f"rules_built:{x['kind']}"] += 1
        STATS[f"rules_lead:{x['kind']}"] += int(x["lead"])
        if x["kind"] == "pair" and x["predicate"].get("both_ways"):
            STATS["rules_built:pair:both_ways"] += 1
    for x in xp["scoped_out"]:
        STATS[f"rules_scoped_out:{x['kind']}"] += 1
    for k, n in xp["excluded"].items():
        STATS[f"excluded:{k}"] += n
    STATS["rounds"] += 1
    ROUND_LOG.append({"where": label, "seconds": round(time.time() - t0, 1), "claim_rows": len(raw),
                      "rules": len(xp["built"]), "per_rule_queries": len(jobs), "mismatches": len(mism),
                      "pre_normalise": data["pre_normalise"], "scope_none": scope is None, "config": cfg,
                      "phase_seconds": {k: round(v, 1) for k, v in tm.items()}})
    return mism


# ===================================================================================== FIXED hand-computed cases
def _sdrow(v, sha, r, c, ind, i):
    return {"version_date": v, "file_sha256": sha, "file_name": "sd.xlsx", "sheet": "S", "row_code": r,
            "row_description": "d", "row_unit": "u", "col_code": c, "col_unit": "u", "indicator": ind, "changed": False,
            "cell": f"D{10 + i}"}


def _dlrow(v, sha, code, n, l1, l2, i):
    return {"version_date": v, "file_sha256": sha, "file_name": "dl.xlsx", "sheet": "S", "code": code,
            "description": "x", "daily_max": n, "limit1": l1[0], "freq1_value": l1[1], "freq1_cd": l1[2],
            "limit2": l2[0], "freq2_value": l2[1], "freq2_cd": l2[2], "source_row": 7 + i}


def _b2row(v, sha, code, pt, i):
    return {"version_date": v, "file_sha256": sha, "file_name": "b2.xlsx", "sheet": "S", "code": code,
            "code_description": "x", "provider_type": pt, "provider_type_description": "y", "coverage_code": "C",
            "category_of_service": "47", "places_of_service": "11", "modifiers": "", "source_row": 3 + i}


def frames_of(sd=(), dl=(), b2=(), extra_cols=()):
    return {"same_day_disallow": _frame("same_day_disallow", [_sdrow(*r, i) for i, r in enumerate(sd)], extra_cols),
            "daily_limits": _frame("daily_limits", [_dlrow(*r, i) for i, r in enumerate(dl)], extra_cols),
            "b2_matrix": _frame("b2_matrix", [_b2row(*r, i) for i, r in enumerate(b2)], extra_cols)}


_NONE = (None, None, None)
FIX_SD = [("2024-10-01", "sd1", "H0001", "H2014", "D"), ("2024-10-01", "sd1", "h2014 ", " H0001", "A*"),   # both ways
          ("2024-10-01", "sd1", "H0004", "H2014", "a"), ("2024-10-01", "sd1", " H2014", "h2014", "D"),     # 'a'; diagonal
          ("2024-10-01", "sd1", "H0015", "H2014", " a* "), ("2024-10-01", "sd1", "H0017", "H2014", "D"),   # H0017 unbilled
          ("2025-01-01", "sd2", "H0001", "H2014", "A"), ("2025-01-01", "sd2", "H2014", "H0001", "A*"),      # mirror A
          ("2025-01-01", "sd2", "H0015", "H2014", " d"),
          ("2025-03-01", "sd3", "H0001", "H2014", "D")]
FIX_DL = [("2024-10-01", "dl1", "97110", 4, (2, 1, "D"), _NONE),          # two daily limits: no rule
          ("2024-10-01", "dl1", "H2014", 4, (4, 1, "D"), _NONE),          # D/1 equal to N: rule 4
          ("2024-10-01", "dl1", " h0004", 3, _NONE, (10, 1, "W")),        # weekly limit recorded: rule 3
          ("2024-10-01", "dl1", "T1019", 2, (5, 2, "D"), (2, 1, "d")),    # D value 2 recorded; Limit 2 ('d') equal: rule 2
          ("2024-10-01", "dl1", "S5125", 6, (6, 1, "D"), (4, 1, "D")),    # Limit 2 differs: no rule
          ("2024-10-01", "dl1", "S9445", 5, (3, 1, " d "), _NONE),        # ' d ' is D (v2.6): two daily limits, no rule
          ("2024-10-01", "dl1", "G0151", 3, _NONE, _NONE),                # never billed: scoped out
          ("2024-10-01", "dl1", "00790", 2, _NONE, _NONE),                # anesthesia: recorded only (v2.6)
          ("2024-10-01", "dl1", "J1100", 999, _NONE, _NONE),              # all-nines maximum: recorded only (v2.6)
          ("2024-10-01", "dl1", "A0425", 99, _NONE, _NONE),               # 99 is a real maximum: rule 99
          ("2025-01-01", "dl2", "H2014", 2, _NONE, _NONE)]                # the next version: rule 2
FIX_B2 = [("2024-10-01", "b1", "H0001", "02"), ("2024-10-01", "b1", " h0001", 8.0), ("2024-10-01", "b1", "H0001", "b6"),
          ("2024-10-01", "b1", "H2017", "77"), ("2024-10-01", "b1", "H2017", None),     # blank type: lead
          ("2024-10-01", "b1", "H2019", "8.5"),                                        # not letters / digits: lead
          ("2024-10-01", "b1", "90834", "08"), ("2024-10-01", "b1", "H1000", "08"),     # not H0xxx / H2xxx: no rule
          ("2024-10-01", "b1", "H0038", 2), ("2024-10-01", "b1", "H0031", "77")]        # H0031 never billed


def fix_frames():
    return frames_of(FIX_SD, FIX_DL, FIX_B2)


_r = O._r
NOV5, DEC31, JAN1, FEB28, MAR1 = D(2024, 11, 5), D(2024, 12, 31), D(2025, 1, 1), D(2025, 2, 28), D(2025, 3, 1)
FIX_CLAIMS = [          # O._r: servicing type 08, billing type none, billing provider id 'B1' unless given
    # Same Day, M1 on 5 Nov 2024 (version 1)
    _r("C1", 1, "H0001", member="M1", sprov="P1", dos=NOV5), _r("C2", 1, "H2014", member="M1", sprov="P2", dos=NOV5),
    _r("C3", 1, "H0004", member="M1", sprov="P1", dos=NOV5),
    _r("C4", 1, "H2014", member="M1", sprov="P1", dos=NOV5, pa="PA7"),
    _r("C5", 1, "H0015", member="M1", sprov="P2", dos=NOV5),
    # M2: last day of version 1, first day of version 2, last day of version 2, first day of version 3
    _r("C10", 1, "H0001", member="M2", sprov="P1", dos=DEC31), _r("C10", 2, "H2014", member="M2", sprov="P1", dos=DEC31),
    _r("C11", 1, "H0001", member="M2", sprov="P1", dos=JAN1), _r("C11", 2, "H2014", member="M2", sprov="P1", dos=JAN1),
    _r("C12", 1, "H0015", member="M2", sprov="P1", dos=FEB28), _r("C12", 2, "H2014", member="M2", sprov="P3", dos=FEB28),
    _r("C13", 1, "H0001", member="M2", sprov="P1", dos=MAR1), _r("C13", 2, "H2014", member="M2", sprov=None, dos=MAR1),
    # M3: before the oldest version (not judged), long after the last (open window)
    _r("C20", 1, "H0001", member="M3", dos=D(2024, 9, 30)), _r("C20", 2, "H2014", member="M3", dos=D(2024, 9, 30)),
    _r("C21", 1, "H0001", member="M3", sprov="P1", dos=D(2026, 6, 1)),
    _r("C21", 2, "H2014", member="M3", sprov="P2", dos=D(2026, 6, 1)),
    # M4: no servicing provider on either line (D pairs, A* never); a line never pairs with itself (same claim + line)
    _r("C30", 1, "H2014", member="M4", sprov=None, dos=NOV5), _r("C30", 2, "H0001", member="M4", sprov=None, dos=NOV5),
    _r("C31", 1, "H0001", member="M4", sprov="P1", dos=D(2024, 11, 6)),
    _r("C31", 1, "H2014", member="M4", sprov="P1", dos=D(2024, 11, 6)),
    # (v2.6) M7-M9: the billing provider id of an A* pair - another id, missing on both lines, padded
    _r("C40", 1, "H0001", member="M7", sprov="P1", dos=NOV5),
    _r("C40", 2, "H2014", member="M7", sprov="P1", bprov="B2", dos=NOV5),
    _r("C41", 1, "H0001", member="M8", sprov="P1", bprov=None, dos=NOV5),
    _r("C41", 2, "H2014", member="M8", sprov="P1", bprov="  ", dos=NOV5),
    _r("C42", 1, "H0001", member="M9", sprov="P1", bprov=" B1 ", dos=NOV5),
    _r("C42", 2, "H2014", member="M9", sprov="P1", dos=NOV5),
    # daily limits, M5 (H2014 under the three scopes: another billing id, no billing id)
    _r("D1", 1, "H2014", units="3", paid="30.00", member="M5", sprov="P1", dos=NOV5),
    _r("D1", 2, "H2014", units="2", paid="20.00", member="M5", sprov="P1", dos=NOV5),
    _r("D2", 1, "H2014", units="3", paid="30.00", member="M5", sprov="P2", dos=NOV5),
    _r("D7", 1, "H2014", member="M5", sprov="P1", bprov="B2", dos=NOV5),
    _r("D7", 2, "H2014", member="M5", sprov="P1", bprov=None, dos=NOV5),
    _r("D3", 1, "97110", units="3", paid="30.00", member="M5", sprov="P1", dos=NOV5),
    _r("D3", 2, "97110", units="3", paid="30.00", member="M5", sprov="P1", dos=NOV5),
    _r("D5", 1, "T1019", units="2", paid="20.00", member="M5", sprov="P1", dos=NOV5),
    _r("D5", 2, "T1019", units="1", paid="10.00", member="M5", sprov="P1", dos=NOV5, mods=("59",)),   # modifier
    _r("D6", 1, "H0004", units="2", member="M5", sprov="P1", dos=NOV5),
    _r("D6", 2, "H0004", units="2", member="M5", sprov="P2", dos=NOV5),
    _r("D4", 1, "H2014", units="3", paid="30.00", member="M5", sprov="P1", dos=JAN1, pa="PA1"),
    _r("D12", 1, "A0425", units="5", paid="50.00", member="M5", sprov="P1", dos=NOV5),    # 5 <= 99
    _r("D13", 1, "00790", units="5", paid="50.00", member="M5", sprov="P1", dos=NOV5),    # anesthesia: no rule
    _r("D14", 1, "J1100", units="5", paid="50.00", member="M5", sprov="P1", dos=NOV5),    # 999: no rule
    _r("D15", 1, "S9445", units="9", paid="90.00", member="M5", sprov="P1", dos=NOV5),    # two daily limits: no rule
    # (v2.6) §3 daily-cap labels on H0004 (threshold 3), servicing P3: span / PA beats span / modifier / '25' not listed
    _r("D8", 1, "H0004", units="4", paid="40.00", member="M10", sprov="P3", dos=NOV5),
    _r("D9", 1, "H0004", units="4", paid="40.00", member="M11", sprov="P3", dos=NOV5),
    _r("D9", 2, "H0004", member="M11", sprov="P3", dos=NOV5, pa="PA2", mods=("RT",)),
    _r("D10", 1, "H0004", units="2", paid="20.00", member="M12", sprov="P3", dos=NOV5, mods=(" rt",)),
    _r("D10", 2, "H0004", units="2", paid="20.00", member="M12", sprov="P3", dos=NOV5),
    _r("D11", 1, "H0004", units="2", paid="20.00", member="M13", sprov="P3", dos=NOV5, mods=("25",)),
    _r("D11", 2, "H0004", units="2", paid="20.00", member="M13", sprov="P3", dos=NOV5),
    # (v2.6, N4) the labels read PAYABLE lines only (H0004, threshold 3, P3): M14 a cancelled long line with listed
    # modifiers + its reversal + payable lines over the cap -> units_over_limit (pre-N4: verify_span); M15 an orphan
    # reversal with LT -> units_over_limit (pre-N4: verify_modifier); M16 a payable line with NO units and F1 ->
    # verify_modifier; M17 a paid line with -1 units and E2 (counted, not payable) -> units_over_limit (pre-N4:
    # verify_modifier); M18 a cancelled long line + reversal + a payable line over the cap -> verify_span
    _r("D16", 1, "H0004", units="5", paid="50.00", member="M14", sprov="P3", dos=NOV5, mods=("RT", "XS")),
    _r("R16", 1, "H0004", units="5", paid="-50.00", member="M14", sprov="P3", dos=NOV5, mods=(" rt", "xs ")),
    _r("D16", 2, "H0004", units="3", paid="30.00", member="M14", sprov="P3", dos=NOV5, mods=("GT",)),
    _r("D16", 3, "H0004", units="1", paid="10.00", member="M14", sprov="P3", dos=NOV5),
    _r("D17", 1, "H0004", units="3", paid="30.00", member="M15", sprov="P3", dos=NOV5),
    _r("D17", 2, "H0004", units="1", paid="10.00", member="M15", sprov="P3", dos=NOV5),
    _r("R17", 1, "H0004", units="-0.5", paid="-4.00", member="M15", sprov="P3", dos=NOV5, mods=("LT",)),
    _r("D18", 1, "H0004", units="3", paid="30.00", member="M16", sprov="P3", dos=NOV5),
    _r("D18", 2, "H0004", units="1", paid="10.00", member="M16", sprov="P3", dos=NOV5),
    _r("D18", 3, "H0004", units=None, paid="5.00", member="M16", sprov="P3", dos=NOV5, mods=("F1",)),
    _r("D19", 1, "H0004", units="3", paid="30.00", member="M17", sprov="P3", dos=NOV5),
    _r("D19", 2, "H0004", units="2", paid="20.00", member="M17", sprov="P3", dos=NOV5),
    _r("D19", 3, "H0004", units="-1", paid="5.00", member="M17", sprov="P3", dos=NOV5, mods=("E2",)),
    _r("D20", 1, "H0004", units="6", paid="60.00", member="M18", sprov="P3", dos=NOV5, mods=("59",)),
    _r("R20", 1, "H0004", units="-6", paid="-60.00", member="M18", sprov="P3", dos=NOV5, mods=("59",)),
    _r("D20", 2, "H0004", units="4", paid="40.00", member="M18", sprov="P3", dos=NOV5),
    # B2 matrix, M6 (billing provider types; (v2.6) group lines billed '1' / ' 01 ' / '01.0' / '01')
    _r("B1", 1, "H0001", member="M6", dos=NOV5, btype="2"), _r("B1", 2, "H0001", member="M6", dos=NOV5, btype="03"),
    _r("B1", 3, "H0001", member="M6", dos=NOV5, btype=None), _r("B1", 4, "H0001", member="M6", dos=NOV5, btype="b6"),
    _r("B2", 1, "H2017", member="M6", dos=NOV5, btype="03"), _r("B2", 2, "H2019", member="M6", dos=NOV5, btype="03"),
    _r("B3", 1, "90834", member="M6", dos=NOV5, btype="03"), _r("B3", 2, "H1000", member="M6", dos=NOV5, btype="03"),
    _r("B3", 3, "H0038", member="M6", dos=NOV5, btype="08", pa="PA3"),
    _r("B3", 4, "H0038", member="M6", dos=NOV5, btype=" 2.0"),
    _r("B4", 1, "H0001", member="M6", dos=D(2024, 9, 30), btype="03"),
    _r("B5", 1, "H0001", member="M6", dos=NOV5, btype="1", ptype="08"),          # group, rendering 08 allowed
    _r("B5", 2, "H0001", member="M6", dos=NOV5, btype=" 01 ", ptype="31"),       # group, rendering 31 not allowed
    _r("B5", 3, "H0001", member="M6", dos=NOV5, btype="01.0", ptype=None),       # group, rendering type missing
    _r("B5", 4, "H0001", member="M6", dos=NOV5, btype="01", ptype="NONE"),       # group, textual-null rendering type
    _r("B6", 1, "H0038", member="M6", dos=NOV5, btype="01", ptype="02"),         # group, rendering 02 allowed
]
FIX_CONFIGS = {"msb+billing_or_rendering(default)": (MSB, "billing_or_rendering"),
               "member_provider_day+billing": ("member_provider_day", "billing"),
               "member_day+billing_or_rendering": ("member_day", "billing_or_rendering")}


def fix_expected(S, R):
    """The hand-computed answer for FIX_* (§2b + §2 + §3 v2.6, by hand) with A* and daily scope S and B2 role R:
    {label: (sig, [finding tuples] or None for a lead)}, scoped out, excluded counts. Pair tuple: (claim, line, member,
    dos, severity, evidence, text form); daily: (member, servicing, billing, dos, observed, excess, paid, at risk,
    severity, evidence); B2: (claim, line, member, dos, severity, text form)."""
    v1, v1e, v2, v2e = "2024-10-01", "2024-12-31", "2025-01-01", "2025-02-28"
    VE, VP, VS, VM, UO, PT = ("verify_exception", "verify_pa", "verify_span", "verify_modifier", "units_over_limit",
                              "provider_type_not_allowed")
    BW, PL, OT = "both_ways_text", "plain", ("other",)
    md, msb = S == "member_day", S == MSB
    p2 = [("C4", 1, "M1", NOV5, VP, ("C1:1",), BW), ("C10", 2, "M2", DEC31, VE, ("C10:1",), BW),
          ("C42", 2, "M9", NOV5, VE, ("C42:1",), BW)]
    if not msb:                                    # another billing id / no billing id: pair under servicing alone
        p2 += [("C40", 2, "M7", NOV5, VE, ("C40:1",), BW), ("C41", 2, "M8", NOV5, VE, ("C41:1",), BW)]
    if md:                                         # any provider
        p2 += [("C2", 1, "M1", NOV5, VE, ("C1:1",), BW), ("C30", 1, "M4", NOV5, VE, ("C30:2",), BW)]
    p3 = [("C5", 1, "M1", NOV5, VP, ("C2:1", "C4:1"), PL)] if md else [("C5", 1, "M1", NOV5, VE, ("C2:1",), PL)]

    def P(p):
        return None if md else p

    def B(b):
        return b if msb else None
    d1 = ([("M5", None, None, NOV5, "10", "6", "100.00", "60.00", UO, ("D1:1", "D1:2", "D2:1", "D7:1", "D7:2"))] if md
          else [("M5", "P1", "B1", NOV5, "5", "1", "50.00", "10.00", UO, ("D1:1", "D1:2"))] if msb
          else [("M5", "P1", None, NOV5, "7", "3", "70.00", "30.00", UO, ("D1:1", "D1:2", "D7:1", "D7:2"))])
    d2 = [("M10", P("P3"), B("B1"), NOV5, "4", "1", "40.00", "10.00", VS, ("D8:1",)),
          ("M11", P("P3"), B("B1"), NOV5, "5", "2", "50.00", "20.00", VP, ("D9:1", "D9:2")),
          ("M12", P("P3"), B("B1"), NOV5, "4", "1", "40.00", "10.00", VM, ("D10:1", "D10:2")),
          ("M13", P("P3"), B("B1"), NOV5, "4", "1", "40.00", "10.00", UO, ("D11:1", "D11:2")),
          ("M14", P("P3"), B("B1"), NOV5, "4", "1", "40.00", "10.00", UO, ("D16:1", "D16:2", "D16:3", "R16:1")),
          ("M15", P("P3"), B("B1"), NOV5, "3.5", "0.5", "36.00", "5.14", UO, ("D17:1", "D17:2", "R17:1")),
          ("M16", P("P3"), B("B1"), NOV5, "4", "1", "45.00", "11.25", VM, ("D18:1", "D18:2", "D18:3")),
          ("M17", P("P3"), B("B1"), NOV5, "4", "1", "55.00", "13.75", UO, ("D19:1", "D19:2", "D19:3")),
          ("M18", P("P3"), B("B1"), NOV5, "4", "1", "40.00", "10.00", VS, ("D20:1", "D20:2", "R20:1"))]
    if md:
        d2.append(("M5", None, None, NOV5, "4", "1", "20.00", "5.00", UO, ("D6:1", "D6:2")))
    if R == "billing_or_rendering":
        b1 = [("B1", 2, "M6", NOV5, PT, OT), ("B5", 2, "M6", NOV5, PT, ("group", "31", "01"))]
        b4 = [("B3", 3, "M6", NOV5, VP, OT)]
    else:
        b1 = [("B1", 2, "M6", NOV5, PT, OT)] + [(f"B5", n, "M6", NOV5, PT, OT) for n in (1, 2, 3, 4)]
        b4 = [("B3", 3, "M6", NOV5, VP, OT), ("B6", 1, "M6", NOV5, PT, OT)]
    rules = {
        "P1": (("pair", "H2014", "H0001", "member_day", True, v1, v1e),
               [("C1", 1, "M1", NOV5, VP, ("C2:1", "C4:1"), BW), ("C10", 1, "M2", DEC31, VE, ("C10:2",), BW),
                ("C30", 2, "M4", NOV5, VE, ("C30:1",), BW), ("C40", 1, "M7", NOV5, VE, ("C40:2",), BW),
                ("C41", 1, "M8", NOV5, VE, ("C41:2",), BW), ("C42", 1, "M9", NOV5, VE, ("C42:2",), BW)]),
        "P2": (("pair", "H0001", "H2014", S, True, v1, v1e), p2),
        "P3": (("pair", "H2014", "H0015", S, False, v1, v1e), p3),
        "P4": (("pair", "H0001", "H2014", S, False, v2, v2e), [("C11", 2, "M2", JAN1, VE, ("C11:1",), PL)]),
        "P5": (("pair", "H2014", "H0015", "member_day", False, v2, v2e), [("C12", 1, "M2", FEB28, VE, ("C12:2",), PL)]),
        "P6": (("pair", "H2014", "H0001", "member_day", False, "2025-03-01", None),
               [("C13", 1, "M2", MAR1, VE, ("C13:2",), PL), ("C21", 1, "M3", D(2026, 6, 1), VE, ("C21:2",), PL)]),
        "D1": (("daily", ("H2014",), 4, S, v1, v1e), d1),
        "D2": (("daily", ("H0004",), 3, S, v1, v1e), d2),
        "D3": (("daily", ("T1019",), 2, S, v1, v1e),
               [("M5", P("P1"), B("B1"), NOV5, "3", "1", "30.00", "10.00", VM, ("D5:1", "D5:2"))]),
        "D4": (("daily", ("H2014",), 2, S, v2, None),
               [("M5", P("P1"), B("B1"), JAN1, "3", "1", "30.00", "10.00", VP, ("D4:1",))]),
        "D5": (("daily", ("A0425",), 99, S, v1, v1e), []),
        "B1": (("b2", ("H0001",), ("02", "08", "B6"), R, v1, None), b1),
        "B4": (("b2", ("H0038",), ("02",), R, v1, None), b4),
        "B2L": (("b2", ("H2017",), (None, "77"), R, v1, None), None),       # lead
        "B3L": (("b2", ("H2019",), ("8.5",), R, v1, None), None),           # lead
    }
    scoped_out = {("pair", "H2014", "H0017", "member_day", False, v1, v1e), ("daily", ("G0151",), 3, S, v1, v1e),
                  ("b2", ("H0031",), ("77",), R, v1, None)}
    excluded = {"pair:diagonal": 1, "pair:A": 2, "daily:two_daily_limits": 3, "daily:record_only_code": 1,
                "daily:placeholder_maximum": 1, "b2:code_not_compiled": 2}
    return rules, scoped_out, excluded


def _set_fix_config(monkeypatch, S, R):
    monkeypatch.setattr(config, "AHCCCS_SAME_PROVIDER_SCOPE", S)
    monkeypatch.setattr(config, "AHCCCS_DAILY_LIMIT_SCOPE", S)
    monkeypatch.setattr(config, "AHCCCS_B2_PROVIDER_ROLE", R)


def _tuple_of(x, f):
    kind, p = x["kind"], x["predicate"]
    if kind == "pair":
        return (f["key"][0], f["key"][1], f["key"][2], f["key"][3], f["finding_severity"],
                tuple(O.ev_str(e) for e in f["evidence"]), "both_ways_text" if p.get("both_ways") else "plain")
    if kind == "daily":
        return (f["key"][0], f["servicing_provider"], f["billing_provider"], f["key"][3],
                str(O._num(f["observed_units"])), str(O._num(f["excess_units"])), str(O._q2(f["paid_amt"])),
                str(O._q2(f["paid_at_risk"])), f["finding_severity"], tuple(O.ev_str(e) for e in f["evidence"]))
    form = f["finding_form"]
    return (f["key"][0], f["key"][1], f["key"][2], f["key"][3], f["finding_severity"],
            form[:3] if form[0] == "group" else form)


@pytest.mark.parametrize("label", sorted(FIX_CONFIGS))
def test_oracle_pins_hand_computed_fixed_cases(monkeypatch, label):
    """The oracle itself (no Spark) on FIX_*, against the HAND-computed answer (v2.6): D any provider / A* under the
    configured scope (servicing AND billing id by default: another, missing or padded billing id) / A and the diagonal
    nothing / both-ways cells two both_ways rules (a mirror A: none); indicators and Frequency Cds spelled ' a* ', 'd';
    version windows; two daily limits, anesthesia code, 999 maximum -> no rule, 99 -> a rule; the three daily scopes and
    §3's daily-cap labels (span, PA beats span, modifier RT / ' rt' / 59, '25' not listed; N4: payable lines only - a
    cancelled long line with listed modifiers and its reversal, an orphan reversal and a paid -1-unit line with a listed
    modifier never decide, a payable no-units line with F1 does); B2 types cleaned, a blank
    or '8.5' type -> a lead, a non-H0/H2 code -> no rule, group lines judged on the rendering type under
    billing_or_rendering; never-billed codes -> scoped out; severities and dollars."""
    S, R = FIX_CONFIGS[label]
    _set_fix_config(monkeypatch, S, R)
    rules, scoped_out, excluded = fix_expected(S, R)
    snap = O.build_snapshot(FIX_CLAIMS, cover=False)
    xp = derive_rules(fix_frames(), claims_scope(FIX_CLAIMS))
    assert not xp["refused"], xp["refused"]
    assert Counter(x["sig"] for x in xp["built"]) == Counter(s for s, _ in rules.values()), \
        sorted(map(sig_str, Counter(x["sig"] for x in xp["built"]) ^ Counter(s for s, _ in rules.values())))
    assert {x["sig"] for x in xp["built"] if x["lead"]} == {rules["B2L"][0], rules["B3L"][0]}
    assert {x["sig"] for x in xp["scoped_out"]} == scoped_out
    assert dict(xp["excluded"]) == excluded
    by_code = defaultdict(list)
    for r in snap:
        by_code[r["code"]].append(r)
    for name, (sig, want) in rules.items():
        x = next(x for x in xp["built"] if x["sig"] == sig)
        if want is None:
            assert x["lead"], name
            continue
        got = sorted((_tuple_of(x, f) for f in expected_findings(x, by_code)), key=repr)
        assert got == sorted(want, key=repr), (name, got)
    x = next(x for x in xp["built"] if x["sig"] == rules["P1"][0])
    f = next(f for f in expected_findings(x, by_code) if f["key"][0] == "C1")
    assert (f["pa_present"], f["finding_basis"], f["paid_amt"], f["paid_at_risk"], f["col1"]) == \
        (True, "hard_denial", Decimal("10.00"), Decimal("10.00"), ("C2", 1))


# ===================================================================================== refusals (R-T18)
V1 = "2024-10-01"
REFUSAL_CASES = {   # name: (frames, refused?)
    "same_cell_twice_conflicting_indicators(G1)": (frames_of(sd=[(V1, "s1", "H0001", "H2014", "D"),
                                                                 (V1, "s1", " h0001", "H2014", "A*")]), True),
    "same_cell_twice_same_indicator(G2)": (frames_of(sd=[(V1, "s1", "H0001", "H2014", "D"),
                                                         (V1, "s1", "h0001 ", "h2014", " d ")]), True),
    "same_daily_code_twice_other_maximum(G3)": (frames_of(dl=[(V1, "d1", "H2014", 4, _NONE, _NONE),
                                                              (V1, "d1", "h2014 ", 2, _NONE, _NONE)]), True),
    "same_daily_code_twice_same_maximum": (frames_of(dl=[(V1, "d1", "H2014", 4, _NONE, _NONE),
                                                         (V1, "d1", " H2014", 4, _NONE, _NONE)]), True),
    "blank_same_day_row_code(G7)": (frames_of(sd=[(V1, "s1", "  ", "H2014", "D")]), True),
    "missing_same_day_column_code": (frames_of(sd=[(V1, "s1", "H0001", None, "D")]), True),
    "blank_daily_code": (frames_of(dl=[(V1, "d1", " ", 4, _NONE, _NONE)]), True),
    "missing_b2_code": (frames_of(b2=[(V1, "b1", None, "02"), (V1, "b1", "H0001", "02")]), True),
    "blank_b2_code": (frames_of(b2=[(V1, "b1", "H0001", "02"), (V1, "b1", "  ", "08")]), True),
    "blank_maximum(G5)": (frames_of(dl=[(V1, "d1", "H2014", None, _NONE, _NONE)]), True),
    "zero_maximum": (frames_of(dl=[(V1, "d1", "H2014", 0, _NONE, _NONE)]), True),
    "negative_maximum": (frames_of(dl=[(V1, "d1", "H2014", -2, _NONE, _NONE)]), True),
    "indicator_X": (frames_of(sd=[(V1, "s1", "H0001", "H2014", "X")]), True),
    "indicator_blank": (frames_of(sd=[(V1, "s1", "H0001", "H2014", " ")]), True),
    "two_files_for_one_version": (frames_of(sd=[(V1, "s1", "H0001", "H2014", "D"),
                                                (V1, "s2", "H0004", "H2014", "D")]), True),
    "refusal_in_one_table_stops_the_call": (frames_of(sd=[(V1, "s1", "H0001", "H2014", "D")],
                                                      dl=[(V1, "d1", "H2014", 0, _NONE, _NONE)],
                                                      b2=[(V1, "b1", "H0001", "02")]), True),
    # controls: NOT refused
    "same_cell_in_two_versions": (frames_of(sd=[(V1, "s1", "H0001", "H2014", "D"),
                                                ("2025-01-01", "s2", "h0001", "H2014", "D")]), False),
    "both_ways_pair_is_not_a_duplicate": (frames_of(sd=[(V1, "s1", "H0001", "H2014", "D"),
                                                        (V1, "s1", "H2014", "H0001", "D")]), False),
    "indicator_and_frequency_cd_spelled_lower_or_padded": (frames_of(
        sd=[(V1, "s1", "H0001", "H2014", " d "), (V1, "s1", "H2014", "H0001", "a*"), (V1, "s1", "H0004", "H2014", "a")],
        dl=[(V1, "d1", "H2014", 4, (3, 1, " d"), _NONE), (V1, "d1", "T1019", 2, (2, 1, "w "), _NONE)]), False),
    "b2_code_on_several_rows(merged ranges)": (frames_of(b2=[(V1, "b1", "H0001", "02"), (V1, "b1", " h0001", "08"),
                                                             (V1, "b1", "H0001", "02")]), False),
    "diagonal_cell": (frames_of(sd=[(V1, "s1", "H2014", " h2014", "D")]), False),
    "blank_limit_value_with_D/1(G4)": (frames_of(dl=[(V1, "d1", "H2014", 4, (None, 1, "D"), _NONE)]), False),
    "anesthesia_and_placeholder_rows": (frames_of(dl=[(V1, "d1", "00790", 2, _NONE, _NONE),
                                                      (V1, "d1", "J1100", 999999, _NONE, _NONE)]), False),
}


def _production_refuses(frames, pre_normalise):
    """(refused?, which stage, message) for the production path - rules_from_frames on the raw frames, or after
    normalise_frame (the frames_for_build path, where either call may refuse)."""
    import ahcccs_tables
    stage = "normalise_frame"
    try:
        if pre_normalise:
            frames = {k: ahcccs_tables.normalise_frame(k, df.copy()) for k, df in frames.items()}
        stage = "rules_from_frames"
        ahcccs_tables.rules_from_frames(frames, None, {})
    except ValueError as e:
        return True, stage, str(e)[:240]
    return False, None, None


@pytest.mark.parametrize("pre_normalise", [False, True])
@pytest.mark.parametrize("name", sorted(REFUSAL_CASES))
def test_frame_level_refusals(name, pre_normalise):
    """§2b (v2.6) 'Refused, never guessed' (R-T18): every frame the spec refuses raises ValueError (raw frames into
    rules_from_frames, or through normalise_frame first) and the oracle derives nothing; the controls build rules."""
    frames, refused = REFUSAL_CASES[name]
    assert bool(refusals(frames)) == refused, (name, refusals(frames))
    got, stage, msg = _production_refuses(frames, pre_normalise)
    REFUSAL_LOG.append({"case": name, "pre_normalise": pre_normalise, "oracle_refuses": refused, "production_refuses": got,
                        "stage": stage, "message": msg})
    if got != refused:
        MISMATCHES.append({"phase": f"refusal:{name}:{'normalised' if pre_normalise else 'raw'}", "type": "refusal",
                           "key": name, "oracle": refused, "sql": got if not got else (stage, msg)})
    assert got == refused, (name, stage, msg)


def test_extra_frame_column_is_ignored():
    """G9, STATED v2.6 §6 ('A column added by hand to a loaded table in the catalog is ignored ... 07's load check
    compares the rows of the known columns'): frames with an extra column - holding content or not - build exactly the
    rules the oracle derives from the known columns, on the raw and on the normalise_frame path."""
    import ahcccs_tables
    base = dict(sd=[(V1, "s1", "H0001", "H2014", "D"), (V1, "s1", "H2014", "H0001", "A*")],
                dl=[(V1, "d1", "H2014", 4, _NONE, _NONE)], b2=[(V1, "b1", "H0001", "02"), (V1, "b1", "H0001", "08")])
    want = Counter(x["sig"] for x in derive_rules(frames_of(**base), None)["built"])
    out, bad = {}, []
    for content in ("note", None):
        frames = frames_of(**base, extra_cols=("unexpected_col",))
        for df in frames.values():
            df["unexpected_col"] = content
        for path in ("raw", "normalised"):
            tag = f"{path}:content={content!r}"
            try:
                fr = frames if path == "raw" else {k: ahcccs_tables.normalise_frame(k, df.copy())
                                                    for k, df in frames.items()}
                got = Counter(rule_sig(r.to_dict()) for r in ahcccs_tables.rules_from_frames(fr, None, {}))
            except Exception as e:                       # noqa: BLE001 - reported below
                out[tag] = f"{type(e).__name__}: {str(e)[:160]}"
                bad.append((tag, out[tag]))
                continue
            out[tag] = f"accepted ({sum(got.values())} rules)" + ("" if got == want else " - RULES DIFFER")
            if got != want:
                bad.append((tag, sorted(map(sig_str, got - want)), sorted(map(sig_str, want - got))))
    PROBES["G9_extra_frame_column"] = out
    if bad:
        MISMATCHES.append({"phase": "G9:extra_frame_column", "type": "frame", "key": repr(bad)[:1500]})
    assert not bad, bad


# ===================================================================================== pytest: Spark comparisons
N_ROUNDS = int(os.environ.get("PIE_TBL_ORACLE_ROUNDS", "8"))
N_SETS = int(os.environ.get("PIE_TBL_ORACLE_SETS", "4"))
VARIANT_REPEATS = int(os.environ.get("PIE_TBL_ORACLE_VARIANT_REPEATS", "1"))
T_PATTERN = r"^(H[02][0-9]{3}|T10(16|19)|S9484)$"
VARIANTS = {
    "same_provider_scope_member_provider_day": {"config": {"AHCCCS_SAME_PROVIDER_SCOPE": "member_provider_day"}},
    "same_provider_scope_member_day": {"config": {"AHCCCS_SAME_PROVIDER_SCOPE": "member_day"}},
    "daily_scope_member_provider_day": {"config": {"AHCCCS_DAILY_LIMIT_SCOPE": "member_provider_day"}},
    "daily_scope_member_day": {"config": {"AHCCCS_DAILY_LIMIT_SCOPE": "member_day"}},
    "b2_role_billing": {"config": {"AHCCCS_B2_PROVIDER_ROLE": "billing"}},
    "group_types_1_and_c2": {"config": {"GROUP_BILLING_PROVIDER_TYPES": ("1", " c2 ")}},
    "record_only_patterns_wider": {"config": {"AHCCCS_DAILY_RECORD_ONLY_CODES": r"^(0[01][0-9]{3}|97110|T1019)$",
                                              "AHCCCS_DAILY_PLACEHOLDER_MAX": r"^9{2,}$"}},
    "record_only_patterns_none": {"config": {"AHCCCS_DAILY_RECORD_ONLY_CODES": r"^$",
                                             "AHCCCS_DAILY_PLACEHOLDER_MAX": r"^$"}},
    "b2_pattern_with_T_and_S_codes": {"config": {"AHCCCS_B2_COMPILE_CODES": T_PATTERN}},
    # S-T1: H2019 matches under re.search only; T1016 / T1019 under re.search and re.match, not re.fullmatch
    "b2_pattern_unanchored_probe": {"config": {"AHCCCS_B2_COMPILE_CODES": r"H00[0-9]{2}|T10|1[69]$"},
                                    "force_b2": ("H2019", "T1016", "T1019")},
    "claims_scope_none": {"config": {}, "scope_none": True},
    "all_member_provider_day_billing_T_pattern_normalised": {
        "config": {"AHCCCS_SAME_PROVIDER_SCOPE": "member_provider_day", "AHCCCS_DAILY_LIMIT_SCOPE": "member_provider_day",
                   "AHCCCS_B2_PROVIDER_ROLE": "billing", "AHCCCS_B2_COMPILE_CODES": T_PATTERN}, "pre_normalise": True},
}


def _fmt(mism, n=12):
    lines = [f"{len(mism)} mismatch(es) between the SQL / rule derivation and the oracle (first {min(n, len(mism))}):"]
    for x in mism[:n]:
        if x.get("type") == "field":
            lines.append(f"  {x['phase']} {x['key']} field {x['field']}: oracle={x['oracle']!r} sql={x['sql']!r}")
        else:
            lines.append(f"  {x['phase']} {x.get('type')} {x.get('key')}: oracle={x.get('oracle')!r} "
                         f"sql={x.get('sql')!r}")
    return "\n".join(lines)


def _report():
    rep = {"stats": dict(STATS), "table_coverage": dict(sorted(TCOVER.items())),
           "case_coverage": {k: len(v) for k, v in sorted(O.COVER_SETS.items())},
           "row_coverage": dict(sorted(O.COVER.items())), "readings": ORACLE_READINGS,
           "spec_gaps_observed": SPEC_GAPS_OBSERVED, "rounds": ROUND_LOG, "refusals": REFUSAL_LOG, "probes": PROBES,
           "schema_notes": {" | ".join(k): v for k, v in SCHEMA_NOTES.items()},
           "mismatch_count": len(MISMATCHES),
           "mismatches": [{k: (v if isinstance(v, (str, int, float, bool, type(None))) else repr(v)) for k, v in x.items()}
                          for x in MISMATCHES[:500]]}
    path = os.environ.get("PIE_TBL_ORACLE_REPORT")
    if path:
        with open(path, "w") as fh:
            json.dump(rep, fh, indent=1, default=str)
    print("\n[pie table oracle] " + json.dumps({"stats": rep["stats"], "mismatches": len(MISMATCHES)}, default=str))


@pytest.fixture(scope="module")
def spark():
    try:
        from pyspark.sql import SparkSession  # noqa: F401
    except Exception:
        pytest.skip("pyspark (pyspark.sql) not available")
    if not (shutil.which("java") or os.environ.get("JAVA_HOME")):
        pytest.skip("no Java runtime for Spark")
    saved = (dg.CLAIMS, dg.DETECT, dg.PTP_EDITS_TABLE, dg.MUE_LIMITS_TABLE, config.TABLE_FORMAT)
    warehouse = tempfile.mkdtemp(prefix="pie_tbl_oracle_", dir=os.environ.get("PIE_TBL_ORACLE_TMP") or None)
    O.COVER.clear()
    O.COVER_SETS.clear()
    session = None
    try:
        O.point_detector_gen_at_test_tables()
        session = make_spark(warehouse)
        session.sparkContext.setLogLevel("ERROR")
        O.setup_schemas(session)
        yield session
    finally:
        if session is not None:
            session.stop()
        dg.CLAIMS, dg.DETECT, dg.PTP_EDITS_TABLE, dg.MUE_LIMITS_TABLE, config.TABLE_FORMAT = saved
        shutil.rmtree(warehouse, ignore_errors=True)
        if session is not None:
            _report()


def _run_fixed(spark, frames, claims, scope):
    """Production on fixed frames + claims: {sig: findings rows} from the per-rule SQL and from the batches, plus the
    production rules."""
    O.write_claims(spark, claims)
    with contextlib.redirect_stdout(io.StringIO()):
        dg.create_snapshot(spark, source=dg.CLAIMS, target=dg.DETECT, fmt="parquet")
    pr = production_rules(frames, scope, False)
    sig_of = {r["rule_id"]: rule_sig(r) for r in pr["accepted"]}
    per_rule = defaultdict(list)
    for d in pr["dets_p"]:
        if d.get("compiled") and d.get("sql"):
            per_rule[sig_of[d["rule_id"]]] += run_sql(spark, d["sql"])
    batched = {d["rule_id"] for d in pr["dets_b"] if d.get("compiled") and d.get("batch")}
    batch = defaultdict(list)
    for b, df in zip(dg.TABLE_BATCHES, dg.ahcccs_edit_tables([r for r in pr["accepted"] if r["rule_id"] in batched])):
        write_edit_table(spark, df, EDIT_FQN[b])
        for row in run_sql(spark, dg.TABLE_BATCH_SQL[b](table=EDIT_FQN[b], build_id=None)):
            batch[sig_of.get(row["rule_id"])].append(row)
    return pr, per_rule, batch


def _sql_tuple(sig, row):
    kind = sig[0]
    ev = tuple(O.parse_evidence(row.get("evidence_lines")) or ())
    if kind == "pair":
        return (row["claim_id"], row["line_no"], row["member_id"], row["dos"], row["finding_severity"], ev,
                pair_text_form(row.get("finding"), sig[1], sig[2]))
    if kind == "daily":
        return (row["member_id"], row.get("servicing_provider"), row.get("billing_provider"), row["dos"],
                str(O._num(row["observed_units"])), str(O._num(row["excess_units"])), str(O._q2(row["paid_amt"])),
                str(O._q2(row["paid_at_risk"])), row["finding_severity"], ev)
    form = O.finding_form(row.get("finding"), list(sig[1]))
    if form[0] == "group" and (form[3] != frozenset(t for t in sig[2] if t) or not form[4]):
        form = ("group_text_list_or_code_WRONG", row.get("finding"))
    return (row["claim_id"], row["line_no"], row["member_id"], row["dos"], row["finding_severity"],
            form[:3] if form[0] == "group" else form)


@pytest.mark.parametrize("label", sorted(FIX_CONFIGS))
def test_fixed_cases_through_spark_match_the_hand_computed_answer(spark, monkeypatch, label):
    """FIX_* through production (rules_from_frames -> gate -> normalise -> per-rule SQL and the three batches) against
    the HAND-computed answer (not the oracle): rules (with both_ways), leads, and every finding of every rule in both
    paths, incl. the both-ways text, the billing_provider column and the group text."""
    S, R = FIX_CONFIGS[label]
    _set_fix_config(monkeypatch, S, R)
    rules, scoped_out, _ = fix_expected(S, R)
    pr, per_rule, batch = _run_fixed(spark, fix_frames(), FIX_CLAIMS, claims_scope(FIX_CLAIMS))
    problems = []
    got_sigs = Counter(rule_sig(r) for r in pr["built"])
    want_sigs = Counter(s for s, _ in rules.values())
    if got_sigs != want_sigs:
        problems.append(("rules", {"missing": [sig_str(s) for s in want_sigs - got_sigs],
                                   "unexpected": [sig_str(s) for s in got_sigs - want_sigs]}))
    by_id = {r["rule_id"]: rule_sig(r) for r in pr["accepted"]}
    leads = {by_id[d["rule_id"]] for d in pr["dets_b"] if not d.get("compiled")}
    if leads != {rules["B2L"][0], rules["B3L"][0]}:
        problems.append(("leads", sorted(map(sig_str, leads))))
    for name, (sig, want) in rules.items():
        if want is None:
            continue
        for path, got_rows in (("per_rule", per_rule.get(sig, [])), ("batch", batch.get(sig, []))):
            got = sorted((_sql_tuple(sig, r) for r in got_rows), key=repr)
            if got != sorted(want, key=repr):
                problems.append((name, path, {"want": sorted(want, key=repr), "got": got}))
    stray = [sig_str(s) if s else s for s in set(per_rule) | set(batch) if s not in {s_ for s_, _ in rules.values()}]
    if stray:
        problems.append(("findings of unexpected rules", stray))
    MISMATCHES.extend({"phase": f"fixed:{label}", "type": "fixed_case", "key": repr(p)[:2000]} for p in problems)
    assert not problems, problems


@pytest.mark.parametrize("rnd", range(N_ROUNDS))
def test_random_rounds_match_oracle(spark, rnd):
    """One seeded round (default config): rules, the three batch statements (and their build filter), every table
    rule's own SQL and the batch-vs-per-rule equality, all against the oracle."""
    data = build_round(rnd, N_SETS)
    mism = run_round(spark, data, f"r{rnd}")
    MISMATCHES.extend(dict(x, round=rnd) for x in mism)
    assert not mism, _fmt(mism)


@pytest.mark.parametrize("rep", range(VARIANT_REPEATS))
@pytest.mark.parametrize("variant", sorted(VARIANTS))
def test_variant_rounds_match_oracle(spark, monkeypatch, variant, rep):
    """§2b switches (rules_from_frames reads them at call time, so does the oracle): the A* scope, the daily scope, the
    B2 role, the group billing types, the record-only patterns, the B2 compile pattern; no claims scope."""
    spec = VARIANTS[variant]
    for k, v in spec["config"].items():
        monkeypatch.setattr(config, k, v)
    rnd = 700 + sorted(VARIANTS).index(variant) + 100 * rep
    data = build_round(rnd, N_SETS, scope_none=spec.get("scope_none", False), pre_normalise=spec.get("pre_normalise"),
                       force_b2=spec.get("force_b2", ()))
    mism = run_round(spark, data, f"{variant}#{rep}")
    STATS[f"rounds:{variant}"] += 1
    MISMATCHES.extend(dict(x, round=f"{variant}#{rep}") for x in mism)
    assert not mism, _fmt(mism)


def test_statements_run_on_empty_edit_tables(spark):
    """07 always writes the three edit tables, empty when a table built nothing (every rule scoped out here): each
    statement must run and find nothing."""
    O.write_claims(spark, [_r("C1", 1, "H2014", units="5", member="M1", dos=NOV5)])
    with contextlib.redirect_stdout(io.StringIO()):
        dg.create_snapshot(spark, source=dg.CLAIMS, target=dg.DETECT, fmt="parquet")
    pr = production_rules(fix_frames(), {"ZZZZZ"}, False)
    assert pr["built"] == []
    edits = dg.ahcccs_edit_tables([])
    for b, df in zip(dg.TABLE_BATCHES, edits):
        assert len(df) == 0
        write_edit_table(spark, df, EDIT_FQN[b])
        assert run_sql(spark, dg.TABLE_BATCH_SQL[b](table=EDIT_FQN[b], build_id=None)) == []
        assert run_sql(spark, dg.TABLE_BATCH_SQL[b](table=EDIT_FQN[b], build_id=BUILD_ID)) == []
