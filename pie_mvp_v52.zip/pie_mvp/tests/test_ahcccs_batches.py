"""AHCCCS rule tables - the QUERY LAYER (v5.2, 2026-10-04). Offline: grammar, ids, edit tables, build_detectors, the
07 / 08 notebook source, the query-pack scenarios and its judge. The SQL itself runs on Spark 4 in
tests/test_sql_spark.py (per-rule scope semantics; each batch statement multiset-equal to the per-rule SQL of the same
rules on random claims; edge cases).

Why these tests exist (2026-10-04 (v5.2)): SB decided that the three AHCCCS rule tables (Same Day Disallow, HCPCS/CPT
daily limits, B2 matrix) compile as STATE rules with origin "ahcccs_table" (ahcccs_tables.py, implementer T1). Thousands
of cells cannot be thousands of per-rule claims self-joins, so - like NCCI - the rules are written as data (three edit
tables) and checked by one statement each. The risks pinned here: a table rule treated as NCCI (no PA, routed by edit
file), collapsed into or dropped against an extracted rule, an existing rule's SQL changed by the new daily scope, an
edit row for a rule that does not compile, and a notebook that runs the table batches through the NCCI routing gate.
Run: cd pie_mvp && python -m pytest tests/test_ahcccs_batches.py -q
"""
import ast
import os
import sys

import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, PKG)

import config  # noqa: E402
import detector_gen as dg  # noqa: E402
import kb_io  # noqa: E402
import query_pack as qp  # noqa: E402
import rule_normalize as rn  # noqa: E402
import schema  # noqa: E402
import validate_gate as vg  # noqa: E402
from schema import Rule  # noqa: E402

NOTE2 = ("Exceptions to limitations on service frequency or duration may be approved based on medical necessity.")
SCOPE = {"D": "member_day", "A*": "member_provider_day"}


def tbl(pred, eff="2026-10-01", end=None, locator="sheet '1012026 Effective Date' cell D7", **kw):
    """A rule as ahcccs_tables.rules_from_frames builds it (contract v5.2)."""
    codes = schema.predicate_codes(pred)
    return Rule(origin="ahcccs_table", plane="coding_edit", binding_status="state_policy",
                statement=f"AHCCCS table {pred['type']} {codes} {eff}", source_doc="AHCCCS Same Day Disallow Table (10/1/2026)",
                source_locator=locator, source_url="https://www.azahcccs.gov/x.xlsx", doc_version=eff or "",
                doc_hash="f" * 64, predicate=pred, codes=codes, effective_date=eff, end_date=end,
                **kw).assign_id().to_dict()


def sdd(col, row, ind="D", **kw):
    return tbl({"type": "code_pair_prohibited", "code_a": col, "code_b": row, "modifier_indicator": "0",
                "scope": SCOPE[ind], "exception": NOTE2, "service_category": "state_bh"}, **kw)


def dl(code, n, scope="member_provider_day", **kw):
    return tbl({"type": "max_units_per_day", "code": code, "threshold": n, "scope": scope}, **kw)


def b2(code, types, role="billing", **kw):
    return tbl({"type": "provider_type_allowed", "code_set": [code], "provider_types": sorted(types),
                "provider_role": role}, **kw)


def ext(pred, **kw):
    codes = schema.predicate_codes(pred)
    return Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy", statement=f"s {codes}",
                source_doc="Ch10", source_locator="p", predicate=pred, codes=codes, **kw).assign_id().to_dict()


def ncci(pred):
    return Rule(origin="ncci", plane="coding_edit", binding_status="mandatory", statement="n", source_doc="CMS",
                source_locator="x", predicate=pred, codes=schema.predicate_codes(pred),
                effective_date="2010-01-01").assign_id().to_dict()


# ======================================================== grammar and ids
def test_max_units_per_day_takes_an_optional_scope_from_pair_scopes():
    base = {"type": "max_units_per_day", "code": "H2014", "threshold": 4}
    for s in (None, "", "member_day", "member_provider_day"):
        p = dict(base) if s is None else dict(base, scope=s)
        assert schema.validate_predicate(p) == (True, ""), s
    for s in ("provider", "MEMBER_DAY", "member_provider", "any"):
        ok, why = schema.validate_predicate(dict(base, scope=s))
        assert not ok and "scope must be one of" in why, s
    # the gate turns a bad scope into a lead with the reason - never a guess at what was meant
    acc, _ = vg.gate([Rule.from_dict(dl("H2014", 4, scope="per_provider"))])
    assert not acc[0]["machine_checkable"] and "scope must be one of" in acc[0]["gate_notes"]


def test_table_rules_get_the_TBL_prefix_and_every_other_prefix_is_unchanged():
    def rid(origin):
        return schema.stable_rule_id({"origin": origin, "source_doc": "S", "source_locator": "L", "statement": "x",
                                      "predicate": {"type": "code_not_covered", "code": "11975"},
                                      "effective_date": None, "end_date": None})
    # pinned on 2026-10-04 before the change: only the prefix of an ahcccs_table id moves (MAN- -> TBL-)
    assert rid("ncci") == "NCCI-e5bef0ecc487988e"
    assert rid("extracted") == "EXT-4a45389427bbe490"
    assert rid("manual") == "MAN-0548980b3d92fd1e"
    assert rid(None) == "MAN-4b525290031e82e2"
    assert rid("ahcccs_table") == "TBL-89c35a77e3ed6f3b"
    r = sdd("H0017", "H2014")
    assert r["rule_id"].startswith("TBL-") and rn.rule_id_for(r) == r["rule_id"]      # normalisation keeps it


# ======================================================== existing SQL is byte-identical
GOLDEN = {   # sha256 of each statement with the table names replaced by placeholders, taken BEFORE v5.2 (2026-10-04)
    "daily_code": "58d8e1589f0e407c7f3f41483a8a0f4cb1c3f2c80cc361a77a710a13a2244193",
    "daily_set": "82bcb3d455919d0527d02a019e85a4c1de6d55f79ecb15a757cf869198503ee3",
    "dos": "f1eab4dea4534d41cbcdbb33465a88b3416d8f0343608d8533cf4d12aa2b567c",
    "pair_md": "f3d9d40f8e8b966049cc69211fcee35a91bc7d973262a94d17227fd56d8c7bf6",
    "pair_mpd": "adfe1e5c0939678782c9dd8b6559b73de8e59fd12d99f6145f374dcb978e9245",
    "ptype": "2e91df87577a4426442a47a4da2e03f0f30adf55e92e52c7207c4c2051b69cfa",
    "period": "b7314351ae8df7c9c6dce9b49a3f2c0a0964748863e7eb0341934e32ae1b4fae",
    "period_signal": "396add9b93531ba258dd76a020ed8da4ac69a2b8a6dc2b5a9005ec514a4f1083",
    "nc": "0c4969ed8a4610523fc72cdc7605514caad9187eebbed4ea9e7a3c09aa76d4ae",
    "ncci_pair": "d415ce0fc5c6838898ab0b6bcab8061aa6497213b16edd04b6b84d2f3ad396d8",
    "ncci_mue": "4a025b275b5e43578d14ed0c09ae2cb3f3f76ca0720710cb7b8c752018cb486d",
    "batch_ptp": "5e29f6e63276deb9d684c205a4c4830b987848ca826917a60d504cdfc3df0cc8",
    "batch_mue": "675673110d9a871b26eeb13b22aab7f76512b1b27fe835ca16466918fbf5ba1e",
    "snapshot": "ff12088ccd721fbc30477fa017faa7c44aec7970006fac213c4d2ccc27664db3",
}
# 2026-10-04 (QUERY_SEMANTICS v2.6 §3, B3): the daily caps of STATE rules (max_units_per_day, max_units_per_dos) gained
# the labels verify_span / verify_modifier - their severity CASE is the ONLY text that changed (checked line by line
# against the pre-fix snapshot: one line became four). Their sql_sha256 moved, so a v06 signature of such a query is
# void until the validator signs the new text. Every other statement above is still byte-identical.
V26_CHANGED = {
    # 2026-10-05 (critic re-check N4): the span / modifier labels read the group's PAYABLE lines only
    "daily_code": "6c5828ff7e8667a31b41740164f5fe12c5955e0e058db1f99ab756558f432287",
    "daily_set": "e03ea83a8192d4e824bb37b9ae0a655a8ea5acf78417e663624c65418b6af323",
    "dos": "20ee2d66f4433ced02846b7d24d773d2c7068d81601670aa0c83f0034a2ad72d",
}


def _h(sql):
    s = (sql.replace(dg.DETECT, "<DETECT>").replace(dg.PTP_EDITS_TABLE, "<PTP>").replace(dg.MUE_LIMITS_TABLE, "<MUE>")
         .replace(dg.CLAIMS, "<CLAIMS>"))
    return dg.sql_sha256(s)


def _golden_rules():
    def st(pred, eff=None):
        codes = [pred[k] for k in ("code_a", "code_b", "code") if pred.get(k)] + list(pred.get("code_set") or [])
        return Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy", statement=f"s {codes}",
                    source_doc="Ch10", source_locator="p", predicate=pred, codes=codes,
                    effective_date=eff).assign_id().to_dict()

    def nc(pred):
        return Rule(origin="ncci", plane="coding_edit", binding_status="mandatory", statement="n", source_doc="CMS",
                    source_locator="x", predicate=pred, codes=[], effective_date="2010-01-01").assign_id().to_dict()
    return {
        "daily_code": st({"type": "max_units_per_day", "code": "A0422", "threshold": 1, "exception": "unless x"}),
        "daily_set": st({"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4},
                        eff="2024-01-01"),
        "dos": st({"type": "max_units_per_dos", "code": "97110", "threshold": 2}),
        "pair_md": st({"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2017", "modifier_indicator": "0",
                       "scope": "member_day", "discretionary": True}),
        "pair_mpd": st({"type": "code_pair_prohibited", "code_a": "S9484", "code_b": "S9485", "modifier_indicator": "1"}),
        "ptype": st({"type": "provider_type_allowed", "code_set": ["H0035"], "provider_types": ["B2", "02"]}),
        "period": st({"type": "max_units_per_period", "code": "T1021", "threshold": 10, "period": "benefit_year"}),
        "nc": st({"type": "code_not_covered", "code": "11975"}),
        "ncci_pair": nc({"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222", "modifier_indicator": "0",
                         "ncci_edition": "practitioner", "service_category": "practitioner"}),
        "ncci_mue": nc({"type": "max_units_per_line", "code": "J3490", "threshold": 1, "ncci_edition": "practitioner",
                        "service_category": "practitioner", "later_max_threshold": None, "removed_later": False}),
    }


def test_every_existing_statement_is_byte_identical_after_v52():
    """2026-10-04 (v5.2): a changed SQL text changes its sql_sha256, which voids every validator signature (v06) bound
    to it. The new daily scope and the table batches must not move one byte of today's queries. (v2.6: except the
    severity CASE of the state daily caps, V26_CHANGED - spec §3.)"""
    got = {}
    for k, r in _golden_rules().items():
        d = dg.build_detectors([r], batch_ncci=False, batch_tables=True)[0]   # batch_tables never touches them
        assert d["compiled"] and d["batch"] is None, (k, d["reason"])
        got[k] = _h(d["sql"])
        if d.get("signal_sql"):
            got[k + "_signal"] = _h(d["signal_sql"])
    got["batch_ptp"] = _h(dg.batch_ptp_sql(build_id="B1"))
    got["batch_mue"] = _h(dg.batch_mue_sql(build_id="B1"))
    got["snapshot"] = _h(dg.snapshot_select_sql())
    assert {k: v for k, v in got.items() if k not in V26_CHANGED} == \
        {k: v for k, v in GOLDEN.items() if k not in V26_CHANGED}
    assert {k: got[k] for k in V26_CHANGED} == V26_CHANGED and set(got) == set(GOLDEN)
    assert all(V26_CHANGED[k] != GOLDEN[k] for k in V26_CHANGED)


def test_daily_scope_default_and_member_day_compile_the_same_sql_per_provider_groups_by_provider():
    r0 = ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4})
    rmd = ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4, "scope": "member_day"})
    rmpd = ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4, "scope": "member_provider_day"})
    s0, smd, smpd = (dg.compile_units_per_day(r)[0] for r in (r0, rmd, rmpd))
    assert s0 == smd == dg._compile_units_per_day(r0, group_provider=False)[0]
    assert smpd == dg._compile_units_per_day(r0, group_provider=True)[0]
    P, M, DOS = dg.COL["provider"], dg.COL["member"], dg.COL["dos"]
    assert f"GROUP BY a.{M}, a.{P}, a.{DOS}" in smpd and f"a.{P} IS NOT NULL" in smpd
    assert f"a.{P} AS servicing_provider" in smpd and "servicing_provider" not in s0
    assert dg.daily_scope(r0) == dg.daily_scope(rmd) == "member_day" and dg.daily_scope(rmpd) == "member_provider_day"
    # the detector row and the pack say which scope a daily cap has
    assert "servicing provider" in (dg.build_detectors([rmpd])[0]["conditions"] or "")
    assert dg.build_detectors([r0])[0]["conditions"] is None


# ======================================================== batch kinds and build_detectors
def test_table_batch_kind_per_predicate_and_only_for_table_rules():
    assert dg.TABLE_ORIGIN == "ahcccs_table"
    assert (dg.BATCH_AHCCCS_PAIR, dg.BATCH_AHCCCS_DAILY, dg.BATCH_AHCCCS_PTYPE) == \
        ("ahcccs_same_day", "ahcccs_daily_max", "ahcccs_provider_type")
    assert dg.TABLE_BATCHES == (dg.BATCH_AHCCCS_PAIR, dg.BATCH_AHCCCS_DAILY, dg.BATCH_AHCCCS_PTYPE)
    assert dg.table_batch_kind(sdd("H0017", "H2014")) == "ahcccs_same_day"
    assert dg.table_batch_kind(dl("H2014", 4)) == "ahcccs_daily_max"
    assert dg.table_batch_kind(b2("H0017", ["B2"])) == "ahcccs_provider_type"
    assert dg.table_batch_kind(tbl({"type": "code_not_covered", "code": "H0017"})) is None
    aged = dl("H2014", 4)
    aged["predicate"]["age"] = {"min": 21}
    assert dg.table_batch_kind(aged) is None                 # the batches carry no age condition: runs per rule
    for other in (ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4}),
                  ncci({"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222", "modifier_indicator": "0",
                        "ncci_edition": "practitioner"})):
        assert dg.table_batch_kind(other) is None
    assert dg.batch_kind(sdd("H0017", "H2014")) is None     # never an NCCI batch
    assert {dg.TABLE_BATCH_PREDICATE[k] for k in dg.TABLE_BATCHES} == \
        {"code_pair_prohibited", "max_units_per_day", "provider_type_allowed"}
    assert dg.TABLE_BATCH_EDIT_TABLE == {"ahcccs_same_day": "policy_ahcccs_pair_edits",
                                         "ahcccs_daily_max": "policy_ahcccs_daily_limits",
                                         "ahcccs_provider_type": "policy_ahcccs_provider_types"}
    assert dg.AHCCCS_PAIR_EDITS_TABLE == f"{dg.KB}.policy_ahcccs_pair_edits"
    assert dg.AHCCCS_DAILY_LIMITS_TABLE == f"{dg.KB}.policy_ahcccs_daily_limits"
    assert dg.AHCCCS_PTYPE_TABLE == f"{dg.KB}.policy_ahcccs_provider_types"


def test_build_detectors_batches_table_rules_only_when_asked():
    rules = [sdd("H0017", "H2014"), dl("H2014", 4), b2("H0017", ["B2", "77"]),
             ext({"type": "max_units_per_day", "code": "A0422", "threshold": 1}),
             ncci({"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222", "modifier_indicator": "0",
                   "ncci_edition": "practitioner"})]
    on = dg.build_detectors(rules, batch_ncci=True, batch_tables=True)
    assert [d["batch"] for d in on] == ["ahcccs_same_day", "ahcccs_daily_max", "ahcccs_provider_type", None, "ncci_ptp"]
    for d in on[:3]:
        assert d["compiled"] and d["sql"] is None and d["sql_sha256"] is None and d["origin"] == "ahcccs_table"
        assert d["routing"] == "all_forms"                     # a state rule: no NCCI edit file
    assert on[0]["finding_severity"] == "verify_exception" and on[0]["pair_scope"] == "member_day"
    assert on[3]["sql"] and on[3]["batch"] is None            # an extracted rule always runs per rule
    off = dg.build_detectors(rules, batch_ncci=True)          # batch_tables defaults to False
    assert [d["batch"] for d in off] == [None, None, None, None, "ncci_ptp"]
    assert all(d["compiled"] and d["sql"] and d["sql_sha256"] == dg.sql_sha256(d["sql"]) for d in off[:4])
    only_tables = dg.build_detectors(rules, batch_tables=True)
    assert only_tables[4]["batch"] is None and only_tables[4]["sql"]     # NCCI batching is its own switch
    s = dg.summarize(on)
    assert s["batched"] == 4 and s["by_batch"] == {"ahcccs_same_day": 1, "ahcccs_daily_max": 1,
                                                   "ahcccs_provider_type": 1, "ncci_ptp": 1}


def test_a_table_rule_the_batch_cannot_express_or_that_does_not_compile_is_never_batched():
    aged = dl("H2014", 4)
    aged["predicate"]["age"] = {"min": 21}
    bad_code = sdd("H0017", "H2014")
    bad_code["predicate"]["code_b"] = "H2014;--"
    inverted = dl("T1019", 3, eff="2026-10-01", end="2026-09-01")
    off = dict(b2("H0017", ["B2"]), deactivated=True)
    dets = dg.build_detectors([aged, bad_code, inverted, off], batch_tables=True)
    assert dets[0]["compiled"] and dets[0]["batch"] is None and dets[0]["sql"]       # per rule, still exact
    assert all(not d["compiled"] and d["batch"] is None for d in dets[1:])
    pairs, daily, ptypes = dg.ahcccs_edit_tables([aged, bad_code, inverted, off])
    assert len(pairs) == len(daily) == len(ptypes) == 0


# ======================================================== edit tables
def _nn(d):
    """pandas 3 string columns hold a missing value as NaN; the edit tables are written with it as NULL (kb_io)."""
    return {k: (None if not isinstance(v, (list, dict)) and pd.isna(v) else v) for k, v in d.items()}


def test_edit_tables_columns_rows_and_labels():
    pd_, md_ = sdd("H0017", "H2014", "D", eff="2026-10-01"), sdd("S5151", "T1019", "A*", eff=None, end="2026-09-30")
    soft = tbl({"type": "code_pair_prohibited", "code_a": "S5151", "code_b": "H0004", "modifier_indicator": "1",
                "scope": "member_provider_day", "discretionary": True})
    d1 = dl("H2014", 4)
    dset = tbl({"type": "max_units_per_day", "code_set": ["h0004", "H0005", "H0004 "], "threshold": 5,
                "scope": "member_day", "exception": NOTE2})
    t1 = b2("H0017", [" 2", "b2", "77"])
    t2 = tbl({"type": "provider_type_allowed", "code_set": ["H0004", "H0005"], "provider_types": ["B5"],
              "provider_role": "servicing"})
    rules = [pd_, md_, soft, d1, dset, t1, t2, ext({"type": "max_units_per_day", "code": "A0422", "threshold": 1}), pd_]
    pairs, daily, ptypes = dg.ahcccs_edit_tables(rules)
    assert list(pairs.columns) == dg.AHCCCS_PAIR_EDIT_COLUMNS == [
        "rule_id", "code_a", "code_b", "pair_scope", "modifier_indicator", "effective_date", "end_date", "finding",
        "finding_severity", "finding_basis", "both_ways"]                                  # v2.6: + both_ways (B4)
    assert list(daily.columns) == dg.AHCCCS_DAILY_LIMIT_COLUMNS == [
        "rule_id", "code", "threshold", "daily_scope", "effective_date", "end_date", "finding", "finding_severity",
        "finding_basis"]
    assert list(ptypes.columns) == dg.AHCCCS_PTYPE_COLUMNS == [
        "rule_id", "code", "provider_role", "allowed_types", "effective_date", "end_date", "finding_prefix",
        "finding_suffix", "finding_severity", "finding_basis", "rendered_prefix"]      # v2.6: + rendered_prefix (B2)
    # pairs: one row per rule (the duplicate rule dict is written once); the table's own scope; labels as compiled
    p = pairs.set_index("rule_id")
    assert len(pairs) == 3
    assert _nn(p.loc[pd_["rule_id"]].to_dict()) == {
        "code_a": "H0017", "code_b": "H2014", "pair_scope": "member_day", "modifier_indicator": "0",
        "effective_date": "2026-10-01", "end_date": None, "finding": "H2014 billed with H0017",
        "finding_severity": "verify_exception", "finding_basis": "hard_denial", "both_ways": False}
    assert p.loc[md_["rule_id"], "pair_scope"] == "member_provider_day" and p.loc[md_["rule_id"], "end_date"] == "2026-09-30"
    assert pd.isna(p.loc[md_["rule_id"], "effective_date"])
    assert tuple(p.loc[soft["rule_id"], ["modifier_indicator", "finding_severity", "finding_basis"]]) == \
        ("1", "discretionary", "unbypassed_pair")
    # daily: a code set is one row per DISTINCT code (a line must never join one rule twice); the finding text is the
    # per-rule SQL's text exactly
    d = daily[daily["rule_id"] == dset["rule_id"]]
    assert sorted(d["code"]) == ["H0004", "H0005"] and set(d["threshold"]) == {5}
    assert set(d["finding"]) == {"H0004/H0005/H0004 units per day > 5"} and set(d["daily_scope"]) == {"member_day"}
    assert set(d["finding_severity"]) == {"verify_exception"} and set(d["finding_basis"]) == {"units_over_limit"}
    one = daily[daily["rule_id"] == d1["rule_id"]].iloc[0]
    assert (one["code"], int(one["threshold"]), one["daily_scope"], one["finding"], one["finding_severity"]) == \
        ("H2014", 4, "member_provider_day", "H2014 units per day > 4", "units_over_limit")
    assert str(daily["threshold"].dtype) == "Int64"
    # provider types: cleaned and sorted exactly like the per-rule SQL's list; prefix + type + suffix = its finding text
    a = ptypes[ptypes["rule_id"] == t1["rule_id"]].iloc[0]
    assert (a["code"], a["provider_role"], a["allowed_types"]) == ("H0017", "billing", "02/77/B2")
    assert a["finding_prefix"] + "77" + a["finding_suffix"] == "H0017 billed by provider type 77 (allowed: 02/77/B2)"
    assert (a["finding_severity"], a["finding_basis"]) == ("provider_type_not_allowed", "provider_type_not_allowed")
    b = ptypes[ptypes["rule_id"] == t2["rule_id"]]
    assert sorted(b["code"]) == ["H0004", "H0005"] and set(b["provider_role"]) == {"servicing"}
    assert set(b["finding_prefix"]) == {"H0004/H0005 billed by provider type "}


def test_edit_tables_are_empty_frames_with_fixed_columns_when_nothing_compiles():
    pairs, daily, ptypes = dg.ahcccs_edit_tables([])
    assert (len(pairs), len(daily), len(ptypes)) == (0, 0, 0)
    assert list(pairs.columns) == dg.AHCCCS_PAIR_EDIT_COLUMNS and list(ptypes.columns) == dg.AHCCCS_PTYPE_COLUMNS
    assert list(daily.columns) == dg.AHCCCS_DAILY_LIMIT_COLUMNS and str(daily["threshold"].dtype) == "Int64"


# ======================================================== batch statements (text)
def test_batch_statements_read_their_own_table_and_build_and_are_state_rules():
    sqls = {"pair": dg.batch_ahcccs_pair_sql(build_id="B9"), "daily": dg.batch_ahcccs_daily_sql(build_id="B9"),
            "ptype": dg.batch_ahcccs_ptype_sql(build_id="B9")}
    for k, t in (("pair", dg.AHCCCS_PAIR_EDITS_TABLE), ("daily", dg.AHCCCS_DAILY_LIMITS_TABLE),
                 ("ptype", dg.AHCCCS_PTYPE_TABLE)):
        s = sqls[k]
        assert f"FROM {t} WHERE build_id = 'B9'" in s, k                # C4-01: only its own build's rows
        assert dg.DETECT in s and "BROADCAST(e)" in s, k
        assert dg.PIE_EDITION + " =" not in s and "IN (SELECT DISTINCT ncci_edition" not in s, k   # never routed
        assert f"{dg.COL['pa_no']} IS NOT NULL" in s and dg.VERIFY_PA in s, k                       # PA evaluated
        assert "e.rule_id AS rule_id" in s, k
    assert "WHERE build_id" not in dg.batch_ahcccs_daily_sql()
    assert "FROM x.y WHERE build_id = 'B1'" in dg.batch_ahcccs_ptype_sql("x.y", build_id="B1")
    assert "e.pair_scope = 'member_day'" in sqls["pair"] and "e.pair_scope = 'member_provider_day'" in sqls["pair"]
    assert "CAST(e.threshold AS INT)" in sqls["daily"] and dg.PIE_PAYABLE in sqls["daily"]
    assert f"a.{dg.COL['paid']} <> 0" in sqls["daily"]                  # counted rows: a $0 line adds nothing
    assert dg.PIE_BPROV_TYPE in sqls["ptype"] and dg.PIE_PROV_TYPE in sqls["ptype"]


def test_without_a_pa_column_the_batches_do_not_evaluate_pa(monkeypatch):
    """As the per-rule SQL: no PA column -> pa_present NULL ('not evaluated'), never 0 ('no PA on file')."""
    monkeypatch.setitem(dg.COL, "pa_no", None)
    pair, daily, ptype = (dg.batch_ahcccs_pair_sql(build_id="B"), dg.batch_ahcccs_daily_sql(build_id="B"),
                          dg.batch_ahcccs_ptype_sql(build_id="B"))
    assert "CAST(NULL AS INT) AS pa_flag" in pair            # the rollup's MAX(NULL) -> NULL -> the edit row's label
    for s in (daily, ptype):
        assert "CAST(NULL AS INT) AS pa_present" in s and dg.VERIFY_PA not in s
    for s in (pair, daily, ptype):
        assert "None" not in s


# ======================================================== normalisation: never collapsed into an extracted rule
def test_why_07_normalises_table_rules_on_their_own():
    """rule_normalize.collapse_state_duplicates keeps an extracted rule over any other origin with the same predicate,
    codes, population and window - fed together, a table rule identical to an extracted one would be DROPPED. 07
    normalises the table rules separately (2026-10-04 (v5.2): the table is its own authority; policy_ahcccs_conflicts
    reports agreements and disagreements instead)."""
    t = dl("H2014", 4)
    e = Rule.from_dict(t)
    e.origin, e.statement, e.source_doc = "extracted", "Ch19: H2014 at most 4 units per day", "Ch19"
    e = e.assign_id().to_dict()
    together, _ = rn.normalize_rules([t, e])
    assert [r["origin"] for r in together] == ["extracted"]            # the hazard
    # what 07 does: its own normalisation block, run from the notebook's source text
    src = _nb("07_build_kb.py")
    start = src.index("tbl_accepted = [r for r in accepted if r.get(\"origin\") == TABLE_ORIGIN]")
    end = src.index("accepted = accepted + tbl_accepted", start) + len("accepted = accepted + tbl_accepted")
    g = {"rule_normalize": rn, "json": __import__("json"), "TABLE_ORIGIN": dg.TABLE_ORIGIN, "accepted": [t, e]}
    exec(compile(src[start:end], "07_build_kb.py:normalise", "exec"), g)
    kept = g["accepted"]
    assert sorted(r["origin"] for r in kept) == ["ahcccs_table", "extracted"], [r["origin"] for r in kept]
    assert [r["rule_id"] for r in kept if r["origin"] == "ahcccs_table"] == [t["rule_id"]]
    assert g["tbl_norm_report"]["rules_out"] == 1 and g["norm_report"]["rules_out"] == 1


# ======================================================== notebooks 07 and 08 (source)
def _nb(name):
    return open(os.path.join(PKG, "notebooks", name)).read()


def _dict_keys(src, var):
    for node in ast.parse(src).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) \
                and node.targets[0].id == var and isinstance(node.value, ast.Dict):
            return {k.value for k in node.value.keys if isinstance(k, ast.Constant)}
    raise AssertionError(f"{var} = {{...}} not found")


def test_07_builds_the_table_rules_through_the_gate_and_writes_three_batches():
    src = _nb("07_build_kb.py")
    compile(src, "07_build_kb.py", "exec")
    assert src.startswith("# Databricks notebook source\n# MAGIC %md") and "\n# COMMAND ----------\n" in src
    import re
    assert re.search(r"^import .*\bahcccs_tables\b", src, re.M)                       # imported and reloaded
    assert "ahcccs_tables" in src.split("for m in (")[1].split("importlib.reload(m)")[0]
    # frames from the UC tables, the signed-readings gate PER TABLE, then the rules (scoped to the claims like NCCI)
    assert "ahcccs_tables.frames_for_build(spark)" in src
    assert "ahcccs_tables.table_compiles(key)" in src and "ahcccs_tables.unsigned_readings(key)" in src
    assert "ahcccs_tables.rules_from_frames(" in src and "scope_codes, AHCCCS_REPORT)" in src
    # the same gate, normalisation and compiler; batched, never per-rule SQL
    assert "rules = ncci_rules + st_rules + table_rules" in src
    assert "build_detectors(accepted, batch_ncci=True, batch_tables=True)" in src
    assert '"state_table"' in src and 'jurisdiction="federal" if r.get("origin") == "ncci" else "state"' in src
    assert "detector_gen.ahcccs_edit_tables(" in src and "detector_gen.TABLE_BATCH_SQL" in src
    assert "ahcccs_tables.table_conflicts(" in src and '"policy_ahcccs_conflicts"' in src
    # three more batch rows, always written (rules = 0 when nothing compiled); every edit table carries the build_id
    assert '"rules": int(df_["rule_id"].nunique())' in src and '"edits_sha256": frame_sha256(df_.drop(columns=["build_id"]))' in src
    # history first (when KEEP_NCCI_EDIT_HISTORY), current next, the build log last
    i_hist = src.index('write(df_, f"{name}_history", mode="append")')
    i_cur = src.index("write(df_, name)")
    i_log = src.index('write([build_meta], "policy_build_log", mode="append")')
    assert i_hist < i_cur < i_log
    assert src.rindex('getattr(config, "KEEP_NCCI_EDIT_HISTORY", True)', 0, i_hist) > src.index("write(accepted,   \"policy_rules_history\"")
    keys = _dict_keys(src, "build_meta")
    assert {"ahcccs_table_rules", "ahcccs_batch_statements", "ahcccs_tables", "ahcccs_rules_by_batch",
            "ahcccs_held_back_unsigned", "ahcccs_edit_rows", "ahcccs_edits_sha256", "ahcccs_conflict_rows",
            "ahcccs_normalize"} <= keys
    assert {"ncci_batch_statements", "ptp_edit_rows", "state_rules"} <= keys          # NCCI fields kept as they were


def test_07_without_loaded_tables_builds_exactly_as_before():
    """A missing table is skipped and said so; with none loaded rules_from_frames is not even called with a table, the
    three batch rows are still written with rules = 0, and the state-rule count does not include table rules."""
    src = _nb("07_build_kb.py")
    assert "if f is not None and len(f)" in src                         # missing / empty table -> not loaded
    assert "not loaded" in src
    assert "if _compiling else []" in src
    assert 'sum(r["origin"] not in ("ncci", TABLE_ORIGIN) for r in accepted)' in src
    assert "pd.DataFrame(columns=AHCCCS_CONFLICT_COLUMNS)" in src


def test_08_runs_the_table_batches_as_state_rules_and_keeps_ncci_as_it_was():
    src = _nb("08_run_detectors.py")
    compile(src, "08_run_detectors.py", "exec")
    assert "RUN_AHCCCS_TABLES     = True" in src
    # the NCCI loop sees only the NCCI statements, still gated, still staged for the Column One check
    assert 'for b in ncci_batches.to_dict("records"):' in src
    assert '"skipped": run_guard.skip_reason(qst) or NCCI_GATE}' in src
    sec = src.split("## 3b. AHCCCS rule tables")[1].split("## 4. State")[0]
    assert 'for b in table_batches.to_dict("records"):' in sec
    assert '"skipped": run_guard.skip_reason(qst)}' in sec and "NCCI_GATE" not in sec.split("# COMMAND")[1]
    assert "STAGE" not in sec.split("# COMMAND")[1]                         # never relabelled by the Column One check
    assert '"origin": detector_gen.TABLE_ORIGIN' in sec and "ncci_routing" not in sec.split("# COMMAND")[1]
    assert "append(normalise(spark.sql(b[\"sql\"])" in sec and 'hits_by_rule(f"batch = \'{b[\'batch\']}\'")' in sec
    # the build check covers the three edit tables and hashes their statements (run_guard: every batch row passed)
    assert "detector_gen.TABLE_BATCH_EDIT_TABLE.values()" in src
    assert "run_guard.build_problems(det, batches if (RUN_NCCI_BATCH or RUN_AHCCCS_TABLES) else None" in src
    assert "bool(RUN_NCCI_BATCH and NCCI_GATE and len(ncci_batches))" in src and "(not RUN_AHCCCS_TABLES)" in src


def test_run_guard_hashes_and_validates_the_table_batch_rows():
    """No change to run_guard was needed: it hashes and validates EVERY batch row it is given (08 passes them all)."""
    import run_guard
    det = pd.DataFrame([{"rule_id": "R1", "compiled": True, "sql": None, "sql_sha256": None, "batch": "ahcccs_same_day",
                         "build_id": "B1"}])
    good = dg.batch_ahcccs_pair_sql(build_id="B1")
    batches = pd.DataFrame([{"batch": "ahcccs_same_day", "sql": good, "sql_sha256": dg.sql_sha256(good), "rules": 1,
                             "build_id": "B1"}])
    log = pd.DataFrame([{"build_id": "B1", "status": "complete"}])
    assert run_guard.build_problems(det, batches, {}, log, "B1") == []
    bad = batches.assign(sql=good + " ")
    assert any("BATCH:ahcccs_same_day" in p for p in run_guard.build_problems(det, bad, {}, log, "B1"))
    assert run_guard.current_hashes(det, batches) == {"BATCH:ahcccs_same_day": dg.sql_sha256(good)}


# ======================================================== query pack: scenarios and the judge
def _sids(scs):
    return {s["sid"]: s for s in scs}


def test_pack_scenarios_for_same_day_disallow_d_and_a_star():
    d = _sids(qp.scenarios(sdd("H0017", "H2014", "D"), "TP000"))
    assert d["F1"]["expect"] == 1 and d["F1"]["severity"] == "verify_exception"       # note 2: never a plain violation
    assert d["F2"]["expect"] == 1 and "N4" not in d                                  # D: any provider
    assert d["F4"]["severity"] == d["F7"]["severity"] == "verify_pa"                  # PA on either line
    assert d["W1"]["expect"] == 0 and d["F3"]["expect"] == 1                          # day before; 59 never bypasses
    a = _sids(qp.scenarios(sdd("S5151", "T1019", "A*", eff="2025-10-01", end="2026-09-30"), "TP001"))
    assert a["N4"]["expect"] == 0 and "F2" not in a                                   # A*: not by another provider
    assert a["W1"]["expect"] == 0 and a["W2"]["expect"] == 0                          # the version's window, both ends
    assert {x["member"] for x in a.values()} == {f"TP001_{k}" for k in a}


def test_pack_scenarios_for_daily_limits_per_provider_and_across_providers():
    mpd = _sids(qp.scenarios(dl("H2014", 4), "TD000"))
    assert mpd["N6"]["expect"] == 0 and mpd["N7"]["expect"] == 0 and "F2" not in mpd  # per provider; no provider
    assert mpd["N5"]["expect"] == 0 and mpd["F4"]["severity"] == "verify_pa"          # $0 line; PA label
    md = _sids(qp.scenarios(dl("T1019", 3, scope="member_day"), "TD001"))
    assert md["F2"]["expect"] == 1 and "N6" not in md and "N7" not in md              # summed across providers
    assert "servicing provider" in qp.what_it_does(dl("H2014", 4))
    assert "per member per date" in qp.what_it_does(dl("T1019", 3, scope="member_day"))


def test_pack_scenarios_for_b2_provider_types():
    t = _sids(qp.scenarios(b2("H0017", ["B2", "77"]), "TT000"))
    assert t["F1"]["expect"] == 1 and t["N1"]["expect"] == 0 and t["N3"]["expect"] == 0   # not / allowed / missing
    assert t["F4"]["severity"] == "verify_pa"


class _Row(dict):
    def asDict(self):
        return dict(self)


class _Res:
    def __init__(self, rows):
        self.rows = rows

    def collect(self):
        return [_Row(r) for r in self.rows]


class _FakeSpark:
    def __init__(self, answer):
        self.answer, self.seen = answer, []

    def sql(self, text):
        self.seen.append(text)
        return _Res(self.answer(text))


@pytest.fixture
def offline(monkeypatch):
    written = []
    monkeypatch.setattr(qp, "_write_claims", lambda spark, df, fmt: None)
    monkeypatch.setattr(kb_io, "write_table", lambda spark, df, t, mode="overwrite", **k: written.append(t) or len(df))
    return written


def _table_pack(spark, sample):
    rows = [{"batch": k, "sql": dg.TABLE_BATCH_SQL[k](build_id="BX"), "sql_sha256": "h"} for k in dg.TABLE_BATCHES]
    return qp.build_pack(spark, [], [], rows, fmt="parquet", build_id="BX", table_sample=sample)


SAMPLE = [sdd("H0017", "H2014", "D"), sdd("S5151", "T1019", "A*"), dl("H2014", 4), dl("T1019", 3, scope="member_day"),
          b2("H0017", ["B2", "77"])]


def _right_answer(sample):
    """What a correct statement returns for the pack's scenarios of a table sample (v2.6: with the finding text where a
    scenario checks it, and the cross-rule both-ways scenario - qp.table_scenarios)."""
    rows = []
    for k in dg.TABLE_BATCHES:
        for sc in qp.table_scenarios(k, [r for r in sample if dg.table_batch_kind(r) == k]):
            texts = sc.get("findings") or [None] * sc["expect"]
            rows += [{"member_id": sc["member"], "finding_severity": sc["severity"], "rule_id": sc["rule_id"],
                      "finding": t} for t in texts[:sc["expect"]]]
    return rows


def test_pack_tests_each_table_batch_on_sampled_rules_and_fails_a_wrong_query(offline):
    right = _right_answer(SAMPLE)
    spark = _FakeSpark(lambda text: right)
    q, s = _table_pack(spark, SAMPLE)
    assert set(q["query_id"]) == {f"BATCH:{k}" for k in dg.TABLE_BATCHES}
    assert s["pass"].all() and set(q["auto_test"]) == {"PASS"}, s[~s["pass"]].to_string()
    assert set(q["origin"]) == {"ahcccs_table"} and set(q["query_kind"]) == {"AHCCCS table batch (finding query)"}
    assert q.set_index("query_id").loc["BATCH:ahcccs_same_day", "rules_tested"] == 2
    assert all("version" in x for x in q["dates_covered"])
    # the stored SQL ran with ONLY its table names pointed at the scratch tables
    assert all(qp._qv("claims_snapshot") in t and dg.DETECT not in t for t in spark.seen)
    assert any(qp._qv("ahcccs_pair_edits") in t for t in spark.seen)
    assert {qp._qv("ahcccs_pair_edits"), qp._qv("ahcccs_daily_limits"), qp._qv("ahcccs_provider_types")} <= set(offline)
    assert set(qp.SCRATCH_TABLES) >= {"claims_raw", "claims_snapshot", "ptp_edits", "mue_limits", "ahcccs_pair_edits",
                                      "ahcccs_daily_limits", "ahcccs_provider_types"}
    # a query that also flags a must-NOT case (another provider, a reversed line) fails; one that finds nothing fails
    for wrong in (lambda text: right + [dict(x, member_id=x["member_id"].rsplit("_", 1)[0] + "_N4") for x in right],
                  lambda text: []):
        q2, s2 = _table_pack(_FakeSpark(wrong), SAMPLE)
        assert "FAIL" in set(q2["auto_test"]) and not s2["pass"].all()


def test_pack_without_a_table_sample_writes_no_table_scratch_tables(offline):
    """v06 on a build with no table rules (every workspace until the tables are loaded and signed) must not create new
    scratch tables: the e2e checks that the validation exports write nothing they do not drop."""
    rows = [{"batch": k, "sql": dg.TABLE_BATCH_SQL[k](build_id="BX")} for k in dg.TABLE_BATCHES]
    q, s = qp.build_pack(_FakeSpark(lambda t: []), [], [], rows, fmt="parquet", build_id="BX")
    assert q.empty and not any("ahcccs" in t for t in offline)


def test_sample_tables_is_stratified_and_reproducible():
    rules = ([sdd(f"H00{10 + i}", "H2014", "D" if i % 2 else "A*", end=None if i % 3 else "2026-09-30") for i in range(9)]
             + [dl(f"H20{10 + i}", 4, scope="member_day" if i % 2 else "member_provider_day") for i in range(7)]
             + [b2(f"H00{30 + i}", ["B2"], role="servicing" if i == 0 else "billing") for i in range(5)]
             + [ext({"type": "max_units_per_day", "code": "A0422", "threshold": 1})])
    s1, s2 = qp.sample_tables(rules, 4, 2, 2, seed=7), qp.sample_tables(rules, 4, 2, 2, seed=7)
    assert [r["rule_id"] for r in s1] == [r["rule_id"] for r in s2]
    kinds = [dg.table_batch_kind(r) for r in s1]
    assert kinds.count("ahcccs_same_day") == 4 and kinds.count("ahcccs_daily_max") == 2
    assert kinds.count("ahcccs_provider_type") == 2 and None not in kinds
    pairs = [r for r in s1 if dg.table_batch_kind(r) == "ahcccs_same_day"]
    assert {dg.pair_scope(r) for r in pairs} == {"member_day", "member_provider_day"}
    assert {dg.daily_scope(r) for r in s1 if dg.table_batch_kind(r) == "ahcccs_daily_max"} == \
        {"member_day", "member_provider_day"}


def test_scratch_sql_swaps_the_three_table_names_only():
    s = qp.scratch_sql(dg.batch_ahcccs_pair_sql(build_id="B7") + dg.batch_ahcccs_daily_sql(build_id="B7")
                       + dg.batch_ahcccs_ptype_sql(build_id="B7"), "B7")
    for t in (dg.AHCCCS_PAIR_EDITS_TABLE, dg.AHCCCS_DAILY_LIMITS_TABLE, dg.AHCCCS_PTYPE_TABLE, dg.DETECT):
        assert t not in s
    assert s.count(f"WHERE build_id = '{qp.QV_BUILD}'") == 3 and "B7" not in s


# ======================================================== v2.6 (2026-10-04, after the independent critic of v5.2)
# QUERY_SEMANTICS v2.6: scope member_servicing_billing_day (B1, F5), provider role billing_or_rendering (B2, F1), the
# daily-cap labels verify_span / verify_modifier (B3, F3 / F15), pairs disallowed both ways (B4, F4).
MSBD = "member_servicing_billing_day"
_P, _BP, _M, _DOS = dg.COL["provider"], dg.COL["billing"], dg.COL["member"], dg.COL["dos"]


def _pair(scope, **extra):
    return tbl(dict({"type": "code_pair_prohibited", "code_a": "H0017", "code_b": "H2014", "modifier_indicator": "0",
                     "scope": scope, "exception": NOTE2, "service_category": "state_bh"}, **extra))


def test_v26_b1_pair_scope_member_servicing_billing_day_joins_both_provider_ids():
    """Spec §2 Code pair (v2.6): the same servicing provider AND the same billing provider id (a missing id never
    matches - an equi-join on NULL is never true). member_provider_day and member_day keep their SQL; NCCI ignores it."""
    r = _pair(MSBD)
    assert schema.validate_predicate(r["predicate"]) == (True, "") and dg.pair_scope(r) == MSBD
    sql = dg.compile_code_pair(r)[0]
    assert f"a.{_P} = b.{_P}" in sql and f"a.{_BP} = b.{_BP}" in sql and f"'{MSBD}' AS pair_scope" in sql
    mpd, md = dg.compile_code_pair(_pair("member_provider_day"))[0], dg.compile_code_pair(_pair("member_day"))[0]
    assert f"a.{_P} = b.{_P}" in mpd and _BP not in mpd and _P not in md.split("FROM")[1].split("WHERE")[0]
    d = dg.build_detectors([r], batch_tables=False)[0]
    assert d["compiled"] and d["pair_scope"] == MSBD
    n = ncci({"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222", "modifier_indicator": "0",
              "ncci_edition": "practitioner", "scope": MSBD})
    assert dg.pair_scope(n) == "member_provider_day" and _BP not in dg.build_detectors([n])[0]["sql"]


def test_v26_b1_daily_cap_scope_member_servicing_billing_day_groups_by_both_ids():
    """Spec §2 Units per day (v2.6): per member, servicing provider, billing provider and date; a row missing either id
    is not counted; the finding's servicing provider is the group's."""
    r = dl("H2014", 4, scope=MSBD)
    assert dg.daily_scope(r) == MSBD
    s = dg.compile_units_per_day(r)[0]
    assert f"GROUP BY a.{_M}, a.{_P}, a.{_BP}, a.{_DOS}" in s
    assert f"a.{_P} IS NOT NULL" in s and f"a.{_BP} IS NOT NULL" in s and f"a.{_P} AS servicing_provider" in s
    s_mpd = dg.compile_units_per_day(dl("H2014", 4, scope="member_provider_day"))[0]
    assert f"GROUP BY a.{_M}, a.{_P}, a.{_DOS}" in s_mpd and _BP not in s_mpd
    assert "billing provider" in (dg.build_detectors([r])[0]["conditions"] or "")


def test_v26_b1_the_new_scope_needs_the_billing_provider_column(monkeypatch):
    """No billing provider id in config.CLAIM_COLS: the scope cannot be judged - the rule is a lead saying why (never SQL
    that silently matches nothing), and the batch statements leave the scope out (no edit row can carry it)."""
    monkeypatch.setitem(dg.COL, "billing", None)
    for r in (_pair(MSBD), dl("H2014", 4, scope=MSBD)):
        d = dg.build_detectors([r], batch_tables=True)[0]
        assert not d["compiled"] and "billing_provider" in d["reason"], d["reason"]
        assert sum(len(x) for x in dg.ahcccs_edit_tables([r])) == 0
    pair, daily = dg.batch_ahcccs_pair_sql(build_id="B"), dg.batch_ahcccs_daily_sql(build_id="B")
    assert f"'{MSBD}'" not in pair and "None" not in pair and "None" not in daily
    assert f"e.daily_scope <> '{MSBD}'" in daily


def test_v26_b1_batch_statements_carry_the_new_scope():
    pair = dg.batch_ahcccs_pair_sql(build_id="B9")
    assert f"e.pair_scope = '{MSBD}'" in pair and f"da.{_BP} = db.{_BP}" in pair and f"a.{_BP} = k.{_BP}" in pair
    assert "e.pair_scope = 'member_day'" in pair and "e.pair_scope = 'member_provider_day'" in pair
    daily = dg.batch_ahcccs_daily_sql(build_id="B9")
    assert f"'{MSBD}'" in daily and f"a.{_BP} IS NOT NULL" in daily
    assert f"CASE WHEN e.daily_scope = '{MSBD}' THEN a.{_BP} END" in daily


def test_v26_b2_billing_or_rendering_judges_a_group_line_on_its_rendering_type(monkeypatch):
    """Spec §2 Provider type allowed (v2.6): provider_role billing_or_rendering = the billing type, except a group
    billing type (config.GROUP_BILLING_PROVIDER_TYPES, cleaned as §1) -> the servicing (rendering) type is judged; the
    finding says which type was judged. billing / servicing keep their SQL byte for byte (GOLDEN 'ptype')."""
    r = b2("H0004", ["03", "77"], role="billing_or_rendering")
    sql = dg.compile_provider_type_allowed(r)[0]
    grp = f"a.{dg.PIE_BPROV_TYPE} IN ('01')"
    judged = f"CASE WHEN {grp} THEN a.{dg.PIE_PROV_TYPE} ELSE a.{dg.PIE_BPROV_TYPE} END"
    assert f"{judged} IS NOT NULL AND {judged} NOT IN ('03','77')" in sql
    assert (f"CASE WHEN {grp} THEN CONCAT('H0004 rendered by provider type ', a.{dg.PIE_PROV_TYPE}, ' for a group (', "
            f"a.{dg.PIE_BPROV_TYPE}, ') (allowed: 03/77)')") in sql
    assert f"ELSE CONCAT('H0004 billed by provider type ', a.{dg.PIE_BPROV_TYPE}, ' (allowed: 03/77)') END" in sql
    for role, col in (("billing", dg.PIE_BPROV_TYPE), ("servicing", dg.PIE_PROV_TYPE)):
        s = dg.compile_provider_type_allowed(b2("H0004", ["03", "77"], role=role))[0]
        assert "rendered by" not in s and "IN ('01')" not in s and f"a.{col} IS NOT NULL AND a.{col} NOT IN" in s
    # the group list is the config value cleaned like the claims column ('1' / ' 01 ' / 'c2 ' -> '01' / 'C2'), distinct
    monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", (" 1", "c2 ", "01"))
    assert f"a.{dg.PIE_BPROV_TYPE} IN ('01','C2')" in dg.compile_provider_type_allowed(r)[0]
    # no group type configured: every line is judged on its billing type (no 'IN ()')
    monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", ())
    s = dg.compile_provider_type_allowed(r)[0]
    assert "IN ()" not in s and "CASE WHEN FALSE THEN" in s
    # a value that is not a provider type code: the rule is a lead saying why - never SQL built from it
    monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", ("01'; --",))
    d = dg.build_detectors([r])[0]
    assert not d["compiled"] and "GROUP_BILLING_PROVIDER_TYPES" in d["reason"], d["reason"]


def test_v26_b2_edit_table_and_batch_statement_for_billing_or_rendering():
    r, old = b2("H0004", ["77", " 3"], role="billing_or_rendering"), b2("H0017", ["B2"])
    pairs, daily, ptypes = dg.ahcccs_edit_tables([r, old])
    assert list(ptypes.columns) == dg.AHCCCS_PTYPE_COLUMNS and "rendered_prefix" in dg.AHCCCS_PTYPE_COLUMNS
    row = ptypes.set_index("rule_id").loc[r["rule_id"]]
    assert (row["provider_role"], row["allowed_types"]) == ("billing_or_rendering", "03/77")
    assert row["finding_prefix"] == "H0004 billed by provider type "
    assert row["rendered_prefix"] == "H0004 rendered by provider type " and row["finding_suffix"] == " (allowed: 03/77)"
    assert pd.isna(ptypes.set_index("rule_id").loc[old["rule_id"], "rendered_prefix"])   # only where the role uses it
    s = dg.batch_ahcccs_ptype_sql(build_id="B9")
    grp = f"a.{dg.PIE_BPROV_TYPE} IN ('01')"
    assert f"WHEN e.provider_role = 'billing_or_rendering' AND {grp} THEN a.{dg.PIE_PROV_TYPE}" in s
    assert (f"CONCAT(e.rendered_prefix, a.{dg.PIE_PROV_TYPE}, ' for a group (', a.{dg.PIE_BPROV_TYPE}, ')', "
            f"e.finding_suffix)") in s


def _mods_sql(alias="a", mods=None):
    lst = ",".join(f"'{m}'" for m in (mods or config.DAILY_CAP_VERIFY_MODIFIERS))
    return "(" + " OR ".join(f"COALESCE({alias}.{m}, '') IN ({lst})" for m in dg.COL["mods"]) + ")"


def test_v26_b3_daily_caps_of_state_rules_label_verify_span_then_verify_modifier():
    """Spec §3 (v2.6), daily caps only (max_units_per_day, max_units_per_dos), state rules of every origin: verify_pa >
    verify_span (ONE payable line alone over the threshold) > verify_modifier (a payable line with a modifier of
    config.DAILY_CAP_VERIFY_MODIFIERS on any of the four columns) > the rule's qualified label. NCCI unchanged.
    2026-10-05 (critic re-check N4): payable lines only - a cancelled line and its reversal say nothing about the day."""
    assert (dg.VERIFY_SPAN, dg.VERIFY_MODIFIER) == ("verify_span", "verify_modifier")
    assert {dg.VERIFY_SPAN, dg.VERIFY_MODIFIER} <= set(dg.SEVERITIES)
    U = dg.COL["units"]
    cases = {"day": (ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4}), "units_over_limit"),
             "exc": (ext({"type": "max_units_per_day", "code_set": ["H2014", "H2015"], "threshold": 4,
                          "exception": "unless x"}), "verify_exception"),
             "may": (ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4, "discretionary": True}),
                     "discretionary"),
             "dos": (dict(ext({"type": "max_units_per_dos", "code": "97110", "threshold": 4}), origin="manual"),
                     "units_over_limit"),
             "tbl": (dl("H2014", 4, scope=MSBD), "units_over_limit")}
    for k, (r, qual) in cases.items():
        s = dg.build_detectors([r])[0]["sql"]
        sev = s.split(" AS finding_severity")[0].rsplit("CASE WHEN", 1)
        want = (f"CASE WHEN MAX(CASE WHEN a.{dg.COL['pa_no']} IS NOT NULL THEN 1 ELSE 0 END) = 1 THEN 'verify_pa'\n"
                f"            WHEN MAX(CASE WHEN a.pie_payable THEN a.{U} END) > 4 THEN 'verify_span'\n"
                f"            WHEN MAX(CASE WHEN a.pie_payable AND {_mods_sql()} THEN 1 ELSE 0 END) = 1 "
                f"THEN 'verify_modifier'\n"
                f"            ELSE '{qual}' END AS finding_severity")
        assert want in s, (k, sev)
    # NCCI per-DOS caps, period caps, per-line caps and every other query: no new label
    n = ncci({"type": "max_units_per_dos", "code": "A1234", "threshold": 4, "mai": 2, "ncci_edition": "practitioner",
              "service_category": "practitioner"})
    per = ext({"type": "max_units_per_period", "code": "T1021", "threshold": 10, "period": "month"})
    for r in (n, per, ext({"type": "code_not_covered", "code": "11975"}), b2("H0017", ["B2"]), _pair(MSBD)):
        d = dg.build_detectors([r])[0]
        assert d["compiled"] and "verify_span" not in d["sql"] and "verify_modifier" not in d["sql"], r["predicate"]
    # the AHCCCS daily batch statement: the same order on the edit row's threshold and label
    b = dg.batch_ahcccs_daily_sql(build_id="B")
    assert (f"WHEN MAX(CASE WHEN a.pie_payable THEN a.{U} END) > CAST(e.threshold AS INT) THEN 'verify_span'\n"
            f"            WHEN MAX(CASE WHEN a.pie_payable AND {_mods_sql()} THEN 1 ELSE 0 END) = 1 "
            f"THEN 'verify_modifier'\n"
            f"            ELSE e.finding_severity END AS finding_severity") in b


def test_v26_b3_daily_cap_modifier_list_is_cleaned_and_refused_when_not_modifiers(monkeypatch):
    r = ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4})
    monkeypatch.setattr(config, "DAILY_CAP_VERIFY_MODIFIERS", (" rt", "LT", "rt"))
    assert _mods_sql(mods=("RT", "LT")) in dg.compile_units_per_day(r)[0]
    monkeypatch.setattr(config, "DAILY_CAP_VERIFY_MODIFIERS", ())            # none configured: no modifier label
    s = dg.compile_units_per_day(r)[0]
    assert "verify_modifier" not in s and "verify_span" in s and "IN ()" not in s
    monkeypatch.setattr(config, "DAILY_CAP_VERIFY_MODIFIERS", ("RT", "5'0"))
    d = dg.build_detectors([r])[0]
    assert not d["compiled"] and "DAILY_CAP_VERIFY_MODIFIERS" in d["reason"], d["reason"]


def test_v26_b3_without_a_pa_column_daily_caps_still_label_span_and_modifier(monkeypatch):
    monkeypatch.setitem(dg.COL, "pa_no", None)
    s = dg.compile_units_per_day(ext({"type": "max_units_per_day", "code": "H2014", "threshold": 4}))[0]
    assert "CAST(NULL AS INT) AS pa_present" in s and "verify_pa" not in s and "'verify_span'" in s
    b = dg.batch_ahcccs_daily_sql(build_id="B")
    assert "CAST(NULL AS INT) AS pa_present" in b and "verify_pa" not in b and "'verify_span'" in b and "None" not in b


BOTH = "pair disallowed both ways: AHCCCS would deny one of the two lines"


def test_v26_b4_a_pair_disallowed_both_ways_says_so_in_the_per_rule_sql_and_the_edit_table():
    """Spec §2b (v2.6): when a version marks R x C and C x R, each line is the finding of its own rule; both rules carry
    both_ways and their finding text says the pair is disallowed both ways. The pair edit table gains a boolean
    column both_ways (08 joins it to count the dollars of such pairs once)."""
    fwd, one = _pair(MSBD, both_ways=True), _pair(MSBD)
    rev = tbl({"type": "code_pair_prohibited", "code_a": "H2014", "code_b": "H0017", "modifier_indicator": "0",
               "scope": "member_day", "exception": NOTE2, "both_ways": True})
    assert dg.BOTH_WAYS_NOTE == f" ({BOTH})"
    assert f"'H2014 billed with H0017 ({BOTH})' AS finding" in dg.compile_code_pair(fwd)[0]
    assert f"'H0017 billed with H2014 ({BOTH})' AS finding" in dg.compile_code_pair(rev)[0]
    assert "'H2014 billed with H0017' AS finding" in dg.compile_code_pair(one)[0]
    pairs, _, _ = dg.ahcccs_edit_tables([fwd, rev, one])
    assert list(pairs.columns) == dg.AHCCCS_PAIR_EDIT_COLUMNS and dg.AHCCCS_PAIR_EDIT_COLUMNS[-1] == "both_ways"
    p = pairs.set_index("rule_id")
    assert p.loc[fwd["rule_id"], "finding"] == f"H2014 billed with H0017 ({BOTH})" and p.loc[fwd["rule_id"], "both_ways"]
    assert p.loc[rev["rule_id"], "both_ways"] and not p.loc[one["rule_id"], "both_ways"]
    assert p.loc[one["rule_id"], "finding"] == "H2014 billed with H0017"
    assert str(pairs["both_ways"].dtype) == "bool" and str(dg.ahcccs_edit_tables([])[0]["both_ways"].dtype) == "bool"
    # only a boolean is read; anything else is refused (the rule is a lead saying why - never guessed one way or the
    # other); NCCI never (its text and edit table are unchanged)
    d = dg.build_detectors([_pair(MSBD, both_ways="yes")])[0]
    assert not d["compiled"] and "both_ways" in d["reason"], d["reason"]
    assert "both ways" not in dg.compile_code_pair(_pair(MSBD, both_ways=False))[0]
    assert "pair disallowed both ways" in (dg.build_detectors([fwd])[0]["conditions"] or "")
    n = ncci({"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222", "modifier_indicator": "0",
              "ncci_edition": "practitioner", "both_ways": True})
    assert "both ways" not in dg.build_detectors([n])[0]["sql"]
    assert "both_ways" not in dg.ncci_edit_tables([n])[0].columns


# ---- B5 (F14): the query validation pack (v06) has scenarios for every v2.6 case
_C = config.CLAIM_COLS


def _rev(scope="member_day"):
    return tbl({"type": "code_pair_prohibited", "code_a": "H2014", "code_b": "H0017", "modifier_indicator": "0",
                "scope": scope, "exception": NOTE2, "service_category": "state_bh", "both_ways": True})


def test_v26_b5_pack_scenarios_for_the_new_pair_scope():
    """same servicing + same billing -> finding; same servicing, other billing -> none; no billing id -> none."""
    s = _sids(qp.scenarios(_pair(MSBD), "TP010"))
    assert s["F1"]["expect"] == 1 and s["N4"]["expect"] == 0 and "F2" not in s
    assert len({(x[_C["servicing_provider"]], x[_C["billing_provider"]]) for x in s["F1"]["lines"]}) == 1
    n9 = s["N9"]["lines"]
    assert s["N9"]["expect"] == 0 and {x[_C["servicing_provider"]] for x in n9} == {"P1"}
    assert len({x[_C["billing_provider"]] for x in n9}) == 2
    assert s["N10"]["expect"] == 0 and all(x[_C["billing_provider"]] is None for x in s["N10"]["lines"])
    assert "same billing provider" in qp.what_it_does(_pair(MSBD))
    md = _sids(qp.scenarios(_pair("member_day"), "TP011"))
    assert md["F2"]["expect"] == 1 and "N9" not in md and "N10" not in md


def test_v26_b5_pack_scenarios_for_a_pair_disallowed_both_ways():
    fwd, rev = _pair(MSBD, both_ways=True), _rev(MSBD)
    s = _sids(qp.scenarios(fwd, "TP000"))
    assert s["F1"]["findings"] == [f"H2014 billed with H0017 ({BOTH})"]
    assert "findings" not in _sids(qp.scenarios(_pair(MSBD), "TP001"))["F1"]
    sc = qp.table_scenarios(dg.BATCH_AHCCCS_PAIR, [fwd, rev, _pair("member_day")])
    cross = [x for x in sc if x.get("any_rule")]
    assert len(cross) == 1 and cross[0]["expect"] == 2 and cross[0]["sid"] == "BW"
    assert sorted(cross[0]["findings"]) == sorted([f"H2014 billed with H0017 ({BOTH})", f"H0017 billed with H2014 ({BOTH})"])
    assert {x[_C["code"]] for x in cross[0]["lines"]} == {"H0017", "H2014"}
    assert len({x["member"] for x in sc}) == len(sc)                                  # every scenario its own member
    assert "both directions" in qp.what_it_does(fwd)
    # the sample keeps a both-ways rule's partner, so the pack shows both lines flagged
    picked = qp.sample_tables([fwd, rev], n_pair=1, n_daily=0, n_ptype=0, seed=3)
    assert sorted(r["rule_id"] for r in picked) == sorted([fwd["rule_id"], rev["rule_id"]])


def test_v26_b5_pack_scenarios_for_group_billing():
    r = b2("H0004", ["03", "77"], role="billing_or_rendering")
    s = _sids(qp.scenarios(r, "TT010"))
    BT, ST = _C["billing_type"], _C["prov_type"]
    f1 = s["F1"]["lines"][0]                          # a non-group biller judged on its own type
    assert s["F1"]["expect"] == 1 and f1[BT] not in ("01", "03", "77")
    assert s["N5"]["expect"] == 0 and s["N5"]["lines"][0][BT] == "03" and s["N5"]["lines"][0][ST] not in ("03", "77")
    g1, g2, g3 = (s[k]["lines"][0] for k in ("G1", "G2", "G3"))
    assert s["G1"]["expect"] == 0 and (g1[BT], g1[ST]) == ("01", "03")                 # group, rendering allowed
    assert s["G2"]["expect"] == 1 and g2[BT].strip() in ("1", "01") and g2[ST] not in ("03", "77")
    assert s["G2"]["findings"] == [f"H0004 rendered by provider type {g2[ST]} for a group (01) (allowed: 03/77)"]
    assert s["G3"]["expect"] == 0 and g3[BT] == "01" and g3[ST] is None                # rendering type missing
    assert "group" in qp.what_it_does(r) and "RENDERING" in qp.what_it_does(r)
    assert "rendering provider" in (dg.build_detectors([r])[0]["conditions"] or "")


def test_v26_b5_pack_scenarios_for_daily_caps_span_modifier_and_the_new_scope():
    r = dl("H2014", 4, scope=MSBD)
    s = _sids(qp.scenarios(r, "TD010"))
    assert s["S1"]["expect"] == 1 and s["S1"]["severity"] == "verify_span"
    assert [x[_C["units"]] for x in s["S1"]["lines"]] == [5.0]                         # ONE line over the cap
    assert s["S2"]["expect"] == 1 and s["S2"]["severity"] == "verify_modifier"
    mods = {m for x in s["S2"]["lines"] for m in (x[c] for c in _C["mods"]) if m}
    assert mods == {"RT", "LT"} and max(x[_C["units"]] for x in s["S2"]["lines"]) <= 4
    assert any(x[_C["mods"][3]] for x in s["S2"]["lines"])                            # any of the four columns
    for k in ("N6", "N7", "N8", "N9"):
        assert s[k]["expect"] == 0, k
    n8 = s["N8"]["lines"]
    assert {x[_C["servicing_provider"]] for x in n8} == {"P1"} and len({x[_C["billing_provider"]] for x in n8}) == 2
    assert all(x[_C["billing_provider"]] is None for x in s["N9"]["lines"]) and "F2" not in s
    w = qp.what_it_does(r)
    assert "billing provider" in w and "verify_span" in w and "verify_modifier" in w
    md = _sids(qp.scenarios(ext({"type": "max_units_per_day", "code": "A0422", "threshold": 1}), "Q000"))
    assert md["S1"]["severity"] == "verify_span" and md["S2"]["severity"] == "verify_modifier" and "N8" not in md
    n = ncci({"type": "max_units_per_dos", "code": "A1234", "threshold": 4, "mai": 2, "ncci_edition": "practitioner",
              "service_category": "practitioner"})
    assert not {"S1", "S2"} & set(_sids(qp.scenarios(n, "Q001")))                     # NCCI: no new label


def test_v26_b5_judge_checks_the_finding_text_and_cross_rule_scenarios():
    sc = {"member": "M1", "expect": 1, "severity": "verify_exception", "rule_id": "R1", "findings": ["x (both ways)"]}
    f = lambda txt="x (both ways)", rid="R1": {"member_id": "M1", "finding_severity": "verify_exception",
                                               "rule_id": rid, "finding": txt}
    assert qp._judge([f()], sc)[0] and not qp._judge([f(txt="x")], sc)[0]
    cross = {"member": "M1", "expect": 2, "severity": None, "rule_id": "R1", "any_rule": True,
             "findings": ["a (both ways)", "b (both ways)"]}
    assert qp._judge([f("a (both ways)"), f("b (both ways)", rid="R2")], cross)[0]
    assert not qp._judge([f("a (both ways)")], cross)[0]                               # only one line flagged
    assert not qp._judge([f("a (both ways)"), f("a (both ways)", rid="R2")], cross)[0]


SAMPLE26 = [_pair(MSBD, both_ways=True), _rev(MSBD), _pair("member_day"), dl("H2014", 4, scope=MSBD),
            b2("H0004", ["03", "77"], role="billing_or_rendering")]


def test_v26_b5_pack_passes_the_right_answer_and_fails_a_query_that_ignores_the_billing_provider(offline):
    right = _right_answer(SAMPLE26)
    q, s = _table_pack(_FakeSpark(lambda text: right), SAMPLE26)
    assert s["pass"].all() and set(q["auto_test"]) == {"PASS"}, s[~s["pass"]].to_string()
    assert {"BW", "N9", "N10", "S1", "S2", "G1", "G2", "G3", "N8"} <= set(s["scenario"])
    wrong = right + [dict(x, member_id=x["member_id"].rsplit("_", 1)[0] + "_N9") for x in right
                     if x["member_id"].endswith("_F1")]
    q2, s2 = _table_pack(_FakeSpark(lambda text: wrong), SAMPLE26)
    assert "FAIL" in set(q2["auto_test"]) and not s2[s2["scenario"] == "N9"]["pass"].all()
