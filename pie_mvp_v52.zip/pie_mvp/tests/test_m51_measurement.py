"""Critic M51 (2026-10-04): the measurement notebooks, run from SOURCE against an in-memory catalog (tests/nbfake_m51.py).

  M51-1  05 persists each run's drafts (policy_extraction_drafts); v01's default sample is the LATEST successful run's
         own drafts - never approved / rejected rows an older engine left in state_rules - and a chapter whose latest
         run has no rows there is reported, not silently dropped
  M51-3  v01 stamps every sheet row with the sample's population and corpus_version, ingest copies both into each
         metric row, and v03 judges a bar only on the engine's own sample of the current corpus
  M51-6  v03: a bar with more than 10% of its drawn units unscored is NOT YET
  M51-8  v03: the RUN:snapshot row is not a detector error; a partial run says why
  M51-9  v03: the routing bar checks what 08 checks (servicing types, + billing types when routing by billing type)
         and is GO only when the routing is signed
  M51-4 / M51-10  v05: each run's ship gate covers ALL its chapters; the A/B is a comparison on the shared chapters,
         and its corpus warning is about those chapters
Run: cd pie_mvp && python -m pytest tests/test_m51_measurement.py -q
"""
import json
import os
import re
import sys

import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, PKG)
sys.path.insert(0, HERE)

import config  # noqa: E402
import extract_io  # noqa: E402
import nbfake_m51 as nbf  # noqa: E402
import policy_docs  # noqa: E402
import quality  # noqa: E402
import state_rules as sr  # noqa: E402

V01, V03, V05 = ("validation/v01_extraction_scoring.py", "validation/v03_pipeline_health.py",
                 "validation/v05_extraction_regression.py")


def _kb(name):
    return f"{config.KB}.{name}"


# ====================================================================== v01: the population (M51-1, M51-3)
def _draft(key, run, typ="max_units_per_day", ch="19", doc="H19", sec="s19a"):
    pred = {"type": typ, "code": "T1016"} if typ == "code_not_covered" else {"type": typ, "code": "T1016",
                                                                               "threshold": 4}
    return {"rule_id": f"EXT-{key}", "extraction_key": key, "origin": "extracted", "chapter": ch, "doc_hash": doc,
            "section_id": sec, "statement": f"rule {key} of run {run}",
            "verbatim_quote": f"T1016 is limited to four units per day ({key}).", "predicate": json.dumps(pred),
            "codes": json.dumps(["T1016"]), "extraction_run_id": run, "extraction_source": "model",
            "review_status": "draft", "population": "all", "source_doc": f"Chapter {ch}", "source_locator": "page 3",
            "source_url": "https://x"}


def _v01_tables():
    """The critic's fresh start (probe_population): run R1 proposes K1-K3, a reviewer rejects K1 and approves K2; run R2
    of the SAME document version produces K4 and K1 with another predicate. Chapter 4's latest run R0 was persisted
    before policy_extraction_drafts existed."""
    r1 = [_draft("K1", "R1"), _draft("K2", "R1"), _draft("K3", "R1")]
    table, _ = sr.merge_drafts(None, r1, rerun={"19": "H19"}, run_id="R1", completed_sections={"s19a"})
    table["reviewer"] = table["reviewer"].astype(object)
    table.loc[table.extraction_key == "K1", ["review_status", "reviewer"]] = ["rejected", "SB"]
    table.loc[table.extraction_key == "K2", ["review_status", "reviewer"]] = ["approved", "SB"]
    r2 = [_draft("K4", "R2"), _draft("K1", "R2", typ="code_not_covered")]
    table, _ = sr.merge_drafts(table, r2, rerun={"19": "H19"}, run_id="R2", completed_sections={"s19a"})
    r0 = [_draft("K40", "R0", ch="4", doc="H4", sec="s4a"), _draft("K41", "R0", ch="4", doc="H4", sec="s4a")]
    table, _ = sr.merge_drafts(table, r0, rerun={"4": "H4"}, run_id="R0", completed_sections={"s4a"})
    table.loc[table.extraction_key == "K40", ["review_status", "reviewer"]] = ["approved", "SB"]

    def sec(sid, ch, doc, run):
        return {"heading": f"Section {sid}", "page_start": 3, "page_end": 4, "chapter": ch, "doc_hash": doc,
                "text": f"Text of {sid}: T1016 is limited to four units per day.", "section_id": sid, "run_id": run}

    def drop(stmt, run):
        return {"chapter": "19", "section_id": "s19a", "heading": "Section s19a", "statement": stmt,
                "predicate": json.dumps({"type": "code_not_covered", "code": "T1016"}), "codes": '["T1016"]',
                "verbatim_quote": f"{stmt}: quote", "drop_reason": "quote not found in source",
                "extraction_source": "model", "doc_hash": "H19", "page_start": 3, "page_end": 4, "run_id": run}
    return {
        _kb("policy_document_inventory"): pd.DataFrame([
            {"chapter": "19", "doc_hash": "H19", "fetched_at": "2026-10-02T00:00:00"},
            {"chapter": "4", "doc_hash": "H4", "fetched_at": "2026-09-01T00:00:00"}]),
        config.STATE_RULES_TABLE: table,
        # 05 persisted R1 and R2 (R0 predates the table)
        _kb("policy_extraction_drafts"): pd.DataFrame([dict(x, run_id=x["extraction_run_id"]) for x in r1 + r2]),
        _kb("policy_extraction_log"): pd.DataFrame([
            {"chapter": "19", "doc_hash": "H19", "run_id": "R1", "error": None, "drafts_unique": 3},
            {"chapter": "19", "doc_hash": "H19", "run_id": "R2", "error": None, "drafts_unique": 2},
            {"chapter": "4", "doc_hash": "H4", "run_id": "R0", "error": None, "drafts_unique": 2}]),
        _kb("policy_sections"): pd.DataFrame([sec("s19a", "19", "H19", "R1"), sec("s19a", "19", "H19", "R2"),
                                              sec("s19b", "19", "H19", "R2"), sec("s4a", "4", "H4", "R0")]),
        _kb("policy_extraction_outcomes"): pd.DataFrame([
            {"chapter": "19", "section_id": "s19a", "doc_hash": "H19", "run_id": "R2", "outcome": "proposals",
             "reason": None},
            {"chapter": "19", "section_id": "s19b", "doc_hash": "H19", "run_id": "R2", "outcome": "no_rules",
             "reason": "no rule stated"},
            {"chapter": "4", "section_id": "s4a", "doc_hash": "H4", "run_id": "R0", "outcome": "proposals",
             "reason": None}]),
        _kb("policy_extraction_dropped"): pd.DataFrame([drop("dropped by R1", "R1"), drop("dropped by R2", "R2")]),
    }


CORPUS = policy_docs.corpus_version({"19": "H19", "4": "H4"})


@pytest.fixture
def v01(tmp_path, monkeypatch):
    nbf.install(monkeypatch)
    monkeypatch.setattr(config, "WORKSPACE_DATA_DIR", str(tmp_path))
    return nbf.FakeSpark(_v01_tables())


def test_m51_1_v01_samples_the_latest_runs_own_drafts_and_reports_a_chapter_without_run_rows(v01, capsys):
    g = nbf.run_notebook(V01, v01)
    book = quality.xlsx_read_sheets(g["EXPORT_PATH"])
    rules = book["RULES"]
    assert sorted(rules["extraction_key"]) == ["K1", "K4"]                 # run R2's drafts, nothing R1 left behind
    k1 = rules.set_index("extraction_key").loc["K1"]
    assert json.loads(k1["predicate"])["type"] == "code_not_covered"       # R2's reading, not R1's
    assert k1["review_status"] == "rejected" and set(rules["extraction_run_id"]) == {"R2"}
    recall = book["RECALL"].set_index("section_id")
    assert recall.loc["s19a", "rules_extracted"] == 2 and "K2" not in recall.loc["s19a", "rules_extracted_text"]
    assert "s4a" not in recall.index                                       # chapter 4 is not in this sample ...
    dropped = book["DROPPED"]
    assert dropped["statement"].tolist() == ["dropped by R2"]
    kept = dropped["rules_kept_text"].iloc[0]
    assert "rule K4 of run R2" in kept and "run R1" not in kept
    out = capsys.readouterr().out
    assert re.search(r"chapter\(s\) 4\b.*R0", out) and "policy_extraction_drafts" in out   # ... and it says so
    readme = " ".join(str(x) for x in book["README"].iloc[:, 0])
    assert "NOT in this sample" in readme and "chapter(s) 4" in readme


def test_m51_3_v01_stamps_every_sheet_row_with_its_population_and_corpus(v01):
    book = quality.xlsx_read_sheets(nbf.run_notebook(V01, v01)["EXPORT_PATH"])
    for sh in ("RULES", "RECALL", "DROPPED"):
        assert len(book[sh]) and set(book[sh]["population"]) == {"engine_latest_run"}, sh
        assert set(book[sh]["corpus_version"]) == {CORPUS}, sh
    assert set(book["RULES"]["rule_population"]) == {"all"}
    # STATUSES = ["approved"]: the fidelity of APPROVED rules, from state_rules, stamped as such
    g = nbf.run_notebook(V01, v01, {"STATUSES        = None": 'STATUSES        = ["approved"]'})
    book = quality.xlsx_read_sheets(g["EXPORT_PATH"])
    assert sorted(book["RULES"]["extraction_key"]) == ["K2", "K40"]
    for sh in ("RULES", "RECALL", "DROPPED"):
        assert set(book[sh]["population"]) == {"statuses:approved"}, sh


def test_m51_3_v01_ingest_copies_the_stamps_into_every_metric_row(v01):
    book = quality.xlsx_read_sheets(nbf.run_notebook(V01, v01)["EXPORT_PATH"])
    book["RULES"]["is_real_rule"], book["RULES"]["faithful_to_source"] = "Y", "Y"
    book["RECALL"]["real_rules_found"] = book["RECALL"]["rules_extracted"]
    book["RECALL"]["missed_rules"] = 0
    book["DROPPED"]["is_real_rule"] = "N"
    scored = quality.xlsx_write_sheets(book, os.path.join(config.WORKSPACE_DATA_DIR, "scored.xlsx"))
    nbf.run_notebook(V01, v01, {"EXPORT          = True": "EXPORT          = False",
                                "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"})
    m = v01.frame(_kb("policy_quality_metrics"))
    assert set(m["population"]) == {"engine_latest_run"} and set(m["corpus_version"]) == {CORPUS}
    assert {"unscored", "scored_units", "sample_id", "computed_at"} <= set(m.columns)
    e = m[(m["metric"] == "executable_rule_precision") & (m["scope"] == "all")].iloc[0]
    assert int(e["n"]) == 2 and int(e["unscored"]) == 0 and "weighted by stratum size" in e["notes"]


def test_m51_12_v01_stamps_the_latest_run_of_each_sampled_chapter(v01):
    """Every sheet row says which run of each sampled chapter the sample describes (one canonical text): v03 judges a bar
    only while those runs are still the latest. Chapter 4 is not sampled (its run has no rows in
    policy_extraction_drafts), so the default sample names chapter 19 only."""
    book = quality.xlsx_read_sheets(nbf.run_notebook(V01, v01)["EXPORT_PATH"])
    for sh in ("RULES", "RECALL", "DROPPED"):
        assert set(book[sh]["sample_runs"]) == {'{"19": "R2"}'}, sh
    g = nbf.run_notebook(V01, v01, {"STATUSES        = None": 'STATUSES        = ["approved"]'})
    book = quality.xlsx_read_sheets(g["EXPORT_PATH"])                      # approved K2 (ch 19) and K40 (ch 4)
    for sh in ("RULES", "RECALL", "DROPPED"):
        assert set(book[sh]["sample_runs"]) == {'{"19": "R2", "4": "R0"}'}, sh


def test_m51_12_v01_ingest_copies_the_runs_into_every_metric_row(v01):
    book = quality.xlsx_read_sheets(nbf.run_notebook(V01, v01)["EXPORT_PATH"])
    book["RULES"]["is_real_rule"], book["RULES"]["faithful_to_source"] = "Y", "Y"
    book["RECALL"]["real_rules_found"], book["RECALL"]["missed_rules"] = book["RECALL"]["rules_extracted"], 0
    book["DROPPED"]["is_real_rule"] = "N"
    scored = quality.xlsx_write_sheets(book, os.path.join(config.WORKSPACE_DATA_DIR, "scored.xlsx"))
    nbf.run_notebook(V01, v01, {"EXPORT          = True": "EXPORT          = False",
                                "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"})
    m = v01.frame(_kb("policy_quality_metrics"))
    assert set(m["sample_runs"]) == {'{"19": "R2"}'}
    pooled = m[(m["metric"] == "executable_rule_precision") & (m["scope"] == "all")].iloc[0]
    ok, why = quality.metric_for_bar(m, "executable_rule_precision", "all", CORPUS, latest_run={"19": "R2", "4": "R0"})
    assert ok is not None and ok["sample_id"] == pooled["sample_id"]
    ok, why = quality.metric_for_bar(m, "executable_rule_precision", "all", CORPUS, latest_run={"19": "R3"})
    assert ok is None and "measured on run R2 of chapter 19; the latest run is R3" in why


# ====================================================================== v03 (M51-3, M51-6, M51-8, M51-9)
V03_CORPUS = policy_docs.corpus_version({"19": "H19"})


def _metric_rows(**kw):
    rows = []
    for name in ("executable_rule_precision", "extraction_recall", "extraction_fidelity", "extraction_precision"):
        for st, sc in (("overall", "all"), ("chapter", "19")):
            rows.append(dict({"metric": name, "scope_type": st, "scope": sc, "n": 400, "value": 0.995,
                              "ci_low": 0.98, "ci_high": 0.999, "unscored": 0, "scored_units": 400,
                              "population": "engine_latest_run", "corpus_version": V03_CORPUS,
                              "sample_runs": '{"19": "R2"}', "sample_id": "s1", "computed_at": "2026-10-04T10:00:00",
                              "notes": "weighted by stratum size"}, **kw))
    return rows


LOG_R2 = [{"chapter": "19", "doc_hash": "H19", "run_id": "R2", "error": None, "drafts_unique": 3}]


def _v03(monkeypatch, metrics=None, runs=None, claims=None, sql_hook=None, log=LOG_R2):
    nbf.install(monkeypatch)
    t = {config.STATE_RULES_TABLE: pd.DataFrame([{"rule_id": "EXT-1", "origin": "extracted", "chapter": "19",
                                                   "review_status": "draft"}]),
         _kb("policy_document_inventory"): pd.DataFrame([{"chapter": "19", "doc_hash": "H19",
                                                          "fetched_at": "2026-10-01T00:00:00"}])}
    if log is not None:
        t[_kb("policy_extraction_log")] = pd.DataFrame(log)
    if metrics is not None:
        t[_kb("policy_quality_metrics")] = pd.DataFrame(metrics)
    if runs is not None:
        t[_kb("policy_detector_runs")] = runs
        t[_kb("policy_rules")] = pd.DataFrame([{"rule_id": "EXT-1", "build_id": "B1"}])
    if claims is not None:
        t[config.CLAIMS_TABLE] = claims
    if claims is None:
        monkeypatch.setattr(config, "NCCI_ROUTE_BY", "form")              # no claims read unless the test needs it
    g = nbf.run_notebook(V03, nbf.FakeSpark(t, sql_hook=sql_hook))
    go = g["go_table"]
    return {r["measurement bar item"]: (r["status"], r["reason"]) for r in go.to_dict("records")}


def _bar(bars, prefix):
    hits = [v for k, v in bars.items() if k.startswith(prefix)]
    assert len(hits) == 1, (prefix, list(bars))
    return hits[0]


PASS_MARKS = ("Executable-rule precision", "Extraction recall >=", "Extraction fidelity")


def test_m51_3_v03_goes_on_the_engines_own_sample_of_the_current_corpus(monkeypatch):
    bars = _v03(monkeypatch, _metric_rows())
    for p in PASS_MARKS:
        assert _bar(bars, p)[0] == "GO", (p, _bar(bars, p))


def test_m51_3_v03_does_not_judge_an_approved_only_sample(monkeypatch):
    bars = _v03(monkeypatch, _metric_rows(population="statuses:approved"))
    for p in PASS_MARKS:
        st, why = _bar(bars, p)
        assert st == "NOT YET" and "statuses:approved" in why, (p, why)
    assert _bar(bars, "Extraction precision measured per chapter")[0] == "NOT YET"


def test_m51_3_v03_does_not_judge_another_corpus_or_an_unstamped_sample(monkeypatch):
    bars = _v03(monkeypatch, _metric_rows(corpus_version="corpus-0000000000000000"))
    for p in PASS_MARKS:
        st, why = _bar(bars, p)
        assert st == "NOT YET" and "corpus-0000000000000000" in why and V03_CORPUS in why, (p, why)
    old = [{k: v for k, v in r.items() if k not in ("population", "corpus_version", "unscored", "scored_units",
                                                    "sample_runs")}
           for r in _metric_rows()]                                           # rows ingested before M51
    bars = _v03(monkeypatch, old)
    for p in PASS_MARKS:
        st, why = _bar(bars, p)
        assert st == "NOT YET" and "not recorded" in why, (p, why)


def test_m51_12_v03_does_not_judge_a_sample_of_an_older_run(monkeypatch):
    """SB re-runs 04 on the same corpus (another reasoning effort): run R3 is now the engine's output, and a sample
    drawn from run R2 no longer describes it."""
    log = LOG_R2 + [{"chapter": "19", "doc_hash": "H19", "run_id": "R3", "error": None, "drafts_unique": 4}]
    bars = _v03(monkeypatch, _metric_rows(), log=log)
    for p in PASS_MARKS:
        st, why = _bar(bars, p)
        assert st == "NOT YET" and "measured on run R2 of chapter 19; the latest run is R3" in why, (p, why)
    assert _bar(bars, "Extraction precision measured per chapter")[0] == "NOT YET"
    # a failed re-run is not the engine's output: the sample of R2 still stands
    log_failed = LOG_R2 + [{"chapter": "19", "doc_hash": "H19", "run_id": "R3", "error": "boom", "drafts_unique": None}]
    bars = _v03(monkeypatch, _metric_rows(), log=log_failed)
    assert all(_bar(bars, p)[0] == "GO" for p in PASS_MARKS)


def test_m51_12_v03_does_not_judge_a_sample_without_its_runs(monkeypatch):
    bars = _v03(monkeypatch, _metric_rows(sample_runs=None))                   # ingested before the run check
    for p in PASS_MARKS:
        st, why = _bar(bars, p)
        assert st == "NOT YET" and "sample_runs was not recorded" in why, (p, why)
    bars = _v03(monkeypatch, _metric_rows(), log=None)                         # no extraction log to tell the latest
    for p in PASS_MARKS:
        st, why = _bar(bars, p)
        assert st == "NOT YET" and "chapter 19 has no successful run" in why, (p, why)


def test_m51_6_v03_holds_a_bar_with_too_many_unscored_units(monkeypatch):
    bars = _v03(monkeypatch, _metric_rows(unscored=100))                     # 100 of 500 drawn units: 20%
    for p in PASS_MARKS:
        st, why = _bar(bars, p)
        assert st == "NOT YET" and "100 of 500 drawn" in why, (p, why)


def _runs(partial, skipped=None, extra_error=None):
    gate = ("not run: 3 provider type code(s) on CMS-1500 / UB-04 lines have no SIGNED routing row (05, B2, 77) - "
            "sign them in ncci_provider_type_routing.csv")
    rows = [{"rule_id": "BATCH:ncci_ptp", "error": None, "skipped": skipped and gate},
            {"rule_id": "BATCH:ncci_mue", "error": None, "skipped": skipped and gate},
            {"rule_id": "EXT-1", "error": extra_error, "skipped": None},
            {"rule_id": "RUN:snapshot", "skipped": None,
             "error": json.dumps({"snapshot_rows": 10, "ncci_routing": "unsigned", "ncci_gate": gate})}]
    df = pd.DataFrame(rows)
    df["run_id"], df["build_id"], df["predicate_type"] = "20261004T120000", "B1", None
    df["partial_run"], df["detectors_eligible"] = partial, 3
    return df


def test_m51_8_v03_does_not_count_the_run_snapshot_as_an_error(monkeypatch):
    st, why = _bar(_v03(monkeypatch, runs=_runs(False)), "Latest detector run complete")
    assert st == "GO" and "no errors" in why
    st, why = _bar(_v03(monkeypatch, runs=_runs(False, extra_error="AnalysisException: boom")),
                   "Latest detector run complete")
    assert st == "NOT YET" and "1 detector error(s)" in why


def test_m51_8_v03_says_why_a_run_is_partial(monkeypatch):
    st, why = _bar(_v03(monkeypatch, runs=_runs(True, skipped=True)), "Latest detector run complete")
    assert st == "NOT YET" and "partial run" in why and "have no SIGNED routing row" in why
    assert "BATCH:ncci_ptp" in why


ROUTING = ("sprov_type,description_at_mapping,cms_category,note,status,reviewer,reviewed_at\n"
           "08,MD-Physician,practitioner,,signed,SB,2026-10-04\n"
           "31,DO-Physician Osteopath,practitioner,,signed,SB,2026-10-04\n"
           "B2,Residential,not_applicable,,proposed,,\n")


def _claims(billing):
    return pd.DataFrame({"FORM_TYP": ["A", "O", "C"], "SProv_Type": ["08", "31", "B2"], "BProv_Type": billing})


def _types_hook(claims):
    """Answers the observed-provider-types query from the claims frame: which columns it reads decides the answer."""
    col = {"pie_prov_type": "SProv_Type", "pie_bprov_type": "BProv_Type"}
    on_ao = claims[claims["FORM_TYP"].isin(["A", "O"])]

    def hook(q):
        if "explode(array(" in q:                                    # the pre-M51 query: billing AND servicing always
            vals = set(on_ao["SProv_Type"]) | set(on_ao["BProv_Type"])
            return [{"ptype": v} for v in sorted(v for v in vals if v)]
        cols = re.findall(r"SELECT (pie_\w+) AS t FROM", q)
        assert cols and "pie_form IN ('A','O')" in q.replace(", ", ","), q
        vals = set().union(*(set(on_ao[col[c]]) for c in cols))
        return [{"t": v} for v in sorted(v for v in vals if v)]
    return hook


@pytest.fixture
def routing_csv(tmp_path, monkeypatch):
    p = tmp_path / "routing.csv"
    p.write_text(ROUTING)
    monkeypatch.setattr(config, "NCCI_PROVIDER_TYPE_TABLE", str(p))
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "none")
    return str(p)


ROUTING_BAR = "NCCI routing table"


def test_m51_9_v03_routing_by_servicing_type_ignores_billing_types(monkeypatch, routing_csv):
    claims = _claims(["B2", "31", "B2"])                       # billing B2 is unsigned, but provider_type mode ignores it
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "provider_type")
    st, why = _bar(_v03(monkeypatch, claims=claims, sql_hook=_types_hook(claims)), ROUTING_BAR)
    assert st == "GO" and "all 2 provider type code(s) observed on CMS-1500 / UB-04 lines (servicing)" in why
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")     # routing by billing type: B2 counts
    st, why = _bar(_v03(monkeypatch, claims=claims, sql_hook=_types_hook(claims)), ROUTING_BAR)
    assert st == "NOT YET" and "e.g. B2" in why


def test_m51_9_v03_routing_bar_is_go_only_when_the_routing_is_signed(monkeypatch, routing_csv):
    claims = _claims(["08", "31", "B2"])                       # every observed code signed ...
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    st, _ = _bar(_v03(monkeypatch, claims=claims, sql_hook=_types_hook(claims)), ROUTING_BAR)
    assert st == "GO"
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "form")         # ... but unmapped lines take a guess
    st, why = _bar(_v03(monkeypatch, claims=claims, sql_hook=_types_hook(claims)), ROUTING_BAR)
    assert st == "NOT YET" and "NCCI_UNMAPPED_PROVIDER_TYPE = 'form'" in why


# ====================================================================== 05 (M51-1)
def _make_run(root, run_id, doc_hash):
    """A real run folder like 04 writes it: the fixture PDF read by the STUB backend."""
    import extract_rules as ex
    import fixture_pdf
    import policy_changes
    path = fixture_pdf.build(os.path.join(root, f"fx_{doc_hash}.pdf"))
    inv = {"chapter": "10", "title": "Individual Practitioner Services", "url": "https://x/FFS_Chap10.pdf",
           "path": path, "doc_hash": doc_hash, "bytes": 1, "source": "volume", "fetched_at": "2026-10-04T10:00:00"}
    secs, meta = policy_docs.segment(policy_docs.parse_pdf(path), "10", doc_hash)
    inv["revision_date"] = meta["revision_date"]
    outcomes = []
    drafts, dropped, stats = ex.extract_chapter(secs, inv, ex.make_backend("STUB"), run_id, cache={},
                                                log_fn=lambda *a: None, outcomes=outcomes)
    stats.update(seconds=0.1, error=None)
    d = extract_io.new_run_dir(os.path.join(root, "runs"), run_id)
    extract_io.write_run(d, inventory_rows=[policy_docs.inventory_record(inv, meta)],
                         section_rows=[{k: (json.dumps(v) if isinstance(v, list) else v) for k, v in s.items()}
                                       | {"run_id": run_id} for s in secs],
                         log_rows=[stats], dropped_rows=dropped,
                         change_rows=policy_changes.diff_chapter(None, drafts, inv, None, run_id), drafts=drafts,
                         cache={}, manifest={"run_id": run_id, "finished": True, "model_calls": 0,
                                             "model_failures": 0}, outcome_rows=outcomes)
    return drafts


def test_m51_1_05_persists_each_runs_drafts_as_run_telemetry(tmp_path, monkeypatch):
    nbf.install(monkeypatch)
    monkeypatch.setattr(config, "RUN_ROOT", str(tmp_path / "runs"))
    monkeypatch.setattr(config, "WORKSPACE_DATA_DIR", str(tmp_path / "data"))
    drafts = _make_run(str(tmp_path), "20261004T100000", "DOC_A")
    spark = nbf.FakeSpark()
    nbf.run_notebook("05_persist_extraction.py", spark)
    t = _kb("policy_extraction_drafts")
    assert t in spark.tables
    d = spark.frame(t)
    assert len(d) == len(drafts) and set(d["run_id"]) == {"20261004T100000"}
    assert sorted(d["extraction_key"]) == sorted(x["extraction_key"] for x in drafts)
    types_ = {f.name: f.dataType.typeName() for f in spark.table(t).schema.fields}
    assert types_["machine_checkable"] == "boolean" and types_["extraction_confidence"] == "double"
    assert types_["predicate"] == types_["run_id"] == types_["statement"] == "string"
    nbf.run_notebook("05_persist_extraction.py", spark)                        # the SAME run folder again
    assert len(spark.frame(t)) == len(drafts)                                 # replaced, never doubled


# ====================================================================== v05 (M51-4, M51-10)
def _d(ch, key, code, quote, typ="max_units_per_day"):
    pred = {"type": typ, "code": code, "threshold": 4} if typ != "code_not_covered" else {"type": typ, "code": code}
    return {"rule_id": f"EXT-{key}", "extraction_key": key, "origin": "extracted", "chapter": ch, "doc_hash": f"H{ch}",
            "section_id": f"{ch}-s1", "statement": key, "verbatim_quote": quote, "population": "all",
            "predicate": json.dumps(pred), "codes": json.dumps([code]), "extraction_source": "model",
            "review_status": "draft"}


CH10 = _d("10", "k10", "T1016", "T1016 is limited to four units per day for any member.")
CH4_NEW = _d("4", "k4new", "ZZ999", "Code ZZ999 is never covered for any member in any setting.", typ="code_not_covered")
CH22_NEW = _d("22", "k22new", "ZZ888", "Code ZZ888 is never covered for any member in any setting.",
              typ="code_not_covered")


def _v05(tmp_path, monkeypatch, a_drafts, a_inv, b_drafts, b_inv):
    nbf.install(monkeypatch)
    root = str(tmp_path / "runs")
    a = extract_io.new_run_dir(root, "20261004T000000")
    extract_io.write_run(a, inventory_rows=a_inv, section_rows=[], log_rows=[], dropped_rows=[], change_rows=[],
                         drafts=a_drafts, cache={},
                         manifest={"run_id": "20261004T000000", "finished": True, "reasoning": "low"})
    b = extract_io.new_run_dir(root, "20261004T010000")
    extract_io.write_run(b, inventory_rows=b_inv, section_rows=[], log_rows=[], dropped_rows=[], change_rows=[],
                         drafts=b_drafts, cache={},
                         manifest={"run_id": "20261004T010000", "finished": True, "reasoning": "medium"})
    table, _ = sr.merge_drafts(None, [CH10])
    table["review_status"], table["reviewer"] = "approved", "SB"
    monkeypatch.setattr(config, "RUN_ROOT", root)
    monkeypatch.setattr(config, "WORKSPACE_DATA_DIR", str(tmp_path))
    return nbf.run_notebook(V05, nbf.FakeSpark({config.STATE_RULES_TABLE: table}),
                            {"RUN_ID               = None": 'RUN_ID               = "20261004T000000"',
                             "RUN_DIR_B            = None": f"RUN_DIR_B            = {b!r}"})


def test_m51_4_each_runs_ship_gate_covers_all_its_chapters(tmp_path, monkeypatch, capsys):
    """The critic's probe: run A has an unreviewed executable draft in chapter 4, which run B did not extract; the
    A/B used to narrow A's own gate to the shared chapter 10 and print SHIP GATE: OK. Run B has one in chapter 22."""
    g = _v05(tmp_path, monkeypatch, [CH10, CH4_NEW], [{"chapter": "10", "doc_hash": "H10"},
                                                      {"chapter": "4", "doc_hash": "H4"}],
             [CH10, CH22_NEW], [{"chapter": "10", "doc_hash": "H10"}, {"chapter": "22", "doc_hash": "H22"}])
    assert g["ok"] is False and "1 new executable draft(s) have no reviewed decision" in g["why"]
    runs = g["runs_df"]
    assert runs["ship_gate"].tolist() == ["BLOCKED", "BLOCKED"]               # each run's OWN gate
    assert runs["unmatched_compiled"].tolist() == [0, 0]                       # the comparison: chapter 10 only
    assert g["chapters"] == ["10"]
    assert g["summary"]["total"]["unmatched_compiled"] == 1                  # run A scored on chapters 10 and 4
    out = capsys.readouterr().out
    assert "SHIP GATE: OK" not in out and "a comparison, not a gate" in out
    book = quality.xlsx_read_sheets(g["path"])
    assert sorted(book["summary"]["chapter"].astype(str)) == ["10", "4", "TOTAL"]


def test_m51_10_the_corpus_warning_is_about_the_compared_chapters(tmp_path, monkeypatch, capsys):
    g = _v05(tmp_path / "one", monkeypatch, [CH10, CH4_NEW], [{"chapter": "10", "doc_hash": "H10"},
                                                              {"chapter": "4", "doc_hash": "H4"}],
             [CH10], [{"chapter": "10", "doc_hash": "H10"}])
    w = g["CORPUS_WARNINGS"]
    assert not any(x.startswith("runs A and B rest on different corpus versions") for x in w), w
    out = capsys.readouterr().out
    assert "WARNING: runs A and B" not in out
    assert re.search(r"outside the comparison.*4 only in A", out)               # the rest is still mentioned
    # a document version that differs in a COMPARED chapter is still a warning
    g = _v05(tmp_path / "two", monkeypatch, [CH10], [{"chapter": "10", "doc_hash": "H10"}],
             [CH10], [{"chapter": "10", "doc_hash": "H10-v2"}])
    assert any(x.startswith("runs A and B rest on different corpus versions") and "10: A H10 vs B H10-v2" in x
               for x in g["CORPUS_WARNINGS"])
