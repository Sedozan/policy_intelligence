"""regress.py after critic M51 (2026-10-04): DANGER and the unreviewed-draft count of the v05 ship gate.

M51-5  a REVERSED code pair (draft 97110 -> 97530 where the signed rule is 97530 -> 97110) puts the finding on the
       other line (detector_gen.compile_code_pair: the finding sits on code_b), so it flags lines the signed rule does
       not: DANGER, never a mere label difference. A second same-type draft on an already-matched signed rule is a
       harmless 'duplicate' only when its comparable predicate is the signed one; a different reading that is not
       wider is an executable rule nobody reviewed (unmatched_compiled), and a wider one stays DANGER (counted once).
M51-4  compare_runs reports each run's OWN ship gate when v05 passes it (the A/B numbers are a comparison only).
Run: cd pie_mvp && python -m pytest tests/test_regress_v51.py -q
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import regress  # noqa: E402

Q = "Procedure code 97110 may not be billed on the same date of service as code 97530 by the same provider."
PAIR = {"type": "code_pair_prohibited", "code_a": "97530", "code_b": "97110", "modifier_indicator": "0"}
REVERSED = dict(PAIR, code_a="97110", code_b="97530")
CAP = {"type": "max_units_per_day", "code": "97110", "threshold": 4}
QC = "Procedure code 97110 is limited to four units per day for any member."


def _gold(gid, kind, pred, quote=Q, key=None):
    return regress._gold_row(gid, kind, "14", pred, quote, doc_hash="H14", key=key, reviewer="SB", source="test")


def _draft(rid, pred, key=None, quote=Q, pop="all"):
    return {"rule_id": rid, "extraction_key": key, "chapter": "14", "verbatim_quote": quote, "population": pop,
            "predicate": json.dumps(pred)}


# ------------------------------------------------------------------ M51-5: a reversed pair flags the other line
def test_a_reversed_code_pair_is_danger_not_a_label_difference():
    summ, det = regress.compare([_gold("G1", "positive", PAIR, key="k1")], [_draft("D1", REVERSED, key="k1")])
    row = det[0]
    assert row["danger"] and "reversed" in row["danger_reasons"]
    assert "97530" in row["danger_reasons"] and "97110" in row["danger_reasons"]
    assert row["exact"] is False and row["result"] == "changed"            # not the signed predicate
    assert not (row["label_diffs"] or "").count("direction")               # no longer filed as a label
    assert summ["total"]["danger"] == 1 and not regress.ship_gate(summ)[0]
    # the same direction is still exact and safe
    summ, det = regress.compare([_gold("G1", "positive", PAIR, key="k1")], [_draft("D1", dict(PAIR), key="k1")])
    assert det[0]["exact"] and not det[0]["danger"] and regress.ship_gate(summ)[0]
    assert regress.canon(PAIR) != regress.canon(REVERSED)
    assert regress.wider_reasons(_draft("D", REVERSED), _gold("G", "positive", PAIR)) != []


def test_a_reversed_copy_of_a_matched_pair_is_danger():
    summ, det = regress.compare([_gold("G1", "positive", PAIR, key="k1")],
                                [_draft("D1", PAIR, key="k1"), _draft("D2", REVERSED, key="k2")])
    by = {r["rule_id"]: r for r in det}
    assert by["D1"]["result"] == "exact" and by["D2"]["danger"] and "reversed" in by["D2"]["danger_reasons"]
    assert summ["total"]["danger"] == 1 and not regress.ship_gate(summ)[0]


def test_a_rejected_reversal_of_a_kept_pair_stays_a_negative():
    """_finish drops a rejection that is the SAME rule as a kept one (rejected as a duplicate). A reversed pair is not
    the same rule - its finding sits on the other line - so the reviewer's rejection of it is a real negative."""
    import pandas as pd
    book = {"review": pd.DataFrame([
        {"rule_id": "EXT-keep", "chapter": "14", "decision": "Approve", "reviewer": "SB", "extraction_key": "k",
         "predicate": json.dumps(PAIR), "verbatim_quote": Q},
        {"rule_id": "EXT-rev", "chapter": "14", "decision": "Reject", "reviewer": "SB", "extraction_key": "r",
         "predicate": json.dumps(REVERSED), "verbatim_quote": Q}])}
    rep = {}
    gold = regress.gold_from_workbook(book, report=rep)
    assert [(g["gold_id"], g["kind"]) for g in gold] == [("EXT-keep", "positive"), ("EXT-rev", "negative")]
    assert "reject_same_as_a_kept_rule" not in rep["excluded"]


# ------------------------------------------------------------------ M51-5: a different extra reading nobody reviewed
def test_a_narrower_different_extra_draft_is_an_unreviewed_executable_rule():
    cap8 = dict(CAP, threshold=8)
    summ, det = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                                [_draft("D2", CAP, key="k2", quote=QC), _draft("D3", cap8, key="k3", quote=QC)])
    by = {r["rule_id"]: r for r in det}
    assert by["D2"]["result"] == "exact"
    assert by["D3"]["result"] == "unreviewed_variant" and not by["D3"]["danger"] and by["D3"]["gold_id"] == "G2"
    t = summ["total"]
    assert (t["unmatched_compiled"], t["duplicate"], t["danger"]) == (1, 0, 0)
    ok, why = regress.ship_gate(summ)
    assert not ok and "1 new executable draft(s) have no reviewed decision" in why and "unreviewed_variant" in why


def test_an_identical_extra_draft_is_a_harmless_duplicate_and_a_wider_one_is_danger_once():
    summ, det = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                                [_draft("D2", CAP, key="k2", quote=QC), _draft("D3", dict(CAP), key="k3", quote=QC)])
    t = summ["total"]
    assert [r["result"] for r in det if r["rule_id"] == "D3"] == ["duplicate"]
    assert (t["duplicate"], t["unmatched_compiled"], t["danger"]) == (1, 0, 0) and regress.ship_gate(summ)[0]
    wide = dict(CAP, threshold=2)                                              # flags more: DANGER, counted once
    summ, det = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                                [_draft("D2", CAP, key="k2", quote=QC), _draft("D3", wide, key="k3", quote=QC)])
    t = summ["total"]
    d3 = [r for r in det if r["rule_id"] == "D3"][0]
    assert d3["result"] == "duplicate" and d3["danger"] and "threshold 2 < signed 4" in d3["danger_reasons"]
    assert (t["danger"], t["unmatched_compiled"]) == (1, 0)


def test_a_different_extra_lead_does_not_block():
    lead = {"type": "not_checkable", "reason": "requires_medical_record"}
    other = {"type": "not_checkable", "reason": "process_obligation"}
    summ, det = regress.compare([_gold("G4", "positive", lead, quote=QC, key="k4")],
                                [_draft("D4", lead, key="k4", quote=QC), _draft("D5", other, key="k5", quote=QC)])
    assert [r["result"] for r in det if r["rule_id"] == "D5"] == ["unreviewed_variant"]
    assert summ["total"]["unmatched_compiled"] == 0 and regress.ship_gate(summ)[0]
    # an age-scoped rule without an age condition stays a lead (regress.compiles): no block either
    cap8 = dict(CAP, threshold=8)
    summ, _ = regress.compare([_gold("G2", "positive", CAP, quote=QC, key="k2")],
                              [_draft("D2", CAP, key="k2", quote=QC),
                               _draft("D3", cap8, key="k3", quote=QC, pop="members under 21")])
    assert summ["total"]["unmatched_compiled"] == 0


# ------------------------------------------------------------------ M51-4: compare_runs carries each run's own gate
def test_compare_runs_reports_the_gate_it_is_given():
    gold = [_gold("G2", "positive", CAP, quote=QC, key="k2")]
    a = [_draft("D2", CAP, key="k2", quote=QC)]
    blocked = (False, "BLOCKED: 1 new executable draft(s) have no reviewed decision (chapter 4)")
    rows = regress.compare_runs(gold, a, a, labels=("A", "B"), gates=[blocked, (True, "OK: all chapters")])
    assert [r["ship_gate"] for r in rows] == ["BLOCKED", "OK"]
    assert rows[0]["ship_gate_reason"] == blocked[1] and rows[0]["unmatched_compiled"] == 0
    # without gates: the gate of the compared drafts, as before
    assert [r["ship_gate"] for r in regress.compare_runs(gold, a, None)] == ["OK"]
