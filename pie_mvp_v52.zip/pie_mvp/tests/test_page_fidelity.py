"""Page-level PDF fidelity (page_fidelity.py, notebooks/validation/v07_page_fidelity.py), 2026-10-04 external review:
"confirm what reaches the extractor against what a human sees in the PDF". Synthetic PDFs with planted layout defects:
each check must catch its defect and stay quiet on the clean twin. The sections always come from the pipeline's own
policy_docs.parse_pdf -> policy_docs.segment. Offline: no Spark, no model.
Run: cd pie_mvp && python3 -m pytest -q tests/test_page_fidelity.py -p no:cacheprovider
"""
import hashlib
import os
import sys

import pandas as pd
import pymupdf as fitz
import pytest

HERE = os.path.dirname(__file__)
PKG = os.path.dirname(HERE)
sys.path.insert(0, PKG)
sys.path.insert(0, HERE)

import config  # noqa: E402
import page_fidelity as pf  # noqa: E402
import policy_docs as pdx  # noqa: E402
import quality  # noqa: E402

HEADER = "04/29/2026 CHAPTER {ch} BEHAVIORAL HEALTH SERVICES {n} | {N}"


# ------------------------------------------------------------------ a small builder for ugly pages
def build(path, pages, ch="19", footer=None, footer_first=False):
    """One PDF page per item list, with the manual's running header at the top and bottom of every page (like
    tests/fixture_pdf.py). Items, laid out top to bottom:
        ("h", text)                    12pt bold line: a heading
        ("t", text)                    10pt line: body text, ONE physical line (so a test decides where lines break)
        ("small", text)                7pt line: a footnote
        ("gap", points)                move down
        ("at", x, y, text)             9pt line at a fixed place (two columns; content order = item order)
        ("table", widths, rows, order) a ruled grid; cells written row by row or "columns" (column by column); a "\\n"
                                       in a cell makes a two-line cell; order may be a dict {"order": ..., "after": pts
                                       below the bottom rule to the next item's baseline (default 20), "merge": {row: True}
                                       (one cell across the row, 12pt bold)}
    footer: a format string (n, N, ch) drawn at the bottom instead of the running header; footer_first: the footer is
    drawn BEFORE the page body, so it comes first in the PDF's content order (Word does this).
    """
    doc = fitz.open()
    for n, items in enumerate(pages, 1):
        pg = doc.new_page(width=612, height=792)
        foot = (footer or HEADER).format(ch=ch, n=n, N=len(pages))
        if footer_first:
            pg.insert_text((40, 770), foot, fontsize=8, fontname="helv")
        pg.insert_text((40, 40), HEADER.format(ch=ch, n=n, N=len(pages)), fontsize=8, fontname="helv")
        y = 80
        for it in items:
            if it[0] == "h":
                pg.insert_text((40, y), it[1], fontsize=12, fontname="hebo")
                y += 20
            elif it[0] == "t":
                pg.insert_text((40, y), it[1], fontsize=10, fontname="helv")
                y += 15
            elif it[0] == "small":
                pg.insert_text((40, y), it[1], fontsize=7, fontname="helv")
                y += 11
            elif it[0] == "gap":
                y += it[1]
            elif it[0] == "at":
                pg.insert_text((it[1], it[2]), it[3], fontsize=9, fontname="helv")
            elif it[0] == "table":
                _, widths, rows, order = it
                opts = order if isinstance(order, dict) else {"order": order}
                merge = opts.get("merge") or {}
                xs = [40]
                for w in widths:
                    xs.append(xs[-1] + w)
                ys = [y]                                   # row tops: 18pt a row, 12pt more per extra line in a cell
                for row in rows:
                    ys.append(ys[-1] + 18 + 12 * max(cell.count("\n") for cell in row))
                cells = [(r, c) for r in range(len(rows)) for c in range(len(widths)) if not (merge.get(r) and c)]
                if opts.get("order") == "columns":
                    cells = sorted(cells, key=lambda rc: (rc[1], rc[0]))
                for r, c in cells:
                    big = bool(merge.get(r))
                    pg.insert_text((xs[c] + 3, ys[r] + 13), rows[r][c], fontsize=12 if big else 10,
                                   fontname="hebo" if big else "helv")
                for yy in ys:
                    pg.draw_line((xs[0], yy), (xs[-1], yy))
                for r in range(len(rows)):                 # a merged row has no inner column rules
                    for c, x in enumerate(xs):
                        if not (merge.get(r) and 0 < c < len(xs) - 1):
                            pg.draw_line((x, ys[r]), (x, ys[r + 1]))
                y = ys[-1] + opts.get("after", 20)
        if not footer_first:
            pg.insert_text((40, 770), foot, fontsize=8, fontname="helv")
    doc.save(path)
    doc.close()
    return path


def checks(path, doc_id="19"):
    """{page: page_checks record} for every page of a synthetic PDF."""
    doc = pf.load_document(doc_id, path=str(path))
    return doc, {p: pf.page_checks(doc, p) for p in range(1, len(doc["pages"]) + 1)}


def flags(rec, check=None, severity="flag"):
    return [f for f in rec["flags"] if (check is None or f["check"] == check) and f["severity"] == severity]


def without_table_positions(monkeypatch):
    """Plant the pre-2026-10-04 table handling: parse_pdf without table positions, so segment() files a page's tables
    at the END of the page and cannot tell a table cell from a heading."""
    real = pdx.parse_pdf

    def parse(path):
        pages = real(path)
        for pg in pages:
            pg.pop("table_bboxes", None)
        return pages

    monkeypatch.setattr(pdx, "parse_pdf", parse)


CRISIS = [("h", "CRISIS SERVICES"), ("t", "Crisis services must be billed per encounter.")]
PAGE2 = [("t", "Crisis teams must document the encounter.")]
S5151 = "NOTE: Providers are prohibited from billing S5151 with H0001, H0002, H0004, H0006, H0018"
LIST_MID = "H0025, H0034, H0036, H2012, H2014, H2015, H2017, H2019, H2025, H2027, H2033, S5150. T1019. H0031,"
LIST_END = "H0038, H0030 or any other per diem code on the same day."


# ------------------------------------------------------------------ same code path as 04
def test_sections_are_the_pipelines_own_and_a_clean_chapter_has_no_flag(tmp_path):
    import fixture_pdf
    path = fixture_pdf.build(str(tmp_path / "fx.pdf"))
    doc, recs = checks(path, "10")
    digest = hashlib.sha256(open(path, "rb").read()).hexdigest()
    secs, meta = pdx.segment(pdx.parse_pdf(path), "10", digest)
    assert doc["doc_hash"] == digest and doc["sections"] == secs and doc["meta"] == meta
    assert all(r["n_flags"] == 0 for r in recs.values()), {p: r["flags"] for p, r in recs.items()}
    # every body line of every page was found in its section, in order; the headers were stripped as segment() does
    for p, r in recs.items():
        assert {x["status"] for x in r["lines"]} <= {"header", "revision", "heading", "body"}
        assert all(not x["out_of_sequence"] for x in r["lines"])
    p2 = recs[2]
    assert [v["heading"] for v in p2["sections"]] == ["COMMUNITY HEALTH WORKER SERVICES", "FAMILY PLANNING SERVICES",
                                                      "ANESTHESIA SERVICES"]
    assert all(v["reaches_model"] for v in p2["sections"])
    assert not recs[3]["sections"][-1]["reaches_model"]           # PROVIDER RESPONSIBILITIES: no rule signal


# ------------------------------------------------------------------ (d1) a code on the page that never reaches the extractor
def test_exhibit_rows_that_differ_only_in_their_codes_reach_the_extractor(tmp_path):
    """Found by this check on 2026-10-04 and fixed in policy_docs.find_headers / segment: a 2-page code table whose rows
    differ only in their codes ("A4206 Syringe with needle" / "A4207 Syringe with needle") is equal once digits are
    removed, and was stripped as a running header - A4206 and A4207 never reached the extractor. A line naming a
    procedure code is never a running header now."""
    path = build(tmp_path / "exh.pdf", [
        [("h", "MEDICAL SUPPLIES INCLUDED IN THE PER DIEM"), ("t", "The following supplies are included in the per diem rate."),
         ("t", "A4206 Syringe with needle"), ("t", "A4215 Needle, sterile, any size")],
        [("t", "A4207 Syringe with needle"), ("t", "A4927 Gloves, non-sterile, per 100")]], ch="22")
    _, recs = checks(path, "22-2")
    assert recs[1]["codes_missing"] == [] and recs[2]["codes_missing"] == []
    assert not flags(recs[1], "code_missing") and not flags(recs[2], "code_missing")
    assert not any(x["status"] == "header" and x["text"].startswith("A42") for x in recs[1]["lines"])
    # the real running header (date, chapter, page counter) is still stripped
    assert any(x["status"] == "header" and "CHAPTER 22" in x["text"] for x in recs[1]["lines"])


def test_lines_that_differ_only_in_their_numbers_are_content_unless_they_sit_where_headers_do(tmp_path):
    """Critic P51-9: find_headers() compared EVERY line with its digits removed, so on a short document a limit that
    differs from page to page only in its number ("Maximum: 4 units per day." / "Maximum: 16 units per day.", or two
    table cells "4 units per day" / "16 units per day") was a 'running header' and stripped - the limits never reached
    the extractor as text. With positions (PyMuPDF), only a line in the top or bottom band of the page
    (policy_docs.HEADER_BAND) and outside every grid row may be a running header; without them (pypdf) every line, as
    before."""
    def cells(limit):
        return ("table", [80, 160], [("Code", "Limit"), ("T1016", limit)], "rows")

    path = build(tmp_path / "nums.pdf", [
        [("h", "CASE MANAGEMENT"), ("t", "Case management T1016 is limited as follows."), ("t", "Maximum: 4 units per day."),
         ("gap", 575), cells("4 units per day")],                # the grid in the bottom band of the page
        [("t", "Respite S5150 is limited as follows."), ("t", "Maximum: 16 units per day."), ("gap", 595),
         cells("16 units per day")]])
    pages = pdx.parse_pdf(str(path))
    headers, _ = pdx.find_headers(pages)
    assert not any("units per day" in h for h in headers), headers
    assert not {"code", "limit", "t1016"} & headers                    # cells that repeat on both pages, codes included
    assert pages[0]["height"] == 792.0
    assert all(pg["table_bboxes"][0][1] > (1 - pdx.HEADER_BAND) * 792 for pg in pages)
    doc, recs = checks(path)
    text = doc["sections"][0]["text"]
    assert "Maximum: 4 units per day." in text and "Maximum: 16 units per day." in text
    assert text.count(" 4 units per day") == text.count("16 units per day") == 3     # 'Maximum: ...', the cell, the copy
    assert all(r["n_flags"] == 0 for r in recs.values()), {p: r["flags"] for p, r in recs.items()}
    # the running header (top and bottom of every page) is still stripped
    assert all([x["status"] for x in r["lines"]][0] == "header" == [x["status"] for x in r["lines"]][-1]
               for r in recs.values())
    # without positions (pypdf): every line is a candidate, as before
    plain = [{"page": p["page"], "tables": [], "lines": [{"text": ln["text"], "size": 0.0, "bold": False}
                                                         for ln in p["lines"]]} for p in pages]
    headers, _ = pdx.find_headers(plain)
    assert pdx._header_key("Maximum: 4 units per day.") in headers and pdx._header_key("4 units per day") in headers


def test_any_line_segment_loses_is_flagged(tmp_path, monkeypatch):
    """Planted through the pipeline itself: a segment() that drops one line. The check reads the sections as they are,
    so the lost line and its code show up whatever the cause."""
    path = build(tmp_path / "drop.pdf", [[("h", "PEER SUPPORT"), ("t", "Peer support H0038 is billed per 15 minutes."),
                                          ("t", "Do not bill H0038 with H0039 on the same day."), ("t", "Notes are required.")]
                                         + CRISIS, PAGE2])
    real = pdx.segment

    def lossy(pages, chapter, doc_hash):
        secs, meta = real(pages, chapter, doc_hash)
        for s in secs:
            s["text"] = s["text"].replace("Do not bill H0038 with H0039 on the same day.\n", "")
        return secs, meta

    monkeypatch.setattr(pdx, "segment", lossy)
    _, recs = checks(path)
    assert recs[1]["codes_missing"] == ["H0039"]                   # H0038 still reaches it from the line above
    assert flags(recs[1], "code_missing")[0]["codes"] == ["H0039"]
    lost = flags(recs[1], "text_missing")
    assert len(lost) == 1 and "Do not bill H0038 with H0039" in lost[0]["detail"]
    monkeypatch.setattr(pdx, "segment", real)
    _, clean = checks(path)
    assert clean[1]["n_flags"] == 0


# ------------------------------------------------------------------ (d2) a code list cut into two sentences
def test_stray_period_inside_a_list_passes_now_and_is_caught_without_code_list_break(tmp_path, monkeypatch):
    """Ch.19 p.31: '... H2033, S5150. T1019. H0031, H0038, H0030 or any other per diem code'. With
    policy_docs.code_list_break the list is one sentence (no flag); with it switched off the splitter cuts it twice and
    the check must say so - this is how the original loss would have been caught."""
    path = build(tmp_path / "s5151.pdf", [[("h", "PER DIEM SERVICES"), ("t", S5151), ("t", LIST_MID), ("t", LIST_END)]
                                          + CRISIS, PAGE2])
    _, recs = checks(path)
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    monkeypatch.setattr(pdx, "code_list_break", lambda before, after: False)
    _, recs = checks(path)
    f = flags(recs[1], "code_list_split")
    assert len(f) == 1 and recs[1]["n_flags"] == 1
    assert len(f[0]["codes"]) == 21 and {"S5150", "T1019", "H0031", "H0038", "H0030"} <= set(f[0]["codes"])
    assert "'S5150. T1019'" in f[0]["detail"] and "'T1019. H0031'" in f[0]["detail"]
    assert "cut into 3 sentences" in f[0]["detail"]
    v = recs[1]["sections"][0]
    assert v["heading"] == "PER DIEM SERVICES" and len(v["breaks"]) == 2
    assert v["text"][v["breaks"][0]:].startswith("T1019. H0031")      # the bar goes where the new sentence starts


def test_stray_period_at_the_end_of_a_pdf_line_does_not_cut_the_list(tmp_path, monkeypatch):
    """The same list with 'S5150.' as the LAST word of a physical line. Found by this check on 2026-10-04: _join_lines
    ended the paragraph there, so T1019, H0031, H0038, H0030 were cut off from S5151 even with code_list_break in
    place. _join_lines now asks code_list_break too; with it switched off the cut (and the flag) come back."""
    mid = LIST_MID.rsplit(" T1019.", 1)[0]                                    # "... H2033, S5150."
    path = build(tmp_path / "s5151_eol.pdf", [[("h", "PER DIEM SERVICES"), ("t", S5151), ("t", mid),
                                               ("t", "T1019. H0031, " + LIST_END)] + CRISIS, PAGE2])
    _, recs = checks(path)
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    text = recs[1]["sections"][0]["text"]
    assert "S5150. T1019. H0031, H0038" in text                    # the two physical lines joined into one paragraph
    assert len(pdx.sentences(text)) == 1 and text.startswith("NOTE: Providers are prohibited from billing S5151")
    monkeypatch.setattr(pdx, "code_list_break", lambda before, after: False)      # planted: the old splitter
    _, recs = checks(path)
    f = flags(recs[1], "code_list_split")
    assert len(f) == 1, recs[1]["flags"]
    # the line end now ends the paragraph ('\n' in the text), and the in-line 'T1019.' ends a sentence as well
    assert "S5150.\nT1019" in recs[1]["sections"][0]["text"]
    assert "cut into 3 sentences" in f[0]["detail"]
    assert "'S5150.\\nT1019'" in f[0]["detail"] and "'T1019. H0031'" in f[0]["detail"]
    assert f[0]["detail"].endswith("S5150 | T1019 | H0031, H0038, H0030")
    assert pdx.sentences(recs[1]["sections"][0]["text"])[-1].startswith("H0031, H0038, H0030")


def test_a_wrapped_bullet_with_a_stray_period_keeps_its_list(tmp_path):
    """Critic P51-7, on a page: a bullet ending '... H2033, S5150.' with 'T1019. H0031, H0038 ...' on the next physical
    line. The check flagged the cut (code_list_split); _join_lines now keeps the bullet's list whole, so no flag."""
    path = build(tmp_path / "bullet.pdf", [[("h", "PER DIEM SERVICES"), ("t", "The following limits apply:"),
                                            ("t", "• Providers are prohibited from billing S5151 with H0001, H0002, H2033, S5150."),
                                            ("t", "T1019. H0031, H0038 or any other per diem code on the same day."),
                                            ("t", "• Crisis services must be billed per encounter.")], CRISIS])
    _, recs = checks(path)
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    text = recs[1]["sections"][0]["text"]
    lines = text.split("\n")
    assert len(lines) == 3 and lines[1].endswith("S5150. T1019. H0031, H0038 or any other per diem code on the same day.")
    assert len(pdx.sentences(lines[1])) == 1


def test_a_list_in_a_two_line_table_cell(tmp_path):
    """The row copy segment() appends keeps a cell's line break ('H0018, H0014,' / 'H0015'), so the splitter cuts the
    cell's list there. The same cells read as lines stay one list, so the cut is shown (info), not counted."""
    rows = [("Code", "Not with"), ("T1016", "H0018, H0014,\nH0015"), ("H0031", "H0038")]
    _, recs = checks(build(tmp_path / "cell.pdf", [[("h", "CASE MANAGEMENT"),
                                                    ("t", "The codes below cannot be billed on the same day."),
                                                    ("table", [100, 200], rows, "rows"), ("t", "Providers must keep records.")],
                                                   PAGE2]))
    v = recs[1]["sections"][0]
    a, b = v["tables"][0]
    assert "H0018, H0014,\nH0015" in v["text"][a:b] and "H0018, H0014, H0015" in v["text"][v["slice"][0]:v["slice"][1]]
    cut = flags(recs[1], "code_list_split", "info")
    assert recs[1]["n_flags"] == 0 and len(cut) == 1
    assert "table row copy" in cut[0]["detail"] and "keeps this list whole" in cut[0]["detail"]
    assert cut[0]["codes"] == ["H0018", "H0014", "H0015"]


def test_code_lists_as_a_reader_sees_them():
    note = S5151 + " " + LIST_MID + " " + LIST_END
    lists = pf.code_lists(note)                        # S5151 is the hub ("billing S5151 with ..."), not a list item
    assert len(lists) == 1 and len(lists[0]["codes"]) == 21
    assert lists[0]["codes"][0] == "H0001" and lists[0]["codes"][-3:] == ["H0031", "H0038", "H0030"]
    assert pf.code_lists("Do not bill 99070. H2014 requires prior authorization.") == []          # two sentences
    assert pf.code_lists("Do not bill 99070, 99071. H2014 requires prior authorization.")[0]["codes"] == ["99070", "99071"]
    assert pf.code_lists("H0031 (assessment), H0038 (peer support) and H0030 apply.")[0]["codes"] == ["H0031", "H0038", "H0030"]
    assert pf.code_lists("Codes 99201-99205, 99211 through 99215 apply.")[0]["codes"] == ["99201", "99205", "99211", "99215"]
    assert pf.code_lists("T1016 | 4 units per day | H0018, H0014")[0]["codes"] == ["H0018", "H0014"]   # cells are not a list
    assert pf.code_lists("Not covered:\n• H0031\n• H0038") == []          # a bullet list is cut on purpose, one per line
    # a list the splitter keeps whole is not reported; one it cuts is, with where
    assert pf.split_code_lists("Bill H0031, H0038. H0030, H0039 on the same day.") == []
    cut = pf.split_code_lists("Bill H0031, H0038;\nH0030, H0039 on the same day.")
    assert len(cut) == 1 and cut[0]["sentences"] == [["H0031", "H0038"], ["H0030", "H0039"]]
    assert pf.code_lists("Not with H0018, H0014,\nH0015\nH0031 | H0038")[0]["codes"] == ["H0018", "H0014", "H0015"]
    assert pf.code_lists("Bill H0031, H0038.\nH0030 Crisis services are per diem.")[0]["codes"] == ["H0031", "H0038"]


FINE_STOPS = ["Do not bill H0031. H0038 and H0039 are covered when medically necessary.",
              "Providers must bill E/M with 99201-99205. 99211, 99212 are covered without PA.",
              "Bill H0031/H0038. H0039, H0040 require prior authorization.",
              "Bill S5151 with H0001, H0002. H0004 or H0006 require prior authorization."]


def test_a_period_after_a_lone_code_a_range_or_a_pair_ends_the_list(tmp_path):
    """Critic P51-6: code_lists() let a '.' between two codes continue a list whenever the code after it was followed by
    a list mark, so 'Do not bill H0031. H0038 and H0039 ...' was one list cut in two and flagged (code_list_split) on a
    page that reads fine. A list goes on across a '.' only as policy_docs.code_list_break (critic P51-4) reads one: the
    code before the stop is a comma-list item (or the stop follows another stray period) and the code after it is followed
    by ',' or '.'. The Ch.19 stray periods are still inside one list (test_code_lists_as_a_reader_sees_them)."""
    assert [x["codes"] for x in pf.code_lists(FINE_STOPS[0])] == [["H0038", "H0039"]]
    assert [x["codes"] for x in pf.code_lists(FINE_STOPS[1])] == [["99211", "99212"]]   # a range alone is no list
    assert [x["codes"] for x in pf.code_lists(FINE_STOPS[2])] == [["H0031", "H0038"], ["H0039", "H0040"]]
    assert [x["codes"] for x in pf.code_lists(FINE_STOPS[3])] == [["H0001", "H0002"], ["H0004", "H0006"]]
    assert all(pf.split_code_lists(t) == [] for t in FINE_STOPS)
    # the same sentences on a page: no flag
    _, recs = checks(build(tmp_path / "stops.pdf", [[("h", "BILLING LIMITS")] + [("t", t) for t in FINE_STOPS] + CRISIS,
                                                     PAGE2]))
    assert recs[1]["n_flags"] == 0 and not flags(recs[1], "code_list_split", "info"), recs[1]["flags"]
    # still one list: a stray period after a comma-list item, and a chain of them
    assert pf.code_lists("Bill S5151 with H0001, H0002. H0004, H0006 on the same day.")[0]["codes"] == \
        ["H0001", "H0002", "H0004", "H0006"]
    assert len(pf.code_lists("with H2027, H2033, S5150. T1019. H0031, H0038")[0]["codes"]) == 6


# ------------------------------------------------------------------ (d3) text given to a later heading
def test_a_table_is_filed_under_the_heading_open_where_it_is(tmp_path, monkeypatch):
    """A ruled table under CASE MANAGEMENT, then the CRISIS SERVICES heading on the same page. Found by this check on
    2026-10-04: segment() appended a page's tables to the section open at the END of the page, so the row copy landed
    under CRISIS. segment() now files a table where it starts on the page (parse_pdf keeps its position); without the
    positions (planted) the old misfiling and its flag come back."""
    table = ("table", [80, 140, 140], [("Code", "Limit", "Not with"), ("T1016", "4 units per day", "H0018, H0014"),
                                       ("H0031", "1 per day", "H0038, H0030")], "rows")
    path = build(tmp_path / "tbl.pdf", [[("h", "CASE MANAGEMENT"), ("t", "Case management is billed as shown below."), table]
                                        + CRISIS, PAGE2])
    _, recs = checks(path)
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    case = next(v for v in recs[1]["sections"] if v["heading"] == "CASE MANAGEMENT")
    a, b = case["tables"][0]
    assert case["text"][a:b].startswith("Code | Limit | Not with\nT1016 | 4 units per day")
    without_table_positions(monkeypatch)
    _, recs = checks(path)
    f = flags(recs[1], "later_heading")
    assert len(f) == 1 and recs[1]["n_flags"] == 1
    assert "appended to 'CRISIS SERVICES'" in f[0]["detail"] and "first row 'Code | Limit | Not with'" in f[0]["detail"]
    assert {"T1016", "H0018", "H0014", "H0031", "H0038", "H0030"} == set(f[0]["codes"])
    crisis = next(v for v in recs[1]["sections"] if v["heading"] == "CRISIS SERVICES")
    a, b = crisis["tables"][0]
    assert crisis["text"][a:b].startswith("Code | Limit | Not with\nT1016 | 4 units per day")
    assert recs[1]["codes_missing"] == []                         # nothing lost - it went to the wrong place
    # clean twin: the same table with no heading after it on the page -> its own section keeps the row copy
    monkeypatch.undo()
    path = build(tmp_path / "tbl_ok.pdf", [[("h", "CASE MANAGEMENT"), ("t", "Case management is billed as shown below."),
                                            table, ("t", "Providers must keep records.")], CRISIS])
    _, recs = checks(path)
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    assert recs[1]["tables"][0]["section"] == 0 and recs[1]["sections"][0]["tables"]


PEER_COPY = "Code | Limit\nT1016 | 4 per day\nH0031 | 1 per day"


def two_column_page(path):
    """Page 1 in two columns: CASE MANAGEMENT and CRISIS SERVICES on the left; PEER SUPPORT on the right, with a ruled
    table whose top (y 300) lies above the left column's last lines. Page 2: one line."""
    doc = fitz.open()
    for n in (1, 2):
        pg = doc.new_page(width=612, height=792)
        pg.insert_text((40, 40), HEADER.format(ch="19", n=n, N=2), fontsize=8, fontname="helv")
        if n == 1:
            for x, items in ((40, [("h", "CASE MANAGEMENT"), ("t", "Case management T1016 is billed per 15 minutes."),
                                   ("t", "Notes are kept."), ("gap", 160), ("h", "CRISIS SERVICES"),
                                   ("t", "Crisis services H2011 require prior authorization."),
                                   ("t", "Crisis teams must document."), ("gap", 160),
                                   ("t", "Crisis follow-up within 72 hours.")]),
                             (320, [("h", "PEER SUPPORT"), ("t", "Peer support is limited as shown"),
                                    ("t", "in the table below.")])):
                y = 80
                for kind, text in items:
                    if kind == "gap":
                        y += text
                        continue
                    pg.insert_text((x, y), text, fontsize=12 if kind == "h" else 9, fontname="hebo" if kind == "h" else "helv")
                    y += 20 if kind == "h" else 14
            xs, ys = [320, 400, 560], [300, 318, 336, 354]
            for r, row in enumerate([("Code", "Limit"), ("T1016", "4 per day"), ("H0031", "1 per day")]):
                for c, cell in enumerate(row):
                    pg.insert_text((xs[c] + 3, ys[r] + 13), cell, fontsize=9, fontname="helv")
            for yy in ys:
                pg.draw_line((xs[0], yy), (xs[-1], yy))
            for x in xs:
                pg.draw_line((x, ys[0]), (x, ys[-1]))
            pg.insert_text((320, 400), "Peer notes are required.", fontsize=9, fontname="helv")
        else:
            pg.insert_text((40, 80), "Page two text continues the peer support section.", fontsize=10, fontname="helv")
        pg.insert_text((40, 770), HEADER.format(ch="19", n=n, N=2), fontsize=8, fontname="helv")
    doc.save(path)
    doc.close()
    return path


def test_a_table_is_filed_where_its_own_first_line_is(tmp_path):
    """Critic P51-3: segment() filed a table at the first line (in the PDF's reading order) whose top lay below the
    table's top. On a two-column page that is a line of the LEFT column, so the right column's table went under CRISIS
    SERVICES; on a page whose footer is drawn before the body (Word) it is the footer - the table went to the section
    open at the end of the previous page. A table (each run of its grid rows) is filed where its OWN first line is now."""
    doc, recs = checks(two_column_page(tmp_path / "two.pdf"))
    assert [s["heading"] for s in doc["sections"]] == ["CASE MANAGEMENT", "CRISIS SERVICES", "PEER SUPPORT"]
    assert doc["sections"][2]["text"].endswith(PEER_COPY) and " | " not in doc["sections"][1]["text"]
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    # a bare page number as the footer, drawn before the body
    pages = [[("h", "CASE MANAGEMENT"), ("t", "Case management is billed per 15 minutes."), ("h", "PEER SUPPORT"),
              ("t", "Peer support is limited as shown below."), ("table", [80, 160, 140], TABLE3, "rows"),
              ("t", "Peer notes are required.")],
             [("h", "RESPITE"), ("t", "Respite is limited as below."),
              ("table", [80, 160, 140], [TABLE3[0], ("S5150", "16 units per day", "S5151")], "rows")]]
    doc, recs = checks(build(tmp_path / "foot_first.pdf", pages, footer="{n}", footer_first=True))
    copies = {s["heading"]: s["text"][s["text"].index(" | ") - 4:] for s in doc["sections"] if " | " in s["text"]}
    assert set(copies) == {"PEER SUPPORT", "RESPITE"}, copies
    assert "T1016 | 4 units per day" in copies["PEER SUPPORT"] and "S5150 | 16 units per day" in copies["RESPITE"]
    assert all(r["n_flags"] == 0 for r in recs.values()), {p: r["flags"] for p, r in recs.items()}


def test_a_row_copy_under_an_earlier_heading_is_flagged(tmp_path, monkeypatch):
    """Critic P51-3, the check: later_heading caught a row copy filed under a heading that comes AFTER the table, not one
    filed under an EARLIER heading than the one open where the table starts. Planted through the pipeline: a segment()
    that moves the right column's row copy to CRISIS SERVICES (what the pre-P51 filing did on this page)."""
    path = two_column_page(tmp_path / "two.pdf")
    real = pdx.segment

    def misfiled(pages, chapter, doc_hash):
        secs, meta = real(pages, chapter, doc_hash)
        for s in secs:                                  # wherever segment() put it ...
            s["text"] = s["text"].replace("\n" + PEER_COPY, "")
        crisis = next(s for s in secs if s["heading"] == "CRISIS SERVICES")
        crisis["text"] += "\n" + PEER_COPY              # ... it goes to CRISIS SERVICES
        return secs, meta

    monkeypatch.setattr(pdx, "segment", misfiled)
    _, recs = checks(path)
    f = flags(recs[1], "later_heading")
    assert len(f) == 1 and recs[1]["n_flags"] == 1, recs[1]["flags"]
    assert "appended to 'CRISIS SERVICES'" in f[0]["detail"] and "under 'PEER SUPPORT'" in f[0]["detail"]
    assert set(f[0]["codes"]) == {"T1016", "H0031"}


def test_a_table_header_cell_is_never_a_heading(tmp_path, monkeypatch):
    """ALL-CAPS column headers ("CODE  DESCRIPTION  LIMIT"). Found by this check on 2026-10-04: segment() took the cell
    row for a heading, so the rows went under it and the lead-in sentence was left alone (and skipped by the pre-filter).
    A line inside a table's box is table content now; without the positions (planted) the old split comes back."""
    rows = [("CODE", "DESCRIPTION", "LIMIT"), ("E0100", "Cane", "1 per year"), ("E0105", "Cane, quad", "1 per 5 years")]
    path = build(tmp_path / "caps.pdf", [[("h", "DURABLE MEDICAL EQUIPMENT"), ("t", "The following items are limited as shown:"),
                                          ("table", [80, 160, 120], rows, "rows"), ("t", "Repairs require prior authorization.")],
                                         PAGE2], ch="13")
    _, recs = checks(path, "13")
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    assert [v["heading"] for v in recs[1]["sections"]] == ["DURABLE MEDICAL EQUIPMENT"]
    assert recs[1]["sections"][0]["reaches_model"]
    without_table_positions(monkeypatch)
    _, recs = checks(path, "13")
    f = flags(recs[1], "heading_in_table")
    assert len(f) == 1 and "'CODE DESCRIPTION LIMIT'" in f[0]["detail"]
    assert [v["heading"] for v in recs[1]["sections"]] == ["DURABLE MEDICAL EQUIPMENT", "CODE DESCRIPTION LIMIT"]
    assert not recs[1]["sections"][0]["reaches_model"]           # the lead-in sentence is skipped by the pre-filter


def test_a_heading_in_a_one_row_box_stays_a_heading(tmp_path):
    """find_tables() also reads a ruled box split by one vertical line as a 1-row, 2-column "table". Probe 2026-10-04:
    with every in-table line treated as table content, both headings inside such a box were lost and the page became
    one PREAMBLE section. Only a real grid (2+ rows, 2+ filled cells in a row) now makes its lines table content, and
    only a grid gets a row copy (a box's lines are in the text already). The check says 'check by eye' (info)."""
    doc = fitz.open()
    for n in (1, 2):
        pg = doc.new_page(width=612, height=792)
        pg.insert_text((40, 40), HEADER.format(ch="19", n=n, N=2), fontsize=8, fontname="helv")
        if n == 1:
            pg.draw_rect(fitz.Rect(35, 65, 577, 160))
            pg.draw_line((300, 65), (300, 160))
            for y, size, font, text in ((80, 12, "hebo", "CASE MANAGEMENT"),
                                        (100, 10, "helv", "Case management T1016 is billed per 15 minutes."),
                                        (115, 10, "helv", "T1016 cannot be billed with H0018 on the same day."),
                                        (155, 12, "hebo", "CRISIS SERVICES"),
                                        (175, 10, "helv", "Crisis services H2011 must be billed per 15 minutes.")):
                pg.insert_text((40, y), text, fontsize=size, fontname=font)
        else:
            pg.insert_text((40, 80), "Crisis teams must document the encounter.", fontsize=10, fontname="helv")
        pg.insert_text((40, 770), HEADER.format(ch="19", n=n, N=2), fontsize=8, fontname="helv")
    path = tmp_path / "box.pdf"
    doc.save(path)
    doc.close()
    pages = pdx.parse_pdf(str(path))
    assert [len(t) for t in pages[0]["tables"]] == [1] and not pdx.is_grid(pages[0]["tables"][0])
    secs, _ = pdx.segment(pages, "19", "h")
    assert [s["heading"] for s in secs] == ["CASE MANAGEMENT", "CRISIS SERVICES"]
    assert " | " not in secs[0]["text"] and secs[0]["text"].count("T1016 cannot be billed") == 1     # no row copy
    doc, recs = checks(path)
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    assert {f["check"] for f in recs[1]["flags"] if f["severity"] == "info"} >= {"heading_in_table"}
    box = doc["loc"]["tables"][1][0]
    assert box["copy"] is False and box["section"] is None and box["span"] is None     # no row copy to look for


TABLE3 = [("Code", "Limit", "Not with"), ("T1016", "4 units per day", "H0018, H0014"), ("H0031", "1 per day", "H0038, H0030")]


def _line(text, y0, y1, x0=72.1, x1=300.0, size=10.0, bold=False):
    return {"text": text, "size": size, "bold": bold, "x0": x0, "y0": y0, "x1": x1, "y1": y1}


def test_a_heading_right_under_a_table_is_a_heading(tmp_path):
    """Critic P51-1: segment() took a line for table content when its TOP was within 1pt of a grid's box. The line box of
    a 12pt heading set right under a table (Word's Normal style: no space before) starts at - or a little above - the
    bottom rule, so CRISIS SERVICES became a line of the table and its section merged into CASE MANAGEMENT. A line is
    table content when its CENTRE lies inside a grid row now."""
    for after in (8, 10, 12):                         # points from the bottom rule to the heading's baseline
        path = build(tmp_path / f"after{after}.pdf", [[("h", "CASE MANAGEMENT"), ("t", "Case management is billed as shown below."),
                                                       ("table", [80, 160, 140], TABLE3, {"after": after}),
                                                       ("h", "CRISIS SERVICES"),
                                                       ("t", "Crisis services H2011 must be billed per encounter.")], PAGE2])
        doc, recs = checks(path)
        assert [s["heading"] for s in doc["sections"]] == ["CASE MANAGEMENT", "CRISIS SERVICES"], after
        case, crisis = doc["sections"]
        assert case["text"].count("T1016 | 4 units per day | H0018, H0014") == 1 and " | " not in crisis["text"]
        assert crisis["text"].startswith("Crisis services H2011") and crisis["has_rule_signal"]
        assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    # the geometry Word writes (the reproduction): the bottom rule at 164.0, the heading's line box from 163.2
    cells = [_line("Code", 125.9, 137.1, 72.1, 96.0), _line("Limit", 125.9, 137.1, 228.1, 249.2),
             _line("Not with", 125.9, 137.1, 384.1, 420.0), _line("T1016", 139.6, 150.8, 72.1, 100.4),
             _line("4 units per day", 139.6, 150.8, 228.1, 293.6), _line("H0018, H0014", 139.6, 150.8, 384.1, 448.6),
             _line("H0031", 151.6, 162.8, 72.1, 101.6), _line("1 per day", 151.6, 162.8, 228.1, 269.8),
             _line("H0038, H0030", 151.6, 162.8, 384.1, 448.6)]
    page = {"page": 1, "width": 612.0, "height": 792.0, "tables": [[list(r) for r in TABLE3]],
            "lines": [_line("CASE MANAGEMENT", 84.4, 97.8, size=12.0, bold=True),
                      _line("Case management T1016 is billed as shown below.", 106.2, 117.4)] + cells
                     + [_line("CRISIS SERVICES", 163.2, 176.6, x1=176.0, size=12.0, bold=True),
                        _line("Crisis services H2011 must be billed per encounter.", 185.0, 196.2)],
            "table_bboxes": [(66.6, 125.3, 534.6, 164.0)],
            "table_rows": [[(66.6, 125.3, 534.6, 138.2), (66.6, 138.2, 534.6, 151.1), (66.6, 151.1, 534.6, 164.0)]]}
    for pg in (page, {k: v for k, v in page.items() if k != "table_rows"}):         # with and without row boxes
        secs, _ = pdx.segment([pg], "19", "h")
        assert [s["heading"] for s in secs] == ["CASE MANAGEMENT", "CRISIS SERVICES"]
        assert secs[0]["text"].endswith("Code | Limit | Not with\nT1016 | 4 units per day | H0018, H0014\n"
                                         "H0031 | 1 per day | H0038, H0030")


EXHIBIT = [("HOME HEALTH SERVICES", "", ""), ("G0151", "Physical therapy in the home", "1 per day"),
           ("G0152", "Occupational therapy in the home", "1 per day"), ("HOSPICE SERVICES", "", ""),
           ("Q5001", "Hospice care in the home", "1 per day"), ("Q5002", "Hospice care in assisted living", "1 per day")]


def test_a_merged_row_of_a_grid_is_text_and_may_be_a_heading(tmp_path):
    """Critic P51-5: every line inside a grid's box was table content, so a full-width merged row of an exhibit grid
    ("HOME HEALTH SERVICES") - a real heading - was lost and all the rows reached the extractor under the exhibit's
    heading. parse_pdf keeps each table's row boxes now; only a line inside a row of 2+ cells is table content, and a
    merged row (one cell across the table) is text. Each run of grid rows between merged rows is its own row copy
    (policy_docs.table_pieces), filed where its first line is."""
    path = build(tmp_path / "merged.pdf", [[("h", "EXHIBIT SERVICES"), ("t", "The codes below are limited as shown."),
                                            ("table", [80, 220, 100], EXHIBIT, {"merge": {0: True, 3: True}})], PAGE2])
    doc, recs = checks(path)
    assert [s["heading"] for s in doc["sections"]] == ["EXHIBIT SERVICES", "HOME HEALTH SERVICES", "HOSPICE SERVICES"]
    rows = doc["pages"][0]["table_rows"][0]
    assert [r is None for r in rows] == [True, False, False, True, False, False]       # the merged rows
    home, hospice = doc["sections"][1:]
    assert home["text"].endswith("G0151 | Physical therapy in the home | 1 per day\n"
                                 "G0152 | Occupational therapy in the home | 1 per day") and "Q5001" not in home["text"]
    assert hospice["text"].endswith("Q5001 | Hospice care in the home | 1 per day\n"
                                    "Q5002 | Hospice care in assisted living | 1 per day")
    assert "HOME HEALTH SERVICES |" not in "\n".join(s["text"] for s in doc["sections"])
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]
    assert [t["section"] for t in recs[1]["tables"]] == [1, 2]                            # one row copy per run


def test_a_grid_row_with_one_filled_cell_is_still_table_content(tmp_path):
    """The other side of critic P51-5: what ends a run is a MERGED row (one cell across the table), not a row with one
    filled cell. A data row whose other cells are empty - here the wrapped tail 'EACH' of an ALL-CAPS descriptor - is
    still table content: read as text, 'EACH' would be a heading and the next rows would go under it."""
    rows = [("Code", "Description", "Limit"), ("A4206", "SYRINGE WITH NEEDLE, STERILE", "1 per day"), ("", "EACH", ""),
            ("A4207", "SYRINGE, 2 CC", "1 per day")]
    doc, recs = checks(build(tmp_path / "each.pdf", [[("h", "MEDICAL SUPPLIES"), ("t", "The supplies below are limited."),
                                                      ("table", [80, 220, 100], rows, "rows"),
                                                      ("t", "Repairs require prior authorization.")], PAGE2]))
    assert all(b is not None for b in doc["pages"][0]["table_rows"][0])
    assert [s["heading"] for s in doc["sections"]] == ["MEDICAL SUPPLIES"]
    assert doc["sections"][0]["text"].endswith("A4206 | SYRINGE WITH NEEDLE, STERILE | 1 per day\n | EACH | \n"
                                               "A4207 | SYRINGE, 2 CC | 1 per day")
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]


def test_a_column_rule_touching_a_table_does_not_swallow_the_column(tmp_path):
    """Critic P51-5: a rule between two text columns that touches a table's edge makes find_tables() read the whole
    column as one 'grid' (one cell above the table, the table's rows, one cell below). With every line in that box
    taken for table content, CRISIS SERVICES, PEER SUPPORT and DAY PROGRAMS stopped being headings. The cells above and
    below are merged rows (text); only the real table's rows are table content and copied, under PEER SUPPORT."""
    base = build(tmp_path / "col.pdf", [[("h", "CASE MANAGEMENT"), ("t", "Case management T1016 is billed per 15 minutes."),
                                         ("h", "CRISIS SERVICES"), ("t", "Crisis services H2011 require prior authorization."),
                                         ("h", "PEER SUPPORT"), ("t", "Peer support is limited as shown below."),
                                         ("table", [80, 186], [("Code", "Limit"), ("T1016", "4 per day"), ("H0031", "1 per day")],
                                          "rows"),
                                         ("t", "Peer support notes are required."), ("h", "DAY PROGRAMS"),
                                         ("t", "Day programs H2012 are billed per hour.")], PAGE2])
    d = fitz.open(base)
    pg = d[0]
    pg.draw_line((306, 70), (306, 740))                # the rule between the columns: it touches the table's right edge
    for y, text, font, size in ((90, "RESPITE", "hebo", 12), (110, "Respite S5150 is limited to 600 hours per year.", "helv", 9),
                                (140, "TRANSPORT", "hebo", 12), (160, "Transport A0120 is covered per trip.", "helv", 9)):
        pg.insert_text((316, y), text, fontsize=size, fontname=font)
    path = tmp_path / "col_rule.pdf"
    d.save(path)
    d.close()
    doc, recs = checks(path)
    assert pdx.is_grid(doc["pages"][0]["tables"][0]) and doc["pages"][0]["table_bboxes"][0][3] > 700   # the column 'grid'
    assert [s["heading"] for s in doc["sections"]] == ["CASE MANAGEMENT", "CRISIS SERVICES", "PEER SUPPORT", "DAY PROGRAMS",
                                                       "RESPITE", "TRANSPORT"]
    peer = doc["sections"][2]
    assert peer["text"].endswith("Code | Limit\nT1016 | 4 per day\nH0031 | 1 per day")
    assert sum(s["text"].count(" | ") for s in doc["sections"]) == 3                     # nothing else is copied
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]


def test_a_line_with_a_code_is_a_running_header_only_when_it_repeats_with_its_codes():
    """policy_docs.is_running_header: the shared predicate segment() and the page check use. A line holding a procedure
    code is content even when its digit-less form matches a repeating line (exhibit rows "A4206 Syringe with needle" /
    "A4207 Syringe with needle"). Critic P51-2: such a line was NEVER a running header, so footers holding a code-shaped
    token ("Phoenix, AZ 85034", "Form AH-10021 Rev. 2025A") were kept as text. A line with a code is now compared with
    its codes kept and only short numbers (the page counter) removed (_header_key)."""
    heads = {pdx._norm_header("A4206 Syringe with needle"), pdx._norm_header("AHCCCS FFS Provider Manual 12")}
    assert not pdx.is_running_header("A4206 Syringe with needle", heads)
    assert pdx.is_running_header("AHCCCS FFS Provider Manual 13", heads)
    assert pdx.is_running_header("04/29/2026 CHAPTER 19 BEHAVIORAL HEALTH SERVICES 31 | 45", set())
    heads = {pdx._header_key("A4206 Syringe with needle"), pdx._header_key(FORM_FOOTER + " Page 3 of 9"),
             pdx._header_key(ZIP_FOOTER.format(n=3, N=9))}
    assert not pdx.is_running_header("A4207 Syringe with needle", heads)
    assert pdx.is_running_header(FORM_FOOTER + " Page 4 of 9", heads)
    assert pdx.is_running_header(ZIP_FOOTER.format(n=12, N=9), heads)
    assert not pdx.is_running_header(FORM_FOOTER.replace("10021", "10022") + " Page 4 of 9", heads)
    assert pdx._header_key("T1016 4 units per day") == pdx._header_key("T1016 16 units per day")   # see item 9 (band)


FORM_FOOTER = "AHCCCS FFS Provider Billing Manual - Form AH-10021 Rev. 2025A"
ZIP_FOOTER = "AHCCCS, 801 E. Jefferson Street, Phoenix, AZ 85034   Page {n} of {N}"


def test_a_footer_with_a_code_shaped_token_is_stripped(tmp_path):
    """Critic P51-2, on pages: a footer holding a code-shaped token was kept as text; on a code list crossing the page
    break it landed INSIDE the list ("... H0004, AHCCCS ... Form AH-10021 Rev. 2025A H0006, H0018 ...") and the pattern
    extractor paired S5151 with 10021 and 2025A. Stripped now; the page check names the tokens (info), never counts them."""
    import extract_rules as ex
    import json
    for foot in (FORM_FOOTER, ZIP_FOOTER):
        path = build(tmp_path / "foot.pdf", [
            [("h", "PER DIEM SERVICES"), ("t", "Providers are prohibited from billing S5151 with H0001, H0002, H0004,")],
            [("t", "H0006, H0018 or any other per diem code on the same day.")],
            [("h", "CRISIS SERVICES"), ("t", "Crisis services must be billed per encounter.")]], footer=foot)
        doc, recs = checks(path)
        per_diem = doc["sections"][0]
        assert per_diem["heading"] == "PER DIEM SERVICES" and "AHCCCS" not in per_diem["text"], per_diem["text"]
        assert "H0004, H0006, H0018 or any other" in per_diem["text"]
        assert per_diem["codes_seen"] == ["H0001", "H0002", "H0004", "H0006", "H0018", "S5151"]
        inv = {"chapter": "19", "title": "T", "url": "u", "doc_hash": "h", "revision_date": None}
        drafts, _, _ = ex.extract_chapter(doc["sections"], inv, ex.StubBackend(), "r", cache={}, log_fn=lambda *a: None)
        pairs = [json.loads(d["predicate"]) for d in drafts]
        pairs = {p["code_a"] for p in pairs if p.get("type") == "code_pair_prohibited"}
        assert pairs == {"H0001", "H0002", "H0004", "H0006", "H0018"}
        for p, r in recs.items():
            assert r["n_flags"] == 0, (foot, p, r["flags"])
            assert [x["status"] for x in r["lines"]][-1] == "header"            # the footer line, on every page
            assert flags(r, "code_missing", "info") and "running header/footer" in flags(r, "code_missing", "info")[0]["detail"]


def test_is_grid():
    assert pdx.is_grid([["Code", "Limit"], ["T1016", "4"]])
    assert pdx.is_grid([["Header spanning", ""], ["T1016", "4"]])          # a merged header row
    assert not pdx.is_grid([["a", "b"]])                                     # one row
    assert not pdx.is_grid([["a"], ["b"], ["c"]])                            # one column
    assert not pdx.is_grid([["a", ""], ["", "b"]])                           # never 2 filled cells in a row
    assert not pdx.is_grid([]) and not pdx.is_grid(None)


# ------------------------------------------------------------------ (d4) lines with 2+ codes, top to bottom
def test_table_read_column_by_column_is_out_of_row_order(tmp_path):
    rows = [("Code", "Not billable with"), ("T1016", "H0018, H0014"), ("H0031", "H0038, H0030")]

    def page(order):
        return [[("h", "CASE MANAGEMENT"), ("t", "The codes below cannot be billed on the same day."),
                 ("table", [100, 200], rows, order), ("t", "Providers must keep records.")], PAGE2]

    _, recs = checks(build(tmp_path / "cols.pdf", page("columns")))
    f = flags(recs[1], "row_order")
    assert len(f) == 1 and f[0]["codes"] == ["H0031"] and "row 'H0031 | H0038, H0030'" in f[0]["detail"]
    _, recs = checks(build(tmp_path / "rows.pdf", page("rows")))
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]


def test_two_columns_are_compared_within_a_column_only(tmp_path):
    left = [("at", 40, 100, "LEFT: Do not bill H0031, H0038 together."), ("at", 40, 115, "LEFT: Bill T1016, T1019 per day.")]
    right = [("at", 320, 100, "RIGHT: Do not bill H2014, H2015 together."), ("at", 320, 115, "RIGHT: Bill S5150, S5151 per day.")]
    _, recs = checks(build(tmp_path / "two.pdf", [[("h", "TWO COLUMN SERVICES")] + left + right, PAGE2]))
    assert recs[1]["n_flags"] == 0, recs[1]["flags"]             # column by column is the reading order
    # planted: the left column's lower line comes first in the PDF's text
    _, recs = checks(build(tmp_path / "two_bad.pdf", [[("h", "TWO COLUMN SERVICES")] + left[::-1] + right, PAGE2]))
    f = flags(recs[1], "row_order")
    assert len(f) == 1 and f[0]["codes"] == ["H0031", "H0038"] and "is above" in f[0]["detail"]


# ------------------------------------------------------------------ layouts that must stay quiet
def test_wrapped_heading_list_across_a_page_break_and_footnote(tmp_path):
    _, recs = checks(build(tmp_path / "wrap.pdf", [[("h", "BEHAVIORAL HEALTH REHABILITATION (PSYCHOSOCIAL"), ("h", "SERVICES)"),
                                                    ("t", "Psychosocial rehabilitation H2017 is limited to four units per day.")]
                                                   + CRISIS, PAGE2]))
    assert recs[1]["n_flags"] == 0 and recs[1]["flags"] == []               # not even an info note
    assert recs[1]["sections"][0]["heading"] == "BEHAVIORAL HEALTH REHABILITATION (PSYCHOSOCIAL SERVICES)"
    assert [x["status"] for x in recs[1]["lines"]][:4] == ["header", "heading", "heading", "body"]   # both heading lines
    doc, recs = checks(build(tmp_path / "multi.pdf", [
        [("h", "PER DIEM SERVICES"), ("t", "Providers may not bill S5151 on the same day as H0001, H0002, H0004,")],
        [("t", "H0006, H0018 or any other per diem code.")] + CRISIS]))
    assert recs[1]["n_flags"] == 0 and recs[2]["n_flags"] == 0
    assert doc["sections"][0]["page_end"] == 2 and "H0004, H0006" in doc["sections"][0]["text"]
    # planted: a heading-like line at the top of the next page cuts the list into two sections
    doc, recs = checks(build(tmp_path / "multi_cut.pdf", [
        [("h", "PER DIEM SERVICES"), ("t", "Providers may not bill S5151 on the same day as H0001, H0002, H0004,")],
        [("h", "PER DIEM CODES (CONTINUED)"), ("t", "H0006, H0018 or any other per diem code.")] + CRISIS]))
    assert [s["heading"] for s in doc["sections"]][:2] == ["PER DIEM SERVICES", "PER DIEM CODES (CONTINUED)"]
    f = flags(recs[1], "code_list_split")
    assert len(f) == 1 and "ends inside a code list" in f[0]["detail"] and "'PER DIEM CODES (CONTINUED)'" in f[0]["detail"]
    assert f[0]["codes"] == ["H0004"] and recs[2]["n_flags"] == 0
    # a footnote read mid-sentence is shown (info), never counted: a person judges it
    _, recs = checks(build(tmp_path / "foot.pdf", [
        [("h", "TELEHEALTH"), ("t", "Telehealth services must be billed with modifier GT and the codes"), ("gap", 560),
         ("small", "1 See Chapter 4 for H0031 telehealth rules.")],
        [("t", "99213, 99214 when the member is at home.")] + CRISIS]))
    assert recs[1]["n_flags"] == 0 and len(flags(recs[1], "footnote_in_flow", "info")) == 1


# ------------------------------------------------------------------ choosing pages
def test_random_pages_are_seeded_and_seeds_expand(tmp_path):
    counts = {"19": 40, "10": 59, "22-1": 3}
    a = pf.random_pages(counts, 2, 7)
    assert a.equals(pf.random_pages(counts, 2, 7)) and a.groupby("doc_id").size().to_dict() == {"10": 2, "19": 2, "22-1": 2}
    assert not a.equals(pf.random_pages(counts, 2, 8))
    assert pf.random_pages(counts, 0, 7).empty
    path = build(tmp_path / "t.pdf", [[("h", "A SECTION"), ("t", "Text H0031 here."),
                                       ("table", [80, 80], [("Code", "Unit"), ("H0031", "day")], "rows")], PAGE2, PAGE2])
    doc = pf.load_document("19", path=str(path))
    assert pf.expand_seed(doc, "all") == ([1, 2, 3], [])
    assert pf.expand_seed(doc, "tables") == ([1], [])
    assert pf.expand_seed(doc, [2, 31]) == ([2], [31])
    assert {s["doc_id"] for s in pf.SEED_PAGES} == {"19", "10", "14", "22-1", "22-2", "13"}
    assert all(s["doc_id"] in config.CHAPTERS for s in pf.SEED_PAGES)
    assert pf.pdf_path("19", "/x") == "/x/FFS_Chap19BehavioralHealth.pdf"     # 04's file name for chapter 19


# ------------------------------------------------------------------ the metric
def gold_sheet(**cols):
    """A scored GOLD sheet: one sample, one corpus version, the columns given."""
    n = len(cols["doc_id"])
    return pd.DataFrame({"sample_id": ["v07-t"] * n, "corpus_version": ["corpus-0123456789abcdef"] * n, **cols})


def test_page_text_fidelity_and_its_interval():
    gold = gold_sheet(
        doc_id=["19", "19", "10", "10", "10", "22-1", "22-1", "13", "13", "13"],
        page=[31, 20, 1, 2, 3, 1, 2, 4, 5, 6],
        doc_pages=[45, 45, 59, 59, 59, 3, 3, 30, 30, 30],
        selection=["seed", "seed+random", "random", "random", "random", "random", "flagged", "random", "random", "seed"],
        auto_flags=["code_list_split:1", None, None, "later_heading:1", None, None, "code_missing:2", None, None, None],
        page_ok=["N", "Y", "Y", "N", "y", "Y", "N", "yes", None, "maybe"])
    m = pf.page_text_fidelity(gold)
    assert list(m.columns) == quality.METRIC_COLUMNS
    assert set(m["metric"]) == {"page_text_fidelity"}
    row = {(r["scope_type"], r["scope"]): r for r in m.to_dict("records")}
    # random pages: 19 Y, 10 Y N y, 22-1 Y, 13 yes + one blank -> 6 scored. Critic P51-8: weighted by document length
    # (quality.stratified_ratio: stratum = document, size = its page count), not pooled
    scored = pd.DataFrame({"stratum": ["19", "10", "10", "10", "22-1", "13"], "stratum_size": [45, 59, 59, 59, 3, 30],
                           "y": [1, 1, 0, 1, 1, 1], "x": 1})
    w = quality.stratified_ratio(scored, "y", "x")
    r = row[("sample", "random")]
    assert (r["n"], r["value"], r["ci_low"], r["ci_high"]) == (6, w["value"], w["ci_low"], w["ci_high"])
    assert r["value"] == pytest.approx((45 + 59 * 2 / 3 + 3 + 30) / (45 + 59 + 3 + 30))    # not 5/6
    assert "1 unscored page(s) excluded" in r["notes"] and "weighted by document length" in r["notes"]
    assert row[("overall", "all")]["n"] == 8 and row[("overall", "all")]["value"] == pytest.approx(5 / 8)
    assert row[("sample", "seed")]["n"] == 2 and row[("sample", "seed")]["value"] == 0.5        # "maybe" is blank
    assert row[("sample", "flagged")]["n"] == 1 and row[("sample", "flagged")]["value"] == 0.0
    assert row[("auto_flag", "flagged")]["n"] == 3 and row[("auto_flag", "flagged")]["value"] == 0.0
    assert row[("auto_flag", "not_flagged")]["n"] == 5 and row[("auto_flag", "not_flagged")]["value"] == 1.0
    assert row[("doc_id", "10")]["n"] == 3 and row[("doc_id", "10")]["value"] == pytest.approx(2 / 3)
    assert ("doc_id", "13") in row and row[("doc_id", "13")]["n"] == 1
    # nothing scored: the rate is unmeasured, the interval says it could be anything
    empty = pf.page_text_fidelity(gold.assign(page_ok=None))
    r = empty[empty["scope"] == "random"].iloc[0]
    assert r["n"] == 0 and pd.isna(r["value"]) and (r["ci_low"], r["ci_high"]) == (0.0, 1.0)
    assert len(pf.page_text_fidelity(pd.DataFrame())) == 2                       # overall + random, both n = 0


def test_the_fair_rate_weights_documents_by_length_and_a_malformed_sheet_is_refused():
    """Critic P51-8: the 'fair rate' took 2 random pages from every document and pooled them, so a page of a 3-page
    exhibit counted 20x a page of a 60-page chapter, and the Wilson interval assumed a simple random sample. It is the
    stratified ratio now (stratum = document, its size = its page count). And the ingest accepted a malformed sheet:
    a duplicated row counted twice, a blank or mixed corpus_version and mixed sample ids passed with at most a note."""
    gold = gold_sheet(doc_id=["10", "10", "22-1", "22-1"], page=[7, 40, 1, 3], doc_pages=[60, 60, 3, 3],
                      selection=["random"] * 4, page_ok=["Y", "Y", "N", "N"])
    r = pf.page_text_fidelity(gold).set_index("scope").loc["random"]
    assert r["n"] == 4 and r["value"] == pytest.approx(60 / 63)                 # pooled it was 0.5
    w = quality.stratified_ratio(pd.DataFrame({"stratum": ["10", "10", "22-1", "22-1"], "stratum_size": [60, 60, 3, 3],
                                               "y": [1, 1, 0, 0], "x": 1}), "y", "x")
    assert (r["ci_low"], r["ci_high"]) == (w["ci_low"], w["ci_high"])
    assert pf.check_gold(gold) == {"sample_id": "v07-t", "corpus_version": "corpus-0123456789abcdef", "pages": 4}
    for bad, why in ((pd.concat([gold, gold.iloc[[0]]], ignore_index=True), "doc 10 page 7"),
                     (pd.concat([gold, gold.iloc[[1]].assign(doc_id=10, page=40.0)], ignore_index=True), "doc 10 page 40"),
                     (gold.assign(corpus_version=None), "corpus_version"),
                     (gold.assign(corpus_version=["corpus-a", " ", "corpus-a", "corpus-a"]), "corpus_version"),
                     (gold.assign(corpus_version=["corpus-a", "corpus-b", "corpus-a", "corpus-a"]), "corpus_version"),
                     (gold.assign(sample_id=["v07-a", "v07-a", "v07-b", "v07-b"]), "sample_id"),
                     (gold.assign(sample_id=None), "sample_id"),
                     (gold.drop(columns=["corpus_version"]), "corpus_version")):
        with pytest.raises(ValueError, match=why):
            pf.page_text_fidelity(bad)
        with pytest.raises(ValueError, match=why):
            pf.check_gold(bad)
    with pytest.raises(ValueError, match="no rows"):
        pf.check_gold(gold.iloc[0:0])


# ------------------------------------------------------------------ the report and the gold sheet
def test_gold_sheet_and_html_report_round_trip(tmp_path, monkeypatch):
    monkeypatch.setattr(pdx, "code_list_break", lambda before, after: False)      # planted: a page with a flag
    path = build(tmp_path / "rep.pdf", [[("h", "PER DIEM SERVICES"), ("t", S5151), ("t", LIST_MID.rsplit(" T1019.", 1)[0]),
                                         ("t", "T1019. H0031, " + LIST_END)] + CRISIS, PAGE2])
    doc = pf.load_document("19", path=str(path))
    recs = [pf.page_record(doc, p, dpi=40) for p in (1, 2)]
    recs[0]["selection"], recs[0]["seed_reason"], recs[1]["selection"] = "seed+random", "S5151 list", "random"
    page = pf.html_report(recs, "t", ["note one"])
    assert page.count("data:image/png;base64,") == 2 and 'id="p-19-1"' in page and 'href="#p-19-2"' in page
    assert "src=\"http" not in page and "href=\"http" not in page and "<script" not in page      # self-contained
    assert 'class="brk"' in page and "code_list_split" in page and "PER DIEM SERVICES" in page
    corpus = pdx.corpus_version({"19": doc["doc_hash"]})
    gold = pf.gold_frame(recs, "v07-t", corpus)
    assert list(gold.columns) == pf.GOLD_COLUMNS and gold["report_anchor"].tolist() == ["#p-19-1", "#p-19-2"]
    assert set(gold["corpus_version"]) == {corpus}
    assert gold.loc[0, "auto_flags"] == "code_list_split:1" and pd.isna(gold.loc[1, "auto_flags"])
    assert gold[pf.GOLD_SCORE_COLUMNS].isna().all().all()
    out = quality.xlsx_write_sheets({"GOLD": gold.assign(page_ok=["N", "Y"], scorer="SB")}, str(tmp_path / "g.xlsx"))
    back = quality.xlsx_read_sheets(out)["GOLD"]
    m = pf.page_text_fidelity(back)
    r = m[m["scope"] == "random"].iloc[0]
    assert (r["n"], r["value"]) == (2, 0.5) and r["notes"].endswith(f"Corpus {corpus}.")


def test_corpus_version_treats_blank_hashes_as_missing():
    """Critic P51-10: corpus_version() counted a NaN or whitespace-only hash as a document, so an inventory read from a
    table with one empty doc_hash got another version id than the same corpus without that row (v03 / quality.corpus_bar
    treat a blank hash as missing). A blank hash is missing now; a document's hash is compared stripped."""
    import numpy as np
    base = pdx.corpus_version({"10": "abc", "19": "def"})
    assert base.startswith("corpus-") and base != "corpus-empty"
    assert pdx.corpus_version({"10": "abc", "19": "def", "13": float("nan"), "14": "  ", "22-1": None,
                               "22-2": np.nan, "15": pd.NA, "16": ""}) == base
    assert pdx.corpus_version({"10": " abc ", "19": "def\n"}) == base
    assert pdx.corpus_version({"10": float("nan"), "19": "   "}) == "corpus-empty"
    assert pdx.corpus_version({"10": "abc"}) != base and pdx.corpus_version({}) == pdx.corpus_version(None) == "corpus-empty"


# ------------------------------------------------------------------ the notebook, both phases
class _Catalog:
    def tableExists(self, name):
        return False


class _FakeSpark:
    """Only what v07 touches; any table read or write fails the test (writes go through kb_io.write_table, patched)."""
    catalog = _Catalog()

    def table(self, name):
        raise AssertionError(f"v07 read {name}")

    def createDataFrame(self, *a, **k):
        raise AssertionError("v07 must not write outside kb_io.write_table")


def _run_v07(subs, monkeypatch):
    src = open(os.path.join(PKG, "notebooks", "validation", "v07_page_fidelity.py")).read()
    src = src.replace("    importlib.reload(_m)", "    pass")                  # keep the patched config
    for old, new in subs.items():
        assert old in src, old
        src = src.replace(old, new)
    monkeypatch.setenv("PKB_PACKAGE_DIR", PKG)
    g = {"spark": _FakeSpark(), "display": lambda *a: None, "__name__": "v07"}
    exec(compile(src, "v07", "exec"), g)
    return g


def test_v07_notebook_exports_then_ingests(tmp_path, monkeypatch):
    import fixture_pdf
    import kb_io
    monkeypatch.setattr(pdx, "code_list_break", lambda before, after: False)      # planted: a page with a flag
    pdf_dir = tmp_path / "policy_docs"
    pdf_dir.mkdir()
    fixture_pdf.build(pf.pdf_path("10", str(pdf_dir)))                         # staged under 04's file names
    build(pf.pdf_path("19", str(pdf_dir)), [[("h", "PER DIEM SERVICES"), ("t", S5151), ("t", LIST_MID.rsplit(" T1019.", 1)[0]),
                                             ("t", "T1019. H0031, " + LIST_END)] + CRISIS, PAGE2, PAGE2])
    monkeypatch.setattr(config, "STAGE_PDF_DIR", str(pdf_dir))
    monkeypatch.setattr(config, "WORKSPACE_DATA_DIR", str(tmp_path))
    g = _run_v07({"SEED_PAGES       = page_fidelity.SEED_PAGES":
                  "SEED_PAGES       = [{'doc_id': '19', 'pages': [1, 31], 'reason': 'S5151 list'}, "
                  "{'doc_id': '22-1', 'pages': 'all', 'reason': 'exhibit'}]",
                  "N_RANDOM_PER_DOC = 2": "N_RANDOM_PER_DOC = 1"}, monkeypatch)
    assert set(g["docs"]) == {"10", "19"} and len(g["screen"]) == 6
    assert os.path.exists(g["HTML_PATH"]) and g["EXPORT_PATH"].startswith(str(tmp_path / "validation"))
    book = quality.xlsx_read_sheets(g["EXPORT_PATH"])
    assert {"README", "GOLD", "SCREEN"} <= set(book)
    gold = book["GOLD"]
    assert list(gold.columns) == pf.GOLD_COLUMNS
    sel = dict(zip(zip(gold["doc_id"].astype(str), gold["page"]), gold["selection"]))
    assert "seed" in sel[("19", 1)].split("+") and ("19", 31) not in sel
    assert sorted(d for (d, _), s in sel.items() if "random" in str(s).split("+")) == ["10", "19"]
    assert gold.loc[(gold["doc_id"].astype(str) == "19") & (gold["page"] == 1), "auto_flags"].iloc[0] == "code_list_split:1"
    # phase 2: a person scores the sheet; the metric is appended with quality.METRIC_COLUMNS + sample_id, computed_at
    gold["page_ok"] = ["N" if "seed" in str(s) else "Y" for s in gold["selection"]]
    gold["scorer"] = "SB"
    scored = quality.xlsx_write_sheets({"GOLD": gold}, str(tmp_path / "scored.xlsx"))
    written = []
    monkeypatch.setattr(kb_io, "write_table",
                        lambda spark, df, fqn, mode="overwrite", schema=None: written.append((df, fqn, mode)))
    g = _run_v07({"EXPORT           = True": "EXPORT           = False",
                  "SCORED_WORKBOOK  = None": f"SCORED_WORKBOOK  = {scored!r}"}, monkeypatch)
    assert len(written) == 1
    df, fqn, mode = written[0]
    assert fqn == f"{config.KB}.policy_quality_metrics" and mode == "append"
    assert list(df.columns) == quality.METRIC_COLUMNS[:-1] + ["sample_id", "computed_at", "notes"]
    r = df[(df["scope_type"] == "sample") & (df["scope"] == "random")].iloc[0]
    rnd = gold[gold["selection"].map(lambda s: "random" in str(s).split("+"))]
    assert set(rnd["doc_pages"]) == {3}                                     # both documents have 3 pages
    w = quality.stratified_ratio(pd.DataFrame({"stratum": rnd["doc_id"].astype(str).tolist(),
                                               "stratum_size": rnd["doc_pages"].tolist(),
                                               "y": [0 if "seed" in str(s) else 1 for s in rnd["selection"]],
                                               "x": [1] * len(rnd)}), "y", "x")
    assert (r["n"], r["value"], r["ci_low"]) == (len(rnd), w["value"], w["ci_low"])
    assert df["sample_id"].iloc[0] == gold["sample_id"].iloc[0]
    # the denominator is stated: the corpus version of the two staged documents, in the sheet and in every metric row
    hashes = {d: hashlib.sha256(open(pf.pdf_path(d, str(pdf_dir)), "rb").read()).hexdigest() for d in ("10", "19")}
    assert set(gold["corpus_version"]) == {pdx.corpus_version(hashes)}
    assert df["notes"].map(lambda n: n.endswith(f"Corpus {pdx.corpus_version(hashes)}.")).all()
    # critic P51-8: a malformed scored sheet is refused before anything is written (a page twice; a mixed corpus)
    for bad in (pd.concat([gold, gold.iloc[[0]]], ignore_index=True),
                gold.assign(corpus_version=[f"corpus-{i % 2}" for i in range(len(gold))])):
        path = quality.xlsx_write_sheets({"GOLD": bad}, str(tmp_path / "bad.xlsx"))
        with pytest.raises(ValueError, match="more than once|mixes 2 corpus_version"):
            _run_v07({"EXPORT           = True": "EXPORT           = False",
                      "SCORED_WORKBOOK  = None": f"SCORED_WORKBOOK  = {path!r}"}, monkeypatch)
    assert len(written) == 1
