"""NCCI v2 fixes (critic C2): edit-file routing (2026-10-03: by provider type x form, per line), collapse over all members, retroactive deletions,
strict dates and codes, CCMI changes across quarters, MUE later-quarter changes, provenance.
Pure pandas; ingest_tables / discover_tables run against a fake Spark (no JVM).
Run: cd pie_mvp && python -m pytest tests/test_ncci_v2.py -q"""
import json
import os
import random
import re
import sys
import types
from datetime import date, timedelta

import numpy as np
import pandas as pd
import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import config  # noqa: E402
import ingest_ncci_tables as ing  # noqa: E402
import rule_normalize as rn  # noqa: E402
import validate_gate as vg  # noqa: E402

EDITIONS = ("practitioner", "outpatient", "dme")      # each rule keeps ONE; lines take one (ncci_routing)
PTP_COLS = ["Col1", "Col2", "EffDt", "DelDt", "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable",
            "PTP_Edit_Rationale"]


@pytest.fixture(autouse=True)
def _config(monkeypatch):
    # pin what these tests rely on, whatever the shared config says today
    monkeypatch.setattr(config, "NCCI_STRICT", True, raising=False)
    monkeypatch.setattr(config, "NCCI_DELETION_DATE_INCLUSIVE", True, raising=False)
    monkeypatch.setattr(config, "NCCI_ALLOW_MUE_GAPS", False, raising=False)


def meta(service, edit, q, y):
    return {"table": f"medicaid_ncci_edit_{service}_{edit}_q{q}_{y}", "fqn": f"main.sedo.medicaid_ncci_edit_{service}_{edit}_q{q}_{y}",
            "service": service, "edit_type": edit, "quarter": q, "year": y,
            "label": f"{y}Q{q}", "starts": f"{y}-{ing.QUARTER_START[q]}"}


def ptp_df(rows):
    return pd.DataFrame(rows, columns=PTP_COLS)


def mue_df(rows, svc="Practitioner"):
    return pd.DataFrame(rows, columns=["HCPCS/CPT Code", f"{svc} Services MUE Values", "MUE Rationale"])


def rule(pred, eff=None, end=None, **kw):
    d = {"origin": "ncci", "statement": kw.pop("statement", f"s {pred} {eff} {end}"), "source_doc": "x",
         "predicate": dict(pred), "effective_date": eff, "end_date": end, "machine_checkable": True}
    d.update(kw)
    return d


def mue(code, thr, svc, eff=None, end=None, **kw):
    return rule({"type": "max_units_per_line", "code": code, "threshold": thr, "service_category": svc}, eff, end, **kw)


def ptp(a, b, mi, svc, eff=None, end=None, **kw):
    return rule({"type": "code_pair_prohibited", "code_a": a, "code_b": b, "modifier_indicator": mi,
                 "service_category": svc}, eff, end, **kw)


def by_edition(out):
    d = {}
    for r in out:
        d.setdefault(r["predicate"].get("ncci_edition"), []).append(r)
    return d


def build(rule_objs):
    """The 07 path: gate -> normalize."""
    acc, rej = vg.gate(rule_objs)
    assert not rej, rej
    return rn.normalize_rules(acc)


# ================================================================ fake Spark (no JVM)
def _spark_cast_string(v):
    """CAST(x AS STRING) for the types a code column can have (int 100 -> '100', double -> '100.0')."""
    if v is None or (isinstance(v, float) and v != v):
        return None
    if isinstance(v, (bool, np.bool_)):
        return "true" if v else "false"
    if isinstance(v, (int, np.integer)):
        return str(int(v))
    if isinstance(v, (float, np.floating)):
        return repr(float(v))
    return str(v)


class _Col:
    def __init__(self, fn):
        self.fn = fn

    def cast(self, t):
        assert t == "string"
        return _Col(lambda df: self.fn(df).map(_spark_cast_string))

    def isin(self, vals):
        s = set(vals)
        return _Col(lambda df: self.fn(df).map(lambda v: v in s))

    def __and__(self, other):
        return _Col(lambda df: self.fn(df).astype(bool) & other.fn(df).astype(bool))


def _fake_functions():
    F = types.ModuleType("pyspark.sql.functions")

    def _map(c, f):
        return _Col(lambda df: c.fn(df).map(lambda v: None if v is None else f(v)))
    F.upper = lambda c: _map(c, lambda v: str(v).upper())
    F.trim = lambda c: _map(c, lambda v: str(v).strip())
    F.regexp_replace = lambda c, pat, rep: _map(c, lambda v: re.sub(pat, rep, str(v)))
    return F


class _SDF:
    def __init__(self, pdf):
        self.pdf = pdf

    @property
    def columns(self):
        return list(self.pdf.columns)

    @property
    def dtypes(self):
        return [(c, {"int64": "bigint", "float64": "double"}.get(str(t), "string")) for c, t in self.pdf.dtypes.items()]

    def __getitem__(self, c):
        return _Col(lambda df, c=c: df[c])

    def filter(self, cond):
        return _SDF(self.pdf[cond.fn(self.pdf).astype(bool)].reset_index(drop=True))

    def select(self, *cols):
        return _SDF(self.pdf[list(cols)].copy())

    def count(self):
        return len(self.pdf)

    def toPandas(self):
        return self.pdf.copy()


class FakeSpark:
    def __init__(self, tables: dict):
        self.tables = tables
        self.selected: dict = {}

    def sql(self, q):
        assert q.startswith("SHOW TABLES"), q
        rows = [{"tableName": n} for n in self.tables]
        return types.SimpleNamespace(collect=lambda: rows)

    def table(self, fqn):
        return _SDF(self.tables[fqn.split(".")[-1]])


@pytest.fixture
def fake_pyspark(monkeypatch):
    F = _fake_functions()
    sql = types.ModuleType("pyspark.sql")
    sql.functions = F
    root = types.ModuleType("pyspark")
    root.sql = sql
    monkeypatch.setitem(sys.modules, "pyspark", root)
    monkeypatch.setitem(sys.modules, "pyspark.sql", sql)
    monkeypatch.setitem(sys.modules, "pyspark.sql.functions", F)
    return F


def _no_acquisition_log(monkeypatch):
    import acquire_ncci
    monkeypatch.delattr(acquire_ncci, "acquisition_provenance", raising=False)


# ================================================================ C2-01 / C2-02 routing
def test_outpatient_edits_carry_only_the_outpatient_file():
    # R3: a pair / code only in the outpatient-hospital edition used to fire on CMS-1500 claims. Every rule now carries
    # its own edit file and runs only on lines that take that file (ncci_routing: provider type x claim form)
    rules = ing.ptp_rules(ptp_df([["33333", "44444", 20100101, "*", 0, "x"]]), meta("outpatient", "ptp", 4, 2026))
    rules += ing.mue_history([(meta("outpatient", "mue", 4, 2026), mue_df([["55555", 0, "x"]], "Outpatient Hospital"))])
    out, rep = build(rules)
    assert {r["predicate"]["ncci_edition"] for r in out} == {"outpatient"}
    assert not any("form_typ" in r["predicate"] for r in out)
    assert rep["ncci_rules_by_edition"] == {"practitioner": 0, "outpatient": 2, "dme": 0} and rep["ncci_rules_no_edition"] == 0


def test_practitioner_and_outpatient_editions_are_never_merged():
    # R3b / R3c inverted: PRA CCMI 0 + OPH CCMI 1 used to become '1' everywhere (PRA hard denial lost);
    # PRA MUE 1 + OPH MUE 4 used to become 4 everywhere (3 units on a CMS-1500 line passed)
    rules = ing.ptp_rules(ptp_df([["11111", "22222", 20100101, "*", 0, "x"]]), meta("practitioner", "ptp", 4, 2026))
    rules += ing.ptp_rules(ptp_df([["11111", "22222", 20100101, "*", 1, "x"]]), meta("outpatient", "ptp", 4, 2026))
    rules += ing.mue_history([(meta("practitioner", "mue", 4, 2026), mue_df([["66666", 1, "x"]])),
                              (meta("outpatient", "mue", 4, 2026), mue_df([["66666", 4, "x"]], "Outpatient Hospital"))])
    out, rep = build(rules)
    f = by_edition(out)
    a = {r["predicate"]["type"]: r["predicate"] for r in f["practitioner"]}
    o = {r["predicate"]["type"]: r["predicate"] for r in f["outpatient"]}
    assert a["code_pair_prohibited"]["modifier_indicator"] == "0" and a["code_pair_prohibited"]["service_category"] == "practitioner"
    assert o["code_pair_prohibited"]["modifier_indicator"] == "1" and o["code_pair_prohibited"]["service_category"] == "outpatient"
    assert a["max_units_per_line"]["threshold"] == 1 and o["max_units_per_line"]["threshold"] == 4
    assert rep["ncci_editions_collapsed"] == 0 and "editions" not in a["code_pair_prohibited"]


def test_editions_are_never_merged_one_rule_per_edit_file():
    # TGM fn 19: the DME edits are identical inside the PRA and OPH files, so a line takes ONE file - no merge, no copy
    out, rep = rn.normalize_rules([mue("A4218", 4, "practitioner"), mue("A4218", 20, "dme"), mue("A4218", 6, "outpatient")])
    f = by_edition(out)
    assert {e: [r["predicate"]["threshold"] for r in rs] for e, rs in f.items()} == {"practitioner": [4], "dme": [20],
                                                                                    "outpatient": [6]}
    assert all("editions" not in r["predicate"] and r["predicate"]["service_category"] == r["predicate"]["ncci_edition"]
               for r in out)
    assert rep["ncci_editions_collapsed"] == 0 and len({r["rule_id"] for r in out}) == 3
    out, _ = rn.normalize_rules([mue("E0601", 1, "dme")])
    assert [r["predicate"]["ncci_edition"] for r in out] == ["dme"]          # never copied per form


def test_rule_with_an_unknown_edit_file_is_counted_not_emitted():
    rules = [mue("A0425", 2, "ambulance"), ptp("11111", "22222", "0", "practitioner"),
             dict(mue("D0120", 1, "practitioner"), predicate={"type": "max_units_per_line", "code": "D0120",
                                                              "threshold": 1, "service_category": "practitioner",
                                                              "form_typ": "D"})]
    out, rep = rn.normalize_rules(rules)
    assert sorted((r["predicate"]["type"], r["predicate"]["ncci_edition"]) for r in out) == [
        ("code_pair_prohibited", "practitioner"), ("max_units_per_line", "practitioner")]
    assert all("form_typ" not in r["predicate"] for r in out)          # an old form stamp is dropped: lines decide
    assert rep["ncci_rules_no_edition"] == 1 and "ambulance" in rep["ncci_no_edition_examples"][0]
    json.dumps(rep)                                                      # 07 logs it as JSON





def test_every_ncci_rule_carries_one_known_edit_file():
    rules = ing.ptp_rules(ptp_df([["11111", "22222", 20100101, "*", 0, "x"]]), meta("practitioner", "ptp", 4, 2026))
    for svc, col in (("practitioner", "Practitioner"), ("outpatient", "Outpatient Hospital"), ("dme", "DME Supplier")):
        rules += ing.mue_history([(meta(svc, "mue", 4, 2026), mue_df([["41899", 1, "x"]], col))])
    out, _ = build(rules)
    assert {r["predicate"]["ncci_edition"] for r in out} == set(EDITIONS)
    assert not any("form_typ" in r["predicate"] for r in out)   # dental / pharmacy exclusion is per LINE (ncci_routing)


def test_normalize_is_idempotent_with_routing():
    rules = [mue("A4218", 4, "practitioner", "2020-01-01"), mue("A4218", 20, "dme", "2022-01-01", "2023-06-30"),
             ptp("11111", "22222", "1", "practitioner", "2015-01-01"), ptp("11111", "22222", "0", "dme", "2018-01-01"),
             mue("J1100", 2, "outpatient", "2019-01-01", "9999-12-31")]
    once, _ = rn.normalize_rules(rules)
    twice, rep2 = rn.normalize_rules(once)
    key = lambda r: (r["rule_id"], json.dumps(r["predicate"], sort_keys=True), r["effective_date"], r["end_date"])  # noqa: E731
    assert sorted(map(key, once)) == sorted(map(key, twice))
    assert rep2["rule_ids_rederived"] == 0 and rep2["ncci_editions_collapsed"] == 0


def test_legacy_cross_edition_row_is_rebuilt_per_edition_before_routing():
    legacy = ptp("11111", "22222", "1", "ncci", "2021-01-01")
    legacy["predicate"]["editions"] = {"practitioner": "0", "outpatient": "1"}
    out, _ = rn.normalize_rules([legacy])
    got = {r["predicate"]["ncci_edition"]: (r["predicate"]["modifier_indicator"], r["predicate"]["service_category"])
           for r in out}
    assert got == {"practitioner": ("0", "practitioner"), "outpatient": ("1", "outpatient")}
    assert all("(practitioner)" in r["statement"] or "(outpatient)" in r["statement"] for r in out)
    # an edition with no edit file is counted, even when its siblings route
    legacy["predicate"]["editions"] = {"practitioner": "0", "ambulance": "1"}
    out, rep = rn.normalize_rules([legacy])
    assert len(out) == 1 and rep["ncci_rules_no_edition"] == 1 and "ambulance" in rep["ncci_no_edition_examples"][0]


def test_contract_predicate_keys_after_normalize():
    rules = ing.ptp_rules(ptp_df([["11111", "22222", 20100101, "*", 0, "x"], ["11111", "33333", 20100101, "*", 1, "x"]]),
                          meta("practitioner", "ptp", 4, 2026))
    rules += ing.ptp_rules(ptp_df([["11111", "33333", 20100101, "*", 0, "x"]]), meta("dme", "ptp", 4, 2026))
    rules += ing.mue_history([(meta("practitioner", "mue", 3, 2026), mue_df([["A4218", 2, "x"], ["J3490", 1, "x"]])),
                              (meta("practitioner", "mue", 4, 2026), mue_df([["A4218", 3, "x"]]))])
    rules += ing.mue_history([(meta("dme", "mue", 4, 2026), mue_df([["A4218", 5, "x"]], "DME Supplier"))])
    out, rep = build(rules)
    ptp_keys = {"type", "code_a", "code_b", "modifier_indicator", "service_category", "ncci_edition", "editions"}
    mue_keys = {"type", "code", "threshold", "service_category", "ncci_edition", "editions", "later_max_threshold",
                "removed_later", "mai"}
    for r in out:
        p = r["predicate"]
        assert p["ncci_edition"] in EDITIONS, r
        if p["type"] == "code_pair_prohibited":
            assert set(p) <= ptp_keys and p["modifier_indicator"] in ("0", "1")
        else:
            assert set(p) <= mue_keys and isinstance(p["threshold"], int)
            assert "later_max_threshold" in p and isinstance(p["removed_later"], bool)
        if "editions" in p:
            assert isinstance(p["editions"], dict) and p["service_category"] in set(p["editions"]) | {"ncci"}
        else:
            assert p["service_category"] in ("practitioner", "outpatient", "dme")
    j3490 = [r for r in out if r["predicate"].get("code") == "J3490"]
    assert j3490 and all(r["predicate"]["removed_later"] is True for r in j3490)
    json.dumps(rep)


# ================================================================ C2-06 collapse over ALL members
def test_same_edition_overlap_takes_the_max_over_every_rule_in_force():
    # repro_collapse_same_edition: dme 3 and dme 2 overlap -> the old dict kept 2 (the later row)
    out, _ = rn.normalize_rules([mue("A1234", 3, "dme", "2020-01-16", "2020-02-25"),
                                 mue("A1234", 2, "dme", "2020-01-08", "2020-02-13")])
    dme = by_edition(out)["dme"]
    assert set(by_edition(out)) == {"dme"}
    segs = sorted((r["effective_date"], r["end_date"], r["predicate"]["threshold"]) for r in dme)
    assert segs == [("2020-01-08", "2020-01-15", 2), ("2020-01-16", "2020-02-13", 3), ("2020-02-14", "2020-02-25", 3)]
    mid = [r for r in dme if r["effective_date"] == "2020-01-16"][0]
    assert mid["ambiguity_flag"] and "dme rows disagree" in mid["ambiguity_note"]
    assert mid["reconciliation"] == "single_edition_segment" and mid["predicate"]["service_category"] == "dme"
    tail = [r for r in dme if r["effective_date"] == "2020-02-14"][0]
    assert not tail["ambiguity_flag"] and tail["reconciliation"] == "single_edition_segment"


def test_same_edition_overlap_ptp_keeps_any_bypass():
    out, _ = rn.normalize_rules([ptp("11111", "22222", "1", "practitioner", "2015-01-01"),
                                 ptp("11111", "22222", "0", "practitioner", "2020-01-01")])
    segs = sorted((r["effective_date"], r["end_date"], r["predicate"]["modifier_indicator"]) for r in out)
    assert segs == [("2015-01-01", "2019-12-31", "1"), ("2020-01-01", None, "1")]
    assert all(r["predicate"]["ncci_edition"] == "practitioner" for r in out)


D0 = date(2020, 1, 1)
DAYS = [D0 + timedelta(days=i) for i in range(0, 70)]
PROBES = [date(1900, 1, 1)] + DAYS + [date(2100, 1, 1)]          # unbounded ends are probed too
SVCS = ["practitioner", "outpatient", "dme"]


def _iso(d):
    return None if d is None else d.isoformat()


def _active(r, d):
    s, e = r.get("effective_date"), r.get("end_date")
    return (s is None or date.fromisoformat(s[:10]) <= d) and (e is None or d <= date.fromisoformat(e[:10]))


def _rand_rule(rnd, kind, key):
    s = rnd.choice([None] + DAYS[:60])
    e = rnd.choice([None, None] + DAYS[5:])
    if s is not None and e is not None and rnd.random() < 0.85 and e < s:
        s, e = e, s                                              # mostly valid windows, some inverted ones kept
    svc = rnd.choice(SVCS)
    if kind == "ptp":
        pred = {"type": "code_pair_prohibited", "code_a": key[0], "code_b": key[1],
                "modifier_indicator": rnd.choice(["0", "1"]), "service_category": svc}
    else:
        pred = {"type": "max_units_per_line", "code": key, "threshold": rnd.randint(1, 9), "service_category": svc}
        if rnd.random() < 0.5:
            pred["later_max_threshold"] = rnd.choice([None, rnd.randint(1, 12)])
            pred["removed_later"] = rnd.random() < 0.3
    return {"origin": "ncci", "statement": f"s{rnd.random()}", "source_doc": "x", "predicate": pred,
            "effective_date": _iso(s), "end_date": _iso(e)}


def _matches(r, kind, key):
    p = r["predicate"]
    return (p["code_a"], p["code_b"]) == key if kind == "ptp" else p["code"] == key


def test_collapse_property_routes_and_aggregates_over_all_members(n_cases=1500, seed=20261002):
    """Adapted from critic C2 (c2_tests/test_c2_collapse_property.py), now per EDIT FILE and with same-edition
    overlaps: on every date, for every edit file and key, at most ONE output rule is in force and its value is
    the most permissive over ALL inputs of that file in force that day (C2-06); its editions dict and later-quarter
    fields aggregate the same inputs; nothing is fabricated, widened, or merged across files."""
    rnd = random.Random(seed)
    probes = 0
    for _ in range(n_cases):
        kind = rnd.choice(["ptp", "mue"])
        keys = [("11111", "22222"), ("22222", "11111")] if kind == "ptp" else ["A1234", "B5678"]
        inputs = [_rand_rule(rnd, kind, rnd.choice(keys)) for _ in range(rnd.randint(1, 5))]
        out, rep = rn.normalize_rules([json.loads(json.dumps(r)) for r in inputs])
        assert all(r["predicate"]["ncci_edition"] in EDITIONS for r in out)
        for form in EDITIONS:                          # (variable name kept: one edit file per pass)
            for key in keys:
                ins = [r for r in inputs if _matches(r, kind, key) and r["predicate"]["service_category"] == form]
                outs = [r for r in out if _matches(r, kind, key) and r["predicate"]["ncci_edition"] == form]
                for d in PROBES:
                    probes += 1
                    on = [r for r in ins if _active(r, d)]
                    act = [r for r in outs if _active(r, d)]
                    assert len(act) <= 1, f"{len(act)} rules overlap on {d} ({form})"
                    if not on:
                        assert not act, f"fabricated window on {d} ({form})"
                        continue
                    assert act, f"lost window on {d} ({form}): inputs {[(r['effective_date'], r['end_date']) for r in on]}"
                    p = act[0]["predicate"]
                    vals = [r["predicate"]["modifier_indicator" if kind == "ptp" else "threshold"] for r in on]
                    exp = ("1" if "1" in vals else "0") if kind == "ptp" else max(vals)
                    assert p["modifier_indicator" if kind == "ptp" else "threshold"] == exp, (form, key, d, vals)
                    per_ed = {}
                    for r in on:
                        per_ed.setdefault(r["predicate"]["service_category"], []).append(
                            r["predicate"]["modifier_indicator" if kind == "ptp" else "threshold"])
                    agg = {e: (("1" if "1" in v else "0") if kind == "ptp" else max(v)) for e, v in per_ed.items()}
                    if "editions" in p:
                        assert p["editions"] == agg and all(e in act[0]["statement"] for e in agg)
                        assert act[0]["reconciliation"].split(";")[0] in rn._COLLAPSE_LABELS
                    else:
                        assert len(on) == 1 and p["service_category"] == on[0]["predicate"]["service_category"]
                    if kind == "mue":
                        later = [r["predicate"].get("later_max_threshold") for r in on
                                 if r["predicate"].get("later_max_threshold") is not None]
                        assert p["later_max_threshold"] == (max(later) if later else None)
                        assert p["removed_later"] == any(r["predicate"].get("removed_later", False) for r in on)
    assert probes > 100_000


# ================================================================ C2-25 every edition cited
def test_overlapping_rows_of_one_file_merge_and_cite_every_row():
    rules = [mue("A4218", 4, "practitioner", "2024-01-01", doc_version="tP1", doc_hash="h1"),
             mue("A4218", 20, "practitioner", "2024-04-01", doc_version="tP2", doc_hash="h2")]
    out, rep = rn.normalize_rules(rules)
    a = sorted(by_edition(out)["practitioner"], key=lambda r: r["effective_date"])
    assert [(r["effective_date"], r["end_date"], r["predicate"]["threshold"]) for r in a] == [
        ("2024-01-01", "2024-03-31", 4), ("2024-04-01", None, 20)]
    clipped, both = a
    assert clipped["reconciliation"] == "single_edition_segment" and not clipped["ambiguity_flag"]
    assert both["reconciliation"] == "single_edition_segment" and both["ambiguity_flag"]   # the rows disagree
    assert "practitioner rows disagree" in both["ambiguity_note"]
    assert both["doc_version"] == "tP1; tP2" and both["doc_hash"] == "h1; h2"
    assert rep["ncci_collapse_labels"] == {"single_edition_segment": 2}
    # across edit files nothing merges, even when the values agree
    out2, rep2 = rn.normalize_rules([mue("B1234", 5, "practitioner"), mue("B1234", 5, "dme")])
    assert sorted(r["predicate"]["ncci_edition"] for r in out2) == ["dme", "practitioner"] and rep2["ncci_editions_collapsed"] == 0


def test_member_labels_and_ambiguity_survive_a_collapse():
    r1 = ptp("11111", "22222", "1", "practitioner", "2021-01-01", ambiguity_flag=True,
             ambiguity_note="CCMI changed", reconciliation="ccmi_changed_across_quarters")
    out, _ = rn.normalize_rules([r1, ptp("11111", "22222", "1", "practitioner", "2021-01-01", statement="other row")])
    a = by_edition(out)["practitioner"]
    assert len(a) == 1 and a[0]["reconciliation"] == "single_edition_segment;ccmi_changed_across_quarters"
    assert a[0]["ambiguity_flag"] and "CCMI changed" in a[0]["ambiguity_note"]


# ================================================================ C2-05 EffDt == DelDt
def test_ptp_row_with_effective_equal_deletion_date_is_dropped_whatever_the_indicator(capsys):
    st = {}
    rules = ing.ptp_rules(ptp_df([["11111", "22222", 20250301, 20250301, 0, "x"],
                                  ["11111", "33333", 20250301, 20250301, 1, "x"],
                                  ["11111", "44444", 20250301, 20250301, "X", "x"],
                                  ["11111", "55555", 20250301, 20250301, 9, "x"],
                                  ["11111", "66666", 20250301, 20250302, 0, "x"]]),
                          meta("practitioner", "ptp", 4, 2026), stats=st)
    assert [(r.predicate["code_b"], r.effective_date, r.end_date) for r in rules] == [("66666", "2025-03-01", "2025-03-02")]
    assert st["retro_deleted"] == 3 and st["skipped_indicator9"] == 1 and st["bad_indicator"] == 0
    assert "3 EffDt==DelDt retroactive deletions" in capsys.readouterr().out


# ================================================================ C2-10 strict deletion dates
@pytest.mark.parametrize("bad", ["20251301", 0, "0", "00000000", "2025-13-01", "soon"])
def test_unparseable_deletion_date_is_a_strict_error(bad, monkeypatch, capsys):
    df = ptp_df([["11111", "22222", 20100101, bad, 0, "x"], ["11111", "33333", 20100101, "*", 0, "x"]])
    with pytest.raises(ValueError, match="deletion date unparseable"):
        ing.ptp_rules(df, meta("practitioner", "ptp", 4, 2026))
    monkeypatch.setattr(config, "NCCI_STRICT", False)
    rules = ing.ptp_rules(df, meta("practitioner", "ptp", 4, 2026))
    assert [r.predicate["code_b"] for r in rules] == ["33333"]           # dropped, never 'active forever'
    assert "WARNING" in capsys.readouterr().out


@pytest.mark.parametrize("blank", ["*", "", None, float("nan"), pd.NA, "99999999", 99999999, "99991231",
                                   20251231.0, " 20251231 "])
def test_blank_or_open_deletion_dates_are_active(blank):
    r = ing.ptp_rules(ptp_df([["11111", "22222", 20100101, blank, 0, "x"]]), meta("practitioner", "ptp", 4, 2026))[0]
    assert r.end_date == ("2025-12-31" if str(blank).strip().startswith("2025") else None)


@pytest.mark.parametrize("cell", [20251231, "20251231", "12/31/2025", "2025-12-31", "2025-12-31 00:00:00",
                                  "12/31/2025 00:00:00", "2025/12/31", "12/31/25", date(2025, 12, 31),
                                  pd.Timestamp("2025-12-31"), np.int64(20251231), np.float64(20251231.0)])
def test_deletion_date_spellings_parse(cell):
    assert ing._parse_date(cell, open_end=True) == ("2025-12-31", True)
    assert ing._parse_date(pd.NaT) == (None, True) and ing._parse_date(True) == (None, False)


# ================================================================ C2-11 tables and codes
def test_discover_tables_raises_or_warns_on_names_it_cannot_parse(monkeypatch, capsys):
    names = ["medicaid_ncci_edit_practitioner_ptp_q4_2026", "medicaid_ncci_edit_durable_medical_equipment_ptp_q4_2026",
             "medicaid_ncci_edit_dme_mue_q4_2026_v2", "medicaid_ncci_edit_outpatient_hospital_mue_q4_2026",
             "state_rules", "ncci_acquisition_log"]
    spark = FakeSpark({n: pd.DataFrame() for n in names})
    with pytest.raises(ValueError) as e:
        ing.discover_tables(spark, "main", "sedo")
    for n in names[1:4]:
        assert n in str(e.value)
    assert "state_rules" not in str(e.value)
    got = ing.discover_tables(spark, "main", "sedo", strict=False)
    assert [m["table"] for m in got] == names[:1] and "WARNING" in capsys.readouterr().out
    monkeypatch.setattr(config, "NCCI_STRICT", False)
    assert len(ing.discover_tables(spark, "main", "sedo")) == 1


@pytest.mark.parametrize("raw,code", [(100.0, "00100"), (100, "00100"), ("938", "00938"), (1996, "01996"),
                                      ("100.0", "00100"), (" 0001a ", "0001A"), ("99213", "99213"),
                                      (np.int64(1999), "01999"), (99213.0, "99213"), (None, ""), (float("nan"), "")])
def test_codes_that_lost_leading_zeros_are_zero_padded(raw, code):
    assert ing.norm_code(raw) == code


def test_numeric_code_columns_keep_anesthesia_edits():
    # R21: '100.0' / '1999' / '1996.0' used to drop out of scope or never match PROC_CD '00100'
    df = pd.DataFrame({"Col1": [100.0, 1996.0], "Col2": [1999, 64450], "EffDt": [20100101, 20100101],
                       "DelDt": ["*", "*"], "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable": [0, 1],
                       "PTP_Edit_Rationale": ["x", "y"]})
    rules = ing.ptp_rules(df, meta("practitioner", "ptp", 4, 2026), {"00100", "01999", "01996", "64450"})
    assert [(r.predicate["code_a"], r.predicate["code_b"]) for r in rules] == [("00100", "01999"), ("01996", "64450")]
    q = pd.DataFrame({"HCPCS/CPT Code": [100.0], "Practitioner Services MUE Values": [1], "MUE Rationale": [""]})
    assert ing.mue_history([(meta("practitioner", "mue", 4, 2026), q)], {"00100"})[0].predicate["code"] == "00100"


def test_check_codes_reports_codes_that_are_not_cpt_or_hcpcs(monkeypatch, capsys):
    df = pd.DataFrame({"Col1": ["11111", "ABC", 100.0, "123456"], "Col2": ["22222", "22222", "22222", None],
                       "EffDt": [20100101] * 4})
    with pytest.raises(ValueError, match="2 rows with a procedure code"):
        ing.check_codes(df, meta("practitioner", "ptp", 4, 2026))
    monkeypatch.setattr(config, "NCCI_STRICT", False)
    out = ing.check_codes(df, meta("practitioner", "ptp", 4, 2026))
    assert list(out["Col1"]) == ["11111", "ABC", "00100", "123456"] and list(out["Col2"])[-1] == ""
    printed = capsys.readouterr().out
    assert "2 rows with a procedure code that is not a 5-character" in printed and "'ABC/22222'" in printed


def test_scope_variants_match_unpadded_spellings_only():
    v = set(ing.scope_variants({"00100", "99213", "0001A", "J3490"}))
    assert {"00100", "0100", "100", "99213", "0001A", "J3490"} <= v
    assert "1" not in v and "10" not in v and "001A" not in v


def test_ingest_tables_keeps_numeric_code_tables_in_scope(fake_pyspark, monkeypatch, capsys):
    _no_acquisition_log(monkeypatch)
    tables = {
        "medicaid_ncci_edit_practitioner_ptp_q4_2026": pd.DataFrame({
            "Col1": [100, 1996, 11111], "Col2": [1999, 64450, 22222], "EffDt": [20100101] * 3, "DelDt": ["*"] * 3,
            "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable": [0, 1, 0], "PTP_Edit_Rationale": ["x"] * 3}),
        "medicaid_ncci_edit_practitioner_mue_q4_2026": pd.DataFrame({
            "HCPCS/CPT Code": [100.0, 99213.0], "Practitioner Services MUE Values": [1, 4], "MUE Rationale": ["", ""]}),
    }
    rules = ing.ingest_tables(FakeSpark(tables), "main", "sedo", code_filter={"00100", "01999", "01996", "64450", "99213"})
    got = sorted((r.predicate["type"], tuple(r.codes)) for r in rules)
    assert got == [("code_pair_prohibited", ("00100", "01999")), ("code_pair_prohibited", ("01996", "64450")),
                   ("max_units_per_line", ("00100",)), ("max_units_per_line", ("99213",))]
    assert "numeric" in capsys.readouterr().out                          # the lost zeros are reported


def test_unscoped_ingest_refuses_a_table_with_junk_codes(fake_pyspark, monkeypatch):
    _no_acquisition_log(monkeypatch)
    t = {"medicaid_ncci_edit_practitioner_ptp_q4_2026": ptp_df([["11111", "22222", 20100101, "*", 0, "x"],
                                                                ["Column 1", "Column 2", "EffDt", "*", "x", "x"]])}
    with pytest.raises(ValueError, match="not a 5-character CPT/HCPCS code"):
        ing.ingest_tables(FakeSpark(t), "main", "sedo")


# ================================================================ C2-21 duplicate MUE codes
def test_duplicate_mue_codes_in_one_quarter(monkeypatch, capsys):
    m = meta("dme", "mue", 4, 2026)
    same = ing.mue_history([(m, mue_df([["E0601", 4, "a"], ["E0601", 4, "b"]], "DME Supplier"))])
    assert [(r.predicate["code"], r.predicate["threshold"]) for r in same] == [("E0601", 4)]
    assert "1 duplicate row(s) with identical values de-duplicated" in capsys.readouterr().out
    diff = mue_df([["E0601", 4, "a"], ["E0601", 2, "b"]], "DME Supplier")
    with pytest.raises(ValueError, match="DIFFERENT MUE values"):
        ing.mue_history([(m, diff)])
    monkeypatch.setattr(config, "NCCI_STRICT", False)
    kept = ing.mue_history([(m, diff)])
    assert [(r.predicate["code"], r.predicate["threshold"]) for r in kept] == [("E0601", 4)]   # max, not last
    assert "WARNING" in capsys.readouterr().out


def test_fractional_mue_value_is_not_truncated_to_a_stricter_limit():
    with pytest.raises(ValueError, match="non-numeric MUE"):
        ing.mue_history([(meta("dme", "mue", 4, 2026), mue_df([["E0601", 4.9, "a"]], "DME Supplier"))])


# ================================================================ C2-23 9999-12-31
def test_far_future_end_dates_are_open_and_never_overflow():
    r1 = ing.ptp_rules(ptp_df([["11111", "22222", 20100101, 99991231, 0, "x"]]), meta("practitioner", "ptp", 4, 2026))
    r2 = ing.ptp_rules(ptp_df([["11111", "22222", 20100101, 99991231, 1, "x"]]), meta("dme", "ptp", 4, 2026))
    assert r1[0].end_date is None
    out, _ = rn.normalize_rules([ptp("11111", "22222", "0", "practitioner", "2010-01-01", "9999-12-31"),
                                 ptp("11111", "22222", "1", "dme", "2010-01-01", "9999-12-30")])
    assert all(r["end_date"] is None for r in out)
    assert rn._bounds({"effective_date": "2010-01-01", "end_date": "9999-12-31"})[1] == date.max
    assert len(build(r1 + r2)[0]) == 2                                  # A: collapsed pair, O: dme pair


# ================================================================ C2-24 MAI column
def test_mai_column_is_matched_on_exact_names_only():
    q = pd.DataFrame({"HCPCS/CPT Code": ["A4218"], "MUE Values": [2], "Remaining_Units_Note": ["7 see note"]})
    r = ing.mue_history([(meta("dme", "mue", 4, 2026), q)])[0]
    assert "mai" not in r.predicate
    for col in ("MUE Adjudication Indicator", "MUE_Adjudication_Indicator", "Adjudication Indicator", "MAI"):
        q = pd.DataFrame({"HCPCS/CPT Code": ["A4218"], "MUE Values": [2], col: [3]})
        assert ing.mue_history([(meta("dme", "mue", 4, 2026), q)])[0].predicate["mai"] == 3, col


# ================================================================ C2-12 CCMI across quarters
def _frame(rows):
    return pd.DataFrame(rows, columns=["code_a", "code_b", "eff", "mi"])


def test_ccmi_changes_compares_same_pair_and_effective_date_only():
    old = _frame([("11111", "22222", "2010-01-01", "1"), ("11111", "33333", "2010-01-01", "0"),
                  ("11111", "44444", "2010-01-01", "9"), ("11111", "55555", "2010-01-01", "0"),
                  ("11111", "66666", "2010-01-01", "1"), ("11111", "77777", "2010-01-01", "0")])
    new = _frame([("11111", "22222", "2010-01-01", "0"), ("11111", "33333", "2010-01-01", "1"),
                  ("11111", "44444", "2010-01-01", "0"), ("11111", "55555", "2010-01-01", "0"),
                  ("11111", "66666", "2015-01-01", "0"), ("11111", "88888", "2010-01-01", "0")])
    ch = ing.ccmi_changes(old, new)
    got = {r["code_b"]: (r["mi_old"], r["mi_new"], r["mi_before"]) for r in ch.to_dict("records")}
    assert got == {"22222": ("1", "0", "1"), "33333": ("0", "1", "1"), "44444": ("9", "0", "9")}
    assert ing.ccmi_changes(None, new).empty and ing.ccmi_changes(old.iloc[:0], new).empty


def test_ccmi_split_windows():
    s = "2026-10-01"
    assert ing.ccmi_split("2010-01-01", None, "0", "1", s) == [("2010-01-01", "2026-09-30", "1"), ("2026-10-01", None, "0")]
    assert ing.ccmi_split("2010-01-01", "2020-12-31", "0", "1", s) == [("2010-01-01", "2020-12-31", "1")]
    assert ing.ccmi_split("2010-01-01", None, "1", "1", s) == [("2010-01-01", None, "1")]          # newest already permissive
    assert ing.ccmi_split("2010-01-01", None, "0", "9", s) == [("2026-10-01", None, "0")]          # no edit before
    assert ing.ccmi_split("2010-01-01", "2020-12-31", "0", "9", s) == []
    assert ing.ccmi_split("2026-11-01", None, "0", "1", s) == [("2026-11-01", None, "0")]


def test_ptp_rules_splits_a_pair_whose_indicator_changed():
    newest = meta("practitioner", "ptp", 4, 2026)
    df = ptp_df([["11111", "22222", 20100101, "*", 0, "x"], ["11111", "33333", 20100101, "*", 0, "y"]])
    ch = ing.ccmi_changes(_frame([("11111", "22222", "2010-01-01", "1"), ("11111", "33333", "2010-01-01", "0")]),
                          ing.ptp_indicator_frame(df))
    st = {}
    rules = ing.ptp_rules(df, newest, stats=st, ccmi=ch, ccmi_from=meta("practitioner", "ptp", 1, 2025))
    segs = sorted((r.predicate["code_b"], r.effective_date, r.end_date, r.predicate["modifier_indicator"]) for r in rules)
    assert segs == [("22222", "2010-01-01", "2026-09-30", "1"), ("22222", "2026-10-01", None, "0"),
                    ("33333", "2010-01-01", None, "0")]
    split = [r for r in rules if r.predicate["code_b"] == "22222"]
    assert all(r.ambiguity_flag and r.reconciliation == "ccmi_changed_across_quarters" for r in split)
    assert all("medicaid_ncci_edit_practitioner_ptp_q1_2025" in r.ambiguity_note for r in split)
    assert "(modifier indicator 1)" in [r for r in split if r.effective_date == "2010-01-01"][0].statement
    assert st["ccmi_flagged"] == 1 and st["ccmi_split"] == 1
    unchanged = [r for r in rules if r.predicate["code_b"] == "33333"][0]
    assert not unchanged.ambiguity_flag and unchanged.reconciliation is None


def test_ingest_tables_compares_the_oldest_and_newest_ptp_quarter(fake_pyspark, monkeypatch):
    _no_acquisition_log(monkeypatch)
    old = ptp_df([["11111", "22222", 20100101, "*", 1, "x"], ["11111", "33333", 20100101, "*", 0, "x"],
                  ["99999", "22222", 20100101, "*", 1, "x"]])
    mid = ptp_df([["11111", "22222", 20100101, "*", 1, "x"]])
    new = ptp_df([["11111", "22222", 20100101, "*", 0, "x"], ["11111", "33333", 20100101, "*", 0, "x"],
                  ["99999", "22222", 20100101, "*", 0, "x"]])
    spark = FakeSpark({"medicaid_ncci_edit_practitioner_ptp_q1_2025": old,
                       "medicaid_ncci_edit_practitioner_ptp_q2_2025": mid,
                       "medicaid_ncci_edit_practitioner_ptp_q4_2026": new})
    rep = {}
    rules = ing.ingest_tables(spark, "main", "sedo", code_filter={"11111", "22222", "33333"}, report=rep)
    segs = sorted((r.predicate["code_b"], r.effective_date, r.end_date, r.predicate["modifier_indicator"]) for r in rules)
    # 99999/22222 is out of scope in BOTH files (the oldest is scoped like the newest)
    assert segs == [("22222", "2010-01-01", "2026-09-30", "1"), ("22222", "2026-10-01", None, "0"),
                    ("33333", "2010-01-01", None, "0")]
    assert rep["ptp"]["practitioner"]["compared_with"] == "2025Q1" and rep["ptp"]["practitioner"]["ccmi_split"] == 1
    # 2026-10-04: the CMS file's size next to the part that can touch these claims (the newest PTP quarter is read
    # for rules; 99999/22222 is out of scope)
    assert rep["claims_scoped"] is True
    assert rep["source_vs_claims_scope"] == [{"table": "medicaid_ncci_edit_practitioner_ptp_q4_2026",
                                              "service": "practitioner", "edit_type": "ptp", "quarter": "2026Q4",
                                              "source_rows": 3, "rows_in_claims_scope": 2}]
    assert ing.scope_lines(rep["source_vs_claims_scope"], True) == [
        "PTP practitioner 2026Q4: 3 rows in the CMS file; 2 with both codes paid in these claims (66.7%)"]
    assert ing.scope_lines(rep["source_vs_claims_scope"], False)[0].endswith("no claims scope (all rows read)")
    json.dumps(rep)
    # end to end: the split survives normalize as two form-A rules, still labelled
    out, _ = build(rules)
    lab = sorted(r["reconciliation"] for r in out if r["predicate"]["code_b"] == "22222")
    assert lab == ["ccmi_changed_across_quarters"] * 2


# ================================================================ C2-03 later MUE changes
def test_mue_runs_carry_later_quarter_changes():
    q = lambda n: meta("practitioner", "mue", n, 2026)                 # noqa: E731
    rules = ing.mue_history([(q(2), mue_df([["37256", 1, "x"], ["77777", 1, "x"], ["44444", 4, "x"]])),
                             (q(3), mue_df([["37256", 3, "x"], ["88888", 1, "x"], ["44444", 2, "x"]]))])
    by = {(r.predicate["code"], r.effective_date): r.predicate for r in rules}
    assert by[("37256", "2026-04-01")]["later_max_threshold"] == 3          # R4: raised 1 -> 3 later
    assert by[("37256", "2026-04-01")]["removed_later"] is False
    assert by[("77777", "2026-04-01")]["removed_later"] is True              # R4b: dropped in Q3
    assert by[("77777", "2026-04-01")]["later_max_threshold"] is None
    assert by[("44444", "2026-04-01")]["later_max_threshold"] == 2           # lowered: never a 'verify'
    assert "later_max_threshold" not in by[("37256", "2026-07-01")]          # open run: nothing later
    out, _ = rn.normalize_rules([r.to_dict() for r in rules])
    cur = [r["predicate"] for r in out if r["predicate"]["code"] == "37256" and r["effective_date"] == "2026-07-01"]
    assert cur and all(p["later_max_threshold"] is None and p["removed_later"] is False for p in cur)
    assert "verify_mue_changed_later" in [r for r in rules if r.predicate["code"] == "37256"][0].notes


def test_later_changes_pure():
    qs = [{"label": x} for x in ("2026Q1", "2026Q2", "2026Q3", "2026Q4")]
    per_q = {"2026Q1": (1,), "2026Q2": (1,), "2026Q4": (5,)}
    assert ing.later_changes(per_q, qs, "2026Q2") == (5, True)
    assert ing.later_changes(per_q, qs, "2026Q4") == (None, False)
    assert ing.later_changes({"2026Q1": (2,), "2026Q2": (3,), "2026Q3": (1,), "2026Q4": (1,)}, qs, "2026Q1") == (3, False)


def test_mue_rule_id_does_not_move_when_a_later_quarter_is_loaded():
    q = lambda n: (meta("practitioner", "mue", n, 2026), mue_df([["37256", {2: 1, 3: 3, 4: 5}[n], "x"]]))  # noqa: E731
    two = [r for r in ing.mue_history([q(2), q(3)]) if r.effective_date == "2026-04-01"][0]
    three = [r for r in ing.mue_history([q(2), q(3), q(4)]) if r.effective_date == "2026-04-01"][0]
    assert two.predicate["later_max_threshold"] == 3 and three.predicate["later_max_threshold"] == 5
    assert two.rule_id == three.rule_id
    n2, _ = rn.normalize_rules([two.to_dict()])
    n3, _ = rn.normalize_rules([three.to_dict()])
    assert sorted(r["rule_id"] for r in n2) == sorted(r["rule_id"] for r in n3)
    assert rn.rule_id_for(n3[0]) == n3[0]["rule_id"]


# ================================================================ C2-19 provenance
SHA = "ab12" * 16
URL = "https://www.cms.gov/files/zip/medicaid-ncci-2026-q4-ptp-edits-practitioner-services.zip"


def _prov_tables():
    return {"medicaid_ncci_edit_practitioner_ptp_q4_2026": ptp_df([["11111", "22222", 20100101, "*", 1, "x"]]),
            "medicaid_ncci_edit_dme_mue_q4_2026": pd.DataFrame({"HCPCS/CPT Code": ["E0601"],
                                                                "DME Supplier Services MUE Values": [1],
                                                                "MUE Rationale": ["x"]})}


def test_provenance_cites_the_archived_zip_and_marks_hand_loaded_tables(fake_pyspark, monkeypatch):
    import acquire_ncci
    _no_acquisition_log(monkeypatch)
    base = {r.rule_id: r for r in ing.ingest_tables(FakeSpark(_prov_tables()), "main", "sedo")}
    calls = []

    def fake_prov(spark, catalog, schema):
        calls.append((catalog, schema))
        return {"medicaid_ncci_edit_practitioner_ptp_q4_2026": {"src_sha256": SHA, "src_url": URL, "status": "loaded",
                                                                "loaded_at": "2026-10-01T00:00:00+00:00"}}
    monkeypatch.setattr(acquire_ncci, "acquisition_provenance", fake_prov, raising=False)
    rules = {r.rule_id: r for r in ing.ingest_tables(FakeSpark(_prov_tables()), "main", "sedo")}
    assert calls == [("main", "sedo")] and set(rules) == set(base)            # ids never depend on provenance
    p = [r for r in rules.values() if r.predicate["type"] == "code_pair_prohibited"][0]
    m = [r for r in rules.values() if r.predicate["type"] == "max_units_per_line"][0]
    assert (p.doc_hash, p.source_url, p.doc_version) == (SHA, URL, "medicaid_ncci_edit_practitioner_ptp_q4_2026")
    assert m.doc_version == "hand_loaded:medicaid_ncci_edit_dme_mue_q4_2026"
    assert m.doc_hash == base[m.rule_id].doc_hash and len(m.doc_hash) == 16  # content hash kept
    assert m.source_url == ing.MEDICAID_NCCI_URL


def test_provenance_falls_back_to_the_tables_own_src_columns(fake_pyspark, monkeypatch, capsys):
    import acquire_ncci

    def boom(spark, catalog, schema):
        raise RuntimeError("log table missing")
    monkeypatch.setattr(acquire_ncci, "acquisition_provenance", boom, raising=False)
    t = _prov_tables()
    t["medicaid_ncci_edit_dme_mue_q4_2026"] = t["medicaid_ncci_edit_dme_mue_q4_2026"].assign(
        src_zip="m.zip", src_sha256="cd34" * 16, src_url=None, src_member="MUE.txt", loaded_at="x")
    rules = ing.ingest_tables(FakeSpark(t), "main", "sedo")
    m = [r for r in rules if r.predicate["type"] == "max_units_per_line"][0]
    p = [r for r in rules if r.predicate["type"] == "code_pair_prohibited"][0]
    assert m.doc_hash == "cd34" * 16 and m.doc_version == "medicaid_ncci_edit_dme_mue_q4_2026"
    assert m.source_url == ing.MEDICAID_NCCI_URL                              # drop-zone load: no download URL
    assert p.doc_version.startswith("hand_loaded:")
    assert "log table missing" in capsys.readouterr().out


def test_table_rows_outrank_a_disagreeing_acquisition_log(capsys):
    m = meta("dme", "mue", 4, 2026)
    df = pd.DataFrame({"HCPCS/CPT Code": ["E0601"], "src_sha256": ["cd34" * 16], "src_url": [None]})
    same = ing.table_provenance({m["table"]: {"sha256": "cd34" * 16, "url": URL}}, m, df)
    assert same["sha256"] == "cd34" * 16 and same["url"] == URL               # same zip: the log's URL is used
    other = ing.table_provenance({m["table"]: {"sha256": SHA, "url": URL}}, m, df)
    assert other["sha256"] == "cd34" * 16 and other["url"] is None            # the rows travel with the data
    assert "acquisition log says" in capsys.readouterr().out
    assert ing.table_provenance({m["table"]: {"sha256": SHA, "url": URL}}, m, df.drop(columns=["src_sha256"]))["sha256"] == SHA
    assert ing.table_provenance({}, m, df.drop(columns=["src_sha256"])) is None


def test_normalize_provenance_accepts_the_shapes_acquire_can_return():
    import acquire_ncci as acq
    rows = [acq.LoadResult(quarter="2026q4", edit="ptp", service="practitioner", kind="edits", url=URL,
                           table="medicaid_ncci_edit_practitioner_ptp_q4_2026", status="loaded", sha256=SHA,
                           loaded_at="2026-10-01T00:00:00+00:00"),
            acq.LoadResult(quarter="2026q4", edit="mue", service="dme", kind="edits", url=URL,
                           table="medicaid_ncci_edit_dme_mue_q4_2026", status="skipped_exists", sha256="ff" * 32),
            acq.LoadResult(quarter="2026q4", edit="mue", service="practitioner", kind="edits", url=URL,
                           table="medicaid_ncci_edit_practitioner_mue_q4_2026", status="failed", sha256="ee" * 32)]
    for raw in (rows, pd.DataFrame([vars(r) for r in rows])):
        got = ing.normalize_provenance(raw)
        assert set(got) == {"medicaid_ncci_edit_practitioner_ptp_q4_2026"} and got[
            "medicaid_ncci_edit_practitioner_ptp_q4_2026"]["sha256"] == SHA
    newer = {"main.sedo.T1": {"src_sha256": "old", "loaded_at": "2026-01-01"}}
    assert ing.normalize_provenance(newer) == {"t1": {"sha256": "old", "url": None, "zip": None, "loaded_at": "2026-01-01"}}
    assert ing.normalize_provenance({"t2": SHA})["t2"]["sha256"] == SHA       # {table: '<sha256>'}
    two = [{"table": "t", "sha256": "a", "loaded_at": "2026-01-01"}, {"table": "t", "sha256": "b", "loaded_at": "2026-02-01"}]
    assert ing.normalize_provenance(two)["t"]["sha256"] == "b"               # latest load wins
    assert ing.normalize_provenance(None) == {}


# ================================================================ C2-14 newest quarter end
def test_newest_quarter_end_per_service_and_edit():
    metas = [meta("practitioner", "ptp", 3, 2026), meta("practitioner", "ptp", 4, 2026),
             meta("dme", "mue", 2, 2026), meta("dme", "mue", 3, 2026), meta("outpatient", "mue", 1, 2027)]
    assert ing.newest_quarter_end(metas) == {("dme", "mue"): "2026-09-30", ("outpatient", "mue"): "2027-03-31",
                                             ("practitioner", "ptp"): "2026-12-31"}


# ================================================================ route note
def test_route_note_describes_edit_file_routing(monkeypatch):
    n = ing.route_note()
    assert "Table 2" in n and "provider type" in n and "never merged" in n and "ncci_edition" in n
    assert "dental, pharmacy, inpatient or residential" in n
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    n = ing.route_note()
    assert "BILLING provider type CODE" in n and "servicing type also says whether a rendering practitioner" in n
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "none")
    assert "a provider type the table does not map: no NCCI on the line" in ing.route_note()
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "provider_type")
    assert "SERVICING provider type CODE" in ing.route_note()
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "form")
    assert "routing by claim FORM only" in ing.route_note()


