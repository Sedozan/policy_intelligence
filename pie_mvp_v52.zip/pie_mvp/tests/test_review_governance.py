"""
Review-governance fixes (critic C4 + the C3 review-workbook findings), each pinned by a test that EXECUTES
the code path:
  * the review ingest through the fake-Spark pattern of tests/test_phase15.py::_review,
  * kb_io against an in-memory catalog (FakeSpark) that enforces Delta-style append type merging and
    supports or refuses DELETE (Delta vs the offline e2e's parquet),
  * notebooks 02 / 05 / 06 run from SOURCE against that catalog (like tests/e2e_local_spark.py, no Spark).
Run: cd pie_mvp && python -m pytest tests -q
"""
from __future__ import annotations

import glob
import hashlib
import importlib
import json
import os
import re
import sys
import types

import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, PKG)
sys.path.insert(0, HERE)

import config  # noqa: E402
import detector_gen as dg  # noqa: E402
import kb_io  # noqa: E402
import rule_normalize as rn  # noqa: E402
import schema  # noqa: E402
import state_rules as sr  # noqa: E402
import state_seed  # noqa: E402
import validate_gate as vg  # noqa: E402
from extract_io import guard_state_rules_merge  # noqa: E402
from schema import Rule  # noqa: E402

P4 = {"type": "max_units_per_day", "code": "98960", "threshold": 4}


# ------------------------------------------------------------------ rows
def _row(key, status="draft", doc_hash="DOC1", reviewer=None, chapter="10", pred=None, quote=None,
         statement="98960: maximum 4 units per day.", population="all", section_id=None, eff=None, end=None):
    pred = dict(pred or P4)
    r = sr.rule_to_row(Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy",
                            statement=statement, source_doc="Ch10", source_locator="page 9", predicate=pred,
                            codes=schema.predicate_codes(pred), doc_hash=doc_hash, population=population,
                            verbatim_quote=quote, section_id=section_id, effective_date=eff, end_date=end),
                       chapter=chapter, review_status=status, reviewer=reviewer)
    r.update(rule_id=f"EXT-{key}", extraction_key=key, extraction_run_id="R0")
    return r


def _seed_row(pred=None, status="legacy_hand_authored", statement="S5150: maximum 48 unit(s) per day."):
    pred = dict(pred or {"type": "max_units_per_day", "code": "S5150", "threshold": 48})
    r = Rule(origin="manual", plane="coverage_scope", binding_status="state_policy", statement=statement,
             source_doc=state_seed.CH19, source_locator="page 30", source_url=state_seed.CH19_URL, predicate=pred,
             codes=schema.predicate_codes(pred))
    row = sr.rule_to_row(r, chapter="19", review_status=status, review_note="seeded during MVP build")
    row["rule_id"] = schema.stable_rule_id(r.to_dict())
    return row


def _wb(rows, **fill):
    """The exported workbook rows (review_frame), every row filled with `fill`."""
    return [dict(r, **fill) for r in sr.review_frame(pd.DataFrame(rows)).to_dict("records")]


# --------------------------------------------- the test_phase15 `_review` pattern
class _Frame:
    def __init__(self, rows): self.rows = rows
    def toPandas(self): return pd.DataFrame(self.rows).copy()


class _Spark:
    def __init__(self, rows): self.rows = rows
    def table(self, t): return _Frame(self.rows)


def _review(monkeypatch, workbook_rows, table_rows):
    captured, logged = {}, {}
    monkeypatch.setattr(sr, "_xlsx_read", lambda p: pd.DataFrame(workbook_rows))
    monkeypatch.setattr(sr, "write_state_rules",
                        lambda s, t, rows: captured.update(rows={r["rule_id"]: r for r in rows}))
    monkeypatch.setattr(kb_io, "write_table",
                        lambda spark, df, fqn, mode="overwrite", **kw: logged.update(df=df, mode=mode, **kw) or 0)
    res = sr.ingest_review_decisions(_Spark(table_rows), "t", "x", "l")
    return captured.get("rows"), logged, res


# --------------------------------------------- an in-memory catalog (no Spark)
def _fake_types():
    T = types.ModuleType("pyspark.sql.types")

    class DataType:
        _name = "?"
        def typeName(self): return self._name
        def simpleString(self): return {"long": "bigint", "integer": "int"}.get(self._name, self._name)
        def __eq__(self, o): return isinstance(o, DataType) and o._name == self._name
        def __hash__(self): return hash(self._name)
        def __repr__(self): return f"{type(self).__name__}()"

    for cls, nm in (("StringType", "string"), ("LongType", "long"), ("IntegerType", "integer"),
                    ("DoubleType", "double"), ("BooleanType", "boolean"), ("DateType", "date"),
                    ("TimestampType", "timestamp")):
        setattr(T, cls, type(cls, (DataType,), {"_name": nm}))

    class StructField:
        def __init__(self, name, dataType, nullable=True):
            self.name, self.dataType, self.nullable = name, dataType, nullable

    class StructType:
        def __init__(self, fields): self.fields = list(fields)

    T.DataType, T.StructField, T.StructType = DataType, StructField, StructType
    return T


@pytest.fixture
def fake_pyspark(monkeypatch):
    T = _fake_types()
    pyspark, sql = types.ModuleType("pyspark"), types.ModuleType("pyspark.sql")
    sql.types, pyspark.sql = T, sql
    for name, mod in (("pyspark", pyspark), ("pyspark.sql", sql), ("pyspark.sql.types", T)):
        monkeypatch.setitem(sys.modules, name, mod)
    return T


class _Writer:
    def __init__(self, df): self.df, self._mode, self.opts = df, "errorifexists", {}
    def format(self, f): return self
    def mode(self, m): self._mode = m; return self
    def option(self, k, v): self.opts[k] = v; return self

    def saveAsTable(self, fqn):
        sp, pdf, st = self.df.spark, self.df.pdf, self.df.struct
        if self._mode == "append" and fqn in sp.tables:
            old_pdf, old_st = sp.tables[fqn]
            old = {f.name: f.dataType for f in old_st.fields}
            for f in st.fields:                    # Delta: a column keeps its type; a clash fails the append
                if f.name in old and old[f.name] != f.dataType:
                    raise Exception(f"[DELTA_FAILED_TO_MERGE_FIELDS] {fqn}.{f.name}: {old[f.name]!r} vs {f.dataType!r}")
            added = [f for f in st.fields if f.name not in old]
            if added and self.opts.get("mergeSchema") != "true":
                raise Exception(f"schema mismatch on append to {fqn}: {[f.name for f in added]}")
            struct = type(st)(old_st.fields + added)
            both = pd.concat([old_pdf.astype(object), pdf.astype(object)], ignore_index=True)
            sp.tables[fqn] = (both[[f.name for f in struct.fields]], struct)
        else:
            sp.tables[fqn] = (pdf.copy(), st)
        sp.writes.append((fqn, self._mode, len(pdf)))


class _DF:
    def __init__(self, spark, pdf, struct): self.spark, self.pdf, self.struct = spark, pdf, struct
    @property
    def columns(self): return [f.name for f in self.struct.fields]
    @property
    def schema(self): return self.struct
    @property
    def write(self): return _Writer(self)

    def toPandas(self):                          # Spark's typing: a long with nulls comes back as float64
        out = self.pdf.copy()
        for f in self.struct.fields:
            k, s = f.dataType.typeName(), out[f.name]
            if k in ("long", "integer"):
                out[f.name] = s.astype("float64") if s.isna().any() else s.astype("int64")
            elif k == "double":
                out[f.name] = s.astype("float64")
            elif k == "boolean":
                out[f.name] = s.astype(object) if s.isna().any() else s.astype(bool)
            else:
                out[f.name] = s.astype(object).where(s.notna(), None)
        return out


class FakeSpark:
    def __init__(self, delete_supported: bool = True):
        self.tables: dict = {}
        self.writes: list = []
        self.delete_supported = delete_supported
        self.conf = types.SimpleNamespace(set=lambda *a: None)
        self.catalog = types.SimpleNamespace(tableExists=lambda fqn: fqn in self.tables)

    def table(self, fqn):
        if fqn not in self.tables:
            raise Exception(f"[TABLE_OR_VIEW_NOT_FOUND] The table or view `{fqn}` cannot be found.")
        return _DF(self, *self.tables[fqn])

    def createDataFrame(self, data, schema=None):
        pdf = data.copy() if isinstance(data, pd.DataFrame) else pd.DataFrame(list(data),
                                                                             columns=[f.name for f in schema.fields])
        return _DF(self, pdf, schema)

    def sql(self, q):
        m = re.match(r"\s*(SELECT COUNT\(\*\) AS n FROM|DELETE FROM) (\S+) WHERE `(\w+)` IN \((.*)\)\s*$", q, re.S)
        if not m:                                # e.g. 02's display query: not modelled
            return _DF(self, pd.DataFrame(), sys.modules["pyspark.sql.types"].StructType([]))
        verb, fqn, col, lits = m.groups()
        vals = set(re.findall(r"'((?:[^'\\]|\\.)*)'", lits))
        pdf, st = self.tables[fqn]
        hit = pdf[col].map(lambda v: v is not None and str(v) in vals)
        if verb.startswith("SELECT"):
            return types.SimpleNamespace(collect=lambda: [[int(hit.sum())]])
        if not self.delete_supported:
            raise Exception("[UNSUPPORTED_FEATURE] DELETE is only supported with v2 tables.")
        self.tables[fqn] = (pdf[~hit].reset_index(drop=True), st)
        return None


def _types_of(spark, fqn):
    return {f.name: f.dataType.typeName() for f in spark.tables[fqn][1].fields}


# ====================================================================== C4-03
def test_C4_03_stale_check_fails_closed_without_a_current_document_hash():
    df = pd.DataFrame([_row("k1", "approved", "OLD", "kim")])
    for cur in (None, {}, {"19": "X"}, {"10": None}, {"10": float("nan")}):
        rep = {}
        assert sr.rules_from_frame(df, current_doc_hash=cur, report=rep) == [], cur
        assert [(s["rule_id"], s["reason"]) for s in rep["stale"]] == [("EXT-k1", "no_inventory")]
    rep = {}
    assert sr.rules_from_frame(df, current_doc_hash={"10": "NEW"}, report=rep) == []
    assert rep["stale"][0]["reason"] == "doc_changed"
    assert len(sr.rules_from_frame(df, current_doc_hash={"10": "OLD"})) == 1
    assert len(sr.rules_from_frame(df.assign(chapter=10.0), current_doc_hash={10: "OLD"})) == 1   # dtype-proof
    rep = {}                                     # an extracted approval with no document version at all
    assert sr.rules_from_frame(pd.DataFrame([_row("k2", "approved", "", "kim")]),
                               current_doc_hash={"10": "OLD"}, report=rep) == []
    assert rep["stale"][0]["reason"] == "no_doc_hash"
    assert sr.stale_mask(df, {}).tolist() == [True]                     # the d07 demo's view agrees


def test_C4_03_C4_05_seeds_follow_the_switch_unless_signed(monkeypatch):
    seed = _seed_row()
    signed = dict(_seed_row({"type": "code_not_covered", "code": "11975"}, status="approved"), reviewer="SS")
    df = pd.DataFrame([seed, signed])
    monkeypatch.setattr(config, "COMPILE_LEGACY_SEEDS", True)
    assert len(sr.rules_from_frame(df, current_doc_hash={})) == 2      # no doc_hash -> never stale
    monkeypatch.setattr(config, "COMPILE_LEGACY_SEEDS", False)
    rep = {}
    got = sr.rules_from_frame(df, current_doc_hash={}, report=rep)
    assert [r.predicate["type"] for r in got] == ["code_not_covered"]
    assert rep == {"stale": [], "legacy": 0, "engine_excluded": []}     # run_prompt None: the one-engine rule is off


# ====================================================================== C4-17
def test_C4_17_nan_flags_never_become_true():
    import numpy as np
    r = _row("k9", "approved", "D", "kim")
    for v in (float("nan"), None, pd.NA):
        r.update(deactivated=v, ambiguity_flag=v, machine_checkable=v)
        rule = sr.row_to_rule(r)
        assert (rule.deactivated, rule.ambiguity_flag, rule.machine_checkable) == (False, False, False)
    r.update(deactivated="False", ambiguity_flag="true", machine_checkable=np.bool_(True))
    rule = sr.row_to_rule(r)
    assert (rule.deactivated, rule.ambiguity_flag, rule.machine_checkable) == (False, True, True)
    # the load filter and the rule agree: a NaN 'deactivated' loads AND compiles (it used to load as deactivated)
    r.update(deactivated=float("nan"), ambiguity_flag=False, machine_checkable=True)
    acc, _ = vg.gate(sr.rules_from_frame(pd.DataFrame([r]), current_doc_hash={"10": "D"}))
    assert acc[0]["deactivated"] is False and dg.build_detectors(acc)[0]["compiled"]


# ====================================================================== C4-04
def test_C4_04_a_fix_survives_a_new_document_version(monkeypatch):
    fixed_pred = {"type": "max_units_per_day", "code": "98960", "threshold": 6}
    orig = _row("k1")
    rows, _, _ = _review(monkeypatch, [{"rule_id": "EXT-k1", "decision": "fix", "reviewer": "SS", "doc_hash": "DOC1",
                                        "corrected_predicate": json.dumps(fixed_pred),
                                        "corrected_rule": "98960: maximum 6 units per day."}], [orig])
    fixed = rows["EXT-k1"]
    assert fixed["review_status"] == "approved" and fixed["review_decision"] == "fix"
    merged, counts = sr.merge_drafts(pd.DataFrame([fixed]), [_row("k1", doc_hash="DOC2")])
    m = merged.iloc[0].to_dict()
    assert counts["resign_new_version"] == 1 and m["review_status"] == "needs_review"
    prior = json.loads(m["prior_review"])
    assert (prior["decision"], prior["reviewer"], prior["doc_hash"]) == ("fix", "SS", "DOC1")
    assert prior["predicate"] == fixed_pred and prior["statement"] == "98960: maximum 6 units per day."
    assert json.loads(m["predicate"])["threshold"] == 4                   # the live predicate is the new extraction
    wb = _wb([m])[0]
    assert wb["previous_decision"].startswith(f"Fix by SS {prior['reviewed_at'][:10]}: ")
    assert '"threshold": 6' in wb["previous_decision"]
    # a plain re-sign would revert the Fix to the model's predicate -> refused, nothing changes
    rows, _, res = _review(monkeypatch, [dict(wb, decision="Approve", reviewer="SS")], [m])
    assert res["outcomes"] == ["approve_reverts_fix"] and rows["EXT-k1"]["review_status"] == "needs_review"
    assert json.loads(rows["EXT-k1"]["predicate"])["threshold"] == 4
    assert sr.parked_reason(rows["EXT-k1"]["review_note"]) == "approve_reverts_fix"
    # re-signing the earlier correction with Fix keeps it
    rows, log, res = _review(monkeypatch, [dict(wb, decision="Fix", reviewer="SS",
                                                corrected_predicate=json.dumps(fixed_pred))], [m])
    assert res["outcomes"] == ["fixed"] and json.loads(rows["EXT-k1"]["predicate"])["threshold"] == 6
    assert list(log["df"]["previous_decision"])[0].startswith("Fix by SS")


def test_C4_04_a_pending_resign_survives_another_persist():
    merged, _ = sr.merge_drafts(pd.DataFrame([_row("k1", "approved", "DOC1", "kim")]), [_row("k1", doc_hash="DOC2")])
    again, c = sr.merge_drafts(merged, [_row("k1", doc_hash="DOC2")])          # 05 re-run, or a later run
    r = again.iloc[0]
    assert r["review_status"] == "needs_review" and json.loads(r["prior_review"])["reviewer"] == "kim"
    assert c["kept_resign_pending"] == 1
    guard_state_rules_merge(merged, again, "t")        # dropping the prior_review used to trip the shrink guard


# ====================================================================== C4-05
def test_C4_05_seeds_are_exported_and_can_be_signed(monkeypatch):
    seed, draft = _seed_row(), _row("k1")
    assert "legacy_hand_authored" in sr.export_review_workbook.__defaults__[0]
    rec = [r for r in _wb([draft, seed]) if r["rule_id"] == seed["rule_id"]][0]
    assert rec["origin"] == "manual" and not sr._text(rec["doc_hash"]) and rec["review_status"] == "legacy_hand_authored"
    # a reviewer is still required; an unsigned decision leaves the (compiling) seed exactly as it was
    rows, _, res = _review(monkeypatch, [dict(rec, decision="Approve", reviewer="")], [seed])
    assert res["outcomes"] == ["no_reviewer"] and rows[seed["rule_id"]]["review_status"] == "legacy_hand_authored"
    # signed: applied with no doc_hash check (a seed has none)
    rows, log, res = _review(monkeypatch, [dict(rec, decision="Approve", reviewer="SS")], [seed])
    r = rows[seed["rule_id"]]
    assert res["outcomes"] == ["approved"] and (r["review_status"], r["reviewer"]) == ("approved", "SS")
    assert json.loads(r["prior_review"])["status"] == "legacy_hand_authored" and list(log["df"]["origin"]) == ["manual"]
    monkeypatch.setattr(config, "COMPILE_LEGACY_SEEDS", False)            # a signed seed compiles regardless
    assert len(sr.rules_from_frame(pd.DataFrame([r]), current_doc_hash={})) == 1
    # rejecting a seed applies and is not a "shrink" of the reviewed rules
    rows, _, res = _review(monkeypatch, [dict(rec, decision="Reject", reviewer="SS")], [seed])
    assert res["outcomes"] == ["rejected"] and rows[seed["rule_id"]]["review_status"] == "rejected"


def test_C4_05_reseeding_keeps_signatures_and_retires_dropped_seeds():
    seed = _seed_row()
    old = _seed_row(P4, statement="98960: maximum 4 unit(s) per day.")          # no longer in the seed
    signed = dict(seed, review_status="approved", reviewer="SS", review_decision="approve")
    existing = pd.DataFrame([signed, old, _row("k1", "approved", "D", "kim")])
    out, c = sr.upsert_seed_rows(existing, [seed])                              # used to raise on `signed`
    by = out.set_index("rule_id")
    assert (c["kept_signed_seed"], c["retired_seed"], c["seeded"], len(out)) == (1, 1, 0, 3)
    assert (by.loc[seed["rule_id"], "review_status"], by.loc[seed["rule_id"], "reviewer"]) == ("approved", "SS")
    assert by.loc[old["rule_id"], "review_status"] == "superseded"
    assert json.loads(by.loc[old["rule_id"], "prior_review"])["status"] == "legacy_hand_authored"
    guard_state_rules_merge(existing, out, "t")                                 # retiring is not a shrink
    assert sr.rules_from_frame(out[out["rule_id"] == old["rule_id"]]) == []     # a retired seed never loads


# ====================================================================== C4-11
def test_C4_11_export_never_overwrites_a_workbook_with_reviewer_entries(tmp_path, capsys):
    path = str(tmp_path / "policy_rules_review.xlsx")
    spark = _Spark([_row("k1"), _row("k2")])
    assert sr.export_review_workbook(spark, "t", path) == path
    book = pd.read_excel(path).astype(object)
    book.loc[0, "decision"], book.loc[0, "reviewer"] = "Approve", "SS"
    book.to_excel(path, index=False)
    again = sr.export_review_workbook(spark, "t", path)
    assert again != path and re.search(r"policy_rules_review_\d{8}T\d{6}(_\d+)?\.xlsx$", again) and os.path.exists(again)
    assert pd.read_excel(path)["decision"].tolist()[0] == "Approve"            # the review in progress survived
    assert "NOT overwritten" in capsys.readouterr().out
    clean = str(tmp_path / "clean.xlsx")                                        # no entries -> simply replaced
    sr.export_review_workbook(spark, "t", clean)
    assert sr.export_review_workbook(spark, "t", clean) == clean
    junk = tmp_path / "junk.xlsx"                                               # cannot inspect -> protected
    junk.write_bytes(b"not a workbook")
    assert sr.export_review_workbook(spark, "t", str(junk)) != str(junk) and junk.read_bytes() == b"not a workbook"
    dest = sr.archive_workbook(path)                                            # 06 after a successful ingest
    assert dest and os.path.exists(dest) and not os.path.exists(path) and os.sep + "ingested" + os.sep in dest


@pytest.mark.parametrize("delta", [True, False], ids=["delta_DELETE", "parquet_rewrite"])
def test_C4_11_a_rerun_of_the_same_run_never_doubles_telemetry(fake_pyspark, monkeypatch, delta):
    monkeypatch.setattr(config, "TABLE_FORMAT", "delta" if delta else "parquet")
    spark = FakeSpark(delete_supported=delta)
    inv = [{"chapter": "10", "doc_hash": "h", "bytes": 10, "fetched_at": "t"}]   # inventory rows carry no run_id
    secs = [{"section_id": f"s{i}", "run_id": "R1", "n_chars": i} for i in range(3)]
    for _ in range(2):
        kb_io.write_run_rows(spark, inv, "kb.inv", "R1")
        kb_io.write_run_rows(spark, secs, "kb.sec", "R1")
    assert spark.tables["kb.inv"][0]["run_id"].tolist() == ["R1"]               # stamped, and once
    assert len(spark.tables["kb.sec"][0]) == 3
    kb_io.write_run_rows(spark, [{"section_id": "s9", "run_id": "R2", "n_chars": 9}], "kb.sec", "R2")
    kb_io.write_run_rows(spark, [], "kb.sec", "R1")                             # R1 re-persisted with no rows
    assert spark.table("kb.sec").toPandas()["run_id"].tolist() == ["R2"]
    assert _types_of(spark, "kb.sec")["n_chars"] == "long"
    if delta:                                    # on Delta a failing DELETE is an error, never a silent rewrite
        kb_io.write_run_rows(spark, [{"section_id": "s9", "run_id": "R2", "n_chars": 9}], "kb.sec", "R2")
        spark.delete_supported = False
        with pytest.raises(Exception, match="DELETE"):
            kb_io.write_run_rows(spark, [{"section_id": "s9", "run_id": "R2", "n_chars": 9}], "kb.sec", "R2")


# ====================================================================== C4-12
def test_C4_12_approval_records_the_predicate_it_signed(monkeypatch):
    a0, r0 = _row("k1"), _row("k2")
    recs = {r["rule_id"]: r for r in _wb([a0, r0], reviewer="SS")}
    recs["EXT-k1"].update(decision="Approve", review_note="AI pre-review: quote verified p.9; SS agrees")
    recs["EXT-k2"].update(decision="Reject", review_note=float("nan"))
    rows, log, res = _review(monkeypatch, list(recs.values()), [a0, r0])
    a, rj = rows["EXT-k1"], rows["EXT-k2"]
    want = hashlib.sha256(json.dumps(P4, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    assert a["approved_predicate_sha256"] == want == sr.predicate_sha256(a["predicate"])
    assert (a["decision_source"], a["review_decision"]) == ("workbook", "approve")
    assert a["review_note"] == "AI pre-review: quote verified p.9; SS agrees"            # kept as given
    assert rj["review_note"] == "" and rj["approved_predicate_sha256"] is None           # an empty cell is not 'nan'
    L = log["df"].set_index("rule_id")
    assert L.loc["EXT-k1", "approved_predicate_sha256"] == want and set(L["decision_source"]) == {"workbook"}
    assert L.loc["EXT-k1", "review_note"].startswith("AI pre-review:") and res["ai_prereview_notes"] == 1
    assert log["schema"] == sr.REVIEW_LOG_SCHEMA and log["mode"] == "append"            # C4-13: typed log
    assert {"approved_predicate_sha256", "decision_source"} <= set(sr.REVIEW_FIELDS)
    # the build refuses an approval whose predicate was changed after sign-off
    rep = {}
    tampered = dict(a, predicate=json.dumps(dict(P4, threshold=1)))
    assert sr.rules_from_frame(pd.DataFrame([tampered]), current_doc_hash={"10": "DOC1"}, report=rep) == []
    assert rep["stale"][0]["reason"] == "predicate_changed"
    assert len(sr.rules_from_frame(pd.DataFrame([a]), current_doc_hash={"10": "DOC1"})) == 1


def test_C4_12_an_edited_predicate_cell_is_not_silently_signed(monkeypatch):
    orig = _row("k1")
    rec = _wb([orig], decision="Approve", reviewer="SS")[0]
    rows, _, res = _review(monkeypatch, [dict(rec, predicate=json.dumps(dict(P4, threshold=6)))], [orig])
    assert res["outcomes"] == ["predicate_mismatch"] and rows["EXT-k1"]["review_status"] == "needs_review"
    same = json.dumps({"threshold": 4, "code": "98960", "type": "max_units_per_day"}, indent=1)   # order/space only
    assert _review(monkeypatch, [dict(rec, predicate=same)], [orig])[2]["outcomes"] == ["approved"]


# ====================================================================== C3-10
@pytest.mark.parametrize("bad", [
    {"type": "not_checkable", "reason": "needs a human"},          # off-list reason (extraction lets it through)
    {"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961", "modifier_indicator": "2"},
    {"type": "max_units_per_day", "code": "98960", "threshold": 4.5},
    {"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961", "scope": "provider"},
])
def test_C3_10_approve_validates_the_rules_predicate(monkeypatch, bad):
    orig = _row("k1", pred=bad)
    rows, _, res = _review(monkeypatch, _wb([orig], decision="Approve", reviewer="SS"), [orig])
    r = rows["EXT-k1"]
    assert res["outcomes"] == ["invalid_predicate"] and r["review_status"] == "needs_review"
    assert "approve refused" in r["review_note"] and r["approved_predicate_sha256"] is None
    assert json.loads(r["predicate"]) == bad and sr.parked_reason(r["review_note"]) == "invalid_predicate"


# ====================================================================== C3-09
def test_C3_09_drafts_the_latest_run_no_longer_produces_are_superseded():
    existing = pd.DataFrame([
        _row("k1", section_id="s1"), _row("k2", section_id="s1"),               # same chapter + document
        _row("k3", section_id="s2"),                                          # a section the run did not answer
        _row("k4", doc_hash="OLDDOC", section_id="s0"),                       # an older document version
        _row("k5", chapter="19", section_id="x1"),                            # a chapter this run did not extract
        _row("k6", "approved", reviewer="kim", section_id="s1"),              # decided: never touched
        dict(_row("k7", "needs_review", section_id="s1"), prior_review=json.dumps({"status": "approved"})),
    ])
    new = [_row("k1", section_id="s1")]
    merged, c = sr.merge_drafts(existing, new, rerun={"10": "DOC1"}, run_id="R9", completed_sections={"s1"})
    st = dict(zip(merged["extraction_key"], merged["review_status"]))
    assert c["superseded"] == 1 and st["k2"] == "superseded" and len(merged) == len(existing)   # never deleted
    assert st["k3"] == st["k4"] == st["k5"] == "draft" and st["k6"] == "approved" and st["k7"] == "needs_review"
    assert "superseded by run R9" in merged.set_index("extraction_key").loc["k2", "review_note"]
    assert "superseded" not in set(sr.review_frame(merged)["review_status"])                  # never exported
    assert sr.rules_from_frame(merged[merged["review_status"] == "superseded"]) == []
    assert sr.merge_drafts(existing, new)[1]["superseded"] == 0                                # no rerun: nothing
    assert sr.merge_drafts(existing, new, rerun={"10": "DOC1"}, run_id="R9")[1]["superseded"] == 2   # chapter-wide


def test_C3_09_quote_level_rejection_memory():
    q = "Claims can be submitted for a maximum of four units per day - up to 24 units per month per member."
    rejected = dict(_row("old", "rejected", reviewer="SS", quote=q), review_note="a combined limit, not per code")
    redraft = _row("new", quote=q.upper().replace("-", "‑"))        # new key; case / U+2011 dash only differ
    other = _row("other", quote=q, pred={"type": "max_units_per_day", "code": "98961", "threshold": 4})
    merged, c = sr.merge_drafts(pd.DataFrame([rejected]), [redraft, other])
    by = merged.set_index("extraction_key")
    assert (c["rejected_quote_seen"], c["added"]) == (1, 1)
    assert by.loc["new", "review_status"] == "needs_review" and by.loc["other", "review_status"] == "draft"
    prior = json.loads(by.loc["new", "prior_review"])
    assert (prior["decision"], prior["rule_id"], prior["matched_on"]) == ("reject", "EXT-old", "verbatim_quote+codes")
    assert "REJECTED before by SS" in by.loc["new", "review_note"] and by.loc["old", "review_status"] == "rejected"
    wb = sr.review_frame(merged).set_index("extraction_key")
    assert wb.loc["new", "previous_decision"].startswith("Reject by SS")


# ====================================================================== C3-06
def test_C3_06_workbook_shows_window_population_and_qualifiers():
    pair = _row("kp", pred={"type": "code_pair_prohibited", "code_a": "H2025", "code_b": "H2026", "scope": "member_day",
                            "exception": "unless a separately identifiable service", "discretionary": True})
    aged = _row("ka", pred=dict(P4, age={"below": 21}), population="members under 21", eff="2024-10-01",
                end="2025-09-30")
    wb = sr.review_frame(pd.DataFrame([pair, aged])).set_index("extraction_key")
    for c in ("effective_date", "end_date", "population", "age", "scope", "modifier_indicator", "exception",
              "discretionary", "previous_decision", "corrected_effective_date", "corrected_end_date",
              "corrected_population", "corrected_predicate", "corrected_rule", "decision", "reviewer", "review_note"):
        assert c in wb.columns, c
    assert (wb.loc["ka", "age"], wb.loc["ka", "population"]) == ("under 21", "members under 21")
    assert (wb.loc["ka", "effective_date"], wb.loc["ka", "end_date"]) == ("2024-10-01", "2025-09-30")
    assert (wb.loc["kp", "scope"], wb.loc["kp", "modifier_indicator"]) == ("member_day", "0")
    assert wb.loc["kp", "exception"].startswith("unless") and wb.loc["kp", "discretionary"].startswith("yes")
    assert wb.loc["ka", "scope"] == "" and wb.loc["ka", "corrected_effective_date"] == ""


def test_C3_06_a_fix_can_correct_only_the_window_and_population(monkeypatch):
    orig = _row("k1", eff="2020-01-01")          # the model read "prior to 1/1/2020" as an effective date
    base = _wb([orig], decision="Fix", reviewer="SS")[0]
    rows, log, res = _review(monkeypatch, [dict(base, corrected_effective_date="clear",
                                                corrected_end_date=pd.Timestamp("2019-12-31"),   # an Excel date cell
                                                corrected_population="members under 21")], [orig])
    r = rows["EXT-k1"]
    assert res["outcomes"] == ["fixed"] and r["review_status"] == "approved" and r["review_decision"] == "fix"
    assert (r["effective_date"], r["end_date"], r["population"]) == (None, "2019-12-31", "members under 21")
    assert json.loads(r["predicate"]) == P4 and json.loads(r["codes"]) == ["98960"]      # predicate as signed
    assert r["approved_predicate_sha256"] == sr.predicate_sha256(P4)
    assert list(log["df"]["corrected_end_date"]) == ["2019-12-31"]
    for extra, why in ((dict(corrected_end_date="12/31/2019"), "invalid corrected date"),
                       (dict(corrected_end_date="2019-12-31"), "before effective_date"),
                       (dict(corrected_rule="maximum four units"), "fix needs a valid corrected_predicate")):
        rows, _, res = _review(monkeypatch, [dict(base, **extra)], [orig])
        r = rows["EXT-k1"]
        assert res["outcomes"] == ["fix_deferred"] and r["review_status"] == "needs_review" and why in r["review_note"]
        assert (r["effective_date"], r["end_date"]) == ("2020-01-01", None)              # untouched
    # corrections only apply with Fix; with Approve they park the row instead of being ignored
    rows, _, res = _review(monkeypatch, [dict(base, decision="Approve", corrected_end_date="2019-12-31")], [orig])
    assert res["outcomes"] == ["corrections_need_fix"] and rows["EXT-k1"]["review_status"] == "needs_review"
    # a dates-only Fix signs the EXISTING predicate, so that predicate must validate
    bad = _row("kb", pred={"type": "not_checkable", "reason": "off-list"})
    rows, _, res = _review(monkeypatch, _wb([bad], decision="Fix", reviewer="SS", corrected_end_date="2025-01-01"), [bad])
    assert res["outcomes"] == ["fix_deferred"] and "predicate is invalid" in rows["EXT-kb"]["review_note"]
    # a corrected predicate with an age condition needs the date of birth
    rows, _, _ = _review(monkeypatch, [dict(base, corrected_predicate=json.dumps(dict(P4, age={"below": 21})))], [orig])
    assert "dob" in json.loads(rows["EXT-k1"]["required_claim_fields"])


def test_fix_relabelling_a_lead_keeps_its_codes(monkeypatch):
    """69 of the first run's 146 fixes only relabelled a not_checkable reason. Such a predicate names no code,
    and re-deriving `codes` from it wiped the lead's codes (it vanished from per-code lookups / coverage)."""
    lead = dict(_row("kl", pred={"type": "not_checkable", "reason": "no_claim_field"}), codes=json.dumps(["H0018"]))
    fix = json.dumps({"type": "not_checkable", "reason": "requires_medical_record"})
    rows, _, res = _review(monkeypatch, _wb([lead], decision="Fix", reviewer="SS", corrected_predicate=fix), [lead])
    r = rows["EXT-kl"]
    assert res["outcomes"] == ["fixed"] and json.loads(r["codes"]) == ["H0018"]
    assert r["not_checkable_reason"] == "requires_medical_record" and r["machine_checkable"] is False
    # a corrected predicate that DOES name codes still re-derives them (F07)
    rows, _, _ = _review(monkeypatch, _wb([lead], decision="Fix", reviewer="SS",
                                          corrected_predicate=json.dumps({"type": "code_not_covered", "code": "H0019"})),
                         [lead])
    assert json.loads(rows["EXT-kl"]["codes"]) == ["H0019"] and rows["EXT-kl"]["machine_checkable"] is True


def test_review_workbook_round_trips_through_excel(tmp_path, monkeypatch):
    # C4-05: a hand-authored seed is exported and signable - when hand-authored rules may compile at all (since
    # 2026-10-04 only with config.COMPILE_HAND_AUTHORED; tests/test_one_engine.py covers the default)
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", True)
    table = [_row("k1"), _seed_row()]
    path = str(tmp_path / "wb.xlsx")
    sr.export_review_workbook(_Spark(table), "t", path)
    book = pd.read_excel(path).astype(object)
    book["decision"], book["reviewer"] = "Approve", "SS"
    book.to_excel(path, index=False)
    captured = {}
    monkeypatch.setattr(sr, "write_state_rules", lambda s, t, rows: captured.update(rows=rows))
    monkeypatch.setattr(kb_io, "write_table", lambda *a, **k: 0)
    res = sr.ingest_review_decisions(_Spark(table), "t", path, "l")
    assert res["outcomes"] == ["approved", "approved"]                       # blank cells are not corrections
    assert {r["review_status"] for r in captured["rows"]} == {"approved"}


# ====================================================================== C4-13 / C4-18 (kb_io)
def test_C4_13_append_keeps_table_types_and_null_text_is_never_double(fake_pyspark):
    spark = FakeSpark()
    kb_io.write_table(spark, [{"chapter": "10", "run_id": "r1", "sections": 7, "error": None}], "kb.log", mode="append")
    assert _types_of(spark, "kb.log") == {"chapter": "string", "run_id": "string", "sections": "long", "error": "string"}
    # 04's failed-chapter row has no `sections`: the batch's column is float64 with NaN -> must stay long
    kb_io.write_table(spark, [{"chapter": "13", "run_id": "r2", "seconds": 0.4, "error": "FileNotFoundError"},
                              {"chapter": "10", "run_id": "r2", "sections": 7, "error": None}], "kb.log", mode="append")
    assert _types_of(spark, "kb.log")["sections"] == "long" and _types_of(spark, "kb.log")["seconds"] == "double"
    assert spark.table("kb.log").toPandas()["sections"].tolist()[2] == 7
    # an explicit schema pins a NEW table's types; an existing column keeps the table's type
    kb_io.write_table(spark, [{"a": None, "b": 1.0}], "kb.x", mode="append", schema={"a": "string", "b": "long"})
    assert _types_of(spark, "kb.x") == {"a": "string", "b": "long"}
    kb_io.write_table(spark, [{"a": "x", "b": 2}], "kb.x", mode="append", schema={"b": "double"})
    assert _types_of(spark, "kb.x")["b"] == "long" and len(spark.tables["kb.x"][0]) == 2
    # an all-empty column read from Excel is float64 NaN: appended as string, never DOUBLE
    kb_io.write_table(spark, pd.DataFrame({"run_id": ["r9"], "note": [float("nan")]}), "kb.notes", mode="append")
    assert _types_of(spark, "kb.notes") == {"run_id": "string", "note": "string"}
    # the review log: every column text even when this batch's cells are all empty
    kb_io.write_table(spark, pd.DataFrame({c: [float("nan")] for c in sr.REVIEW_LOG_COLUMNS}), "kb.review_log",
                      mode="append", schema=sr.REVIEW_LOG_SCHEMA)
    assert set(_types_of(spark, "kb.review_log").values()) == {"string"}
    with pytest.raises(TypeError, match="not a whole number"):                 # 7.5 never truncates to 7
        kb_io.write_table(spark, [{"chapter": "1", "run_id": "r3", "sections": 7.5}], "kb.log", mode="append")


def test_C4_18_an_empty_overwrite_replaces_the_table(fake_pyspark, capsys):
    spark = FakeSpark()
    kb_io.write_table(spark, [{"category": "x", "n": 1}], "kb.reg")
    kb_io.write_table(spark, pd.DataFrame(columns=["build_id"]), "kb.reg")       # this build found nothing
    pdf, st = spark.tables["kb.reg"]
    assert len(pdf) == 0 and [f.name for f in st.fields] == ["category", "n"]   # emptied, schema kept
    assert "REPLACED with an empty table" in capsys.readouterr().out
    kb_io.write_table(spark, pd.DataFrame(columns=["a"]), "kb.new")              # created empty
    assert len(spark.tables["kb.new"][0]) == 0 and _types_of(spark, "kb.new") == {"a": "string"}
    assert kb_io.write_table(spark, [], "kb.none") == 0 and "kb.none" not in spark.tables
    kb_io.write_table(spark, [{"category": "y", "n": 2}], "kb.reg")
    kb_io.write_table(spark, [], "kb.reg", mode="append")                        # appending nothing: no change
    assert len(spark.tables["kb.reg"][0]) == 1
    # the reviewed rules table is the exception: an empty frame is refused, never written
    assert sr.write_state_rules(spark, "sedo.state_rules", []) == 0 and "sedo.state_rules" not in spark.tables


# ====================================================================== state_seed
def test_seed_chw_daily_cap_is_one_combined_rule_and_pairs_have_text_scopes():
    rules = state_seed.seed_rules()
    chw = ["98960", "98961", "98962"]
    day = [r for r in rules if r.predicate["type"] == "max_units_per_day" and set(r.codes) & set(chw)]
    assert len(day) == 1                                                      # was three per-code caps
    cap = day[0]
    assert cap.predicate == {"type": "max_units_per_day", "code_set": chw, "threshold": 4} and cap.codes == chw
    assert cap.source_locator == "page 9" and "inclusive of all 3 billable codes" in cap.notes
    assert "prior authorization" in cap.notes
    pairs = {(r.predicate["code_a"], r.predicate["code_b"]): r for r in rules
             if r.predicate["type"] == "code_pair_prohibited"}
    scope = {k: r.predicate.get("scope") for k, r in pairs.items()}
    assert set(scope.values()) <= set(schema.PAIR_SCOPES) and None not in scope.values()
    assert {k for k, v in scope.items() if v == "member_day"} == {
        ("98960", "98961"), ("98960", "98962"), ("98961", "98962"),
        ("H2025", "H2026"), ("H2025", "H2027"), ("H2026", "H2027")}
    for k in (("H2025", "H2026"), ("H2025", "H2027"), ("H2026", "H2027")):
        assert "reviewer's to confirm" in pairs[k].notes and not pairs[k].ambiguity_flag
    for k in (("H2016", "S5151"), ("S9485", "S5151"), ("99213", "99238")):
        assert scope[k] == "member_provider_day" and pairs[k].ambiguity_flag
        assert pairs[k].ambiguity_note.startswith("INTERPRETATION")
    # Ch10 p.13: "the E/M code will be paid, but the discharge management code will be denied" -> the finding
    # (reported on code_b's line) is on 99238, never on the paid E/M line
    assert ("99238", "99213") not in pairs and pairs[("99213", "99238")].statement.endswith(
        "by the same provider for the same member.")
    s5150 = [r for r in rules if r.predicate.get("code") == "S5150"][0]
    assert s5150.ambiguity_flag and s5150.ambiguity_note.startswith("DERIVED")
    # still a complete, citable seed that gates without rejects and has no id collisions
    rows = [sr.rule_to_row(r, chapter=state_seed.CHAPTER_BY_DOC[r.source_doc]) for r in rules]
    acc, rej = vg.gate([sr.row_to_rule(x) for x in rows])
    acc, _ = rn.normalize_rules(acc)
    dets = dg.build_detectors(acc)
    assert rej == [] and len(rules) == 59 and len({a["rule_id"] for a in acc}) == 59
    assert sum(not d["compiled"] for d in dets) == 3                         # the three leads stay leads
    # 2026-10-03: the 40 explicit rules the extraction missed carry their verbatim source sentence and page
    new = rules[19:]
    assert len(new) == 40 and all('Verbatim (Ch.' in r.notes and "page" in r.source_locator for r in new)
    # 2026-10-03 (independent re-read, agent S): "Providers are prohibited from billing S5151 with H0001, ..." - the
    # finding is on the S5151 line; and the Respite / Case Management sections were added to Ch.19 on 07/08/2024, so
    # the 23 S5151 pairs and the 13 T1016 pairs start 2024-07-08 (no rule judges claims from before its text)
    s5151 = [r for r in rules if r.predicate.get("code_b") == "S5151"]
    assert len(s5151) == 23 and {r.predicate["code_a"] for r in s5151} >= {"H2014", "H2017", "S5150", "H2016", "S9485"}
    assert not [r for r in rules if r.predicate.get("code_a") == "S5151" and r.predicate.get("code_b") != "T1016"]
    t1016 = [r for r in new if r.predicate.get("code_b") == "T1016"]
    assert len(t1016) == 13
    assert all(r.effective_date == "2024-07-08" for r in s5151 + t1016)
    assert all(r.predicate.get("scope") == "member_provider_day" for r in new if r.predicate["type"] == "code_pair_prohibited")
    respite = [r for r in new if r.predicate.get("type") == "max_units_per_period"]
    assert len(respite) == 1 and respite[0].effective_date == "2021-10-01" and "720 hours" in respite[0].notes
    amb = [r for r in new if r.predicate.get("code") in ("A0382", "A0398")]
    assert len(amb) == 2 and all(r.ambiguity_flag and r.ambiguity_note.startswith("HOLD") for r in amb)


def test_parked_reasons_for_the_06_summary():
    assert sr.parked_reason("x [decision not applied: reviewer name required]") == "no_reviewer"
    assert sr.parked_reason("source document changed (a -> b); previously approved by kim") == "resign_new_version"
    assert sr.parked_reason("[fix rejected: invalid corrected_predicate: bad period]") == "invalid_corrected_predicate"
    assert sr.parked_reason(None) == "other"


# ====================================================================== notebooks 02 / 05 / 06 from source
def _make_run(root: str, run_id: str, doc_hash: str, fetched_at: str) -> str:
    """A real run folder, like 04_extract_chapters_gpu writes it: fixture PDF + STUB backend."""
    import extract_io, extract_rules as ex, fixture_pdf, policy_changes, policy_docs as pdx
    path = fixture_pdf.build(os.path.join(root, f"fx_{doc_hash}.pdf"))
    inv = {"chapter": "10", "title": "Individual Practitioner Services", "url": "https://x/FFS_Chap10.pdf",
           "path": path, "doc_hash": doc_hash, "bytes": 1, "source": "volume", "fetched_at": fetched_at}
    secs, meta = pdx.segment(pdx.parse_pdf(path), "10", doc_hash)
    inv["revision_date"] = meta["revision_date"]
    outcomes = []
    drafts, dropped, stats = ex.extract_chapter(secs, inv, ex.make_backend("STUB"), run_id, cache={},
                                                log_fn=lambda *a: None, outcomes=outcomes)
    stats.update(seconds=0.1, error=None)
    d = extract_io.new_run_dir(os.path.join(root, "data", "extraction_runs"), run_id)
    extract_io.write_run(d, inventory_rows=[pdx.inventory_record(inv, meta)],
                         section_rows=[{k: (json.dumps(v) if isinstance(v, list) else v) for k, v in s.items()}
                                       | {"run_id": run_id} for s in secs],
                         log_rows=[stats], dropped_rows=dropped,
                         change_rows=policy_changes.diff_chapter(None, drafts, inv, None, run_id), drafts=drafts,
                         cache={f"k|{run_id}": {"proposals": [], "no_rule_reason": None}},
                         manifest={"run_id": run_id, "finished": True, "model_calls": 0, "model_failures": 0},
                         outcome_rows=outcomes)
    return d


@pytest.fixture
def nb(tmp_path, fake_pyspark):
    keys = ("PKB_PACKAGE_DIR", "PKB_WORKSPACE_DATA_DIR", "PKB_TABLE_FORMAT")
    saved = {k: os.environ.get(k) for k in keys}
    os.environ.update(PKB_PACKAGE_DIR=PKG, PKB_WORKSPACE_DATA_DIR=str(tmp_path / "data"), PKB_TABLE_FORMAT="parquet")
    spark = FakeSpark(delete_supported=False)            # like the offline e2e: parquet, no DELETE

    def run(rel):
        path = os.path.join(PKG, "notebooks", rel)
        g = {"spark": spark, "display": lambda *a, **k: None, "__name__": "__main__", "__file__": path}
        cwd = os.getcwd()
        os.chdir(os.path.dirname(path))
        try:
            exec(compile(open(path).read(), path, "exec"), g)
        finally:
            os.chdir(cwd)
        return g

    try:
        yield types.SimpleNamespace(spark=spark, run=run, root=str(tmp_path), data=str(tmp_path / "data"),
                                    wb=str(tmp_path / "data" / "review" / "policy_rules_review.xlsx"))
    finally:
        for k, v in saved.items():
            os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
        importlib.reload(config)                         # the notebooks reloaded it with the temp data dir


def _fill(path, **cols):
    book = pd.read_excel(path).astype(object)
    for k, v in cols.items():
        book[k] = v
    book.to_excel(path, index=False)
    return book


def test_C4_11_rerunning_05_never_doubles_telemetry_or_overwrites_a_review(nb):
    _make_run(nb.root, "20261001T100000", "DOC_A", "2026-10-01T10:00:00")
    nb.run("05_persist_extraction.py")
    T, KB = nb.spark.tables, f"{config.OUTPUT_CATALOG}.{config.OUTPUT_SCHEMA}"
    tele = ("policy_document_inventory", "policy_sections", "policy_extraction_log", "policy_extraction_outcomes",
            "policy_change_log")
    first = {t: len(T[f"{KB}.{t}"][0]) for t in tele}
    n_rules = len(T[config.STATE_RULES_TABLE][0])
    book = pd.read_excel(nb.wb).astype(object)
    book.loc[:1, "decision"], book.loc[:1, "reviewer"] = "Approve", "SS"        # a review half done, in place
    book.to_excel(nb.wb, index=False)
    nb.run("05_persist_extraction.py")                                          # the SAME run folder again
    assert {t: len(T[f"{KB}.{t}"][0]) for t in tele} == first
    assert T[f"{KB}.policy_document_inventory"][0]["run_id"].tolist() == ["20261001T100000"]
    assert len(T[config.STATE_RULES_TABLE][0]) == n_rules
    assert pd.read_excel(nb.wb)["decision"].notna().sum() == 2                  # the review in progress survived
    assert len(glob.glob(os.path.join(nb.data, "review", "policy_rules_review_*.xlsx"))) == 1
    # 06 ingests it, archives it, and re-exports what is still pending to the standard path
    nb.run("06_review_decisions.py")
    st = T[config.STATE_RULES_TABLE][0]
    assert (st["review_status"] == "approved").sum() == 2 and st["approved_predicate_sha256"].notna().sum() == 2
    assert glob.glob(os.path.join(nb.data, "review", "ingested", "policy_rules_review_ingested_*.xlsx"))
    again = pd.read_excel(nb.wb)
    assert len(again) == n_rules - 2 and again["decision"].isna().all()
    assert set(_types_of(nb.spark, f"{KB}.policy_review_log").values()) == {"string"}


def test_notebooks_govern_seeds_and_a_document_revision_end_to_end(nb, monkeypatch):
    # hand-authored seeds as signable rules: only with COMPILE_HAND_AUTHORED since 2026-10-04 (the notebooks reload
    # config, so the switch is set through its environment variable)
    monkeypatch.setenv("PKB_COMPILE_HAND_AUTHORED", "1")
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", True)
    ST = config.STATE_RULES_TABLE
    nb.run("02_migrate_state_rules.py")
    T = nb.spark.tables
    assert (T[ST][0]["review_status"] == "legacy_hand_authored").sum() == len(state_seed.seed_rules())
    _make_run(nb.root, "20261001T100000", "DOC_A", "2026-10-01T10:00:00")
    nb.run("05_persist_extraction.py")
    book = pd.read_excel(nb.wb)
    assert set(book["review_status"]) == {"draft", "legacy_hand_authored"}                      # C4-05
    assert (book["origin"] == "manual").sum() == len(state_seed.seed_rules())
    n = len(_fill(nb.wb, decision="Approve", reviewer="SS"))
    nb.run("06_review_decisions.py")
    st = T[ST][0]
    assert (st["review_status"] == "approved").sum() == n == len(st)
    assert st["approved_predicate_sha256"].notna().all() and set(st["decision_source"]) == {"workbook"}
    assert not os.path.exists(nb.wb)                                    # archived; nothing left to review
    nb.run("02_migrate_state_rules.py")                                 # re-seeding keeps every signature
    assert (T[ST][0]["review_status"] == "approved").sum() == n and len(T[ST][0]) == n
    monkeypatch.setattr(config, "COMPILE_LEGACY_SEEDS", False)
    assert len(sr.rules_from_frame(T[ST][0], current_doc_hash={"10": "DOC_A"})) == n
    # the source PDF is revised: extracted approvals go back for re-sign; signed seeds (no doc) stay signed
    _make_run(nb.root, "20261002T100000", "DOC_B", "2026-10-02T10:00:00")
    nb.run("05_persist_extraction.py")
    st = T[ST][0]
    ext = st[st["origin"] == "extracted"]
    assert (ext["review_status"] == "needs_review").all() and ext["prior_review"].notna().all()
    assert (st.loc[st["origin"] == "manual", "review_status"] == "approved").all()
    book = pd.read_excel(nb.wb)                                         # the standard path was free again
    assert len(book) == len(ext) and book["previous_decision"].str.startswith("Approve by SS").all()
    assert len(sr.rules_from_frame(st, current_doc_hash={"10": "DOC_B"})) == n - len(ext)
    _fill(nb.wb, decision="Approve", reviewer="SS (re-sign)")
    nb.run("06_review_decisions.py")
    st = T[ST][0]
    assert (st["review_status"] == "approved").all()
    assert len(sr.rules_from_frame(st, current_doc_hash={"10": "DOC_B"})) == n
    assert len(sr.rules_from_frame(st, current_doc_hash={})) == n - len(ext)    # no inventory: fail closed


# ------------------------------------------------ 2026-10-02: reopen = yes changes a DECIDED rule
P3 = {"type": "max_units_per_day", "code": "98960", "threshold": 3}


def _decided_wb(rows, **fill):
    return [dict(r, **fill) for r in sr.review_frame(pd.DataFrame(rows), statuses=sr.REOPENABLE_STATUS)
            .to_dict("records")]


def test_reopen_a_decided_rule_changes_only_with_reopen_yes_and_a_name(monkeypatch):
    approved = _row("k1", status="approved", reviewer="SS")
    fix = dict(decision="Fix", corrected_predicate=json.dumps(P3), corrected_rule="98960: maximum 3 units per day.")
    # 1) no reopen: an old / re-imported workbook never flips a decided row (D6)
    rows, _, res = _review(monkeypatch, _decided_wb([approved], reviewer="SB", **fix), [approved])
    assert res["outcomes"] == ["ignored: row is approved, not pending review"]
    assert json.loads(rows["EXT-k1"]["predicate"]) == P4 and rows["EXT-k1"]["review_status"] == "approved"
    # 2) reopen without a name: refused, and the approved rule is NOT parked (it keeps compiling)
    rows, _, res = _review(monkeypatch, _decided_wb([approved], reopen="yes", **fix), [approved])
    assert res["outcomes"] == ["reopen refused: reviewer name required"]
    assert rows["EXT-k1"]["review_status"] == "approved" and json.loads(rows["EXT-k1"]["predicate"]) == P4
    # 3) reopen with a workbook from another document version: refused, unchanged
    old_doc = [dict(r, doc_hash="OLD") for r in _decided_wb([approved], reopen="yes", reviewer="SB", **fix)]
    rows, _, res = _review(monkeypatch, old_doc, [approved])
    assert res["outcomes"][0].startswith("reopen refused: workbook is for doc OLD")
    assert rows["EXT-k1"]["review_status"] == "approved"
    # 4) reopen = yes, named: the Fix replaces the decision; the old one is kept in prior_review and the log
    rows, log, res = _review(monkeypatch, _decided_wb([approved], reopen="yes", reviewer="SB", **fix), [approved])
    r = rows["EXT-k1"]
    assert res["outcomes"] == ["fixed"] and res["applied"]["reopened"] == 1
    assert r["review_status"] == "approved" and r["review_decision"] == "fix" and r["reviewer"] == "SB"
    assert json.loads(r["predicate"]) == P3 and r["approved_predicate_sha256"] == sr.predicate_sha256(P3)
    prior = json.loads(r["prior_review"])
    assert prior["decision"] == "approve" and prior["reviewer"] == "SS" and prior["predicate"] == P4
    assert log["df"]["previous_decision"].iloc[0].startswith("Approve by SS")


def test_reopen_same_decision_twice_is_unchanged_and_a_bad_fix_keeps_the_old_decision(monkeypatch):
    fixed = _row("k2", status="approved", reviewer="SB", pred=P3)
    fixed["review_decision"] = "fix"
    wb = _decided_wb([fixed], reopen="yes", reviewer="SB", decision="Fix", corrected_predicate=json.dumps(P3))
    rows, _, res = _review(monkeypatch, wb, [fixed])
    assert res["outcomes"] == ["unchanged: already approved this way"] and res["applied"]["unchanged"] == 1
    # an invalid correction on a reopened row: the decision in force stays (approved, old predicate) - never parked
    bad = _decided_wb([fixed], reopen="yes", reviewer="SB", decision="Fix",
                      corrected_predicate=json.dumps({"type": "max_units_per_day", "code": "98960"}))
    rows, _, res = _review(monkeypatch, bad, [fixed])
    assert res["outcomes"] == ["fix_deferred"]
    assert rows["EXT-k2"]["review_status"] == "approved" and json.loads(rows["EXT-k2"]["predicate"]) == P3
    assert "reopen not applied" in rows["EXT-k2"]["review_note"]


def test_reopen_a_rejected_rule_and_reopen_is_ignored_on_pending_rows(monkeypatch):
    rej = _row("k3", status="rejected", reviewer="SS")
    rows, _, res = _review(monkeypatch, _decided_wb([rej], reopen="yes", reviewer="SB", decision="Approve"), [rej])
    assert res["outcomes"] == ["approved"] and rows["EXT-k3"]["review_status"] == "approved"
    assert json.loads(rows["EXT-k3"]["prior_review"])["decision"] == "reject"
    # a draft is pending: reopen has nothing to do, the decision applies as usual
    d = _row("k4")
    rows, _, res = _review(monkeypatch, _wb([d], reviewer="SB", decision="Approve", reopen="yes"), [d])
    assert res["outcomes"] == ["approved"] and res["applied"]["reopened"] == 0
    # the decided-rules export shows the decision in force
    out = sr.review_frame(pd.DataFrame([rej]), statuses=sr.REOPENABLE_STATUS)
    assert out["previous_decision"].iloc[0].startswith("Reject by SS") and out["previous_decision"].iloc[0].endswith("(in force)")
    assert "reopen" in out.columns and "reopen" in sr.EDITABLE_COLUMNS


# ------------------------------------------------ 2026-10-03: mutants that survived the red-team run (G07, G12)
@pytest.mark.parametrize("word", ["no", "n", "false", "0", "", "maybe"])
def test_reopen_needs_an_explicit_yes_a_no_or_a_typo_never_flips_a_decided_rule(monkeypatch, word):
    approved = _row("k5", status="approved", reviewer="SS")
    fix = dict(decision="Fix", corrected_predicate=json.dumps(P3), corrected_rule="98960: maximum 3 units per day.")
    rows, _, res = _review(monkeypatch, _decided_wb([approved], reopen=word, reviewer="SB", **fix), [approved])
    assert res["outcomes"] == ["ignored: row is approved, not pending review"] and res["applied"]["reopened"] == 0
    assert rows["EXT-k5"]["review_status"] == "approved" and json.loads(rows["EXT-k5"]["predicate"]) == P4


@pytest.mark.parametrize("word", ["yes", "Y", " YES ", "true"])
def test_reopen_accepts_the_usual_spellings_of_yes(monkeypatch, word):
    approved = _row("k6", status="approved", reviewer="SS")
    fix = dict(decision="Fix", corrected_predicate=json.dumps(P3), corrected_rule="98960: maximum 3 units per day.")
    rows, _, res = _review(monkeypatch, _decided_wb([approved], reopen=word, reviewer="SB", **fix), [approved])
    assert res["outcomes"] == ["fixed"] and res["applied"]["reopened"] == 1


def test_a_superseded_rule_can_never_be_reopened(monkeypatch):
    """A retired draft / seed stays retired: reopen = yes on it is ignored, whatever the decision says."""
    sup = _row("k7", status="superseded", reviewer="SS")
    wb = [dict(r, review_status="superseded") for r in _decided_wb([dict(sup, review_status="approved")],
                                                                    reopen="yes", reviewer="SB", decision="Approve")]
    rows, _, res = _review(monkeypatch, wb, [sup])
    assert res["applied"]["reopened"] == 0 and res["applied"].get("approved", 0) == 0
    assert rows["EXT-k7"]["review_status"] == "superseded"
    assert "superseded" not in sr.REOPENABLE_STATUS


def test_workbook_staging_file_is_private_to_each_write(tmp_path, monkeypatch):
    """2026-10-03 (found when two test runs shared a machine): the openpyxl staging copy was <tmp>/<basename>, so two
    notebooks exporting policy_rules_review.xlsx at the same time on one driver could copy each other's workbook to their
    destination. Each write now stages in its own temp file and removes it."""
    import tempfile
    import quality
    tmpdir = tmp_path / "tmp"
    tmpdir.mkdir()
    monkeypatch.setattr(tempfile, "tempdir", str(tmpdir))
    seen = []
    real = tempfile.mkstemp
    monkeypatch.setattr(tempfile, "mkstemp", lambda *a, **k: seen.append(real(*a, **k)) or seen[-1])
    for i, dest in enumerate((tmp_path / "a" / "policy_rules_review.xlsx", tmp_path / "b" / "policy_rules_review.xlsx")):
        dest.parent.mkdir()
        assert sr._xlsx_write(pd.DataFrame({"row": [i]}), str(dest)) == str(dest)
        assert sr._xlsx_read(str(dest))["row"].tolist() == [i]
    out = quality.xlsx_write_sheets({"QUERIES": pd.DataFrame({"q": [1]})}, str(tmp_path / "c" / "pack.xlsx"))
    assert quality.xlsx_read_sheets(out)["QUERIES"]["q"].tolist() == [1]
    assert len({p for _, p in seen}) == len(seen) == 3                  # a new staging file per write
    assert not any(tmpdir.iterdir())                                     # and none left behind
