"""Offline harness for running notebooks 05 / v01 / v03 from SOURCE without Spark (critic M51, 2026-10-04).

Not a test module. It provides:
  * install(monkeypatch)  - a fake `pyspark` package (sql, functions, types, Window) in sys.modules for the duration of
                            one test, so `from pyspark.sql import Window, functions as F` and kb_io's lazy
                            `from pyspark.sql import types as T` work with no JVM;
  * FakeSpark             - an in-memory catalog of pandas frames with the subset of the DataFrame API the notebooks
                            use (withColumn / join / where / select / Window row_number / agg / groupBy-pivot ...),
                            and the write path kb_io uses (createDataFrame with a StructType, write...saveAsTable,
                            Delta-style append: a column keeps its type, new columns need mergeSchema);
  * run_notebook(...)     - exec a notebook's source with parameter substitutions and `importlib.reload` switched off
                            (so a test's monkeypatched config stays in force), returning its globals.
Anything the fake does not model raises NotImplementedError, so a test can never pass on an unmodelled call.
"""
from __future__ import annotations

import os
import re
import sys
import types

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)


def _null(v) -> bool:
    if v is None:
        return True
    if isinstance(v, (list, dict, tuple, set)):
        return False
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


# ------------------------------------------------------------------ pyspark.sql.types
def _types_module():
    T = types.ModuleType("pyspark.sql.types")

    class DataType:
        _name = "?"

        def typeName(self):
            return self._name

        def simpleString(self):
            return {"long": "bigint", "integer": "int"}.get(self._name, self._name)

        def __eq__(self, o):
            return isinstance(o, DataType) and o._name == self._name

        def __hash__(self):
            return hash(self._name)

        def __repr__(self):
            return f"{type(self).__name__}()"

    for cls, nm in (("StringType", "string"), ("LongType", "long"), ("IntegerType", "integer"),
                    ("DoubleType", "double"), ("BooleanType", "boolean"), ("DateType", "date"),
                    ("TimestampType", "timestamp")):
        setattr(T, cls, type(cls, (DataType,), {"_name": nm}))

    class StructField:
        def __init__(self, name, dataType, nullable=True):
            self.name, self.dataType, self.nullable = name, dataType, nullable

    class StructType:
        def __init__(self, fields):
            self.fields = list(fields)

        @property
        def names(self):
            return [f.name for f in self.fields]

    T.DataType, T.StructField, T.StructType = DataType, StructField, StructType
    return T


# ------------------------------------------------------------------ expressions (pyspark.sql.functions)
class Col:
    """A column expression: fn(pandas frame) -> Series."""

    def __init__(self, fn, name=None):
        self.fn, self.name = fn, name

    def alias(self, name):
        return Col(self.fn, name)

    def cast(self, t):
        f = self.fn
        if str(t).strip().lower() in ("string", "str"):
            return Col(lambda d: pd.Series([None if _null(v) else str(v) for v in f(d)], index=d.index, dtype=object),
                       self.name)
        raise NotImplementedError(f"fake cast to {t!r}")

    def _bin(self, other, op):
        return Col(lambda d: op(self.fn(d), other.fn(d) if isinstance(other, Col) else other))

    def __eq__(self, other):                                 # noqa: D105 - an expression, not a comparison
        return self._bin(other, lambda a, b: a == b)

    def __ne__(self, other):
        return self._bin(other, lambda a, b: a != b)

    __hash__ = object.__hash__

    def isNotNull(self):
        return Col(lambda d: self.fn(d).notna())

    def isNull(self):
        return Col(lambda d: self.fn(d).isna())


class _Desc:
    def __init__(self, name):
        self.name = name


class _Agg:
    def __init__(self, how, name):
        self.how, self.name = how, name


class _RowNumber:
    def over(self, w):
        part, order = list(w.part), list(w.order)

        def fn(d):
            keys = [k.name if isinstance(k, _Desc) else k for k in order]
            asc = [not isinstance(k, _Desc) for k in order]
            s = d.sort_values(part + keys, ascending=[True] * len(part) + asc, kind="mergesort", na_position="last")
            rn = s.groupby(part, sort=False, dropna=False).cumcount() + 1 if part else pd.Series(
                range(1, len(s) + 1), index=s.index)
            return rn.reindex(d.index)
        return Col(fn)


class WindowSpec:
    def __init__(self, part=(), order=()):
        self.part, self.order = tuple(part), tuple(order)

    def orderBy(self, *keys):
        return WindowSpec(self.part, keys)

    def partitionBy(self, *cols):
        return WindowSpec(cols, self.order)


class Window:
    @staticmethod
    def partitionBy(*cols):
        return WindowSpec(cols)

    @staticmethod
    def orderBy(*keys):
        return WindowSpec((), keys)


def _functions_module():
    F = types.ModuleType("pyspark.sql.functions")
    F.col = lambda c: Col(lambda d: d[c], c)
    F.lit = lambda v: Col(lambda d: pd.Series([v] * len(d), index=d.index, dtype=object))
    F.desc = _Desc
    F.max = lambda c: _Agg("max", c)
    F.min = lambda c: _Agg("min", c)
    F.row_number = _RowNumber

    def concat_ws(sep, *cols):
        def fn(d):
            parts = [d[c] if isinstance(c, str) else c.fn(d) for c in cols]
            return pd.Series([sep.join(str(v) for v in vals if not _null(v)) for vals in zip(*parts)], index=d.index,
                             dtype=object)
        return Col(fn)
    F.concat_ws = concat_ws
    return F


# ------------------------------------------------------------------ rows / frames
class Row(dict):
    def __getitem__(self, k):
        if isinstance(k, int):
            return list(self.values())[k]
        return dict.__getitem__(self, k)

    def __getattr__(self, k):
        try:
            return dict.__getitem__(self, k)
        except KeyError:
            raise AttributeError(k) from None


def _rows(pdf):
    return [Row({c: (None if _null(v) else v) for c, v in r.items()}) for r in pdf.to_dict("records")]


_WHERE = [(re.compile(r"^\s*(\w+)\s*=\s*(-?\d+)\s*$"), lambda d, m: d[m[1]] == int(m[2])),
          (re.compile(r"^\s*(\w+)\s+IS\s+NOT\s+NULL\s*$", re.I), lambda d, m: d[m[1]].notna()),
          (re.compile(r"^\s*(\w+)\s+IS\s+NULL\s*$", re.I), lambda d, m: d[m[1]].isna())]


class _Writer:
    def __init__(self, df):
        self.df, self._mode, self.opts = df, "errorifexists", {}

    def format(self, f):
        return self

    def mode(self, m):
        self._mode = m
        return self

    def option(self, k, v):
        self.opts[k] = v
        return self

    def saveAsTable(self, fqn):
        sp, pdf, st = self.df.spark, self.df.pdf, self.df.schema
        if self._mode == "append" and fqn in sp.tables:
            old_pdf, _ = sp.tables[fqn]
            old_st = sp.table(fqn).schema
            old = {f.name: f.dataType for f in old_st.fields}
            for f in st.fields:                    # Delta: a column keeps its type; a clash fails the append
                if f.name in old and old[f.name] != f.dataType:
                    raise Exception(f"[DELTA_FAILED_TO_MERGE_FIELDS] {fqn}.{f.name}: {old[f.name]!r} vs {f.dataType!r}")
            added = [f for f in st.fields if f.name not in old]
            if added and self.opts.get("mergeSchema") != "true":
                raise Exception(f"schema mismatch on append to {fqn}: {[f.name for f in added]}")
            struct = type(st)(old_st.fields + added)
            both = pd.concat([old_pdf.astype(object), pdf.astype(object)], ignore_index=True)
            sp.tables[fqn] = (both.reindex(columns=[f.name for f in struct.fields]), struct)
        else:
            sp.tables[fqn] = (pdf.copy(), st)
        sp.writes.append((fqn, self._mode, len(pdf)))


class DF:
    def __init__(self, spark, pdf: pd.DataFrame, struct=None):
        self.spark, self.pdf, self.struct = spark, pdf.reset_index(drop=True), struct

    # ---- metadata / writing
    @property
    def columns(self):
        return [f.name for f in self.struct.fields] if self.struct is not None else list(self.pdf.columns)

    @property
    def schema(self):
        if self.struct is not None:
            return self.struct
        T = sys.modules["pyspark.sql.types"]
        return T.StructType([T.StructField(str(c), T.StringType()) for c in self.pdf.columns])

    @property
    def write(self):
        return _Writer(self)

    def toPandas(self):
        out = self.pdf.copy()
        if self.struct is None:
            return out
        for f in self.struct.fields:              # Spark's typing: a long with nulls comes back as float64
            if f.name not in out.columns:
                continue
            k, s = f.dataType.typeName(), out[f.name]
            if k in ("long", "integer"):
                out[f.name] = s.astype("float64") if s.isna().any() else s.astype("int64")
            elif k == "double":
                out[f.name] = s.astype("float64")
            elif k == "boolean":
                out[f.name] = s.astype(object) if s.isna().any() else s.astype(bool)
            else:
                out[f.name] = s.astype(object).where(s.notna(), None)
        return out

    def _new(self, pdf):
        return DF(self.spark, pdf)

    # ---- transformations
    def withColumn(self, name, col):
        d = self.toPandas()
        d[name] = col.fn(d).values
        return self._new(d)

    def withColumnRenamed(self, a, b):
        return self._new(self.toPandas().rename(columns={a: b}))

    def join(self, other, on, how="inner"):
        on = [on] if isinstance(on, str) else list(on)
        left, right = self.toPandas(), other.toPandas()
        right = right[right[on].notna().all(axis=1)]          # SQL: a NULL key never matches
        if how not in ("inner", "left"):
            raise NotImplementedError(f"fake join how={how!r}")
        return self._new(left.merge(right, on=on, how=how))

    def where(self, cond):
        d = self.toPandas()
        if isinstance(cond, Col):
            mask = cond.fn(d)
        else:
            for rx, f in _WHERE:
                m = rx.match(str(cond))
                if m:
                    mask = f(d, m)
                    break
            else:
                raise NotImplementedError(f"fake where: {cond!r}")
        return self._new(d[mask.fillna(False).astype(bool)])

    filter = where

    def drop(self, *cols):
        return self._new(self.toPandas().drop(columns=[c for c in cols if c in self.pdf.columns]))

    def select(self, *cols):
        d = self.toPandas()
        out = pd.DataFrame(index=d.index)
        for c in cols:
            if isinstance(c, str):
                out[c] = d[c]
            elif isinstance(c, Col):
                if not c.name:
                    raise NotImplementedError("fake select of an unnamed expression")
                out[c.name] = c.fn(d)
            else:
                raise NotImplementedError(f"fake select of {c!r}")
        return self._new(out)

    def distinct(self):
        return self._new(self.toPandas().drop_duplicates())

    def orderBy(self, *keys):
        names = [k.name if isinstance(k, _Desc) else k for k in keys]
        asc = [not isinstance(k, _Desc) for k in keys]
        return self._new(self.toPandas().sort_values(names, ascending=asc, kind="mergesort", na_position="last"))

    sort = orderBy

    def limit(self, n):
        return self._new(self.toPandas().head(n))

    def fillna(self, v):
        return self._new(self.toPandas().fillna(v))

    def cache(self):
        return self

    def agg(self, *aggs):
        d = self.toPandas()
        row = {}
        for a in aggs:
            if not isinstance(a, _Agg):
                raise NotImplementedError(f"fake agg {a!r}")
            s = d[a.name].dropna()
            row[f"{a.how}({a.name})"] = (getattr(s, a.how)() if len(s) else None)
        return self._new(pd.DataFrame([row]))

    def groupBy(self, *cols):
        return _Grouped(self, list(cols))

    # ---- actions
    def count(self):
        return len(self.pdf)

    def collect(self):
        return _rows(self.toPandas())

    def first(self):
        r = self.collect()
        return r[0] if r else None


class _Grouped:
    def __init__(self, df, cols):
        self.df, self.cols, self.pivot_col = df, cols, None

    def pivot(self, col):
        self.pivot_col = col
        return self

    def count(self):
        d = self.df.toPandas()
        if self.pivot_col is None:
            out = d.groupby(self.cols, dropna=False).size().reset_index(name="count")
        else:
            out = d.groupby(self.cols + [self.pivot_col], dropna=False).size().unstack(self.pivot_col).reset_index()
            out.columns = [str(c) for c in out.columns]
        return self.df._new(out)


class FakeSpark:
    """tables: {fqn: pandas frame}. sql_hook(q) -> list of dicts answers queries the fake does not model itself."""

    def __init__(self, tables: dict | None = None, sql_hook=None, delete_supported: bool = True):
        self.tables = {k: (v.copy(), None) for k, v in (tables or {}).items()}
        self.sql_hook, self.delete_supported = sql_hook, delete_supported
        self.writes, self.queries = [], []
        self.conf = types.SimpleNamespace(set=lambda *a, **k: None)
        self.catalog = types.SimpleNamespace(tableExists=lambda fqn: fqn in self.tables)

    def table(self, fqn):
        if fqn not in self.tables:
            raise Exception(f"[TABLE_OR_VIEW_NOT_FOUND] The table or view `{fqn}` cannot be found.")
        return DF(self, *self.tables[fqn])

    def frame(self, fqn) -> pd.DataFrame:
        return self.table(fqn).toPandas()

    def createDataFrame(self, data, schema=None):
        T = sys.modules["pyspark.sql.types"]
        if isinstance(schema, str):                 # "chapter string, doc_hash string"
            fields = [p.strip().split() for p in schema.split(",")]
            names = {"string": T.StringType, "bigint": T.LongType, "long": T.LongType, "double": T.DoubleType,
                     "boolean": T.BooleanType}
            schema = T.StructType([T.StructField(n, names[t.lower()]()) for n, t in fields])
        if isinstance(data, pd.DataFrame):
            pdf = data.copy()
        else:
            pdf = pd.DataFrame(list(data), columns=[f.name for f in schema.fields] if schema is not None else None)
        return DF(self, pdf, schema)

    def sql(self, q):
        self.queries.append(q)
        m = re.match(r"\s*(SELECT COUNT\(\*\) AS n FROM|DELETE FROM) (\S+) WHERE `(\w+)` IN \((.*)\)\s*$", q, re.S)
        if m:                                       # kb_io.write_run_rows
            verb, fqn, col, lits = m.groups()
            vals = set(re.findall(r"'((?:[^'\\]|\\.)*)'", lits))
            pdf, st = self.tables[fqn]
            hit = pdf[col].map(lambda v: v is not None and str(v) in vals)
            if verb.startswith("SELECT"):
                return types.SimpleNamespace(collect=lambda: [[int(hit.sum())]])
            if not self.delete_supported:
                raise Exception("[UNSUPPORTED_FEATURE] DELETE is only supported with v2 tables.")
            self.tables[fqn] = (pdf[~hit].reset_index(drop=True), st)
            return None
        if re.match(r"\s*SHOW TABLES", q, re.I):
            return types.SimpleNamespace(collect=lambda: [])
        if self.sql_hook is None:
            raise NotImplementedError(f"fake sql: {q[:200]}")
        rows = self.sql_hook(q)
        return types.SimpleNamespace(collect=lambda: [Row(r) for r in rows])


# ------------------------------------------------------------------ install + run
def install(monkeypatch):
    """Register the fake pyspark package for one test (monkeypatch restores sys.modules afterwards)."""
    T, F = _types_module(), _functions_module()
    pyspark, sql = types.ModuleType("pyspark"), types.ModuleType("pyspark.sql")
    sql.types, sql.functions, sql.Window, pyspark.sql = T, F, Window, sql
    window = types.ModuleType("pyspark.sql.window")
    window.Window = Window
    for name, mod in (("pyspark", pyspark), ("pyspark.sql", sql), ("pyspark.sql.types", T),
                      ("pyspark.sql.functions", F), ("pyspark.sql.window", window)):
        monkeypatch.setitem(sys.modules, name, mod)
    return types.SimpleNamespace(T=T, F=F)


def notebook_source(rel: str, subs: dict | None = None) -> str:
    src = open(os.path.join(PKG, "notebooks", rel)).read()
    # keep the test's monkeypatched config / modules: the notebooks reload them
    src = src.replace("    importlib.reload(_m)", "    pass").replace("    importlib.reload(m)", "    pass")
    for old, new in (subs or {}).items():
        assert old in src, f"{rel}: substitution target not found: {old!r}"
        src = src.replace(old, new)
    return src


def run_notebook(rel: str, spark, subs: dict | None = None, shown: list | None = None) -> dict:
    path = os.path.join(PKG, "notebooks", rel)
    g = {"spark": spark, "display": (shown.append if shown is not None else (lambda *a, **k: None)),
         "__name__": "__main__", "__file__": path}
    cwd = os.getcwd()
    os.chdir(os.path.dirname(path))
    try:
        exec(compile(notebook_source(rel, subs), path, "exec"), g)
    finally:
        os.chdir(cwd)
    return g
