"""Extraction v2 (C3 critic, 2026-10-02): prompt contract, post-checks, keys, dates, cache key, unicode, stub,
HFLOCAL truncation + split, splitter / pre-filter, PDF versions (C4-08), regression gate.
Post-check cases are VERBATIM quotes from the first real run (/home/claude/review/rules.json) with the AI
pre-review's decision in the comment. Offline: no Spark, no model.
Run: cd pie_mvp && python -m pytest tests -q
"""
import copy
import json
import os
import re
import sys

import pandas as pd
import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import config  # noqa: E402
import extract_rules as ex  # noqa: E402
import policy_docs as pdx  # noqa: E402
import post_checks as pc  # noqa: E402
import regress  # noqa: E402
import schema  # noqa: E402

PKG = os.path.dirname(HERE)
INV = {"chapter": "19", "title": "Behavioral Health Services", "url": "u", "doc_hash": "h19", "revision_date": "r"}
REVIEW = "/home/claude/review/rules.json"


def _p(pred, quote, stmt=None, pop="all", **kw):
    return {"predicate": copy.deepcopy(pred), "verbatim_quote": quote, "statement": stmt or quote, "population": pop,
            "codes": pc.codes_of(pred), **kw}


def _sec(text, sid="s1", heading="H", candidate=True):
    return {"text": text, "text_hash": f"th-{sid}", "section_id": sid, "heading": heading, "page_start": 3,
            "page_end": 4, "has_rule_signal": candidate, "rule_signal": 1}


def _check(pred, quote, section=None, ctx=None, **kw):
    """repair -> ground -> check, like extract_chapter. Returns (proposal', actions, grounding)."""
    sec = _sec(section or quote)
    prop, rep = pc.repair(_p(pred, quote, **kw))
    g = ex.ground(prop, sec)
    assert g["keep"], g["drop_reason"]
    out, acts = pc.check(prop, g, sec["text"], ctx or {})
    return out, rep + acts, g


def _checks(acts):
    return [a["check"] for a in acts]


class _Fixed(ex.Backend):
    name, model = "FAKE", "fake"

    def __init__(self, rules):
        self.rules = rules

    def complete(self, s, u):
        return json.dumps({"rules": copy.deepcopy(self.rules), "no_rule_reason": None})


# ============================================================ 1. prompt v2 = the schema contract
_NON_REASON_TOKENS = set(schema.PREDICATE_TYPES) | {
    "no_rule_reason", "verbatim_quote", "not_checkable_reason", "derivation_note", "ambiguity_note", "effective_date",
    "end_date", "code_set", "code_a", "code_b", "modifier_indicator", "service_category", "member_provider_day",
    "member_day", "provider_types", "benefit_year"}


def test_prompt_v2_reason_list_is_exactly_schema_prompt_reasons():
    assert ex.PROMPT_VERSION == "v2"
    toks = set(re.findall(r"\b[a-z]+(?:_[a-z]+)+\b", ex.SYSTEM_PROMPT))
    reasons = {r for r, _ in schema.PROMPT_REASONS}
    assert reasons <= toks, reasons - toks                       # every canonical reason is offered
    assert toks - _NON_REASON_TOKENS == reasons, toks - _NON_REASON_TOKENS - reasons   # and nothing else
    # first-fit order and the one-line meanings come from schema (generated, not copied)
    pos = [ex.SYSTEM_PROMPT.index(f"  {r} ") for r, _ in schema.PROMPT_REASONS]
    assert pos == sorted(pos)
    for _, meaning in schema.PROMPT_REASONS:
        assert meaning in ex.SYSTEM_PROMPT


def test_prompt_v2_encodes_age_pairs_exceptions_dates_and_examples_are_valid():
    sp = ex.SYSTEM_PROMPT
    assert '"age"' in sp and '{"min":21}' in sp and '{"below":21}' in sp and '{"min":21,"below":65}' in sp
    assert "EPSDT" in sp and '"scope"' in sp and '"modifier_indicator":"0"' in sp and "code_b is the code" in sp
    assert '"exception"' in sp and '"discretionary": true' in sp and '"effective_date"' in sp and '"end_date"' in sp
    assert "max_units_per_day per code" not in sp                # v1 rule 1 (C3-04) is gone
    assert "member age" not in sp                                # v1 rule 3 said age is not on a claim
    examples = [json.JSONDecoder().raw_decode(ln.strip())[0] for ln in sp.splitlines()
                if ln.strip().startswith('{"type":')]
    assert len(examples) == 9
    for e in examples:
        if e["type"] == "not_checkable":
            e["reason"] = "process_obligation"
        assert schema.validate_predicate(e, strict_reason=True) == (True, ""), e
    # the user template is unchanged (backward compatible contract)
    assert "TEXT:" in ex.USER_TEMPLATE and "{text}" in ex.USER_TEMPLATE


# ============================================================ 2. post-checks on real quotes
HQ = ("NOTE: H2014, H2017, H2018 and H2038 must be paired with the HQ modifier when providers are serving two or more "
      "members at the same time.")                                                      # fix -> requires_medical_record
GE = ("All codes under the exception for E/M services should be used with the “GE” modifier to designate the "
      "claim as a teaching physician billing exception claim. Codes 99201, 99202, 99203, 99211, 99212 and 99213.")
RR = ("Providers who bill for apnea management, training, and the use of the apnea monitor must use procedure codes "
      "E0618 (apnea monitor, without recording feature) or E0619 (apnea monitor, with recording feature) and the RR "
      "modifier.")                                                                       # APPROVED


def test_conditional_modifier_requirement_becomes_a_lead_unconditional_is_kept():
    out, acts, _ = _check({"type": "modifier_required", "code_set": ["H2014", "H2017", "H2018", "H2038"],
                           "modifier": "HQ"}, HQ)
    assert out["predicate"] == {"type": "not_checkable", "reason": "requires_medical_record"}
    assert "modifier_conditional" in _checks(acts) and out["pre_check_predicate"]["modifier"] == "HQ"
    out, _, _ = _check({"type": "modifier_required", "code_set": ["99201", "99202"], "modifier": "GE"}, GE)
    assert out["predicate"] == {"type": "not_checkable", "reason": "no_claim_field"}        # 'to designate'
    out, acts, _ = _check({"type": "modifier_required", "code_set": ["E0618", "E0619"], "modifier": "RR"}, RR)
    assert out["predicate"]["type"] == "modifier_required" and not [a for a in acts if a["action"] != "flag"]


def test_provider_type_list_must_be_the_complete_list():
    """2026-10-03: provider_type_allowed compiles - every type NOT in the list is flagged. 'include' with no 'only' may
    be a partial list (Ch14 A0110); 'only by the following' is the complete one (Ch19 H0035)."""
    bus = ("Provider types that are eligible to claim reimbursement for public transportation passes include 02, 05, 13, "
           "14, 25, 27, 29, 41, 77, 81, 85, 86, 87, A3, A4, A6, B7, BC, C2, and C5.")
    sec = bus + " Providers shall bill using Code A0110 for the net cost of the transportation pass."
    out, acts, _ = _check({"type": "provider_type_allowed", "code_set": ["A0110"], "provider_types": ["02", "05"]}, bus,
                          section=sec)
    assert out["predicate"] == {"type": "not_checkable", "reason": "ambiguous_source"}
    assert "provider_type_list_may_be_partial" in _checks(acts)
    php = ("Partial Hospitalization services must be billed with code H0035, mental health partial hospitalization, "
           "treatment less than 24 hours, only by the following approved provider types and with an approved place of "
           "service: The approved provider types are as follows: B2, B5, 02 Hospital, and 71 Psychiatric Hospital.")
    out, acts, _ = _check({"type": "provider_type_allowed", "code_set": ["H0035"],
                           "provider_types": ["B2", "B5", "02", "71"]}, php)
    assert out["predicate"]["type"] == "provider_type_allowed" and "provider_type_list_may_be_partial" not in _checks(acts)


def test_context_limited_or_inverted_non_coverage_is_not_code_not_covered():
    q = ("Apnea management and training services may not be billed using procedure code 94799 (Unlisted pulmonary "
         "service or procedure).")                                                        # fix -> not_checkable
    out, acts, _ = _check({"type": "code_not_covered", "code": "94799"}, q)
    assert out["predicate"]["type"] == "not_checkable" and "noncoverage_context_limited" in _checks(acts)
    q = ("Observation services that directly precede inpatient admission to the same hospital must not be billed "
         "separately. These charges must be billed on the inpatient claim.")             # fix -> no_claim_field
    out, _, _ = _check({"type": "code_not_covered", "code": "G0378"}, q, section=q + " Use code G0378.")
    assert out["predicate"] == {"type": "not_checkable", "reason": "no_claim_field"}
    q = ("Providers shall bill using Code A0110 for the net cost of the transportation pass, not to exceed the cost of "
         "a 30-day pass.")                                                                # fix: inverted meaning
    out, acts, _ = _check({"type": "code_not_covered", "code": "A0110"}, q)
    assert out["predicate"]["type"] == "not_checkable" and "noncoverage_wording_missing" in _checks(acts)
    q = ("AHCCCS does not reimburse providers on a fee-for-service basis for services billed using procedure code "
         "99070 (Supplies and materials, except spectacles, provided by the physician over and above those usually "
         "included with the office visit or other services rendered).")                # APPROVED as is
    out, acts, _ = _check({"type": "code_not_covered", "code": "99070"}, q)
    assert out["predicate"] == {"type": "code_not_covered", "code": "99070"}           # descriptor is no exception
    assert not [a for a in acts if a["action"] != "flag"]


def test_retired_code_without_date_and_code_ranges_are_predicate_not_in_grammar():
    out, acts, _ = _check({"type": "code_not_covered", "code": "W2404"},
                          "Respiratory therapists must bill with code S5180. This code replaces W2404 and is not "
                          "covered.")
    assert out["predicate"] == {"type": "not_checkable", "reason": "predicate_not_in_grammar"}
    out, _, _ = _check({"type": "code_not_covered", "code": "G0154"},
                       "For dates of service on or after January 1st, 2016, G0154 has been replaced with G0299 and "
                       "G0154 is not covered.")
    assert out["predicate"]["type"] == "code_not_covered"                                  # dated: stays a rule
    out, _, _ = _check({"type": "code_not_covered", "code_set": ["99201", "99499"]},
                       "Modifier 59 is not covered with evaluation and management codes (99201-99499).")
    assert out["predicate"] == {"type": "not_checkable", "reason": "predicate_not_in_grammar"}


S5151 = "T1016 cannot be billed on the same day as H0018, H0014 or H0035."
PER_DIEM = ("H2014 (skills training and development) and H2017 (psychosocial rehabilitation services) may be denied "
            "when billed on the same day any per diem codes are billed.")
PER_DIEM_SECTION = PER_DIEM + "\nH2018 - Psychosocial rehabilitation services, per diem.\nH2038 - Skills training, per diem."


def test_pair_not_stated_by_the_sentence_is_dropped():
    q = ("Self-help/peer services provided in an ADHS DLS licensed inpatient, residential or day program setting are "
         "included in the rate for those settings and cannot be billed separately and cannot be billed on the same day "
         "as a per diem code.")                                                           # REJECTED: invented pair
    out, acts, _ = _check({"type": "code_pair_prohibited", "code_a": "H0038", "code_b": "H2016"}, q,
                          section=q + "\nCodes: H0038, H2016.")
    assert out.get("_drop") and [a for a in acts if a["action"] == "drop"][0]["check"] == "pair_codes_not_in_sentence"
    # C3-12: a hub sentence never pairs two listed codes; the hub is code_b (C3-13)
    out, acts, _ = _check({"type": "code_pair_prohibited", "code_a": "H0014", "code_b": "H0018"}, S5151)
    assert out.get("_drop") and "pair_hub_spoke" in _checks(acts)
    out, acts, _ = _check({"type": "code_pair_prohibited", "code_a": "T1016", "code_b": "H0018"}, S5151)
    assert not out.get("_drop") and (out["predicate"]["code_a"], out["predicate"]["code_b"]) == ("H0018", "T1016")
    # category: the per diem code is named elsewhere in the section -> kept, flagged, direction, discretionary
    out, acts, _ = _check({"type": "code_pair_prohibited", "code_a": "H2014", "code_b": "H2038",
                           "modifier_indicator": "", "service_category": ""}, PER_DIEM, section=PER_DIEM_SECTION)
    p = out["predicate"]
    assert not out.get("_drop") and (p["code_a"], p["code_b"]) == ("H2038", "H2014")
    assert p["modifier_indicator"] == "0" and p["service_category"] == "state" and p["discretionary"] is True
    assert p["scope"] == "member_provider_day" and "pair_code_from_category" in _checks(acts)
    # the two barred codes are not barred with each other
    out, _, _ = _check({"type": "code_pair_prohibited", "code_a": "H2014", "code_b": "H2017"}, PER_DIEM,
                       section=PER_DIEM_SECTION)
    assert out.get("_drop")


def test_pair_scope_is_explicit_and_never_silently_wide():
    chw = "codes cannot be billed together on the same day for the same member"
    sec = ("Billable codes: 98960, 98961, 98962.\nClaims can be submitted for a maximum of four units per day "
           "(total units allowable is inclusive of all 3 billable codes; " + chw + ").")
    out, acts, _ = _check({"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961",
                           "modifier_indicator": "0", "service_category": "state"}, chw, section=sec)
    assert out["predicate"]["scope"] == "member_provider_day"                 # C3-01: missing -> NARROW + note
    a = [x for x in acts if x["check"] == "pair_scope_default"][0]
    assert "member_day" in a["detail"] and a["attention"] and "pair_codes_by_reference" in _checks(acts)
    out, _, _ = _check({"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961", "scope": "member_day"},
                       chw, section=sec)
    assert out["predicate"]["scope"] == "member_day"                          # stated by the text: kept
    s9484 = "A single provider cannot bill both codes in the first 24 hours of a crisis episode, for the same member."
    out, acts, _ = _check({"type": "code_pair_prohibited", "code_a": "S9484", "code_b": "S9485", "scope": "member_day"},
                          s9484, section="S9484 crisis, per hour. S9485 crisis, per diem.\n" + s9484)
    assert out["predicate"]["scope"] == "member_provider_day" and "pair_scope_narrowed" in _checks(acts)
    out, _, _ = _check({"type": "code_pair_prohibited", "code_a": "H2025", "code_b": "H2026", "scope": "member_day"},
                       "Service codes H2025, H2026, and H2027 cannot be billed on the same day.")
    assert out["predicate"]["scope"] == "member_provider_day"                 # member_day not stated -> narrowed


def test_combined_cap_becomes_one_code_set_rule_and_siblings_are_merged():
    q = ("Claims can be submitted for a maximum of four units per day, up to 24 units per month per member (total units "
         "allowable is inclusive of all 3 billable codes; codes cannot be billed together on the same day for the "
         "same member).")                                                                 # fix: 98960 alone (C3-04)
    sec = "Billable codes: 98960, 98961, 98962.\n" + q
    items = []
    for c in ("98960", "98961"):
        prop = _p({"type": "max_units_per_day", "code": c, "threshold": 4}, q)
        items.append(pc.check(prop, ex.ground(prop, _sec(sec)), sec))
    out = pc.section_pass(items, sec)
    assert out[0][0]["predicate"] == {"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4}
    assert out[1][0].get("_duplicate") and out[1][1][-1]["action"] == "duplicate"
    # no 'combined' wording: per-code caps stay (a per-code cap never over-flags)
    q2 = "A maximum of four units per day applies to codes 98960 and 98961."
    prop = _p({"type": "max_units_per_day", "code": "98960", "threshold": 4}, q2)
    out = pc.section_pass([pc.check(prop, ex.ground(prop, _sec(q2)), q2)], q2)
    assert out[0][0]["predicate"] == {"type": "max_units_per_day", "code": "98960", "threshold": 4}


def test_unit_definition_code_descriptor_and_per_provider_caps():
    out, acts, _ = _check({"type": "max_units_per_day", "code": "H0020", "threshold": 1},
                          "The billing unit is one dose per day (includes cost associated with drug and administration).",
                          section="H0020 methadone. The billing unit is one dose per day (includes cost associated with "
                                  "drug and administration).")
    assert out["predicate"]["type"] == "not_checkable" and "cap_is_unit_definition" in _checks(acts)
    out, acts, _ = _check({"type": "max_units_per_day", "code": "W2405", "threshold": 1},
                          "W2405 Respiratory therapy performed by Medicare certified home health agency, limited to one "
                          "(1) visit per day")                                            # REJECTED: retired descriptor
    assert out["predicate"]["type"] == "not_checkable" and "cap_from_code_descriptor" in _checks(acts)
    out, _, _ = _check({"type": "max_units_per_day", "code": "T1015", "threshold": 1},
                       "MSIC-eligible visits may be billed with a T1015 procedure code once per day, per MSIC.")
    assert out["predicate"] == {"type": "max_units_per_dos", "code": "T1015", "threshold": 1}   # per provider


def test_exception_and_discretionary_labels():
    q = ("In addition, oxygen supplies (for either BLS or ALS in a life sustaining situation with code A0422) may be "
         "charged for only one ground ambulance trip, unless the additional transport is a separately identifiable "
         "service.")                                                                      # APPROVED
    out, acts, _ = _check({"type": "max_units_per_day", "code": "A0422", "threshold": 1}, q)
    assert out["predicate"]["exception"] == "unless the additional transport is a separately identifiable service"
    assert out["predicate"]["exception"] in q and not [a for a in acts if a.get("attention")]
    assert pc.exception_clause("X and Y cannot be billed when billed on the same day together.") is None
    assert pc.exception_clause("Do not bill 11975 unless prior authorization is obtained.") == \
        "unless prior authorization is obtained"
    out, _, _ = _check({"type": "code_not_covered", "code": "T1016"},
                       "T1016 may not be reimbursed for members in a hospital stay unless the stay is under 24 hours.")
    assert out["predicate"]["type"] in ("code_not_covered", "not_checkable")
    if out["predicate"]["type"] == "code_not_covered":
        assert out["predicate"]["discretionary"] is True


def test_off_list_reasons_are_mapped_and_recorded():
    out, acts, _ = _check({"type": "not_checkable", "reason": "requires_claim_field"},
                          "When billing for a podiatrist's services, CMS 1500 field 17 must have Qualifier DK and the "
                          "ordering provider's name.")                                    # fix -> process_obligation
    assert out["predicate"]["reason"] == "process_obligation" and out["not_checkable_reason"] == "process_obligation"
    assert "'requires_claim_field'" in acts[0]["detail"]                           # the original is recorded
    assert pc.map_reason("requires_claim_attribute", "At least one accommodation revenue code must be billed with "
                         "associated charges greater than zero.") == "no_claim_field"
    assert pc.map_reason("requires_provider_attribute", "The pharmacy providing the vaccine must be an AHCCCS "
                         "registered provider;") == "process_obligation"
    for r in ("totally_new_reason", "requires_documentation", "code_range", None):
        assert pc.map_reason(r) in {x for x, _ in schema.PROMPT_REASONS}


def test_repair_keeps_invalid_but_real_obligations_as_leads():
    q = "Modifier 80 - Assistant surgeon services shall be identified by adding modifier 80 to the procedure."
    prop, acts = pc.repair(_p({"type": "modifier_required", "code_set": [], "modifier": "80"}, q))
    assert prop["predicate"] == {"type": "not_checkable", "reason": "no_claim_field"} and acts[0]["check"] == "modifier_no_codes"
    assert ex.ground(prop, _sec(q))["keep"]                                    # reaches a reviewer (was dropped)
    prop, _ = pc.repair(_p({"type": "modifier_required", "code_set": ["A0998"], "modifier": "UA/UB/UC/UD"}, q))
    assert prop["predicate"]["type"] == "not_checkable"
    prop, _ = pc.repair(_p({"type": "max_dollars_per_period", "code_set": ["T2029"], "threshold": 5000,
                            "period": "lifetime"}, q))
    assert prop["predicate"] == {"type": "not_checkable", "reason": "predicate_not_in_grammar"}
    prop, acts = pc.repair(_p({"type": "max_units_per_day", "code": "98960", "threshold": 4}, q))
    assert acts == [] and "_orig_predicate" not in prop                        # valid predicates untouched


def test_age_and_program_scope():
    q = "Code 90471 is not covered for members 21 years of age and older."
    out, _, _ = _check({"type": "code_not_covered", "code": "90471", "age": {"min": 21}}, q)
    assert out["predicate"]["age"] == {"min": 21}                                # stated: kept
    out, acts, _ = _check({"type": "code_not_covered", "code": "90471", "age": {"below": 21}}, q)
    assert out["predicate"]["type"] == "not_checkable" and "age_not_stated" in _checks(acts)   # inverted age
    out, acts, _ = _check({"type": "code_not_covered", "code": "90471"}, q)
    assert out["predicate"]["type"] == "code_not_covered" and out["population"] != "all"     # stays a lead
    assert "age_scoped_population" in _checks(acts)
    assert pc.ages_in_text("limited to one visit per 60 days (this does not apply to EPSDT members)") == [{"min": 21}]
    assert pc.ages_in_text("for members ages 21 through 64") == [{"min": 21, "below": 65}]
    assert pc.ages_in_text("covered for members under 21") == [{"below": 21}]
    out, acts, _ = _check({"type": "code_not_covered", "code": "T1016"},
                          "Providers and Tribal Contractors are prohibited from billing for Case Management Services "
                          "(T1016).", ctx={"chapter_title": "ALTCS Services"})        # fix -> requires_member_attribute
    assert out["predicate"] == {"type": "not_checkable", "reason": "requires_member_attribute"}


def test_post_checks_never_make_a_rule_executable_or_wider_on_the_real_run():
    """Invariant over the 242 real proposals (skipped if the review folder is absent): no check turns a not_checkable
    rule into an executable one, every reason is canonical, no pair becomes member_day."""
    if not os.path.exists(REVIEW):
        pytest.skip("first-run review evidence not available")
    for r in json.load(open(REVIEW)):
        before = r["predicate_obj"]
        prop, _ = pc.repair(_p(before, r["verbatim_quote"], r["proposed_rule"]))
        out, _ = pc.check(prop, {"source_sentences": r["verbatim_quote"]}, r["verbatim_quote"])
        p = out["predicate"]
        if before.get("type") == "not_checkable":
            assert p["type"] == "not_checkable", r["rule_id"]
        if p["type"] == "not_checkable":
            assert p["reason"] in {x for x, _ in schema.PROMPT_REASONS}, r["rule_id"]
        if p["type"] == "code_pair_prohibited":
            assert p["scope"] == "member_provider_day" or before.get("scope") == "member_day", r["rule_id"]


# ============================================================ 3. wiring in extract_chapter
def test_extract_chapter_records_post_checks_drops_and_merges():
    sec_text = ("Billable codes: 98960, 98961, 98962.\nClaims can be submitted for a maximum of four units per day "
                "(total units allowable is inclusive of all 3 billable codes).\n" + S5151)
    rules = [
        {"statement": "98960 4/day", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
         "codes": ["98960"], "verbatim_quote": "Claims can be submitted for a maximum of four units per day (total "
         "units allowable is inclusive of all 3 billable codes).", "confidence": 0.9},
        {"statement": "98961 4/day", "predicate": {"type": "max_units_per_day", "code": "98961", "threshold": 4},
         "codes": ["98961"], "verbatim_quote": "Claims can be submitted for a maximum of four units per day (total "
         "units allowable is inclusive of all 3 billable codes).", "confidence": 0.9},
        {"statement": "H0014/H0018", "predicate": {"type": "code_pair_prohibited", "code_a": "H0014", "code_b": "H0018"},
         "codes": ["H0014", "H0018"], "verbatim_quote": S5151, "confidence": 0.9},
        {"statement": "T1016/H0018", "predicate": {"type": "code_pair_prohibited", "code_a": "T1016", "code_b": "H0018"},
         "codes": ["T1016", "H0018"], "verbatim_quote": S5151, "confidence": 0.9}]
    outcomes = []
    drafts, dropped, st = ex.extract_chapter([_sec(sec_text)], INV, _Fixed(rules), "r1", cache={},
                                             log_fn=lambda *a: None, outcomes=outcomes)
    preds = [json.loads(d["predicate"]) for d in drafts]
    assert {"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4} in preds
    pair = [p for p in preds if p["type"] == "code_pair_prohibited"]
    assert len(pair) == 1 and (pair[0]["code_a"], pair[0]["code_b"], pair[0]["scope"]) == ("H0018", "T1016",
                                                                                           "member_provider_day")
    reasons = sorted(d["drop_reason"] for d in dropped)
    assert any(r.startswith("duplicate (post-check): merged") for r in reasons)
    assert any(r.startswith("post-check: the sentence bars") for r in reasons)
    for d in drafts:
        g = json.loads(d["grounding"])
        assert "post_checks" in g and isinstance(g["post_checks"], list)
    cap = [d for d in drafts if json.loads(d["predicate"]).get("code_set")][0]
    assert "post-checks:" in cap["ambiguity_note"] and json.loads(cap["grounding"])["pre_check_predicate"]["code"] == "98960"
    assert json.loads(cap["codes"]) == ["98960", "98961", "98962"]
    assert st["post_check_drop"] == 1 and st["post_check_duplicate"] == 1 and st["duplicates"] == 1
    assert st["dropped"] == 2 and st["grounded"] == 2
    o = outcomes[0]
    assert o["n_post_check_actions"] > 0 and o["n_chars"] == len(sec_text) and o["split_pieces"] == 1
    # dropped rows carry their post-check record
    assert all(isinstance(json.loads(d["post_checks"]), (list, dict)) for d in dropped)


# ============================================================ 4. semantic key (C3-02)
def test_semantic_key_has_the_quote_for_every_not_checkable_and_collisions_are_logged():
    nc = {"type": "not_checkable", "reason": "process_obligation"}
    k1 = ex.semantic_key("19", nc, ["T1016"], quote="Case management services T1016 must be billed on a CMS 1500.")
    k2 = ex.semantic_key("19", nc, ["T1016"], quote="Group T1016 claims use each member's AHCCCS ID.")
    assert k1 != k2
    p = {"type": "code_not_covered", "code": "11975"}
    assert ex.semantic_key("10", p, ["11975"], quote="a") == ex.semantic_key("10", p, ["11975"], quote="b")
    assert ex.semantic_key("10", p, ["11975"]) == ex.semantic_key("10", p, ["11975"], end_date=None)
    assert ex.semantic_key("10", p, ["11975"]) != ex.semantic_key("10", p, ["11975"], end_date="2016-09-30")
    # within one run: the same rule from two sections -> one draft, the other in `dropped`
    q = "Do not bill for CPT code 11975 on any claim."
    r = [{"statement": "11975", "predicate": p, "codes": ["11975"], "verbatim_quote": q, "confidence": 0.9}]
    drafts, dropped, st = ex.extract_chapter([_sec(q, "a"), _sec(q, "b")], INV, _Fixed(r), "r", cache={},
                                             log_fn=lambda *a: None)
    assert len(drafts) == 1 and len(dropped) == 1 and st["duplicates"] == 1
    assert dropped[0]["drop_reason"] == f"duplicate of {drafts[0]['extraction_key']}"
    assert dropped[0]["page_start"] == 3 and dropped[0]["heading"] == "H"


# ============================================================ 5. dates (C3-06)
def test_prior_to_is_an_end_date_never_an_effective_date():
    f, e = ex._effective_from_quote, ex._end_from_quote
    q = "Prior to date of service 10/1/2016, foot and ankle services are not covered for adults (age 21 and older)."
    assert f(q) is None and e(q) == "2016-09-30"
    assert e("for dates of service before 1/1/2013 bill J1055") == "2012-12-31"
    assert e("covered from 1/1/2013 through 12/31/2014") == "2014-12-31" and f("covered from 1/1/2013 through x") == "2013-01-01"
    assert f("After January 1st, 2016, if a provider is not enrolled, claims will deny.") == "2016-01-02"
    assert f("Effective for dates of service 7/1/2023 and after, the participating provider must be listed.") == "2023-07-01"
    assert f("a letter from AHCCCS dated 1/1/2013") is None and e("revised March 3, 2024") is None


def test_draft_dates_come_from_the_model_when_grounded_else_from_the_cue_parser():
    q = ("Prior to 1/1/2013 providers must bill for Depo-Provera injections using HCPCS code J1055. Effective 1/1/2013 "
         "the Depo-Provera injections should billed with HCPCS code J1050.")
    assert ex.rule_dates({"effective_date": "2013-01-01"}, q)[:2] == ("2013-01-01", None)
    assert ex.rule_dates({"end_date": "2012-12-31"}, q)[:2] == (None, "2012-12-31")           # model's choice stands
    eff, end, notes = ex.rule_dates({"effective_date": "2012-12-31"}, q)                     # not grounded
    assert (eff, end) == ("2013-01-01", None) and any("not grounded" in n for n in notes)
    assert any("transition" in n for n in notes)                                             # parser saw both cues
    sec = _sec("Code J1055 is not covered for dates of service on or after 1/1/2013.")
    pr = {"statement": "J1055 not covered", "predicate": {"type": "code_not_covered", "code": "J1055"},
          "codes": ["J1055"], "verbatim_quote": sec["text"], "confidence": 0.9, "effective_date": "2013-01-01"}
    row = ex.to_draft_row(pr, ex.ground(pr, sec), sec, INV, _Fixed([]), "r")
    assert row["effective_date"] == "2013-01-01" and row["end_date"] is None
    sec2 = _sec("Code J1055 is not covered prior to 1/1/2013.")
    pr2 = dict(pr, verbatim_quote=sec2["text"], effective_date="2013-01-01")                  # the C3-06 bug shape
    row = ex.to_draft_row(pr2, ex.ground(pr2, sec2), sec2, INV, _Fixed([]), "r")
    assert row["effective_date"] is None and row["end_date"] == "2012-12-31"
    assert "not grounded" in row["ambiguity_note"]


# ============================================================ 6. cache key (C3-08)
def test_cache_key_includes_prompt_version_reasoning_and_budget():
    s = {"text_hash": "th"}
    lo, med = ex.HFLocalBackend(reasoning_level="low"), ex.HFLocalBackend(reasoning_level="medium")
    assert ex.cache_key(s, lo) != ex.cache_key(s, med)
    assert "|v2|" in ex.cache_key(s, lo) and "reasoning=low" in ex.cache_key(s, lo) and "budget=3000" in ex.cache_key(s, lo)
    old = dict(config.REASONING_TOKEN_BUDGET)
    try:
        config.REASONING_TOKEN_BUDGET["low"] = 6000
        assert "budget=6000" in ex.cache_key(s, lo)
    finally:
        config.REASONING_TOKEN_BUDGET.clear()
        config.REASONING_TOKEN_BUDGET.update(old)
    assert ex.cache_key(s, ex.HybridBackend(med)).endswith("reasoning=medium|budget=4500|retry_x=1.8")
    st = ex.StubBackend()
    assert ex.cache_key(s, st) == f"th|{ex.PROMPT_VERSION}|STUB|{st.model}"                    # shape unchanged
    assert "max_tokens=" in ex.cache_key(s, ex.DBFMBackend("ep"))


# ============================================================ 7. unicode (C3-11)
@pytest.mark.parametrize("ch", ["‐", "‑", "‒", "–", "—", "―", "−"])
def test_every_unicode_dash_grounds_exactly(ch):
    sec = _sec("Apart from case management, the provider may not bill any time associated with indirect contact with "
               "the member, including e-mail, as these activities are included in the rate.")
    q = f"the provider may not bill any time associated with indirect contact with the member, including e{ch}mail"
    g = ex.ground({"predicate": {"type": "not_checkable", "reason": "no_claim_field"}, "verbatim_quote": q}, sec)
    assert g["keep"] and g["quote_found"] == "exact"
    assert g["source_quote"].endswith("including e-mail")                     # the SOURCE characters are stored


def test_nbsp_thin_space_and_curly_quotes_ground_exactly():
    src = "Modifier “GT” must be used for 99213 visits by telehealth with 98960."
    q = 'Modifier "GT" must be used for 99213 visits by telehealth with 98960.'
    g = ex.ground({"predicate": {"type": "modifier_required", "code_set": ["99213"], "modifier": "GT"},
                   "verbatim_quote": q}, _sec(src))
    assert g["quote_found"] == "exact" and g["source_quote"] == src
    assert ex._norm("e‑mail x") == ex._norm("e-mail x") == pc.norm("E–mail x")


# ============================================================ 8. stub patterns (C3-04 / C3-12 / C3-18)
def _stub(text):
    return json.loads(ex.StubBackend().complete(ex.SYSTEM_PROMPT, ex.USER_TEMPLATE.format(
        chapter="19", title="T", heading="H", page_start=1, page_end=1, revision="r", text=text)))["rules"]


def test_stub_inclusive_caps_hub_pairs_scope_and_indicator():
    rules = _stub("A maximum of four units per day applies, inclusive of codes 98960, 98961 and 98962.")
    day = [r["predicate"] for r in rules if r["predicate"]["type"] == "max_units_per_day"]
    assert day == [{"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4}]
    pairs = [r["predicate"] for r in _stub(S5151) if r["predicate"]["type"] == "code_pair_prohibited"]
    assert {(p["code_a"], p["code_b"]) for p in pairs} == {("H0018", "T1016"), ("H0014", "T1016"), ("H0035", "T1016")}
    assert all(p["scope"] == "member_provider_day" and p["modifier_indicator"] == "0" for p in pairs)
    pairs = [r["predicate"] for r in _stub("Codes 98960, 98961, 98962 are CHW codes. These codes cannot be billed "
                                           "together on the same day for the same member.")
             if r["predicate"]["type"] == "code_pair_prohibited"]
    assert len(pairs) == 3 and all(p["scope"] == "member_day" for p in pairs)


def test_a_period_inside_a_code_list_does_not_cut_the_list():
    """Ch.19 p.31 has stray periods inside its S5151 list ("... H2033, S5150. T1019. H0031, H0038, H0030 or any other
    per diem code on the same day."). Cut there, the engine paired S5151 with 17 of the 21 listed codes (2026-10-04):
    the hand-written copies of those rules were the only place the other 4 existed."""
    note = ("NOTE: Providers are prohibited from billing S5151 with H0001, H0002, H0004, H0006, H0018 H0025, H0034, "
            "H0036, H2012, H2014, H2015, H2017, H2019, H2025, H2027, H2033, S5150. T1019. H0031, H0038, H0030 or any "
            "other per diem code on the same day.")
    assert pdx.sentences(note) == [note]
    pairs = [r["predicate"] for r in _stub(note) if r["predicate"]["type"] == "code_pair_prohibited"]
    assert {p["code_b"] for p in pairs} == {"S5151"} and len(pairs) == 21
    assert {"T1019", "H0031", "H0038", "H0030"} <= {p["code_a"] for p in pairs}
    assert all(p["scope"] == "member_provider_day" for p in pairs)
    # a sentence that merely ends and starts with a code is still two sentences
    assert pdx.sentences("Do not bill 99070. H2014 requires prior authorization.") == \
        ["Do not bill 99070.", "H2014 requires prior authorization."]


def _caps(text):
    """{code: threshold} of the pattern extractor's max_units_per_day rules for `text`."""
    return {r["predicate"]["code"]: r["predicate"]["threshold"] for r in _stub(text)
            if r["predicate"]["type"] == "max_units_per_day" and "code" in r["predicate"]}


def test_a_sentence_ending_in_a_code_is_not_a_stray_period_in_a_list():
    """Critic P51-4: code_list_break took ANY 'CODE.' followed by 'CODE,' for a stray period inside a list, so two real
    sentences fused - inside one line and (since _join_lines asks it too) at a PDF line end: "... may be billed for
    T1016." + "T1017, T1019 and H2014 are limited to a maximum of two units per day." became one sentence and the pattern
    extractor gave T1017, T1019 and H2014 the 4-unit limit. A stray period is one only after a LIST item: ', CODE.' or
    'CODE. CODE.' (the Ch.19 list); a lone 'for T1016.' ends its sentence."""
    first = "A maximum of four units per day may be billed for T1016."
    second = "T1017, T1019 and H2014 are limited to a maximum of two units per day."
    assert pdx.sentences(f"{first} {second}") == [first, second]
    assert _caps(f"{first} {second}") == {"T1016": 4, "T1017": 2, "T1019": 2, "H2014": 2}
    joined = pdx._join_lines([first, second])                 # the PDF line ends after 'T1016.'
    assert joined == f"{first}\n{second}" and _caps(joined) == {"T1016": 4, "T1017": 2, "T1019": 2, "H2014": 2}
    for before, after in (("Psychosocial rehabilitation is limited to four units per day for H0031.",
                           "H0038, peer support, is not limited."),
                          ("Peer support is billed with H0038.", "H0038, H0039 cannot be billed on the same day as S5151."),
                          ("Not covered: J3490.", "J3590, J9999 require a NDC."),
                          ("Providers must bill E/M with 99201-99205.", "99211, 99212 are covered without PA."),
                          ("Bill H0031/H0038.", "H0039, H0040 require prior authorization.")):
        assert pdx.sentences(f"{before} {after}") == [before, after]
        assert not pdx.code_list_break(before, after) and pdx._join_lines([before, after]) == f"{before}\n{after}"
    # the Ch.19 list stays whole: the stray period after a comma-list item, and the chain 'S5150. T1019.'
    assert pdx.code_list_break("... H2027, H2033, S5150.", "T1019. H0031, H0038")
    assert pdx.code_list_break("... H2033, S5150. T1019.", "H0031, H0038, H0030")
    assert pdx.code_list_break("Bill H0031, H0038.", "H0030, H0039 on the same day.")
    assert not pdx.code_list_break("... H2033, S5150.", "T1019 requires prior authorization.")
    head = "NOTE: Providers are prohibited from billing S5151 with H0001, H0002, H0004, H0006, H0018, H2027, H2033,"
    tail = "H0031, H0038, H0030 or any other per diem code on the same day."
    for lines in ([head + " S5150.", "T1019. " + tail], [head + " S5150. T1019.", tail],
                  [head + " S5150.", "T1019.", tail], [head, "S5150.", "T1019. " + tail]):   # a line of one code:
        # the list item before its period is on an earlier line - _join_lines reads the paragraph so far
        joined = pdx._join_lines(lines)
        assert "\n" not in joined and len(pdx.sentences(joined)) == 1, joined
        pairs = [r["predicate"] for r in _stub(joined) if r["predicate"]["type"] == "code_pair_prohibited"]
        assert {"S5150", "T1019", "H0031", "H0038", "H0030"} <= {p["code_a"] for p in pairs}


def test_stub_bullet_lead_in_descriptor_and_ranges():
    text = ("The following anesthesia services are not covered:\n• 00938 (Insertion of penile prosthesis)\n"
            "• Qualifying circumstances codes\nPeripheral Nerve Blocks A peripheral nerve block (CPT codes "
            "64400-64530) may be billed separately when the following conditions are met.")
    rules = _stub(text)
    assert [r["predicate"] for r in rules] == [{"type": "code_not_covered", "code": "00938"}]   # no glued range rule
    g = ex.ground(rules[0], _sec(text))
    assert g["keep"] and g["quote_found"] == "exact" and not g["quote_truncates_condition"]
    q = ("AHCCCS does not reimburse providers on a fee-for-service basis for services billed using procedure code "
         "99070 (Supplies and materials, except spectacles, provided by the physician).")
    assert [r["predicate"] for r in _stub(q)] == [{"type": "code_not_covered", "code": "99070"}]
    rules = _stub("Modifier 59 cannot be billed with evaluation and management codes (99201-99499).")
    assert [r["predicate"] for r in rules] == [{"type": "not_checkable", "reason": "predicate_not_in_grammar"}]


# ============================================================ 9. HFLOCAL truncation, split (C3-07)
def _fake_gen(final_for_budget):
    calls = []

    def gen(self, messages, max_new_tokens=None):
        b = max_new_tokens or self.budget()
        calls.append(b)
        final, n = final_for_budget(b)
        self.generate_calls += 1
        self.tokens_generated += n
        self.hit_budget_calls += int(n >= b - 2)
        return final, "analysis", {"final_channel_present": bool(final), "parse_error": None, "tokens_generated": n,
                                   "budget": b, "hit_budget": n >= b - 2, "reasoning_level": self.reasoning_level}
    return gen, calls


def test_hflocal_retries_when_the_budget_ends_inside_the_final_channel():
    b = ex.HFLocalBackend(reasoning_level="low")
    gen, calls = _fake_gen(lambda budget: ('{"rules": [{"statement": "x"', budget) if budget <= 3000
                           else ('{"rules": [], "no_rule_reason": "none"}', 3500))
    b._generate = gen.__get__(b)
    assert json.loads(b.complete("s", "u"))["rules"] == []
    assert calls == [3000, int(3000 * config.RETRY_BUDGET_FACTOR)] and b.retries == 1 and b.last_meta["retried"]
    b2 = ex.HFLocalBackend(reasoning_level="low")
    gen, calls = _fake_gen(lambda budget: ('{"rules": [{"statement": "x"', budget))
    b2._generate = gen.__get__(b2)
    with pytest.raises(ex.ModelOutputTruncated, match="final channel truncated"):
        b2.complete("s", "u")
    assert len(calls) == 2 and b2.truncated == 1 and b2.failures == 1
    assert ex.model_health(b2)["model_truncated"] == 1 and ex.model_health(b2)["model_tokens_generated"] == 3000 + 5400


class _Budgeted(ex.Backend):
    """Answers only when the section text is short enough; otherwise 'runs out of budget'."""
    name, model = "BUDGET", "b"

    def __init__(self, limit):
        self.limit, self.calls = limit, 0
        self.tokens_generated = self.hit_budget_calls = 0

    def complete(self, s, u):
        self.calls += 1
        text = re.search(r'TEXT:\n"""\n(.*?)\n"""', u, re.S).group(1)
        self.tokens_generated += len(text)
        if len(text) > self.limit:
            self.hit_budget_calls += 1
            raise ex.ModelOutputTruncated("final channel truncated (incomplete JSON) after 3000/3000 tokens")
        first = pdx.sentences(text)[0]
        code = re.search(r"\b\d{5}\b", first).group(0)
        return json.dumps({"rules": [{"statement": first, "predicate": {"type": "code_not_covered", "code": code},
                                      "codes": [code], "verbatim_quote": first, "confidence": 0.9}]})


def test_truncated_section_is_split_and_extracted_in_halves_with_depth_cap():
    paras = [f"Do not bill code {98900 + i} for any member." + " Narrative text follows here." * 4 for i in range(4)]
    sec = _sec("\n".join(paras))
    outcomes, cache = [], {}
    b = _Budgeted(limit=len(sec["text"]) // 2 + 10)                         # halves fit, the whole does not
    drafts, dropped, st = ex.extract_chapter([sec], INV, b, "r", cache=cache, log_fn=lambda *a: None, outcomes=outcomes)
    assert b.calls == 3 and st["sections_split"] == 1 and len(drafts) == 2 and len(cache) == 1   # cached once split
    assert outcomes[0]["split_pieces"] == 2 and outcomes[0]["outcome"] == "proposals"
    assert outcomes[0]["tokens_generated"] > 0 and outcomes[0]["hit_budget"] is True and st["hit_budget_calls"] == 1
    # nothing fits: at most SPLIT_MAX_DEPTH levels, then a retryable failure that is NOT cached
    b = _Budgeted(limit=10)
    cache = {}
    drafts, _, st = ex.extract_chapter([sec], INV, b, "r", cache=cache, log_fn=lambda *a: None)
    assert drafts == [] and cache == {} and st["model_failed"] == 1 and b.calls == ex.SPLIT_MAX_DEPTH + 1
    assert "cannot split further" in st["retryable_sections"][0]["why"]
    assert ex.split_section(_sec("short")) is None


def test_hybrid_passes_truncation_up_even_when_patterns_only_is_allowed():
    hy = ex.HybridBackend(_Budgeted(limit=10), ex.StubBackend(), require_model=False)
    with pytest.raises(ex.ModelOutputTruncated):
        hy.complete(ex.SYSTEM_PROMPT, ex.USER_TEMPLATE.format(chapter="1", title="t", heading="h", page_start=1,
                                                              page_end=1, revision="r", text="x" * 50))


# ============================================================ 10. splitter, headings, pre-filter, grounding (C3-16/17/19)
def test_heading_artefacts_and_wrapped_headings():
    for t in ["SERVICES)", "7. 638FQHC (PTC5)", "N400074115278 ML10", "MM/DD/CC", "0 = ICD-10-CM", "PAY:  0.00",
              "EMG", "NTE02", "ICU", "TO MAINTAIN EMPLOYMENT"]:
        assert not pdx._is_heading({"text": t, "size": 10.0, "bold": False}, 10.0), t
    for t in ["GENERAL INFORMATION", "WELL EXAMS", "FQHC/RHC SERVICES", "COMMUNITY HEALTH WORKER SERVICES"]:
        assert pdx._is_heading({"text": t, "size": 10.0, "bold": False}, 10.0), t
    lines = [{"text": t, "size": 10.0, "bold": False} for t in
             ["BEHAVIORAL HEALTH REHABILITATION (PSYCHOSOCIAL", "SERVICES)", "Body sentence one.", "CRISIS SERVICES",
              "Body two."]]
    secs, _ = pdx.segment([{"page": 1, "lines": lines, "tables": []}], "19", "h")
    assert [s["heading"] for s in secs] == ["BEHAVIORAL HEALTH REHABILITATION (PSYCHOSOCIAL SERVICES)", "CRISIS SERVICES"]


def test_sentence_splitter_bullets_abbreviations_and_bullet_continuations():
    assert pdx.sentences("Use code X, e.g. Medicare codes. Dr. Smith agrees. Supplies, etc. are not covered. Next.") == \
        ["Use code X, e.g. Medicare codes.", "Dr. Smith agrees.", "Supplies, etc. are not covered.", "Next."]
    assert pdx.sentences("Not covered:\n• 00938 (x)\nNext paragraph here.") == \
        ["Not covered:", "• 00938 (x)", "Next paragraph here."]
    assert pdx.sentences("covered: • A1 x • B2 y") == ["covered:", "• A1 x", "• B2 y"]
    joined = pdx._join_lines(["The following are met:", "• The block was performed for the purpose of pain",
                              "management;", "• Second item", "Peripheral Nerve Blocks heading text"])
    assert joined.split("\n") == ["The following are met:",
                                  "• The block was performed for the purpose of pain management;",
                                  "• Second item", "Peripheral Nerve Blocks heading text"]


def test_a_wrapped_bullet_keeps_its_code_list():
    """Critic P51-7: a bullet whose code list wraps onto the next physical line was cut there - the line after a bullet
    continued it only when it started in lowercase (or with a digit / punctuation), and 'T1019. H0031, ...' or 'H0031,
    H0038 ...' start with a capital - so S5151 lost its pairing with every code on the second line. A bullet line that
    ends inside a code list (a stray period after a list item, or a code and a comma / 'and' / 'or') now goes on into a
    next line that starts with a code."""
    head, nxt = "The following limits apply:", "• Crisis services must be billed per encounter."
    tail = "H0031, H0038 or any other per diem code on the same day."
    bill = "• Providers are prohibited from billing S5151 with H0001, H0002"
    for first, second in ((bill + ", H2033, S5150.", "T1019. " + tail),
                          (bill + ", H2033, S5150. T1019.", tail),
                          (bill + ", H2033,", tail),
                          (bill + " and", "H2033 on the same day.")):
        joined = pdx._join_lines([head, first, second, nxt])
        assert joined.split("\n") == [head, f"{first} {second}", nxt], joined
        assert len(pdx.sentences(f"{first} {second}")) == 1
        pairs = [r["predicate"] for r in _stub(joined) if r["predicate"]["type"] == "code_pair_prohibited"]
        assert {"H0001", "H2033"} <= {p["code_a"] for p in pairs} and {p["code_b"] for p in pairs} == {"S5151"}
    # unchanged: a capitalised line after a bullet that ends a sentence (with or without a code) starts a new paragraph
    assert pdx._join_lines(["• Do not bill T1016.", "T1017, T1019 are limited to two units per day."]).count("\n") == 1
    assert pdx._join_lines(["• Bill H0031", "Peer support notes are required."]).count("\n") == 1
    assert pdx._join_lines(["• Bill H0031,", "Peer support notes are required."]).count("\n") == 1


def test_prefilter_stems_find_obligations_but_not_narrative():
    for t in ["Hospice services require prior authorization.", "PA is required for all home health services.",
              "In general, observation status should not exceed 24 hours.",
              "The initial claim must be submitted to AHCCCS within six months of the date of service.",
              "Continuous home care is not available to nursing facility residents.",
              "The AIR for prescription services may be billed once daily, per member, per facility pharmacy."]:
        assert pdx.rule_signal(t)["score"] > 0, t
    for t in ["This chapter describes billing requirements for individual practitioners who bill AHCCCS on the CMS "
              "1500 claim form. Providers should also review Chapter 4, General Billing Rules.",
              "Questions may be directed to the Claims Customer Service unit."]:
        assert pdx.rule_signal(t)["score"] == 0, t


def test_short_obligation_quotes_thresholds_and_whole_code_tokens():
    sec = _sec("Hospice services require prior authorization. Billing will be submitted once per month for T2023. "
               "Utility arrears may not exceed $1,000 per member for T2028.")
    g = ex.ground({"predicate": {"type": "not_checkable", "reason": "process_obligation"},
                   "verbatim_quote": "Hospice services require prior authorization."}, sec)
    assert g["keep"]                                                      # 5 words + an obligation verb (C3-17)
    g = ex.ground({"predicate": {"type": "not_checkable", "reason": "process_obligation"},
                   "verbatim_quote": "Hospice services require"}, sec)
    assert not g["keep"] and g["drop_reason"] == "quote too short to evidence the rule"
    assert ex._threshold_present(1000, ex._norm("not to exceed $1,000 per member"))
    assert ex._threshold_present(1, ex._norm("billing will be submitted once per month"))
    assert ex._threshold_present(2, ex._norm("may be billed twice per day"))
    assert not ex._threshold_present(1, ex._norm("a dose of 1.5 units"))
    g = ex.ground({"predicate": {"type": "code_not_covered", "code": "T202"}, "codes": ["T202"],
                   "verbatim_quote": "Billing will be submitted once per month for T2023."}, sec)
    assert not g["keep"] and g["codes_found"] == "none"                   # 'T202' is not in 'T2023' (C3-19)


# ============================================================ 11. PDF versions + stage manifest (C4-08)
def test_every_acquired_pdf_version_is_kept_and_the_stage_manifest_records_it(tmp_path, monkeypatch):
    d = str(tmp_path)
    path = os.path.join(d, os.path.basename(config.CHAPTERS["10"][1]))
    open(path, "wb").write(b"%PDF-1.4 version A")
    a = pdx.acquire("10", d, download=False)                               # already in the folder (hand upload)
    assert a["version_path"] == os.path.join(d, "_versions", f"10_{a['doc_hash'][:12]}.pdf")
    assert open(a["version_path"], "rb").read() == b"%PDF-1.4 version A"
    open(path, "wb").write(b"%PDF-1.4 version B (hand upload)")             # replaced by hand: no download
    b = pdx.acquire("10", d, download=False)
    assert os.path.exists(a["version_path"]) and os.path.exists(b["version_path"]) and a["doc_hash"] != b["doc_hash"]
    import types
    monkeypatch.setitem(sys.modules, "requests", types.SimpleNamespace(get=lambda *a, **k: types.SimpleNamespace(
        content=b"%PDF-1.4 version C", raise_for_status=lambda: None)))
    c = pdx.acquire("10", d, download=True)
    assert len(os.listdir(os.path.join(d, "_versions"))) == 3 and c["source"] == "download"
    assert pdx.inventory_record(c, {"pages": 1, "revision_date": None, "revision_dates": [], "sections": 0,
                                    "candidate_sections": 0})["version_path"] == c["version_path"]
    mpath = pdx.write_stage_manifest(d, [c])
    m = pdx.read_stage_manifest(d)
    assert mpath.endswith("stage_manifest.json") and m["files"]["10"]["doc_hash"] == c["doc_hash"]
    assert {"bytes", "fetched_at", "version_path", "source"} <= set(m["files"]["10"])
    pdx.write_stage_manifest(d, [])                                          # a partial re-stage keeps entries
    assert pdx.read_stage_manifest(d)["files"]["10"]["restaged"] is False


def test_stage_and_gpu_notebooks_use_the_stage_manifest():
    src03 = open(os.path.join(PKG, "notebooks", "03_stage_inputs.py")).read()
    src04 = open(os.path.join(PKG, "notebooks", "04_extract_chapters_gpu.py")).read()
    assert "policy_docs.write_stage_manifest(PDF_DIR, staged)" in src03 and "_versions" in src03
    assert "policy_docs.read_stage_manifest(PDF_DIR)" in src04 and "staged_doc_hash" in src04
    assert "post_check_downgrade" in src04 and "model_truncated" in src04


# ============================================================ 12. regression gate (regress.py)
def _g(gid, kind, pred, quote, ch="19", effective_date=None, end_date=None, **kw):
    return regress._gold_row(gid, kind, ch, pred, quote, eff=effective_date, end=end_date, **kw)


def _d(rid, pred, quote, ch="19", **kw):
    return {"rule_id": rid, "chapter": ch, "predicate": json.dumps(pred), "verbatim_quote": quote, **kw}


def test_regress_matches_by_key_then_quote_and_scores_exact_and_recall():
    pair = {"type": "code_pair_prohibited", "code_a": "H2025", "code_b": "H2026", "modifier_indicator": "0"}
    q = "Service codes H2025, H2026, and H2027 cannot be billed on the same day."
    gold = [_g("G1", "positive", pair, q, key="k1"),
            _g("G2", "positive", dict(pair, code_b="H2027"), q),
            _g("G3", "missed", {"type": "code_not_covered", "code": "J1055"}, "Prior to 1/1/2013 bill J1055. "
               "Effective 1/1/2013 bill J1050.")]
    drafts = [_d("D1", dict(pair, scope="member_provider_day"), "other text", extraction_key="k1"),   # by key
              _d("D2", dict(pair, code_b="H2027", code_a="H2025"), q),                              # by quote
              _d("D3", {"type": "not_checkable", "reason": "process_obligation"}, "unrelated sentence here")]
    summ, detail = regress.compare(gold, drafts)
    t = summ["total"]
    assert (t["tp"], t["exact"], t["fn_missed"], t["unmatched"], t["danger"]) == (2, 2, 1, 1, 0)
    assert t["recall"] == round(2 / 3, 3) and regress.ship_gate(summ)[0]
    assert {r["how"] for r in detail} == {"key", "quote", "missing", "unmatched"}


def test_regress_danger_for_wider_or_resurrected_rules():
    pair = {"type": "code_pair_prohibited", "code_a": "S9484", "code_b": "S9485", "modifier_indicator": "0"}
    q = "A single provider cannot bill both codes in the first 24 hours of a crisis episode, for the same member."
    cap = {"type": "max_units_per_day", "code": "A0422", "threshold": 1, "exception": "unless separately identifiable"}
    qc = "oxygen supplies with code A0422 may be charged for only one ground ambulance trip, unless separately identifiable"
    rej = ("Self-help/peer services ... cannot be billed on the same day as a per diem code.")
    gold = [_g("G1", "positive", pair, q), _g("G2", "positive", cap, qc),
            _g("G3", "negative", {"type": "code_pair_prohibited", "code_a": "H0038", "code_b": "H2016"}, rej),
            _g("G4", "positive", {"type": "not_checkable", "reason": "requires_medical_record"}, "Apnea management "
               "and training services may not be billed using procedure code 94799.")]
    drafts = [_d("D1", dict(pair, scope="member_day"), q),                                    # wider scope
              _d("D2", {"type": "max_units_per_day", "code": "A0422", "threshold": 1}, qc),   # lost exception
              _d("D3", {"type": "code_pair_prohibited", "code_a": "H0038", "code_b": "H2016"}, rej),  # resurrected
              _d("D4", {"type": "code_not_covered", "code": "94799"}, "Apnea management and training services may "
                 "not be billed using procedure code 94799.")]                                 # compiles, gold not
    summ, detail = regress.compare(gold, drafts)
    by = {r["rule_id"]: r for r in detail if r["rule_id"]}
    assert "member_day" in by["D1"]["danger_reasons"] and "exception" in by["D2"]["danger_reasons"]
    assert "REJECTED" in by["D3"]["danger_reasons"] and "compiles" in by["D4"]["danger_reasons"]
    assert summ["total"]["danger"] == 4 and not regress.ship_gate(summ)[0]
    # narrower is not danger: per-provider cap, shorter period, later start, scope narrowed, an added label
    g = _g("G", "positive", {"type": "max_units_per_period", "code_set": ["H0044"], "threshold": 6,
                             "period": "benefit_year"}, "Six units of H0044.", effective_date="2016-01-01")
    d = _d("D", {"type": "max_units_per_period", "code_set": ["H0044"], "threshold": 6, "period": "month"},
           "Six units of H0044.", effective_date="2017-01-01")
    assert regress.wider_reasons(d, g) == []
    assert regress.wider_reasons(_d("D", {"type": "max_units_per_dos", "code": "T1015", "threshold": 1}, "q"),
                                 _g("G", "positive", {"type": "max_units_per_day", "code": "T1015", "threshold": 1},
                                    "q")) == []


def test_regress_gold_builders_signed_only_and_current_version():
    sr = pd.DataFrame([
        {"rule_id": "EXT-a", "origin": "extracted", "review_status": "approved", "reviewer": "SS", "chapter": "10",
         "doc_hash": "h1", "predicate": json.dumps({"type": "code_not_covered", "code": "11975"}),
         "verbatim_quote": "Do not bill 11975.", "extraction_key": "a", "population": "all"},
        {"rule_id": "EXT-b", "origin": "extracted", "review_status": "rejected", "reviewer": "SS", "chapter": "10",
         "doc_hash": "h1", "predicate": "{}", "verbatim_quote": "x", "extraction_key": "b"},
        {"rule_id": "EXT-c", "origin": "extracted", "review_status": "approved", "reviewer": None, "chapter": "10",
         "doc_hash": "h1", "predicate": "{}", "verbatim_quote": "y", "extraction_key": "c"},
        {"rule_id": "EXT-d", "origin": "extracted", "review_status": "approved", "reviewer": "SS", "chapter": "10",
         "doc_hash": "OLD", "predicate": "{}", "verbatim_quote": "z", "extraction_key": "d"},
        {"rule_id": "EXT-e", "origin": "extracted", "review_status": "draft", "reviewer": None, "chapter": "10",
         "doc_hash": "h1", "predicate": "{}", "verbatim_quote": "w", "extraction_key": "e"}])
    rep = {}
    gold = regress.gold_from_state_rules(sr, {"10": "h1"}, report=rep)
    assert [(g["gold_id"], g["kind"]) for g in gold] == [("EXT-a", "positive"), ("EXT-b", "negative")]
    assert rep["excluded"] == {"unsigned": 1, "other_doc_version": 1, "status:draft": 1}
    book = {"review": pd.DataFrame([
        {"rule_id": "EXT-f", "chapter": "19", "decision": "Fix", "reviewer": "SS", "predicate": "{}",
         "corrected_predicate": '{"type": "not_checkable", "reason": "no_claim_field"}', "verbatim_quote": "q1"},
        {"rule_id": "EXT-g", "chapter": "19", "decision": "Approve", "reviewer": "",
         "predicate": '{"type": "code_not_covered", "code": "11977"}', "verbatim_quote": "q2"}]),
        "missed_rules": pd.DataFrame([{"chapter": 19, "verbatim": "Claims with T1016 must not be billed on the same "
                                       "day as H0018.", "suggested_predicate": '{"type": "code_pair_prohibited", '
                                       '"code_a": "H0018", "code_b": "T1016"}'}])}
    gold = regress.gold_from_workbook(book)
    assert [(g["gold_id"], g["kind"]) for g in gold] == [("EXT-f", "positive"), ("MISSED-19-000", "missed")]
    assert gold[0]["predicate"] == {"type": "not_checkable", "reason": "no_claim_field"}
    assert len(regress.gold_from_workbook(book, require_reviewer=False)) == 3


def test_regress_scores_a_rerun_against_the_consolidated_workbook_correctly():
    """2026-10-04, before re-extracting with prompt v2: the consolidated review workbook must be a usable answer key.
    (1) curated rows (origin manual, no verbatim_quote) are 'missed' gold scored on the passages their notes quote -
    they used to be unmatchable, so a run that found them still scored them missing; (2) a Fix is scored with its
    corrected dates; (3) a reject that duplicates a kept rule is not a negative, and a draft equal to the kept rule is
    matched to it, not to a rejected alternative of the same sentence (a false DANGER); (4) provider-type rules."""
    s5151 = ("NOTE: Providers are prohibited from billing S5151 with H0001, H0002 or any other per diem code on the "
             "same day.")
    pair = lambda a, b, **k: json.dumps(dict({"type": "code_pair_prohibited", "code_a": a, "code_b": b,
                                              "modifier_indicator": "0"}, **k))
    q25 = "Service codes H2025, H2026, and H2027 cannot be billed on the same day."
    pta = {"type": "provider_type_allowed", "code_set": ["H0035"], "provider_types": ["B2", "B5", "02", "71"]}
    review = pd.DataFrame([
        {"rule_id": "MAN-1", "origin": "manual", "chapter": "19", "decision": "Approve", "predicate": pair("H0001", "S5151"),
         "policy_text_and_notes": f'Verbatim (Ch.19 p.31): "{s5151}" The finding sits on the S5151 line.',
         "effective_date": "2024-07-08"},
        {"rule_id": "MAN-2", "origin": "manual", "chapter": "10", "decision": "Approve",
         "predicate": json.dumps({"type": "code_not_covered", "code": "11975"}),
         "policy_text_and_notes": "Norplant insertion; no longer distributed."},                 # quotes nothing
        {"rule_id": "EXT-k", "origin": "extracted", "chapter": "19", "decision": "Fix", "extraction_key": "k",
         "predicate": json.dumps(pta), "corrected_predicate": json.dumps(dict(pta, provider_role="billing")),
         "corrected_effective_date": "2024-07-08", "verbatim_quote": "H0035 only by B2, B5, 02 and 71."},
        {"rule_id": "MAN-3", "origin": "manual", "chapter": "19", "decision": "Reject",          # rejected wider reading
         "predicate": pair("H2025", "H2026", scope="member_day"), "policy_text_and_notes": f'Verbatim: "{q25}"'},
        {"rule_id": "EXT-p", "origin": "extracted", "chapter": "19", "decision": "Approve", "extraction_key": "p",
         "predicate": pair("H2025", "H2026", scope="member_provider_day"), "verbatim_quote": q25},   # (after MAN-3)
        {"rule_id": "EXT-dup", "origin": "extracted", "chapter": "19", "decision": "Reject", "extraction_key": "dup",
         "predicate": pair("H2025", "H2026", scope="member_provider_day"), "verbatim_quote": q25}])  # a duplicate
    missed = pd.DataFrame([{"chapter": 19, "verbatim": s5151, "suggested_predicate": pair("H0001", "S5151")},
                           {"chapter": 19, "verbatim": "Claims with T1016 must not be billed on the same day as H0018.",
                            "suggested_predicate": pair("H0018", "T1016")}])
    rep = {}
    gold = regress.gold_from_workbook({"review": review, "missed_rules": missed}, require_reviewer=False, report=rep)
    kinds = {g["gold_id"]: g["kind"] for g in gold}
    assert kinds == {"MAN-1": "missed", "EXT-k": "positive", "EXT-p": "positive", "MAN-3": "negative",
                     "MISSED-19-001": "missed"}, kinds
    assert rep["excluded"] == {"curated_without_quote": 1, "missed_rule_already_curated": 1,
                               "reject_same_as_a_kept_rule": 1}
    g = {x["gold_id"]: x for x in gold}
    assert g["MAN-1"]["quote"] == s5151 and g["MAN-1"]["extraction_key"] is None
    assert g["EXT-k"]["effective_date"] == "2024-07-08" and g["EXT-k"]["predicate"]["provider_role"] == "billing"
    drafts = [_d("D1", json.loads(pair("H0001", "S5151")), s5151, effective_date="2024-07-08"),   # finds the curated
              _d("D2", pta, "H0035 only by B2, B5, 02 and 71.", extraction_key="k"),             # lacks the date
              _d("D3", json.loads(pair("H2025", "H2026")), q25)]                                  # = the kept reading
    summ, detail = regress.compare(gold, drafts)
    t, by = summ["total"], {r["rule_id"]: r for r in detail if r["rule_id"]}
    assert (t["tp_missed"], t["fn_missed"], t["exact"]) == (1, 1, 3)
    assert by["D3"]["gold_id"] == "EXT-p" and not by["D3"]["danger"]          # not a "resurrected" rejection
    assert by["D2"]["danger_reasons"].startswith("starts at the beginning before the signed 2024-07-08")
    assert (t["danger"], t["danger_date_only"]) == (1, 1) and "only lack a start" in regress.ship_gate(summ)[1]
    wide = _d("D4", json.loads(pair("H2025", "H2026", scope="member_day")), q25)   # the rejected member-wide reading
    summ, detail = regress.compare(gold, [wide])
    assert detail[0]["gold_id"] == "MAN-3" and "REJECTED" in detail[0]["danger_reasons"]
    # provider-type rules: a shorter list or the other provider flags more; ' 2' is '02'
    gp = _g("G", "positive", dict(pta, provider_role="billing"), "q")
    assert regress.wider_reasons(_d("D", dict(pta, provider_types=["B2", "B5", " 2", "71.0"]), "q"), gp) == []
    assert regress.canon(dict(pta, provider_types=["B2", "B5", " 2", 71])) == regress.canon(gp["predicate"])
    assert "also allows ['71']" in regress.wider_reasons(_d("D", dict(pta, provider_types=["B2", "B5", "02"]), "q"),
                                                         gp)[0]
    assert "servicing" in regress.wider_reasons(_d("D", dict(pta, provider_role="servicing"), "q"), gp)[0]
    # state_rules gold: approved curated rows are 'missed' gold too (they used to be skipped)
    sr = pd.DataFrame([{"rule_id": "MAN-1", "origin": "manual", "review_status": "approved", "reviewer": "SS",
                        "chapter": "19", "predicate": pair("H0001", "S5151"), "notes": f'Verbatim: "{s5151}"'},
                       {"rule_id": "MAN-9", "origin": "manual", "review_status": "legacy_hand_authored", "reviewer": None,
                        "chapter": "19", "predicate": pair("H0002", "S5151"), "notes": f'Verbatim: "{s5151}"'}])
    rep = {}
    assert [(x["gold_id"], x["kind"]) for x in regress.gold_from_state_rules(sr, {"19": "h"}, report=rep)] == \
        [("MAN-1", "missed")] and rep["excluded"] == {"status:legacy_hand_authored": 1}


def test_ship_gate_blocks_new_executable_drafts_nobody_reviewed():
    """2026-10-04 (external review): DANGER is measured only on drafts the gold matches, so a run whose NEW executable
    drafts nobody reviewed passed the gate. unmatched_compiled > 0 now blocks it; a new LEAD (not_checkable) does not."""
    q = "Do not bill for CPT code 11975 on any claim."
    gold = [_g("G1", "positive", {"type": "code_not_covered", "code": "11975"}, q, ch="10")]
    found = _d("D1", {"type": "code_not_covered", "code": "11975"}, q, ch="10")
    new_rule = _d("D2", {"type": "code_not_covered", "code": "99070"}, "AHCCCS does not reimburse code 99070 at all.",
                  ch="10")
    new_lead = _d("D3", {"type": "not_checkable", "reason": "process_obligation"}, "Providers must keep records.", ch="10")
    summ, _ = regress.compare(gold, [found, new_rule, new_lead])
    assert (summ["total"]["danger"], summ["total"]["unmatched"], summ["total"]["unmatched_compiled"]) == (0, 2, 1)
    ok, why = regress.ship_gate(summ)
    assert not ok and why.startswith("BLOCKED: 1 new executable draft(s) have no reviewed decision: adjudicate them "
                                     "before this run replaces the current extraction")
    summ, _ = regress.compare(gold, [found, new_lead])
    ok, why = regress.ship_gate(summ)
    assert ok and why.startswith("OK: no draft is wider than the signed decisions (DANGER == 0)")
    # nothing signed at all: every draft that would compile is unreviewed
    assert not regress.ship_gate(regress.compare([], [found])[0])[0]
    # both reasons, the date-only count kept
    ok, why = regress.ship_gate({"total": {"danger": 2, "danger_date_only": 1, "unmatched_compiled": 3}})
    assert not ok and "BLOCKED: 2 draft(s) would flag claims the signed rules do not" in why
    assert "1 of them only lack a start / end date" in why and "3 new executable draft(s) have no reviewed decision" in why
    assert regress.ship_gate({"total": {"danger": 0}})[0]                # a summary without the key: nothing unmatched


def test_compare_runs_one_row_per_run_on_the_same_gold():
    pair = {"type": "code_pair_prohibited", "code_a": "H2025", "code_b": "H2026", "modifier_indicator": "0"}
    q = "Service codes H2025, H2026, and H2027 cannot be billed on the same day."
    gold = [_g("G1", "positive", pair, q), _g("G2", "positive", dict(pair, code_b="H2027"), q),
            _g("G3", "missed", {"type": "code_not_covered", "code": "J1055"}, "Prior to 1/1/2013 bill J1055.")]
    low = [_d("L1", pair, q), _d("L2", {"type": "not_checkable", "reason": "process_obligation"}, "unrelated text here")]
    medium = [_d("M1", pair, q), _d("M2", dict(pair, code_b="H2027"), q),
              _d("M3", {"type": "code_not_covered", "code": "J1055"}, "Prior to 1/1/2013 bill J1055."),
              _d("M4", dict(pair, scope="member_day"), q),                                      # a wider duplicate
              _d("M5", {"type": "code_not_covered", "code": "T1016"}, "T1016 is never paid on its own.")]  # unreviewed
    rows = regress.compare_runs(gold, low, medium, labels=("low", "medium"))
    assert [r["run"] for r in rows] == ["low", "medium"]
    keys = ["drafts", "recall", "recall_missed", "exact_rate", "precision_known", "danger", "danger_date_only",
            "unmatched_compiled", "ship_gate"]
    assert all(set(keys) <= set(r) for r in rows)
    a, b = rows
    assert (a["drafts"], a["recall"], a["recall_missed"], a["danger"], a["unmatched_compiled"], a["ship_gate"]) == \
        (2, round(1 / 3, 3), 0.0, 0, 0, "OK")                     # 1 of 3 signed + missed rules found
    assert (b["drafts"], b["recall"], b["recall_missed"], b["exact_rate"], b["danger"], b["unmatched_compiled"]) == \
        (5, 1.0, 1.0, 1.0, 1, 1)
    assert b["ship_gate"] == "BLOCKED" and "1 new executable draft(s)" in b["ship_gate_reason"]
    # the rows are compare() + ship_gate() of each run: nothing else differs
    summ, _ = regress.compare(gold, medium)
    assert b["precision_known"] == summ["total"]["precision_known"] and b["ship_gate_reason"] == regress.ship_gate(summ)[1]
    assert [r["run"] for r in regress.compare_runs(gold, low, None)] == ["A"]


def test_v05_notebook_is_databricks_source_read_only_and_gated():
    src = open(os.path.join(PKG, "notebooks", "validation", "v05_extraction_regression.py")).read()
    assert src.startswith("# Databricks notebook source") and "# COMMAND ----------" in src
    assert "PKB_PACKAGE_DIR" in src and "os.path.dirname(os.path.dirname(_here))" in src     # package-finding preamble
    assert "regress.compare(" in src and "regress.ship_gate(" in src and "REQUIRE_SIGNATURE    = True" in src
    assert "write_table" not in src and "saveAsTable" not in src and ".write." not in src     # read-only
    assert "xlsx_write_sheets" in src and 'f"{config.WORKSPACE_DATA_DIR}/validation"' in src


class _FakeTable:
    def __init__(self, df):
        self.df = df

    def toPandas(self):
        return self.df.copy()


class _FakeSpark:
    """spark.table(name).toPandas() over pandas frames; any write attempt fails the test."""
    def __init__(self, tables):
        self.tables = tables

    def table(self, name):
        if name not in self.tables:
            raise Exception(f"[TABLE_OR_VIEW_NOT_FOUND] The table `{name}` cannot be found")
        return _FakeTable(self.tables[name])

    def createDataFrame(self, *a, **k):
        raise AssertionError("v05 must be read-only")


def test_v05_notebook_runs_on_a_stub_run_folder(tmp_path, monkeypatch):
    """Smoke run of the notebook source (the e2e harness runs every validation notebook): a STUB run of the fixture
    chapter, every draft approved by a named reviewer -> gold == drafts by key -> DANGER 0, workbook exported."""
    import extract_io
    import state_rules as sr
    sys.path.insert(0, HERE)
    import fixture_pdf
    path = fixture_pdf.build(str(tmp_path / "fx.pdf"))
    secs, meta = pdx.segment(pdx.parse_pdf(path), "10", "dh10")
    inv = {"chapter": "10", "title": "T", "url": "u", "doc_hash": "dh10", "revision_date": meta["revision_date"]}
    drafts, dropped, st = ex.extract_chapter(secs, inv, ex.StubBackend(), "r1", cache={}, log_fn=lambda *a: None)
    run_root = tmp_path / "extraction_runs"
    rd = extract_io.new_run_dir(str(run_root), "20261002T000000")
    extract_io.write_run(rd, inventory_rows=[{"chapter": "10", "doc_hash": "dh10"}], section_rows=[], log_rows=[st],
                         dropped_rows=dropped, change_rows=[], drafts=drafts, cache={},
                         manifest={"run_id": "20261002T000000", "finished": True, "prompt_version": ex.PROMPT_VERSION})
    table, _ = sr.merge_drafts(None, drafts)
    table["review_status"], table["reviewer"] = "approved", "SS"
    monkeypatch.setenv("PKB_PACKAGE_DIR", PKG)
    monkeypatch.setattr(config, "RUN_ROOT", str(run_root))
    monkeypatch.setattr(config, "WORKSPACE_DATA_DIR", str(tmp_path))
    src = open(os.path.join(PKG, "notebooks", "validation", "v05_extraction_regression.py")).read()
    src = src.replace("    importlib.reload(_m)", "    pass")                      # keep the patched config
    shown = []
    g = {"spark": _FakeSpark({config.STATE_RULES_TABLE: table}), "display": shown.append, "__name__": "v05"}
    exec(compile(src, "v05", "exec"), g)
    assert g["ok"] and g["summary"]["total"]["danger"] == 0 and g["summary"]["total"]["tp"] == len(drafts)
    assert g["summary"]["total"]["exact"] == len(drafts) and os.path.exists(g["path"])
    assert g["path"].startswith(str(tmp_path / "validation"))
    assert len(g["runs_df"]) == 1 and g["runs_df"]["ship_gate"].tolist() == ["OK"] and not g["CORPUS_WARNINGS"]


def test_v05_ab_scores_two_runs_on_the_same_gold_and_records_their_corpus(tmp_path, monkeypatch, capsys):
    """2026-10-04 (external review): reasoning_effort low vs medium on the same gold - one row per run with its gate
    verdict and corpus_version; a WARNING when the runs, or a run and the gold, read different document versions."""
    import extract_io
    import quality
    import state_rules as sr
    sys.path.insert(0, HERE)
    import fixture_pdf
    path = fixture_pdf.build(str(tmp_path / "fx.pdf"))
    secs, meta = pdx.segment(pdx.parse_pdf(path), "10", "dh10")
    inv = {"chapter": "10", "title": "T", "url": "u", "doc_hash": "dh10", "revision_date": meta["revision_date"]}
    drafts, dropped, st = ex.extract_chapter(secs, inv, ex.StubBackend(), "r1", cache={}, log_fn=lambda *a: None)
    run_root = tmp_path / "extraction_runs"
    a = extract_io.new_run_dir(str(run_root), "20261002T000000")
    extract_io.write_run(a, inventory_rows=[{"chapter": "10", "doc_hash": "dh10"}], section_rows=[], log_rows=[st],
                         dropped_rows=dropped, change_rows=[], drafts=drafts, cache={},
                         manifest={"run_id": "20261002T000000", "finished": True, "prompt_version": ex.PROMPT_VERSION,
                                   "reasoning": "low"})
    # run B: the same drafts plus one new EXECUTABLE draft nobody reviewed, read from another version of the chapter
    extra = dict(drafts[0], rule_id="EXT-new", extraction_key="new-key", population="all",
                 predicate=json.dumps({"type": "code_not_covered", "code": "ZZ999"}), codes=json.dumps(["ZZ999"]),
                 verbatim_quote="Code ZZ999 is never covered for any member in any setting.")
    b = extract_io.new_run_dir(str(run_root), "20261003T000000")
    extract_io.write_run(b, inventory_rows=[{"chapter": "10", "doc_hash": "dh10-v2"}], section_rows=[], log_rows=[st],
                         dropped_rows=dropped, change_rows=[], drafts=drafts + [extra], cache={},
                         manifest={"run_id": "20261003T000000", "finished": True, "prompt_version": ex.PROMPT_VERSION,
                                   "reasoning": "medium"})
    table, _ = sr.merge_drafts(None, drafts)
    table["review_status"], table["reviewer"] = "approved", "SS"
    monkeypatch.setenv("PKB_PACKAGE_DIR", PKG)
    monkeypatch.setattr(config, "RUN_ROOT", str(run_root))
    monkeypatch.setattr(config, "WORKSPACE_DATA_DIR", str(tmp_path))
    src = open(os.path.join(PKG, "notebooks", "validation", "v05_extraction_regression.py")).read()
    for old, new in (("    importlib.reload(_m)", "    pass"),
                     ("RUN_ID               = None", 'RUN_ID               = "20261002T000000"'),
                     ("RUN_DIR_B            = None", f"RUN_DIR_B            = {str(b)!r}")):
        assert old in src
        src = src.replace(old, new)
    g = {"spark": _FakeSpark({config.STATE_RULES_TABLE: table}), "display": lambda *a, **k: None, "__name__": "v05"}
    exec(compile(src, "v05", "exec"), g)
    runs = g["runs_df"]
    assert runs["ship_gate"].tolist() == ["OK", "BLOCKED"] and runs["unmatched_compiled"].tolist() == [0, 1]
    assert runs["drafts"].tolist() == [len(drafts), len(drafts) + 1] and runs["recall"].tolist() == [1.0, 1.0]
    assert runs["corpus_version"].tolist() == [pdx.corpus_version({"10": "dh10"}), pdx.corpus_version({"10": "dh10-v2"})]
    assert "reasoning low" in runs["run"].iloc[0] and "reasoning medium" in runs["run"].iloc[1]
    w = g["CORPUS_WARNINGS"]
    assert any(x.startswith("runs A and B rest on different corpus versions") and "10: A dh10 vs B dh10-v2" in x for x in w)
    assert any("another document version than run B in chapter(s) 10" in x for x in w)
    assert not any("than run A" in x for x in w)                  # the gold was built on run A's versions
    assert "WARNING: runs A and B rest on different corpus versions" in capsys.readouterr().out
    book = quality.xlsx_read_sheets(g["path"])
    assert {"README", "summary", "runs", "detail", "summary_B", "detail_B"} <= set(book)
    assert book["runs"]["ship_gate"].tolist() == ["OK", "BLOCKED"] and "corpus_version" in book["runs"]
    assert any("corpus warnings: runs A and B rest on different corpus versions" in str(x)
               for x in book["README"].iloc[:, 0])
    assert g["path"].endswith(".xlsx") and "20261002T000000_vs_20261003T000000" in g["path"]
