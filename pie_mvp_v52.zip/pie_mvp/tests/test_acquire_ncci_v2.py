"""Offline tests for the 2026-10-02 acquisition fixes (critic C2 / C4 findings):
C2-15 real CMS archive names + revisions + duplicates, C2-16 file-name-only classification and the
edition check against the file's own content, C2-17 quoting / row accounting, C2-18 malformed rows,
C2-24 exact MAI header, C4-09 per-row provenance, C2-19 acquisition_provenance(). No Spark, no network."""
import io
import os
import sys
import zipfile

import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import acquire_ncci as acq  # noqa: E402
import kb_io  # noqa: E402

# ----------------------------------------------------------------------------------------- data
# Every .zip on https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-mue-archive
# (WebFetch 2026-10-02), in page order, per section. Link text on that page is only "Effective <date>"
# (a POSTING date: "Effective Sep. 2, 2025" is the 2025Q4 file), so the file name is the only source.
# There is no 2023Q2 entry in any section, and there is no Medicaid PTP archive page (404).
ARCHIVE_QUARTERS = ["2026q2", "2026q1", "2025q4", "2025q3", "2025q2", "2025q1", "2024q4", "2024q3", "2024q2",
                    "2024q1", "2023q4", "2023q3", "2023q1", "2022q4", "2022q3", "2022q2", "2022q1", "2021q4",
                    "2021q3", "2021q2", "2021q1", "2020q4", "2020q3", "2020q2", "2020q1"]
ARCHIVE = {
    "practitioner": """
medicaid-ncci-q2-2026-mue-edits-practitioner-services.zip
medicaid-ncci-q1-2026-mue-edits-practitioner-services.zip
medicaid-ncci-q4-2025-mue-edits-practitioner-services.zip
medicaid-ncci-2025-q3-mue-edits-practitioner-services.zip
medicaid-ncci-2025q2-mue-edits-practitioner-services.zip
2025-q1-r1-ncci-mue-edits-practitioner-services.zip
medicaid-ncci-2024q4-mue-edits-practitioner-services.zip
2024-q3-ncci-mue-edits-practitioner-services.zip
medicaid-ncci-2024q2-mue-edits-practitioner-services.zip
medicaid-ncci-2024q1-mue-edits-practitioner-services.zip
medicaid-2023q4-ncci-mue-edits-practitioner-services.zip
2023q3-ncci-mue-edits-practitioner-services.zip
2023q1nccimueedits-practitionerservices.zip
medicaid-mcd-mue-practitionerservices-effective10012022.zip
medicaid-mcd-mue-practitionerservices-effective07012022.zip
medicaid-mcd-mue-practitionerservices-effective04012022.zip
medicaid-mcd-mue-practitionerservices-effective01012022.zip
medicaid-mcd-mue-practitionerservices-effective10012021.zip
medicaid-mcd-mue-practitionerservices-effective07012021.zip
medicaid-mcd-mue-practitionerservices-effective04012021.zip
medicaid-mcd-mue-practitionerservices-effective01012021.zip
medicaid-mcd-mue-practitionerservices-effective10012020.zip
medicaid-mcd-mue-practitionerservices-effective07012020.zip
medicaid-mcd-mue-practitionerservices-effective04012020.zip
medicaid-mcd-mue-practitionerservices-effective01012020.zip""",
    "outpatient": """
medicaid-ncci-q2-2026-mue-edits-outpatient-hospital-services.zip
medicaid-ncci-q1-2026-mue-edits-outpatient-hospital-services.zip
medicaid-ncci-q4-2025-mue-edits-outpatient-hospital-services.zip
medicaid-ncci-2025-q3-mue-edits-outpatient-hospital-services.zip
medicaid-ncci-2025q2-mue-edits-outpatient-hospital-services.zip
2025-q1-r1-ncci-mue-edits-outpatient-hospital-services.zip
medicaid-ncci-2024q4-mue-outpatient-hospital-services.zip
2024-q3-ncci-mue-edits-outpatient-hospital-services-zip.zip
medicaid-ncci-2024q2-mue-edits-outpatient-hospital-services.zip
medicaid-ncci-2024q1-mue-edits-outpatient-hospital-services.zip
medicaid-2023q4-ncci-mue-edits-outpatient-hospital-services.zip
2023q3-ncci-mue-edits-outpatient-hospital-services.zip
2023q1nccimueedits-outpatienthospitalservices.zip
medicaid-mcd-mue-outpatienthospitalservices-effective10012022.zip
medicaid-mcd-mue-outpatienthospitalservices-effective07012022.zip
medicaid-mcd-mue-outpatienthospitalservices-effective04012022.zip
medicaid-mcd-mue-outpatienthospitalservices-effective01012022.zip
medicaid-mcd-mue-outpatienthospitalservices-effective10012021.zip
medicaid-mcd-mue-outpatienthospitalservices-effective07012021.zip
medicaid-mcd-mue-outpatienthospitalservices-effective04012021.zip
medicaid-mcd-mue-outpatienthospitalservices-effective01012021.zip
medicaid-mcd-mue-outpatienthospitalservices-effective10012020.zip
medicaid-mcd-mue-outpatienthospitalservices-effective07012020.zip
medicaid-mcd-mue-outpatienthospitalservices-effective04012020.zip
medicaid-mcd-mue-outpatienthospitalservices-effective01012020.zip""",
    # NB the 'Effective April 1, 2025' DME entry links the PRACTITIONER zip (C2-16)
    "dme": """
medicaid-ncci-q2-2026-mue-edits-durable-medical-equipment-services.zip
medicaid-ncci-q1-2026-mue-edits-durable-medical-equipment-services.zip
medicaid-ncci-q4-2025-mue-edits-durable-medical-equipment.zip
medicaid-ncci-2025-q3-mue-edits-durable-medical-equipment-services.zip
medicaid-ncci-2025q2-mue-edits-practitioner-services.zip
2025-q1-r1-ncci-mue-edits-durable-medical-equipment-services.zip
medicaid-ncci-2024q4-mue-edits-dme-services.zip
2024-q3-ncci-mue-edits-durable-medical-equipment-services.zip
medicaid-ncci-2024q2-mue-edits-durable-medical-equipment-services.zip
medicaid-ncci-2024q1-mue-edits-durable-medical-equipment-services.zip
medicaid-2023q4-ncci-mue-edits-durable-medical-services.zip
2023q3-ncci-mue-edits-durable-medical-equipment-services.zip
2023q1nccimueedits-durablemedicalservices.zip
medicaid-mcd-mue-dmeservices-effective10012022.zip
medicaid-mcd-mue-dmeservices-effective07012022.zip
medicaid-mcd-mue-dmeservices-effective04012022.zip
medicaid-mcd-mue-dmeservices-effective01012022.zip
medicaid-mcd-mue-dmeservices-effective10012021.zip
medicaid-mcd-mue-dmeservices-effective07012021.zip
medicaid-mcd-mue-dmeservices-effective04012021.zip
medicaid-mcd-mue-dmeservices-effective01012021.zip
medicaid-mcd-mue-dmeservices-effective10012020.zip
medicaid-mcd-mue-dmeservices-effective07012020.zip
medicaid-mcd-mue-dmeservices-effective04012020.zip
medicaid-mcd-mue-dmeservices-effective01012020.zip""",
}
# The current edit-files page (WebFetch 2026-10-02): the only real PTP names there are.
LIVE_PTP = ["medicaid-ncci-2026-q4-ptp-edits-practitioner-services.zip",
            "medicaid-ncci-2026-q4-ptp-edits-outpatient-hospital-services.zip",
            "medicaid-ncci-2026-q4-ptp-edits-durable-medical-equipment-services.zip",
            "medicaid-ncci-2026-q3-ptp-edits-practitioner-services.zip",
            "medicaid-ncci-2026-q3-ptp-edits-hospital-outpatient-services.zip",
            "medicaid-ncci-2026-q3-ptp-edits-durable-medical-equipment.zip"]
CMS = "https://www.cms.gov/files/zip/"

HDR_PTP = ("Quarter Begin Date\tCategory\tColumn One\tColumn Two\tEffective Date\tDeletion Date\t"
           "Modifier Indicator\tPTP Edit Rationale\n")


def ptp_txt(qdate="20250101", category="Practitioner", rows=None, pre="", post=""):
    rows = rows or [("11042", "97597", "20100101", "*", "1", "Misuse of column two code with column one code"),
                    ("36415", "36416", "19960101", "20201231", "0", "Mutually exclusive procedures")]
    body = "".join(f"{qdate}\t{category}\t{a}\t{b}\t{e}\t{d}\t{m}\t{r}\n" for a, b, e, d, m, r in rows)
    return pre + HDR_PTP + body + post


def mue_txt(qdate="20250101", category="Practitioner", header="Practitioner Services MUE Values", rows=None,
            with_category=True):
    rows = rows or [("J3490", "1", "Nature of Service"), ("98960", "4", "Clinical: Data")]
    if with_category:
        return (f"Quarter Begin Date\tCategory\tHCPCS/CPT Code\t{header}\tMUE Rationale\n"
                + "".join(f"{qdate}\t{category}\t{c}\t{v}\t{r}\n" for c, v, r in rows))
    return (f"HCPCS/CPT Code\t{header}\tMUE Rationale\n" + "".join(f"{c}\t{v}\t{r}\n" for c, v, r in rows))


def zip_bytes(members: dict) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for n, d in members.items():
            z.writestr(n, d)
    return b.getvalue()


def put(folder, name, members) -> str:
    os.makedirs(folder, exist_ok=True)
    p = os.path.join(folder, name)
    with open(p, "wb") as f:
        f.write(zip_bytes(members))
    return p


def run(links, raw_dir, existing=None, overwrite=False, **kw):
    writes = []
    res = acq.acquire(None, links, str(raw_dir), "main", "sedo", download_files=False, overwrite=overwrite,
                      log=lambda *_: None, existing=existing or (lambda fqn: None),
                      writer=lambda df, fqn, mode: writes.append((fqn, mode, len(df), df)), **kw)
    return res, writes


# ------------------------------------------------------------------------- C2-15 classification
def test_every_real_mue_archive_name_classifies():
    for section, block in ARCHIVE.items():
        names = block.split()
        assert len(names) == len(ARCHIVE_QUARTERS) == 25
        for name, label in zip(names, ARCHIVE_QUARTERS):
            l = acq._classify(CMS + name, "Effective ...")
            want_service = "practitioner" if name == "medicaid-ncci-2025q2-mue-edits-practitioner-services.zip" else section
            assert (l.kind, l.edit, l.service, l.label) == ("edits", "mue", want_service, label), (name, l)
            assert l.revision == (1 if name.startswith("2025-q1-r1-") else 0), name
            assert l.table == f"medicaid_ncci_edit_{want_service}_mue_q{label[-1]}_{label[:4]}"


def test_live_ptp_names_and_change_reports_classify():
    for name in LIVE_PTP:
        l = acq._classify(CMS + name, "")
        assert l.kind == "edits" and l.edit == "ptp" and l.label in ("2026q3", "2026q4") and l.revision == 0
    assert {acq._classify(CMS + n, "").service for n in LIVE_PTP} == {"practitioner", "outpatient", "dme"}
    cr = acq._classify(CMS + "medicaid-ncci-change-report-effective-10012026.zip", "")
    assert cr.kind == "change_report" and cr.label == "2026q4"


@pytest.mark.parametrize("name, why", [
    ("medicaid-ncci-2026-q4-ptp-mue-edits-practitioner-services.zip", "both PTP and MUE"),
    ("medicaid-ncci-2026-q4-ptp-edits-practitioner-outpatient-services.zip", "several editions"),
    ("medicaid-ncci-2026-q4-q1-2027-ptp-edits-practitioner-services.zip", "more than one quarter"),
    ("medicaid-mcd-mue-dmeservices-effective01292025.zip", "not a quarter start"),
    ("medicaid-ncci-ptp-edits-practitioner-services.zip", "no year/quarter"),
    ("medicaid-ncci-2026-q4-ptp-edits-amendment-services.zip", "no edition"),   # 'amendment' is not DME
])
def test_ambiguous_or_incomplete_names_stay_unknown_with_a_reason(name, why):
    l = acq._classify(CMS + name, "")
    assert l.kind == "unknown" and why in l.note


def test_link_text_contradicting_the_file_name_is_noted_not_obeyed():
    html = ('<a href="/files/zip/medicaid-ncci-2025q2-mue-edits-practitioner-services.zip">'
            '2025_Q2_NCCI_MUE_Edits - Durable Medical Equipment Services (ZIP)</a>')
    (l,) = acq.discover_links(html)
    assert l.service == "practitioner" and "edition dme" in l.note and "classified by the file name" in l.note


def test_same_file_linked_under_two_headings_is_one_link_and_the_gap_is_reported():
    # the MUE archive links the practitioner 2025Q2 zip under both 'Practitioner' and 'DME'
    names = ["medicaid-ncci-2025q2-mue-edits-practitioner-services.zip",
             "medicaid-ncci-2025q2-mue-edits-outpatient-hospital-services.zip",
             "medicaid-ncci-2025q2-mue-edits-practitioner-services.zip"]
    html = "".join(f'<a href="https://www.cms.gov/files/zip/{n}">Effective April 1, 2025</a>' for n in names)
    links = acq.discover_links(html)
    assert len(links) == 2
    assert acq.check_quarter_complete(links)["2025q2"] == ["mue/dme", "ptp/dme", "ptp/outpatient", "ptp/practitioner"]


def test_duplicate_files_for_one_quarter_are_an_error(tmp_path):
    q = tmp_path / "raw"
    a = put(str(q / "a"), "2024-q3-ncci-mue-edits-outpatient-hospital-services-zip.zip",
            {"MUE.txt": mue_txt("20240701", "Outpatient Hospital", "Outpatient Hospital Services MUE Values")})
    b = put(str(q / "b"), "2024-q3-ncci-mue-edits-outpatient-hospital-services.zip",
            {"MUE.txt": mue_txt("20240701", "Outpatient Hospital", "Outpatient Hospital Services MUE Values")})
    links = acq.links_from_drop_zone(str(q))
    assert acq.duplicate_links(links) == {"2024q3 mue/outpatient r0": sorted([a, b])}
    with pytest.raises(acq.DuplicateLinkError, match="2024q3 mue/outpatient"):
        acq.check_quarter_complete(links)
    assert "2024q3" in acq.check_quarter_complete(links, allow_duplicates=True)     # still reports what is missing
    res, writes = run(links, q)
    assert [r.status for r in res] == ["failed", "failed"] and not writes
    assert all("DuplicateLinkError" in r.error and "keep exactly one" in r.error for r in res)


# ------------------------------------------------------------------------------ C2-15 revisions
ORIG = "medicaid-ncci-2025-q1-mue-edits-practitioner-services.zip"   # original: not on the archive any more
R1 = "2025-q1-r1-ncci-mue-edits-practitioner-services.zip"           # real archive name ('Effective Jan. 29, 2025')


@pytest.mark.parametrize("order", [(ORIG, R1), (R1, ORIG)])
def test_revision_wins_over_the_original_in_the_same_run_in_any_order(tmp_path, order):
    files = {ORIG: mue_txt("20250101", rows=[("J3490", "1", "x")]), R1: mue_txt("20250101", rows=[("J3490", "3", "x")])}
    paths = {n: put(str(tmp_path / "raw" / "2025q1"), n, {"MUE.txt": files[n]}) for n in order}
    links = [acq._classify(paths[n], n) for n in order]
    assert acq.check_quarter_complete(links, allow_duplicates=False)          # original + r1 is not a duplicate
    res, writes = run(links, tmp_path / "raw")
    by = {os.path.basename(r.url): r for r in res}
    assert by[ORIG].status == "superseded" and R1 in by[ORIG].note and by[ORIG].src_sha256 is None
    assert by[ORIG].sha256 == acq.sha256_file(paths[ORIG])                       # its OWN hash (C4-09)
    assert by[R1].status == "loaded" and by[R1].revision == 1 and "mid-quarter" in by[R1].warning
    assert [(w[0], w[1]) for w in writes] == [("main.sedo.medicaid_ncci_edit_practitioner_mue_q1_2025", "errorifexists")]
    assert list(writes[0][3]["MUE_Values"]) == [3]                               # the revised value


def test_revision_replaces_a_table_loaded_from_the_original_and_never_skips(tmp_path):
    p = put(str(tmp_path / "raw" / "2025q1"), R1, {"MUE.txt": mue_txt("20250101")})
    links = [acq._classify(p, R1)]
    table = {"known": True, "src_zip": ORIG, "src_sha256": "f" * 64, "revision": 0}
    res, writes = run(links, tmp_path / "raw", existing=lambda fqn: table)
    (r,) = res
    assert r.status == "replaced" and r.replaced_src_zip == ORIG and r.existing_source == "earlier_revision"
    assert writes and writes[0][1] == "overwrite"
    assert r.src_sha256 == r.sha256 == acq.sha256_file(p) and r.rows_loaded == 2


def test_original_never_downgrades_a_revision_even_with_overwrite(tmp_path):
    p = put(str(tmp_path / "raw" / "2025q1"), ORIG, {"MUE.txt": mue_txt("20250101")})
    table = {"known": True, "src_zip": R1, "src_sha256": "e" * 64, "revision": 1}
    for overwrite in (False, True):
        res, writes = run([acq._classify(p, ORIG)], tmp_path / "raw", existing=lambda fqn: table, overwrite=overwrite)
        assert res[0].status == "skipped_exists" and res[0].existing_source == "later_revision" and not writes
        assert "later revision" in res[0].note


def test_revision_next_to_a_hand_loaded_table_is_refused_original_is_skipped(tmp_path):
    hand = {"known": False, "src_zip": None, "src_sha256": None, "revision": None}
    p1 = put(str(tmp_path / "raw" / "2025q1"), R1, {"MUE.txt": mue_txt("20250101")})
    res, writes = run([acq._classify(p1, R1)], tmp_path / "raw", existing=lambda fqn: hand)
    assert res[0].status == "failed" and "ConflictError" in res[0].error and "OVERWRITE = True" in res[0].error
    assert not writes
    p0 = put(str(tmp_path / "raw2" / "2025q1"), ORIG, {"MUE.txt": mue_txt("20250101")})
    res, writes = run([acq._classify(p0, ORIG)], tmp_path / "raw2", existing=lambda fqn: hand)
    assert res[0].status == "skipped_exists" and res[0].existing_source == "no_provenance" and not writes
    assert "hand-loaded" in res[0].note and res[0].warning is None


# ------------------------------------------------------------------------------- C2-16 edition
def test_drop_zone_folder_names_never_steer_the_edition(tmp_path):
    folder = tmp_path / "Users" / "x" / "outpatient_project" / "data" / "ncci_raw" / "2026q4"
    p = put(str(folder), "medicaid-ncci-2026-q4-ptp-edits-practitioner-services.zip",
            {"PTP.txt": ptp_txt("20261001")})
    (l,) = acq.links_from_drop_zone(str(tmp_path))
    assert l.service == "practitioner" and l.url == p


def test_practitioner_file_under_a_dme_name_is_refused(tmp_path):
    # repro A3 inverted: CMS's archive links its 'DME 2025Q2' entry to the practitioner zip
    name = "medicaid-ncci-2025q2-mue-edits-durable-medical-equipment-services.zip"
    p = put(str(tmp_path / "raw" / "2025q2"), name, {"MUE.txt": mue_txt("20250401", "Practitioner")})
    res, writes = run([acq._classify(p, name)], tmp_path / "raw")
    assert res[0].status == "failed" and "C2-16" in res[0].error and "practitioner edition" in res[0].error
    assert not writes


@pytest.mark.parametrize("service, category, header", [
    ("practitioner", "Practitioner", "Practitioner Services MUE Values"),
    ("practitioner", "PRA", "MUE Values"),
    ("outpatient", "Outpatient Hospital", "Outpatient Hospital Services MUE Values"),
    ("outpatient", "OPH", "MUE Values"),
    ("dme", "DME", "DME Supplier Services MUE Values"),
    ("dme", "Durable Medical Equipment", "MUE Values"),
])
def test_known_edition_spellings_are_accepted(tmp_path, service, category, header):
    p = put(str(tmp_path), "m.zip", {"MUE.txt": mue_txt("20250101", category, header)})
    df, st = acq.parse_zip(p, "mue", (2025, 1), expected_service=service)
    assert len(df) == 2 and category in st["edition_evidence"] and st["edition_warnings"] == []


def test_mue_header_naming_another_edition_is_refused_without_a_category_column(tmp_path):
    p = put(str(tmp_path), "m.zip", {"MUE.txt": mue_txt(header="Practitioner Services MUE Values", with_category=False)})
    with pytest.raises(acq.ParseError, match="value column 'Practitioner Services MUE Values' is the practitioner"):
        acq.parse_zip(p, "mue", expected_service="dme")


def test_unknown_category_spelling_strict_refuses_lenient_warns(tmp_path):
    p = put(str(tmp_path), "p.zip", {"PTP.txt": ptp_txt(category="Medicaid")})
    with pytest.raises(acq.ParseError, match="not a known spelling"):
        acq.parse_zip(p, "ptp", expected_service="practitioner")
    df, st = acq.parse_zip(p, "ptp", expected_service="practitioner", category_check="lenient")
    assert len(df) == 2 and any("not recognised" in w for w in st["edition_warnings"])
    p2 = put(str(tmp_path), "p2.zip", {"PTP.txt": ptp_txt(category="Outpatient Hospital")})
    with pytest.raises(acq.ParseError, match="outpatient edition"):                       # lenient never
        acq.parse_zip(p2, "ptp", expected_service="practitioner", category_check="lenient")   # accepts a mismatch


def test_no_edition_evidence_is_a_warning_on_the_log_row(tmp_path):
    name = "medicaid-ncci-2025q2-mue-edits-practitioner-services.zip"
    p = put(str(tmp_path / "raw"), name, {"MUE.txt": mue_txt(header="MUE Values", with_category=False)})
    res, _ = run([acq._classify(p, name)], tmp_path / "raw")
    assert res[0].status == "loaded" and "file name only" in res[0].warning and res[0].edition_evidence is None


# ----------------------------------------------------------------------------- C2-17 parsing
def test_field_starting_with_a_quote_does_not_swallow_the_following_rows(tmp_path):
    body = "".join(f"20261001\tPractitioner\t1{i:04d}\t2{i:04d}\t20100101\t*\t1\tMisuse\n" for i in range(10))
    bad = body.replace("\tMisuse\n", '\t"Misuse of column two code\n', 1)              # repro A5
    df, st = acq.parse_zip(put(str(tmp_path), "q.zip", {"PTP.txt": "Medicaid NCCI PTP Edits\n\n" + HDR_PTP + bad}),
                           "ptp", (2026, 4))
    assert len(df) == 10 and df.loc[0, "PTP_Edit_Rationale"] == '"Misuse of column two code'
    assert st["members"][0]["nonblank_lines_after_header"] == 10


def test_fully_quoted_tab_cells_are_unwrapped(tmp_path):
    line = "\t".join(f'"{v}"' for v in ("20261001", "Practitioner", "11042", "97597", "20100101", "*", "1",
                                          'Say ""no""'))
    df, _ = acq.parse_zip(put(str(tmp_path), "q.zip", {"PTP.txt": HDR_PTP + line + "\n"}), "ptp", (2026, 4))
    assert df.loc[0, "Col1"] == "11042" and df.loc[0, "EffDt"] == 20100101 and df.loc[0, "PTP_Edit_Rationale"] == 'Say "no"'


def test_comma_file_unbalanced_quote_stays_on_its_own_line(tmp_path):
    hdr = HDR_PTP.replace("\t", ",")
    rows = ["20261001,Practitioner,11042,97597,20100101,*,1,\"Misuse, of codes\"",
            "20261001,Practitioner,11043,97598,20100101,*,1,\"Unbalanced quote",
            "20261001,Practitioner,11044,97599,20100101,*,0,Plain"]
    df, _ = acq.parse_zip(put(str(tmp_path), "c.zip", {"PTP.csv": hdr + "\n".join(rows) + "\n"}), "ptp", (2026, 4))
    assert list(df["Col1"]) == ["11042", "11043", "11044"] and df.loc[0, "PTP_Edit_Rationale"] == "Misuse, of codes"


def test_only_cr_lf_end_a_record(tmp_path):
    data = (HDR_PTP + "20261001\tPractitioner\t11042\t97597\t20100101\t*\t1\tSee notes\x85 more\n"
            "20261001\tPractitioner\t11043\t97598\t20100101\t*\t1\tx\n").encode("latin-1")
    df, _ = acq.parse_zip(put(str(tmp_path), "n.zip", {"PTP.txt": data}), "ptp")
    assert len(df) == 2 and df.loc[0, "PTP_Edit_Rationale"] == "See notes\x85 more"


def test_three_column_mue_text_file_is_recognised(tmp_path):
    # 'HCPCS/CPT Code', '<edition> MUE Values', 'MUE Rationale' = 2 tabs a line; the old sniff wanted 3
    txt = "Medicaid NCCI MUE Edits\n" + mue_txt(header="DME Supplier Services MUE Values", with_category=False,
                                                 rows=[("E0601", "1", "Nature of Equipment"), ("A4253", "2", "x"),
                                                       ("A4259", "2", "x")])
    df, st = acq.parse_zip(put(str(tmp_path), "m.zip", {"MUE.txt": txt}), "mue", expected_service="dme")
    assert list(df["HCPCS_CPT_Code"]) == ["E0601", "A4253", "A4259"] and list(df["MUE_Values"]) == [1, 2, 2]
    assert "DME Supplier Services MUE Values" in st["edition_evidence"]
    with pytest.raises(acq.ParseError, match="delimiter"):
        acq._text_rows(b"just\none\nword per line\n")


def test_row_accounting_invariant_raises_when_lines_and_rows_disagree():
    rows = acq._Rows([HDR_PTP.rstrip("\n").split("\t"),
                      "20261001\tPractitioner\t11042\t97597\t20100101\t*\t1\tx".split("\t")])
    rows.line_nonblank = [True, True, True]          # three physical lines, but the parse produced two rows
    with pytest.raises(acq.ParseError, match="row accounting failed"):
        acq.frame_from_rows(rows, "ptp")


# ------------------------------------------------------------------------- C2-18 malformed rows
def test_blank_column_two_raises_instead_of_dropping(tmp_path):
    rows = [(f"1{i:04d}", f"2{i:04d}", "20100101", "*", "1", "ok") for i in range(10)]
    rows += [(f"3{i:04d}", "", "20100101", "*", "0", "blank col2") for i in range(40)]       # repro A8
    with pytest.raises(acq.ParseError, match="40 rows have one valid code column"):
        acq.parse_zip(put(str(tmp_path), "w.zip", {"PTP.txt": ptp_txt("20261001", rows=rows)}), "ptp", (2026, 4))


def test_a_single_malformed_edit_raises():
    rows = acq._text_rows(ptp_txt(rows=[("11042", "97597", "20100101", "*", "1", "ok"),
                                        ("11042", "9759", "20100101", "*", "1", "4-char col2")]).encode())
    with pytest.raises(acq.ParseError, match="one valid code column"):
        acq.frame_from_rows(rows, "ptp")


def test_edit_data_with_blank_codes_raises():
    rows = acq._text_rows(ptp_txt(rows=[("11042", "97597", "20100101", "*", "1", "ok"),
                                        ("", "", "20100101", "*", "0", "codes lost")]).encode())
    with pytest.raises(acq.ParseError, match="edit data .* but no codes"):
        acq.frame_from_rows(rows, "ptp")


def test_unknown_text_in_a_code_column_raises():
    rows = acq._text_rows(ptp_txt(post="20261001\tPractitioner\tNOTE 1\tx\t\t\t\t\n").encode())
    with pytest.raises(acq.ParseError, match="not a 5-char CPT/HCPCS code"):
        acq.frame_from_rows(rows, "ptp")


def test_footers_notes_and_header_repeats_are_tolerated_and_counted(tmp_path):
    post = ("\n"
            "CPT codes, descriptions and other data only are copyright 2025 American Medical Association.\n"
            "\t\t\t\t\t\t\tNote: rationale text continues on the CMS site\n"     # code cells blank, no edit data
            + HDR_PTP                                                              # a repeated header
            + "20250101\tPractitioner\t11044\t97599\t20100101\t*\t1\tafter repeat\n"
            + "\t\tEnd of file\n")                                                 # footer text in a code column
    name = "medicaid-ncci-2025-q1-ptp-edits-practitioner-services.zip"
    p = put(str(tmp_path / "raw"), name, {"PTP.txt": ptp_txt(post=post)})
    df, st = acq.parse_zip(p, "ptp", (2025, 1))
    m = st["members"][0]
    assert len(df) == 3 and m["tolerated"] == {"blank_code_cells": 2, "header_repeat": 1, "footer_text": 1}
    assert m["nonblank_lines_after_header"] == 7
    res, _ = run([acq._classify(p, name)], tmp_path / "raw")
    assert res[0].status == "loaded" and res[0].tolerated_rows == 4 and "4 non-data body rows tolerated" in res[0].note


def test_header_repeat_with_a_different_layout_raises():
    swapped = HDR_PTP.replace("Column One\tColumn Two", "Column Two\tColumn One")
    rows = acq._text_rows(ptp_txt(post=swapped + "20250101\tPractitioner\t97597\t11042\t20100101\t*\t1\tx\n").encode())
    with pytest.raises(acq.ParseError, match="DIFFERENT column layout"):
        acq.frame_from_rows(rows, "ptp")


def test_too_many_tolerated_rows_still_means_a_misread_layout():
    rows = acq._text_rows(ptp_txt(post="".join(f"\t\t\t\t\t\t\tnote {i}\n" for i in range(51))).encode())
    with pytest.raises(acq.ParseError, match="more than 50"):
        acq.frame_from_rows(rows, "ptp")


# ---------------------------------------------------------------------------------- C2-24 MAI
def test_mai_column_matches_the_whole_name_only():
    m = acq._map_header(["HCPCS/CPT Code", "MUE Values", "Remaining Notes", "Maintenance", "MAIL"], acq.MUE_COLUMNS)
    assert "MUE_Adjudication_Indicator" not in m.values()
    for h in ("MUE Adjudication Indicator", "MAI", "Adjudication Indicator", "MUE Adjudication Indicator (MAI)"):
        m = acq._map_header(["HCPCS/CPT Code", "MUE Values", h], acq.MUE_COLUMNS)
        assert m[2] == "MUE_Adjudication_Indicator", h


# ------------------------------------------------------------------------- C4-09 log provenance
class _Resp:
    def __init__(self, content):
        self.status_code, self.content = 200, content


class _Session:
    def __init__(self, files):
        self.files = files

    def get(self, url, timeout=None):
        return _Resp(self.files[url.rsplit("/", 1)[1]])


def test_loaded_row_carries_its_file_provenance_and_skipped_row_only_its_own_hash(tmp_path):
    name = "medicaid-ncci-2026-q4-mue-edits-practitioner-services.zip"
    data = zip_bytes({"MUE.txt": mue_txt("20261001")})
    (l,) = acq.discover_links(f'<a href="/files/zip/{name}">2026_Q4_NCCI_MUE_Edits - Practitioner Services (ZIP)</a>')
    writes = []
    res = acq.acquire(None, [l], str(tmp_path), "main", "sedo", session=_Session({name: data}), log=lambda *_: None,
                      existing=lambda fqn: None, writer=lambda df, fqn, mode: writes.append(df))
    r = res[0]
    import hashlib
    assert r.status == "loaded" and r.sha256 == r.src_sha256 == hashlib.sha256(data).hexdigest()
    assert r.src_url == CMS + name and r.src_member == "MUE.txt" and r.src_zip == name and r.rows_loaded == 2
    assert set(writes[0]["src_sha256"]) == {r.sha256} and set(writes[0]["src_url"]) == {CMS + name}
    # the next run: the table exists, loaded from ANOTHER file of the same revision
    other = {"known": True, "src_zip": name, "src_sha256": "0" * 64, "revision": 0}
    res2 = acq.acquire(None, [l], str(tmp_path), "main", "sedo", session=_Session({}), log=lambda *_: None,
                       existing=lambda fqn: other, writer=lambda *a: None)
    s = res2[0]
    assert s.status == "skipped_exists" and s.sha256 == r.sha256          # its own (archived) file's hash
    assert "0" * 64 not in str(acq.results_frame(res2).iloc[0].to_dict())   # never the table's other file
    assert s.src_sha256 is None and s.src_url is None and s.rows_loaded is None
    assert s.existing_source == "different_file" and "DIFFERENT file" in s.warning
    # same file again: skipped quietly
    same = dict(other, src_sha256=r.sha256)
    res3 = acq.acquire(None, [l], str(tmp_path), "main", "sedo", session=_Session({}), log=lambda *_: None,
                       existing=lambda fqn: same, writer=lambda *a: None)
    assert res3[0].status == "skipped_exists" and res3[0].existing_source == "same_file" and res3[0].warning is None


def test_drop_zone_load_has_no_invented_url(tmp_path):
    name = "medicaid-ncci-2026-q4-mue-edits-practitioner-services.zip"
    p = put(str(tmp_path / "raw"), name, {"MUE.txt": mue_txt("20261001")})
    res, writes = run([acq._classify(p, name)], tmp_path / "raw")
    assert res[0].src_url is None and res[0].src_zip == name and res[0].src_sha256 == acq.sha256_file(p)


def test_results_frame_has_fixed_columns_and_dtypes():
    failed_only = [acq.LoadResult(quarter="2026q4", edit="mue", service="dme", kind="edits", url="u",
                                  status="failed", error="x")]
    df = acq.results_frame(failed_only)
    assert list(df.columns) == [f.name for f in acq.fields(acq.LoadResult)]
    for c in ("rows", "bytes", "rows_loaded", "revision", "tolerated_rows"):
        assert str(df[c].dtype) == "Int64", c
    assert df["src_sha256"].dtype == object and df.loc[0, "src_sha256"] is None
    assert acq.results_frame([]).empty


# ------------------------------------------------------------------- C2-19 acquisition_provenance
class _Frame:
    def __init__(self, df):
        self.df = df

    def toPandas(self):
        return self.df.copy()


class _LogSpark:
    def __init__(self, df=None, exc=None):
        self.df, self.exc, self.asked = df, exc, []

    def table(self, fqn):
        self.asked.append(fqn)
        if self.exc:
            raise self.exc
        return _Frame(self.df)


def test_acquisition_provenance_latest_successful_load_per_table():
    t1, t2, t3 = ("medicaid_ncci_edit_practitioner_mue_q1_2025", "medicaid_ncci_edit_dme_ptp_q4_2026",
                  "medicaid_ncci_edit_outpatient_mue_q3_2026")
    log = pd.DataFrame([
        # legacy row (before 2026-10-02): no src_* columns were written - sha256/url/members WERE the file
        {"quarter": "2026q3", "edit": "mue", "service": "outpatient", "kind": "edits", "table": t3, "status": "loaded",
         "url": CMS + "o.zip", "sha256": "a3", "members": "MUE.txt", "rows": 7, "loaded_at": "2026-07-05T10:00:00+00:00"},
        {"quarter": "2025q1", "edit": "mue", "service": "practitioner", "kind": "edits", "table": t1, "status": "loaded",
         "url": CMS + ORIG, "sha256": "s0", "src_sha256": "s0", "src_url": CMS + ORIG, "src_member": "MUE.txt",
         "src_zip": ORIG, "rows_loaded": 10, "loaded_at": "2025-01-05T10:00:00+00:00"},
        {"quarter": "2025q1", "edit": "mue", "service": "practitioner", "kind": "edits", "table": t1, "status": "replaced",
         "url": CMS + R1, "sha256": "s1", "src_sha256": "s1", "src_url": CMS + R1, "src_member": "MUE.txt",
         "src_zip": R1, "rows_loaded": 11, "loaded_at": "2025-02-01T10:00:00+00:00"},
        # later non-loads never change what the table holds
        {"quarter": "2025q1", "edit": "mue", "service": "practitioner", "kind": "edits", "table": t1,
         "status": "skipped_exists", "url": CMS + R1, "sha256": "s1", "loaded_at": "2025-03-01T10:00:00+00:00"},
        {"quarter": "2025q1", "edit": "mue", "service": "practitioner", "kind": "edits", "table": t1,
         "status": "failed", "url": CMS + R1, "sha256": None, "loaded_at": "2025-04-01T10:00:00+00:00"},
        {"quarter": "2026q4", "edit": "ptp", "service": "dme", "kind": "edits", "table": t2, "status": "loaded",
         "url": "/Workspace/x/ncci_raw/2026q4/d.zip", "sha256": "d4", "src_sha256": "d4", "src_url": None,
         "src_member": "PTP.txt", "src_zip": "d.zip", "rows_loaded": 3, "loaded_at": "2026-10-02T10:00:00+00:00"},
        {"quarter": "2026q4", "edit": None, "service": None, "kind": "change_report", "table": None,
         "status": "archived_only", "url": CMS + "cr.zip", "sha256": "cr", "loaded_at": "2026-10-02T10:00:00+00:00"},
    ])
    spark = _LogSpark(log)
    prov = acq.acquisition_provenance(spark)
    import config
    assert spark.asked == [config.NCCI_ACQUISITION_LOG]
    assert set(prov) == {t1, t2, t3}
    assert prov[t1] == {"src_sha256": "s1", "src_url": CMS + R1, "src_member": "MUE.txt", "quarter": "2025q1",
                        "service": "practitioner", "edit_type": "mue", "loaded_at": "2025-02-01T10:00:00+00:00",
                        "src_zip": R1, "rows_loaded": 11, "status": "replaced"}
    assert prov[t2]["src_url"] is None and prov[t2]["src_sha256"] == "d4" and prov[t2]["edit_type"] == "ptp"
    assert prov[t3]["src_sha256"] == "a3" and prov[t3]["src_url"] == CMS + "o.zip" and prov[t3]["src_member"] == "MUE.txt"
    assert prov[t3]["src_zip"] == "o.zip" and prov[t3]["rows_loaded"] == 7


def test_acquisition_provenance_without_a_log_table_is_empty_and_a_denied_read_raises():
    class AnalysisException(Exception):
        pass
    missing = _LogSpark(exc=AnalysisException("[TABLE_OR_VIEW_NOT_FOUND] The table `main.sedo.ncci_acquisition_log` cannot be found"))
    assert acq.acquisition_provenance(missing) == {}
    assert acq.acquisition_provenance(_LogSpark(pd.DataFrame())) == {}
    with pytest.raises(kb_io.TableAccessError):
        acq.acquisition_provenance(_LogSpark(exc=Exception("[CLOUD_ACCESS_DENIED] 403 AuthorizationFailure")))
    s = _LogSpark(exc=AnalysisException("TABLE_OR_VIEW_NOT_FOUND"))
    acq.acquisition_provenance(s, catalog="dev", schema="ncci")
    assert s.asked == ["dev.ncci.ncci_acquisition_log"]


def test_acquire_log_round_trips_into_acquisition_provenance(tmp_path):
    name = "medicaid-ncci-2026-q4-ptp-edits-practitioner-services.zip"
    p = put(str(tmp_path / "raw"), name, {"PTP.txt": ptp_txt("20261001")})
    res, _ = run([acq._classify(p, name)], tmp_path / "raw")
    prov = acq.acquisition_provenance(_LogSpark(acq.results_frame(res)))
    t = "medicaid_ncci_edit_practitioner_ptp_q4_2026"
    assert prov[t]["src_sha256"] == acq.sha256_file(p) and prov[t]["quarter"] == "2026q4"
    assert prov[t]["service"] == "practitioner" and prov[t]["src_member"] == "PTP.txt" and prov[t]["rows_loaded"] == 2


def test_quarter_end():
    from datetime import date
    assert acq.quarter_end(2026, 4) == date(2026, 12, 31) and acq.quarter_end(2026, 1) == date(2026, 3, 31)
    assert acq.quarter_end(2024, 1) == date(2024, 3, 31) and acq.quarter_end(2025, 3) == date(2025, 9, 30)
