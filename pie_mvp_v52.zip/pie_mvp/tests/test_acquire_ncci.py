"""Offline tests for acquire_ncci: discovery, retry policy, parsing, fail-loud checks, and
compatibility with the existing ingest (parsed frame -> ptp_rules / mue_history -> Rule)."""
import io
import os
import sys
import zipfile
from datetime import date

import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import acquire_ncci as acq  # noqa: E402
import ingest_ncci_tables as ing  # noqa: E402

# The 14 zip links on the live CMS page, 2026-09-28 (note the NON-uniform Q3 slugs).
LIVE_LINKS = """
<a href="/files/zip/medicaid-ncci-2026-q4-ptp-edits-practitioner-services.zip">2026_Q4_NCCI_PTP_Edits - Practitioner Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q4-ptp-edits-outpatient-hospital-services.zip">2026_Q4_NCCI_PTP_Edits - Outpatient Hospital Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q4-ptp-edits-durable-medical-equipment-services.zip">2026_Q4_NCCI_PTP_Edits - Durable Medical Equipment Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q4-mue-edits-practitioner-services.zip">2026_Q4_NCCI_MUE_Edits - Practitioner Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q4-mue-edits-outpatient-hospital-services.zip">2026_Q4_NCCI_MUE_Edits - Outpatient Hospital Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q4-mue-edits-durable-medical-equipment-services.zip">2026_Q4_NCCI_MUE_Edits - Durable Medical Equipment Services (ZIP)</a>
<a class="x" href="https://www.cms.gov/files/zip/medicaid-ncci-2026-q3-ptp-edits-practitioner-services.zip"><span>2026_Q3_NCCI_PTP_Edits - Practitioner Services</span> (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q3-ptp-edits-hospital-outpatient-services.zip">2026_Q3_NCCI_PTP_Edits - Outpatient Hospital Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q3-ptp-edits-durable-medical-equipment.zip">2026_Q3_NCCI_PTP_Edits - Durable Medical Equipment Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q3-mue-edits-practitioner-services.zip">2026_Q3_NCCI_MUE_Edits - Practitioner Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q3-mue-edits-outpatient-hospital-services.zip">2026_Q3_NCCI_MUE_Edits - Outpatient Hospital Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q3-mue-edits-durable-medical-equipment-services.zip">2026_Q3_NCCI_MUE_Edits - Durable Medical Equipment Services (ZIP)</a>
<a href="/files/zip/medicaid-ncci-change-report-effective-10012026.zip">Medicaid NCCI Change Report (ZIP)</a>
<a href="/files/zip/medicaid-ncci-2026-q3-change-report-effective-07012026.zip">Medicaid NCCI Change Report (ZIP)</a>
<a href="/files/document/manual.pdf">Policy manual</a>
<a href="/files/zip/some-new-thing.zip">Something CMS adds later</a>
"""

PTP_TXT = (
    "CPT codes, descriptions and other data only are copyright 2025 American Medical Association.\n"
    "Medicaid NCCI PTP Edits - Practitioner Services - Effective 10/01/2026\n"
    "\n"
    "Quarter Begin Date\tCategory\tColumn One\tColumn Two\tEffective Date\tDeletion Date\tModifier Indicator\tPTP Edit Rationale\n"
    "20261001\tPractitioner\t11042\t97597\t20100101\t*\t1\tMisuse of column two code with column one code\n"
    "20261001\tPractitioner\t0001F\t99213\t20200101\t20251231\t0\tMutually exclusive procedures\n"
    "20261001\tPractitioner\t36415\t36416\t19960101\t*\t9\tDeleted edit\n"
    "\n"
)

MUE_TXT = (
    "Medicaid NCCI MUE Edits - Practitioner Services\n"
    "Quarter Begin Date\tCategory\tHCPCS/CPT Code\tPractitioner Services MUE Values\tMUE Rationale\n"
    "20261001\tPractitioner\t98960\t4\tClinical: Data\n"
    "20261001\tPractitioner\tJ3490\t1\tNature of Service/Procedure\n"
)


def _zip(tmp_path, name, members: dict) -> str:
    p = tmp_path / name
    with zipfile.ZipFile(p, "w") as z:
        for n, data in members.items():
            z.writestr(n, data)
    return str(p)


def _xlsx(rows) -> bytes:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    for r in rows:
        ws.append(r)
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


# ------------------------------------------------------------------ discovery
def test_discovery_classifies_all_live_links_despite_inconsistent_slugs():
    links = acq.discover_links(LIVE_LINKS)
    assert len(links) == 15                                   # 14 zips + 1 unknown; the pdf is ignored
    edits = [l for l in links if l.kind == "edits"]
    assert len(edits) == 12
    assert {(l.label, l.edit, l.service) for l in edits} == {
        (q, e, s) for q in ("2026q3", "2026q4") for e in ("ptp", "mue") for s in ("practitioner", "outpatient", "dme")}
    assert all(l.url.startswith("https://www.cms.gov/files/zip/") for l in links)
    crs = [l for l in links if l.kind == "change_report"]
    assert {l.label for l in crs} == {"2026q3", "2026q4"}     # q4 one has no "q" token, read from effective date
    assert [l.url.rsplit("/", 1)[1] for l in links if l.kind == "unknown"] == ["some-new-thing.zip"]
    assert acq.check_quarter_complete(links) == {}


def test_table_names_match_ingest_discovery_regex():
    for l in acq.discover_links(LIVE_LINKS):
        if l.kind == "edits":
            m = ing._TABLE_RE.match(l.table)
            assert m and m.group("service") == l.service and m.group("edit") == l.edit


def test_incomplete_quarter_is_reported():
    links = [l for l in acq.discover_links(LIVE_LINKS) if not (l.label == "2026q4" and l.service == "dme")]
    assert acq.check_quarter_complete(links) == {"2026q4": ["mue/dme", "ptp/dme"]}


# ----------------------------------------------------------------- retry policy
class _Resp:
    def __init__(self, code, content=b"PK..."):
        self.status_code, self.content = code, content


class _Sess:
    def __init__(self, seq):
        self.seq, self.calls = list(seq), 0

    def get(self, url, timeout=None):
        self.calls += 1
        x = self.seq.pop(0)
        if isinstance(x, Exception):
            raise x
        return _Resp(x)


def test_retries_transient_then_succeeds():
    s = _Sess([503, ConnectionError("reset"), 200])
    assert acq._get(s, "u", sleep=lambda _: None).status_code == 200
    assert s.calls == 3


def test_does_not_retry_403_or_404():
    for code in (403, 404):
        s = _Sess([code, 200])
        with pytest.raises(acq.DownloadError, match=str(code)):
            acq._get(s, "u", sleep=lambda _: None)
        assert s.calls == 1


def test_retries_are_bounded():
    s = _Sess([503] * 10)
    with pytest.raises(acq.DownloadError, match="after 4 attempts"):
        acq._get(s, "u", attempts=4, sleep=lambda _: None)
    assert s.calls == 4


def test_html_page_instead_of_zip_is_refused_and_not_archived(tmp_path):
    link = acq.discover_links(LIVE_LINKS)[0]
    s = _Sess([200])
    s.get = lambda url, timeout=None: _Resp(200, b"<html>Access Denied</html>")
    with pytest.raises(acq.DownloadError, match="did not return a zip"):
        acq.download(link, str(tmp_path), s)
    assert not os.path.exists(acq.archive_path(str(tmp_path), link))


def test_download_is_idempotent(tmp_path):
    link = acq.discover_links(LIVE_LINKS)[0]
    s = _Sess([200])
    s.get = lambda url, timeout=None: _Resp(200, b"PK\x03\x04fake")
    first = acq.download(link, str(tmp_path), s)
    s.get = lambda url, timeout=None: (_ for _ in ()).throw(AssertionError("refetched"))
    second = acq.download(link, str(tmp_path), s)
    assert first["status"] == "downloaded" and second["status"] == "archived"
    assert first["sha256"] == second["sha256"]


# -------------------------------------------------------------------- parsing
def test_ptp_text_with_preamble(tmp_path):
    z = _zip(tmp_path, "p.zip", {"PTP.txt": PTP_TXT, "PTP.xlsx": _xlsx([["x"]])})
    df, st = acq.parse_zip(z, "ptp", (2026, 4))
    assert st["format"] == "txt" and len(df) == 3
    assert df.loc[0, "Col1"] == "11042" and pd.isna(df.loc[0, "DelDt"])     # '*' -> NULL
    assert df.loc[1, "DelDt"] == 20251231 and df.loc[1, "Col1"] == "0001F"
    assert list(df["ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable"]) == ["1", "0", "9"]


def test_ptp_split_excel_with_two_row_header_and_numeric_codes(tmp_path):
    hdr1 = ["Quarter Begin Date", "Category", "Column 1", "Column 2", "Effective", "Deletion", "Modifier", "PTP Edit Rationale"]
    hdr2 = ["", "", "", "", "Date", "Date *=no data", "0=not allowed 1=allowed 9=not applicable", ""]
    wb1 = _xlsx([["Medicaid NCCI PTP"], hdr1, hdr2,
                 [20261001, "Practitioner", 1996, 64450, 20150101, "*", 1, "Anesthesia"]])
    wb2 = _xlsx([hdr1, hdr2, [20261001, "Practitioner", "99213", "G0463", "10/1/2024", "", 0, "x"]])
    z = _zip(tmp_path, "p.zip", {"a/PTP_part1.xlsx": wb1, "a/PTP_part2.xlsx": wb2})
    df, st = acq.parse_zip(z, "ptp", (2026, 4))
    assert st["format"] == "xlsx" and len(df) == 2
    assert df.loc[0, "Col1"] == "01996"                          # Excel dropped the leading zero
    assert df.loc[1, "EffDt"] == 20241001


def test_mue_text(tmp_path):
    df, _ = acq.parse_zip(_zip(tmp_path, "m.zip", {"MUE.txt": MUE_TXT}), "mue", (2026, 4))
    assert list(df["HCPCS_CPT_Code"]) == ["98960", "J3490"] and list(df["MUE_Values"]) == [4, 1]


@pytest.mark.parametrize("bad, match", [
    (PTP_TXT.replace("\t1\tMisuse", "\tX\tMisuse"), "unparseable"),              # modifier indicator
    (PTP_TXT.replace("20100101", "2010-13-45"), "unparseable"),                   # effective date
    (PTP_TXT.replace("Modifier Indicator", "Mod Ind"), "no header row"),          # required column missing
    (PTP_TXT.replace("20261001", "20260701"), "Quarter Begin Date"),              # file is not the linked quarter
])
def test_ptp_fails_loudly(tmp_path, bad, match):
    with pytest.raises(acq.ParseError, match=match):
        acq.parse_zip(_zip(tmp_path, "p.zip", {"PTP.txt": bad}), "ptp", (2026, 4))


def test_mue_non_numeric_value_fails_instead_of_dropping(tmp_path):
    with pytest.raises(acq.ParseError, match="MUE_Values"):
        acq.parse_zip(_zip(tmp_path, "m.zip", {"MUE.txt": MUE_TXT.replace("\t4\t", "\tN/A\t")}), "mue")


def test_misread_layout_fails(tmp_path):
    body = "\n".join(f"20261001\tPractitioner\tNOTE {i}\tx\t20100101\t*\t1\tr" for i in range(60))
    txt = PTP_TXT.split("\n\n")[0] + "\n" + PTP_TXT.split("\n")[3] + "\n" + body
    with pytest.raises(acq.ParseError, match="not a 5-char"):
        acq.parse_zip(_zip(tmp_path, "p.zip", {"PTP.txt": txt}), "ptp")


def test_cross_check_detects_row_count_mismatch(tmp_path):
    hdr = PTP_TXT.split("\n")[3].split("\t")
    wb = _xlsx([hdr, [20261001, "Practitioner", "11042", "97597", 20100101, "*", 1, "r"]])
    with pytest.raises(acq.ParseError, match="Excel has 1"):
        acq.parse_zip(_zip(tmp_path, "p.zip", {"PTP.txt": PTP_TXT, "PTP.xlsx": wb}), "ptp", cross_check_xlsx=True)


# ------------------------------------------------ compatibility with the ingest
def _meta(edit, service="practitioner", y=2026, q=4):
    t = acq.TABLE_TEMPLATE.format(service=service, edit=edit, quarter=q, year=y)
    return {"table": t, "fqn": f"main.sedo.{t}", "service": service, "edit_type": edit, "quarter": q,
            "year": y, "label": f"{y}Q{q}", "starts": f"{y}-{ing.QUARTER_START[q]}"}


def _with_provenance(df):
    df = df.copy()
    for c in acq.PROVENANCE_COLUMNS + ["src_member"]:
        df[c] = "x"
    return df


def test_parsed_ptp_flows_through_existing_ingest(tmp_path):
    df, _ = acq.parse_zip(_zip(tmp_path, "p.zip", {"PTP.txt": PTP_TXT}), "ptp", (2026, 4))
    rules = ing.ptp_rules(_with_provenance(df), _meta("ptp"))
    assert len(rules) == 2                                          # indicator 9 (deleted) skipped by ingest
    r0 = [r for r in rules if r.predicate["code_a"] == "11042"][0]
    assert r0.predicate["code_b"] == "97597" and r0.predicate["modifier_indicator"] == "1"
    assert r0.effective_date == "2010-01-01" and r0.end_date is None
    r1 = [r for r in rules if r.predicate["code_a"] == "0001F"][0]
    assert r1.end_date == "2025-12-31"


def test_parsed_mue_flows_through_existing_ingest(tmp_path):
    q3 = MUE_TXT.replace("20261001", "20260701")
    frames = []
    for (y, q), txt in (((2026, 3), q3), ((2026, 4), MUE_TXT.replace("\t4\t", "\t6\t"))):
        df, _ = acq.parse_zip(_zip(tmp_path, f"m{q}.zip", {"MUE.txt": txt}), "mue", (y, q))
        frames.append((_meta("mue", y=y, q=q), _with_provenance(df)))
    rules = ing.mue_history(frames)
    runs = sorted((r.predicate["threshold"], r.effective_date, r.end_date)
                  for r in rules if r.predicate["code"] == "98960")
    assert runs == [(4, "2026-07-01", "2026-09-30"), (6, "2026-10-01", None)]


def test_provenance_columns_do_not_shadow_ingest_columns():
    ptp_cols = list(acq.PTP_COLUMNS) + acq.PROVENANCE_COLUMNS + ["src_member"]
    mue_cols = [c for c in acq.MUE_COLUMNS if c != "MUE_Adjudication_Indicator"] + acq.PROVENANCE_COLUMNS + ["src_member"]
    f = ing._find_col
    assert f(ptp_cols, "column1", "col1") == "Col1" and f(ptp_cols, "column2", "col2") == "Col2"
    assert f(ptp_cols, "effective date", "effdt") == "EffDt" and f(ptp_cols, "deletion date", "deldt") == "DelDt"
    assert f(ptp_cols, "ptp edit rationale", "edit rationale", "rationale") == "PTP_Edit_Rationale"
    assert f(mue_cols, "hcpcs/cpt code", "hcpcs cpt code", "procedure code", "code") == "HCPCS_CPT_Code"
    assert f(mue_cols, "mue value", "mue values") == "MUE_Values"
    assert f(mue_cols, "mue adjudication indicator", "adjudication indicator", "mai") is None


# -------------------------------------------------------------- orchestration
def test_acquire_drop_zone_without_spark(tmp_path):
    q = tmp_path / "raw" / "2026q4"
    q.mkdir(parents=True)
    _zip(q, "medicaid-ncci-2026-q4-ptp-edits-practitioner-services.zip", {"PTP.txt": PTP_TXT})
    _zip(q, "medicaid-ncci-2026-q4-mue-edits-practitioner-services.zip", {"MUE.txt": MUE_TXT.replace("\t4\t", "\tbad\t")})
    links = acq.links_from_drop_zone(str(tmp_path / "raw"))
    res = {r.edit: r for r in acq.acquire(None, links, str(tmp_path / "raw"), "main", "sedo",
                                          download_files=False, prev_counts={"ptp/practitioner": 100},
                                          log=lambda *_: None)}
    assert res["ptp"].status == "loaded" and res["ptp"].rows == 3 and "fell 100 -> 3" in res["ptp"].warning
    assert res["mue"].status == "failed" and "MUE_Values" in res["mue"].error      # one failure does not stop the rest


def test_missing_quarters():
    assert acq.missing_quarters([(2025, 3), (2025, 4), (2026, 2)], date(2026, 9, 28)) == ["2026Q1", "2026Q3"]
    assert acq.current_quarter(date(2026, 10, 1)) == (2026, 4)
