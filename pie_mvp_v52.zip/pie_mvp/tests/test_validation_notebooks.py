"""Validation notebooks v01 / v03 (2026-10-04, external review of the measurement). They run only on Databricks and in
the Spark e2e, so these source-level checks pin, offline, the decisions the review asked for: recall on REAL rules found,
the engine's own precision before review, a DROPPED sheet, pass marks on the lower 95% bound, a routing bar that reads
the provider types actually on the claims, and a corpus bar that states its scope. The arithmetic behind them is tested
in tests/test_quality.py; v05 (the A/B) runs end to end in tests/test_extraction_v2.py. Since critic M51 (2026-10-04)
05, v01, v03 and v05 also RUN from source against an in-memory catalog in tests/test_m51_measurement.py.
Run: cd pie_mvp && python -m pytest tests -q
"""
import ast
import os

HERE = os.path.dirname(__file__)
PKG = os.path.dirname(HERE)


def _src(name):
    return open(os.path.join(PKG, "notebooks", "validation", name)).read()


def _consts(src, *names):
    """Module-level literal assignments of a notebook (column lists, parameters), read without running it."""
    out = {}
    for node in ast.parse(src).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) \
                and node.targets[0].id in names:
            out[node.targets[0].id] = ast.literal_eval(node.value)
    return out


def test_changed_validation_notebooks_compile_and_keep_the_databricks_format():
    for nb in ("v01_extraction_scoring.py", "v03_pipeline_health.py", "v05_extraction_regression.py"):
        src = _src(nb)
        compile(src, nb, "exec")
        assert src.startswith("# Databricks notebook source\n# MAGIC %md"), nb
        assert "\n# COMMAND ----------\n" in src and "PKB_PACKAGE_DIR" in src, nb
        assert "write_table" not in src or nb == "v01_extraction_scoring.py", nb      # v03 / v05 stay read-only


def test_v01_recall_sheet_scores_real_rules_found_and_a_dropped_sheet_is_exported():
    src = _src("v01_extraction_scoring.py")
    c = _consts(src, "SEC_SCORE_COLS", "DROP_COLS", "DROP_SCORE_COLS", "N_DROPPED_PER_STRATUM", "STATUSES", "RULE_COLS",
                "EXEC_PRECISION_TARGET", "RECALL_TARGET", "FIDELITY_TARGET")
    assert c["SEC_SCORE_COLS"] == ["real_rules_found", "missed_rules", "scorer"]
    assert c["DROP_SCORE_COLS"] == ["is_real_rule", "notes", "scorer"] and c["N_DROPPED_PER_STRATUM"] == 10
    assert {"chapter", "drop_reason", "drop_class", "verbatim_quote", "section_text", "rules_kept_text"} <= set(c["DROP_COLS"])
    assert {"predicate_type", "reviewer_fix"} <= set(c["RULE_COLS"])
    assert (c["EXEC_PRECISION_TARGET"], c["RECALL_TARGET"], c["FIDELITY_TARGET"]) == (0.95, 0.90, 0.95)
    # the sheets, the sample and the ingest
    assert '"DROPPED": dropped[DROP_COLS + DROP_SCORE_COLS]' in src and "policy_extraction_dropped" in src
    assert 'quality.stratified_sample(dp, ["chapter", "drop_class"], N_DROPPED_PER_STRATUM' in src
    assert "quality.current_run_rows(" in src and "quality.drop_reason_class(" in src
    assert "quality.extraction_metrics(rs, ss, ds)" in src
    assert 'sheet="RULES"' in src and 'sheet="RECALL"' in src and 'sheet="DROPPED"' in src
    # the README tells the scorer what real_rules_found means and how the DROPPED sheet is scored
    assert "real_rules_found: how many of the rules in rules_extracted_text are REAL, DISTINCT rules" in src
    assert "Fill both on a row, or neither" in src and "DROPPED sheet - one candidate" in src
    # the e2e substitutes these exact parameter lines
    assert "EXPORT          = True" in src and "SCORED_WORKBOOK = None" in src


def test_v01_population_is_the_engine_before_review_rejected_drafts_included():
    src = _src("v01_extraction_scoring.py")
    assert _consts(src, "STATUSES")["STATUSES"] is None
    assert "NOT IN ('rejected'" not in src and "review_status NOT IN" not in src     # rejected drafts are not dropped
    # critic M51-1: the default population is the LATEST successful run's own drafts (policy_extraction_drafts, written by
    # 05), not state_rules (which keeps decided rows of older runs); STATUSES samples state_rules as before
    assert 'T_DRAFTS = f"{KB}.policy_extraction_drafts"' in src
    assert "quality.run_population(DRAFTS, CUR, LATEST, state, LOG)" in src and "quality.latest_runs(LOG, CUR)" in src
    assert "sr, rep = quality.scoring_population(state, CUR, STATUSES)" in src
    assert "quality.scoring_population(state, CUR)\n" not in src                     # the old default population
    # critic M51-3: every sheet is stamped; the ingest keeps every metric column (population, corpus_version, unscored)
    c = _consts(src, "RULE_COLS", "SEC_COLS", "DROP_COLS")
    assert all({"population", "corpus_version"} <= set(c[k]) for k in c) and "rule_population" in c["RULE_COLS"]
    assert "POPULATION = quality.sample_population(STATUSES)" in src
    assert "CORPUS_VERSION = policy_docs.corpus_version(CUR)" in src
    assert 'metrics[quality.METRIC_COLUMNS[:-1] + ["sample_id", "computed_at", "notes"]]' in src


def test_v03_pass_marks_on_the_lower_bound_and_filter_loss_shown():
    src = _src("v03_pipeline_health.py")
    c = _consts(src, "EXEC_PRECISION_TARGET", "RECALL_TARGET", "FIDELITY_TARGET")
    assert (c["EXEC_PRECISION_TARGET"], c["RECALL_TARGET"], c["FIDELITY_TARGET"]) == (0.95, 0.90, 0.95)
    assert 'quality.lower_bound_bar(metric("executable_rule_precision", "all"), EXEC_PRECISION_TARGET' in src
    assert "quality.lower_bound_bar(rc, RECALL_TARGET" in src and 'rc = metric("extraction_recall", "all")' in src
    assert 'quality.lower_bound_bar(metric("extraction_fidelity", "all"), FIDELITY_TARGET' in src
    assert 'bar(f"Extraction fidelity >= {FIDELITY_TARGET} (lower 95% bound)"' in src      # the e2e reads this label
    assert 'per_chapter("extraction_recall")' in src and 'per_chapter("executable_rule_precision")' in src
    # filter loss: shown, never judged (INFO), and its label does not read as a precision / recall / fidelity bar
    assert 'fl = metric("extraction_filter_loss", "all")' in src
    label = 'info("Extraction filter loss: dropped candidates that were real rules (no pass mark)"'
    assert label in src and not any(w in label.lower() for w in ("precision", "recall", "fidelity"))
    assert '"status": "INFO"' in src


def test_v03_routing_bar_reads_the_provider_types_on_the_claims():
    src = _src("v03_pipeline_health.py")
    assert 'mode"] == "provider_type"' not in src                        # the bug: always "claim form only"
    assert "ncci_routing.uses_table()" in src and "ncci_routing.unsigned_observed(OBSERVED_TYPES)" in src
    assert "ncci_routing.routed_sql(config.CLAIMS_TABLE, config.CLAIM_COLS" in src
    # critic M51-9: 08's own reading - the codes observed_types_sql returns (billing types only when routing by them)
    # and run_guard's routing kind; never both types in every mode
    assert 'ncci_routing.observed_types_sql(f"{_src} rc", ncci_routing.PIE_FORM)' in src
    assert "explode(array(" not in src
    assert "ROUTING_KIND = run_guard.ncci_routing_kind(OBSERVED_TYPES)" in src
    assert "quality.routing_bar(ncci_routing.uses_table(), _rt, OBSERVED_TYPES, UNSIGNED_TYPES, ROUTING_KIND)" in src


def test_v03_corpus_and_signoff_bars():
    src = _src("v03_pipeline_health.py")
    # one recipe for the current corpus, shared with v01's stamp (critic M51-3), computed before any bar is judged
    assert "CORPUS_VERSION = policy_docs.corpus_version(INV_CUR)" in src and 'getattr(config, "CORPUS_PENDING", {})' in src
    assert "quality.current_doc_hash(" in src and src.index("CORPUS_VERSION = ") < src.index("def metric(name, scope)")
    # ... and the current latest run of each chapter (follow-up: a sample of an older run of the same corpus is stale)
    assert "quality.metric_for_bar(QM_ALL, name, scope, CORPUS_VERSION, LATEST_RUNS)" in src
    assert "LATEST_RUNS = quality.latest_runs(" in src and src.index("LATEST_RUNS = ") < src.index("def metric(name, scope)")
    assert "quality.run_completeness(r)" in src and _consts(src, "MAX_UNSCORED_SHARE")["MAX_UNSCORED_SHARE"] == 0.10
    assert 'bar(f"Corpus frozen and complete for its stated scope ({quality.CORPUS_SCOPE})"' in src
    assert "AHCCCS policy" not in src and "every AHCCCS FFS manual chapter ingested" not in src
    assert "quality.signoff_bar(compiled_state)" in src and "Every executable state rule signed by a named reviewer" in src
    assert "where(\"compiled AND (origin IS NULL OR origin <> 'ncci')\")" in src
