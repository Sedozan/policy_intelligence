"""Extraction defects D1 / D2 / D2b / D11, each pinned by a test that failed on the
code before the fix. Offline, no Spark, no model.
Run: cd pie_mvp && python -m pytest tests -q
"""
import copy
import json
import os
import sys

import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import extract_io
import extract_rules as ex

PKG = os.path.dirname(HERE)
INV = {"chapter": "19", "title": "T", "url": "u", "doc_hash": "h19", "revision_date": None}


class _Raw(ex.Backend):
    """A model backend that returns a fixed raw string (or raises)."""
    name, model = "FAKE", "fake"

    def __init__(self, raw=None, exc=None):
        self.raw, self.exc, self.calls = raw, exc, 0

    def complete(self, s, u):
        self.calls += 1
        if self.exc:
            raise self.exc
        return self.raw


class _Fixed(ex.Backend):
    name, model = "FAKE", "fake"

    def __init__(self, rules):
        self.rules = rules

    def complete(self, s, u):
        return json.dumps({"rules": copy.deepcopy(self.rules), "no_rule_reason": None})


def _sec(text, sid="s1", candidate=True, text_hash=None):
    return {"text": text, "text_hash": text_hash or f"th-{sid}", "section_id": sid, "heading": f"H {sid}",
            "page_start": 3, "page_end": 4, "has_rule_signal": candidate, "rule_signal": 1 if candidate else 0}


def _user(text):
    return ex.USER_TEMPLATE.format(chapter="19", title="T", heading="H", page_start=1, page_end=1,
                                   revision="r", text=text)


RULE_98960 = {"statement": "98960 max 4/day", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
              "codes": ["98960"], "verbatim_quote": "A maximum of four units per day applies to 98960.",
              "confidence": 0.8}


# ===================================================================== D1
def test_d1_fenced_model_reply_is_parsed_not_silently_empty():
    """A ```json fenced reply used to become 'no model rules' and the section was cached."""
    fenced = "```json\n" + json.dumps({"rules": [RULE_98960], "no_rule_reason": None}) + "\n```"
    hy = ex.HybridBackend(_Raw(fenced), _Fixed([]))
    obj = json.loads(hy.complete(ex.SYSTEM_PROMPT, _user("x")))
    assert [r["source"] for r in obj["rules"]] == ["model"]
    assert obj["rules"][0]["predicate"]["code"] == "98960"
    assert ex.model_health(hy)["model_unparseable"] == 0


def test_d1_unparseable_model_half_is_retryable_never_cached():
    text = "A maximum of four units per day applies to 98960."
    # require_model=True (default): an unparseable model half is a failure, not "no rules"
    hy = ex.HybridBackend(_Raw("Sorry, I can't help with that."), ex.StubBackend())
    cache = {}
    drafts, _, st = ex.extract_chapter([_sec(text)], INV, hy, "r", cache=cache, log_fn=lambda x: None)
    assert cache == {} and drafts == []
    assert st["unparseable"] == 1 and st["retryable_sections"][0]["why"].startswith("unparseable")
    mh = ex.model_health(hy)
    assert mh["model_unparseable"] == 1 and mh["model_failures"] == 1 and "unparseable" in mh["last_model_error"]
    # require_model=False: degraded patterns-only output, flagged and still not cached
    hy2 = ex.HybridBackend(_Raw("no json here"), ex.StubBackend(), require_model=False)
    cache = {}
    drafts, _, st = ex.extract_chapter([_sec(text)], INV, hy2, "r", cache=cache, log_fn=lambda x: None)
    assert cache == {} and st["degraded_patterns_only"] == 1 and len(drafts) == 1
    assert ex.model_health(hy2)["model_unparseable"] == 1


def test_d1_pattern_half_still_parses_strictly():
    """The pattern half is our own code: bad JSON there is a bug and must not read as 'no rules'."""
    hy = ex.HybridBackend(_Fixed([RULE_98960]), _Raw("not json"))
    with pytest.raises(ValueError):
        hy.complete(ex.SYSTEM_PROMPT, _user("x"))


# ===================================================================== D2
def test_d2a_short_quote_does_not_evidence_a_rule():
    sec = _sec("Do not bill 11975 unless prior authorization is obtained.")
    lead = {"statement": "PA", "predicate": {"type": "not_checkable", "reason": "requires_medical_record"},
            "codes": [], "verbatim_quote": "is obtained", "confidence": 0.9}
    g = ex.ground(lead, sec)
    assert not g["keep"] and g["drop_reason"] == "quote too short to evidence the rule"
    # a short quote that names every predicate code is still acceptable evidence
    short_coded = {"statement": "s", "predicate": {"type": "code_not_covered", "code": "11975"},
                   "codes": ["11975"], "verbatim_quote": "Do not bill 11975", "confidence": 0.9}
    assert ex.ground(short_coded, sec)["keep"]


def test_d2b_codes_far_from_quote_are_flagged_and_capped():
    sec = _sec("Codes covered by this section: 98960 and 98961. Services must be delivered by a registered "
               "worker. Claims are submitted on the CMS 1500 form. Providers must keep records for six years. "
               "A maximum of four units per day applies to these services.")
    pr = {"statement": "98960 max 4/day", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
          "codes": ["98960"], "verbatim_quote": "A maximum of four units per day applies to these services.",
          "confidence": 0.9}
    g = ex.ground(pr, sec)
    assert g["keep"] and g["codes_found"] == "all"            # section-level gate unchanged (recall)
    assert g["codes_in_quote_window"] is False
    row = ex.to_draft_row(pr, g, sec, INV, ex.StubBackend(), "r")
    assert row["extraction_confidence"] <= 0.5
    assert "codes not stated near the quoted sentence" in row["ambiguity_note"]
    # a code in the NEIGHBOURING sentence is inside the window
    sec2 = _sec("Codes 98960 and 98961 are CHW codes. A maximum of four units per day applies to these services.")
    assert ex.ground(pr, sec2)["codes_in_quote_window"] is True


def test_d2c_quote_that_drops_an_unless_clause_is_not_a_clean_rule():
    sec = _sec("Do not bill 11975 unless prior authorization is obtained.")
    pr = {"statement": "11975 not covered", "predicate": {"type": "code_not_covered", "code": "11975"},
          "codes": ["11975"], "verbatim_quote": "Do not bill 11975", "confidence": 0.9}
    g = ex.ground(pr, sec)
    assert g["keep"] and g["quote_truncates_condition"] is True
    row = ex.to_draft_row(pr, g, sec, INV, _Fixed([]), "r")
    assert row["ambiguity_flag"] is True and row["extraction_confidence"] <= 0.5
    assert ("source sentence carries a condition the quote omits: "
            "Do not bill 11975 unless prior authorization is obtained.") in row["ambiguity_note"]
    # the full sentence as the quote is not truncated
    full = dict(pr, verbatim_quote="Do not bill 11975 unless prior authorization is obtained.")
    assert ex.ground(full, sec)["quote_truncates_condition"] is False


def test_d2d_verbatim_quote_is_the_source_text_not_the_model_text():
    src = "A maximum of four units per day applies to code 98960."
    sec = _sec("Community health workers are covered. " + src)
    # fuzzy: model paraphrased one non-meaning word
    fuzzy = {"statement": "s", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
             "codes": ["98960"], "verbatim_quote": "A maximum of four units per day is applied to code 98960.",
             "confidence": 0.8}
    g = ex.ground(fuzzy, sec)
    assert g["keep"] and g["quote_found"] == "fuzzy" and g["source_quote"] == src
    row = ex.to_draft_row(fuzzy, g, sec, INV, _Fixed([]), "r")
    assert row["verbatim_quote"] == src and row["model_quote"] == fuzzy["verbatim_quote"]
    assert f'Verbatim: "{src}"' in row["notes"]
    # exact (after normalisation): original casing from the source, no model_quote
    exact = dict(fuzzy, verbatim_quote="a MAXIMUM of four units  per day applies to code 98960")
    g = ex.ground(exact, sec)
    row = ex.to_draft_row(exact, g, sec, INV, _Fixed([]), "r")
    assert g["quote_found"] == "exact"
    assert row["verbatim_quote"] == src and row["model_quote"] is None


def test_d2e_dropped_word_number_is_drift_not_fuzzy():
    sec = _sec("Providers may bill a maximum of four units per day for code 98960.")
    pr = {"statement": "s", "predicate": {"type": "max_units_per_day", "code": "98960", "threshold": 4},
          "codes": ["98960"], "verbatim_quote": "Providers may bill a maximum of units per day for code 98960.",
          "confidence": 0.8}
    g = ex.ground(pr, sec)
    assert not g["keep"] and g["quote_found"] == "drift"


def test_d2f_hybrid_merge_keeps_the_pattern_quote():
    pat = dict(RULE_98960, verbatim_quote="A maximum of four units per day applies to 98960.")
    mdl = dict(RULE_98960, verbatim_quote="Per the manual, a maximum of four units per day applies to 98960 "
                                          "for all community health worker services.")
    out = json.loads(ex.HybridBackend(_Fixed([mdl]), _Fixed([pat])).complete("", ""))["rules"]
    assert len(out) == 1 and out[0]["source"] == "pattern+model"
    assert out[0]["verbatim_quote"] == pat["verbatim_quote"] and out[0]["alt_quote"] == mdl["verbatim_quote"]
    # end to end: the corroborated rule still grounds (the longer model quote would not)
    sec = _sec("A maximum of four units per day applies to 98960.")
    hy = ex.HybridBackend(_Fixed([mdl]), _Fixed([pat]))
    drafts, dropped, _ = ex.extract_chapter([sec], INV, hy, "r", cache={}, log_fn=lambda x: None)
    assert len(drafts) == 1 and dropped == [] and drafts[0]["extraction_source"] == "pattern+model"


# ==================================================================== D2b
def test_d2b_extraction_source_is_recorded_for_every_backend():
    sec = _sec("A maximum of four units per day applies to 98960.")
    pr = dict(RULE_98960)
    g = ex.ground(pr, sec)
    assert ex.to_draft_row(pr, g, sec, INV, ex.StubBackend(), "r")["extraction_source"] == "pattern"
    row = ex.to_draft_row(pr, g, sec, INV, ex.HFLocalBackend(), "r")
    assert row["extraction_source"] == "model" and "Found by: model" in row["notes"]
    assert ex.to_draft_row(pr, g, sec, INV, ex.DBFMBackend("ep"), "r")["extraction_source"] == "model"
    hy_pr = dict(pr, source="pattern+model")
    assert ex.to_draft_row(hy_pr, g, sec, INV, ex.StubBackend(), "r")["extraction_source"] == "pattern+model"


def test_gpu_notebook_tallies_by_extraction_source_and_runs_one_chapter():
    src = open(os.path.join(PKG, "notebooks", "04_extract_chapters_gpu.py")).read()
    assert 'CHAPTERS_TO_RUN = ["19"]' in src and 'LLM_BACKEND     = "HYBRID"' in src
    assert 'd.get("extraction_source")' in src
    assert "outcomes=outcome_rows" in src and "outcome_rows=outcome_rows" in src
    per = open(os.path.join(PKG, "notebooks", "05_persist_extraction.py")).read()
    assert "policy_extraction_outcomes" in per and 'run["outcomes"]' in per


# ===================================================================== D11
def test_d11_every_section_gets_an_outcome_and_cache_keeps_the_reason():
    class _Scripted(ex.Backend):
        name, model = "SCRIPT", "s"

        def __init__(self): self.calls = 0

        def complete(self, s, u):
            self.calls += 1
            if "BOOM" in u:
                raise TimeoutError("endpoint")
            if "98960" in u:
                return json.dumps({"rules": [RULE_98960], "no_rule_reason": None})
            if "99999" in u:
                return json.dumps({"rules": [dict(RULE_98960, verbatim_quote="invented text that is nowhere")],
                                   "no_rule_reason": None})
            return json.dumps({"rules": [], "no_rule_reason": "section describes enrollment only"})

    secs = [_sec("Narrative only.", "skip", candidate=False),
            _sec("Enrollment is handled by the plan.", "none"),
            _sec("A maximum of four units per day applies to 98960.", "rule"),
            _sec("Code 99999 text.", "drop"),
            _sec("BOOM", "fail")]
    # 150 non-candidates: the old 100-heading cap lost the tail
    secs += [_sec(f"Narrative {i}.", f"n{i}", candidate=False) for i in range(150)]
    b, cache, outcomes = _Scripted(), {}, []
    drafts, dropped, st = ex.extract_chapter(secs, INV, b, "r1", cache=cache, log_fn=lambda x: None,
                                             outcomes=outcomes)
    assert len(outcomes) == len(secs) and st["sections_skipped_noncandidate"] == 151
    by = {o["section_id"]: o for o in outcomes}
    assert by["skip"]["outcome"] == "skipped_prefilter" and by["n149"]["outcome"] == "skipped_prefilter"
    assert by["none"]["outcome"] == "no_rules" and by["none"]["reason"] == "section describes enrollment only"
    assert by["rule"]["outcome"] == "proposals" and by["rule"]["n_grounded"] == 1 and by["rule"]["n_dropped"] == 0
    assert by["drop"]["outcome"] == "proposals" and by["drop"]["n_dropped"] == 1
    assert by["fail"]["outcome"] == "failed_retryable" and by["fail"]["reason"].startswith("backend error")
    o = by["rule"]
    assert (o["chapter"], o["doc_hash"], o["run_id"], o["page_start"], o["page_end"], o["from_cache"]) == \
           ("19", "h19", "r1", 3, 4, False)
    assert set(o) >= {"heading", "n_proposals"}
    # a cache hit keeps the model's no-rule reason
    outcomes2 = []
    ex.extract_chapter(secs, INV, b, "r2", cache=cache, log_fn=lambda x: None, outcomes=outcomes2)
    by2 = {o["section_id"]: o for o in outcomes2}
    assert by2["none"]["from_cache"] is True and by2["none"]["reason"] == "section describes enrollment only"
    assert by2["rule"]["from_cache"] is True and by2["rule"]["n_grounded"] == 1
    assert by2["fail"]["from_cache"] is False                              # never cached, retried
    # dropped rows are traceable to chapter / codes / doc / pages
    d = dropped[0]
    assert (d["chapter"], d["doc_hash"], d["page_start"], d["page_end"]) == ("19", "h19", 3, 4)
    assert json.loads(d["codes"]) == ["98960"]


def test_d11_old_plain_list_cache_entries_still_read():
    sec = _sec("A maximum of four units per day applies to 98960.")
    b = ex.StubBackend()
    ck = ex.cache_key(sec, b)                          # C3-08: one helper builds the key everywhere
    assert ck == f"{sec['text_hash']}|{ex.PROMPT_VERSION}|{b.name}|{b.model}"   # STUB keys keep their shape
    cache = {ck: [dict(RULE_98960)], "other": []}
    outcomes = []
    drafts, _, st = ex.extract_chapter([sec], INV, b, "r", cache=cache, log_fn=lambda x: None, outcomes=outcomes)
    assert st["sections_from_cache"] == 1 and len(drafts) == 1
    assert outcomes[0]["from_cache"] is True and outcomes[0]["outcome"] == "proposals"


def test_d11_outcomes_file_round_trips(tmp_path):
    assert extract_io.RUN_FILES["outcomes"] == "outcomes.jsonl"
    run_dir = extract_io.new_run_dir(str(tmp_path), "r1")
    rows = [{"chapter": "19", "section_id": "s", "outcome": "no_rules", "reason": "x", "from_cache": False}]
    counts = extract_io.write_run(run_dir, inventory_rows=[], section_rows=[], log_rows=[], dropped_rows=[],
                                  change_rows=[], drafts=[], cache={}, manifest={"finished": True},
                                  outcome_rows=rows)
    assert counts["outcomes"] == 1 and extract_io.read_run(run_dir)["outcomes"] == rows


def test_daily_cap_accepts_code_set_and_ingest_requires_known_reason():
    from extract_rules import predicate_valid
    ok, _ = predicate_valid({"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4})
    assert ok
    ok, why = predicate_valid({"type": "max_units_per_line", "code_set": ["98960"], "threshold": 4})
    assert not ok and "missing code" in why          # the per-line compiler reads p["code"] only
    assert predicate_valid({"type": "not_checkable", "reason": "requires_provider_attribute"})[0]
    ok, why = predicate_valid({"type": "not_checkable", "reason": "requires_provider_attribute"}, strict_reason=True)
    assert not ok and "unknown not_checkable reason" in why
