"""
tests/test_sql_oracle.py - independent reference check of every compiled PIE query.

The ORACLE in this file was written from docs/QUERY_SEMANTICS.md sections 1-4 (version 2.6) and
reference/ncci_provider_type_routing.csv ONLY. It does not read, copy or call detector_gen's SQL builders,
ncci_routing.py, query_pack.py or the other Spark tests. detector_gen is used as a black box:
build_detectors / ncci_edit_tables / batch_ptp_sql / batch_mue_sql / create_snapshot produce the SQL, and the
SQL is run UNCHANGED on Spark 4 (ANSI on, the production engine). For many seeded random claim sets full of
hard cases the oracle computes the expected findings in pure Python and the test requires an exact match:
the multiset of findings per query plus severity, basis, observed / allowed / excess units, evidence lines,
Column One, paid_amt, paid_at_risk (to the cent), pa_present and period bounds.
Version 2.6 (2026-10-05, after the independent critic of v5.2; updated by a new agent from the v2.6 text alone):
state pairs and daily caps with scope member_servicing_billing_day (the same servicing AND billing provider id; a missing
id never matches / is not counted) - claims carry a billing provider id per claim, equal / other / padded / other case /
missing between lines; §3's daily-cap labels (verify_pa > verify_span > verify_modifier > the rule's own label) on every
max_units_per_day / max_units_per_dos rule, with daily-cap rows carrying the listed modifiers; provider_type_allowed with
role billing_or_rendering (a group billing type - config.GROUP_BILLING_PROVIDER_TYPES, spelled '1', ' 01 ', '01.0' ... -
is judged on the rendering type: allowed, not allowed, missing) and the group finding text; pair_scope and the new
billing_provider column compared. Readings A25-A29 (chosen before running); variants over
config.GROUP_BILLING_PROVIDER_TYPES and config.DAILY_CAP_VERIFY_MODIFIERS; hand-computed V26_* cases.
N4 (2026-10-05, the critic's re-check; §3 v2.6 as amended): the daily-cap labels read the group's PAYABLE lines only -
verify_span when ONE payable line alone has units > threshold, verify_modifier when a payable line carries a listed
modifier ("a cancelled line and its reversal net out of the sum and say nothing about the paid day"). A cancelled line,
any reversal row and a paid line with units <= 0 still count in the sum, the evidence and the dollars, never in these
two labels (A27 amended; verify_pa unchanged, A5). The generator builds the case on purpose
(sc_daily_cancelled_long_line: a cancelled LONG line with listed modifiers + its exact reversal + other payable lines
over the cap, plus controls); coverage counts every group whose label differs from the old counted-row reading; the
hand-computed V26 cases M10 and M16-M21 pin it.
Version 2.4 (2026-10-04): a line whose billing AND servicing types are both missing / not in the table takes NO edit
file by default (§1a step 3, config.NCCI_UNMAPPED_PROVIDER_TYPE = "none"); "form" stays covered by routing variants.
Version 2.3 (2026-10-03): a reversal cancels copies of one claim line in the §1 tie order (form, PA, servicing type,
billing type, billing provider id, date of birth) - the generator books lines twice on purpose instead of re-numbering
ties; the edit file never splits a pair finding (F-05 resolved in the spec); not-covered / provider-type findings carry
observed = line units, allowed = 0, excess = observed; provider_types entries are cleaned like the column ('8.0', 8,
' 8 ' -> 08) and a blank / non-alphanumeric entry makes the rule a lead; the text NONE / NAN / NULL (any case) is a
missing provider type in both columns and a missing entry (the generator writes 'None', 'nan', ' NULL ', 'NONE' ...).
Version 2.2 (2026-10-03): every claim row carries a BILLING provider type (BProv_Type) next to the servicing type;
the oracle routes each line to its NCCI edit file by §1a v2.2 (billing type picks the Table 2 row, then the
servicing type, then the claim form; the servicing type says whether a rendering practitioner is identified),
dentists (07) are practitioners, and provider_type_allowed rules (billing / servicing role) are in every round.

Run (Spark 4 venv):  cd pie_mvp && <spark-4 python> -m pytest -q tests/test_sql_oracle.py      (~4 min, 2 CPUs)
                     v2.6 + N4 (2026-10-05): 16 rounds / 80 claim sets / 22,009 claim rows, 788 queries, 2,610
                     findings (604 provider-type, 185 daily caps - 70 of them labelled otherwise than the pre-N4
                     counted-row reading would) + 112 signal rows, all equal; plus the hand-computed V26_* cases (pure
                     Python and through Spark). ~3x (PIE_ORACLE_ROUNDS=24 PIE_ORACLE_VARIANT_REPEATS=3, ~9.5 min), last
                     run before N4: 48 rounds / 240 claim sets / 62,358 rows, 2,356 queries, 7,011 findings (1,631
                     provider-type, 395 daily caps) + 297 signal rows, all equal.
Scale:               PIE_ORACLE_ROUNDS (default 8) rounds x PIE_ORACLE_SETS (default 5) claim sets per round
                     (default 40 seeded claim sets of 100-400 rows), plus PIE_ORACLE_VARIANT_REPEATS (default 1)
                     rounds per variant (6 variants of §1a's switches, 2 of v2.6's group types / daily-cap modifier
                     list). Every round has its own random rule
                     set; the claim sets of a round share one claims table but use disjoint members / claim ids, so
                     they cannot interact (every semantic is per member).
Optional:            PIE_ORACLE_REPORT=<file.json> writes counts, the v2.2 / v2.3 hard-case coverage
                     ("v23_coverage"), deviation impact and every mismatch; PIE_ORACLE_TMP=<dir> is where the
                     throw-away Spark warehouse goes (default: the system temp dir).
Without pyspark only the pure-Python oracle self-check runs.

ORACLE_READINGS lists the readings chosen where QUERY_SEMANTICS.md is silent or loose (A*: chosen before running;
S*: adopted after the SQL showed a different but defensible reading - reported as SPEC AMBIGUITY).
KNOWN_DEVIATIONS lists confirmed differences of the current SQL from the spec. The random comparison applies each
one as an exact transformation of the oracle's expectation (everything else stays strict) and counts its impact;
the xfail(strict=True) tests assert the spec behaviour. When one is fixed: the xfail test XPASSes (strict -> fails),
remove its marker AND remove the id from ACTIVE_DEVIATIONS. None active in v2.3 (F-05 of v2.2 was resolved in the
spec: the edit file never splits a pair finding).
"""
from __future__ import annotations

import calendar
import datetime as dt
import os
import random
import re
import shutil
import sys
import tempfile
from collections import Counter, defaultdict
from decimal import Decimal, ROUND_HALF_UP

import pytest

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

import config  # noqa: E402
import detector_gen as dg  # noqa: E402

D = dt.date
DAY = dt.timedelta(days=1)
C = config.CLAIM_COLS

# ===================================================================================== spec constants
# QUERY_SEMANTICS.md §2 "Code pair": NCCI-associated modifiers.
ANATOMIC = ({"E1", "E2", "E3", "E4", "FA", "TA", "LT", "RT", "LC", "LD", "RC", "LM", "RI"}
            | {f"F{i}" for i in range(1, 10)} | {f"T{i}" for i in range(1, 10)})
GENERAL_BYPASS = {"58", "78", "79", "27", "59", "91", "XE", "XS", "XP", "XU"}
EM_ONLY_BYPASS = {"24", "25", "57"}                       # only on a line whose code is an E&M code
ANATOMIC_OVERRIDE = {"58", "59", "78", "79", "XE", "XP", "XS", "XU"}
ROLLING_N = {"month": 30, "year": 365, "benefit_year": 365}  # §4

ORACLE_READINGS = {
    # chosen before running v1 (still not stated by the spec)
    "A1": "a blank procedure code (after trimming) is 'no procedure code' -> the row is dropped",
    "A5": "'a PA number on any line of the finding': pair = the code_b line + its evidence code_a lines; unit "
          "groups = every counted row of the group (= evidence); one-line findings = that line",
    "A7": "code_not_covered: paid_amt = paid_at_risk = the line's paid amount",
    "A8": "signal: rolling_paid = paid of every counted row in the window",
    "S06": "pair 'one finding per (rule, code_b line)': code_b rows that pair and share every column the finding shows "
           "(claim id, line number, member, servicing provider, date, form, paid) are ONE finding; pa_present / "
           "severity look at all of them and evidence is their union (v2 run, SQL's reading adopted; same in v1)",
    "S05": "signal (§4 'for each date with units'): every date with a counted row of the code(s) is a window end, even "
           "when its own units are missing (v2 run, SQL's reading adopted; A8 used only dates with non-NULL units)",
    "A9": "pair evidence = the code_a lines that form an UNBYPASSED pair with the code_b line",
    # chosen for v2 (2026-10-03) where version 2 is silent
    "A10": "evidence order 'by claim id then line NUMBER' puts missing values first (as the cancellation order does)",
    "A11": "provider type clean-up is literal: only a LONE digit is zero-padded and only a whole number WITH decimals is "
           "read as a number, so '008' and '8.5' stay as written (not in the table -> unmapped)",
    "A12": "an NCCI rule with no ncci_edition takes no line (build_detectors makes it a lead)",
    # chosen for v2.2 (2026-10-03) BEFORE running; A13 / A14 / A15 / A17 are spec text since v2.3 (kept as pointers)
    "A13": "STATED v2.3 (§1 tie order, §2 'differ only in ... provider types'): the snapshot keeps the cleaned billing "
           "provider type; rows that differ only in its spelling (' 2' / '2.0' / '02') are one row",
    "A14": "STATED v2.3 (§2 provider type allowed): KNOWN = present after the §1 clean-up; a code the routing table does "
           "not list ('ZZ', '008', '8.5', '00') is known and flagged when not in provider_types",
    "A15": "STATED v2.3: provider_type_allowed gives one finding per payable snapshot row; dollars as for Not covered",
    "A16": "provider_role absent / None / '' = billing (the default); the entries are cleaned like the column (STATED "
           "v2.3) - with A11 that keeps '008' as '008' while '008.0' is a whole number -> '08'",
    "A17": "STATED v2.3 (§2 code pair): code_b rows of one line that share (claim id, line number, member, servicing "
           "provider, date, claim form, paid) are ONE finding whatever their PA / units / modifiers / provider types / "
           "edit files; pa_present = any of them, evidence = the union of their code_a lines (F-05 resolved IN THE SPEC)",
    "A18": "§1a step 1 'the billing type code, when it is in the table' picks the row even when that row gives no file "
           "(not_applicable, or an optional row switched off): no fall-back to the servicing type in that case",
    # chosen for v2.3 (2026-10-03) BEFORE running, where version 2.3 is silent or loose
    "A19": "§1 cancellation tie order ('cleaned values, ascending, missing first'): strings compare by character code "
           "(binary, as Spark sorts strings: 'PA9' < 'pa1', '02' < '08' < '8.5' < 'C2' < 'ZZ'); a blank claim form is "
           "'' (a value, not missing: after a missing form, before 'A'); PA numbers / billing provider ids are compared "
           "trimmed but NOT upper-cased (§1 clean-up); dates of birth by date; claim id as text, line NUMBER numerically",
    "A20": "STATED v2.3 (§1 clean-up, §2 entries; owner 2026-10-03, settling S07/S08 of the previous run): the text NONE "
           "/ NAN / NULL (any case, after trimming spaces) is a MISSING provider type in BOTH columns - routing falls "
           "back as for a missing type, provider_type_allowed never flags it - and a missing entry (the rule is a "
           "lead); a float NaN entry is the text 'nan'. Entries and column are cleaned by the same function",
    "S08": "STATED v2.3 (kept as a pointer): an entry 'NONE' / 'NAN' / 'NULL' / a float NaN makes the rule a lead",
    "A22": "STATED v2.3 (§2): an entry that is not 1-4 letters and digits after clean-up makes the rule a lead",
    "A23": "Not covered / provider-type units when the line's units are missing: observed = NULL, allowed = 0, "
           "excess = NULL (= observed)",
    # chosen for the v2.3 textual-null amendment BEFORE running
    "A24": "only the three texts NONE / NAN / NULL are null spellings, matched whole after trimming spaces: 'NA' (a REAL "
           "AHCCCS type - NEMT non-ambulance air, other_outpatient in the routing table), 'NANA', 'NUL' and 'N/A' are "
           "codes ('N/A' is not letters and digits: a lead as an entry, an unmapped known code in a column)",
    # chosen for v2.6 (2026-10-05) BEFORE running, where version 2.6 is silent or loose
    "A25": "(v2.6) §2 Code pair, scope member_servicing_billing_day: a code_a line pairs only when its cleaned servicing "
           "provider id AND its cleaned billing provider id (BProv_ID: trimmed, case kept - ' B1 ' = 'B1', 'b1' != 'B1') "
           "both equal the code_b line's; a missing id on either line never matches. NCCI ignores any scope "
           "(member_provider_day). pair_scope (output column) = the scope applied (member_provider_day for NCCI and for "
           "a state rule with no scope)",
    "A26": "(v2.6) §2 Units per day, scope member_servicing_billing_day: groups (member, servicing id, billing id, date); "
           "a counted row missing either id is not counted - not in the sum, evidence, dollars or labels. Output "
           "contract (coordinator 2026-10-05): billing_provider = the group's billing id for this scope, NULL for every "
           "other scope (a per-rule query that does not output the column reads as NULL); servicing_provider = the "
           "group's servicing id (NULL for member_day). max_units_per_dos never carries a scope (it is "
           "member_provider_day)",
    "A27": "(v2.6, amended by N4 2026-10-05) §3 daily caps (max_units_per_day AND max_units_per_dos, every origin "
           "but NCCI): verify_pa (a PA on any counted row of the group - A5, unchanged by N4) > verify_span > "
           "verify_modifier > verify_exception > discretionary > units_over_limit. Both labels read PAYABLE lines only "
           "(§1: paid > 0, units > 0 or missing, not cancelled): verify_span = AT LEAST one payable line whose own units "
           "exceed the threshold (missing units never; several over: still span); verify_modifier = a payable line with "
           "a modifier of config.DAILY_CAP_VERIFY_MODIFIERS (entries trimmed, upper-cased) in any of its four cleaned "
           "modifier columns (a payable line with missing units counts). A cancelled line, any reversal row (cancelling "
           "or not) and a paid line with units <= 0 still count in the sum, the evidence and the dollars - never in "
           "these two labels. Period limits and max_units_per_line keep the old order",
    "A28": "(v2.6) provider_role billing_or_rendering: the type judged = the cleaned billing type, unless it is in "
           "config.GROUP_BILLING_PROVIDER_TYPES cleaned exactly like the column ('1', ' 01 ', '01.0', 1 -> 01) - then the "
           "cleaned servicing (rendering) type. A missing billing type is judged as missing (no fall-back to the "
           "servicing type: never a finding); a group billing type with a missing or textual-null servicing type is "
           "never a finding. Role billing still judges a group type as itself",
    "A29": "(v2.6) the finding text of a provider-type finding judged on a group line's rendering type (coordinator's "
           "output contract) = '{codes} rendered by provider type {servicing type} for a group ({billing type}) "
           "(allowed: {list})', cleaned types; checked: that form, both types, the allowed list as a SET split on '/' "
           "(order and the rendering of a code set are not stated: every rule code must appear in {codes}); every other "
           "provider-type finding must NOT have that form",
    # stated by the spec since v2 (were readings / ambiguities in v1): A2, A3, S01 (POS not kept), S04 (pair age on
    # the code_b line), distinct numeric-ordered evidence with empty rendering (F-01/S-02/S-03), pa_present NULL for
    # NCCI (F-02), NCCI scope always member_provider_day (F-03), code + code_set is not a valid predicate (F-04),
    # reversal units counted as -|units| (R-01)
}

# Coverage of the hard cases: counted while the oracle runs, reported by the summary (proves each case occurred).
COVER = Counter()


# ===================================================================================== the ORACLE
def _trim(s):
    return None if s is None else s.strip(" ")          # 'spaces trimmed' (only the space character)


def _blank_null(s):
    s = _trim(s)
    return None if s is None or s == "" else s


def _upper(s):
    return None if s is None else s.upper()


# §1a (v2, v2.2): the NCCI edit file a line takes, by Table 2 row x claim form x rendering practitioner identified.
ROUTING_CSV = os.path.join(PKG, "reference", "ncci_provider_type_routing.csv")
# Table 2 row (category) -> (form A rendering identified, form A not identified, form O / UB-04)
TABLE2 = {
    "practitioner": ("practitioner", "practitioner", "outpatient"),         # incl. dentists (v2.2, footnote 14)
    "asc": ("practitioner", "practitioner", "practitioner"),
    "outpatient_hospital": ("outpatient", "outpatient", "outpatient"),
    "dme": ("dme", "dme", "dme"),
    "testing_facility": ("practitioner", "practitioner", "practitioner"),   # optional row
    "other_outpatient": ("practitioner", "outpatient", "outpatient"),      # optional row
    "not_applicable": (None, None, None),
}
OPTIONAL_CATEGORIES = {"testing_facility", "other_outpatient"}


def load_routing_rows(path=ROUTING_CSV) -> list:
    import csv
    with open(path, newline="") as fh:
        return list(csv.DictReader(fh))


def load_routing_table(path=ROUTING_CSV) -> dict:
    """provider type code -> Table 2 row. One code list serves the billing and the servicing provider (§1a)."""
    table = {}
    for row in load_routing_rows(path):
        code, cat = row["sprov_type"], row["cms_category"]
        assert code not in table, f"duplicate provider type {code!r} in {path}"
        assert cat in TABLE2, f"unknown Table 2 category {cat!r} for {code!r}"
        table[code] = cat
    return table


PROV_TYPE_CATEGORY = load_routing_table()


NULL_TEXTS = ("NONE", "NAN", "NULL")       # §1 (v2.3): what an export writes for an empty cell - missing (A20, A24)


def clean_prov_type(s):
    """§1 (v2): trimmed, upper-cased, a lone digit zero-padded (8 -> 08), a whole number written with decimals read
    as the number (8.0 -> 08); blank = missing, and (v2.3) so is the text NONE / NAN / NULL in any case (A20; only
    these three whole texts - A24: 'NA', 'NANA', 'NUL' are codes). A11: nothing else is reinterpreted ('008', '8.5')."""
    if s is None:
        return None
    t = s.strip(" ").upper()
    if t == "" or t in NULL_TEXTS:
        return None
    if re.fullmatch(r"[0-9]+\.[0-9]+", t) and Decimal(t) == Decimal(t).to_integral_value():
        t = str(int(Decimal(t)))
    if re.fullmatch(r"[0-9]", t):
        t = "0" + t
    return t


def routing_config():
    """Read at call time, so a test can monkeypatch config exactly as it does for the SQL side."""
    return (config.NCCI_ROUTE_BY, tuple(config.NCCI_OPTIONAL_CATEGORIES_ON), config.NCCI_UNMAPPED_PROVIDER_TYPE)


def rendering_identified(stype) -> bool:
    """§1a (v2.2): the line's SERVICING type is an individual practitioner - a code in the practitioner row other than
    01 (a group billing ID is not a person). Missing or any other servicing type = not identified."""
    return stype is not None and stype != "01" and PROV_TYPE_CATEGORY.get(stype) == "practitioner"


def route(form, stype, btype, cfg):
    """§1a (v2.2) -> (edit file or None, how the row was chosen). `how` only feeds the coverage report.
    Forms other than A / O: none. "form": A -> practitioner, O -> outpatient. "billing_provider_type" (default): the
    billing type picks the Table 2 row when it is in the table, else the servicing type when it is in the table, else
    NCCI_UNMAPPED_PROVIDER_TYPE ("form" = route by form, "none" = no file). "provider_type": the servicing type picks
    (billing ignored), then the same fall-back. A18: a type that is in the table picks its row even when the row gives
    no file (not_applicable / optional row off). An optional row gives a file only when switched on. The
    other_outpatient row's form-A column depends on the SERVICING type (rendering practitioner identified)."""
    route_by, optional_on, unmapped = cfg
    if form not in ("A", "O"):
        return None, "form_not_A_or_O"
    by_form = "practitioner" if form == "A" else "outpatient"
    if route_by == "form":
        return by_form, "route_by_form"
    picks = [("servicing", stype)] if route_by == "provider_type" else [("billing", btype), ("servicing", stype)]
    tried = []
    for who, code in picks:
        cat = PROV_TYPE_CATEGORY.get(code) if code is not None else None
        if cat is None:
            tried.append(f"{who}_{'missing' if code is None else 'unmapped'}")
            continue
        how = f"{who}_picks:{cat}" + (f"(after {'+'.join(tried)})" if tried else "")
        if cat in OPTIONAL_CATEGORIES and cat not in optional_on:
            return None, how + ":optional_row_off"
        a_ident, a_not, o = TABLE2[cat]
        if form == "O":
            return o, how
        ident = rendering_identified(stype)
        if a_ident != a_not:
            how += ":rendering_identified" if ident else ":rendering_not_identified"
        return (a_ident if ident else a_not), how
    how = "unmapped(" + "+".join(tried) + ")"
    return (by_form, how + "->form") if unmapped == "form" else (None, how + "->none")


def edit_file(form, stype, btype, cfg):
    """§1a: the edit file a (cleaned) line takes - see route()."""
    return route(form, stype, btype, cfg)[0]


ROW_FIELDS = ("claim", "line", "member", "sprov", "bprov", "dos", "code", "units", "paid", "form",
              "mods", "pa", "dob", "ptype", "btype")       # every column the snapshot keeps (not POS), cleaned (A13)


def clean_row(r: dict) -> dict:
    """§1 Clean-up. Code / modifiers / form: trimmed + upper-cased. Member / providers / PA: trimmed.
    Blank modifier / PA / member / provider -> NULL. Servicing AND (v2.2) billing provider type: the provider-type
    clean-up. Claim id, line number, units, paid, POS untouched."""
    return {
        "claim": r["claim"], "line": r["line"],
        "member": _blank_null(r["member"]), "sprov": _blank_null(r["sprov"]), "bprov": _blank_null(r["bprov"]),
        "dos": r["dos"], "code": _upper(_trim(r["code"])), "units": r["units"], "paid": r["paid"], "pos": r["pos"],
        "form": _upper(_trim(r["form"])),
        "mods": tuple(_upper(_blank_null(m)) for m in r["mods"]),
        "pa": _blank_null(r["pa"]), "dob": r["dob"], "ptype": clean_prov_type(r.get("ptype")),
        "btype": clean_prov_type(r.get("btype")),
        # coverage only (not snapshot columns): the raw type was a textual null (v2.3: missing)
        "ptype_null_text": _is_null_text(r.get("ptype")), "btype_null_text": _is_null_text(r.get("btype")),
        "btype_raw": r.get("btype"), "bprov_raw": r.get("bprov"),          # (v2.6) coverage only
    }


def _is_null_text(s) -> bool:
    return isinstance(s, str) and s.strip(" ").upper() in NULL_TEXTS


def row_key(cr: dict) -> tuple:
    return tuple(cr[f] for f in ROW_FIELDS)


# §1 Cancelled line (v2.3): which identical lines a reversal cancels first - (claim id, line NUMBER), then for rows of
# one claim line: claim form, PA number, servicing provider type, billing provider type, billing provider id, date of
# birth; cleaned values, ascending, missing first (A19). With the offset columns these are every column the snapshot
# keeps, so after de-duplication the order is total.
CANCEL_ORDER = ("claim", "line", "form", "pa", "ptype", "btype", "bprov", "dob")


def cancel_order_key(r):
    out = []
    for c in CANCEL_ORDER:
        v = r[c]
        filler = 0 if c == "line" else D.min if c == "dob" else ""
        out.append((v is not None, v if v is not None else filler))
    return tuple(out)


def _offset_key(r, units, paid):
    # tuple equality is null-safe (None == None): "a missing value matching a missing value"
    return (r["member"], r["sprov"], r["dos"], r["code"], r["mods"], units, paid)


def counted_units(r):
    """§1 (v2): a reversal row's units count as -|units| whatever the sign in the claims table."""
    u = r["units"]
    if r["paid"] is not None and r["paid"] < 0:
        return None if u is None else -abs(u)
    return u


def _line_key(r):
    return _offset_key(r, r["units"], r["paid"])


def _reversal_key(r):
    cu = counted_units(r)
    return _offset_key(r, None if cu is None else -cu, -r["paid"])    # offsets a line of units -(counted units)


def _cover_route(r, cfg):
    """Coverage of §1a v2.2 (rows): which step chose the Table 2 row, and whether the billing type changed the file."""
    route_by, optional_on, unmapped = cfg
    how, ed, form = r["route_how"], r["edition"], r["form"]
    COVER[f"route:{form}|{how}->{ed}"] += 1
    for col, who in (("btype", "billing"), ("ptype", "servicing")):          # (v2.3) textual nulls are missing
        if r.get(f"{col}_null_text"):
            COVER[f"textual_null:{who}_type_rows_read_as_MISSING"] += 1
    if form in ("A", "O") and route_by != "form":
        if r.get("btype_null_text") and route_by != "provider_type":
            COVER["textual_null:billing_missing_" + ("->servicing_type_picks" if how.startswith("servicing_picks")
                                                     else "->no_servicing_type_either(form/none)")] += 1
        if r.get("ptype_null_text") and how.startswith("unmapped"):
            COVER["textual_null:servicing_missing_->fell_back_to_" + ("FORM" if how.endswith("->form") else "NONE")] += 1
        if r.get("ptype_null_text") and ":rendering_not_identified" in how:
            COVER["textual_null:servicing_missing_->rendering_NOT_identified(other_outpatient on A)"] += 1
    if form not in ("A", "O"):
        if "07" in (r["btype"], r["ptype"]) and form == "D":
            COVER["route_v22:dentist_07_on_form_D->none"] += 1
        return
    if how.startswith("billing_picks"):
        COVER["route_v22:row_picked_by_BILLING_type"] += 1
        if r["btype"] != r["ptype"]:
            COVER["route_v22:row_picked_by_billing_type_that_differs_from_servicing"] += 1
        if ed is None:
            COVER["route_v22:billing_row_gives_no_file(A18, no fall-back)"] += 1
            if edit_file(form, r["ptype"], None, cfg) is not None:
                COVER["route_v22:billing_row_gives_no_file_although_servicing_type_would_route"] += 1
    elif how.startswith("servicing_picks") and route_by != "provider_type":
        COVER["route_v22:fell_back_to_SERVICING_type(billing " + ("missing)" if r["btype"] is None else "unmapped)")] += 1
    elif how.startswith("servicing_picks"):
        COVER["route_v22:provider_type_mode_servicing_picks"] += 1
        if r["btype"] is not None and edit_file(form, r["ptype"], r["btype"], ("billing_provider_type",) + cfg[1:]) != ed:
            COVER["route_v22:provider_type_mode_billing_type_IGNORED_although_it_would_change_the_file"] += 1
    elif how.startswith("unmapped"):
        COVER["route_v22:fell_back_to_" + ("FORM" if how.endswith("->form") else "NONE(unmapped=none)")] += 1
    elif how == "route_by_form" and (r["btype"] is not None or r["ptype"] is not None):
        if edit_file(form, r["ptype"], r["btype"], ("billing_provider_type",) + cfg[1:]) != ed:
            COVER["route_v22:form_mode_types_IGNORED_although_they_would_change_the_file"] += 1
    if ":rendering_identified" in how:
        COVER[f"route_v22:other_outpatient_on_form_A_rendering_IDENTIFIED->{ed}"] += 1
    elif ":rendering_not_identified" in how:
        COVER[f"route_v22:other_outpatient_on_form_A_rendering_NOT_identified({r['ptype']})->{ed}"
              if r["ptype"] in (None, "01") else
              "route_v22:other_outpatient_on_form_A_rendering_NOT_identified(other)->" + str(ed)] += 1
    if route_by not in ("provider_type", "form") and edit_file(form, r["ptype"], None, ("provider_type",) + cfg[1:]) != ed:
        COVER["route_v22:billing_type_CHANGES_the_file_vs_servicing_type_alone"] += 1
    if form == "A" and "07" in (r["btype"] if how.startswith("billing") else r["ptype"],) and ed == "practitioner":
        COVER["route_v22:dentist_07_on_form_A->practitioner"] += 1


def _cover_cancel_cut(a, b):
    """Coverage of §1 (v2.3): the column of the cancellation order that decided between the last cancelled line (a)
    and the first surviving one (b), and what the choice changes downstream."""
    ka, kb = cancel_order_key(a), cancel_order_key(b)
    i = next((i for i in range(len(ka)) if ka[i] != kb[i]), None)
    assert i is not None, f"two snapshot rows tie on every cancellation column: {a} / {b}"
    col = CANCEL_ORDER[i]
    COVER[f"cancel_cut_decided_by:{col}" + ("(missing first)" if ka[i][0] != kb[i][0] else "")] += 1
    if col in ("ptype", "btype") and (a.get(f"{col}_null_text") or b.get(f"{col}_null_text")):
        COVER["cancel_tie:a_textual_null_type_sorts_as_MISSING_(first)"] += 1
    if col not in ("claim", "line"):
        COVER["cancel_TIE_on_claim_id_and_line_number_resolved_by_v2.3_order"] += 1
        if a["edition"] != b["edition"]:
            COVER["cancel_tie:cancelled_and_surviving_copies_take_DIFFERENT_edit_files"] += 1
        if a["btype"] != b["btype"]:
            COVER["cancel_tie:cancelled_and_surviving_copies_differ_in_billing_type"] += 1
        if (a["pa"] is None) != (b["pa"] is None):
            COVER["cancel_tie:only_one_copy_has_a_PA(pa_present_follows_the_survivor)"] += 1
    if col == "claim" and None not in (a["claim"], b["claim"]):
        na, nb = (re.sub(r"\D", "", x) for x in (a["claim"], b["claim"]))
        if na and nb and int(na) > int(nb):
            COVER["cancel_order_claim_id_TEXT_differs_from_numeric"] += 1
    if col == "line" and None not in (a["line"], b["line"]) and str(a["line"]) > str(b["line"]):
        COVER["cancel_order_line_NUMBER_differs_from_text_order(10 after 9)"] += 1


def build_snapshot(raw_rows, cover=True, cfg=None):
    """§1: clean, de-duplicate on every cleaned column, drop rows with no member / date / code, flag reversal,
    cancelled (v2.3 tie order), payable, counted."""
    seen, raw_keys, raw_types = {}, Counter(), {}
    for r in raw_rows:
        cr = clean_row(r)
        k = row_key(cr)
        if cover and k in seen:
            COVER["dup_exact_raw" if tuple(r[f] for f in ROW_FIELDS) in raw_keys else "dup_only_after_cleanup"] += 1
            for i, col in enumerate(("ptype", "btype")):
                first = raw_types[k][i]
                if cr[col] is None and first != r.get(col) and (_is_null_text(first) or _is_null_text(r.get(col))):
                    COVER[f"textual_null:{col}_rows_differing_only_in_null_spelling_are_ONE_row"] += 1
        raw_keys[tuple(r[f] for f in ROW_FIELDS)] += 1
        raw_types.setdefault(k, (r.get("ptype"), r.get("btype")))
        if cover:
            for col in ("ptype", "btype"):
                if _is_null_text(r.get(col)):
                    COVER[f"textual_null:{col}_raw_spelling:{r.get(col)!r}"] += 1
        seen.setdefault(k, cr)
    snap = []
    for r in seen.values():
        if r["member"] is not None and r["dos"] is not None and r["code"] not in (None, ""):      # A1
            snap.append(r)
        elif cover:
            COVER["dropped_no_member" if r["member"] is None else "dropped_no_dos" if r["dos"] is None
                  else "dropped_no_code"] += 1
    cfg = cfg or routing_config()
    lines, revs = defaultdict(list), Counter()
    for r in snap:
        r["reversal"] = r["paid"] is not None and r["paid"] < 0
        r["cunits"] = counted_units(r)
        r["edition"], r["route_how"] = route(r["form"], r["ptype"], r["btype"], cfg)
        r["cancelled"] = False
        if cover and r["reversal"] and r["units"] is not None and r["units"] > 0:
            COVER["reversal_with_POSITIVE_units_counted_negative"] += 1
        if r["paid"] is not None and r["paid"] > 0:
            lines[_line_key(r)].append(r)
        elif r["reversal"]:
            revs[_reversal_key(r)] += 1
    for k, group in lines.items():
        n = revs.get(k, 0)
        if n:
            group.sort(key=cancel_order_key)
            for x in group[:n]:
                x["cancelled"] = True
            if n < len(group):                               # the order decides: mark the copies of one claim line
                same_line = defaultdict(list)                # that end up on both sides of the cut (v2.3 ties)
                for x in group:
                    same_line[(x["claim"], x["line"])].append(x)
                for xs in same_line.values():
                    for x in xs:
                        x.setdefault("tie_peers", []).extend(y for y in xs if y["cancelled"] != x["cancelled"])
            if cover:
                COVER["cancelled_lines"] += min(n, len(group))
                if k[1] is None or k[5] is None or any(m is None for m in k[4]):
                    COVER["cancel_key_has_null(prov/units/mod)"] += 1
                if k[1] is None:
                    COVER["cancel_key_null_provider"] += 1
                if k[5] is None:
                    COVER["cancel_key_null_units"] += 1
                if n < len(group):
                    COVER["cancel_partial_group(order_decides)"] += 1
                    _cover_cancel_cut(group[n - 1], group[n])
                if n > len(group):
                    COVER["cancel_more_reversals_than_lines"] += 1
    if cover:
        COVER["code_with_TAB_not_trimmed"] += sum(1 for r in snap if r["code"].startswith("\t"))
        ups = Counter(m.upper() for m in {r["member"] for r in snap})
        COVER["member_ids_differing_only_in_case"] += sum(1 for v in ups.values() if v > 1)
        COVER["rows_with_lower_case_provider_id"] += sum(1 for r in snap if r["sprov"] == "p1")
        COVER["blank_form_kept_as_empty_string"] += sum(1 for r in snap if r["form"] == "")
        for r in snap:
            _cover_route(r, cfg)
        line_keys = set(lines)
        for k, n in revs.items():
            if k not in line_keys:
                COVER["reversal_without_exact_line"] += n
    for r in snap:
        p, u = r["paid"], r["units"]
        r["payable"] = p is not None and p > 0 and (u is None or u > 0) and not r["cancelled"]
        r["counted"] = p is not None and p != 0
    return snap


def unresolved_cancellation_ties(raw_rows):
    """Cleaned rows still tied at the cut of a reversal group under the FULL v2.3 order. Since v2.3 the order covers
    every column the snapshot keeps, so this is always empty; the generator asserts it instead of re-numbering ties
    (it did that up to v2.2, when (claim id, line number) was the whole order)."""
    seen = {}
    for r in raw_rows:
        cr = clean_row(r)
        seen.setdefault(row_key(cr), cr)
    snap = [r for r in seen.values() if r["member"] is not None and r["dos"] is not None and r["code"] not in (None, "")]
    lines, revs = defaultdict(list), Counter()
    for r in snap:
        if r["paid"] is not None and r["paid"] > 0:
            lines[_line_key(r)].append(r)
        elif r["paid"] is not None and r["paid"] < 0:
            revs[_reversal_key(r)] += 1
    out = []
    for k, group in lines.items():
        n = revs.get(k, 0)
        if 0 < n < len(group):
            group.sort(key=cancel_order_key)
            if cancel_order_key(group[n - 1]) == cancel_order_key(group[n]):
                out += [group[n - 1], group[n]]
    return out


def add_years(d: dt.date, n: int) -> dt.date:
    """Spark ADD_MONTHS(d, 12 * n): same month and day, clamped to the month's last day (29 Feb -> 28 Feb)."""
    y = d.year + n
    return D(y, d.month, min(d.day, calendar.monthrange(y, d.month)[1]))


def _iso(s):
    return None if s in (None, "") else D.fromisoformat(str(s)[:10])


def norm_code(c):
    return str(c).strip().upper()


def rule_codes(p: dict) -> set:
    out = {norm_code(p[k]) for k in ("code",) if p.get(k) not in (None, "")}
    out |= {norm_code(c) for c in (p.get("code_set") or [])}
    return out


def is_ncci(rule) -> bool:
    return rule.get("origin") == "ncci"


COVER_SETS = defaultdict(set)


def _cov(name, *ident):
    COVER_SETS[name].add(ident)


def _rk(r):
    return row_key(r)


def in_scope(rule: dict, r: dict, age=True) -> bool:
    """§2 common: window (both ends included) on the date of service; age on the date of service (ADD_MONTHS
    birthdays; no usable DOB never matches); NCCI only on its claim form."""
    rid = rule["rule_id"]
    eff, end = _iso(rule.get("effective_date")), _iso(rule.get("end_date"))
    if eff is not None and r["dos"] == eff:
        _cov("window_row_on_effective_date(included)", rid, _rk(r))
    if end is not None and r["dos"] == end:
        _cov("window_row_on_end_date(included)", rid, _rk(r))
    if eff is not None and r["dos"] < eff:
        if r["dos"] == eff - DAY:
            _cov("window_row_day_before_effective(excluded)", rid, _rk(r))
        return False
    if end is not None and r["dos"] > end:
        if r["dos"] == end + DAY:
            _cov("window_row_day_after_end(excluded)", rid, _rk(r))
        return False
    age = (rule["predicate"].get("age") or {}) if age else {}
    if age:
        if r["dob"] is None:
            _cov("age_rule_row_without_dob(excluded)", rid, _rk(r))
            return False
        for k in ("min", "below"):
            if k in age:
                bd = add_years(r["dob"], int(age[k]))
                if r["dos"] == bd:
                    _cov(f"age_{k}_dos_is_birthday", rid, _rk(r))
                if r["dos"] == bd - DAY:
                    _cov(f"age_{k}_dos_day_before_birthday", rid, _rk(r))
                if (r["dob"].month, r["dob"].day) == (2, 29) and (bd.month, bd.day) == (2, 28) and r["dos"] in (bd, bd - DAY, bd + DAY):
                    _cov("age_feb29_dob_near_28feb_birthday", rid, _rk(r))
        if "min" in age and not r["dos"] >= add_years(r["dob"], int(age["min"])):
            return False
        if "below" in age and not r["dos"] < add_years(r["dob"], int(age["below"])):
            return False
    if is_ncci(rule):                                         # §2 (v2): only lines that take ITS edit file
        want = rule["predicate"].get("ncci_edition")
        want = str(want).strip().lower() if want not in (None, "") else None
        if want is None or r["edition"] != want:
            _cov(f"ncci_line_takes_{r['edition']}_not_{want}(excluded)", rid, _rk(r))
            return False
    return True


def is_em(code) -> bool:
    if code is None or len(code) != 5 or not (code.isascii() and code.isdigit()):
        return False
    n = int(code)
    return 99202 <= n <= 99499 or 92002 <= n <= 92014


def _mods(r) -> set:
    return {m for m in r["mods"] if m is not None}


def bypass_mods(r) -> set:
    m = _mods(r)
    out = m & (ANATOMIC | GENERAL_BYPASS)
    if is_em(r["code"]):
        out |= m & EM_ONLY_BYPASS
    return out


def pair_bypassed(a, b, indicator) -> bool:
    return bypass_branch(a, b, indicator)[0]


def bypass_branch(a, b, indicator):
    """(bypassed?, branch name) - the branch name only feeds the coverage report."""
    ma, mb = _mods(a), _mods(b)
    relevant = (ma | mb) & (ANATOMIC | GENERAL_BYPASS | EM_ONLY_BYPASS)
    if indicator != "1":
        return False, "ind0_modifiers_ignored" if relevant else "ind0_plain"
    if not (bypass_mods(a) or bypass_mods(b)):
        if (ma | mb) & EM_ONLY_BYPASS:
            return False, "ind1_24/25/57_on_non_EM_line_only(no bypass)"
        return False, "ind1_no_ncci_modifier"
    if (ma & mb & ANATOMIC) and not ((ma | mb) & ANATOMIC_OVERRIDE):
        return False, "ind1_same_anatomic_both_lines_no_override(no bypass)"
    if ma & mb & ANATOMIC:
        return True, "ind1_same_anatomic_with_override(bypass)"
    if (bypass_mods(a) | bypass_mods(b)) & GENERAL_BYPASS:
        return True, "ind1_general_modifier(bypass)"
    if (bypass_mods(a) | bypass_mods(b)) & ANATOMIC:
        return True, "ind1_anatomic(bypass)"
    return True, "ind1_24/25/57_on_EM_line(bypass)"


def indicator_of(p: dict) -> str:
    v = p.get("modifier_indicator")
    s = "" if v is None else str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s or "0"


def severity(rule, base, pa_present, mue_changed=False, span=False, modifier=False):
    """§3 (without the Column-One relabel, which notebook 08 applies after all NCCI findings exist). (v2.6, A27) daily
    caps of state rules: verify_pa > verify_span > verify_modifier > verify_exception > discretionary > base."""
    if is_ncci(rule):
        return "verify_mue_changed_later" if mue_changed else base
    p = rule["predicate"]
    if pa_present:
        return "verify_pa"
    if span:
        return "verify_span"
    if modifier:
        return "verify_modifier"
    if p.get("exception") is not None and str(p.get("exception")).strip():
        return "verify_exception"
    if p.get("discretionary") is True:
        return "discretionary"
    return base


def ev(r) -> tuple:
    return (r["claim"], r["line"])


def _finding(rule, kind, key, base, pa, sev=None, **kw):
    f = {"rule_id": rule["rule_id"], "kind": kind, "key": key, "finding_basis": base,
         "finding_severity": sev or severity(rule, base, pa),
         "pa_present": None if is_ncci(rule) else bool(pa)}             # §3 v2: NULL = PA not evaluated
    f.update(kw)
    if not is_ncci(rule):
        p = rule["predicate"]
        if pa:
            _cov("severity_verify_pa", rule["rule_id"], key)
            if (p.get("exception") or "").strip() or p.get("discretionary") is True:
                _cov("severity_pa_beats_exception_or_discretionary", rule["rule_id"], key)
        elif (p.get("exception") or "").strip():
            _cov("severity_verify_exception", rule["rule_id"], key)
            if p.get("discretionary") is True:
                _cov("severity_exception_beats_discretionary", rule["rule_id"], key)
        elif p.get("discretionary") is True:
            _cov("severity_discretionary", rule["rule_id"], key)
    return f


def _cov_tie_ncci(rule, r):
    """Coverage (§1 v2.3 + §2): a payable line whose copy on the same claim line was cancelled by the tie order, judged
    by an NCCI rule - whether the surviving copy's edit file decides the finding."""
    if not is_ncci(rule) or r["cancelled"] or not r.get("tie_peers"):
        return
    want = str(rule["predicate"].get("ncci_edition") or "").strip().lower() or None
    mine, theirs = r["edition"] == want, any(y["edition"] == want for y in r["tie_peers"] if y["cancelled"])
    if mine and not theirs:
        _cov("ncci_cancel_tie:survivor_takes_the_rule's_file_the_cancelled_copy_did_not", rule["rule_id"], _rk(r))
    elif theirs and not mine:
        _cov("ncci_cancel_tie:the_cancelled_copy_took_the_rule's_file_the_survivor_does_not(no finding)",
             rule["rule_id"], _rk(r))


PAIR_MSB = "member_servicing_billing_day"                      # (v2.6) the same servicing AND billing provider id


def oracle_pair(rule, snap):
    """§2 Code pair. (v2.6, A25) scope member_servicing_billing_day = the same servicing provider AND the same billing
    provider id (a missing id of either never matches); NCCI is always member_provider_day."""
    p = rule["predicate"]
    rid = rule["rule_id"]
    a_code, b_code = norm_code(p["code_a"]), norm_code(p["code_b"])
    scope = "member_provider_day" if is_ncci(rule) else (p.get("scope") or "member_provider_day")   # §2 v2
    if is_ncci(rule) and p.get("scope") not in (None, "", "member_provider_day"):
        _cov(f"ncci_pair_stray_scope_{p.get('scope')}_ignored", rid)
    ind = indicator_of(p)
    base = "hard_denial" if ind == "0" else "unbypassed_pair"
    a_lines = [r for r in snap if r["code"] == a_code and r["payable"] and in_scope(rule, r, age=False)]   # S04
    for r in a_lines:
        if rule["predicate"].get("age") and not in_scope(rule, r):
            _cov("pair_code_a_line_fails_age_itself_still_pairs(S04)", rid, _rk(r))
    a_unpayable = [r for r in snap if r["code"] == a_code and not r["payable"]]
    hits = defaultdict(list)
    for b in snap:
        if b["code"] == b_code and b["payable"]:
            _cov_tie_ncci(rule, b)
        if b["code"] != b_code or not b["payable"] or not in_scope(rule, b):
            continue
        m = []
        for a in a_lines:
            if a["member"] != b["member"] or a["dos"] != b["dos"]:
                continue
            if scope != "member_day" and (a["sprov"] is None or a["sprov"] != b["sprov"]):
                _cov("pair_NULL_provider_never_matches" if None in (a["sprov"], b["sprov"])
                     else "pair_other_provider_excluded", rid, _rk(a), _rk(b))
                continue
            if scope == PAIR_MSB and (a["bprov"] is None or a["bprov"] != b["bprov"]):          # (v2.6, A25)
                if None in (a["bprov"], b["bprov"]):
                    _cov("pair_msb_NULL_billing_id_never_matches", rid, _rk(a), _rk(b))
                else:
                    _cov("pair_msb_other_billing_id_excluded" + ("(differs only in CASE)" if a["bprov"].upper()
                                                                 == b["bprov"].upper() else ""), rid, _rk(a), _rk(b))
                continue
            if scope == "member_day" and a["sprov"] != b["sprov"]:
                _cov("pair_member_day_matches_across_providers", rid, _rk(a), _rk(b))
            if scope == "member_provider_day" and not is_ncci(rule) and a["bprov"] != b["bprov"]:
                _cov("pair_member_provider_day_matches_across_billing_ids", rid, _rk(a), _rk(b))
            if a["claim"] == b["claim"] and a["line"] == b["line"]:                 # null-safe self check
                _cov("pair_same_claim_and_line_never_pairs" + ("(NULL line)" if a["line"] is None else ""),
                     rid, _rk(a), _rk(b))
                continue
            byp, branch = bypass_branch(a, b, ind)
            _cov("bypass:" + branch, rid, _rk(a), _rk(b))
            if byp:
                continue
            if a["claim"] == b["claim"]:
                _cov("pair_two_lines_of_same_claim", rid, _rk(a), _rk(b))
            if scope == PAIR_MSB:
                _cov("pair_msb_same_servicing_and_billing_id_pairs" + (
                    "(billing id SPELLED differently: ' B1 ' / 'B1')" if a.get("bprov_raw") != b.get("bprov_raw")
                    else ""), rid, _rk(a), _rk(b))
            m.append(a)
        for a in a_unpayable:
            if a["member"] == b["member"] and a["dos"] == b["dos"]:
                _cov("pair_code_a_line_not_payable_ignored", rid, _rk(a), _rk(b))
        if not m:
            continue
        # S06 / A17 (spec v2.3): one finding per (claim id, line number, member, provider, date, form, paid) - PA,
        # units, modifiers, provider types and edit files never split it
        hits[(b["claim"], b["line"], b["member"], b["dos"], b["sprov"], b["form"], b["paid"])].append((b, m))
    out = []
    for (claim, line, member, dos, sprov, form, paid), group in hits.items():
        if len(group) > 1:                                                    # S06
            _cov("pair_code_b_rows_sharing_the_shown_columns_merged(S06)", rid, claim, line)
            if len({bb["edition"] for bb, _ in group}) > 1:
                _cov("pair_code_b_rows_of_one_line_in_DIFFERENT_edit_files_merged(v2.3, was F-05)", rid, claim, line)
            elif len({(bb["btype"], bb["ptype"]) for bb, _ in group}) > 1:
                _cov("pair_code_b_rows_differing_in_provider_TYPE_same_file_merged(A17)", rid, claim, line)
            else:
                _cov("pair_code_b_rows_same_types_differing_in_PA/units/modifiers_merged(S06)", rid, claim, line)
            if len({bb["pa"] is None for bb, _ in group}) > 1:
                _cov("pair_code_b_merged_rows_PA_on_some_only(pa_present=any)", rid, claim, line)
            if len({frozenset(ev(a) for a in ms) for _, ms in group}) > 1:
                _cov("pair_code_b_merged_rows_pair_with_DIFFERENT_code_a_lines(evidence=union)", rid, claim, line)
            if scope == PAIR_MSB and len({bb["bprov"] for bb, _ in group}) > 1:
                _cov("pair_msb_code_b_rows_of_one_line_with_DIFFERENT_billing_ids_merged", rid, claim, line)
        b = group[0][0]
        m = [a for _, ms in group for a in ms]
        evidence = tuple(sorted({ev(a) for a in m}, key=_num_order))         # §2 v2: distinct, numeric order
        col1 = evidence[0]                                                    # Column One = the first of them
        if [ev_str(e) for e in evidence] != sorted(ev_str(e) for e in evidence):
            _cov("pair_evidence_numeric_order_differs_from_text_order", rid, _rk(b))
        if any(None in e for e in evidence):
            _cov("pair_evidence_has_missing_claim_or_line(rendered empty)", rid, _rk(b))
        if len(evidence) < len(m):
            _cov("pair_evidence_repeated_claim_line_listed_once", rid, _rk(b))
        pa = any(bb["pa"] is not None for bb, _ in group) or any(a["pa"] is not None for a in m)
        if all(bb["pa"] is None for bb, _ in group) and pa:
            _cov("pair_pa_only_on_code_a_line", rid, _rk(b))
        if len(evidence) > 1:
            _cov("pair_several_code_a_lines_in_evidence", rid, _rk(b))
        out.append(_finding(rule, "line", (b["claim"], b["line"], b["member"], b["dos"]), base, pa,
                            paid_amt=b["paid"], paid_at_risk=b["paid"], evidence=evidence, col1=col1,
                            servicing_provider=b["sprov"], form_typ=b["form"], pair_scope=scope))
    return out


def oracle_units_per_line(rule, snap):
    p = rule["predicate"]
    rid = rule["rule_id"]
    code, thr = norm_code(p["code"]), Decimal(int(p["threshold"]))
    later = p.get("later_max_threshold")
    out = []
    for r in snap:
        if r["code"] == code and r["payable"] and r["units"] is not None and r["units"] > thr:
            _cov_tie_ncci(rule, r)
        if r["code"] != code or not r["payable"] or not in_scope(rule, r):
            continue
        if r["units"] is None or not r["units"] > thr:
            if r["units"] is not None and r["units"] == thr:
                _cov("units_line_equal_to_threshold(not flagged)", rid, _rk(r))
            continue
        changed = is_ncci(rule) and (p.get("removed_later") is True
                                     or (later is not None and Decimal(int(later)) >= r["units"]))
        if is_ncci(rule):
            if p.get("removed_later") is True:
                _cov("mue_removed_later(relabel)", rid, _rk(r))
            elif later is not None:
                _cov("mue_later_limit_covers_units(relabel)" if changed else "mue_later_limit_below_units(no relabel)",
                     rid, _rk(r))
        if r["units"] != r["units"].to_integral_value():
            _cov("units_fractional_over_limit", rid, _rk(r))
        pa = r["pa"] is not None
        out.append(_finding(rule, "line", (r["claim"], r["line"], r["member"], r["dos"]), "units_over_limit", pa,
                            sev=severity(rule, "units_over_limit", pa, changed),
                            observed_units=r["units"], allowed_units=thr, excess_units=r["units"] - thr,
                            paid_amt=r["paid"], paid_at_risk=r["paid"], servicing_provider=r["sprov"],
                            form_typ=r["form"]))
    return out


# §3 (v2.6) daily-cap modifiers as the spec lists them (bilateral, anatomic, repeat, distinct); the self-check asserts
# config.DAILY_CAP_VERIFY_MODIFIERS holds exactly these
DAILY_CAP_MODIFIERS_SPEC = ({"50", "RT", "LT", "E1", "E2", "E3", "E4", "FA", "TA", "LC", "LD", "RC", "LM", "RI", "76",
                             "77", "91", "59", "XE", "XS", "XP", "XU"}
                            | {f"F{i}" for i in range(1, 10)} | {f"T{i}" for i in range(1, 10)})


def daily_cap_modifiers() -> set:
    """config.DAILY_CAP_VERIFY_MODIFIERS, read at call time (A27): compared with the row's cleaned modifiers."""
    return {str(m).strip(" ").upper() for m in (config.DAILY_CAP_VERIFY_MODIFIERS or ())}


def _group_finding(rule, kind, key, rows, thr, daily_cap=False, **extra):
    rid = rule["rule_id"]
    units = [r["cunits"] for r in rows if r["cunits"] is not None]          # §1 v2: reversal rows -|units|
    if not units:
        return None
    s = sum(units, Decimal(0))
    if any(r["reversal"] for r in rows):
        _cov(f"{kind}_group_contains_reversal_row", rid, key)
    if any(r["cancelled"] for r in rows):
        _cov(f"{kind}_group_contains_cancelled_line", rid, key)
    if any(r["units"] is None for r in rows):
        _cov(f"{kind}_group_contains_NULL_units_row", rid, key)
    if s == thr:
        _cov(f"{kind}_sum_equal_to_threshold(not flagged)", rid, key)
    if not (s > thr and any(r["payable"] for r in rows)):
        if s > thr:
            _cov(f"{kind}_over_limit_but_no_payable_row(not flagged)", rid, key)
        return None
    total = sum((r["paid"] for r in rows), Decimal(0))
    pa = any(r["pa"] is not None for r in rows)
    if pa and not any(r["pa"] is not None and r["payable"] for r in rows):
        _cov(f"{kind}_pa_only_on_non_payable_counted_row", rid, key)
    span = modifier = False
    if daily_cap:                                                           # §3 (v2.6 + N4, A27): PAYABLE lines only
        pay = [r for r in rows if r["payable"]]
        span = any(r["units"] is not None and r["units"] > thr for r in pay)
        mods = daily_cap_modifiers()
        modifier = any(m in mods for r in pay for m in r["mods"] if m is not None)
        _cover_daily_label(rule, kind, key, rows, thr, pa, span, modifier)
    evidence = tuple(sorted({ev(r) for r in rows}, key=_num_order))       # §2 v2: distinct, numeric order
    if [ev_str(e) for e in evidence] != sorted(ev_str(e) for e in evidence):
        _cov(f"{kind}_evidence_numeric_order_differs_from_text_order", rid, key)
    if len(evidence) < len(rows):
        _cov(f"{kind}_evidence_claim_line_shared_by_several_rows(listed once)", rid, key)
    if any(None in e for e in evidence):
        _cov(f"{kind}_evidence_has_missing_claim_or_line(rendered empty)", rid, key)
    return _finding(rule, kind, key, "units_over_limit", pa,
                    sev=severity(rule, "units_over_limit", pa, span=span, modifier=modifier),
                    observed_units=s, allowed_units=thr, excess_units=s - thr, paid_amt=total,
                    paid_at_risk=total * (s - thr) / s, evidence=evidence, **extra)


def _cover_daily_label(rule, kind, key, rows, thr, pa, span, modifier):
    """Coverage of §3 (v2.6, N4) on daily caps: which label decided, the A27 edges, the counted rows that may NOT decide
    a label (not payable: a cancelled line, a reversal row, a paid line with units <= 0), the N4 case itself, and every
    group whose label differs from the one the pre-N4 reading (every counted row) gives."""
    rid, p = rule["rule_id"], rule["predicate"]
    own = (p.get("exception") or "").strip() or p.get("discretionary") is True
    mods = daily_cap_modifiers()

    def listed(r):
        return any(m in mods for m in r["mods"] if m is not None)

    def label(sp, mo):
        return "verify_pa" if pa else "verify_span" if sp else "verify_modifier" if mo else "own_label(exception/may/base)"

    new = label(span, modifier)
    _cov("daily_cap_label:" + new, rid, key)
    if pa and (span or modifier):
        _cov("daily_cap_label:PA_beats_span_or_modifier", rid, key)
    if span and modifier and not pa:
        _cov("daily_cap_label:span_beats_modifier", rid, key)
    if (span or modifier) and not pa and own:
        _cov("daily_cap_label:span_or_modifier_beats_exception_or_may", rid, key)
    pay = [r for r in rows if r["payable"]]
    if span:
        over = [r for r in pay if r["units"] is not None and r["units"] > thr]
        _cov("daily_cap_span:" + ("exactly_ONE_payable_line_over" if len(over) == 1
                                  else "SEVERAL_payable_lines_over(still span)"), rid, key)
        if len(rows) == 1:
            _cov("daily_cap_span:group_of_a_single_row", rid, key)
    if modifier and any(r["units"] is None and listed(r) for r in pay):
        _cov("daily_cap_modifier:on_a_payable_line_with_NO_units(counts)", rid, key)
    for r in rows:                                  # N4: counted but not payable -> never decides span / modifier
        if r["payable"]:
            continue
        why = "cancelled_line" if r["cancelled"] else "reversal_row" if r["reversal"] else "paid_line_with_units<=0"
        if r["units"] is not None and abs(r["units"]) > thr:
            _cov(f"N4:{why}_over_threshold_ignored" + ("" if span else "(no verify_span)"), rid, key)
        if listed(r):
            _cov(f"N4:{why}_with_listed_modifier_ignored" + ("" if modifier else "(no verify_modifier)"), rid, key)
    if any(r["cancelled"] and r["units"] is not None and r["units"] > thr and listed(r) for r in rows) \
            and any(r["reversal"] for r in rows):
        _cov("N4:THE_CASE:cancelled_LONG_line_with_listed_modifier+reversal+payable_lines_over_cap->" + new, rid, key)
    old = label(any(r["cunits"] is not None and r["cunits"] > thr for r in rows), any(listed(r) for r in rows))
    if old != new:                                  # the pre-N4 reading (every counted row) would label it otherwise
        _cov(f"N4:label_differs_from_the_counted_row_reading:{old}->{new}", rid, key)
    if any(m is not None and m not in mods for r in rows for m in r["mods"]) and not modifier:
        _cov("daily_cap_modifier:only_modifiers_NOT_in_the_list(no verify_modifier)", rid, key)


def daily_scope(rule) -> str:
    """§2 Units per day: max_units_per_dos = member_provider_day; max_units_per_day = its scope (member_day when absent;
    v2.5 member_provider_day, v2.6 member_servicing_billing_day)."""
    p = rule["predicate"]
    if p["type"] == "max_units_per_dos":
        return "member_provider_day"
    return p.get("scope") or "member_day"


DAY_KIND = {"member_day": "day", "member_provider_day": "dos", PAIR_MSB: "msb"}


def _day_key(scope, r):
    return (r["member"], r["sprov"] if scope != "member_day" else None, r["bprov"] if scope == PAIR_MSB else None,
            r["dos"])


def oracle_units_per_day(rule, snap, by_provider=None):
    """§2 Units per day. Groups (key = member, servicing id or None, billing id or None, date): member_day; member_provider_day
    (rows with no servicing provider not counted); (v2.6, A26) member_servicing_billing_day (a row missing either id not
    counted). The finding's servicing_provider / billing_provider = the group's (None where the scope has none).
    by_provider (legacy callers): True = member_provider_day, False = member_day; None = the rule's own scope."""
    p = rule["predicate"]
    scope = daily_scope(rule) if by_provider is None else ("member_provider_day" if by_provider else "member_day")
    kind = DAY_KIND[scope]
    codes, thr = rule_codes(p), Decimal(int(p["threshold"]))
    groups = defaultdict(list)
    zero = set()
    for r in snap:
        if r["code"] in codes and r["counted"] and in_scope(rule, r):
            if scope != "member_day" and r["sprov"] is None:
                _cov(f"{kind}_row_without_provider_ignored", rule["rule_id"], _rk(r))
                continue
            if scope == PAIR_MSB and r["bprov"] is None:
                _cov("msb_row_without_BILLING_id_ignored", rule["rule_id"], _rk(r))
                continue
            groups[_day_key(scope, r)].append(r)
        elif r["code"] in codes and r["paid"] is not None and r["paid"] == 0:
            zero.add(_day_key(scope, r))
    out = []
    for k, rows in groups.items():
        if k in zero:
            _cov(f"{kind}_group_has_zero_paid_row_not_counted", rule["rule_id"], k)
        if len({r["code"] for r in rows}) > 1:
            _cov(f"{kind}_group_mixes_codes_of_code_set", rule["rule_id"], k)
        if scope == "member_provider_day" and len({r["bprov"] for r in rows}) > 1:
            _cov("dos_group_spans_billing_ids(one group)", rule["rule_id"], k)
        if scope == PAIR_MSB and any(r.get("bprov_raw") != rows[0].get("bprov_raw") for r in rows):
            _cov("msb_group_billing_id_spelled_differently(' B1 ' = 'B1')", rule["rule_id"], k)
        f = _group_finding(rule, kind, k, rows, thr, daily_cap=True)
        if f:
            f["servicing_provider"], f["billing_provider"] = k[1], k[2]
            out.append(f)
    return out


def period_bounds(d: dt.date, period: str):
    if period == "month":
        return D(d.year, d.month, 1), D(d.year, d.month, calendar.monthrange(d.year, d.month)[1])
    if period == "year":
        return D(d.year, 1, 1), D(d.year, 12, 31)
    if period == "benefit_year":
        y = d.year if d.month >= 10 else d.year - 1
        return D(y, 10, 1), D(y + 1, 9, 30)
    raise ValueError(period)


def oracle_units_per_period(rule, snap):
    p = rule["predicate"]
    codes, thr = rule_codes(p), Decimal(int(p["threshold"]))
    groups = defaultdict(list)
    for r in snap:
        if r["code"] in codes and r["counted"] and in_scope(rule, r):
            groups[(r["member"], period_bounds(r["dos"], p["period"]))].append(r)
    by_member = defaultdict(set)
    for (m, b) in groups:
        by_member[m].add(b)
    for m, bs in by_member.items():
        if len(bs) > 1:
            _cov(f"period_{p['period']}_member_in_two_or_more_periods", rule["rule_id"], m)
    out = []
    for (m, (ps, pe)), rows in groups.items():
        if any(r["dos"] in (ps, pe) for r in rows):
            _cov(f"period_{p['period']}_row_on_first_or_last_day", rule["rule_id"], m, ps)
        f = _group_finding(rule, "period", (m, ps), rows, thr, period_start=ps, period_end=pe)
        if f:
            out.append(f)
    return out


def line_units(rule, r) -> dict:
    """§2 Not covered (v2.3), also provider type allowed: observed units = the line's units, allowed = 0, excess =
    observed (A23: missing units -> observed / excess NULL); no evidence lines."""
    u = r["units"]
    _cov("one_line_finding_units:" + ("NULL(A23)" if u is None else "fractional" if u != u.to_integral_value()
                                      else "whole"), rule["rule_id"], _rk(r))
    return {"observed_units": u, "allowed_units": Decimal(0), "excess_units": u, "has_evidence": False}


def oracle_not_covered(rule, snap):
    codes = rule_codes(rule["predicate"])
    out = []
    for r in snap:
        if r["code"] in codes and r["payable"] and in_scope(rule, r):
            out.append(_finding(rule, "line", (r["claim"], r["line"], r["member"], r["dos"]), "not_covered_paid",
                                r["pa"] is not None, paid_amt=r["paid"], paid_at_risk=r["paid"],
                                servicing_provider=r["sprov"], form_typ=r["form"], **line_units(rule, r)))
        elif r["code"] in codes and not r["payable"]:
            _cov("not_covered_unpayable_line_ignored", rule["rule_id"], _rk(r))
    return out


def pta_role(p: dict) -> str:
    """A16: provider_role absent / None / '' = billing (the default); 'servicing' = SProv_Type; (v2.6, A28)
    'billing_or_rendering' = the billing type unless it is a group billing type, then the servicing type."""
    r = p.get("provider_role")
    return r if r in ("servicing", "billing_or_rendering") else "billing"


def group_types() -> set:
    """(v2.6, A28) config.GROUP_BILLING_PROVIDER_TYPES cleaned exactly like the column ('1', ' 01 ', '01.0' -> 01),
    read at call time."""
    return {clean_prov_type(str(x)) for x in (config.GROUP_BILLING_PROVIDER_TYPES or ())} - {None}


def judged_type(r: dict, role: str):
    """(the provider type a provider_type_allowed rule of this role judges on a cleaned row, how): servicing -> SProv_Type;
    billing -> BProv_Type; (v2.6) billing_or_rendering -> BProv_Type, or SProv_Type when BProv_Type is a group type.
    A missing billing type stays missing (no fall-back, A28)."""
    if role == "servicing":
        return r["ptype"], "servicing"
    if role == "billing_or_rendering" and r["btype"] is not None and r["btype"] in group_types():
        return r["ptype"], "rendering_for_group"
    return r["btype"], "billing"


GROUP_FINDING_RE = re.compile(r"^(?P<codes>.+) rendered by provider type (?P<st>.+) for a group \((?P<bt>[^()]+)\) "
                              r"\(allowed: (?P<allowed>[^()]*)\)$")


def finding_form(text, codes) -> tuple:
    """(v2.6, A29) the shape of a provider-type finding text: ('group', servicing type, billing type, allowed set, every
    rule code named) for '{codes} rendered by provider type {st} for a group ({bt}) (allowed: {list})'; else ('other',)."""
    m = GROUP_FINDING_RE.match(text or "")
    if not m:
        return ("other",)
    return ("group", m.group("st"), m.group("bt"), frozenset(x.strip() for x in m.group("allowed").split("/")),
            all(c in m.group("codes") for c in codes))


def clean_entry(v):
    """§2 (v2.3): a provider_types entry is cleaned EXACTLY like the column (str() first: 8 -> '8' -> '08', 8.0 -> '8.0'
    -> '08', a float NaN -> 'nan' -> missing); None / blank / NONE / NAN / NULL -> None (A20)."""
    return None if v is None else clean_prov_type(str(v))


def bad_entries(p: dict) -> list:
    """§2 (v2.3): entries that make a provider_type_allowed rule a LEAD - missing after clean-up (None, '', '  ', NONE /
    NAN / NULL in any case, a float NaN - A20) or not 1-4 letters and digits ('8.5', 'C-2', 'C 2', 'N/A', 'ABCDE')."""
    out = []
    for v in p.get("provider_types") or []:
        t = clean_entry(v)
        if t is None or not (t.isascii() and t.isalnum()) or len(t) > 4:
            out.append(v)
    return out


def pta_allowed(p: dict) -> set:
    """The cleaned provider_types (only meaningful for a rule with no bad entry - otherwise the rule is a lead)."""
    return {clean_entry(v) for v in p["provider_types"]} - {None}


def _unpayable_why(r) -> str:
    if r["cancelled"]:
        return "cancelled"
    if r["paid"] is None or r["paid"] == 0:
        return "$0"
    if r["paid"] < 0:
        return "reversal"
    return "units<=0"


def oracle_provider_type_allowed(rule, snap):
    """§2 (v2.2 / v2.6) provider_type_allowed: every payable line of the code(s) inside window / age whose JUDGED type
    (judged_type: the billing type, the servicing type, or - billing_or_rendering - the servicing (rendering) type of a
    line billed under a group type) is KNOWN (A14) and not in provider_types. Whole line at risk, no evidence; one finding
    per snapshot row (A15); finding_form = the shape of the finding text (A29)."""
    p = rule["predicate"]
    rid = rule["rule_id"]
    codes, allowed, role = rule_codes(p), pta_allowed(p), pta_role(p)
    odd_entries = {clean_entry(v) for v in p["provider_types"] if v is not None and str(v) != clean_entry(v)}
    int_entries = {clean_entry(v) for v in p["provider_types"] if isinstance(v, (int, float))}
    _cov(f"pta_rule_role_written_as:{p.get('provider_role', '<absent>')!r}", rid)
    out = []
    for r in snap:
        if r["code"] not in codes:
            continue
        t, how = judged_type(r, role)
        col, other = ("btype", "ptype") if how == "billing" else ("ptype", "btype")
        would_flag = t is not None and t not in allowed
        if not r["payable"]:
            if would_flag:
                _cov(f"pta_type_not_allowed_but_line_not_payable({_unpayable_why(r)})_skipped", rid, _rk(r))
            continue
        if not in_scope(rule, r):
            if would_flag:
                _cov("pta_type_not_allowed_but_outside_window_or_age_skipped", rid, _rk(r))
            continue
        if role == "billing_or_rendering":
            _cover_group_line(rid, r, t, how, allowed)
        if t is None:
            _cov(f"pta_NULL_{how}_type_skipped", rid, _rk(r))
            if r.get(f"{col}_null_text"):
                _cov(f"pta_textual_null_{how}_type_('None'/'nan'/'NULL')_never_flagged", rid, _rk(r))
            if r[other] is not None and r[other] not in allowed:
                _cov(f"pta_NULL_{how}_type_skipped_although_the_{'billing' if other == 'btype' else 'servicing'}"
                     "_type_is_not_allowed", rid, _rk(r))
            continue
        if t in allowed:
            _cov(f"pta_allowed_{how}_type_skipped", rid, _rk(r))
            if t in odd_entries:
                _cov("pta_allowed_via_a_list_entry_spelled_oddly(' 2'/'c2'/'8'/int)", rid, _rk(r))
            if t in int_entries:
                _cov("pta_allowed_via_a_NUMERIC_list_entry(8 / 8.0 -> 08)", rid, _rk(r))
            if any(isinstance(v, str) and "." in v and clean_entry(v) == t for v in p["provider_types"]):
                _cov("pta_allowed_via_a_DECIMAL_text_entry('8.0' -> 08)", rid, _rk(r))
            if t == "008":
                _cov("pta_line_008_allowed_by_list_entry_008(A11/A16)", rid, _rk(r))
            if r[other] is not None and r[other] not in allowed:
                _cov("pta_role_matters:allowed_by_role_type_although_the_other_type_is_not", rid, _rk(r))
            continue
        _cov(f"pta_flagged_{how}" + ("_role" if how != "rendering_for_group" else ""), rid, _rk(r))
        if t not in PROV_TYPE_CATEGORY:
            _cov("pta_flagged_code_not_in_routing_table(A14)", rid, _rk(r))
        if any(a != t and a.isdigit() and t.isdigit() and int(a) == int(t) for a in allowed):
            _cov("pta_flagged_although_the_list_has_the_same_number_padded_otherwise(A11/A16: 08 vs 008)", rid, _rk(r))
        if r[other] is not None and r[other] in allowed:
            _cov("pta_role_matters:flagged_although_the_other_type_is_allowed", rid, _rk(r))
        form = (("group", r["ptype"], r["btype"], frozenset(allowed), True) if how == "rendering_for_group"
                else ("other",))
        out.append(_finding(rule, "line", (r["claim"], r["line"], r["member"], r["dos"]), "provider_type_not_allowed",
                            r["pa"] is not None, paid_amt=r["paid"], paid_at_risk=r["paid"],
                            servicing_provider=r["sprov"], form_typ=r["form"], finding_form=form,
                            **line_units(rule, r)))
    keys = Counter((f["key"][0], f["key"][1]) for f in out)
    for f in out:
        if keys[(f["key"][0], f["key"][1])] > 1:
            _cov("pta_same_claim_line_flagged_on_several_rows(A13/A15)", rid, f["key"])
    by_line = defaultdict(set)
    for r in snap:
        if r["code"] in codes and r["payable"] and in_scope(rule, r, age=True):
            t = judged_type(r, role)[0]
            by_line[(r["claim"], r["line"], r["member"])].add(t is not None and t not in allowed)
    for k, v in by_line.items():
        if v == {True, False}:
            _cov("pta_same_line_two_rows_one_flagged_one_not(types differ)", rid, k)
    for r in snap:                                           # §1 v2.3: the tie order decides which copy is judged
        if r["code"] in codes and r["payable"] and r.get("tie_peers") and in_scope(rule, r):
            t = judged_type(r, role)[0]
            flag = t is not None and t not in allowed
            for y in r["tie_peers"]:
                ty = judged_type(y, role)[0]
                if y["cancelled"] and (ty is not None and ty not in allowed) != flag:
                    _cov("pta_cancel_tie:" + ("survivor_FLAGGED_the_cancelled_copy_would_not_be" if flag
                                              else "survivor_allowed_the_cancelled_copy_WOULD_be_flagged"),
                         rid, _rk(r))
    return out


def _cover_group_line(rid, r, t, how, allowed):
    """Coverage of §2 (v2.6) billing_or_rendering: group lines judged on the rendering type, the group code's spellings,
    and lines whose billing type is missing (no fall-back, A28)."""
    if how == "rendering_for_group":
        _cov("pta_group_billing_type_spelled:" + repr(r.get("btype_raw")), rid, _rk(r))
        _cov("pta_group_line_judged_on_RENDERING_type:" + ("MISSING(no finding)" if t is None else "allowed"
                                                            if t in allowed else "FLAGGED"), rid, _rk(r))
        if t is not None and t in allowed and r["btype"] not in allowed:
            _cov("pta_group_line_ALLOWED_by_rendering_type_although_the_group_type_is_not_listed", rid, _rk(r))
        if t is not None and t not in allowed and r["btype"] in allowed:
            _cov("pta_group_line_FLAGGED_on_rendering_type_although_the_group_type_is_listed", rid, _rk(r))
        if r.get("ptype_null_text"):
            _cov("pta_group_line_rendering_type_is_a_textual_null(no finding)", rid, _rk(r))
    elif r["btype"] is None and r["ptype"] is not None and r["ptype"] not in allowed:
        _cov("pta_b_or_r_billing_type_MISSING_no_fallback_to_the_rendering_type(no finding, A28)", rid, _rk(r))
    elif r["btype"] is not None and r["ptype"] is not None and (r["btype"] in allowed) != (r["ptype"] in allowed):
        _cov("pta_b_or_r_non_group_line_judged_on_BILLING_type_although_rendering_differs", rid, _rk(r))


def oracle_signal(rule, snap):
    """§4: per member, the date with the largest rolling total of counted units (> threshold), earliest on a tie."""
    p = rule["predicate"]
    codes, thr, n = rule_codes(p), Decimal(int(p["threshold"])), ROLLING_N[p["period"]]
    units, paid, dates = defaultdict(Counter), defaultdict(Counter), defaultdict(set)
    for r in snap:
        if r["code"] in codes and r["counted"] and in_scope(rule, r):
            m, d = r["member"], r["dos"]
            paid[m][d] += r["paid"]
            dates[m].add(d)                                       # S05: a counted row makes it a window end
            if r["cunits"] is not None:
                units[m][d] += r["cunits"]
            elif not any(x["cunits"] is not None for x in snap if x["member"] == m and x["dos"] == d
                         and x["code"] in codes and x["counted"]):
                _cov("signal_window_end_on_date_with_only_missing_units(S05)", rule["rule_id"], m, d)
    out = []
    for m in sorted(dates):
        best, ties = None, 0
        for d in sorted(dates[m]):
            lo = d - (n - 1) * DAY
            tot = sum((u for x, u in units[m].items() if lo <= x <= d), Decimal(0))
            if tot > thr and best is not None and tot == best[0]:
                ties += 1
            if tot > thr and (best is None or tot > best[0]):
                best = (tot, d, lo, sum((v for x, v in paid[m].items() if lo <= x <= d), Decimal(0)))
        if best:
            if ties:
                _cov("signal_tie_on_max_total(earliest kept)", rule["rule_id"], m)
            if any(lo_ != best[1] and units[m][lo_] < 0 for lo_ in units[m]):
                _cov("signal_member_has_negative_net_day", rule["rule_id"], m)
            out.append({"rule_id": rule["rule_id"], "kind": "signal", "key": (m,), "rolling_units": best[0],
                        "window_end": best[1], "window_start": best[2], "rolling_paid": best[3],
                        "allowed_units": thr, "rolling_days": n})
    return out


def oracle_findings(rule, snap):
    t = rule["predicate"]["type"]
    if t == "code_pair_prohibited":
        return oracle_pair(rule, snap)
    if t == "max_units_per_line":
        return oracle_units_per_line(rule, snap)
    if t == "max_units_per_day":
        return oracle_units_per_day(rule, snap)
    if t == "max_units_per_dos":
        return oracle_units_per_day(rule, snap)
    if t == "max_units_per_period":
        return oracle_units_per_period(rule, snap)
    if t == "code_not_covered":
        return oracle_not_covered(rule, snap)
    if t == "provider_type_allowed":
        return oracle_provider_type_allowed(rule, snap)
    raise ValueError(t)


# Evidence entries are (claim id, line number) pairs, rendered "claim:line" with a missing part written as empty.
def ev_str(e) -> str:
    c, ln = e
    return f"{'' if c is None else c}:{'' if ln is None else ln}"


def _num_order(e):
    """(claim id, line NUMBER) order, missing values first (A10)."""
    return (e[0] is not None, e[0] or "", e[1] is not None, e[1] if e[1] is not None else 0)


ev_sort_key = _num_order


# ===================================================================================== the GENERATOR
POOL_DATES = [D(2023, 9, 29), D(2023, 9, 30), D(2023, 10, 1), D(2023, 10, 2), D(2023, 10, 31), D(2023, 11, 1),
              D(2023, 12, 31), D(2024, 1, 1), D(2024, 1, 31), D(2024, 2, 1), D(2024, 2, 28), D(2024, 2, 29),
              D(2024, 3, 1), D(2024, 3, 31), D(2024, 4, 1), D(2024, 6, 30), D(2024, 7, 1), D(2024, 9, 29),
              D(2024, 9, 30), D(2024, 10, 1), D(2024, 10, 2), D(2024, 10, 31), D(2024, 11, 1), D(2024, 12, 31),
              D(2025, 1, 1), D(2025, 2, 27), D(2025, 2, 28), D(2025, 3, 1), D(2025, 3, 31), D(2025, 9, 30),
              D(2025, 10, 1)]
STATE_PAIRS = [("H2018", "H2014"), ("S5151", "T1019")]
MSB_PAIR = ("S9480", "H2012")                 # (v2.6) a state pair with scope member_servicing_billing_day (A25)
MSB_DAY_CODE = "H2011"                        # (v2.6) a daily cap with scope member_servicing_billing_day (A26)
DAY_SCOPES = [None, "member_day", "member_provider_day", "member_servicing_billing_day"]   # None = absent (member_day)
RENDERING_TYPES = ["08", "31", "19", "A4", "07", "10", "C1"]      # individual (rendering) practitioner types
# (code_a = Column One, code_b = Column Two, indicator, edit file). E&M boundary codes on purpose:
# 99202-99499 and 92002-92014 are E&M; 99201, 99500, 92015 are not.
NCCI_PAIRS = [("99213", "97110", "1", "practitioner"), ("11111", "22222", "0", "practitioner"),
              ("36415", "99211", "1", "outpatient"), ("92002", "92015", "1", "practitioner"),
              ("99201", "99500", "1", "practitioner"), ("99499", "64450", "1", "outpatient"),
              ("92014", "99202", "1", "practitioner"), ("20610", "J3490", "0", "outpatient"),
              ("E0601", "A7034", "1", "dme")]
NCCI_MUES = [("J3490", 1, "practitioner"), ("96372", 2, "outpatient"), ("97110", 4, "practitioner"),
             ("J1100", 3, "practitioner"), ("E0601", 1, "dme")]
# Provider type codes by Table 2 category. EVERY one is re-checked against reference/ncci_provider_type_routing.csv by
# the self-check (v2.2: 07 Dentist moved to practitioner - TGM Table 2 footnote 14). ODD_PTYPES are not in the table
# and probe the literal clean-up reading (A11). One code list serves the billing and the servicing provider (§1a).
PTYPES = {"practitioner": ["08", "01", "31", "19", "A4", "BC", "C1", "10", "07"], "asc": ["43"],
          "outpatient_hospital": ["02", "ED", "71"], "dme": ["30", "OD", "32"], "testing_facility": ["04", "E1", "60"],
          "other_outpatient": ["05", "C2", "77", "23", "06", "29", "CH", "NA"],    # NA: NEMT non-ambulance air (A24)
          "not_applicable": ["03", "22", "B8", "99", "D4", "54"]}
ODD_PTYPES = ["ZZ", "00", "8.5", "008", "NANA", "NUL", "N/A"]   # A24: near-null texts are ordinary codes
UNLISTABLE = {"8.5", "N/A"}                                      # not 1-4 letters and digits: cannot be an entry
INDIVIDUALS = [c for c in PTYPES["practitioner"] if c != "01"]         # rendering practitioner identified (§1a)
HOSPITALS = ["02", "71"]
CLINICS = ["C2", "05", "77", "29"]                                      # FQHC / clinic / BH clinic / rural HC
# provider_type_allowed (v2.2): dedicated codes (own scenarios) + codes other rules judge too (their lines interact)
PTA_OWN = {"S-PTA1": ["G0466"], "S-PTA2": ["T1016", "H0038"], "S-PTA-ALL": ["99490"], "S-PTA-GRP": ["H0031"]}
PTA_SHARED = ["11975", "97110", "A0422", "J3490", "H2014", "99213"]
ALLOW_ALL_RULES = {"S-PTA-ALL"}                  # provider_types = every type present on its code's lines in the round
ALLOW_ALL_CODES = {c for rid in ALLOW_ALL_RULES for c in PTA_OWN[rid]}
PTA_LISTABLE = sorted({c for cs in PTYPES.values() for c in cs} | {"ZZ", "00", "008", "NANA", "NUL"})   # 1-4 alnum
# another billing type for an otherwise identical row (never '8.5', so S-PTA-ALL can list every type present)
BILLING_ALT = ["02", "08", "C2", "01", "30", "07", None, "ZZ", "43", "05", "D4", "04"]
DAY_SET = ["98960", "98961", "98962"]
DAY_CODE = "A0422"
DOS_CODES = ["T1019", "S5125"]
PERIOD_RULES = [("H0044", "benefit_year"), ("S5150", "month"), ("G0151", "year"), ("H2016,H2017", "benefit_year")]
NC_CODE = "11975"
NC_SET = ["00938", "99070"]
STATE_LINE = ("A0425", 4)
NOISE_CODES = ["99999", "G9999", "A0021", "80053", "Q4100"]
FORMS_RAW = ["A", "A", "A", "a", " A", "O", "O", "o ", "D", "C", None, ""]
PA_RAW = [None] * 16 + ["", "  ", "PA123", " PA77 ", "pa5"]
UNITS_POOL = ["1", "1", "1", "1", "2", "2", "3", "4", "0.5", "1.25", "0", None, "6", "-1"]
PAID_POOL = ["10.00", "25.50", "33.33", "0.01", "99.99", "123.45", "7.77", "0.00", "19.99", "250.00"]
MOD_NOISE = ["GT", "U1", "HN", "HO", "TF", "95"]
EXCEPTION_TEXT = "unless the additional service is separately identifiable"


def _dec(s, places):
    if s is None:
        return None
    return Decimal(str(s)).quantize(Decimal(1).scaleb(-places))


def U(s):
    return _dec(s, 4)


def P(s):
    return _dec(s, 2)


def _vary(rng, s, p=0.25):
    """Cosmetic variant that cleans back to s (code / modifier / form): case and surrounding spaces."""
    if s is None or rng.random() >= p:
        return s
    return rng.choice([s.lower(), " " + s, s + " ", "  " + s.lower() + " "])


def _pad(rng, s, p=0.15):
    """Spaces only (member / provider / PA are trimmed, never upper-cased)."""
    if s is None or rng.random() >= p:
        return s
    return rng.choice([" " + s, s + " ", "  " + s + "  "])


def _ptype_raw(rng, code, p=0.5):
    """A raw spelling of a CLEANED provider type code that cleans back to it ('8', '8.0', ' c2 ', ...)."""
    if code is None:                                 # (v2.3) a textual null is a missing type too (A20)
        return rng.choice([None, "", "  ", None, "", "None", "nan", " NULL ", "NONE", "Null", " none ", "NaN"])
    if rng.random() >= p:
        return code
    v = [" " + code + " ", code + " ", " " + code]
    if not code.isdigit():
        v += [code.lower(), " " + code.lower() + " "]
    elif len(code) == 2 and code in PROV_TYPE_CATEGORY or code == "00":
        n = int(code)
        v += [f"{n}.0", f"{code}.00", f"{code}.0"]
        if n < 10:
            v += [str(n), f" {n} ", f" {n}", f"{n}.00"]
    return rng.choice(v)


def _pick_ptype(rng):
    x = rng.random()
    if x < 0.06:
        return None
    if x < 0.14:
        return rng.choice(ODD_PTYPES)
    cat = rng.choices(list(PTYPES), weights=[6, 1, 2, 1, 1, 2, 1])[0]
    return rng.choice(PTYPES[cat])


def _pick_pair_types(rng):
    """(servicing, billing) CLEANED type codes as real claims pair them, deliberately often different (§1a v2.2):
    a provider billing for itself; a hospital billing a physician's service; an FQHC / clinic billing with an
    individual practitioner, with the group ID 01 or with itself as servicing; group 01 billing with a practitioner;
    an ASC; a DME supplier; a dentist (07 - forms A and D come from the caller) or a dental clinic billing for one;
    the billing type missing / unmapped; anything."""
    x = rng.random()
    if x < 0.34:
        s = _pick_ptype(rng)
        return s, s
    if x < 0.45:
        return rng.choice(INDIVIDUALS), rng.choice(HOSPITALS)
    if x < 0.58:
        c = rng.choice(CLINICS)
        return rng.choice([rng.choice(INDIVIDUALS), rng.choice(INDIVIDUALS), "01", c]), c
    if x < 0.64:
        return rng.choice(INDIVIDUALS), "01"
    if x < 0.67:
        return rng.choice(INDIVIDUALS + ["43"]), "43"
    if x < 0.70:
        return rng.choice(["30", "OD", "08", None]), rng.choice(["30", "OD"])
    if x < 0.75:
        return "07", rng.choice(["07", "07", "01", "D4", "C2", "02"])
    if x < 0.82:
        return _pick_ptype(rng), None
    if x < 0.89:
        return _pick_ptype(rng), rng.choice(ODD_PTYPES)
    return _pick_ptype(rng), _pick_ptype(rng)


def _pick_btype(rng, stype):
    """Billing type for a line whose (cleaned) servicing type is stype: half the time the provider bills for itself."""
    return stype if rng.random() < 0.5 else _pick_pair_types(rng)[1]


def _route_for(rng, rule):
    """(raw form, cleaned servicing type, cleaned billing type) for a scenario line: for an NCCI rule mostly a
    combination that takes the rule's edit file under the routing in force when the claims are generated (§1a v2.2,
    found by sampling real-looking type pairs), otherwise anything."""
    want = rule["predicate"].get("ncci_edition")
    if want and rng.random() < 0.85:
        cfg = routing_config()
        for _ in range(80):
            form = rng.choice(["A", "A", "O"] if want != "outpatient" else ["A", "O", "O"])
            st, bt = _pick_pair_types(rng)
            if edit_file(form, st, bt, cfg) == want:
                return _vary(rng, form, 0.3), st, bt
    st, bt = _pick_pair_types(rng)
    return rng.choice(FORMS_RAW + ["D", "A"]), st, bt


def _list_spelling(rng, code):
    """A spelling of a provider type code for a rule's provider_types list that the column clean-up maps back to it
    (§2 v2.3: cleaned exactly like the column): ' 2 ', '2', 2, 2.0, '2.0', '02.00', 'c2 ', '08' ..."""
    if rng.random() < 0.45:
        return code
    v = [" " + code + " ", code + " ", " " + code]
    if not code.isdigit():
        v += [code.lower(), " " + code.lower()]
    elif len(code) == 2 and code != "00":
        n = int(code)
        v += [n, float(n), f"{n}.0", f"{code}.0", f"{code}.00", f" {n}.0 "]
        if code[0] == "0":
            v += [code[1], " " + code[1] + " ", code[1] + " "]
    return rng.choice(v)


# §2 (v2.3): provider_types entries that make the rule a LEAD (blank after clean-up, 'NONE' - A20, not letters and
# digits after clean-up, longer than 4 characters - A22)
BAD_ENTRIES = [None, "", "  ", "NONE", " none ", "None", "8.5", "C-2", "C 2", "0.5", "08/09", "ABCDE", "12345", 8.5,
               "NAN", "nan", " NULL ", float("nan"), "N/A"]
NULL_ENTRIES = ["None", "nan", " NULL ", "NONE", float("nan"), "Null", " NaN "]       # (v2.3) missing -> lead (A20)
#  ^ cycled by the round seed (S-PTA-NULL), so 8 default rounds list every one of them


def _entry_kind(v) -> str:
    """How a provider_types entry is written (coverage only)."""
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, int):
        return "int(8)"
    if isinstance(v, float):
        return "float(8.0)"
    s = str(v)
    if "." in s:
        return "decimal_text('8.0')"
    if s != s.strip(" "):
        return "padded(' 8 ')"
    if s != s.upper():
        return "lower('c2')"
    if len(s) == 1:
        return "lone_digit('8')"
    return "plain('08')"


def _place_mods(rng, mods):
    slots = [None, None, None, None]
    for m, i in zip(mods, rng.sample(range(4), k=min(4, len(mods)))):
        slots[i] = m
    # blank strings in empty slots: they must count as empty
    return tuple(rng.choice(["", " ", None]) if (m is None and rng.random() < 0.15) else m for m in slots)


def _pair_mods(rng):
    """Modifier combinations that exercise every branch of the indicator-1 bypass rule."""
    a, b = [], []
    x = rng.random()
    anat = sorted(ANATOMIC)
    if x < 0.30:
        pass
    elif x < 0.47:                                         # same anatomic on both lines
        m = rng.choice(anat)
        a, b = [m], [m]
        y = rng.random()
        if y < 0.35:
            rng.choice([a, b]).append(rng.choice(sorted(ANATOMIC_OVERRIDE)))
        elif y < 0.6:
            rng.choice([a, b]).append(rng.choice(["25", "27", "91", "24", "57"]))
    elif x < 0.55:                                         # different anatomic modifiers
        m1, m2 = rng.sample(anat, 2)
        a, b = [m1], [m2]
    elif x < 0.70:                                         # E&M-only modifier on one line
        rng.choice([a, b]).append(rng.choice(["25", "24", "57"]))
    elif x < 0.82:                                         # general bypass on one line
        rng.choice([a, b]).append(rng.choice(sorted(GENERAL_BYPASS)))
    elif x < 0.92:                                         # irrelevant modifiers only
        a.append(rng.choice(MOD_NOISE))
        b.append(rng.choice(MOD_NOISE))
    else:                                                  # several modifiers on one line
        rng.choice([a, b]).extend(rng.sample(sorted(ANATOMIC | GENERAL_BYPASS | EM_ONLY_BYPASS) + MOD_NOISE, 3))
    return ([_vary(rng, m, 0.3) for m in a], [_vary(rng, m, 0.3) for m in b])


def pick_dob(rng):
    x = rng.random()
    if x < 0.15:
        return None
    if x < 0.30:
        return rng.choice([D(2004, 2, 29), D(2000, 2, 29), D(1960, 2, 29), D(2003, 2, 28), D(2004, 3, 1),
                           D(2006, 2, 28)])
    if x < 0.75:                                           # birthday at 18 / 21 / 65 on (or next to) a data date
        d, a = rng.choice(POOL_DATES), rng.choice([18, 21, 21, 65])
        return add_years(d, -a) + rng.choice([-1, 0, 0, 0, 1]) * DAY
    return D(1945, 1, 1) + rng.randint(0, 27000) * DAY


class _Builder:
    def __init__(self, rng, prefix):
        self.rng, self.prefix, self.rows, self.n = rng, prefix, [], 0
        self.ptype_of = {p: _pick_ptype(rng) for p in ("P1", "P2", "P3", "P8", "P9", "p1")}   # one type per provider
        self.btype_of_claim = {}                             # a claim is mostly submitted by ONE billing provider
        self.bprov_of_claim = {}                             # (v2.6) ... with ONE billing provider id

    def claim(self):
        self.n += 1
        return f"{self.prefix}C{self.n}"                     # C1, C10, C2 ... (string order != number order)

    def bprov_for(self, ctx, claim):
        """(v2.6, A25 / A26) a row's billing provider id: mostly its claim's (the visit's agency), sometimes another id
        ('B2', 'B3', 'b1' - ids are not upper-cased) or none (None / '' / '  '); now and then spelled with spaces."""
        rng = self.rng
        if claim in self.bprov_of_claim and rng.random() < 0.9:
            v = self.bprov_of_claim[claim]
        else:
            x = rng.random()
            v = ctx.get("bprov", "B1") if x < 0.72 else rng.choice(["B2", "B3", "b1"]) if x < 0.87 else None
            self.bprov_of_claim.setdefault(claim, v)
        if v is None:
            return rng.choice([None, None, "", "  "])
        return _pad(rng, v, 0.12)

    def add(self, ctx, claim, line, code, *, sprov="_", units="_", paid="_", form="_", mods=(), pa="_", dos=None,
            ptype="_", btype="_", bprov="_"):
        rng = self.rng
        prov = ctx["prov"] if sprov == "_" else sprov
        if ptype == "_":
            ptype = self.ptype_of.get(prov) if prov else _pick_ptype(rng)
            x = rng.random()
            if x < 0.04:
                ptype = None                                 # type missing on this row only
            elif x < 0.07:
                ptype = _pick_ptype(rng)                     # inconsistent type for the same provider
        if btype == "_":                                     # (v2.2) billing type: per claim, sometimes per line
            if claim in self.btype_of_claim and rng.random() < 0.85:
                btype = self.btype_of_claim[claim]
            else:
                btype = _pick_btype(rng, ptype)
                self.btype_of_claim.setdefault(claim, btype)
        row = {
            "claim": claim, "line": line, "member": _pad(rng, ctx["member"], 0.08),
            "sprov": _pad(rng, ctx["prov"] if sprov == "_" else sprov, 0.1), "bprov": self.bprov_for(ctx, claim) if bprov == "_" else bprov,
            "dos": dos or ctx["dos"], "code": _vary(rng, code, 0.2),
            "units": U(rng.choice(UNITS_POOL)) if units == "_" else U(units),
            "paid": P(rng.choice(PAID_POOL)) if paid == "_" else P(paid),
            "pos": rng.choice(["11", "11", "12", "22", None]),
            "form": rng.choice(FORMS_RAW) if form == "_" else form,
            "mods": _place_mods(rng, list(mods)), "pa": rng.choice(PA_RAW) if pa == "_" else pa,
            "dob": ctx["dob"] if rng.random() > 0.03 else None,          # rare per-row missing DOB
            "ptype": _ptype_raw(rng, ptype), "btype": _ptype_raw(rng, btype),
        }
        # row-level damage
        if rng.random() < 0.04:
            row["line"] = None
        if rng.random() < 0.006:
            row["claim"] = None
        if rng.random() < 0.02:
            row["member"] = rng.choice([None, "", "   "])
        if rng.random() < 0.05:
            row["sprov"] = rng.choice([None, "", "  "])
        if rng.random() < 0.006:
            row["dos"] = None
        if rng.random() < 0.004:
            row["code"] = rng.choice([None, "", "  "])
        if rng.random() < 0.004 and row["code"]:
            row["code"] = "\t" + row["code"]                   # a TAB is not a space: not trimmed
        self.rows.append(row)
        return row


def _plain_row(rng, ctx, claim, line, code, form, st, bt, mods, pa=None, paid="10.00", units="1"):
    """A claim row with no random damage (exact control over claim id, line number and modifiers)."""
    return {"claim": claim, "line": line, "member": ctx["member"], "sprov": ctx["prov"], "bprov": "B1", "dos": ctx["dos"],
            "code": code, "units": U(units), "paid": P(paid), "pos": "11", "form": form,
            "mods": tuple(mods) + (None,) * (4 - len(mods)), "pa": pa, "dob": ctx["dob"],
            "ptype": _ptype_raw(rng, st), "btype": _ptype_raw(rng, bt)}


def sc_pair(b, rng, ctx, rule):
    p = rule["predicate"]
    form, pt, bt = _route_for(rng, rule)
    pt_b, bt_b = (pt, bt) if rng.random() < 0.85 else _route_for(rng, rule)[1:]   # mostly the same provider types
    ca = b.claim()
    cb = ca if rng.random() < 0.5 else b.claim()
    x = rng.random()
    prov_b = ctx["prov"] if x < 0.7 else (rng.choice(["P1", "P2", "P3", "P9"]) if x < 0.88 else None)
    ma, mb = _pair_mods(rng)
    units_a = rng.choice(["1", "1", "1", "2", "0", None]) if rng.random() < 0.2 else "1"
    paid_a = rng.choice(["0.00", "12.00"]) if rng.random() < 0.15 else rng.choice(PAID_POOL[:7])
    la_no = rng.choice([1, 1, 1, 2, 3])
    b.add(ctx, ca, la_no, p["code_a"], units=units_a, paid=paid_a, form=form, mods=ma, ptype=pt, btype=bt)
    row_b = b.add(ctx, cb, la_no + 1 if cb == ca else 1, p["code_b"], sprov=prov_b,
                  units=rng.choice(["1", "1", "2", "0.5"]), paid=rng.choice(PAID_POOL[:7]),
                  form=form if rng.random() < 0.9 else rng.choice(FORMS_RAW), mods=mb, ptype=pt_b, btype=bt_b)
    if rng.random() < (0.12 if is_ncci(rule) else 0.35):     # (v2.2) the code_b line again, ANOTHER billing type (A13/A17)
        nd = dict(row_b)
        nd["btype"] = _ptype_raw(rng, rng.choice([c for c in ("02", "08", "C2", "01", "30", "07", None, "ZZ", "43")
                                                  if c != clean_prov_type(row_b["btype"])]))
        b.rows.append(nd)
    if indicator_of(p) == "1" and rng.random() < 0.2:       # v2.3 / A17: one code_b line booked twice (anatomic m1 /
        c0 = b.claim()                                       # m2; state rules: two billing types) pairing with two
        m1, m2 = rng.sample(sorted(ANATOMIC), 2)            # DIFFERENT code_a lines -> ONE finding, evidence = union
        bt2 = bt if is_ncci(rule) else rng.choice([x for x in ("02", "08", "C2", None, "30") if x != bt])
        b.rows += [_plain_row(rng, ctx, c0, 1, p["code_a"], form, pt, bt, [m1]),
                   _plain_row(rng, ctx, c0, 2, p["code_a"], form, pt, bt, [m2], paid="11.00"),
                   _plain_row(rng, ctx, c0, 3, p["code_b"], form, pt, bt, [m1], pa=rng.choice([None, "PA4"])),
                   _plain_row(rng, ctx, c0, 3, p["code_b"], form, pt, bt2, [m2])]
    if rng.random() < 0.08:                                  # S06: the code_b line again with another PA / units /
        nd = dict(row_b)                                     # modifiers, same provider types -> one finding
        nd["pa"] = rng.choice(["PA9", " pa1 ", None, ""])
        nd["units"] = U(rng.choice(["1", "2", "3", "0.5"]))
        nd["mods"] = _place_mods(rng, [rng.choice(MOD_NOISE + ["59", "25", "LT"])]) if rng.random() < 0.5 else row_b["mods"]
        b.rows.append(nd)
    if rng.random() < 0.2:                                   # a second code_b line (own claim)
        b.add(ctx, b.claim(), rng.choice([1, 3, None]), p["code_b"], units="1", paid="15.00", form=form,
              mods=_pair_mods(rng)[1], ptype=pt, btype=bt)
    if rng.random() < 0.25:                                  # a second code_a line
        pt2, bt2 = (pt, bt) if rng.random() < 0.8 else _route_for(rng, rule)[1:]
        b.add(ctx, rng.choice([ca, b.claim()]), rng.choice([3, 4, None, 10, 12]), p["code_a"], units="1", paid="11.00",
              form=form, mods=_pair_mods(rng)[0], ptype=pt2, btype=bt2)
    if rng.random() < 0.05:                                  # same claim id + line number as the code_b line
        b.add(ctx, cb, la_no + 1 if cb == ca else 1, p["code_a"], units="1", paid="9.00", form=form, ptype=pt,
              btype=bt)
    if rng.random() < 0.06:                                  # both lines on one claim, both line numbers missing
        c0 = b.claim()
        for code in (p["code_a"], p["code_b"]):
            row = b.add(ctx, c0, None, code, units="1", paid="8.00", form=form, ptype=pt, btype=bt)
            row["line"], row["claim"] = None, c0
    if rng.random() < 0.05:                                  # a second code_a ROW with the SAME claim id + line
        b.add(ctx, ca, la_no, p["code_a"], units="1", paid="11.00", form=form, mods=ma, ptype=pt, btype=bt)
    if rng.random() < 0.04:                                  # code_a line with a missing claim id
        row = b.add(ctx, None, rng.choice([1, None]), p["code_a"], units="1", paid="6.00", form=form, ptype=pt,
                    btype=bt)
        row["claim"] = None


N4_NOISE_MODS = ["25", "GT", "HN", "U1", "95", "TF"]


def _n4_row(b, rng, ctx, claim, line, code, units, paid, mods=(), pa=None):
    """A daily-cap row of the N4 case: no random damage (the case must form), cosmetic spellings only; the context's
    member, servicing provider, billing provider id and date, so the rows share one group under every scope."""
    prov = ctx["prov"]
    st = b.ptype_of.get(prov) or _pick_ptype(rng)
    return {"claim": claim, "line": line, "member": _pad(rng, ctx["member"], 0.08), "sprov": _pad(rng, prov, 0.1),
            "bprov": _pad(rng, ctx.get("bprov", "B1"), 0.12), "dos": ctx["dos"], "code": _vary(rng, code, 0.2),
            "units": None if units is None else U(units), "paid": P(paid), "pos": rng.choice(["11", "12", None]),
            "form": rng.choice(FORMS_RAW), "mods": _place_mods(rng, [_vary(rng, m, 0.3) for m in mods]), "pa": pa,
            "dob": ctx["dob"], "ptype": _ptype_raw(rng, st), "btype": _ptype_raw(rng, _pick_btype(rng, st))}


def sc_daily_cancelled_long_line(b, rng, ctx, rule):
    """(v2.6, N4) The case §3's payable-lines-only reading decides, for one member / servicing provider / billing
    provider id / date: a cancelled LONG line (units > threshold) carrying listed modifiers, its exact reversal (§1: same
    member, provider, date, code and modifiers - spelled differently -, units booked either sign, paid negated) and
    other PAYABLE lines over the cap together, each alone at or under it and with no listed modifier: neither
    verify_span nor verify_modifier may come from the cancelled line or its reversal. Now and then: the cancelled line
    at or under the cap (modifiers only), a payable line alone over the cap (verify_span), a payable line with a listed
    modifier (verify_modifier), a PA (verify_pa), an orphan reversal or a paid line with 0 / negative units carrying a
    listed modifier (counted, never payable) - each with a payable line that keeps the sum over the cap."""
    p = rule["predicate"]
    codes = sorted(rule_codes(p))
    code = rng.choice(codes)
    thr = Decimal(int(p["threshold"]))
    listed = sorted(DAILY_CAP_MODIFIERS_SPEC)
    claim = b.claim()
    long_ = rng.random() < 0.85
    lu = thr + Decimal(rng.choice(["0.5", "1", "2", "5"])) if long_ else max(Decimal("0.5"), thr - Decimal(rng.choice(["0", "0.5"])))
    lmods = rng.sample(listed, rng.choice([1, 1, 2])) + ([rng.choice(N4_NOISE_MODS)] if rng.random() < 0.2 else [])
    line = _n4_row(b, rng, ctx, claim, 1, code, lu, rng.choice(["40.00", "33.33", "120.00", "9.99", "250.00"]), lmods)
    rev = _reversal(b, rng, line, exact=True)                # cancels `line` (§1); its own claim id / line number
    rev["pa"] = None if rng.random() < 0.9 else rng.choice(PA_RAW)
    rows = [line, rev]
    COVER["n4_generated:cancelled_" + ("LONG" if long_ else "short") + "_line_with_listed_modifiers+reversal"] += 1
    parts, tot = [], Decimal(0)
    while tot <= thr:                                        # payable lines over the cap together, each alone <= thr
        u = min(thr, rng.choice([thr, thr, thr - Decimal("0.5"), Decimal("0.5"), Decimal(1), Decimal(2)]))
        u = u if u > 0 else Decimal("0.5")
        parts.append(u)
        tot += u
    for i, u in enumerate(parts):
        mods = [rng.choice(N4_NOISE_MODS)] if rng.random() < 0.35 else []
        rows.append(_n4_row(b, rng, ctx, claim if rng.random() < 0.6 else b.claim(), i + 2,
                            code if rng.random() < 0.8 else rng.choice(codes), u, rng.choice(PAID_POOL[:7]), mods))
    x = rng.random()
    if x < 0.15:                                             # control: a payable line alone over the cap -> span
        rows.append(_n4_row(b, rng, ctx, b.claim(), 1, code, thr + 1, "45.00", []))
        COVER["n4_generated:control_payable_line_over_the_cap"] += 1
    elif x < 0.35:                                           # control: a payable line with a listed modifier
        rows[2]["mods"] = _place_mods(rng, [_vary(rng, rng.choice(listed), 0.3)])
        COVER["n4_generated:control_payable_line_with_listed_modifier"] += 1
    if rng.random() < 0.25:                                  # an orphan reversal (cancels nothing) with a listed modifier
        rows.append(_n4_row(b, rng, ctx, b.claim(), 1, code, rng.choice(["-0.5", "0.5", "-1"]), "-3.00",
                            [rng.choice(listed)]))
        rows.append(_n4_row(b, rng, ctx, b.claim(), 1, code, 1, "11.00", []))
        COVER["n4_generated:orphan_reversal_with_listed_modifier"] += 1
    if rng.random() < 0.25:                                  # a paid line with 0 / negative units and a listed modifier
        rows.append(_n4_row(b, rng, ctx, b.claim(), 1, code, rng.choice(["0", "-1"]), "5.00", [rng.choice(listed)]))
        rows.append(_n4_row(b, rng, ctx, b.claim(), 1, code, 1, "11.00", []))
        COVER["n4_generated:paid_line_with_units<=0_and_listed_modifier"] += 1
    if rng.random() < 0.1:                                   # control: a PA (verify_pa beats both labels)
        rows[-1]["pa"] = rng.choice(["PA9", " pa1 "])
        COVER["n4_generated:control_PA"] += 1
    b.rows.extend(rows)


def sc_units_group(b, rng, ctx, rule, by_provider):
    p = rule["predicate"]
    if rng.random() < 0.3:                                   # (v2.6, N4) the payable-lines-only case
        sc_daily_cancelled_long_line(b, rng, ctx, rule)
        return
    codes = sorted(rule_codes(p))
    thr = int(p["threshold"])
    target = max(1, thr + rng.choice([-1, 0, 0, 1, 1, 2]))
    n = rng.randint(1, 4)
    cuts = sorted(rng.sample(range(1, target * 2), k=min(n - 1, target * 2 - 1))) if n > 1 else []
    parts = [y - x for x, y in zip([0] + cuts, cuts + [target * 2])]          # halves, so 0.5 units appear
    claims = [b.claim() for _ in range(rng.randint(1, 2))]
    for i, part in enumerate(parts):
        u = Decimal(part) / 2
        if rng.random() < 0.08:
            u = None
        prov = ctx["prov"]
        if rng.random() < (0.3 if by_provider else 0.2):
            prov = rng.choice(["P1", "P2", "P3", None])
        line = i + 1 if rng.random() < 0.8 else rng.choice([10, 11, 20])
        mods = ()
        if rng.random() < 0.22:                              # (v2.6, A27) a modifier the daily-cap label looks at, or not
            mods = (_vary(rng, rng.choice(sorted(DAILY_CAP_MODIFIERS_SPEC) + ["25", "GT", "HN", "U1", "95"]), 0.3),)
        b.add(ctx, rng.choice(claims), line, rng.choice(codes), sprov=prov, units=u, mods=mods)


def sc_period(b, rng, ctx, rule, exact_date=False):
    p = rule["predicate"]
    codes = sorted(rule_codes(p))
    d = ctx["dos"]
    if p["period"] == "benefit_year":
        anchor = D(d.year, 10, 1)
    elif p["period"] == "year":
        anchor = D(d.year, 1, 1)
    else:
        anchor = D(d.year, d.month, 1)
    claim = b.claim()
    for i in range(rng.randint(2, 6)):
        when = d if exact_date else anchor + rng.randint(-20, 20) * DAY
        b.add(ctx, claim if rng.random() < 0.5 else b.claim(), i + 1, rng.choice(codes), dos=when,
              units=rng.choice(["1", "1", "2", "2", "3", "0.5", None]), mods=())


def sc_mue(b, rng, ctx, rule):
    p = rule["predicate"]
    thr = int(p["threshold"])
    later = p.get("later_max_threshold")
    choices = [thr - 1, thr, thr + 1, thr + 0.5, thr + 2, thr + 3]
    if later is not None:
        choices += [later, later + 1, later + 0.5]
    u = max(Decimal("0.5"), Decimal(str(rng.choice(choices))))
    mods = [rng.choice(MOD_NOISE + ["59", "RT"])] if rng.random() < 0.2 else []
    form, pt, bt = _route_for(rng, rule)
    b.add(ctx, b.claim(), 1, p["code"], units=u, form=form, mods=mods, ptype=pt, btype=bt)


def sc_not_covered(b, rng, ctx, rule):
    b.add(ctx, b.claim(), 1, rng.choice(sorted(rule_codes(rule["predicate"]))), mods=())


def sc_pta(b, rng, ctx, rule):
    """provider_type_allowed (v2.2 / v2.6): lines of the code(s) whose JUDGED type (judged_type) is in the list (spelled
    oddly by add()), missing, unmapped, or not in the list while the other type is; (v2.6) lines billed under a GROUP
    type (config.GROUP_BILLING_PROVIDER_TYPES; _ptype_raw spells '01' as '1', ' 01 ', '01.0' ...) whose rendering type is
    allowed, not allowed or missing - mostly for billing_or_rendering rules, now and then for the other roles (which
    judge the group type itself); $0 / zero-unit / negative-unit lines come from the default pools, cancellations from
    gen_claimset; sometimes the same line twice with two billing types (A13)."""
    p = rule["predicate"]
    codes = sorted(rule_codes(p))
    allowed = sorted(pta_allowed(p))
    role = pta_role(p)
    groups = sorted(group_types()) or ["01"]
    not_listed = [c for c in PTA_LISTABLE + ["8.5", "N/A"] if c not in allowed] or ["ZZ"]
    claim = b.claim()
    row = None
    for i in range(rng.randint(1, 3)):
        st, bt = _pick_pair_types(rng)
        y = rng.random()
        if y < (0.35 if role == "billing_or_rendering" else 0.1):      # (v2.6) a GROUP bills the line
            bt = rng.choice(groups)
            z = rng.random()
            st = rng.choice(allowed) if z < 0.4 and allowed else None if z < 0.55 else rng.choice(not_listed)
            COVER[f"pta_generated:group_billed_line(role {role})"] += 1
        elif y < 0.55 and allowed:                           # the judged type IS in the list
            t = rng.choice(allowed)
            st, bt = (t, bt) if role == "servicing" else (st, t)
        elif y < 0.65:                                       # the judged type is missing: never a finding
            st, bt = (None, bt) if role == "servicing" else (st, None)
        elif y < 0.75 and allowed:                           # the OTHER type is in the list, the judged one is not
            o = rng.choice([c for c in PTA_LISTABLE + ["8.5", "N/A", None] if c not in allowed] or ["ZZ"])
            t = rng.choice(allowed)
            st, bt = (o, t) if role == "servicing" else (t, o)
        code = rng.choice(codes)
        if code in ALLOW_ALL_CODES:                          # every type present gets listed: keep them listable
            st, bt = ("008" if st in UNLISTABLE else st), ("008" if bt in UNLISTABLE else bt)
        row = b.add(ctx, claim, i + 1, code, ptype=st, btype=bt, mods=(), form=rng.choice(FORMS_RAW + ["D"]))
    if row is not None and rng.random() < 0.2:               # the same line again with ANOTHER billing type
        nd = dict(row)
        nd["btype"] = _ptype_raw(rng, rng.choice([c for c in ("02", "08", "C2", "01", "30", "07", None, "ZZ", "05")
                                                  if c != clean_prov_type(row["btype"])]))
        b.rows.append(nd)


def sc_noise(b, rng, ctx, rules):
    claim = b.claim()
    for i in range(rng.randint(1, 3)):
        b.add(ctx, claim, i + 1, rng.choice(NOISE_CODES), mods=[rng.choice(MOD_NOISE)] if rng.random() < 0.2 else [])


def run_scenario(b, rng, ctx, rule):
    t = rule["predicate"]["type"]
    if t == "code_pair_prohibited":
        sc_pair(b, rng, ctx, rule)
    elif t in ("max_units_per_day", "max_units_per_dos"):
        sc_units_group(b, rng, ctx, rule, t == "max_units_per_dos")
    elif t == "max_units_per_period":
        sc_period(b, rng, ctx, rule, exact_date=True)
    elif t == "max_units_per_line":
        sc_mue(b, rng, ctx, rule)
    elif t == "provider_type_allowed":
        sc_pta(b, rng, ctx, rule)
    else:
        sc_not_covered(b, rng, ctx, rule)


# §1 Cancelled line (v2.3): the tie columns, in order, and the CLEANED values a copy of one claim line can take
TIE_COLUMNS = CANCEL_ORDER[2:]                     # form, pa, ptype, btype, bprov, dob
TIE_VALUES = {"form": [None, "", "A", "O", "D"], "pa": [None, "PA9", "pa1", "PA10"],
              "ptype": [None, "02", "08", "C2", "ZZ", "07", "8.5"], "btype": [None, "01", "02", "08", "C2", "ZZ", "07", "30"],
              "bprov": [None, "B1", "B2", "b1"], "dob": [None, D(1990, 1, 1), D(2010, 5, 5), D(2004, 2, 29)]}


def _raw_tie(rng, col, v):
    """A raw spelling that cleans to v (form: trimmed + upper-cased, '' stays ''; PA / billing provider id: trimmed,
    NOT upper-cased, blank = missing; provider types: the type clean-up)."""
    if col in ("ptype", "btype"):
        return _ptype_raw(rng, v)
    if col == "dob":
        return v
    if col == "form":
        if v is None:
            return None
        return rng.choice(["", " ", "  "]) if v == "" else rng.choice([v, v.lower(), " " + v, v + " "])
    return rng.choice([None, "", "  "]) if v is None else rng.choice([v, " " + v, v + " "])


def _tie_candidates(rules):
    return [r for r in rules if r["predicate"]["type"] in ("max_units_per_line", "provider_type_allowed",
                                                            "code_not_covered", "code_pair_prohibited")
            and r["rule_id"] not in ALLOW_ALL_RULES and not (r["predicate"].get("code") and r["predicate"].get("code_set"))
            and not (is_ncci(r) and not r["predicate"].get("ncci_edition"))
            and not (r["predicate"]["type"] == "provider_type_allowed" and bad_entries(r["predicate"]))]


def sc_tie(b, rng, ctx, rules):
    """(v2.3) ONE claim line booked 2-3 times - same claim id, line number and offset columns (member, provider, date,
    code, modifiers, units, paid) - the copies equal on the tie columns BEFORE a chosen one, distinct on it, free after
    it; plus ONE exact reversal (sometimes two). §1's tie order decides which copy is cancelled, and with it the line's
    edit file (NCCI findings), its provider-type finding, its PA (severity) and its age (date of birth)."""
    rule = rng.choice(_tie_candidates(rules))
    p = rule["predicate"]
    t = p["type"]
    code = p["code_b"] if t == "code_pair_prohibited" else rng.choice(sorted(rule_codes(p)))
    units = str(int(p["threshold"]) + rng.choice([1, 2])) if t == "max_units_per_line" else rng.choice(["1", "2", "0.5"])
    decider = rng.choice(TIE_COLUMNS)
    i = TIE_COLUMNS.index(decider)
    n = rng.choice([2, 2, 2, 3])
    common = {c: rng.choice(TIE_VALUES[c]) for c in TIE_COLUMNS[:i]}
    claim, line = b.claim(), rng.choice([1, 2, 3, 10, None])
    mods = tuple(rng.choice([None, None, "59", "LT"]) for _ in range(1)) + (None, None, None)
    base = {"claim": claim, "line": line, "member": ctx["member"], "sprov": ctx["prov"], "dos": ctx["dos"], "code": code,
            "units": U(units), "paid": P(rng.choice(PAID_POOL[:7])), "pos": "11", "mods": mods}
    copies = []
    for v in rng.sample(TIE_VALUES[decider], n):
        vals = dict(common, **{decider: v})
        vals.update({c: rng.choice(TIE_VALUES[c]) for c in TIE_COLUMNS[i + 1:]})
        if code in ALLOW_ALL_CODES:
            vals["ptype"] = "008" if vals["ptype"] in UNLISTABLE else vals["ptype"]
        row = dict(base, **{c: _raw_tie(rng, c, vals[c]) for c in TIE_COLUMNS})
        copies.append(row)
    b.rows.extend(copies)
    COVER[f"tie_generated:copies_differ_first_in_{decider}"] += 1
    for _ in range(1 if rng.random() < 0.85 else 2):
        b.rows.append(_reversal(b, rng, copies[0], exact=True))
    if t == "code_pair_prohibited":                          # the code_a line the copies pair with
        form, st, bt = _route_for(rng, rule)
        b.add(ctx, claim, (line or 0) + 20, p["code_a"], units="1", paid="12.00", form=form, ptype=st, btype=bt,
              mods=(), pa=None)


def sc_orphan_reversal(b, rng, ctx, rule):
    """A reversal-like row with POSITIVE units and nothing it offsets: counted, never payable."""
    codes = sorted(rule_codes(rule["predicate"])) or [rule["predicate"].get("code_b") or rule["predicate"]["code"]]
    b.add(ctx, b.claim(), 1, rng.choice(codes), units=str(int(rule["predicate"].get("threshold", 1)) + 1),
          paid="-20.00", mods=())


def _reversal(b, rng, r, exact):
    rv = dict(r)
    if rng.random() < 0.8:
        rv["claim"], rv["line"] = b.claim(), rng.choice([1, 1, 2, None])
    else:
        rv["line"] = (r["line"] or 0) + 50
    # §1 v2: a reversal's units count as -|units|, so -u and +u both offset a line of u units
    rv["units"] = None if r["units"] is None else (-r["units"] if rng.random() < 0.6 else abs(r["units"]))
    rv["paid"] = -r["paid"]
    rv["ptype"] = _ptype_raw(rng, clean_prov_type(r.get("ptype")), 0.5) if rng.random() < 0.8 else _pick_ptype(rng)
    # (v2.2) the billing type is not part of the offset key either: a reversal may carry another one
    rv["btype"] = (_ptype_raw(rng, clean_prov_type(r.get("btype")), 0.5) if rng.random() < 0.8
                   else _ptype_raw(rng, _pick_pair_types(rng)[1]))
    rv["code"] = _vary(rng, _upper(_trim(r["code"])), 0.3)
    rv["mods"] = tuple(_vary(rng, _upper(_blank_null(m)), 0.3) if _blank_null(m) else rng.choice([None, "", " "])
                       for m in r["mods"])
    rv["sprov"] = _pad(rng, _blank_null(r["sprov"]), 0.2) if _blank_null(r["sprov"]) else rng.choice([None, ""])
    rv["member"] = _pad(rng, _blank_null(r["member"]), 0.2)
    rv["form"] = rng.choice(FORMS_RAW)                       # not part of the offset key
    rv["pa"] = rng.choice(PA_RAW)
    rv["pos"] = rng.choice(["11", None])
    if not exact:
        kind = rng.choice(["units", "paid", "prov", "mod", "date", "units_null", "units_other"])
        if kind == "units":
            rv["units"] = U(-(r["units"] or 0) - 1)
        elif kind == "paid":
            rv["paid"] = -r["paid"] + P("0.01")
        elif kind == "prov":
            rv["sprov"] = "P8" if _blank_null(r["sprov"]) else "P1"
        elif kind == "mod":
            rv["mods"] = ("XU" if _upper(_blank_null(r["mods"][0])) != "XU" else "59",) + tuple(rv["mods"][1:])
        elif kind == "date":
            rv["dos"] = (r["dos"] or D(2024, 1, 1)) + DAY
        elif kind == "units_null":
            rv["units"] = None if r["units"] is not None else U("-1")
        else:                                                # |reversal units| differs from the line's units
            rv["units"] = U(abs(r["units"] or 0) + 2) * rng.choice([1, -1])
    return rv


def gen_claimset(seed: int, prefix: str, rules: list) -> list:
    rng = random.Random(seed)
    b = _Builder(rng, prefix)
    by_type = defaultdict(list)
    for r in rules:
        by_type[r["predicate"]["type"]].append(r)
    scen = [("pair", 6), ("day", 3), ("dos", 2), ("period", 3), ("line", 3), ("nc", 1), ("pta", 3), ("tie", 2),
            ("noise", 1)]
    age_rules = [r for r in rules if r["predicate"].get("age")]
    for i in range(rng.randint(4, 7)):
        focus = None                                         # (rule, dates) whose age boundary this member sits on
        provs = rng.sample(["P1", "P2", "P3"], k=rng.randint(1, 2))
        if rng.random() < 0.12:
            provs.append("p1")                               # a DIFFERENT provider id (ids are not upper-cased)
        agencies = rng.sample(["B1", "B2", "B3"], k=rng.randint(1, 2))     # (v2.6) the member's billing provider ids
        dates = rng.sample(POOL_DATES, k=rng.randint(3, 5)) + [D(2023, 9, 1) + rng.randint(0, 790) * DAY
                                                              for _ in range(rng.randint(0, 2))]
        x = rng.random()
        if x < 0.4 and age_rules:                            # birthday of an age rule ON / next to a visit date
            ar = rng.choice(age_rules)
            years = int(rng.choice([v for v in ar["predicate"]["age"].values()]))
            anchor = rng.choice(dates)
            dob = add_years(anchor, -years) + rng.choice([-1, 0, 0, 1]) * DAY
            dates += [anchor - DAY, anchor + DAY]
            focus = (ar, {anchor - DAY, anchor, anchor + DAY})
        elif x < 0.55 and age_rules:                         # 29 Feb birthday at the age of an age rule
            ar = rng.choice(age_rules)
            years = int(rng.choice([v for v in ar["predicate"]["age"].values()]))
            y = rng.choice([2025, 2025, 2023])                # non-leap years: birthday falls on 28 Feb
            dob = D(y - years, 2, 29) if calendar.isleap(y - years) else D(y - years, 2, 28)
            feb = {D(y, 2, 27), D(y, 2, 28), D(y, 3, 1)}
            dates += sorted(feb)
            focus = (ar, feb)
        else:
            dob = pick_dob(rng)
        member = f"{prefix}M{i}" if rng.random() > 0.08 else f"{prefix}m{i}"   # 'm' and 'M' are two members
        for d in sorted(dates):
            for _ in range(rng.randint(1, 3)):
                ctx = {"member": member if rng.random() > 0.1 else f"{prefix}M{i}", "dob": dob, "dos": d,
                       "prov": rng.choice(provs), "bprov": rng.choice(agencies)}
                if focus and d in focus[1] and rng.random() < 0.7:
                    run_scenario(b, rng, ctx, focus[0])
                    continue
                if rng.random() < 0.015:
                    sc_orphan_reversal(b, rng, ctx, rng.choice(rules))
                    continue
                kind = rng.choices([k for k, _ in scen], weights=[w for _, w in scen])[0]
                if kind == "pair":
                    sc_pair(b, rng, ctx, rng.choice(by_type["code_pair_prohibited"]))
                elif kind == "day":
                    sc_units_group(b, rng, ctx, rng.choice(by_type["max_units_per_day"]), False)
                elif kind == "dos":
                    sc_units_group(b, rng, ctx, rng.choice(by_type["max_units_per_dos"]), True)
                elif kind == "period":
                    sc_period(b, rng, ctx, rng.choice(by_type["max_units_per_period"]))
                elif kind == "line":
                    sc_mue(b, rng, ctx, rng.choice(by_type["max_units_per_line"]))
                elif kind == "nc":
                    sc_not_covered(b, rng, ctx, rng.choice(by_type["code_not_covered"]))
                elif kind == "pta":
                    sc_pta(b, rng, ctx, rng.choice(by_type["provider_type_allowed"]))
                elif kind == "tie":
                    sc_tie(b, rng, ctx, rules)
                else:
                    sc_noise(b, rng, ctx, rules)
    base = list(b.rows)
    out = list(base)
    for r in base:                                           # reversals (most exact, some not)
        if r["paid"] is not None and r["paid"] > 0 and r["code"] and rng.random() < 0.14:
            out.append(_reversal(b, rng, r, exact=rng.random() < 0.72))
    for r in base:                                           # several identical lines + one (or two) reversals
        if r["paid"] is not None and r["paid"] > 0 and r["code"] and rng.random() < 0.05:
            for _ in range(rng.randint(1, 2)):
                twin = dict(r)
                x = rng.random()
                if x < 0.45:                                 # another claim (C10 sorts before C9)
                    twin["claim"], twin["line"] = b.claim(), rng.choice([1, 2, None])
                elif x < 0.85:                               # same claim, other line (NULL / 10+ / small)
                    twin["line"] = rng.choice([None, 10, 12, 1, 3]) if r["line"] is not None else rng.choice([1, 2, 10])
                else:                                        # missing claim id
                    twin["claim"], twin["line"] = None, rng.choice([1, None])
                twin["pa"] = rng.choice(PA_RAW)
                twin["form"] = rng.choice([r["form"], "A", "O"])
                if rng.random() < 0.3:                       # (v2.2) the twin billed under ANOTHER billing type:
                    twin["btype"] = _ptype_raw(rng, rng.choice(BILLING_ALT))   # same offset key, other edit file
                out.append(twin)
            for _ in range(1 if rng.random() < 0.75 else 2):
                out.append(_reversal(b, rng, r, exact=True))
    for r in list(out):                                      # exact duplicates
        if rng.random() < 0.06:
            out.append(dict(r))
    for r in list(out):                                      # duplicates after clean-up only
        if rng.random() < 0.04:
            nd = dict(r)
            nd["code"] = _vary(rng, _upper(_trim(r["code"])), 1.0)
            nd["mods"] = tuple(_vary(rng, _upper(_blank_null(m)), 0.6) if _blank_null(m) else rng.choice([None, "", " "])
                               for m in r["mods"])
            nd["form"] = _vary(rng, _upper(_trim(r["form"])), 0.6)
            nd["member"] = _pad(rng, _blank_null(r["member"]), 0.6) if _blank_null(r["member"]) else r["member"]
            nd["sprov"] = _pad(rng, _blank_null(r["sprov"]), 0.6) if _blank_null(r["sprov"]) else rng.choice([None, ""])
            nd["pa"] = _pad(rng, _blank_null(r["pa"]), 0.6) if _blank_null(r["pa"]) else rng.choice([None, "", " "])
            nd["ptype"] = _ptype_raw(rng, clean_prov_type(r.get("ptype")), 0.8)
            nd["btype"] = _ptype_raw(rng, clean_prov_type(r.get("btype")), 0.8)     # ' 2' / '2.0' / 'c2': one row
            out.append(nd)
    for r in list(out):                                      # (v2.2, A13) the same row with ANOTHER billing type:
        if rng.random() < 0.03:                              # a kept column -> two snapshot rows
            nd = dict(r)
            cur = clean_prov_type(r.get("btype"))
            nd["btype"] = _ptype_raw(rng, rng.choice([c for c in BILLING_ALT if c != cur]))
            out.append(nd)
    for r in list(out):                                      # same row, different POS (POS is not cleaned)
        if rng.random() < 0.01:
            nd = dict(r)
            nd["pos"] = " 11" if r["pos"] != " 11" else "99"
            out.append(nd)
    rng.shuffle(out)
    # v2.3: the cancellation order is total (§1), so tied (claim id, line number) copies are KEPT as generated - they
    # are test cases now; nothing may tie on every column of the order (that would be a de-duplication error)
    assert not unresolved_cancellation_ties(out), "rows tie on every column of the v2.3 cancellation order"
    return out


def _window(rng):
    x = rng.random()
    d1, d2 = sorted(rng.sample(POOL_DATES, 2))
    if x < 0.4:
        return None, None
    if x < 0.6:
        return d1.isoformat(), None
    if x < 0.8:
        return None, d2.isoformat()
    return d1.isoformat(), d2.isoformat()


def _age(rng, p=0.5):
    if rng.random() >= p:
        return None
    return rng.choice([{"min": 21}, {"below": 21}, {"min": 21}, {"below": 21}, {"min": 18, "below": 65}, {"min": 65},
                       {"below": 18}])


def _quals(rng):
    q = {}
    if rng.random() < 0.3:
        q["exception"] = EXCEPTION_TEXT
    if rng.random() < 0.35:
        q["discretionary"] = True
    elif rng.random() < 0.1:
        q["discretionary"] = False
    return q


def gen_rules(seed: int) -> list:
    rng = random.Random(seed * 7919 + 13)
    rules = []

    def state(rid, pred, origin="extracted"):
        eff, end = _window(rng)
        age = _age(rng)
        if age:
            pred["age"] = age
        pred.update(_quals(rng))
        rules.append({"rule_id": rid, "origin": origin, "machine_checkable": True, "effective_date": eff,
                      "end_date": end, "predicate": pred})

    for i, (a, b_) in enumerate(STATE_PAIRS):
        pred = {"type": "code_pair_prohibited", "code_a": a, "code_b": b_,
                "modifier_indicator": rng.choice(["0", None, "0"]) if i == 0 else "1"}
        sc = rng.choice([None, "member_day", "member_provider_day", PAIR_MSB])
        if sc:
            pred["scope"] = sc
        state(f"S-PAIR{i + 1}", pred, origin=rng.choice(["extracted", "manual"]))
    # (v2.6, A25) a state pair that always uses member_servicing_billing_day
    state("S-PAIR-MSB", {"type": "code_pair_prohibited", "code_a": MSB_PAIR[0], "code_b": MSB_PAIR[1],
                         "modifier_indicator": rng.choice(["0", "1"]), "scope": PAIR_MSB},
          origin=rng.choice(["extracted", "manual"]))
    dayset = {"type": "max_units_per_day", "code_set": list(DAY_SET), "threshold": rng.randint(2, 5)}
    sc = rng.choice(DAY_SCOPES)                              # (v2.5 / v2.6) the cap's scope; absent = member_day
    if sc:
        dayset["scope"] = sc
    state("S-DAYSET", dayset)
    day = {"type": "max_units_per_day", "code": DAY_CODE, "threshold": rng.randint(1, 3)}
    if rng.random() < 0.4:
        day["form_typ"] = "A"                                # spec: STATE rules apply to every form regardless
    sc = rng.choice(DAY_SCOPES)
    if sc:
        day["scope"] = sc
    state("S-DAY", day)
    state("S-DAY-MSB", {"type": "max_units_per_day", "code": MSB_DAY_CODE, "threshold": rng.randint(1, 4),
                        "scope": PAIR_MSB})                  # (v2.6, A26)
    # schema: max_units_per_dos takes ONE code (a code_set is rejected by validate_predicate)
    state("S-DOS", {"type": "max_units_per_dos", "code": rng.choice(DOS_CODES), "threshold": rng.randint(2, 5)})
    for code, period in PERIOD_RULES:
        thr = {"month": rng.randint(2, 6), "year": rng.randint(4, 10), "benefit_year": rng.randint(3, 9)}[period]
        state(f"S-PER-{code.split(',')[0]}", {"type": "max_units_per_period", "code_set": code.split(","),
                                              "threshold": thr, "period": period})
    nc1 = {"type": "code_not_covered", "code": NC_CODE}
    if rng.random() < 0.5:
        nc1["service_category"] = rng.choice(["dme", "behavioral_health"])   # real extracted predicates carry it
    state("S-NC1", nc1)
    state("S-NC2", {"type": "code_not_covered", "code_set": list(NC_SET)})
    state("S-LINE", {"type": "max_units_per_line", "code": STATE_LINE[0], "threshold": STATE_LINE[1]})
    probe_scope = rng.random() < 0.5
    pairs = [(a, b_, ind, ed, f"N-{a}-{b_}") for a, b_, ind, ed in NCCI_PAIRS]
    # the same pair in ANOTHER edit file with the other indicator (CMS repeats edits across PRA / OPH / DME files), and
    # the same pair twice in one file with successive windows (an edit deleted then re-added with a new indicator)
    pairs += [("99213", "97110", "0", "outpatient", "N-99213-97110-O"),
              ("11111", "22222", "1", "outpatient", "N-11111-22222-O"),
              ("11111", "22222", "0", "dme", "N-11111-22222-D")]
    split = rng.choice(POOL_DATES)
    for a, b_, ind, ed, rid in pairs:
        eff, end = _window(rng)
        if rid == "N-20610-J3490":
            eff, end = "2020-01-01", split.isoformat()
        pred = {"type": "code_pair_prohibited", "code_a": a, "code_b": b_, "modifier_indicator": ind, "ncci_edition": ed}
        if probe_scope and rid == "N-99213-97110":
            pred["scope"] = rng.choice(["member_day", PAIR_MSB])   # spec: NCCI is ALWAYS member_provider_day
        rules.append({"rule_id": rid, "origin": "ncci", "machine_checkable": True,
                      "effective_date": eff or "2020-01-01", "end_date": end, "predicate": pred})
    rules.append({"rule_id": "N-20610-J3490-b", "origin": "ncci", "machine_checkable": True,
                  "effective_date": (split + DAY).isoformat(), "end_date": None,
                  "predicate": {"type": "code_pair_prohibited", "code_a": "20610", "code_b": "J3490",
                                "modifier_indicator": "1", "ncci_edition": "outpatient"}})
    mues = [(code, thr, ed, f"M-{code}") for code, thr, ed in NCCI_MUES]
    mues += [("J3490", 3, "outpatient", "M-J3490-O"), ("97110", 2, "outpatient", "M-97110-O"),
             ("J3490", 2, "dme", "M-J3490-D")]
    for code, thr, ed, rid in mues:
        eff, end = _window(rng)
        if rid == "M-J1100":
            eff, end = None, split.isoformat()
        pred = {"type": "max_units_per_line", "code": code, "threshold": thr, "ncci_edition": ed}
        x = rng.random()
        if x < 0.3:
            pred["later_max_threshold"] = thr + rng.randint(1, 3)
        elif x < 0.45:
            pred["later_max_threshold"] = max(1, thr - 1)    # a later quarter LOWERED it: not a relabel
        elif x < 0.7:
            pred["removed_later"] = True
        rules.append({"rule_id": rid, "origin": "ncci", "machine_checkable": True,
                      "effective_date": eff, "end_date": end, "predicate": pred})
    rules.append({"rule_id": "M-J1100-b", "origin": "ncci", "machine_checkable": True,     # MUE value changed
                  "effective_date": (split + DAY).isoformat(), "end_date": None,
                  "predicate": {"type": "max_units_per_line", "code": "J1100", "threshold": 2,
                                "ncci_edition": "practitioner"}})
    if rng.random() < 0.5:                                   # A12 probe: a legacy NCCI rule with form_typ only -> lead
        rules.append({"rule_id": "N-LEGACY-FORM", "origin": "ncci", "machine_checkable": True,
                      "effective_date": "2020-01-01", "end_date": None,
                      "predicate": {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222",
                                    "modifier_indicator": "0", "form_typ": "A"}})
    # probes: a predicate with BOTH code and code_set (v2: invalid -> must be a lead, F-04); rule codes written in
    # lower case / with spaces (schema.norm_code accepts them, so they validate)
    if rng.random() < 0.5:
        state("S-DAY-CODE+SET", {"type": "max_units_per_day", "code": "98961", "code_set": ["98962"],
                                 "threshold": rng.randint(2, 4)})
    else:
        state("S-NC-LOWER", {"type": "code_not_covered", "code_set": [" 00938", "99070 "]})
        state("S-PAIR-LOWER", {"type": "code_pair_prohibited", "code_a": "h2018 ", "code_b": " h2014",
                               "modifier_indicator": "0"})

    # ---- provider_type_allowed (v2.2): code or code_set; provider_types spelled ' 2 ', '2', 2, 'c2', '08 ' (A16);
    # provider_role absent / None / '' / billing / servicing; window, age, exception, "may" via state(); PA, $0 and
    # cancelled lines come from the claims. S-PTA-ALL lists every type present on its code's lines (zero findings).
    def pta(rid, codes, base=None, entries=None, role=None):
        pred = {"type": "provider_type_allowed"}
        if len(codes) == 1 and rng.random() < 0.65:
            pred["code"] = codes[0] if rng.random() < 0.8 else " " + codes[0].lower()
        else:
            pred["code_set"] = list(codes)
        if base is None:
            base = rng.sample(PTA_LISTABLE, rng.randint(1, 6))
            if rng.random() < 0.6:                           # a type the generator uses a lot: allowed lines too
                base.append(rng.choice(["08", "02", "C2", "01", "07", "30"]))
        pred["provider_types"] = entries if entries is not None else [_list_spelling(rng, c)
                                                                      for c in dict.fromkeys(base)]
        if role is None:                                     # (v2.6) billing_or_rendering too (A28)
            role = rng.choice(["absent", None, "", "billing", "billing", "servicing", "servicing", "servicing",
                               "billing_or_rendering", "billing_or_rendering", "billing_or_rendering"])
        if role != "absent":
            pred["provider_role"] = role
        state(rid, pred, origin=rng.choice(["extracted", "manual"]))

    pta("S-PTA1", PTA_OWN["S-PTA1"])
    pta("S-PTA2", PTA_OWN["S-PTA2"])
    pta("S-PTA3", [rng.choice(PTA_SHARED)])
    pta("S-PTA-ALL", PTA_OWN["S-PTA-ALL"], base=["08"])     # provider_types filled in by build_round
    # (v2.6, A28) always billing_or_rendering: a group's line is judged on its rendering practitioner's type
    pta("S-PTA-GRP", PTA_OWN["S-PTA-GRP"], base=rng.sample(RENDERING_TYPES, rng.randint(2, 4)),
        role="billing_or_rendering")
    # (v2.3) every entry written as a number - 8, 8.0, '8.0', ' 8 ', '08.00' - compiles and means 08
    nums = rng.sample(["08", "02", "01", "07", "05", "04", "10", "31", "19", "30", "43", "71", "77", "29"],
                      rng.randint(2, 5))
    pta("S-PTA-NUM", [rng.choice(PTA_SHARED + PTA_OWN["S-PTA1"] + PTA_OWN["S-PTA2"])],
        entries=[rng.choice([int(c), float(int(c)), f"{int(c)}.0", f" {int(c)} ", f"{c}.00", f" {c}.0"]) for c in nums])
    # (v2.3) one blank / non-alphanumeric / too long entry among good ones -> the rule is a lead (never a guess)
    good = [_list_spelling(rng, c) for c in rng.sample(PTA_LISTABLE, rng.randint(0, 3))]
    good.insert(rng.randint(0, len(good)), rng.choice(BAD_ENTRIES))
    pta("S-PTA-BAD", PTA_OWN["S-PTA1"], entries=good)
    # (v2.3) a textual null among good entries ('None', 'nan', ' NULL ', 'NONE', NaN ...) is MISSING -> a lead (A20)
    good = [_list_spelling(rng, c) for c in rng.sample(PTA_LISTABLE, rng.randint(0, 3))]
    good.insert(rng.randint(0, len(good)), NULL_ENTRIES[seed % len(NULL_ENTRIES)])
    pta("S-PTA-NULL", PTA_OWN["S-PTA2"], entries=good)
    if rng.random() < 0.3:                                   # F-04 for the new type: code AND code_set -> a lead
        state("S-PTA-CODE+SET", {"type": "provider_type_allowed", "code": "G0466", "code_set": ["99490"],
                                 "provider_types": ["08"]})
    return rules


def fill_allow_all(rules, raw, rng):
    """S-PTA-ALL: provider_types = every (listable) type the rule's role JUDGES on its code's rows in the round ((v2.6)
    billing_or_rendering judges a group line's servicing type), plus two more, each in a random spelling -> the oracle
    must expect zero findings (asserted in run_round)."""
    for rule in rules:
        if rule["rule_id"] not in ALLOW_ALL_RULES:
            continue
        p = rule["predicate"]
        codes = rule_codes(p)
        role = pta_role(p)

        def jt(r):
            return judged_type({"btype": clean_prov_type(r.get("btype")), "ptype": clean_prov_type(r.get("ptype"))},
                               role)[0]
        rows = [r for r in raw if _upper(_trim(r["code"])) in codes]
        present = {jt(r) for r in rows} - {None}
        listable = {t for t in present if not bad_entries({"provider_types": [t]})}
        paid_lines = {jt(r) for r in rows if r["paid"] is not None and r["paid"] > 0} - {None}
        assert paid_lines <= listable, f"unlistable type on a paid {rule['rule_id']} line: {paid_lines - listable}"
        p["provider_types"] = [_list_spelling(rng, c) for c in sorted(listable | set(rng.sample(PTA_LISTABLE, 2)))]


# ===================================================================================== the SPARK side (black box)
CLAIMS_TABLE = "spark_catalog.prod_input.all_data_c_a"
SNAPSHOT_TABLE = "spark_catalog.policy_kb.policy_claims_snapshot"
PTP_TABLE = "spark_catalog.policy_kb.policy_ncci_ptp_edits"
MUE_TABLE = "spark_catalog.policy_kb.policy_ncci_mue_limits"
BUILD_ID = "BX"


def point_detector_gen_at_test_tables():
    dg.CLAIMS, dg.DETECT = CLAIMS_TABLE, SNAPSHOT_TABLE
    dg.PTP_EDITS_TABLE, dg.MUE_LIMITS_TABLE = PTP_TABLE, MUE_TABLE
    config.TABLE_FORMAT = "parquet"


def make_spark(warehouse):
    from pyspark.sql import SparkSession
    return (SparkSession.builder.master("local[1]").appName("pie-sql-oracle")
            .config("spark.driver.memory", "1200m")
            .config("spark.sql.shuffle.partitions", "1")
            .config("spark.default.parallelism", "1")
            .config("spark.sql.ansi.enabled", "true")
            .config("spark.sql.session.timeZone", "UTC")
            .config("spark.ui.enabled", "false")
            .config("spark.ui.showConsoleProgress", "false")
            .config("spark.sql.execution.arrow.pyspark.enabled", "false")
            .config("spark.sql.warehouse.dir", warehouse)
            .config("spark.local.dir", os.path.join(warehouse, "_local"))
            .config("spark.driver.extraJavaOptions", "-XX:+UseSerialGC -Dderby.system.home=" + warehouse)
            .getOrCreate())


def claims_schema():
    from pyspark.sql.types import DateType, DecimalType, IntegerType, StringType, StructField, StructType
    s = StringType()
    return StructType([
        StructField(C["claim_id"], s), StructField(C["line_no"], IntegerType()), StructField(C["member"], s),
        StructField(C["servicing_provider"], s), StructField(C["billing_provider"], s),
        StructField(C["dos"], DateType()), StructField(C["code"], s), StructField(C["units"], DecimalType(15, 4)),
        StructField(C["paid_amt"], DecimalType(15, 2)), StructField(C["pos"], s), StructField(C["form"], s),
        *[StructField(m, s) for m in C["mods"]], StructField(C["pa_no"], s), StructField(C["dob"], DateType()),
        StructField(C["prov_type"], s), StructField(C["billing_type"], s)])


def write_claims(spark, raw_rows):
    tuples = [(r["claim"], r["line"], r["member"], r["sprov"], r["bprov"], r["dos"], r["code"], r["units"],
               r["paid"], r["pos"], r["form"], *r["mods"], r["pa"], r["dob"], r.get("ptype"), r.get("btype"))
              for r in raw_rows]
    spark.createDataFrame(tuples, claims_schema()).write.mode("overwrite").format("parquet").saveAsTable(CLAIMS_TABLE)


def run_sql(spark, sql):
    return [r.asDict(recursive=True) for r in spark.sql(sql).collect()]


def setup_schemas(spark):
    spark.sql("CREATE SCHEMA IF NOT EXISTS spark_catalog.prod_input")
    spark.sql("CREATE SCHEMA IF NOT EXISTS spark_catalog.policy_kb")


# ===================================================================================== comparison
def _q2(x):
    return None if x is None else Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _num(x):
    return None if x is None else Decimal(str(x)).normalize() + 0


def parse_evidence(s):
    if s is None:
        return None
    if isinstance(s, (list, tuple)):
        return tuple(s)
    return tuple(s.split(",")) if s != "" else ()


FIELDS = {
    "code_pair_prohibited": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk",
                             "evidence", "col1", "servicing_provider", "form_typ", "pair_scope"),
    "max_units_per_line": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk",
                           "observed_units", "allowed_units", "excess_units", "servicing_provider", "form_typ"),
    # (v2.3) Not covered and provider type allowed: observed = the line's units, allowed = 0, excess = observed; no
    # evidence lines (NULL or empty both count as none)
    "code_not_covered": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk",
                         "observed_units", "allowed_units", "excess_units", "servicing_provider", "form_typ",
                         "has_evidence"),
    "provider_type_allowed": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk",
                              "observed_units", "allowed_units", "excess_units", "servicing_provider", "form_typ",
                              "has_evidence", "finding_form"),
    "max_units_per_day": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk",
                          "observed_units", "allowed_units", "excess_units", "evidence", "servicing_provider",
                          "billing_provider"),
    "max_units_per_period": ("finding_severity", "finding_basis", "pa_present", "paid_amt", "paid_at_risk",
                             "observed_units", "allowed_units", "excess_units", "evidence", "period_end"),
    "signal": ("window_start", "window_end", "rolling_units", "rolling_paid", "allowed_units", "rolling_days"),
}
FIELDS["max_units_per_dos"] = FIELDS["max_units_per_day"]


# Known deviations of the current SQL from the spec. v1 had F-01..F-04; all four are fixed in v2 (QUERY_SEMANTICS
# version 2). v2.2 had F-05 (a state pair merged the rows of one code_b line that take different edit files, while the
# v2.1 text said separate findings): resolved IN THE SPEC by v2.3 ("the edit file never splits a finding"), so the merge
# is now the oracle's normal reading (A17) and the comparison is strict on everything. A deviation belongs here with a
# repro: id -> {"what", "spec", "repro", "impact"}, plus an exact transformation in apply_deviations() and a strict
# xfail test asserting the spec behaviour.
KNOWN_DEVIATIONS: dict = {}
ACTIVE_DEVIATIONS: set = set(KNOWN_DEVIATIONS)


def apply_deviations(rule, exp, snap, impact):
    """The oracle's expectation transformed EXACTLY as each active known deviation changes it (everything else stays
    strict); impact counts what each deviation changes. None active in v2.3."""
    return exp


def oracle_record(f):
    """(key, {field: comparable value}) for one oracle finding."""
    rid = f["rule_id"]
    if f["kind"] == "signal":
        return (rid, f["key"][0]), {
            "window_start": f["window_start"], "window_end": f["window_end"], "rolling_units": _num(f["rolling_units"]),
            "rolling_paid": _q2(f["rolling_paid"]), "allowed_units": _num(f["allowed_units"]),
            "rolling_days": f["rolling_days"]}
    key = (rid,) + tuple(f["key"])
    v = {"finding_severity": f["finding_severity"], "finding_basis": f["finding_basis"],
         "pa_present": f["pa_present"], "paid_amt": _q2(f["paid_amt"]), "paid_at_risk": _q2(f["paid_at_risk"])}
    for k in ("observed_units", "allowed_units", "excess_units"):
        if k in f:
            v[k] = _num(f[k])
    if "evidence" in f:
        v["evidence"] = tuple(ev_str(e) for e in f["evidence"])
    if "col1" in f:
        v["col1"] = f["col1"]
    for k in ("servicing_provider", "form_typ", "period_end", "has_evidence", "pair_scope", "billing_provider",
              "finding_form"):
        if k in f:
            v[k] = f[k]
    return key, v


def sql_record(ptype, rid, row, rule=None):
    """(key, values) of one SQL finding row. Daily caps are keyed by (rule, member, servicing id, billing id, date) as the
    rule's scope groups them (v2.5 / v2.6); a column the statement does not output reads as NULL (A26)."""
    if ptype == "signal":
        return (rid, row["member_id"]), {
            "window_start": row["window_start"], "window_end": row["window_end"],
            "rolling_units": _num(row["rolling_units"]), "rolling_paid": _q2(row["rolling_paid"]),
            "allowed_units": _num(row["allowed_units"]), "rolling_days": row["rolling_days"]}
    if ptype in ("code_pair_prohibited", "max_units_per_line", "code_not_covered", "provider_type_allowed"):
        key = (rid, row["claim_id"], row["line_no"], row["member_id"], row["dos"])
    elif ptype in ("max_units_per_day", "max_units_per_dos"):
        sc = daily_scope(rule) if rule is not None else (
            "member_provider_day" if ptype == "max_units_per_dos" else "member_day")
        key = (rid, row["member_id"], row.get("servicing_provider") if sc != "member_day" else None,
               row.get("billing_provider") if sc == PAIR_MSB else None, row["dos"])
    else:
        key = (rid, row["member_id"], row["period_start"])
    v = {"finding_severity": row["finding_severity"], "finding_basis": row["finding_basis"],
         "pa_present": None if row.get("pa_present") is None else bool(row["pa_present"]),
         "paid_amt": _q2(row["paid_amt"]), "paid_at_risk": _q2(row["paid_at_risk"]),
         "observed_units": _num(row.get("observed_units")), "allowed_units": _num(row.get("allowed_units")),
         "excess_units": _num(row.get("excess_units")), "evidence": parse_evidence(row.get("evidence_lines")),
         "col1": (row.get("col1_claim_id"), row.get("col1_line_no")),
         "servicing_provider": row.get("servicing_provider"), "form_typ": row.get("form_typ"),
         "period_end": row.get("period_end"), "has_evidence": bool(parse_evidence(row.get("evidence_lines"))),
         "pair_scope": row.get("pair_scope"), "billing_provider": row.get("billing_provider"),
         "finding_form": (finding_form(row.get("finding"), sorted(rule_codes(rule["predicate"])) if rule else [])
                          if ptype == "provider_type_allowed" else None)}
    return key, v


def compare(query, ptype, expected, got_rows, rid_of=None, rule_of=None):
    """Multiset comparison keyed by the natural key; then field by field. Returns a list of mismatch dicts. rule_of(rid)
    gives the rule (its daily scope keys the groups; its codes check the provider-type finding text)."""
    fields = FIELDS[ptype]
    exp, got = defaultdict(list), defaultdict(list)
    for f in expected:
        k, v = oracle_record(f)
        exp[k].append(v)
    for row in got_rows:
        rid = rid_of(row) if rid_of else query["rule_id"]
        k, v = sql_record(ptype, rid, row, rule_of(rid) if rule_of else None)
        got[k].append(v)
    out = []
    for k in sorted(set(exp) | set(got), key=repr):
        e, g = exp.get(k, []), got.get(k, [])
        if len(e) != len(g):
            out.append({"query": query["name"], "ptype": ptype, "type": "count", "key": k, "oracle": len(e),
                        "sql": len(g), "oracle_rows": e, "sql_rows": [{f: x.get(f) for f in fields} for x in g]})
            continue
        es = sorted(([x.get(f) for f in fields] for x in e), key=repr)
        gs = sorted(([x.get(f) for f in fields] for x in g), key=repr)
        for ev_, gv in zip(es, gs):
            for f, a, b in zip(fields, ev_, gv):
                if a != b:
                    out.append({"query": query["name"], "ptype": ptype, "type": "field", "key": k, "field": f,
                                "oracle": a, "sql": b})
    return out


SNAP_COLS = ("claim", "line", "member", "sprov", "bprov", "dos", "code", "cunits", "units", "paid", "form", "mods",
             "pa", "dob", "ptype", "btype", "edition", "cancelled", "reversal", "payable")


def snapshot_tuples_oracle(snap):
    return Counter(tuple(_num(r[c]) if c in ("units", "cunits") and r[c] is not None else r[c] for c in SNAP_COLS)
                   for r in snap)


def snapshot_tuples_sql(spark):
    out = Counter()
    for r in spark.table(SNAPSHOT_TABLE).collect():
        d = r.asDict()
        out[(d[C["claim_id"]], d[C["line_no"]], d[C["member"]], d[C["servicing_provider"]],
             d[C["billing_provider"]], d[C["dos"]], d[C["code"]], _num(d[C["units"]]), _num(d[dg.PIE_UNITS_RAW]),
             d[C["paid_amt"]], d[C["form"]], tuple(d[m] for m in C["mods"]), d[C["pa_no"]], d[dg.PIE_DOB],
             d[dg.PIE_PROV_TYPE], d[dg.PIE_BPROV_TYPE], d[dg.PIE_EDITION], d[dg.PIE_CANCELLED], d[dg.PIE_REVERSAL],
             d[dg.PIE_PAYABLE])] += 1
    return out


def compare_snapshot(spark, snap):
    exp, got = snapshot_tuples_oracle(snap), snapshot_tuples_sql(spark)
    out = []
    for k in sorted(set(exp) | set(got), key=repr):
        if exp.get(k, 0) != got.get(k, 0):
            out.append({"query": "snapshot", "ptype": "snapshot", "type": "count", "key": k,
                        "oracle": exp.get(k, 0), "sql": got.get(k, 0)})
    return out


# ===================================================================================== one round
def build_round(rnd, n_sets):
    rules = gen_rules(rnd)
    raw = []
    for k in range(n_sets):
        raw += gen_claimset(rnd * 1000 + k, f"r{rnd}s{k}", rules)
    fill_allow_all(rules, raw, random.Random(rnd * 31 + 7))
    return rules, raw


def run_round(spark, rules, raw, stats=None, impact=None):
    """Write the claims, build the snapshot, run every per-rule query, every signal query and both NCCI batch
    statements; compare everything with the oracle. Returns the list of mismatches."""
    import contextlib
    import io
    import kb_io
    stats = stats if stats is not None else Counter()
    impact = impact if impact is not None else Counter()
    write_claims(spark, raw)
    with contextlib.redirect_stdout(io.StringIO()):          # create_snapshot prints its SQL; not read here
        dg.create_snapshot(spark, source=dg.CLAIMS, target=dg.DETECT, fmt="parquet")
    snap = build_snapshot(raw)
    mism = compare_snapshot(spark, snap)
    stats["claim_rows"] += len(raw)
    stats["snapshot_rows"] += len(snap)
    by_id = {r["rule_id"]: r for r in rules}
    dets = dg.build_detectors(rules)
    for d in dets:
        rule = by_id[d["rule_id"]]
        ptype = rule["predicate"]["type"]
        p_ = rule["predicate"]
        lead_reason, reason_text = None, None                       # reason_text: what the lead's reason must say
        if p_.get("code") not in (None, "") and p_.get("code_set"):
            lead_reason = reason_text = "both code and code_set"    # F-04 fix: not a valid predicate any more
        elif is_ncci(rule) and not p_.get("ncci_edition"):
            lead_reason = reason_text = "no ncci_edition"           # A12
        elif ptype == "provider_type_allowed" and bad_entries(p_):
            lead_reason = f"bad provider_types entry {bad_entries(p_)!r}"   # §2 v2.3 (the spec names no reason text)
            for v in bad_entries(p_):
                COVER["pta_rule_with_a_bad_entry_must_be_a_lead:" + repr(v)] += 1
        if lead_reason:
            stats["leads_asserted"] += 1
            if d.get("sql") or d.get("compiled") or (reason_text and reason_text not in (d.get("reason") or "")):
                mism.append({"query": d["rule_id"], "ptype": ptype, "type": "must_be_a_lead", "key": lead_reason,
                             "oracle": "lead", "sql": d.get("reason") or "compiled"})
            continue
        if ptype == "provider_type_allowed":
            for kind in sorted({_entry_kind(v) for v in p_["provider_types"]}):
                COVER[f"pta_rule_expected_to_compile_has_an_entry_spelled:{kind}"] += 1
        if not d.get("sql"):
            mism.append({"query": d["rule_id"], "ptype": ptype, "type": "not_compiled", "key": d.get("reason")})
            continue
        exp = apply_deviations(rule, oracle_findings(rule, snap), snap, impact)
        if rule["rule_id"] in ALLOW_ALL_RULES:               # generator self-check: every type present is listed
            assert not exp, f"{rule['rule_id']} lists every type present yet the oracle expects {len(exp)} findings"
            n_lines = sum(1 for r in snap if r["code"] in rule_codes(p_) and r["payable"])
            COVER["pta_allow_all_rule:queries_expecting_zero_findings"] += 1
            COVER["pta_allow_all_rule:payable_lines_of_its_code(none may be flagged)"] += n_lines
        if ptype == "provider_type_allowed":
            stats[f"pta_queries:{pta_role(p_)}"] += 1
        got = run_sql(spark, d["sql"])
        mism += compare({"name": d["rule_id"], "rule_id": d["rule_id"]}, ptype, exp, got, rule_of=by_id.get)
        stats["queries"] += 1
        stats["findings_oracle"] += len(exp)
        stats["findings_sql"] += len(got)
        stats[f"findings:{ptype}{'/ncci' if is_ncci(rule) else ''}"] += len(exp)
        if ptype == "max_units_per_period":
            if not d.get("signal_sql"):
                mism.append({"query": d["rule_id"] + ":signal", "ptype": "signal", "type": "no_signal_sql",
                             "key": None})
            else:
                sexp = oracle_signal(rule, snap)
                sgot = run_sql(spark, d["signal_sql"])
                mism += compare({"name": d["rule_id"] + ":signal", "rule_id": d["rule_id"]}, "signal", sexp, sgot)
                stats["queries"] += 1
                stats["signal_rows_oracle"] += len(sexp)
                stats["signal_rows_sql"] += len(sgot)
    # ---- NCCI batch statements (all edit rows at once), with decoy rows of another build that must be ignored.
    # Only rules build_detectors accepted go to the edit tables (as in notebook 07).
    compiled = {d["rule_id"] for d in dets if d.get("compiled")}
    ncci = [r for r in rules if is_ncci(r) and r["rule_id"] in compiled]
    ptp, mue = dg.ncci_edit_tables(ncci)
    decoy_p, decoy_m = ptp.copy(), mue.copy()
    decoy_p["rule_id"] = "Y" + decoy_p["rule_id"]
    decoy_m["rule_id"] = "Y" + decoy_m["rule_id"]
    ptp["build_id"], decoy_p["build_id"] = BUILD_ID, "BY"
    mue["build_id"], decoy_m["build_id"] = BUILD_ID, "BY"
    import pandas as pd
    with contextlib.redirect_stdout(io.StringIO()):
        kb_io.write_table(spark, pd.concat([ptp, decoy_p], ignore_index=True), PTP_TABLE, "overwrite")
        kb_io.write_table(spark, pd.concat([mue, decoy_m], ignore_index=True), MUE_TABLE, "overwrite")
    for name, sql, ptype in (("BATCH_PTP", dg.batch_ptp_sql(build_id=BUILD_ID), "code_pair_prohibited"),
                             ("BATCH_MUE", dg.batch_mue_sql(build_id=BUILD_ID), "max_units_per_line")):
        exp = [f for r in ncci if r["predicate"]["type"] == ptype
               for f in apply_deviations(r, oracle_findings(r, snap), snap, Counter())]
        got = run_sql(spark, sql)
        mism += compare({"name": name, "rule_id": None}, ptype, exp, got, rid_of=lambda row: row["rule_id"],
                        rule_of=by_id.get)
        stats["queries"] += 1
        stats["findings_oracle"] += len(exp)
        stats["findings_sql"] += len(got)
    return mism



# ===================================================================================== pytest: oracle self-checks
def _r(claim, line, code, units="1", paid="10.00", member="M1", sprov="P1", form="A", mods=(), pa=None,
       dob=D(1990, 1, 1), dos=D(2024, 3, 5), pos="11", ptype="08", btype=None, bprov="B1"):
    return {"claim": claim, "line": line, "member": member, "sprov": sprov, "bprov": bprov, "dos": dos, "code": code,
            "units": U(units), "paid": P(paid), "pos": pos, "form": form,
            "mods": tuple(mods) + (None,) * (4 - len(mods)), "pa": pa, "dob": dob, "ptype": ptype, "btype": btype}


def _state(rid, pred, **kw):
    d = {"rule_id": rid, "origin": "extracted", "machine_checkable": True, "effective_date": None, "end_date": None,
         "predicate": pred}
    d.update(kw)
    return d


def _ncci(rid, pred, eff="2020-01-01", end=None):
    return {"rule_id": rid, "origin": "ncci", "machine_checkable": True, "effective_date": eff, "end_date": end,
            "predicate": pred}


DEFAULT_ROUTING = ("billing_provider_type", (), "none")      # spec v2.4 defaults (checked against config below)
UNMAPPED_FORM = ("billing_provider_type", (), "form")        # §1a step 3 switch "form" (the default until v2.3)
UNMAPPED_NONE = DEFAULT_ROUTING                               # step 3 "none" = the default since v2.4
ROUTE_PT = ("provider_type", (), "none")
ROUTE_PT_FORM = ("provider_type", (), "form")
OO_ON = ("billing_provider_type", ("other_outpatient",), "none")
BOTH_ON = ("billing_provider_type", ("testing_facility", "other_outpatient"), "none")
BY_FORM = ("form", (), "none")

# §1a v2.2 / v2.4, computed by hand from the spec's steps and Table 2: (form, servicing, billing, routing config) -> file
ROUTING_EXAMPLES = [
    ("A", "07", "07", DEFAULT_ROUTING, "practitioner"),   # dentist on a CMS-1500 (Table 2 footnote 14)
    ("D", "07", "07", DEFAULT_ROUTING, None),             # dental claim: no file whatever the provider
    ("A", "08", "02", DEFAULT_ROUTING, "outpatient"),     # hospital bills a physician's service
    ("A", "02", "08", DEFAULT_ROUTING, "practitioner"),   # the billing type picks, not the servicing one
    ("A", "01", "01", DEFAULT_ROUTING, "practitioner"),   # group billing ID: still a practitioner claim
    ("A", "08", "C2", DEFAULT_ROUTING, None),             # FQHC: optional row off -> none (A18: no fall-back)
    ("A", "08", "C2", OO_ON, "practitioner"),             # ... on: rendering practitioner identified
    ("A", "01", "C2", OO_ON, "outpatient"),               # ... 01 is not a person: not identified
    ("A", "02", "ZZ", DEFAULT_ROUTING, "outpatient"),     # billing unmapped -> the servicing type picks
    ("A", "30", None, DEFAULT_ROUTING, "dme"),            # billing missing -> the servicing type picks
    ("O", "30", None, DEFAULT_ROUTING, "dme"),
    ("O", "ZZ", "ZZ", DEFAULT_ROUTING, None),             # v2.4: both unmapped -> NO file (step 3 default "none")
    ("O", "ZZ", "ZZ", UNMAPPED_FORM, "outpatient"),       # ... step 3 "form": form O -> outpatient
    ("A", "08", "02", ROUTE_PT, "practitioner"),          # "provider_type": the billing type is ignored
    ("A", "08", "03", DEFAULT_ROUTING, None),             # A18: pharmacy billing type is in the table -> its row
    ("A", "07", "D4", DEFAULT_ROUTING, None),             # dental clinic billing a dentist's CMS-1500 line
    ("O", "08", "C2", OO_ON, "outpatient"),               # UB-04 column: outpatient whoever renders
    ("A", None, "C2", OO_ON, "outpatient"),               # missing servicing type: not identified
    ("A", "07", "77", OO_ON, "practitioner"),             # a dentist IS an individual practitioner
    ("A", "ZZ", "05", OO_ON, "outpatient"),
    ("A", "C2", "C2", OO_ON, "outpatient"),               # the clinic as its own servicing provider
    ("A", "08", "04", DEFAULT_ROUTING, None),             # testing facility: optional row off
    ("A", "08", "04", BOTH_ON, "practitioner"),
    ("O", "08", "04", BOTH_ON, "practitioner"),
    ("A", "08", "C2", ("billing_provider_type", ("testing_facility",), "none"), None),   # only the other row on
    ("O", "08", "43", DEFAULT_ROUTING, "practitioner"),   # ASC on a UB-04 -> practitioner file
    ("O", "08", "08", DEFAULT_ROUTING, "outpatient"),
    ("A", None, None, DEFAULT_ROUTING, None),             # v2.4: both missing -> no file
    ("A", None, None, UNMAPPED_FORM, "practitioner"),     # ... step 3 "form"
    ("A", "008", "8.5", DEFAULT_ROUTING, None),           # A11: both unmapped -> no file (v2.4) ...
    ("A", "008", "8.5", UNMAPPED_FORM, "practitioner"),   # ... or form A under step 3 "form"
    ("O", None, "ZZ", BOTH_ON, None),                     # optional rows on change nothing for unknown types
    ("O", "30", "02", BY_FORM, "outpatient"),             # "form" ignores both types
    ("A", "43", "30", BY_FORM, "practitioner"),
    ("A", None, None, BY_FORM, "practitioner"),           # "form" mode: step 3 never applies
    ("A", None, None, ("form", (), "form"), "practitioner"),
    ("D", "08", "08", BY_FORM, None),
    ("A", "C2", "08", ROUTE_PT, None),                    # "provider_type": servicing C2 picks, row off
    ("A", "C2", "08", ("provider_type", ("other_outpatient",), "none"), "outpatient"),   # servicing never identified
    ("O", None, "02", ROUTE_PT, None),                    # billing ignored -> servicing missing -> step 3: none
    ("O", None, "02", ROUTE_PT_FORM, "outpatient"),       # ... step 3 "form"
    ("C", "30", "30", DEFAULT_ROUTING, None), (None, "08", "08", DEFAULT_ROUTING, None),
    ("", None, None, DEFAULT_ROUTING, None), ("", None, None, UNMAPPED_FORM, None),     # form '' is not A / O
]


def test_oracle_self_checks_against_hand_computed_spec_examples():
    """The oracle itself, on cases computed by hand from QUERY_SEMANTICS.md version 2.2 (no Spark needed)."""
    # §1a: the routing table (140 codes; the 79 servicing codes seen in all_data_C_A on 2026-10-03) and every code the
    # generator hard-codes, re-checked against it (v2.2: 07 Dentist is a practitioner)
    rows = load_routing_rows()
    assert len(rows) == 140 and sum(r["in_claims_2026_10_03"] == "yes" for r in rows) == 79
    assert (PROV_TYPE_CATEGORY["07"], PROV_TYPE_CATEGORY["01"]) == ("practitioner", "practitioner")
    for cat, codes in PTYPES.items():
        bad = [c for c in codes if PROV_TYPE_CATEGORY.get(c) != cat]
        assert not bad, (cat, bad)
    assert all(PROV_TYPE_CATEGORY[c] == "practitioner" for c in INDIVIDUALS) and "01" not in INDIVIDUALS
    assert all(PROV_TYPE_CATEGORY[c] == "outpatient_hospital" for c in HOSPITALS)
    assert all(PROV_TYPE_CATEGORY[c] == "other_outpatient" for c in CLINICS)
    assert all(c is None or c == "ZZ" or c in PROV_TYPE_CATEGORY for c in BILLING_ALT)
    assert not set(ODD_PTYPES) & set(PROV_TYPE_CATEGORY) and not UNLISTABLE & set(PTA_LISTABLE)
    # §1 / §2 v2.3 (A20, A24): NONE / NAN / NULL in any case are MISSING in both columns and as entries; near-null
    # texts are codes ('NA' is a real AHCCCS type)
    assert [clean_prov_type(x) for x in ("None", " nan ", "NULL", "Null ", " NaN", "NA", "NANA", "NUL", "N/A")] == \
        [None, None, None, None, None, "NA", "NANA", "NUL", "N/A"]
    assert [clean_entry(x) for x in ("None", " nan ", "NULL", float("nan"), None, "  ", 8.0, "na")] == \
        [None, None, None, None, None, None, "08", "NA"]
    assert PROV_TYPE_CATEGORY["NA"] == "other_outpatient"
    snap = build_snapshot([_r("C1", 1, "X1", ptype="02", btype="None"), _r("C1", 2, "X1", ptype=" nan ", btype="NULL"),
                           _r("C1", 3, "X1", ptype="02", btype="NA")], cover=False, cfg=DEFAULT_ROUTING)
    assert {r["line"]: (r["ptype"], r["btype"], r["edition"]) for r in snap} == \
        {1: ("02", None, "outpatient"), 2: (None, None, None), 3: ("02", "NA", None)}      # 2: both missing (v2.4)
    assert routing_config() == DEFAULT_ROUTING, routing_config()          # config defaults = the spec's
    assert [clean_prov_type(x) for x in ("8", "8.0", " c2 ", "", None, "10.0", "08.0", "8.5", "008", "1", " 2", "2.0",
                                         "c2", "  ")] == \
        ["08", "08", "C2", None, None, "10", "08", "8.5", "008", "01", "02", "02", "C2", None]
    for form, s, bl, cfg, want in ROUTING_EXAMPLES:
        assert edit_file(form, s, bl, cfg) == want, (form, s, bl, cfg, want)
    # the snapshot routes each row with its CLEANED types (' 2' = 02 -> hospital; 'c2' = FQHC)
    snap = build_snapshot([_r("C1", 1, "X1", ptype="8", btype=" 2"), _r("C1", 2, "X1", ptype="08", btype="c2"),
                           _r("C1", 3, "X1", ptype="8.0", btype="  ", form="o"), _r("C1", 4, "X1", ptype="7",
                                                                                     btype="7.0", form="D")],
                          cover=False, cfg=DEFAULT_ROUTING)
    assert {r["line"]: (r["btype"], r["edition"]) for r in snap} == \
        {1: ("02", "outpatient"), 2: ("C2", None), 3: (None, "outpatient"), 4: ("07", None)}
    cfg = DEFAULT_ROUTING
    # ADD_MONTHS birthdays (§2): 29 Feb -> 28 Feb in a non-leap year
    assert add_years(D(2004, 2, 29), 21) == D(2025, 2, 28) and add_years(D(2004, 2, 29), 20) == D(2024, 2, 29)
    age21 = _state("A", {"type": "code_not_covered", "code": "X1", "age": {"min": 21}})
    below21 = _state("B", {"type": "code_not_covered", "code": "X1", "age": {"below": 21}})
    on_bd = dict(clean_row(_r("C", 1, "X1", dob=D(2004, 2, 29), dos=D(2025, 2, 28))), edition="practitioner")
    no_dob = dict(clean_row(_r("C", 1, "X1", dob=None)), edition="practitioner")
    assert in_scope(age21, on_bd) and not in_scope(below21, on_bd)
    assert not in_scope(age21, no_dob) and not in_scope(below21, no_dob)
    # clean-up + duplicates (incl. provider type spelling) + drops
    snap = build_snapshot([_r("C1", 1, " x1 ", mods=(" lt", ""), ptype="8"), _r("C1", 1, "X1", mods=("LT", None)),
                           _r("C2", 1, "X1", member="  "), _r("C3", 1, "  ")], cover=False, cfg=cfg)
    assert len(snap) == 1 and snap[0]["code"] == "X1" and snap[0]["ptype"] == "08"
    # §1 v2: a reversal with POSITIVE units counts -|units| and still offsets (cancels) its line
    snap = build_snapshot([_r("C2", 1, "X1", units="3", paid="30.00"), _r("C10", 1, "X1", units="3", paid="30.00"),
                           _r("R1", 1, "X1", units="3", paid="-30.00")], cover=False, cfg=cfg)
    st = {r["claim"]: (r["cancelled"], r["payable"], r["cunits"]) for r in snap}
    assert st == {"C2": (False, True, 3), "C10": (True, False, 3), "R1": (False, False, -3)}
    # daily cap: the positive-unit reversal nets out (v1 counted +3 -> 6 units)
    rule = _state("D", {"type": "max_units_per_day", "code": "X1", "threshold": 4})
    snap = build_snapshot([_r("C1", 1, "X1", units="3", paid="30.00"), _r("R1", 1, "X1", units="3", paid="-30.00")],
                          cover=False, cfg=cfg)
    assert oracle_units_per_day(rule, snap) == []
    # evidence: distinct, by (claim, line NUMBER), missing first and written empty; Column One = first
    snap = build_snapshot([_r("C1", 12, "H2018"), _r("C1", 3, "H2018", paid="11.00"), _r("C1", None, "H2018", paid="12.00"),
                           _r(None, 5, "H2018", paid="13.00"), _r("C1", 4, "H2014")], cover=False, cfg=cfg)
    f, = oracle_pair(_state("P", {"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2014"}), snap)
    assert [ev_str(e) for e in f["evidence"]] == [":5", "C1:", "C1:3", "C1:12"] and f["col1"] == (None, 5)
    # pa_present: NULL for NCCI, 0 / 1 for state
    n = _ncci("N", {"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2014", "modifier_indicator": "0",
                    "ncci_edition": "practitioner"})
    snap = build_snapshot([_r("C1", 1, "H2018", pa="PA1"), _r("C1", 2, "H2014")], cover=False, cfg=cfg)
    assert [x["pa_present"] for x in oracle_pair(n, snap)] == [None]
    # modifier indicator 1 (§2)
    a = clean_row(_r("C", 1, "99213", mods=("25",)))
    b = clean_row(_r("C", 2, "97110"))
    assert pair_bypassed(a, b, "1") and not pair_bypassed(a, b, "0")
    assert not pair_bypassed(clean_row(_r("C", 1, "99201", mods=("25",))), b, "1")
    assert not pair_bypassed(clean_row(_r("C", 1, "11111", mods=("LT",))), clean_row(_r("C", 2, "2", mods=("LT",))), "1")
    assert pair_bypassed(clean_row(_r("C", 1, "11111", mods=("LT", "59"))), clean_row(_r("C", 2, "2", mods=("LT",))), "1")
    # daily cap dollars and periods
    snap = build_snapshot([_r("C1", 1, "X1", units="2"), _r("C1", 2, "X1", units="2", paid="20.00")], cover=False, cfg=cfg)
    f, = oracle_units_per_day(_state("D", {"type": "max_units_per_day", "code": "X1", "threshold": 3}), snap)
    assert (f["observed_units"], f["paid_amt"], f["paid_at_risk"]) == (Decimal(4), Decimal("30.00"), Decimal("7.5"))
    assert period_bounds(D(2024, 9, 30), "benefit_year") == (D(2023, 10, 1), D(2024, 9, 30))
    assert period_bounds(D(2024, 10, 1), "benefit_year") == (D(2024, 10, 1), D(2025, 9, 30))
    # ---- provider_type_allowed (§2 v2.2 / v2.3, §3), with the v2.3 units columns
    for rid, pred in PTA_EXAMPLE_RULES.items():
        got = sorted(_line_finding_tuple(f) for f in oracle_provider_type_allowed(
            _state(rid, dict(pred)), build_snapshot(PTA_EXAMPLE_ROWS, cover=False, cfg=cfg)))
        assert got == PTA_EXAMPLE_EXPECTED[rid], (rid, got)
    assert pta_allowed({"provider_types": [" 2 ", "c2", 8, "08 ", "008", "zz", 8.0, "8.0", "08.00", " 7 "]}) == \
        {"02", "C2", "08", "008", "ZZ", "07"}
    assert [pta_role({}), pta_role({"provider_role": None}), pta_role({"provider_role": ""}),
            pta_role({"provider_role": "servicing"})] == ["billing", "billing", "billing", "servicing"]
    # §2 v2.3: which provider_types lists compile and which make the rule a lead (A20, A21, A22)
    for entries in ENTRIES_COMPILE:
        assert not bad_entries({"provider_types": entries}), entries
    for entries in ENTRIES_LEAD:
        assert bad_entries({"provider_types": entries}), entries
    # A13: rows that differ only in the billing type's spelling are one row; in the billing type itself, two
    snap = build_snapshot([_r("C1", 1, "X1", btype="02"), _r("C1", 1, "X1", btype=" 2.0"), _r("C1", 1, "X1", btype="08")],
                          cover=False, cfg=cfg)
    assert sorted(r["btype"] for r in snap) == ["02", "08"]
    # A17 (spec v2.3): code_b rows of one line are ONE finding whatever their provider types and edit files; an NCCI
    # pair only sees the rows of its own file
    snap = build_snapshot([_r("C1", 1, "H2018", btype="08"), _r("C1", 2, "H2014", btype="08"),
                           _r("C1", 2, "H2014", btype="31"),
                           _r("C5", 1, "H2018", btype="08", member="M2"), _r("C5", 2, "H2014", btype="08", member="M2"),
                           _r("C5", 2, "H2014", btype="02", member="M2")], cover=False, cfg=cfg)
    state_pair = _state("P", {"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2014"})
    assert sorted(f["key"][2] for f in oracle_pair(state_pair, snap)) == ["M1", "M2"]
    ncci_pair = _ncci("N", {"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2014",
                            "modifier_indicator": "0", "ncci_edition": "practitioner"})
    assert sorted(f["key"][2] for f in oracle_pair(ncci_pair, snap)) == ["M1", "M2"]
    # ... evidence = the UNION of the rows' code_a lines, pa_present = any row (MERGE_ROWS, by hand)
    f, = oracle_pair(_state("PM", dict(MERGE_RULE)), build_snapshot(MERGE_ROWS, cover=False, cfg=cfg))
    assert ([ev_str(e) for e in f["evidence"]], f["col1"], f["pa_present"], f["finding_severity"]) == MERGE_EXPECTED
    # ---- §1 v2.3 cancellation tie order, by hand: which copy is cancelled, and the findings that follow
    snap = build_snapshot([r for r, _ in TIE_EXAMPLE], cover=False, cfg=cfg)
    got = {_tie_row_id(r): r["cancelled"] for r in snap}
    assert got == {_tie_row_id(clean_row(r)): c for r, c in TIE_EXAMPLE}, got
    for rid, rule in TIE_RULES.items():
        found = sorted((f["key"][2], f["key"][0], f["key"][1], f["finding_severity"])
                       for f in oracle_findings(rule, snap))
        assert found == TIE_EXPECTED[rid], (rid, found)


def _line_finding_tuple(f):
    return (f["key"][0], f["key"][1], f["finding_severity"], f["finding_basis"], f["pa_present"], f["paid_amt"],
            f["paid_at_risk"], f.get("observed_units"), f.get("allowed_units"), f.get("excess_units"))


# §2 v2.3: provider_types lists that compile (cleaned like the column: '8.0', 8, 8.0, ' 8 ' are 08) and lists that make
# the rule a lead (a blank entry - None, '', 'NONE' (A20) -, one that is not letters and digits after clean-up, or one
# longer than 4 characters (A22))
ENTRIES_COMPILE = [["8.0"], [8], [8.0], [" 8 "], ["08.00"], ["c2"], ["008"], [" 2 ", "C2", 7], ["ZZZZ"], ["NANA"],
                   ["NUL"], ["NA"], [" na "]]                                                   # A24
ENTRIES_LEAD = [[None], [""], ["  "], ["NONE"], [" none "], ["None"], ["8.5"], ["C-2"], ["C 2"], ["0.5"], ["08/09"],
                ["ABCDE"], ["12345"], [8.5], ["08", None], ["C2", "8.5"], ["08", "NONE"],
                ["NAN"], ["nan"], ["NULL"], [" null "], [float("nan")], ["08", "NaN"],      # A20 (stated v2.3)
                ["N/A"]]                                                                       # A24

# A17 / §2 v2.3, by hand: code_b line C1:3 (H2014) booked twice - billing 08 (practitioner file) with modifier LT and a
# PA, billing 02 (outpatient file) with RT; indicator 1. Code_a C1:1 carries LT (same anatomic as the first copy: not
# bypassed with it, bypassed with RT), C1:2 carries RT (the reverse). One finding: evidence C1:1 + C1:2, pa_present 1.
MERGE_RULE = {"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2014", "modifier_indicator": "1"}
MERGE_ROWS = [_r("C1", 1, "H2018", mods=("LT",)), _r("C1", 2, "H2018", mods=("RT",), paid="11.00"),
              _r("C1", 3, "H2014", mods=("LT",), btype="08", pa="PA1"), _r("C1", 3, "H2014", mods=("RT",), btype="02")]
MERGE_EXPECTED = (["C1:1", "C1:2"], ("C1", 1), True, "verify_pa")


# §1 v2.3 cancellation tie order, by hand. Each member: copies of ONE claim line (same claim id, line number, member,
# provider P1, date, code, modifiers, units, paid) that differ in the columns of the tie order, and ONE exact reversal
# (two for M13). (row, cancelled?)
def _tie(member, claim, code, rows, units="2", n_rev=1, line=1):
    paid = f"{int(Decimal(units) * 10)}.00"
    out = []
    for kw, cancelled in rows:
        kw = dict(kw)
        c, ln = kw.pop("claim", claim), kw.pop("line", line)
        out.append((_r(c, ln, code, units=units, paid=paid, member=member, **kw), cancelled))
    out += [(_r(f"R{member}-{k}", 1, code, units="-" + units, paid="-" + paid, member=member, form="C"), False)
            for k in range(n_rev)]
    return out


TIE_EXAMPLE = (
    _tie("M1", "C1", "J3490", [(dict(form="O", btype="08"), False), (dict(form="A", btype="08"), True)])     # 'A' < 'O'
    + _tie("M2", "C2", "J3490", [(dict(form=None), True), (dict(form="A"), False)])                       # missing first
    + _tie("M3", "C3", "G0466", [(dict(pa="PA9"), False), (dict(pa=None), True)], units="1")              # missing first
    + _tie("M4", "C4", "G0466", [(dict(pa="pa1"), False), (dict(pa="PA9"), True)], units="1")             # 'PA9' < 'pa1'
    + _tie("M5", "C5", "J3490", [(dict(ptype="08"), False), (dict(ptype="02"), True)])                    # servicing type
    + _tie("M6", "C6", "G0466", [(dict(btype="08"), False), (dict(btype="02"), True)], units="1")         # billing type
    + _tie("M7", "C7", "G0466", [(dict(btype="C2"), False), (dict(btype=None), True)], units="1")         # missing first
    + _tie("M8", "C8", "11975", [(dict(bprov="B2", dob=D(2010, 5, 5)), False), (dict(bprov="B1", dob=None), True)],
           units="1")                                                                                     # billing prov id
    + _tie("M9", "C9", "11975", [(dict(dob=D(2010, 5, 5)), False), (dict(dob=None), True)], units="1")    # missing first
    + _tie("M10", "C10", "11975", [(dict(line=9, dob=D(2010, 5, 5)), True), (dict(line=10, dob=D(2010, 5, 5)), False)],
           units="1")                                                                                     # line NUMBER
    + _tie("M11", None, "11975", [(dict(claim="K9", dob=D(2010, 5, 5)), False),
                                  (dict(claim="K10", dob=D(2010, 5, 5)), True)], units="1")              # claim id TEXT
    + _tie("M12", "C12", "J3490", [(dict(form=""), True), (dict(form="A"), False)])                        # '' < 'A' (A19)
    + _tie("M13", "C13", "J3490", [(dict(btype="08"), False), (dict(btype="02"), True), (dict(btype=None), True)],
           n_rev=2)                                                                                       # two reversals
)
TIE_RULES = {
    "M-PRA": _ncci("M-PRA", {"type": "max_units_per_line", "code": "J3490", "threshold": 1, "ncci_edition": "practitioner"},
                   eff=None),
    "M-OPH": _ncci("M-OPH", {"type": "max_units_per_line", "code": "J3490", "threshold": 1, "ncci_edition": "outpatient"},
                   eff=None),
    "NC-G": _state("NC-G", {"type": "code_not_covered", "code": "G0466"}),
    "PTA-02": _state("PTA-02", {"type": "provider_type_allowed", "code": "G0466", "provider_types": ["2.0"]}),
    "NC-AGE": _state("NC-AGE", {"type": "code_not_covered", "code": "11975", "age": {"below": 21}}),
}
TIE_EXPECTED = {   # (member, claim, line, severity) of the findings, by hand from the surviving copies
    "M-PRA": [("M12", "C12", 1, "units_over_limit"), ("M13", "C13", 1, "units_over_limit"),
              ("M2", "C2", 1, "units_over_limit"), ("M5", "C5", 1, "units_over_limit")],
    "M-OPH": [("M1", "C1", 1, "units_over_limit")],
    "NC-G": [("M3", "C3", 1, "verify_pa"), ("M4", "C4", 1, "verify_pa"), ("M6", "C6", 1, "not_covered_paid"),
             ("M7", "C7", 1, "not_covered_paid")],
    "PTA-02": [("M6", "C6", 1, "provider_type_not_allowed"), ("M7", "C7", 1, "provider_type_not_allowed")],
    "NC-AGE": [("M10", "C10", 10, "not_covered_paid"), ("M11", "K9", 1, "not_covered_paid"),
               ("M8", "C8", 1, "not_covered_paid"), ("M9", "C9", 1, "not_covered_paid")],
}


def _tie_row_id(r):
    """A cleaned row's identity for the tie examples (every column the examples vary)."""
    return (r["member"], r["claim"], r["line"], r["form"], r["pa"], r["ptype"], r["btype"], r["bprov"], r["dob"],
            r["paid"])


# provider_type_allowed, by hand (§2 v2.2 + §3): rows of G0466 for member M1 on 2024-03-05 (form A, paid 10.00)
PTA_EXAMPLE_ROWS = [
    _r("C1", 1, "G0466", ptype="08", btype=" c2"),            # billing C2
    _r("C1", 2, "G0466", ptype="C2", btype="2.0"),            # billing 02 (decimal spelling), servicing C2
    _r("C1", 3, "G0466", ptype="08", btype=" "),              # billing missing
    _r("C1", 4, "G0466", ptype="C2", btype="ZZ"),             # billing ZZ: not in the routing table (A14: known)
    _r("C1", 5, "G0466", ptype="C2", btype="02", paid="0.00"),   # $0 line: not payable
    _r("C1", 6, "G0466", ptype=None, btype="5", pa="PA1"),    # billing 05 (lone digit), servicing missing
    _r("C1", 7, "G0466", ptype="08", btype="08", pa=" PA9 "),  # billing 08, a PA on the line
    _r("C1", 8, "G0466", ptype="31", btype="C2"),             # servicing 31 (DO)
    _r("C1", 9, "G0466", ptype="8.5", btype="05"),            # servicing '8.5': not in the table (A11, A14)
    _r("C2", 1, "G0466", units="2", paid="20.00", btype="02"),   # cancelled by R2 below
    _r("R2", 1, "G0466", units="-2", paid="-20.00", btype="08"),
    _r("C3", 1, "G0466", btype="08", dob=D(2010, 1, 1)),      # age 14 on the date of service
    _r("C3", 2, "G0466", btype="08", dob=None),               # no usable date of birth
    _r("C4", 1, "G0466", btype="02"), _r("C4", 1, "G0466", btype=" 2"),   # one snapshot row (A13) ...
    _r("C4", 1, "G0466", btype="C2"),                         # ... and a second row of the same line (A13, A15)
    _r("C1", 10, "G0466", btype="02", units=None),            # (v2.3) units missing: observed / excess NULL (A23)
    _r("C1", 11, "G0466", btype="02", units="1.25"),          # (v2.3) fractional units
]
PTA_EXAMPLE_RULES = {
    # billing role (default); ' 5 ' -> 05, 'c2' -> C2
    "PTA-B": {"type": "provider_type_allowed", "code": "g0466 ", "provider_types": ["c2", " 5 "]},
    # servicing role; the float 8.0 -> '08' (v2.3); an exception clause
    "PTA-S": {"type": "provider_type_allowed", "code_set": ["G0466"], "provider_types": ["C2", 8.0],
              "provider_role": "servicing", "exception": EXCEPTION_TEXT},
    # billing role, under 21 only, "may" (discretionary); '2.0' -> 02 (v2.3)
    "PTA-AGE": {"type": "provider_type_allowed", "code": "G0466", "provider_types": ["2.0", "c2", " 5 ", "zz"],
                "provider_role": "billing", "age": {"below": 21}, "discretionary": True},
}
_TEN, _ONE, _NA = P("10.00"), Decimal(1), "provider_type_not_allowed"
PTA_EXAMPLE_EXPECTED = {   # (claim, line, severity, basis, pa_present, paid_amt, paid_at_risk, observed, allowed, excess)
    "PTA-B": [("C1", 2, _NA, _NA, False, _TEN, _TEN, _ONE, 0, _ONE),
              ("C1", 4, _NA, _NA, False, _TEN, _TEN, _ONE, 0, _ONE),
              ("C1", 7, "verify_pa", _NA, True, _TEN, _TEN, _ONE, 0, _ONE),
              ("C1", 10, _NA, _NA, False, _TEN, _TEN, None, 0, None),
              ("C1", 11, _NA, _NA, False, _TEN, _TEN, Decimal("1.25"), 0, Decimal("1.25")),
              ("C3", 1, _NA, _NA, False, _TEN, _TEN, _ONE, 0, _ONE),
              ("C3", 2, _NA, _NA, False, _TEN, _TEN, _ONE, 0, _ONE),
              ("C4", 1, _NA, _NA, False, _TEN, _TEN, _ONE, 0, _ONE)],
    "PTA-S": [("C1", 8, "verify_exception", _NA, False, _TEN, _TEN, _ONE, 0, _ONE),
              ("C1", 9, "verify_exception", _NA, False, _TEN, _TEN, _ONE, 0, _ONE)],
    "PTA-AGE": [("C3", 1, "discretionary", _NA, False, _TEN, _TEN, _ONE, 0, _ONE)],
}


# ===================================================================================== pytest: Spark comparisons
N_ROUNDS = int(os.environ.get("PIE_ORACLE_ROUNDS", "8"))
N_SETS = int(os.environ.get("PIE_ORACLE_SETS", "5"))
STATS, IMPACT = Counter(), Counter()


MISMATCHES = []                                              # every mismatch of the run (the report keeps them)


def v23_coverage() -> dict:
    """The v2.2 / v2.3 hard cases - routing rows, provider_type_allowed cases, cancellation ties and what they decide,
    one-line units, pair merges - proof that each occurred in the comparison."""
    rows = ("route_v22:", "pta_", "cancel_", "tie_generated", "one_line_finding_units", "textual_null")
    cases = ("pta_", "pair_code_b_", "severity_", "ncci_cancel_tie", "one_line_finding_units")
    out = {k: v for k, v in sorted(COVER.items()) if k.startswith(rows)}
    out.update({k: len(v) for k, v in sorted(COVER_SETS.items()) if k.startswith(cases)})
    return out


def _report():
    import json
    rep = {"stats": dict(STATS), "v23_coverage": v23_coverage(), "coverage_rows": dict(COVER),
           "coverage_cases": {k: len(v) for k, v in sorted(COVER_SETS.items())}, "readings": ORACLE_READINGS,
           "known_deviations": KNOWN_DEVIATIONS, "deviation_impact": dict(IMPACT),
           "mismatches": [{k: (repr(v) if k not in ("query", "type", "ptype", "field") else v) for k, v in x.items()}
                          for x in MISMATCHES[:400]], "mismatch_count": len(MISMATCHES)}
    path = os.environ.get("PIE_ORACLE_REPORT")
    if path:
        with open(path, "w") as fh:
            json.dump(rep, fh, indent=1, default=str)
    print("\n[pie oracle] " + json.dumps({"stats": rep["stats"]}, default=str))


@pytest.fixture(scope="module")
def spark():
    try:                                                     # other test modules may stub a bare 'pyspark'
        from pyspark.sql import SparkSession  # noqa: F401
    except Exception:
        pytest.skip("pyspark (pyspark.sql) not available")
    if not (shutil.which("java") or os.environ.get("JAVA_HOME")):
        pytest.skip("no Java runtime for Spark")
    saved = (dg.CLAIMS, dg.DETECT, dg.PTP_EDITS_TABLE, dg.MUE_LIMITS_TABLE, config.TABLE_FORMAT)
    warehouse = tempfile.mkdtemp(prefix="pie_sql_oracle_", dir=os.environ.get("PIE_ORACLE_TMP") or None)
    session = None
    try:
        point_detector_gen_at_test_tables()
        session = make_spark(warehouse)
        session.sparkContext.setLogLevel("ERROR")
        setup_schemas(session)
        yield session
    finally:
        if session is not None:
            session.stop()
        dg.CLAIMS, dg.DETECT, dg.PTP_EDITS_TABLE, dg.MUE_LIMITS_TABLE, config.TABLE_FORMAT = saved
        shutil.rmtree(warehouse, ignore_errors=True)
        if session is not None:
            _report()


def _fmt(mism, n=12):
    lines = [f"{len(mism)} mismatch(es) between the SQL and the oracle (first {min(n, len(mism))}):"]
    for x in mism[:n]:
        if x["type"] == "field":
            lines.append(f"  {x['query']} {x['key']} field {x['field']}: oracle={x['oracle']!r} sql={x['sql']!r}")
        else:
            lines.append(f"  {x['query']} {x['type']} {x['key']}: oracle={x.get('oracle')!r} sql={x.get('sql')!r}")
    return "\n".join(lines)


@pytest.mark.parametrize("rnd", range(N_ROUNDS))
def test_random_claim_sets_match_oracle(spark, rnd):
    """One round: a random rule set (every predicate type, state + NCCI in all three edit files, windows, ages,
    scopes, indicators, exceptions, discretionary, MUE changed later, invalid predicates that must be leads) and
    N_SETS seeded claim sets of 100-400 rows full of hard cases (provider types in every Table 2 row, spelled '8' /
    '8.0' / ' c2 ' / blank / unknown, every claim form). Checks the snapshot row by row (incl. provider type, edit
    file, counted units), every per-rule query, every rolling signal and both NCCI batch statements."""
    rules, raw = build_round(rnd, N_SETS)
    mism = run_round(spark, rules, raw, STATS, IMPACT)
    STATS["rounds"] += 1
    STATS["claim_sets"] += N_SETS
    MISMATCHES.extend(dict(x, round=rnd) for x in mism)
    assert not mism, _fmt(mism)


# Routing switches (§1a). The default rounds run the v2.4 defaults (billing type, optional rows off, step 3 "none");
# the variants keep every other value covered - step 3 "form" (the default until v2.3) in two of them.
ROUTING_VARIANTS = {
    "optional_rows_on": {"NCCI_OPTIONAL_CATEGORIES_ON": ("testing_facility", "other_outpatient")},
    "other_outpatient_on": {"NCCI_OPTIONAL_CATEGORIES_ON": ("other_outpatient",)},
    "unmapped_form": {"NCCI_UNMAPPED_PROVIDER_TYPE": "form"},
    "route_by_provider_type": {"NCCI_ROUTE_BY": "provider_type"},
    "route_by_provider_type_optional_on_unmapped_form": {
        "NCCI_ROUTE_BY": "provider_type", "NCCI_OPTIONAL_CATEGORIES_ON": ("testing_facility", "other_outpatient"),
        "NCCI_UNMAPPED_PROVIDER_TYPE": "form"},
    "route_by_form": {"NCCI_ROUTE_BY": "form"},
    # (v2.6) not routing: the group billing types (cleaned like the column, A28) and the daily-cap modifier list (A27)
    "v26_group_types_1_and_c2": {"GROUP_BILLING_PROVIDER_TYPES": ("1", " c2 ")},
    "v26_daily_cap_modifiers_59_50_76": {"DAILY_CAP_VERIFY_MODIFIERS": ("59", "50", "76")},
}


VARIANT_REPEATS = int(os.environ.get("PIE_ORACLE_VARIANT_REPEATS", "1"))   # rounds per routing variant


@pytest.mark.parametrize("rep", range(VARIANT_REPEATS))
@pytest.mark.parametrize("variant", sorted(ROUTING_VARIANTS))
def test_random_claim_sets_match_oracle_under_routing_config(spark, variant, rep, monkeypatch):
    """§1a switches: config is patched BEFORE the claims are generated (scenario lines are steered into each NCCI rule's
    file under the routing in force), the rules are compiled and the snapshot is built; the oracle reads the same
    config."""
    for k, v in ROUTING_VARIANTS[variant].items():
        monkeypatch.setattr(config, k, v)
    rnd = 500 + sorted(ROUTING_VARIANTS).index(variant) + 100 * rep
    rules, raw = build_round(rnd, N_SETS)
    mism = run_round(spark, rules, raw, STATS, IMPACT)
    STATS[f"rounds:{variant}"] += 1
    STATS["claim_sets"] += N_SETS
    MISMATCHES.extend(dict(x, round=f"{variant}#{rep}") for x in mism)
    assert not mism, _fmt(mism)


def _run_case(spark, rows, rules):
    import contextlib
    import io
    write_claims(spark, rows)
    with contextlib.redirect_stdout(io.StringIO()):
        dg.create_snapshot(spark, source=dg.CLAIMS, target=dg.DETECT, fmt="parquet")
    out = {}
    for d in dg.build_detectors(rules):
        out[d["rule_id"]] = None if not d.get("sql") else run_sql(spark, d["sql"])
    return out


PAIR_H = {"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2014", "modifier_indicator": "0"}


# ---------------------------------------------------------------- v1 findings, now spec (version 2): strict tests
def test_v2_F01_evidence_keeps_missing_claim_or_line_rendered_empty(spark):
    """F-01 fixed: a code_a line with no line number / no claim id stays in the evidence, written 'C1:' / ':3'."""
    out = _run_case(spark, [_r("C1", None, "H2018"), _r("C2", 1, "H2014"),
                            _r(None, 3, "H2018", member="M2"), _r("C4", 1, "H2014", member="M2"),
                            _r("C5", 1, "A0422", units="2", member="M3"), _r("C5", None, "A0422", units="2",
                                                                             paid="20.00", member="M3")],
                    [_state("PAIR", dict(PAIR_H)),
                     _state("DAY", {"type": "max_units_per_day", "code": "A0422", "threshold": 3})])
    pair = {r["member_id"]: r for r in out["PAIR"]}
    assert (pair["M1"]["evidence_lines"], pair["M1"]["col1_claim_id"], pair["M1"]["col1_line_no"]) == ("C1:", "C1", None)
    assert (pair["M2"]["evidence_lines"], pair["M2"]["col1_claim_id"], pair["M2"]["col1_line_no"]) == (":3", None, 3)
    assert [r["evidence_lines"] for r in out["DAY"]] == ["C5:,C5:1"]


def test_v2_F02_ncci_pa_present_is_null(spark):
    out = _run_case(spark, [_r("C1", 1, "11111"), _r("C1", 2, "22222", pa="PA9"), _r("C3", 1, "J3490", units="3",
                                                                                  pa="PA9")],
                    [_ncci("N1", {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222",
                                  "modifier_indicator": "0", "ncci_edition": "practitioner"}),
                     _ncci("M1", {"type": "max_units_per_line", "code": "J3490", "threshold": 1,
                                  "ncci_edition": "practitioner"}, eff=None)])
    assert [(r["pa_present"], r["finding_severity"]) for r in out["N1"]] == [(None, "hard_denial")]
    assert [(r["pa_present"], r["finding_severity"]) for r in out["M1"]] == [(None, "units_over_limit")]


def test_v2_F03_ncci_pair_is_always_member_provider_day(spark):
    pred = {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222", "modifier_indicator": "0",
            "ncci_edition": "practitioner", "scope": "member_day"}
    out = _run_case(spark, [_r("C1", 1, "11111", sprov="P1"), _r("C2", 1, "22222", sprov="P2"),
                            _r("C3", 1, "11111", sprov="P1", member="M2"), _r("C3", 2, "22222", sprov="P1", member="M2")],
                    [_ncci("N1", pred)])
    assert [(r["member_id"], r["pair_scope"]) for r in out["N1"]] == [("M2", "member_provider_day")]


def test_v2_F04_code_and_code_set_rule_is_a_lead_not_a_query():
    both = {"code": "98961", "code_set": ["98962"]}
    rules = [_state("DAY", {"type": "max_units_per_day", "threshold": 2, **both}),
             _state("NC", {"type": "code_not_covered", **both}),
             _state("PER", {"type": "max_units_per_period", "threshold": 2, "period": "month", **both})]
    for d in dg.build_detectors(rules):
        assert d["sql"] is None and not d["compiled"] and "both code and code_set" in (d["reason"] or ""), d["rule_id"]


def test_v2_R01_reversal_booked_with_positive_units_nets_out(spark):
    out = _run_case(spark, [_r("C1", 1, "A0422", units="3", paid="30.00"), _r("R1", 1, "A0422", units="3",
                                                                          paid="-30.00"),
                            _r("C2", 1, "A0422", units="3", paid="30.00", member="M2"),
                            _r("R2", 1, "A0422", units="1", paid="-10.00", member="M2")],      # partial recoupment
                    [_state("DAY", {"type": "max_units_per_day", "code": "A0422", "threshold": 1})])
    assert [(r["member_id"], r["observed_units"], r["paid_amt"]) for r in out["DAY"]] == [("M2", 2, Decimal("20.00"))]
    snap = {r[C["claim_id"]]: (r[C["units"]], r[dg.PIE_UNITS_RAW], r[dg.PIE_CANCELLED])
            for r in spark.table(SNAPSHOT_TABLE).collect()}
    assert snap["R1"] == (-3, 3, False) and snap["C1"][2] is True and snap["C2"][2] is False


def test_v2_S02_S03_group_evidence_distinct_in_numeric_order(spark):
    out = _run_case(spark, [_r("C1", 10, "A0422", units="2", sprov="P1"), _r("C1", 10, "A0422", units="2", sprov="P2"),
                            _r("C1", 2, "A0422", units="1", sprov="P3"),
                            _r("C9", 3, "H2018"), _r("C9", 12, "H2018", paid="11.00"), _r("C9", 4, "H2014")],
                    [_state("DAY", {"type": "max_units_per_day", "code": "A0422", "threshold": 3}),
                     _state("PAIR", dict(PAIR_H))])
    assert [r["evidence_lines"] for r in out["DAY"]] == ["C1:2,C1:10"]
    r, = out["PAIR"]
    assert (r["evidence_lines"], r["col1_claim_id"], r["col1_line_no"]) == ("C9:3,C9:12", "C9", 3)


def test_v2_S01_rows_differing_only_in_pos_are_one_snapshot_row(spark):
    out = _run_case(spark, [_r("C1", 1, "A0422", units="2", pos="11"), _r("C1", 1, "A0422", units="2", pos="12")],
                    [_state("DAY", {"type": "max_units_per_day", "code": "A0422", "threshold": 3})])
    assert out["DAY"] == [] and spark.table(SNAPSHOT_TABLE).count() == 1


def test_v2_S04_pair_age_condition_is_tested_on_the_code_b_line(spark):
    out = _run_case(spark, [_r("C1", 1, "H2018", dob=None), _r("C1", 2, "H2014", dob=D(2010, 1, 1))],
                    [_state("PAIR", dict(PAIR_H, age={"below": 21}))])
    assert [(r["claim_id"], r["line_no"]) for r in out["PAIR"]] == [("C1", 2)]


def test_documented_S06_pair_code_b_rows_sharing_the_shown_columns_are_one_finding(spark):
    """S-06 (SPEC AMBIGUITY, P3, safe direction; same in v1): 'one finding per (rule, code_b line)' is applied per
    distinct (claim id, line number, member, provider, date, form, paid). Two code_b ROWS that differ only in PA /
    units / modifiers become ONE finding (pa_present = any -> verify_pa); a different paid amount or form keeps two.
    code_not_covered / max_units_per_line stay one finding per row."""
    out = _run_case(spark, [_r("C1", 1, "H2018"), _r("C2", 7, "H2014", pa="PA1"), _r("C2", 7, "H2014", pa=None),
                            _r("C1", 1, "H2018", member="M2"), _r("C3", 7, "H2014", member="M2", paid="10.00", pa="PA1"),
                            _r("C3", 7, "H2014", member="M2", paid="20.00")],
                    [_state("PAIR", dict(PAIR_H)), _state("NC", {"type": "code_not_covered", "code": "H2014"})])
    got = sorted((r["member_id"], str(r["paid_amt"]), r["pa_present"], r["finding_severity"]) for r in out["PAIR"])
    assert got == [("M1", "10.00", 1, "verify_pa"), ("M2", "10.00", 1, "verify_pa"), ("M2", "20.00", 0, "hard_denial")]
    assert len(out["NC"]) == 4


@pytest.mark.parametrize("unmapped", ["none", "form"])
def test_v2_ncci_edit_file_by_provider_type_and_form(spark, monkeypatch, unmapped):
    """§1a on fixed lines: the same pair billed by providers of each Table 2 row on forms A / O / D, under step 3
    "none" (the v2.4 default) and "form"."""
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", unmapped)
    rows, k = [], 0
    for form in ("A", "O", "D", "a"):
        for pt in ("8", "8.0", "43", "02", "30", "04", "C2", "07", "", None, "ZZ"):
            k += 1
            m = f"M{k}"
            rows += [_r(f"C{k}", 1, "11111", member=m, form=form, ptype=pt),
                     _r(f"C{k}", 2, "22222", member=m, form=form, ptype=pt)]
    rules = [_ncci(f"N-{ed}", {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222",
                               "modifier_indicator": "0", "ncci_edition": ed}) for ed in ("practitioner", "outpatient", "dme")]
    out = _run_case(spark, rows, rules)
    got = {(rid, r["member_id"]) for rid, rs in out.items() for r in rs}
    snap = build_snapshot(rows, cover=False)
    exp = {(rule["rule_id"], f["key"][2]) for rule in rules for f in oracle_pair(rule, snap)}
    # no billing type on these lines -> the servicing type picks (v2.2 step 2). Forms A, O, a: 6 of the 11 types are in
    # the table and route (v2.2: 07 Dentist is a practitioner; 04 / C2 are optional rows, off); '' / None / ZZ reach
    # step 3: no file by default (v2.4), by form under "form" -> 9 of 11. Form D: none.
    assert got == exp and len(exp) == 3 * (6 if unmapped == "none" else 9)
    by_member = {r["member"]: r["edition"] for r in snap}
    assert (by_member["M1"], by_member["M13"], by_member["M14"], by_member["M26"], by_member["M8"]) == \
        ("practitioner", "outpatient", "practitioner", None, "practitioner")   # 8 on A, 8.0 on O, ASC 43 on a UB-04,
    #                                                                            form D, dentist 07 on A
    assert (by_member["M10"], by_member["M22"]) == ((None, None) if unmapped == "none" else ("practitioner", "outpatient"))
    #                                                                            no type on A / on O: step 3


def _set_routing(monkeypatch, cfg):
    route_by, optional_on, unmapped = cfg
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", route_by)
    monkeypatch.setattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", tuple(optional_on))
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", unmapped)


@pytest.mark.parametrize("cfg", sorted({c for *_, c, _w in ROUTING_EXAMPLES}, key=repr))
def test_v22_ncci_edit_file_by_billing_and_servicing_type_on_fixed_lines(spark, monkeypatch, cfg):
    """§1a v2.2 on fixed lines, against the HAND-computed files of ROUTING_EXAMPLES (not the oracle): one member per
    example, the snapshot's edit file per line and the findings of the same NCCI pair in each of the three files."""
    _set_routing(monkeypatch, cfg)
    cases = [(f, s, bl, want) for f, s, bl, c, want in ROUTING_EXAMPLES if c == cfg]
    rows = []
    for k, (form, s, bl, _) in enumerate(cases):
        rows += [_r(f"C{k}", 1, "11111", member=f"M{k}", form=form, ptype=s, btype=bl),
                 _r(f"C{k}", 2, "22222", member=f"M{k}", form=form, ptype=s, btype=bl)]
    rules = [_ncci(f"N-{ed}", {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222",
                               "modifier_indicator": "0", "ncci_edition": ed}) for ed in ("practitioner", "outpatient", "dme")]
    out = _run_case(spark, rows, rules)
    files = {}
    for r in spark.table(SNAPSHOT_TABLE).collect():
        files.setdefault(r[C["member"]], set()).add(r[dg.PIE_EDITION])
    want = {f"M{k}": {w} for k, (*_, w) in enumerate(cases)}
    bad = {m: (cases[int(m[1:])][:3], sorted(files.get(m, set()), key=repr), sorted(want[m], key=repr))
           for m in want if files.get(m) != want[m]}
    assert not bad, f"edit file (form, servicing, billing): got vs hand-computed under {cfg}: {bad}"
    got = {(rid, r["member_id"]) for rid, rs in out.items() for r in rs}
    assert got == {(f"N-{w}", f"M{k}") for k, (*_, w) in enumerate(cases) if w}


def _sql_line_tuple(r):
    return (r["claim_id"], r["line_no"], r["finding_severity"], r["finding_basis"],
            None if r.get("pa_present") is None else bool(r["pa_present"]), _q2(r["paid_amt"]), _q2(r["paid_at_risk"]),
            _num(r.get("observed_units")), _num(r.get("allowed_units")), _num(r.get("excess_units")))


def test_v22_provider_type_allowed_on_fixed_lines(spark):
    """§2 v2.2 / v2.3 provider_type_allowed + §3 severity on PTA_EXAMPLE_ROWS, against the HAND-computed findings,
    including the v2.3 units columns (observed = line units, allowed = 0, excess = observed; NULL units -> NULL)."""
    out = _run_case(spark, PTA_EXAMPLE_ROWS, [_state(rid, dict(p)) for rid, p in PTA_EXAMPLE_RULES.items()])
    for rid, want in PTA_EXAMPLE_EXPECTED.items():
        assert out[rid] is not None, f"{rid} did not compile"
        got = sorted(_sql_line_tuple(r) for r in out[rid])
        assert got == want, (rid, got)
        assert all(not parse_evidence(r.get("evidence_lines")) for r in out[rid]), "provider-type finding with evidence"


def test_v23_not_covered_units_columns_on_fixed_lines(spark):
    """§2 Not covered (v2.3): observed units = the line's units, allowed = 0, excess = observed (A23: missing units ->
    NULL); paid_amt = paid_at_risk = the line's paid amount; no evidence lines."""
    rows = [_r("C1", 1, "11975", units="2"), _r("C1", 2, "11975", units=None, paid="7.77"),
            _r("C1", 3, "11975", units="0.5", pa="PA1"), _r("C1", 4, "11975", units="0", paid="9.00")]
    out = _run_case(spark, rows, [_state("NC", {"type": "code_not_covered", "code": "11975"})])
    got = sorted(_sql_line_tuple(r) for r in out["NC"])
    nc = "not_covered_paid"
    assert got == [("C1", 1, nc, nc, False, _q2("10.00"), _q2("10.00"), Decimal(2), Decimal(0), Decimal(2)),
                   ("C1", 2, nc, nc, False, _q2("7.77"), _q2("7.77"), None, Decimal(0), None),
                   ("C1", 3, "verify_pa", nc, True, _q2("10.00"), _q2("10.00"), Decimal("0.5"), Decimal(0),
                    Decimal("0.5"))]
    assert all(not parse_evidence(r.get("evidence_lines")) for r in out["NC"])


def test_v23_cancellation_tie_order_on_fixed_lines(spark):
    """§1 Cancelled line (v2.3) on TIE_EXAMPLE, against the HAND-computed answer: which copy of a claim line each
    reversal cancels (form, PA - binary order, servicing type, billing type, billing provider id, date of birth, line
    NUMBER, claim id text; missing first), and the findings that follow from the surviving copy (its edit file, PA,
    provider type, age)."""
    out = _run_case(spark, [r for r, _ in TIE_EXAMPLE], list(TIE_RULES.values()))
    got = {}
    for s in spark.table(SNAPSHOT_TABLE).collect():
        rid = (s[C["member"]], s[C["claim_id"]], s[C["line_no"]], s[C["form"]], s[C["pa_no"]], s[dg.PIE_PROV_TYPE],
               s[dg.PIE_BPROV_TYPE], s[C["billing_provider"]], s[dg.PIE_DOB], s[C["paid_amt"]])
        got[rid] = s[dg.PIE_CANCELLED]
    want = {_tie_row_id(clean_row(r)): c for r, c in TIE_EXAMPLE}
    assert got == want, {k: (got.get(k), want.get(k)) for k in set(got) | set(want) if got.get(k) != want.get(k)}
    for rid, exp in TIE_EXPECTED.items():
        found = sorted((r["member_id"], r["claim_id"], r["line_no"], r["finding_severity"]) for r in out[rid])
        assert found == exp, (rid, found)


def test_v23_provider_types_entries_compile_or_make_the_rule_a_lead():
    """§2 (v2.3): entries are cleaned exactly like the column ('8.0', 8, 8.0, ' 8 ' -> 08) and the rule compiles; a
    blank entry (None, '', 'NONE' - A20), one that is not letters and digits after clean-up, or (A22) one longer than 4
    characters makes the rule a lead. A21: 'NAN' / 'NULL' / a float NaN are letters -> ordinary codes."""
    def build(entries):
        d, = dg.build_detectors([_state("X", {"type": "provider_type_allowed", "code": "G0466",
                                              "provider_types": list(entries)})])
        return d
    wrong = []
    for entries in ENTRIES_COMPILE:
        d = build(entries)
        if not (d.get("compiled") and d.get("sql")):
            wrong.append(("must compile", entries, d.get("reason")))
    for entries in ENTRIES_LEAD:
        d = build(entries)
        if d.get("compiled") or d.get("sql"):
            wrong.append(("must be a lead", entries, "compiled"))
    assert not wrong, wrong


def test_v23_provider_types_written_as_numbers_mean_08(spark):
    """§2 (v2.3): a rule listing 08 as 8 / 8.0 / '8.0' / ' 8 ' / '08.00' allows billing type 08 however the column
    spells it ('8', '8.0', ' 08'), and flags 02."""
    rows = [_r("C1", 1, "G0466", btype="8"), _r("C1", 2, "G0466", btype="8.0"), _r("C1", 3, "G0466", btype=" 08"),
            _r("C1", 4, "G0466", btype="2.0")]
    spellings = {"I": 8, "F": 8.0, "T": "8.0", "P": " 8 ", "D": "08.00"}
    out = _run_case(spark, rows, [_state(f"N-{k}", {"type": "provider_type_allowed", "code": "G0466",
                                                     "provider_types": [v]}) for k, v in spellings.items()])
    for k in spellings:
        assert out[f"N-{k}"] is not None, f"provider_types [{spellings[k]!r}] did not compile"
        assert sorted((r["claim_id"], r["line_no"]) for r in out[f"N-{k}"]) == [("C1", 4)], (k, out[f"N-{k}"])


@pytest.mark.parametrize("unmapped", ["none", "form"])
def test_v23_textual_nulls_in_both_provider_type_columns_are_missing(spark, monkeypatch, unmapped):
    """§1 (v2.3, A20): for BOTH provider type codes the text NONE / NAN / NULL (any case, after trimming) is missing,
    like blank - routing falls back as for a missing type (both missing: step 3 - no file by default (v2.4), by form
    under "form") and a provider-type rule never flags the line. A24: 'NA' (a real AHCCCS type: other_outpatient,
    optional row off -> billing NA picks its row, no file), 'NANA', 'NUL', 'N/A' are codes - unmapped (the servicing
    type picks) and KNOWN (flagged when not listed)."""
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", unmapped)
    bill = ["NONE", "None", " none ", "nan", " NaN ", "NULL", "Null", "  ", "NA", "NANA", "NUL", "N/A"]
    serv = ["NONE", " nan ", "Null"]
    rows = [_r(f"C{i}", 1, "G0466", member=f"B{i}", btype=v, ptype="02") for i, v in enumerate(bill)]
    rows += [_r(f"S{i}", 1, "G0466", member=f"S{i}", btype=None, ptype=v, form=f) for i, (v, f) in
             enumerate([(v, f) for v in serv for f in ("A", "O")])]
    out = _run_case(spark, rows, [_state("PTA-B", {"type": "provider_type_allowed", "code": "G0466",
                                                   "provider_types": ["08"]}),
                                  _state("PTA-S", {"type": "provider_type_allowed", "code": "G0466",
                                                   "provider_types": ["08"], "provider_role": "servicing"})])
    snap = {s[C["member"]]: (s[dg.PIE_PROV_TYPE], s[dg.PIE_BPROV_TYPE], s[dg.PIE_EDITION])
            for s in spark.table(SNAPSHOT_TABLE).collect()}
    want = {f"B{i}": ("02", None, "outpatient") for i in range(8)}          # billing missing -> servicing 02 picks
    want.update({"B8": ("02", "NA", None), "B9": ("02", "NANA", "outpatient"), "B10": ("02", "NUL", "outpatient"),
                 "B11": ("02", "N/A", "outpatient")})
    want.update({f"S{i}": (None, None, None if unmapped == "none" else "practitioner" if i % 2 == 0 else "outpatient")
                 for i in range(6)})                                         # both missing -> step 3
    assert snap == want, {k: (snap.get(k), want.get(k)) for k in set(snap) | set(want) if snap.get(k) != want.get(k)}
    assert sorted(r["member_id"] for r in out["PTA-B"]) == ["B10", "B11", "B8", "B9"]
    assert sorted(r["member_id"] for r in out["PTA-S"]) == [f"B{i}" for i in sorted(range(12), key=str)]


GRAIN_ROWS = [_r("C9", 1, "X1", btype="02", member="M9"), _r("C9", 1, "X1", btype=" 2.0", member="M9"),
              _r("C9", 1, "X1", btype="08", member="M9"),
              _r("C1", 1, "H2018", btype="08"), _r("C1", 2, "H2014", btype="08"), _r("C1", 2, "H2014", btype="31"),
              _r("C5", 1, "H2018", btype="08", member="M2"), _r("C5", 2, "H2014", btype="08", member="M2", pa="PA1"),
              _r("C5", 2, "H2014", btype="02", member="M2")]


def test_v22_billing_type_is_a_kept_column_and_rows_of_one_line_in_one_edit_file_are_one_pair_finding(spark):
    """A13: rows that differ only in the billing type's spelling are one snapshot row, in the billing type itself two.
    A17: two code_b rows of one line that differ only in the billing type and take the SAME edit file (08 / 31) are one
    state-pair finding; the NCCI pair sees only the rows of its own file (the 02 row is outpatient on form A)."""
    out = _run_case(spark, GRAIN_ROWS, [_state("PAIR", dict(PAIR_H)),
                                        _ncci("N", dict(PAIR_H, ncci_edition="practitioner"))])
    snap = sorted(r[dg.PIE_BPROV_TYPE] for r in spark.table(SNAPSHOT_TABLE).collect() if r[C["member"]] == "M9")
    assert snap == ["02", "08"]
    assert [r["member_id"] for r in out["PAIR"]].count("M1") == 1
    assert sorted((r["member_id"], r["finding_severity"]) for r in out["N"]) == [("M1", "hard_denial"),
                                                                                  ("M2", "hard_denial")]


def test_v23_pair_rows_of_one_line_in_two_edit_files_are_one_finding(spark):
    """Spec §2 (v2.3, was F-05): 'The edit file never splits a finding ... a state rule ignores edit files.' C5:2 is
    booked twice - billing 08 (practitioner file, PA1) and billing 02 (outpatient file, no PA) -> ONE finding,
    pa_present = 1 (any row), verify_pa. MERGE_ROWS: the two copies of C1:3 pair with DIFFERENT code_a lines (LT / RT
    under indicator 1) -> one finding whose evidence is the union C1:1,C1:2 (Column One C1:1)."""
    out = _run_case(spark, GRAIN_ROWS, [_state("PAIR", dict(PAIR_H))])
    assert sorted((r["member_id"], r["finding_severity"], r["pa_present"]) for r in out["PAIR"] if r["member_id"] == "M2") \
        == [("M2", "verify_pa", 1)]
    out = _run_case(spark, MERGE_ROWS, [_state("PM", dict(MERGE_RULE))])
    r, = out["PM"]
    assert ((r["evidence_lines"] or "").split(","), (r["col1_claim_id"], r["col1_line_no"]), bool(r["pa_present"]),
            r["finding_severity"]) == MERGE_EXPECTED


def test_snapshot_reads_a_string_date_of_birth_without_failing_under_ansi(spark):
    """§1 'Date of birth: read as a date; anything that does not read as a date is treated as missing' when the
    production column turns out to be a STRING (its type is unconfirmed). ANSI mode must not abort the snapshot."""
    import contextlib
    import io
    from pyspark.sql.types import StringType, StructField, StructType
    fields = [f if f.name != C["dob"] else StructField(C["dob"], StringType()) for f in claims_schema().fields]
    vals = ["2004-02-29", "02/29/2004", "garbage", "", "2003-02-29", None]
    rows = [(f"C{i}", 1, f"M{i}", "P1", "B1", D(2025, 2, 28), "A0422", U("1"), P("10.00"), "11", "A",
             None, None, None, None, None, v, "08", "08") for i, v in enumerate(vals)]
    spark.createDataFrame(rows, StructType(fields)).write.mode("overwrite").format("parquet").saveAsTable(CLAIMS_TABLE)
    with contextlib.redirect_stdout(io.StringIO()):
        dg.create_snapshot(spark, source=dg.CLAIMS, target=dg.DETECT, fmt="parquet")
    got = {r[C["claim_id"]]: r[dg.PIE_DOB] for r in spark.table(SNAPSHOT_TABLE).collect()}
    assert got == {"C0": D(2004, 2, 29), "C1": None, "C2": None, "C3": None, "C4": None, "C5": None}
    rule = _state("AGE", {"type": "code_not_covered", "code": "A0422", "age": {"min": 21}})
    d, = dg.build_detectors([rule])
    assert [r["claim_id"] for r in run_sql(spark, d["sql"])] == ["C0"]     # 21 on 28 Feb 2025 (ADD_MONTHS)


# ===================================================================================== (v2.6) hand-computed cases
def _r6(claim, line, code, *, member, sprov="P1", bprov="B1", units="1", paid="10.00", mods=(), pa=None, btype=None,
        ptype="08", dos=D(2024, 3, 5)):
    return _r(claim, line, code, units=units, paid=paid, member=member, sprov=sprov, mods=mods, pa=pa, dos=dos,
              ptype=ptype, btype=btype, bprov=bprov)


V26_ROWS = [
    # §2 Code pair, H2018 (code_a) / H2014 (code_b): billing ids equal, padded, other CASE, missing, other servicing
    # provider, and a code_b line pairing with two code_a lines of different billing ids
    _r6("C1", 1, "H2018", member="M1"), _r6("C1", 2, "H2014", member="M1"),
    _r6("C2", 1, "H2018", member="M2", bprov=" B1 "), _r6("C3", 1, "H2014", member="M2"),
    _r6("C4", 1, "H2018", member="M3", bprov="b1"), _r6("C5", 1, "H2014", member="M3"),
    _r6("C6", 1, "H2018", member="M4", bprov=None), _r6("C7", 1, "H2014", member="M4", bprov="  "),
    _r6("C8", 1, "H2018", member="M5", bprov="B2"), _r6("C9", 1, "H2014", member="M5", sprov="P2", bprov="B2"),
    _r6("C10", 1, "H2018", member="M6"), _r6("C10", 2, "H2018", member="M6", bprov="B2", paid="11.00"),
    _r6("C11", 1, "H2014", member="M6", bprov="B2"),
    # §2 Units per day A0422 (threshold 2) under the three scopes + §3 daily-cap labels
    _r6("D1", 1, "A0422", member="M7", units="2", paid="20.00"), _r6("D1", 2, "A0422", member="M7"),
    _r6("D2", 1, "A0422", member="M7", bprov="B2", units="2", paid="20.00"),
    _r6("D3", 1, "A0422", member="M7", bprov=None),
    _r6("D4", 1, "A0422", member="M7", sprov="P2", units="3", paid="30.00", mods=("59",)),     # span beats modifier
    _r6("D5", 1, "A0422", member="M8", units="1.5", paid="15.00", mods=(" rt",)),              # modifier (RT)
    _r6("D5", 2, "A0422", member="M8"),
    _r6("D6", 1, "A0422", member="M9", units="3", paid="30.00", pa="PA1"),                     # PA beats span
    _r6("D8", 1, "A0422", member="M10", units="3", paid="30.00"),                             # cancelled by R8 (N4)
    _r6("R8", 1, "A0422", member="M10", units="-3", paid="-30.00"),
    _r6("D8", 2, "A0422", member="M10", units="1.5", paid="15.00"), _r6("D8", 3, "A0422", member="M10"),
    # a recoupment booked with POSITIVE units over the cap: counted as -3 (§1), so it never makes verify_span (A27)
    _r6("D16", 1, "A0422", member="M15", units="2", paid="20.00"),
    _r6("D16", 2, "A0422", member="M15", units="2", paid="20.00"),
    _r6("D16", 3, "A0422", member="M15", units="2", paid="20.00"),
    _r6("R16", 1, "A0422", member="M15", units="3", paid="-5.00"),
    # (v2.6, N4) §3 labels read PAYABLE lines only: a cancelled long line with listed modifiers + its reversal (booked
    # positive) + payable lines over the cap -> own label; an orphan reversal / a paid 0-unit line with a listed modifier
    # (counted, never payable) -> own label; a payable line with NO units and a listed modifier -> verify_modifier; a
    # cancelled long line + reversal + a PAYABLE line over the cap -> verify_span (the payable line decides)
    _r6("D17", 1, "A0422", member="M16", units="3", paid="30.00", mods=("RT", "59")),         # cancelled by R17
    _r6("R17", 1, "A0422", member="M16", units="3", paid="-30.00", mods=(" rt", "59 ")),
    _r6("D17", 2, "A0422", member="M16", units="2", paid="20.00", mods=("25",)),              # 25: not listed
    _r6("D17", 3, "A0422", member="M16"),
    _r6("D18", 1, "A0422", member="M17", units="2", paid="20.00"), _r6("D18", 2, "A0422", member="M17"),
    _r6("R18", 1, "A0422", member="M17", units="-0.5", paid="-5.00", mods=("LT",)),           # orphan: cancels nothing
    _r6("D19", 1, "A0422", member="M18", units="2", paid="20.00"), _r6("D19", 2, "A0422", member="M18"),
    _r6("D19", 3, "A0422", member="M18", units="0", paid="5.00", mods=("76",)),               # counted, not payable
    _r6("D20", 1, "A0422", member="M19", units="2", paid="20.00"), _r6("D20", 2, "A0422", member="M19"),
    _r6("D20", 3, "A0422", member="M19", units=None, paid="5.00", mods=("XU",)),              # payable, no units
    _r6("D21", 1, "A0422", member="M20", units="4", paid="40.00", mods=("RT",)),              # cancelled by R21 ...
    _r6("R21", 1, "A0422", member="M20", units="-4", paid="-40.00", mods=("RT",)),
    _r6("D21", 2, "A0422", member="M20", units="3", paid="30.00"),                            # ... a payable line spans
    # max_units_per_dos T1019 (threshold 2) with an exception: span / modifier beat it, else verify_exception
    _r6("D9", 1, "T1019", member="M11", units="3", paid="30.00"),
    _r6("D10", 1, "T1019", member="M12", mods=("50",)), _r6("D10", 2, "T1019", member="M12", units="2", paid="20.00"),
    _r6("D11", 1, "T1019", member="M13", units="2", paid="20.00"),
    _r6("D11", 2, "T1019", member="M13", units="1.5", paid="15.00"),
    _r6("D22", 1, "T1019", member="M21", units="3", paid="30.00", mods=("50",)),              # N4: cancelled by R22
    _r6("R22", 1, "T1019", member="M21", units="-3", paid="-30.00", mods=("50",)),
    _r6("D22", 2, "T1019", member="M21", units="2", paid="20.00"), _r6("D22", 3, "T1019", member="M21"),
    # §2 provider type allowed G0466, list 08 / c2: group billing '1' / ' 01 ' / '01.0' / '01', other billers
    _r6("G1", 1, "G0466", member="M14", btype="1", ptype="08"),
    _r6("G1", 2, "G0466", member="M14", btype=" 01 ", ptype="31"),
    _r6("G1", 3, "G0466", member="M14", btype="01.0", ptype=None),
    _r6("G1", 4, "G0466", member="M14", btype="01", ptype="NULL"),
    _r6("G1", 5, "G0466", member="M14", btype="C2", ptype="31"),
    _r6("G1", 6, "G0466", member="M14", btype=None, ptype="31"),
    _r6("G1", 7, "G0466", member="M14", btype="02", ptype="08"),
    _r6("G1", 8, "G0466", member="M14", btype="1", ptype="c2", pa="PA5"),
    _r6("G1", 9, "G0466", member="M14", btype=" 1 ", ptype="ZZ", pa="PA6"),
]
_PAIR6 = {"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2014", "modifier_indicator": "0"}
_DAY6 = {"type": "max_units_per_day", "code": "A0422", "threshold": 2}
_PTA6 = {"type": "provider_type_allowed", "code": "G0466", "provider_types": ["08", "c2"]}
V26_RULES = {
    "P-MSB": _state("P-MSB", dict(_PAIR6, scope="member_servicing_billing_day")),
    "P-MPD": _state("P-MPD", dict(_PAIR6, scope="member_provider_day")),
    "D-MSB": _state("D-MSB", dict(_DAY6, scope="member_servicing_billing_day")),
    "D-MPD": _state("D-MPD", dict(_DAY6, scope="member_provider_day")),
    "D-MD": _state("D-MD", dict(_DAY6)),
    "DOS-EXC": _state("DOS-EXC", {"type": "max_units_per_dos", "code": "T1019", "threshold": 2,
                                  "exception": EXCEPTION_TEXT}),
    "PTA-BR": _state("PTA-BR", dict(_PTA6, provider_role="billing_or_rendering")),
    "PTA-B": _state("PTA-B", dict(_PTA6, provider_role="billing")),
}
_HD, _UO, _VS, _VM, _VP, _PT = ("hard_denial", "units_over_limit", "verify_span", "verify_modifier", "verify_pa",
                                "provider_type_not_allowed")
_MSB, _MPD = "member_servicing_billing_day", "member_provider_day"


def v26_expected(groups=("01",)):
    """By hand from §2 / §3 v2.6. Pair: (claim, line, member, severity, evidence, pair_scope); daily: (member, servicing,
    billing, observed, excess, paid, at risk, severity, evidence); provider type: (claim, line, severity, text form)."""
    m10 = ("2.5", "0.5", "25.00", "5.00", _UO, ("D8:1", "D8:2", "D8:3", "R8:1"))   # N4: cancelled D8:1 never spans
    m8 = ("2.5", "0.5", "25.00", "5.00", _VM, ("D5:1", "D5:2"))
    m9 = ("3", "1", "30.00", "10.00", _VP, ("D6:1",))
    m15 = ("3", "1", "55.00", "18.33", _UO, ("D16:1", "D16:2", "D16:3", "R16:1"))   # R16's raw 3 units never span
    n4 = {"M16": ("3", "1", "30.00", "10.00", _UO, ("D17:1", "D17:2", "D17:3", "R17:1")),   # (pre-N4: verify_span)
          "M17": ("2.5", "0.5", "25.00", "5.00", _UO, ("D18:1", "D18:2", "R18:1")),         # (pre-N4: verify_modifier)
          "M18": ("3", "1", "35.00", "11.67", _UO, ("D19:1", "D19:2", "D19:3")),            # (pre-N4: verify_modifier)
          "M19": ("3", "1", "35.00", "11.67", _VM, ("D20:1", "D20:2", "D20:3")),            # payable, no units, XU
          "M20": ("3", "1", "30.00", "10.00", _VS, ("D21:1", "D21:2", "R21:1"))}            # D21:2 alone over
    exp = {
        "P-MSB": [("C1", 2, "M1", _HD, ("C1:1",), _MSB), ("C3", 1, "M2", _HD, ("C2:1",), _MSB),
                  ("C11", 1, "M6", _HD, ("C10:2",), _MSB)],
        "P-MPD": [("C1", 2, "M1", _HD, ("C1:1",), _MPD), ("C3", 1, "M2", _HD, ("C2:1",), _MPD),
                  ("C5", 1, "M3", _HD, ("C4:1",), _MPD), ("C7", 1, "M4", _HD, ("C6:1",), _MPD),
                  ("C11", 1, "M6", _HD, ("C10:1", "C10:2"), _MPD)],
        "D-MSB": [("M7", "P1", "B1", "3", "1", "30.00", "10.00", _UO, ("D1:1", "D1:2")),
                  ("M7", "P2", "B1", "3", "1", "30.00", "10.00", _VS, ("D4:1",)),
                  ("M8", "P1", "B1") + m8, ("M9", "P1", "B1") + m9, ("M10", "P1", "B1") + m10,
                  ("M15", "P1", "B1") + m15] + [(m, "P1", "B1") + t for m, t in n4.items()],
        "D-MPD": [("M7", "P1", None, "6", "4", "60.00", "40.00", _UO, ("D1:1", "D1:2", "D2:1", "D3:1")),
                  ("M7", "P2", None, "3", "1", "30.00", "10.00", _VS, ("D4:1",)),
                  ("M8", "P1", None) + m8, ("M9", "P1", None) + m9, ("M10", "P1", None) + m10,
                  ("M15", "P1", None) + m15] + [(m, "P1", None) + t for m, t in n4.items()],
        "D-MD": [("M7", None, None, "9", "7", "90.00", "70.00", _VS, ("D1:1", "D1:2", "D2:1", "D3:1", "D4:1")),
                 ("M8", None, None) + m8, ("M9", None, None) + m9, ("M10", None, None) + m10,
                 ("M15", None, None) + m15] + [(m, None, None) + t for m, t in n4.items()],
        "DOS-EXC": [("M11", "P1", None, "3", "1", "30.00", "10.00", _VS, ("D9:1",)),
                    ("M12", "P1", None, "3", "1", "30.00", "10.00", _VM, ("D10:1", "D10:2")),
                    ("M13", "P1", None, "3.5", "1.5", "35.00", "15.00", "verify_exception", ("D11:1", "D11:2")),
                    ("M21", "P1", None, "3", "1", "30.00", "10.00", "verify_exception",          # (pre-N4: verify_span)
                     ("D22:1", "D22:2", "D22:3", "R22:1"))],
        "PTA-BR": [("G1", 2, _PT, ("group", "31", "01")), ("G1", 7, _PT, ("other",)), ("G1", 9, _VP, ("group", "ZZ", "01"))],
        "PTA-B": [("G1", 1, _PT, ("other",)), ("G1", 2, _PT, ("other",)), ("G1", 3, _PT, ("other",)),
                  ("G1", 4, _PT, ("other",)), ("G1", 7, _PT, ("other",)), ("G1", 8, _VP, ("other",)),
                  ("G1", 9, _VP, ("other",))],
    }
    if "C2" in {clean_prov_type(str(g)) for g in groups}:          # an FQHC (C2) as a group type too: G1:5 judged on 31
        exp["PTA-BR"].append(("G1", 5, _PT, ("group", "31", "C2")))
    return {k: sorted(v, key=repr) for k, v in exp.items()}


def _v26_tuple(rule, f):
    t = rule["predicate"]["type"]
    if t == "code_pair_prohibited":
        return (f["key"][0], f["key"][1], f["key"][2], f["finding_severity"],
                tuple(ev_str(e) for e in f["evidence"]), f["pair_scope"])
    if t in ("max_units_per_day", "max_units_per_dos"):
        return (f["key"][0], f["servicing_provider"], f["billing_provider"], str(_num(f["observed_units"])),
                str(_num(f["excess_units"])), str(_q2(f["paid_amt"])), str(_q2(f["paid_at_risk"])),
                f["finding_severity"], tuple(ev_str(e) for e in f["evidence"]))
    form = f["finding_form"]
    return (f["key"][0], f["key"][1], f["finding_severity"], form[:3] if form[0] == "group" else form)


def _v26_sql_tuple(rule, row):
    t = rule["predicate"]["type"]
    ev_ = tuple(parse_evidence(row.get("evidence_lines")) or ())
    if t == "code_pair_prohibited":
        return (row["claim_id"], row["line_no"], row["member_id"], row["finding_severity"], ev_, row.get("pair_scope"))
    if t in ("max_units_per_day", "max_units_per_dos"):
        return (row["member_id"], row.get("servicing_provider"), row.get("billing_provider"),
                str(_num(row["observed_units"])), str(_num(row["excess_units"])), str(_q2(row["paid_amt"])),
                str(_q2(row["paid_at_risk"])), row["finding_severity"], ev_)
    form = finding_form(row.get("finding"), ["G0466"])
    return (row["claim_id"], row["line_no"], row["finding_severity"], form[:3] if form[0] == "group" else form)


V26_GROUP_VARIANTS = {"default": None, "group_types_1_and_c2": ("1", " c2 ")}


@pytest.mark.parametrize("variant", sorted(V26_GROUP_VARIANTS))
def test_v26_oracle_pins_hand_computed_cases(monkeypatch, variant):
    """The oracle itself (no Spark) on V26_ROWS against the HAND-computed answer: the scope member_servicing_billing_day
    for a pair and a daily cap (billing ids equal / padded / other case / missing), the three daily scopes, §3's
    daily-cap labels (PA > span > modifier > exception) on PAYABLE lines only (N4, A27: a cancelled long line with listed
    modifiers and its reversal, an orphan reversal and a paid 0-unit line with a listed modifier never decide a label; a
    payable line with no units and a listed modifier, or a payable line alone over the cap, does), billing_or_rendering
    (group type spelled '1' / ' 01 ' / '01.0'; rendering type allowed / not allowed / missing / textual null; billing
    type missing -> no fall-back) and its finding-text form."""
    if V26_GROUP_VARIANTS[variant]:
        monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", V26_GROUP_VARIANTS[variant])
    assert daily_cap_modifiers() == DAILY_CAP_MODIFIERS_SPEC, "config.DAILY_CAP_VERIFY_MODIFIERS differs from §3's list"
    assert group_types() == ({"01"} if variant == "default" else {"01", "C2"})
    assert [clean_prov_type(x) for x in ("1", " 01 ", "01.0", "1.00", " 1 ")] == ["01"] * 5
    snap = build_snapshot(V26_ROWS, cover=False, cfg=DEFAULT_ROUTING)
    want = v26_expected(V26_GROUP_VARIANTS[variant] or ("01",))
    for rid, rule in V26_RULES.items():
        got = sorted((_v26_tuple(rule, f) for f in oracle_findings(rule, snap)), key=repr)
        assert got == want[rid], (rid, got)


@pytest.mark.parametrize("variant", sorted(V26_GROUP_VARIANTS))
def test_v26_fixed_cases_through_spark(spark, monkeypatch, variant):
    """V26_ROWS through the per-rule SQL, against the HAND-computed answer (not the oracle), including the group finding
    text ('{codes} rendered by provider type {st} for a group ({bt}) (allowed: {list})': list = 08 / C2, G0466 named)."""
    if V26_GROUP_VARIANTS[variant]:
        monkeypatch.setattr(config, "GROUP_BILLING_PROVIDER_TYPES", V26_GROUP_VARIANTS[variant])
    out = _run_case(spark, V26_ROWS, list(V26_RULES.values()))
    want = v26_expected(V26_GROUP_VARIANTS[variant] or ("01",))
    bad = {}
    for rid, rule in V26_RULES.items():
        if out[rid] is None:
            bad[rid] = "did not compile"
            continue
        got = sorted((_v26_sql_tuple(rule, r) for r in out[rid]), key=repr)
        if got != want[rid]:
            bad[rid] = {"want": want[rid], "got": got}
        for r in out[rid]:
            form = finding_form(r.get("finding"), ["G0466"]) if rule["predicate"]["type"] == "provider_type_allowed" \
                else None
            if form and form[0] == "group" and (form[3] != frozenset({"08", "C2"}) or not form[4]):
                bad.setdefault(rid + ":text", []).append(r.get("finding"))
    MISMATCHES.extend({"query": f"v26_fixed:{variant}:{k}", "type": "fixed_case", "key": repr(v)[:1500]}
                      for k, v in bad.items())
    assert not bad, bad
