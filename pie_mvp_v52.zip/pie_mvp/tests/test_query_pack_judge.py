"""The query validation pack must FAIL a wrong query. Two mutants survived the red-team run of 2026-10-02 because
nothing checked this: a query that does not run was reported PASS on every scenario (P01), and a query that flags
MORE than expected - every "must NOT flag" scenario - passed (P02). Offline: a fake Spark returns what a wrong
query would return. Run: cd pie_mvp && python -m pytest tests/test_query_pack_judge.py -q"""
import os
import sys

import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import detector_gen as dg  # noqa: E402
import kb_io  # noqa: E402
import query_pack as qp  # noqa: E402
from schema import Rule  # noqa: E402


def _rule(pred):
    codes = [pred[k] for k in ("code_a", "code_b", "code") if pred.get(k)] + list(pred.get("code_set") or [])
    r = Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy", statement=f"t {codes}",
             source_doc="Ch19", source_locator="p", predicate=pred, codes=codes).assign_id().to_dict()
    r["reviewer"] = "SS"
    return r


PAIR = _rule({"type": "code_pair_prohibited", "code_a": "S9484", "code_b": "S9485", "modifier_indicator": "0",
              "scope": "member_provider_day"})
CAP = _rule({"type": "max_units_per_day", "code": "A0422", "threshold": 1})


class _Row(dict):
    def asDict(self):
        return dict(self)


class _Res:
    def __init__(self, rows):
        self.rows = rows

    def collect(self):
        return [_Row(r) for r in self.rows]


class _FakeSpark:
    """spark.sql(text): raises when `boom`, otherwise returns `answer(text)`."""
    def __init__(self, answer=None, boom=False):
        self.answer, self.boom = answer, boom

    def sql(self, text):
        if self.boom:
            raise RuntimeError("[PARSE_SYNTAX_ERROR] broken query")
        return _Res(self.answer(text))


@pytest.fixture
def offline(monkeypatch):
    monkeypatch.setattr(qp, "_write_claims", lambda spark, df, fmt: None)
    monkeypatch.setattr(kb_io, "write_table", lambda *a, **k: 0)


def _pack(spark, rule):
    dets = dg.build_detectors([rule])
    assert dets[0]["compiled"], dets[0]["reason"]
    return qp.build_pack(spark, [rule], dets, fmt="parquet", build_id="BX")


@pytest.mark.parametrize("rule", [PAIR, CAP], ids=["pair", "daily_cap"])
def test_a_query_that_does_not_run_fails_every_scenario(offline, rule):
    q, s = _pack(_FakeSpark(boom=True), rule)
    assert len(s) > 0 and not s["pass"].any()                        # P01: never PASS on an error
    assert s["result"].str.contains("broken query").all()
    assert q.loc[q["query_id"] == rule["rule_id"], "auto_test"].iloc[0] == "FAIL"


@pytest.mark.parametrize("rule", [PAIR, CAP], ids=["pair", "daily_cap"])
def test_a_query_that_flags_every_scenario_member_fails(offline, rule):
    """The worst defect is a query that over-flags: every 'must NOT flag' scenario must catch it (P02)."""
    scs = qp.scenarios(rule, "Q000")
    assert any(sc["expect"] == 0 for sc in scs) and any(sc["expect"] >= 1 for sc in scs)
    sev = next(sc["severity"] for sc in scs if sc["expect"])
    everyone = [{"member_id": sc["member"], "finding_severity": sev} for sc in scs]
    q, s = _pack(_FakeSpark(answer=lambda text: everyone), rule)
    neg = s[s["expected_findings"] == 0]
    assert len(neg) and not neg["pass"].any()
    assert q.loc[q["query_id"] == rule["rule_id"], "auto_test"].iloc[0] == "FAIL"


def test_a_query_that_finds_one_too_many_or_none_fails_and_the_right_answer_passes(offline):
    scs = qp.scenarios(CAP, "Q000")

    def answer(extra=0, drop=False):
        rows = []
        for sc in scs:
            n = 0 if drop else sc["expect"] + (extra if sc["expect"] else 0)
            rows += [{"member_id": sc["member"], "finding_severity": sc["severity"]}] * n
        return lambda text: rows

    q, s = _pack(_FakeSpark(answer=answer()), CAP)
    assert s["pass"].all() and q["auto_test"].iloc[0] == "PASS"       # the fake that answers right passes
    for wrong in (answer(extra=1), answer(drop=True)):
        q, s = _pack(_FakeSpark(answer=wrong), CAP)
        assert q["auto_test"].iloc[0] == "FAIL" and not s["pass"].all()


def test_judge_checks_count_member_rule_and_severity():
    sc = {"member": "M1", "expect": 1, "severity": "units_over_limit", "rule_id": "R1"}
    f = lambda m="M1", sev="units_over_limit", rid="R1": {"member_id": m, "finding_severity": sev, "rule_id": rid}
    assert qp._judge([f()], sc)[0]
    assert not qp._judge([f(), f()], sc)[0]                          # one too many
    assert not qp._judge([], sc)[0]                                  # missed
    assert not qp._judge([f(sev="verify_pa")], sc)[0]                # wrong label
    assert qp._judge([f(), f(m="M2"), f(rid="R2")], sc)[0]           # other members / other edit rows ignored
    assert not qp._judge([f()], dict(sc, expect=0))[0]               # must NOT flag
    assert qp._judge([f(m="M2")], dict(sc, expect=0))[0]


def test_the_pack_says_which_dates_a_query_judges(offline):
    """2026-10-03: 60 of 63 compiled state rules carry no start date, so they judge every date of service. A blank
    effective_date cell is easy to miss; the pack states it in words."""
    q, _ = _pack(_FakeSpark(answer=lambda text: []), CAP)
    assert q["dates_covered"].iloc[0].startswith("every date of service - the source gives no start date")
    dated = dict(CAP, effective_date="2024-10-01")
    assert qp.dates_covered(dated) == "from 2024-10-01"
    assert qp.dates_covered(dict(dated, end_date="2025-09-30")) == "2024-10-01 to 2025-09-30"
