"""quality.py: Wilson interval, sample-size planning, deterministic stratified sampling, metric edge cases, and
(2026-10-04, external review) the measurement fixes: recall on REAL rules found, executable-rule precision, filter loss,
the engine-before-review population, and v03's GO / NOT YET verdicts.
Run: cd pie_mvp && python -m pytest tests -q
"""
import json
import math
import os
import sys

import pandas as pd
import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import quality as q


# ------------------------------------------------------------------ wilson
def _wilson_by_hand(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z / d * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return c - h, c + h


def test_wilson_95_of_100():
    p, lo, hi = q.wilson(95, 100)
    assert p == pytest.approx(0.95)
    assert lo == pytest.approx(0.8883, abs=5e-4)          # published value 0.888
    assert hi == pytest.approx(0.9785, abs=5e-4)          # published value 0.978
    assert (lo, hi) == pytest.approx(_wilson_by_hand(95, 100))


@pytest.mark.parametrize("k,n,lo,hi", [
    (0, 10, 0.0, 0.2775),      # all failures: lower bound pinned at 0, upper well above 0
    (10, 10, 0.7225, 1.0),     # all successes: upper bound 1, lower bound well below 1
    (5, 10, 0.2366, 0.7634),   # symmetric around 0.5
    (18, 20, 0.6990, 0.9721),  # the "n=20 can't tell 95% from 80%" case in GAP_TO_DONE
])
def test_wilson_known_values(k, n, lo, hi):
    _, a, b = q.wilson(k, n)
    assert a == pytest.approx(lo, abs=5e-4) and b == pytest.approx(hi, abs=5e-4)


def test_wilson_n_zero_is_uninformative():
    p, lo, hi = q.wilson(0, 0)
    assert math.isnan(p) and lo == 0.0 and hi == 1.0


def test_wilson_rejects_k_above_n():
    with pytest.raises(ValueError):
        q.wilson(5, 4)


# ------------------------------------------------------------------ n_needed
def test_n_needed_reaches_target_and_is_minimal():
    n = q.n_needed(0.98, 0.95)
    assert n is not None
    assert q.wilson(0.98 * n, n)[1] >= 0.95
    assert q.wilson(0.98 * (n - 1), n - 1)[1] < 0.95


def test_n_needed_impossible_when_rate_not_above_target():
    assert q.n_needed(0.95, 0.95) is None
    assert q.n_needed(0.90, 0.95) is None
    assert q.n_needed(float("nan"), 0.95) is None


def test_n_needed_perfect_rate_closed_form():
    # p=1: lo = n / (n + z^2) >= t  <=>  n >= t z^2 / (1 - t)
    z = 1.96
    assert q.n_needed(1.0, 0.95) == math.ceil(0.95 * z * z / 0.05)


def test_n_for_ci_width_minimal_and_monotone():
    n = q.n_for_ci_width(0.9, 0.10)
    _, lo, hi = q.wilson(0.9 * n, n)
    assert hi - lo <= 0.10
    _, lo, hi = q.wilson(0.9 * (n - 1), n - 1)
    assert hi - lo > 0.10
    assert q.n_for_ci_width(0.5, 0.10) > n                   # p = 0.5 is the widest
    assert q.n_for_ci_width(float("nan"), 0.1) is None


# ------------------------------------------------------------------ sampling
def _frame(n=60):
    return pd.DataFrame({"chapter": [str(10 + i % 3) for i in range(n)],
                         "src": ["pattern" if i % 2 else "model" for i in range(n)],
                         "rule_id": [f"R{i:03d}" for i in range(n)]})


def test_stratified_sample_is_deterministic_and_order_independent():
    df = _frame()
    a = q.stratified_sample(df, ["chapter", "src"], 3, seed=7, key=["rule_id"])
    b = q.stratified_sample(df.sample(frac=1, random_state=1), ["chapter", "src"], 3, seed=7, key=["rule_id"])
    assert list(a["rule_id"]) == list(b["rule_id"])
    assert len(a) == 6 * 3
    assert set(a["stratum_size"]) == {10}
    c = q.stratified_sample(df, ["chapter", "src"], 3, seed=8, key=["rule_id"])
    assert set(c["rule_id"]) != set(a["rule_id"])            # the seed matters


def test_stratified_sample_small_strata_and_nulls():
    df = pd.DataFrame({"chapter": ["10", "10", None], "rule_id": ["a", "b", "c"]})
    s = q.stratified_sample(df, ["chapter"], 5, seed=1, key=["rule_id"])
    assert len(s) == 3                                        # smaller than n_per: take all
    assert set(s["stratum"]) == {"10", "(none)"}
    assert s["chapter"].isna().sum() == 1                     # data itself is not rewritten


def test_stratified_sample_adding_rows_keeps_old_picks_unless_displaced():
    df = _frame(30)
    a = q.stratified_sample(df, ["chapter"], 4, seed=3, key=["rule_id"])
    more = pd.concat([df, pd.DataFrame({"chapter": ["99"], "src": ["model"], "rule_id": ["NEW"]})])
    b = q.stratified_sample(more, ["chapter"], 4, seed=3, key=["rule_id"])
    assert set(a["rule_id"]) <= set(b["rule_id"])


def test_stratified_sample_empty():
    s = q.stratified_sample(pd.DataFrame(columns=["chapter", "rule_id"]), ["chapter"], 3)
    assert len(s) == 0 and "stratum" in s.columns


def test_sample_hash_sql_mentions_every_key():
    sql = q.sample_hash_sql(["claim_id", "line_no"], 5)
    assert "'5#'" in sql and "claim_id" in sql and "line_no" in sql and "sha2" in sql


# ------------------------------------------------------------------ extraction metrics
def test_extraction_metrics_basic_and_blank_scores():
    rules = pd.DataFrame({"chapter": ["10"] * 4 + ["19"] * 2,
                          "is_real_rule": ["Y", "Y", "N", None, "yes", "n"],
                          "faithful_to_source": ["Y", "N", "Y", None, "Y", None]})
    # 2026-10-04: recall counts the REAL rules found (real_rules_found), not every draft (rules_extracted)
    secs = pd.DataFrame({"chapter": ["10", "10", "19"], "rules_extracted": [2, 0, 1], "real_rules_found": [2, 0, 1],
                         "missed_rules": [1, 1, None]})
    m = q.extraction_metrics(rules, secs).set_index(["metric", "scope"])
    assert m.loc[("extraction_precision", "10"), "n"] == 3            # blank excluded
    assert m.loc[("extraction_precision", "10"), "value"] == pytest.approx(2 / 3)
    assert "1 unscored" in m.loc[("extraction_precision", "10"), "notes"]
    # fidelity among REAL rules only: ch10 real = 2 (Y,Y) -> faithful Y,N
    assert m.loc[("extraction_fidelity", "10"), "n"] == 2
    assert m.loc[("extraction_fidelity", "10"), "value"] == pytest.approx(0.5)
    assert m.loc[("extraction_precision", "all"), "n"] == 5
    # recall: ch10 found 2, missed 2 -> 0.5 ; ch19 unscored -> n = 0
    assert m.loc[("extraction_recall", "10"), "value"] == pytest.approx(0.5)
    assert m.loc[("extraction_recall", "19"), "n"] == 0
    assert math.isnan(m.loc[("extraction_recall", "19"), "value"])
    assert m.loc[("extraction_recall", "all"), "n"] == 4


def test_extraction_metrics_empty_inputs():
    assert len(q.extraction_metrics(None, None)) == 0
    m = q.extraction_metrics(pd.DataFrame({"chapter": ["10"], "is_real_rule": [None],
                                           "faithful_to_source": [None]}), None)
    row = m[(m.metric == "extraction_precision") & (m.scope == "10")].iloc[0]
    assert row["n"] == 0 and math.isnan(row["value"]) and row["ci_low"] == 0.0 and row["ci_high"] == 1.0


def test_extraction_recall_all_found_nothing_missed():
    secs = pd.DataFrame({"chapter": ["4"], "rules_extracted": [3], "real_rules_found": [3], "missed_rules": [0]})
    r = q.extraction_metrics(None, secs).iloc[0]
    assert r["value"] == 1.0 and r["n"] == 3


# ------------------------------------------------------------------ 2026-10-04: recall on REAL rules found
def test_recall_counts_real_rules_found_not_every_draft():
    """A section with 5 drafts of which 2 are real rules, and 1 rule the engine missed: recall is 2/3. The old formula
    took rules_extracted as 'found' and said 5/6 - the 3 wrong drafts RAISED recall."""
    secs = pd.DataFrame({"chapter": ["19"], "rules_extracted": [5], "real_rules_found": [2], "missed_rules": [1]})
    r = q.extraction_metrics(None, secs).set_index(["metric", "scope"]).loc[("extraction_recall", "19")]
    assert (r["n"], r["value"]) == (3, pytest.approx(2 / 3))
    assert r["value"] != pytest.approx(5 / 6)
    assert "2 real rule(s) found, 1 missed" in r["notes"]


def test_recall_section_counts_only_when_both_numbers_are_filled():
    secs = pd.DataFrame({"chapter": ["10"] * 5,
                         "rules_extracted": [2, 2, 1, 3, 1],
                         "real_rules_found": [2, None, 1, "", 4],       # row 5: more real rules than drafts = a slip
                         "missed_rules": [0, 1, None, 2, 0]})
    r = q.extraction_metrics(None, secs).set_index(["metric", "scope"]).loc[("extraction_recall", "10")]
    assert (r["n"], r["value"]) == (2, 1.0)                     # only row 1 is complete and consistent (never assumed)
    assert "3 section(s) without both real_rules_found and missed_rules excluded" in r["notes"]
    assert "1 section(s) excluded: real_rules_found is above rules_extracted" in r["notes"]
    # a workbook exported before real_rules_found existed: recall is not computed from it, and the notes say so
    old = pd.DataFrame({"chapter": ["10"], "rules_extracted": [5], "missed_rules": [1]})
    r = q.extraction_metrics(None, old).iloc[0]
    assert r["n"] == 0 and "no real_rules_found column" in r["notes"]


# ------------------------------------------------------------------ 2026-10-04: precision of the rules that become queries
def _pred(t, **kw):
    return json.dumps({"type": t, **kw})


def test_executable_rule_precision_counts_real_but_unfaithful_against_it_and_leaves_leads_out():
    rules = pd.DataFrame({
        "chapter": ["10"] * 7,
        "predicate": [_pred("code_not_covered", code="99070"),                 # real + faithful -> counts for
                      _pred("max_units_per_day", code="98960", threshold=4),   # real, UNFAITHFUL -> counts against
                      _pred("code_pair_prohibited", code_a="H0018", code_b="T1016"),  # not real -> against
                      _pred("not_checkable", reason="process_obligation"),     # a lead: never enters
                      _pred("modifier_required", code_set=["E0618"], modifier="RR"),  # authorable only: a lead
                      _pred("code_not_covered", code="11975"),                  # real, no fidelity score -> excluded
                      _pred("code_not_covered", code="11977")],                 # unscored -> excluded
        "is_real_rule": ["Y", "Y", "N", "Y", "N", "Y", None],
        "faithful_to_source": ["Y", "N", None, "N", None, None, None]})
    # a sheet in the current layout carries the type of the predicate it shows (2026-10-04, critic M51-3: a sheet
    # without predicate_type is an old export and yields no executable-rule precision at all)
    rules["predicate_type"] = [q.predicate_type_of(p) for p in rules["predicate"]]
    m = q.extraction_metrics(rules, None).set_index(["metric", "scope"])
    e = m.loc[("executable_rule_precision", "10")]
    assert (e["n"], e["value"]) == (3, pytest.approx(1 / 3)) and e["unscored"] == 2
    assert "1 real but unfaithful" in e["notes"] and "1 real rule(s) without faithful_to_source excluded" in e["notes"]
    assert "1 without is_real_rule excluded" in e["notes"]
    assert m.loc[("executable_rule_precision", "all"), "n"] == 3
    # the sheet's predicate_type column wins over the predicate text (the type of the predicate shown)
    rules["predicate_type"] = ["not_checkable"] + [None] * 6
    e = q.extraction_metrics(rules, None).set_index(["metric", "scope"]).loc[("executable_rule_precision", "10")]
    assert (e["n"], e["value"]) == (2, 0.0)
    # precision over every draft is still there, leads included
    assert m.loc[("extraction_precision", "10"), "n"] == 6


# ------------------------------------------------------------------ 2026-10-04: filter loss (DROPPED sheet)
def test_filter_loss_is_real_over_scored_dropped_candidates():
    d = pd.DataFrame({"chapter": ["10", "10", "10", "19", "19"],
                      "drop_class": ["quote not found in source", "post-check: pair_hub_spoke",
                                     "quote not found in source", "codes not in source", "codes not in source"],
                      "is_real_rule": ["Y", "N", "n", "yes", None],
                      "stratum": ["10 | q", "10 | p", "10 | q", "19 | c", "19 | c"],
                      "stratum_size": [40, 5, 40, 2, 2]})
    m = q.extraction_metrics(None, None, d).set_index(["metric", "scope"])
    a = m.loc[("extraction_filter_loss", "all")]
    # 2026-10-04 (critic M51-2): the rate itself is weighted by stratum size, not just the estimate in the notes:
    # 10|q 1/2 x 40 + 10|p 0 x 5 + 19|c 1/1 x 2 = 22 of 47 (the plain pool said 2 of 4)
    assert (a["n"], a["value"], a["unscored"]) == (4, pytest.approx(22 / 47), 1)
    assert "1 unscored row(s) excluded" in a["notes"] and "weighted by stratum size" in a["notes"]
    assert "about 22 of the 47 dropped candidate(s)" in a["notes"]
    assert m.loc[("extraction_filter_loss", "10"), "value"] == pytest.approx(20 / 45)     # 1/2 x 40 + 0 x 5 of 45
    assert m.loc[("extraction_filter_loss", "19"), "n"] == 1
    assert m.loc[("extraction_filter_loss", "quote not found in source"), "scope_type"] == "drop_class"
    assert m.loc[("extraction_filter_loss", "quote not found in source"), "value"] == pytest.approx(0.5)
    assert len(q.extraction_metrics(None, None, pd.DataFrame())) == 0


def test_drop_reason_class_strips_the_specifics():
    c = q.drop_reason_class
    assert c("duplicate of 19|code_not_covered|abc") == c("duplicate (post-check): merged into x") == "duplicate"
    assert c("not all codes in source (missing H0018, T1016)") == "not all codes in source"
    assert c("quote differs from source sentence in negation/condition/number tokens (nearest: 'x')") == \
        "quote differs from source sentence in negation/condition/number tokens"
    assert c("invalid predicate: code_a missing") == "invalid predicate"
    assert c("quote not found in source") == "quote not found in source"
    acts = json.dumps([{"check": "pair_hub_spoke", "action": "drop"}, {"check": "pair_scope_default", "action": "flag"}])
    assert c("post-check: the sentence bars H0014 with T1016", acts) == "post-check: pair_hub_spoke"
    assert c("post-check: whatever") == "post-check"
    assert c("post-check produced an invalid predicate: x") == "post-check: invalid predicate"
    assert c(None) == c(float("nan")) == "(no reason)"


# ------------------------------------------------------------------ 2026-10-04: the engine's own precision, before review
def _state_rows():
    fix_g = json.dumps({"superseded_by_reviewer": True, "reviewer": "SS",
                        "original_predicate": _pred("max_units_per_day", code="98960", threshold=4)})
    base = {"origin": "extracted", "chapter": "10", "doc_hash": "h10", "grounding": "{}", "review_decision": None,
            "predicate": _pred("code_not_covered", code="1")}
    rows = [dict(base, rule_id="A", review_status="approved", review_decision="approve"),
            dict(base, rule_id="R", review_status="rejected", review_decision="reject"),
            dict(base, rule_id="D", review_status="draft"),
            dict(base, rule_id="S", review_status="superseded"),
            dict(base, rule_id="OLD", review_status="draft", doc_hash="h10-old"),
            dict(base, rule_id="F", review_status="approved", review_decision="fix", grounding=fix_g,
                 predicate=_pred("max_units_per_day", code_set=["98960", "98961", "98962"], threshold=4)),
            dict(base, rule_id="W", review_status="approved", review_decision="fix"),     # dates / population only
            dict(base, rule_id="M", origin="manual", review_status="legacy_hand_authored", doc_hash=None),
            dict(base, rule_id="X", chapter="99", doc_hash="h99", review_status="draft")]   # no inventory row
    return pd.DataFrame(rows)


def test_scoring_population_is_every_current_draft_including_rejected_with_the_engines_predicate():
    pop, rep = q.scoring_population(_state_rows(), {"10": "h10"})
    assert sorted(pop["rule_id"]) == ["A", "D", "F", "R", "W"]           # rejected IN; superseded / old version / seeds out
    assert rep["superseded"] == 1 and rep["other_doc_version"] == 2 and rep["not_extracted"] == 1
    f = pop.set_index("rule_id").loc["F"]
    assert json.loads(f["predicate"]) == {"type": "max_units_per_day", "code": "98960", "threshold": 4}   # the ENGINE's
    assert "ENGINE's own predicate" in f["reviewer_fix"] and f["predicate_type"] == "max_units_per_day"
    assert "dates / population" in pop.set_index("rule_id").loc["W", "reviewer_fix"]
    assert pd.isna(pop.set_index("rule_id").loc["A", "reviewer_fix"])
    assert rep["fixed_engine_predicate_shown"] == 1
    # STATUSES = ["approved"]: the definition of done's sample - the SIGNED predicate is shown
    pop, rep = q.scoring_population(_state_rows(), {"10": "h10"}, ["approved"])
    assert sorted(pop["rule_id"]) == ["A", "F", "W"] and rep["other_status"] == 2
    f = pop.set_index("rule_id").loc["F"]
    assert json.loads(f["predicate"])["code_set"] == ["98960", "98961", "98962"] and "signed" in f["reviewer_fix"]


def test_current_run_rows_keeps_the_current_version_of_the_latest_run():
    d = pd.DataFrame({"chapter": ["10", "10", "10", "19", "19", "4"],
                      "doc_hash": ["h10", "h10", "h10-old", "h19", "h19", "h4"],
                      "run_id": ["20261001T0", "20261003T0", "20261003T0", "20261001T0", "20261002T0", "20261001T0"],
                      "x": list("abcdef")})
    rows, rep = q.current_run_rows(d, {"10": "h10", "19": "h19", "4": "h4"}, latest_run={"19": "20261001T0"})
    assert sorted(rows["x"]) == ["b", "d", "f"]       # ch10: newest run of h10; ch19: the log's latest run; ch4: its own
    assert rep == {"rows": 6, "other_doc_version": 1, "older_run": 2}
    assert len(q.current_run_rows(None, {})[0]) == 0


# ------------------------------------------------------------------ 2026-10-04: v03's GO / NOT YET verdicts
def test_lower_bound_bar_judges_the_lower_end_never_a_missing_number():
    assert q.lower_bound_bar(None, 0.95) == (False, "no scored sample (run v01 and ingest)")
    assert q.lower_bound_bar({"n": 0, "value": float("nan"), "ci_low": 0.0, "ci_high": 1.0}, 0.9)[0] is False
    p, lo, hi = q.wilson(100, 100)
    ok, why = q.lower_bound_bar({"n": 100, "value": p, "ci_low": lo, "ci_high": hi}, 0.95)
    assert ok and why.startswith("1.000, 95% CI 0.963")
    p, lo, hi = q.wilson(30, 30)                              # 30 of 30: rate 1.0, lower bound 0.886 - not yet
    ok, why = q.lower_bound_bar({"n": 30, "value": p, "ci_low": lo, "ci_high": hi}, 0.95, "scored real rules")
    assert not ok and f"about {q.n_needed(1.0, 0.95) - 30:,} more scored real rules needed" in why
    p, lo, hi = q.wilson(85, 100)
    ok, why = q.lower_bound_bar({"n": 100, "value": p, "ci_low": lo, "ci_high": hi}, 0.90)
    assert not ok and "more samples cannot fix it" in why


def test_routing_bar_uses_the_observed_provider_types():
    s = {"mode": "billing_provider_type", "types_signed": 3, "types_mapped": 140, "table": "routing.csv",
         "optional_on": [], "require_signed": True}
    ok, why = q.routing_bar(False, {"mode": "form"}, None, None)
    assert not ok and why.startswith("routing by claim form only")
    ok, why = q.routing_bar(True, s, ["02", "05", "08", "B2"], ["05", "B2"])
    assert not ok and why.startswith("2 of 4 provider type code(s) observed") and "e.g. 05, B2" in why
    assert "08 runs no NCCI statement" in why
    ok, why = q.routing_bar(True, s, ["02", "08"], [])
    assert ok and "all 2 provider type code(s)" in why and "routing by billing_provider_type" in why
    assert not q.routing_bar(True, s, [], [])[0]                       # nothing observed: nothing shows coverage
    assert not q.routing_bar(True, s, None, None)[0]                   # claims unreadable: cannot be judged


def test_corpus_bar_states_its_scope_and_waits_for_pending_sources():
    chapters = {"1": 0, "10": 0, "20-1": 0}
    ok, why = q.corpus_bar({"1": "a", "10": "b", "20-1": "c"}, chapters, {"same_day_disallow": ("d", "u"),
                                                                          "b2_matrix": ("d", "u")}, "corpus-x")
    assert not ok and ("2 rule source(s) still to load before the corpus is complete (config.CORPUS_PENDING): "
                       "same_day_disallow, b2_matrix") in why
    assert why.startswith("scope: AHCCCS FFS Provider Billing Manual chapters and exhibits; corpus corpus-x; 3 of 3")
    assert "AHCCCS policy" not in why and q.CORPUS_SCOPE == "AHCCCS FFS Provider Billing Manual chapters and exhibits"
    ok, why = q.corpus_bar({"1": "a", "10": "b"}, chapters, {}, "corpus-y")
    assert not ok and "2 of 3 documents ingested (missing 20-1)" in why
    assert q.corpus_bar({"1": "a", "10": "b", "20-1": "c"}, chapters, {}, "corpus-z")[0]


def test_signoff_bar_every_compiled_state_rule_has_a_named_reviewer():
    cs = pd.DataFrame({"rule_id": ["EXT-1", "EXT-2", "MAN-3"], "review_status": ["approved", "approved", "approved"],
                       "reviewer": ["SS", "Boss", "SS"]})
    ok, why = q.signoff_bar(cs)
    assert ok and "all 3 compiled state rule(s)" in why and "2 reviewer(s)" in why
    cs.loc[1, "reviewer"] = None
    cs.loc[2, "review_status"], cs.loc[2, "reviewer"] = "legacy_hand_authored", None    # a seed compiling unsigned
    ok, why = q.signoff_bar(cs)
    assert not ok and why.startswith("2 of 3 compiled state rule(s) lack") and "COMPILE_LEGACY_SEEDS" in why
    assert "EXT-2" in why and "MAN-3" in why
    assert q.signoff_bar(None)[0] is False and q.signoff_bar(pd.DataFrame())[0] is False


def test_corpus_differences_names_each_document():
    assert q.corpus_differences({"10": "aaaa", "19": "bbbb"}, {"10": "aaaa", "19": "cccc", "4": "d"}, "A", "B") == \
        ["4 only in B", "19: A bbbb vs B cccc"]
    assert q.corpus_differences({"10": "a"}, {"10": "a"}) == []


# ------------------------------------------------------------------ detector metrics
def test_detector_metrics_excludes_cannot_tell():
    f = pd.DataFrame({"origin": ["ncci"] * 4 + ["extracted"] * 2,
                      "predicate_type": ["code_pair_prohibited"] * 4 + ["code_not_covered"] * 2,
                      "disposition": ["true_violation", "false_positive", "cannot_tell", "  TRUE_VIOLATION ",
                                      "bogus", None]})
    m = q.detector_metrics(f).set_index(["metric", "scope"])
    k = ("detector_precision", "ncci | code_pair_prohibited")
    assert m.loc[k, "n"] == 3 and m.loc[k, "value"] == pytest.approx(2 / 3)
    assert m.loc[("detector_cannot_tell_share", "ncci | code_pair_prohibited"), "value"] == pytest.approx(1 / 4)
    e = ("detector_precision", "extracted | code_not_covered")
    assert m.loc[e, "n"] == 0 and "2 blank/invalid" in m.loc[e, "notes"]


def test_detector_metrics_all_cannot_tell():
    f = pd.DataFrame({"stratum": ["s"] * 3, "disposition": ["cannot_tell"] * 3})
    m = q.detector_metrics(f).set_index(["metric", "scope"])
    assert m.loc[("detector_precision", "s"), "n"] == 0
    assert math.isnan(m.loc[("detector_precision", "s"), "value"])
    assert m.loc[("detector_cannot_tell_share", "s"), "value"] == 1.0


def test_detector_metrics_empty():
    assert list(q.detector_metrics(None).columns) == q.METRIC_COLUMNS
    assert len(q.detector_metrics(pd.DataFrame())) == 0


# ------------------------------------------------------------------ stratum-weighted rates (critic 2026-10-04)
def _strat_rows(spec):
    """spec: [(stratum, size, [(y, x), ...])] -> one row per sampled unit."""
    return pd.DataFrame([{"stratum": h, "stratum_size": N, "y": yy, "x": xx} for h, N, units in spec for yy, xx in units])


def test_stratified_ratio_equals_the_plain_rate_when_strata_are_alike():
    spec = [(f"c{i}", 100, [(1, 1)] * 9 + [(0, 1)]) for i in range(4)]       # 4 strata of 100, 9 of 10 right in each
    r = q.stratified_ratio(_strat_rows(spec), "y", "x")
    p, lo, hi = q.wilson(36, 40)
    assert abs(r["value"] - 0.9) < 1e-12 and r["n"] == 40 and r["strata"] == 4 and r["units"] == 40
    assert abs(r["ci_low"] - lo) < 0.03 and abs(r["ci_high"] - hi) < 0.03       # close to the plain interval


def test_small_clean_strata_cannot_outvote_big_ones():
    """The critic's probe: 6 strata of 15 rules, all sampled and right; 6 strata of 500 rules, 15 sampled each, 88 of
    the 90 right. Pooled: 178/180, lower bound 0.960 -> GO at 0.95. Weighted by size the rate is ~0.978 with a lower
    bound below 0.95 -> NOT YET."""
    small = [(f"s{i}", 15, [(1, 1)] * 15) for i in range(6)]
    big = [(f"b{i}", 500, [(1, 1)] * 15) for i in range(4)] + [(f"b{i}", 500, [(1, 1)] * 14 + [(0, 1)]) for i in (4, 5)]
    df = _strat_rows(small + big)
    assert q.wilson(178, 180)[1] >= 0.95                                    # the old pooled verdict: GO
    r = q.stratified_ratio(df, "y", "x")
    assert abs(r["value"] - (90 + 3000 * 88 / 90) / 3090) < 1e-9
    assert r["ci_low"] < 0.95 and not q.lower_bound_bar(r, 0.95)[0]


def test_recall_is_a_ratio_of_rules_over_sections():
    """Recall: a section is the unit (y = real rules found, x = found + missed); big strata of sections weigh more."""
    spec = [("10 | proposals", 100, [(3, 3)] * 9 + [(2, 4)]),                   # 29 of 31 rules found
            ("10 | skipped_prefilter", 300, [(0, 0)] * 8 + [(0, 1), (0, 2)])]     # the pre-filter lost 3 rules
    r = q.stratified_ratio(_strat_rows(spec), "y", "x")
    Y = 100 / 10 * 29
    X = 100 / 10 * 31 + 300 / 10 * 3
    assert abs(r["value"] - Y / X) < 1e-12 and r["n"] == 34 and r["units"] == 20
    assert r["value"] < 29 / 34                                                   # the unweighted rate flatters it


def test_a_perfect_sample_gets_the_plain_wilson_interval():
    spec = [("a", 500, [(1, 1)] * 20), ("b", 50, [(1, 1)] * 10)]
    r = q.stratified_ratio(_strat_rows(spec), "y", "x")
    p, lo, hi = q.wilson(30, 30)
    assert r["value"] == 1.0 and abs(r["ci_low"] - lo) < 1e-12 and r["n_eff"] == 30


def test_a_single_row_stratum_borrows_the_pooled_variance_and_odd_sizes_are_named():
    spec = [("a", 200, [(1, 1)] * 9 + [(0, 1)]), ("b", 400, [(0, 1)])]          # stratum b: one row, wrong
    r = q.stratified_ratio(_strat_rows(spec), "y", "x")
    assert 0 < r["value"] < 1 and r["ci_high"] - r["ci_low"] > 0.3               # one row of 400 is not certainty
    df = _strat_rows([("a", None, [(1, 1)] * 3), ("b", 1, [(1, 1), (0, 1)])])   # missing size; size below the sample
    r = q.stratified_ratio(df, "y", "x")
    assert "weight 1" in r["notes"] and "'a'" in r["notes"] and "'b'" in r["notes"]
    assert abs(r["value"] - 4 / 5) < 1e-12


def test_stratified_ratio_refuses_unscored_or_impossible_rows():
    with pytest.raises(ValueError):
        q.stratified_ratio(pd.DataFrame({"stratum": ["a"], "stratum_size": [5], "y": [None], "x": [1]}), "y", "x")
    with pytest.raises(ValueError):
        q.stratified_ratio(pd.DataFrame({"stratum": ["a"], "stratum_size": [5], "y": [2], "x": [1]}), "y", "x")
    assert q.stratified_ratio(pd.DataFrame(columns=["stratum", "stratum_size", "y", "x"]), "y", "x")["n"] == 0


# ================================================================== critic M51 (2026-10-04)
def _rules_sheet(spec, **extra):
    """spec: [(chapter, stratum, stratum size, [(is_real_rule, faithful_to_source), ...])] -> a RULES sheet in the
    current layout (predicate_type, rule_population, population / corpus_version stamps)."""
    rows = []
    for ch, h, size, units in spec:
        for real, faith in units:
            rows.append(dict({"chapter": ch, "stratum": h, "stratum_size": size, "predicate_type": "max_units_per_day",
                              "predicate": _pred("max_units_per_day", code="98960", threshold=4),
                              "rule_population": "all", "is_real_rule": real, "faithful_to_source": faith,
                              "population": "engine_latest_run", "corpus_version": "corpus-x"}, **extra))
    return pd.DataFrame(rows)


def _probe_strata():
    """The critic's Q3: 6 small strata (15 rules, all sampled, all right) and 6 big ones (500 rules, 15 sampled each,
    one wrong in each of the first two)."""
    spec = [(str(i), f"{i} | table", 15, [("Y", "Y")] * 15) for i in range(6)]
    spec += [(str(i), f"{i} | llm", 500, ([("Y", "N")] + [("Y", "Y")] * 14) if i < 2 else [("Y", "Y")] * 15)
             for i in range(6)]
    return spec


def test_m51_2_pooled_and_chapter_rows_are_weighted_by_stratum_size():
    m = q.extraction_metrics(_rules_sheet(_probe_strata()), None).set_index(["metric", "scope"])
    e = m.loc[("executable_rule_precision", "all")]
    assert e["n"] == 180 and e["value"] == pytest.approx((90 + 3000 * 88 / 90) / 3090)
    assert e["ci_low"] < 0.95 and not q.lower_bound_bar(e.to_dict(), 0.95)[0]   # pooled 178/180: lower bound 0.960, GO
    assert "weighted by stratum size" in e["notes"]
    f = m.loc[("extraction_fidelity", "all")]
    assert f["value"] == pytest.approx(e["value"]) and f["ci_low"] < 0.95
    # a chapter pools its own sub-strata the same way: chapter 0 = 15 of 15 (of 15) + 14 of 15 (of 500)
    assert m.loc[("executable_rule_precision", "0"), "value"] == pytest.approx((15 + 500 * 14 / 15) / 515)
    assert m.loc[("extraction_precision", "all"), "value"] == 1.0


def test_m51_2_recall_is_weighted_by_section_stratum_size():
    """The critic's recall probe: per chapter 100 'proposals' sections (all 3 rules found) and 300 sections the
    pre-filter skipped (1 in 10 states a rule). Unweighted 180/186 (lower bound 0.93) said GO at 0.90."""
    rows = []
    for ch in ("4", "10", "13", "14", "19", "22"):
        rows += [{"chapter": ch, "stratum": f"{ch} | proposals", "stratum_size": 100, "rules_extracted": 3,
                  "real_rules_found": 3, "missed_rules": 0}] * 10
        rows += [{"chapter": ch, "stratum": f"{ch} | skipped_prefilter", "stratum_size": 300, "rules_extracted": 0,
                  "real_rules_found": 0, "missed_rules": 1 if i == 0 else 0} for i in range(10)]
    r = q.extraction_metrics(None, pd.DataFrame(rows)).set_index(["metric", "scope"]).loc[("extraction_recall", "all")]
    assert r["value"] == pytest.approx(1800 / 1980) and r["ci_low"] < 0.90
    assert (r["n"], r["scored_units"], r["unscored"]) == (186, 120, 0)
    assert not q.lower_bound_bar(r.to_dict(), 0.90)[0]


def test_m51_2_a_sheet_without_stratum_sizes_is_weighted_one_and_says_so():
    rules = pd.DataFrame({"chapter": ["10"] * 4, "predicate_type": ["code_not_covered"] * 4,
                          "is_real_rule": ["Y", "Y", "Y", "N"], "faithful_to_source": ["Y", "Y", "Y", None]})
    e = q.extraction_metrics(rules, None).set_index(["metric", "scope"]).loc[("executable_rule_precision", "10")]
    assert (e["n"], e["value"]) == (4, 0.75) and "weight 1" in e["notes"]
    p, lo, hi = q.wilson(3, 4)
    assert e["ci_low"] == pytest.approx(lo)                       # one stratum, weight 1: the plain interval


def test_m51_3_an_old_layout_rules_sheet_yields_no_executable_precision():
    """A RULES sheet exported before 2026-10-04 has no predicate_type: rejected drafts were left out and reviewers'
    predicates shown, so 'executable' read from it is not the engine's (critic Q4: it said GO)."""
    old = pd.DataFrame([{"chapter": "4", "review_status": "approved",
                         "predicate": _pred("max_units_per_day", code="A", threshold=1),
                         "is_real_rule": "Y", "faithful_to_source": "Y"}] * 80)
    m = q.extraction_metrics(old, None).set_index(["metric", "scope"])
    e = m.loc[("executable_rule_precision", "all")]
    assert e["n"] == 0 and "no predicate_type column" in e["notes"]
    assert not q.lower_bound_bar(e.to_dict(), 0.95)[0]
    assert m.loc[("extraction_fidelity", "all"), "n"] == 80             # the other numbers are still computed


def test_m51_3_metric_rows_carry_the_population_and_corpus_of_their_sheet():
    rules = _rules_sheet([("10", "10 | model", 40, [("Y", "Y")] * 3)])
    secs = pd.DataFrame({"chapter": ["10"], "rules_extracted": [1], "real_rules_found": [1], "missed_rules": [0],
                         "population": ["statuses:approved"], "corpus_version": ["corpus-x"]})
    m = q.extraction_metrics(rules, secs)
    assert list(m.columns) == q.METRIC_COLUMNS
    assert {"unscored", "scored_units", "population", "corpus_version"} <= set(q.METRIC_COLUMNS)
    assert q.METRIC_COLUMNS[-1] == "notes"                             # v07 selects METRIC_COLUMNS[:-1] + ... + notes
    e = m[m.metric == "executable_rule_precision"]
    assert set(e["population"]) == {q.ENGINE_POPULATION} == {"engine_latest_run"}
    assert set(e["corpus_version"]) == {"corpus-x"}
    assert set(m.loc[m.metric == "extraction_recall", "population"]) == {"statuses:approved"}
    # a sheet without the stamps (exported before M51): no population, no corpus - v03 will not judge it
    m = q.extraction_metrics(rules.drop(columns=["population", "corpus_version"]), None)
    assert m["population"].isna().all() and m["corpus_version"].isna().all()
    # rows of two samples pasted together never make one population
    mixed = pd.concat([rules, rules.assign(population="statuses:approved")], ignore_index=True)
    assert q.extraction_metrics(mixed, None)["population"].str.startswith("mixed").all()
    assert q.sample_population(None) == "engine_latest_run" and q.sample_population(["approved"]) == "statuses:approved"


def _mrow(**kw):
    base = {"metric": "executable_rule_precision", "scope_type": "overall", "scope": "all", "n": 400, "value": 0.99,
            "ci_low": 0.975, "ci_high": 0.996, "unscored": 0, "scored_units": 400, "population": "engine_latest_run",
            "corpus_version": "corpus-now", "sample_runs": '{"19": "R2"}', "sample_id": "s1",
            "computed_at": "2026-10-04T10:00:00", "notes": ""}
    return dict(base, **kw)


LATEST = {"19": "R2"}            # the latest successful run of each chapter's current version (quality.latest_runs)


def test_m51_3_a_bar_is_judged_only_on_the_engines_own_sample_of_the_current_corpus():
    approved = _mrow(population="statuses:approved", sample_id="s2", computed_at="2026-10-04T11:00:00")
    old_corpus = _mrow(corpus_version="corpus-before", sample_id="s3", computed_at="2026-10-04T12:00:00")
    m, why = q.metric_for_bar(pd.DataFrame([approved]), "executable_rule_precision", "all", "corpus-now",
                              latest_run=LATEST)
    assert m is None and "statuses:approved" in why and "STATUSES = None" in why
    m, why = q.metric_for_bar(pd.DataFrame([old_corpus]), "executable_rule_precision", "all", "corpus-now",
                              latest_run=LATEST)
    assert m is None and "corpus-before" in why and "corpus-now" in why
    m, why = q.metric_for_bar(pd.DataFrame([_mrow(population=None, corpus_version=None)]),
                              "executable_rule_precision", "all", "corpus-now", latest_run=LATEST)
    assert m is None and "not recorded" in why
    m, why = q.metric_for_bar(pd.DataFrame([_mrow(n=0, notes="no predicate_type column")]),
                              "executable_rule_precision", "all", "corpus-now", latest_run=LATEST)
    assert m is None and "no predicate_type column" in why
    # the latest VALID row is judged, even when newer rows of another population or corpus exist
    m, why = q.metric_for_bar(pd.DataFrame([_mrow(), approved, old_corpus]), "executable_rule_precision", "all",
                              "corpus-now", latest_run=LATEST)
    assert m["sample_id"] == "s1" and why == ""
    assert q.metric_for_bar(None, "x", "all", "corpus-now", latest_run=LATEST)[0] is None


def test_m51_12_sample_runs_is_one_canonical_text_and_a_metric_row_names_its_chapters():
    """Follow-up to M51-3 (2026-10-04): v01 stamps every sheet row with the latest run of each sampled chapter; each
    metric row carries the runs of the chapters it covers - a chapter row its own, the pooled row all of them."""
    assert q.sample_runs_text({"4": "R0", "19": "R2"}) == q.sample_runs_text({"19": "R2", 4: "R0"}) \
        == '{"19": "R2", "4": "R0"}'
    assert q.sample_runs_text({}) is None and q.sample_runs_text({"4": None}) == '{"4": null}'
    assert "sample_runs" in q.METRIC_COLUMNS and q.METRIC_COLUMNS[-1] == "notes"   # v02 / v07 write it blank
    stamp = q.sample_runs_text({"19": "R2", "10": "R7"})
    rules = _rules_sheet([("19", "19 | model", 10, [("Y", "Y")] * 3), ("10", "10 | model", 10, [("Y", "Y")] * 3)],
                         sample_runs=stamp)
    m = q.extraction_metrics(rules, None).set_index(["metric", "scope"])
    assert json.loads(m.loc[("executable_rule_precision", "all"), "sample_runs"]) == {"10": "R7", "19": "R2"}
    assert json.loads(m.loc[("executable_rule_precision", "19"), "sample_runs"]) == {"19": "R2"}
    assert json.loads(m.loc[("extraction_fidelity", "10"), "sample_runs"]) == {"10": "R7"}
    # a sheet without the stamp (exported before this check): None - never judgeable; two samples pasted: mixed
    assert q.extraction_metrics(rules.drop(columns=["sample_runs"]), None)["sample_runs"].isna().all()
    mixed = pd.concat([rules, rules.assign(sample_runs=q.sample_runs_text({"19": "R3", "10": "R7"}))],
                      ignore_index=True)
    assert q.extraction_metrics(mixed, None)["sample_runs"].str.startswith("mixed").all()


def test_m51_12_a_bar_is_judged_only_on_the_latest_run_of_every_chapter_it_names():
    """A re-extraction of the same corpus (SB re-runs 04 with another reasoning effort) makes a sample of the older run
    describe an engine output that is no longer current: NOT YET, with the runs named."""
    rows = pd.DataFrame([_mrow()])
    m, why = q.metric_for_bar(rows, "executable_rule_precision", "all", "corpus-now", latest_run={"19": "R2"})
    assert m is not None and why == ""
    m, why = q.metric_for_bar(rows, "executable_rule_precision", "all", "corpus-now", latest_run={"19": "R3"})
    assert m is None and "measured on run R2 of chapter 19; the latest run is R3" in why and "re-export v01" in why
    m, why = q.metric_for_bar(rows, "executable_rule_precision", "all", "corpus-now", latest_run={})
    assert m is None and "chapter 19 has no successful run" in why
    m, why = q.metric_for_bar(rows, "executable_rule_precision", "all", "corpus-now")       # latest runs not given
    assert m is None and "chapter 19 has no successful run" in why
    m, why = q.metric_for_bar(pd.DataFrame([_mrow(sample_runs=None)]), "executable_rule_precision", "all",
                              "corpus-now", latest_run={"19": "R2"})
    assert m is None and "sample_runs was not recorded" in why
    m, why = q.metric_for_bar(pd.DataFrame([_mrow(sample_runs="mixed: a | b")]), "executable_rule_precision", "all",
                              "corpus-now", latest_run={"19": "R2"})
    assert m is None and "not one run per chapter" in why
    # two chapters: one re-extracted since the sample was drawn
    two = pd.DataFrame([_mrow(sample_runs=q.sample_runs_text({"19": "R2", "10": "R7"}))])
    m, why = q.metric_for_bar(two, "executable_rule_precision", "all", "corpus-now", latest_run={"19": "R2", "10": "R8"})
    assert m is None and "run R7 of chapter 10; the latest run is R8" in why and "chapter 19" not in why
    # the latest row measured on the current runs is judged, even when a newer row rests on an older run
    stale = _mrow(sample_runs=q.sample_runs_text({"19": "R1"}), sample_id="s0", computed_at="2026-10-05T10:00:00")
    m, why = q.metric_for_bar(pd.DataFrame([_mrow(), stale]), "executable_rule_precision", "all", "corpus-now",
                              latest_run={"19": "R2"})
    assert m["sample_id"] == "s1" and why == ""


def test_m51_6_drawn_but_unscored_units_are_carried_and_hold_the_bar():
    """The critic's Q2: 80 rules scored real + faithful, 20 real with fidelity left blank - executable n = 80 and GO."""
    rules = pd.DataFrame([{"chapter": "4", "predicate_type": "max_units_per_day", "is_real_rule": "Y",
                           "faithful_to_source": "Y"}] * 80
                         + [{"chapter": "4", "predicate_type": "max_units_per_day", "is_real_rule": "Y",
                             "faithful_to_source": None}] * 20)
    m = q.extraction_metrics(rules, None).set_index(["metric", "scope"])
    e = m.loc[("executable_rule_precision", "all")]
    assert (e["n"], e["unscored"], e["scored_units"]) == (80, 20, 80) and e["ci_low"] >= 0.95
    ok, why = q.lower_bound_bar(e.to_dict(), 0.95)
    assert not ok and "20 of 100 drawn" in why and "unscored" in why
    assert q.MAX_UNSCORED_SHARE == 0.10
    assert q.lower_bound_bar(dict(e.to_dict(), unscored=8), 0.95)[0]           # 8 of 88 (9%) is within the limit
    assert m.loc[("extraction_fidelity", "all"), "unscored"] == 20
    assert m.loc[("extraction_precision", "all"), "unscored"] == 0
    # recall: the unit is the SECTION (n counts rules)
    secs = pd.DataFrame({"chapter": ["4"] * 10, "rules_extracted": [3] * 10,
                         "real_rules_found": [3] * 8 + [None, None], "missed_rules": [0] * 10})
    r = q.extraction_metrics(None, secs).set_index(["metric", "scope"]).loc[("extraction_recall", "all")]
    assert (r["n"], r["scored_units"], r["unscored"]) == (24, 8, 2)
    ok, why = q.lower_bound_bar(r.to_dict(), 0.5)
    assert not ok and "2 of 10 drawn" in why


def test_m51_2_more_units_needed_is_scaled_by_the_design_effect():
    """A stratum-weighted interval rests on an effective sample size below n: the 'more needed' advice scales by
    n / n_eff, read back from the interval itself (a plain Wilson row keeps need - n)."""
    p, lo, hi = q.wilson(97, 100)                                    # an interval worth n_eff = 100 ...
    plain = q.lower_bound_bar({"n": 100, "value": p, "ci_low": lo, "ci_high": hi}, 0.95)[1]
    need = q.n_needed(0.97, 0.95)
    assert f"about {need - 100:,} more" in plain
    weighted = q.lower_bound_bar({"n": 200, "value": p, "ci_low": lo, "ci_high": hi}, 0.95)[1]   # ... from 200 units
    assert f"about {(need - 100) * 2:,} more" in weighted


def test_m51_7_counts_are_whole_numbers_or_blank():
    vals = (2, 2.0, "2", "2.0", " 3 ", "0.5", "2.9", 2.9, -1, "x", None, float("nan"), True)
    assert [q._int_or_none(v) for v in vals] == [2, 2, 2, 2, 3, None, None, None, None, None, None, None, None]
    secs = pd.DataFrame({"chapter": ["4"] * 3, "rules_extracted": [3, None, 4], "real_rules_found": [2, 5, "2.9"],
                         "missed_rules": [1, 0, "0.5"]})
    r = q.extraction_metrics(None, secs).set_index(["metric", "scope"]).loc[("extraction_recall", "4")]
    assert (r["n"], r["value"]) == (3, pytest.approx(2 / 3)) and r["unscored"] == 2
    assert "1 section(s) excluded: rules_extracted is blank" in r["notes"]


def test_m51_8_a_detector_run_is_complete_unless_it_erred_or_was_partial():
    gate = ("not run: 3 provider type code(s) on CMS-1500 / UB-04 lines have no SIGNED routing row (05, B2, 77) - "
            "sign them")
    runs = pd.DataFrame([
        {"rule_id": "BATCH:ncci_ptp", "error": None, "skipped": gate, "partial_run": True},
        {"rule_id": "BATCH:ncci_mue", "error": None, "skipped": gate, "partial_run": True},
        {"rule_id": "EXT-1", "error": None, "skipped": None, "partial_run": True},
        {"rule_id": "RUN:snapshot", "error": json.dumps({"snapshot_rows": 10, "ncci_gate": gate}), "skipped": None,
         "partial_run": True}])
    errors, problems = q.run_completeness(runs)
    assert errors == 0 and len(problems) == 1 and problems[0].startswith("partial run")
    assert "have no SIGNED routing row" in problems[0] and "BATCH:ncci_ptp" in problems[0]
    assert q.run_completeness(runs.assign(partial_run=False, skipped=None)) == (0, [])   # the RUN: JSON is no error
    bad = runs.assign(partial_run=False, skipped=None)
    bad.loc[2, "error"] = "AnalysisException: boom"
    assert q.run_completeness(bad) == (1, ["1 detector error(s)"])
    errors, problems = q.run_completeness(runs.assign(skipped=None))         # partial with no recorded reason
    assert "RUN_NCCI_BATCH" in problems[0]
    assert q.run_completeness(runs.drop(columns=["partial_run"]).assign(skipped=None)) == (0, [])


def test_m51_9_routing_bar_goes_only_on_signed_routing():
    s = {"mode": "provider_type", "types_signed": 2, "types_mapped": 3, "table": "t.csv", "optional_on": [],
         "require_signed": True}
    ok, why = q.routing_bar(True, s, ["08", "31"], [], "signed")
    assert ok and "lines (servicing) have a signed row" in why and "billing" not in why.split(";")[0]
    b = dict(s, mode="billing_provider_type")
    ok, why = q.routing_bar(True, b, ["08", "31"], [], "form_fallback")
    assert not ok and "NCCI_UNMAPPED_PROVIDER_TYPE = 'form'" in why
    ok, why = q.routing_bar(False, {"mode": "form"}, None, None, "form_only")
    assert not ok and why.startswith("routing by claim form only")
    ok, why = q.routing_bar(True, b, ["08", "B2"], ["B2"], "unsigned")
    assert not ok and "billing or servicing" in why and "e.g. B2" in why


def test_m51_11_corpus_bar_states_one_plain_scope():
    ok, why = q.corpus_bar({"1": "a"}, {"1": 0}, {"same_day_disallow": ("d", "u"), "ncci_rissnet": ("d", None)},
                           "corpus-x")
    assert not ok and "2 rule source(s) still to load before the corpus is complete" in why
    assert "same_day_disallow, ncci_rissnet" in why
    assert "in-scope" not in why and "outside this scope" not in why and "federal edits" not in why
    assert why.endswith("Not part of this corpus: the AMPM and the fee schedule.")


def test_m51_11_executable_means_it_would_compile():
    """One definition with v05's gate (regress.compiles): a compiled type whose population is scoped and has no age
    condition stays a lead, so it is not in executable-rule precision."""
    rules = _rules_sheet([("19", "19 | model", 10, [("Y", "N")])], rule_population="members under 21")
    rules = pd.concat([rules, _rules_sheet([("19", "19 | model", 10, [("Y", "Y")])])], ignore_index=True)
    e = q.extraction_metrics(rules, None).set_index(["metric", "scope"]).loc[("executable_rule_precision", "19")]
    assert (e["n"], e["value"]) == (1, 1.0)
    aged = rules.assign(predicate=_pred("max_units_per_day", code="98960", threshold=4, age={"below": 21}))
    e = q.extraction_metrics(aged, None).set_index(["metric", "scope"]).loc[("executable_rule_precision", "19")]
    assert e["n"] == 2                                                # the age condition expresses the population


def test_m51_1_the_default_population_is_the_latest_runs_own_drafts():
    def d(key, run, typ="max_units_per_day", ch="19", doc="H19"):
        return {"rule_id": f"EXT-{key}", "extraction_key": key, "origin": "extracted", "chapter": ch, "doc_hash": doc,
                "section_id": f"s{ch}", "statement": f"rule {key} ({run})", "run_id": run,
                "predicate": _pred(typ, code="T1016", threshold=4), "extraction_source": "model",
                "review_status": "draft", "population": "all", "grounding": "{}"}
    drafts = pd.DataFrame([d("K1", "R1"), d("K2", "R1"), d("K3", "R1"), d("K4", "R2"),
                           d("K1", "R2", typ="code_not_covered"), d("K9", "R2", doc="H19-old")])
    state = pd.DataFrame([dict(d("K1", "R1"), review_status="rejected", reviewer="SB"),
                          dict(d("K2", "R1"), review_status="approved", reviewer="SB"),
                          dict(d("K3", "R1"), review_status="superseded"), d("K4", "R2"),
                          dict(d("K40", "R0", ch="4", doc="H4"), review_status="approved", reviewer="SB"),
                          d("K41", "R0", ch="4", doc="H4"), d("K50", "R5", ch="5", doc="H5")])
    log = pd.DataFrame([{"chapter": "19", "doc_hash": "H19", "run_id": "R1", "error": None, "drafts_unique": 3},
                        {"chapter": "19", "doc_hash": "H19", "run_id": "R2", "error": None, "drafts_unique": 2},
                        {"chapter": "19", "doc_hash": "H19", "run_id": "R3", "error": "boom", "drafts_unique": None},
                        {"chapter": "4", "doc_hash": "H4", "run_id": "R0", "error": None, "drafts_unique": 2},
                        {"chapter": "5", "doc_hash": "H5", "run_id": "R5", "error": None, "drafts_unique": 0}])
    cur = {"19": "H19", "4": "H4", "5": "H5"}
    latest = q.latest_runs(log, cur)
    assert latest == {"19": "R2", "4": "R0", "5": "R5"}                 # R3 failed: not a successful run
    pop, rep = q.run_population(drafts, cur, latest, state, log)
    assert sorted(pop["extraction_key"]) == ["K1", "K4"] and set(pop["run_id"]) == {"R2"}
    k1 = pop.set_index("extraction_key").loc["K1"]
    assert json.loads(k1["predicate"])["type"] == "code_not_covered" and k1["predicate_type"] == "code_not_covered"
    assert k1["review_status"] == "rejected"                            # state_rules' status, for information
    assert "earlier run" in k1["reviewer_fix"]                         # state_rules holds R1's reading of K1
    assert rep["chapters"] == {"19": "R2"} and rep["no_run_rows"] == {"4": "R0"} and rep["empty_latest_run"] == ["5"]
    assert rep["older_run"] == 3 and rep["other_doc_version"] == 1
    pop, rep = q.run_population(None, cur, latest, state, log)          # 05 never persisted a run's drafts
    assert len(pop) == 0 and rep["no_run_rows"] == {"19": "R2", "4": "R0"}


def test_m51_current_doc_hash_is_the_latest_inventory_row_without_blank_hashes():
    inv = pd.DataFrame([{"chapter": 4, "doc_hash": "OLD", "fetched_at": "2026-09-01"},
                        {"chapter": "4", "doc_hash": "NEW", "fetched_at": "2026-10-01"},
                        {"chapter": "19", "doc_hash": " ", "fetched_at": "2026-10-01"}])
    assert q.current_doc_hash(inv) == {"4": "NEW"}
    assert q.current_doc_hash(None) == {} and q.current_doc_hash(pd.DataFrame()) == {}
