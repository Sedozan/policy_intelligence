"""Which NCCI edit file a claim line takes: CMS 2026 Medicaid NCCI Technical Guidance Manual s6.0 Table 2 (provider
type x claim form) and s5.2 (no NCCI on dental, pharmacy, inpatient, residential), through the AHCCCS provider-type
routing table (keyed on the SProv_Type CODE). Pure Python; the SQL twin is executed in tests/test_sql_spark.py.
Run: cd pie_mvp && python -m pytest tests/test_ncci_routing.py -q"""
import os
import sys

import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import config  # noqa: E402
import ncci_routing as nr  # noqa: E402


@pytest.fixture(autouse=True)
def _defaults(monkeypatch):
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "billing_provider_type")
    monkeypatch.setattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", ())
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "form")


# (AHCCCS provider type code, form) -> edit file, read off CMS TGM Table 2
TABLE2_CASES = [
    ("08", "A", "practitioner"), ("08", "O", "outpatient"),      # physician: CMS-1500 PRA, UB-04 OPH
    ("19", "A", "practitioner"), ("19", "O", "outpatient"),      # nonphysician practitioner (RN practitioner)
    ("43", "A", "practitioner"), ("43", "O", "practitioner"),    # ASC: PRA on either form
    ("02", "A", "outpatient"), ("02", "O", "outpatient"),        # hospital: OPH on either form
    ("30", "A", "dme"), ("30", "O", "dme"),                      # DME supplier: DME file
    ("04", "A", None), ("E1", "O", None),                        # testing facilities: OPTIONAL, off by default
    ("C2", "A", None), ("77", "O", None),                        # FQHC / BH outpatient clinic: OPTIONAL, off
    ("07", "A", "practitioner"), ("07", "D", None),             # dentist: a physician practitioner (Table 2 fn 14) -
                                                                 # but never on an ADA dental claim (s5.2)
    ("54", "A", None), ("03", "A", None), ("22", "O", None),     # dental hygienist, pharmacy, nursing home: no NCCI
    ("B8", "O", None),                                           # BH residential facility: no NCCI (s5.2)
    # 2026-10-03: in the claims but missing from the AHCCCS list the table was built from - they used to fall back
    # to routing by form (practitioner edits on a CMS-1500)
    ("CF", "A", None), ("CH", "A", None),                        # counseling-only facility, CHW organization: optional
    ("ES", "A", None), ("HA", "A", None), ("HO", "A", None),     # H2O housing: no NCCI
]


@pytest.mark.parametrize("ptype,form,edition", TABLE2_CASES)
def test_table2(ptype, form, edition):
    assert nr.edition(form, ptype) == edition


@pytest.mark.parametrize("form", ["C", "D", "I", "L", "", None, "X"])
def test_no_ncci_on_dental_pharmacy_inpatient_ltc_or_unknown_forms_whatever_the_provider(form):
    for ptype in ("08", "02", "43", "30", None, "ZZ"):
        assert nr.edition(form, ptype) is None


def test_optional_rows_only_when_switched_on(monkeypatch):
    monkeypatch.setattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", ("testing_facility", "other_outpatient"))
    assert nr.edition("A", "04") == "practitioner" and nr.edition("O", "E1") == "practitioner"   # testing: PRA
    assert nr.edition("A", "C2") == "outpatient" and nr.edition("O", "77") == "outpatient"       # other outpatient: OPH
    monkeypatch.setattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", ("practitioner",))
    with pytest.raises(ValueError, match="not optional"):
        nr.edition("A", "08")


def test_unmapped_provider_type_follows_config(monkeypatch):
    assert nr.edition("A", "ZZ") == "practitioner" and nr.edition("O", None) == "outpatient"
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "none")
    assert nr.edition("A", "ZZ") is None and nr.edition("O", None) is None
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "guess")
    with pytest.raises(ValueError):
        nr.edition("A", "ZZ")


# (servicing type, BILLING type, form) -> edit file. 2026-10-03: CMS applies NCCI to "claims FROM" a type of provider
# (TGM s5.3 / s5.5): the billing type picks the Table 2 row; the servicing type says whether a rendering practitioner
# is identified, which only the 'Other Providers of Outpatient Services' row on a CMS-1500 cares about (PRA / OPH).
BILLING_CASES = [
    ("08", "08", "A", "practitioner"), ("08", "08", "O", "outpatient"),   # a physician's own claim
    ("08", "C2", "A", None), ("08", "77", "A", None),                     # an MD's service billed by an FQHC / BH
                                                                          # clinic: CMS-optional row, off
    ("08", "02", "A", "outpatient"), ("08", "02", "O", "outpatient"),     # billed by a hospital: OPH on either form
    ("08", "30", "A", "dme"), ("08", "43", "O", "practitioner"),          # DME supplier; ASC on a UB-04: PRA
    ("08", "04", "A", None),                                              # independent lab: optional, off
    ("08", "ZZ", "A", "practitioner"), ("30", None, "A", "dme"),          # billing type unknown / missing: the
                                                                          # servicing type decides
    ("ZZ", "ZZ", "O", "outpatient"), ("ZZ", "ZZ", "D", None),             # neither known: by claim form (config)
    ("08", "07", "D", None), ("08", "B8", "O", None),                     # dental claim; BH residential facility
]


@pytest.mark.parametrize("stype,btype,form,edition", BILLING_CASES)
def test_the_billing_provider_type_picks_the_table2_row(stype, btype, form, edition):
    assert nr.edition(form, stype, billing_type=btype) == edition


def test_rendering_practitioner_identified_only_matters_for_other_providers(monkeypatch):
    monkeypatch.setattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", ("other_outpatient", "testing_facility"))
    assert nr.edition("A", "08", billing_type="C2") == "practitioner"     # FQHC claim, MD identified: PRA
    assert nr.edition("A", "19", billing_type="77") == "practitioner"     # BH clinic claim, NP identified: PRA
    assert nr.edition("A", "C2", billing_type="C2") == "outpatient"       # the FQHC itself on the line: OPH
    assert nr.edition("A", None, billing_type="C2") == "outpatient"       # no servicing provider: OPH
    assert nr.edition("A", "01", billing_type="C2") == "outpatient"       # a group billing ID is not a person: OPH
    assert nr.edition("O", "08", billing_type="C2") == "outpatient"       # UB-04: OPH
    assert nr.edition("A", "C2", billing_type="04") == "practitioner"     # testing facility: PRA / PRA
    assert "01" not in nr.individual_practitioners() and "08" in nr.individual_practitioners()


def test_servicing_mode_ignores_the_billing_type(monkeypatch):
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "provider_type")
    assert nr.edition("A", "08", billing_type="C2") == "practitioner"
    assert nr.edition("A", "08", billing_type="30") == "practitioner"
    assert nr.edition("A", "30", billing_type="08") == "dme"
    sql = nr.edition_sql("F", "T", billing_expr="B")
    assert " B IN (" not in sql                                           # the billing expression is not used


def test_form_mode_ignores_the_provider_type(monkeypatch):
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "form")
    assert nr.edition("A", "30") == "practitioner" and nr.edition("O", "43") == "outpatient"
    assert nr.edition("A", "08", billing_type="30") == "practitioner"
    assert nr.edition("D", "08") is None
    assert "WHEN" in nr.edition_sql("F", "T") and "T" not in nr.edition_sql("F", "T").replace("THEN", "").replace("WHEN", "")


@pytest.mark.parametrize("raw,code", [("8", "08"), (8, "08"), ("8.0", "08"), (8.0, "08"), (" c2 ", "C2"),
                                      ("08", "08"), ("43", "43"), ("", None), (None, None), ("nan", None),
                                      (" None ", None), ("NULL", None), (float("nan"), None), ("08.00", "08"),
                                      ("NA", "NA"), ("NANA", "NANA"), ("8.5", "8.5"), ("\t08", "\t08")])
def test_codes_normalise_like_the_table(raw, code):
    """2026-10-03 (oracle S07/S08): the text NONE / NAN / NULL is a missing value an export wrote; 'NA' is a real
    AHCCCS provider type (NEMT non-ambulance air). Only spaces are trimmed - as SQL TRIM does."""
    assert nr.norm_type(raw) == code


def test_type_sql_is_linear_and_routed_sql_computes_the_codes_once():
    """The clean-up expression must not repeat the column: it is inlined in every comparison, and the nested CASE that
    repeated it made Spark's generated code exceed 64 KB (2026-10-03 simulation)."""
    assert nr.type_sql("SProv_Type").count("SProv_Type") == 1
    sql = nr.routed_sql("claims", {"form": "FORM_TYP", "prov_type": "SProv_Type", "billing_type": "BProv_Type"})
    assert sql.count("SProv_Type") == 1 and sql.count("BProv_Type") == 1
    assert sql.count("pie_bprov_type IN (") >= 1                       # the edit file reads the cleaned columns
    no_bill = nr.routed_sql("claims", {"form": "FORM_TYP", "prov_type": "SProv_Type", "billing_type": "BProv_Type"},
                            cols={"FORM_TYP", "SPROV_TYPE"})
    assert "pie_bprov_type IN (" not in no_bill and "CAST(NULL AS STRING) AS pie_bprov_type" in no_bill


def test_the_table_validates(tmp_path):
    rows = nr.load_table()
    codes = [r["sprov_type"] for r in rows]
    assert len(codes) == len(set(codes)) and all(r["cms_category"] in nr.TABLE2 for r in rows)
    assert {"08", "02", "43", "30"} <= set(codes)
    bad = tmp_path / "t.csv"
    bad.write_text("sprov_type,description_at_mapping,cms_category,note,status,reviewer,reviewed_at\n"
                   "08,MD,practitioner,,proposed,,\n8,MD again,hospital,,proposed,,\n")
    with pytest.raises(ValueError, match="listed twice"):
        nr.load_table(str(bad))
    bad.write_text("sprov_type,description_at_mapping,cms_category,note,status,reviewer,reviewed_at\n"
                   "08,MD,doctor,,proposed,,\n")
    with pytest.raises(ValueError, match="unknown cms_category"):
        nr.load_table(str(bad))


def test_summary_reports_signature_state():
    sm = nr.summary()
    assert sm["mode"] == "billing_provider_type" and sm["types_mapped"] == len(nr.load_table())
    assert sm["types_signed"] == 0 and len(sm["table_sha256"]) == 64      # PROPOSED until someone signs it


# SELECT DISTINCT SProv_Type, SProv_Type_Desc FROM main.prod_input.all_data_C_A (SB, 2026-10-03): 79 codes and NULL
CLAIMS_SPROV_TYPES_2026_10_03 = """54 12 16 97 IC 82 70 92 29 41 27 62 02 B1 93 22 86 03 B8 A4 47 C2 79 B5 A6 C4 23 ES 36 14
10 44 43 13 40 SA E1 08 30 85 CH 77 BC B6 87 78 19 18 35 94 A3 HA 05 28 07 55 06 CF 56 95 ED 11 71 CN 17 15 C5 HO 39 A5
09 TS 69 31 49 04 81 46 32""".split()


def test_every_provider_type_in_the_claims_is_mapped_and_marked():
    assert len(set(CLAIMS_SPROV_TYPES_2026_10_03)) == 79
    rows = {r["sprov_type"]: r for r in nr.load_table()}
    assert set(CLAIMS_SPROV_TYPES_2026_10_03) <= set(rows)                  # none falls back to routing by form
    assert {c for c, r in rows.items() if r.get("in_claims_2026_10_03") == "yes"} == set(CLAIMS_SPROV_TYPES_2026_10_03)
    optional_on = {c for c in CLAIMS_SPROV_TYPES_2026_10_03 if rows[c]["cms_category"] in nr.OPTIONAL}
    assert {"C2", "C5", "77", "IC", "CF", "CH", "04", "E1"} <= optional_on    # clinics, FQHCs, labs: CMS-optional rows


# SELECT DISTINCT named_struct(BProv_Type, BProv_Type_Desc) FROM main.prod_input.all_data_C_A (SB, 2026-10-04): 70 + NULL
CLAIMS_BPROV_TYPES_2026_10_04 = """16 12 97 IC 70 82 29 41 27 02 B1 22 86 03 B8 A4 47 C2 79 B5 A6 C4 23 36 14 10 44 43 40
E1 30 08 CH 85 77 BC B6 87 78 19 35 18 A3 05 28 07 55 06 CF 56 ED 95 71 11 15 C5 39 09 TS 69 01 31 49 04 81 62 13 A5 54
32""".split()


def test_every_billing_provider_type_in_the_claims_is_mapped_and_marked():
    """The BILLING type picks the Table 2 row: every BProv_Type in the claims must be in the table (none falls back)."""
    assert len(set(CLAIMS_BPROV_TYPES_2026_10_04)) == 70
    rows = {r["sprov_type"]: r for r in nr.load_table()}
    assert set(CLAIMS_BPROV_TYPES_2026_10_04) <= set(rows)
    assert {c for c, r in rows.items() if r.get("billing_in_claims_2026_10_04") == "yes"} == \
        set(CLAIMS_BPROV_TYPES_2026_10_04)
    # the group billing ID bills but never renders; the school-based, H2O and some individual types only render
    assert set(CLAIMS_BPROV_TYPES_2026_10_04) - set(CLAIMS_SPROV_TYPES_2026_10_03) == {"01"}
    assert set(CLAIMS_SPROV_TYPES_2026_10_03) - set(CLAIMS_BPROV_TYPES_2026_10_04) == \
        {"17", "46", "92", "93", "94", "CN", "ES", "HA", "HO", "SA"}
    assert "01" not in nr.individual_practitioners()                     # a group is never a rendering practitioner
