"""
Every compiled query EXECUTED on a real local Spark (ANSI mode on, production column types) against
adversarial claims, with expected findings stated per scenario. This is the evidence for "are the
queries right?": string checks and SQLite rewrites could not see padded modifiers, duplicate rows,
NULL keys, $0 / reversal lines, or one-finding-per-line grain (critic C1, 2026-10-02: 25 of 26 of
these scenarios failed on the previous package while all 149 offline tests passed).

Run with a Python that has pyspark (4.0.x = Databricks Runtime 17.3's Spark) and Java:
    <python-with-pyspark> -m pytest -q tests/test_sql_spark.py
Skipped (loudly) where pyspark is not importable.
"""
from __future__ import annotations

import os
import random
import shutil
import sys
import tempfile
from collections import Counter
from datetime import date, timedelta
from decimal import Decimal

import pytest

pyspark = pytest.importorskip("pyspark", reason="pyspark not installed: the SQL execution tests did NOT run")

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import config            # noqa: E402
import detector_gen as dg  # noqa: E402
import kb_io             # noqa: E402
import rule_normalize as rn  # noqa: E402
import schema            # noqa: E402
import validate_gate     # noqa: E402
from schema import Rule  # noqa: E402

C = config.CLAIM_COLS
D = "2026-01-15"


# ------------------------------------------------------------------ Spark + table names
@pytest.fixture(scope="module")
def spark():
    from pyspark.sql import SparkSession
    root = tempfile.mkdtemp(prefix="pie_sql_spark_")
    s = (SparkSession.builder.master("local[1]").appName("pie-sql-tests")
         .config("spark.ui.enabled", "false").config("spark.sql.ansi.enabled", "true")
         .config("spark.driver.memory", "1g").config("spark.sql.shuffle.partitions", "2")
         # generated Java code that does not compile (e.g. > 64 KB) FAILS the test instead of silently falling back to
         # the slow interpreted path (2026-10-03: the snapshot's DISTINCT did, with the provider-type clean-up inlined)
         .config("spark.sql.codegen.fallback", "false")
         .config("spark.sql.warehouse.dir", os.path.join(root, "wh")).getOrCreate())
    s.sparkContext.setLogLevel("ERROR")
    for sch in ("prod_input", "policy_kb"):
        s.sql(f"CREATE SCHEMA IF NOT EXISTS spark_catalog.{sch}")
    yield s
    s.stop()
    shutil.rmtree(root, ignore_errors=True)


@pytest.fixture(autouse=True)
def _local_tables(monkeypatch):
    monkeypatch.setattr(dg, "CLAIMS", "spark_catalog.prod_input.all_data_c_a")
    monkeypatch.setattr(dg, "DETECT", "spark_catalog.policy_kb.policy_claims_snapshot")
    monkeypatch.setattr(dg, "PTP_EDITS_TABLE", "spark_catalog.policy_kb.policy_ncci_ptp_edits")
    monkeypatch.setattr(dg, "MUE_LIMITS_TABLE", "spark_catalog.policy_kb.policy_ncci_mue_limits")
    # 2026-10-04 (v5.2): the three AHCCCS rule-table edit tables
    monkeypatch.setattr(dg, "AHCCCS_PAIR_EDITS_TABLE", "spark_catalog.policy_kb.policy_ahcccs_pair_edits", raising=False)
    monkeypatch.setattr(dg, "AHCCCS_DAILY_LIMITS_TABLE", "spark_catalog.policy_kb.policy_ahcccs_daily_limits",
                        raising=False)
    monkeypatch.setattr(dg, "AHCCCS_PTYPE_TABLE", "spark_catalog.policy_kb.policy_ahcccs_provider_types", raising=False)
    monkeypatch.setattr(config, "TABLE_FORMAT", "parquet")


def _schema():
    from pyspark.sql import types as T
    return T.StructType([
        T.StructField(C["claim_id"], T.StringType()), T.StructField(C["line_no"], T.IntegerType()),
        T.StructField(C["member"], T.StringType()), T.StructField(C["servicing_provider"], T.StringType()),
        T.StructField(C["billing_provider"], T.StringType()), T.StructField(C["dos"], T.DateType()),
        T.StructField(C["code"], T.StringType()), T.StructField(C["units"], T.DecimalType(15, 4)),
        T.StructField(C["paid_amt"], T.DecimalType(15, 2)), T.StructField(C["pos"], T.StringType()),
        T.StructField(C["form"], T.StringType()),
        T.StructField(C["mods"][0], T.StringType()), T.StructField(C["mods"][1], T.StringType()),
        T.StructField(C["mods"][2], T.StringType()), T.StructField(C["mods"][3], T.StringType()),
        T.StructField(C["pa_no"], T.StringType()), T.StructField(C["dob"], T.DateType()),
        T.StructField(C["prov_type"], T.StringType()), T.StructField(C["billing_type"], T.StringType()),
    ])


_SAME = object()


def L(cid, ln, mem, prov, dos, code, units=1, paid=10.0, m1=None, m2=None, pa=None, form="A", dob="1980-01-01",
      ptype="08", btype=_SAME, bprov=_SAME, m3=None, m4=None):
    """One claim line. ptype = SERVICING provider type code, btype = BILLING provider type code (default: the same
    code - a provider billing for itself). The billing type picks the CMS TGM Table 2 row (08 MD: practitioner file on
    a CMS-1500, outpatient file on a UB-04). bprov = the BILLING provider id (default: the servicing id `prov`);
    m3 / m4 = modifier columns 3 and 4 (v2.6, 2026-10-04)."""
    d = date.fromisoformat(dos) if isinstance(dos, str) else dos
    return (cid, ln, mem, prov, prov if bprov is _SAME else bprov, d, code,
            None if units is None else Decimal(str(units)),
            None if paid is None else Decimal(str(paid)), "11", form, m1, m2, m3, m4, pa,
            None if dob is None else date.fromisoformat(dob), ptype, ptype if btype is _SAME else btype)


def load(spark, rows):
    spark.createDataFrame(rows, _schema()).write.mode("overwrite").format("parquet").saveAsTable(dg.CLAIMS)
    dg.create_snapshot(spark, fmt="parquet")


def _ed(form, svc):
    """The edit file a test rule comes from: svc when given, else the file practitioner lines take on `form`."""
    return svc if svc != "practitioner" else {"A": "practitioner", "O": "outpatient"}.get(form, form)


def ncci_pair(a, b, mi, eff="2010-01-01", end=None, form="A", svc="practitioner"):
    ed = _ed(form, svc)
    return Rule(origin="ncci", plane="coding_edit", binding_status="mandatory", statement=f"{b} with {a} {ed}",
                source_doc="CMS", source_locator=f"pair {a}/{b}", effective_date=eff, end_date=end,
                predicate={"type": "code_pair_prohibited", "code_a": a, "code_b": b, "modifier_indicator": mi,
                           "service_category": ed, "ncci_edition": ed}, codes=[a, b]).assign_id().to_dict()


def ncci_mue(code, v, eff="2010-01-01", end=None, form="A", later=None, removed=False, svc="practitioner"):
    ed = _ed(form, svc)
    return Rule(origin="ncci", plane="coding_edit", binding_status="mandatory", statement=f"{code} max {v} {ed}",
                source_doc="CMS", source_locator=f"code {code}", effective_date=eff, end_date=end,
                predicate={"type": "max_units_per_line", "code": code, "threshold": v, "service_category": ed,
                           "ncci_edition": ed, "later_max_threshold": later, "removed_later": removed},
                codes=[code]).assign_id().to_dict()


def state(pred, origin="manual", eff=None, end=None, population="all"):
    codes = [pred[k] for k in ("code_a", "code_b", "code") if pred.get(k)] + list(pred.get("code_set") or [])
    return Rule(origin=origin, plane="coverage_scope", binding_status="state_policy",
                statement=f"state {pred['type']} {codes}", source_doc="Ch10", source_locator="p",
                predicate=pred, codes=codes, effective_date=eff, end_date=end,
                population=population).assign_id().to_dict()


def compile_one(rule):
    d = dg.build_detectors([rule])[0]
    assert d["compiled"], d["reason"]
    return d["sql"]


def run(spark, sql):
    return [r.asDict() for r in spark.sql(sql).collect()]


def write_edits(spark, rules, build_id="B1"):
    ptp, mue = dg.ncci_edit_tables(rules)
    ptp["build_id"], mue["build_id"] = build_id, build_id
    for df, t in ((ptp, dg.PTP_EDITS_TABLE), (mue, dg.MUE_LIMITS_TABLE)):
        kb_io.to_spark(spark, df).write.mode("overwrite").format("parquet").saveAsTable(t)


def both_ptp(spark, rule, lines):
    """per-rule AND batch findings for one NCCI pair rule"""
    load(spark, lines)
    write_edits(spark, [rule])
    return run(spark, compile_one(rule)), run(spark, dg.batch_ptp_sql(build_id="B1"))


def both_mue(spark, rule, lines):
    load(spark, lines)
    write_edits(spark, [rule])
    return run(spark, compile_one(rule)), run(spark, dg.batch_mue_sql(build_id="B1"))


HARD = ncci_pair("11111", "22222", "0")
MOD = ncci_pair("33333", "44444", "1")


# ======================================================== PTP modifier logic (CMS TGM s8.1)
@pytest.mark.parametrize("m1a,m2a,m1b,m2b,expect", [
    ("LT", None, "LT", None, 1),       # same anatomic modifier, no override -> edit applies
    ("LT", None, "LT", "59", 0),       # 59 overrides the exception
    ("LT", "XS", "LT", None, 0),       # override on either line
    ("LT", None, "RT", None, 0),       # different sites -> bypass
    ("LT", None, None, None, 0),       # modifier on one line -> bypass
    (None, None, None, None, 1),       # no modifier -> flag
    ("GT", None, None, None, 1),       # GT is not an NCCI modifier
    (" 59", None, None, None, 0),      # C1-02: padded / lower case still bypass
    (None, None, "59 ", None, 0),
    (None, None, "xu", None, 0),
    ("lt", None, "LT", None, 1),       # case-insensitive same-site exception
])
def test_ptp_indicator1_modifiers(spark, m1a, m2a, m1b, m2b, expect):
    lines = [L("c", 1, "M", "P", D, "33333", m1=m1a, m2=m2a), L("c", 2, "M", "P", D, "44444", m1=m1b, m2=m2b)]
    for f in both_ptp(spark, MOD, lines):
        assert len(f) == expect


def test_ptp_indicator0_never_bypassed(spark):
    for f in both_ptp(spark, HARD, [L("c", 1, "M", "P", D, "11111", m1="59"), L("c", 2, "M", "P", D, "22222", m1="XU")]):
        assert len(f) == 1 and f[0]["finding_severity"] == "hard_denial"


def test_ptp_25_bypasses_only_on_em_code(spark):
    """C2-08: 'Modifiers 24, 25, and 57 should only be appended to an E&M code (99202-99499, 92002-92014)'."""
    surg = ncci_pair("11111", "22222", "1")
    for f in both_ptp(spark, surg, [L("c", 1, "M", "P", D, "11111"), L("c", 2, "M", "P", D, "22222", m1="25")]):
        assert len(f) == 1                                        # 25 on a surgical code: no bypass
    em = ncci_pair("11111", "99213", "1")
    for f in both_ptp(spark, em, [L("c", 1, "M", "P", D, "11111"), L("c", 2, "M", "P", D, "99213", m1="25")]):
        assert f == []                                            # 25 on the E&M line: bypass


def test_ptp_finding_targets_column_two_one_row_per_line(spark):
    """C1-07: 3 Column One lines x 2 Column Two lines = 2 findings, not 6."""
    lines = [L("h", i + 1, "M", "P", D, "11111", paid=10) for i in range(3)] + \
            [L("h", 10 + i, "M", "P", D, "22222", paid=25) for i in range(2)]
    for f in both_ptp(spark, HARD, lines):
        assert Counter((x["claim_id"], x["line_no"]) for x in f) == Counter({("h", 10): 1, ("h", 11): 1})
        assert all(x["col1_claim_id"] == "h" and x["col1_line_no"] == 1 for x in f)
        assert all(x["evidence_lines"] == "h:1,h:2,h:3" for x in f)
        assert sum(float(x["paid_amt"]) for x in f) == 50.0


def test_ptp_needs_same_provider_and_both_payable_lines(spark):
    for f in both_ptp(spark, HARD, [L("c", 1, "M", "P1", D, "11111"), L("c", 2, "M", "P2", D, "22222")]):
        assert f == []                                            # NCCI: same servicing provider only
    for paid in (0, -60):                                         # C1-01: $0 / reversal Column Two line
        lines = [L("c", 1, "M", "P", D, "11111", paid=100), L("c", 2, "M", "P", D, "22222", paid=paid,
                                                                units=1 if paid >= 0 else -1)]
        for f in both_ptp(spark, HARD, lines):
            assert f == []
    # a reversed Column Two line (original + exact reversal) is not payable either
    lines = [L("c", 1, "M", "P", D, "11111"), L("c", 2, "M", "P", D, "22222", paid=60),
             L("cR", 1, "M", "P", D, "22222", units=-1, paid=-60)]
    for f in both_ptp(spark, HARD, lines):
        assert f == []
    # C2-07 inside SQL: a $0 Column One line does not make the Column Two line deniable
    for f in both_ptp(spark, HARD, [L("c", 1, "M", "P", D, "11111", paid=0), L("c", 2, "M", "P", D, "22222")]):
        assert f == []


def test_ptp_window_inclusive_and_codes_normalised(spark):
    r = ncci_pair("11111", "22222", "0", eff="2026-01-15", end="2026-01-15")
    for f in both_ptp(spark, r, [L("c", 1, "M", "P", D, "11111"), L("c", 2, "M", "P", D, "22222 ")]):
        assert len(f) == 1                                        # deletion date is the last active day
    for f in both_ptp(spark, r, [L("c", 1, "M", "P", "2026-01-16", "11111"), L("c", 2, "M", "P", "2026-01-16", "22222")]):
        assert f == []


def test_ptp_null_line_numbers_still_pair(spark):
    for f in both_ptp(spark, HARD, [L("c", None, "M", "P", D, "11111"), L("c2", None, "M", "P", D, "22222")]):
        assert len(f) == 1


# ======================================================== NCCI edit file per line: provider type x form (CMS Table 2)
def test_ncci_runs_only_on_lines_of_its_edit_file(spark):
    for form in ("D", "C", "I", "L"):                              # TGM s5.2: never, whatever the provider type
        lines = [L("c", 1, "M", "P", D, "11111", form=form), L("c", 2, "M", "P", D, "22222", form=form)]
        for f in both_ptp(spark, HARD, lines):
            assert f == [], form
    oph = ncci_pair("11111", "22222", "0", form="O", svc="outpatient")
    for f in both_ptp(spark, oph, [L("c", 1, "M", "P", D, "11111"), L("c", 2, "M", "P", D, "22222")]):
        assert f == []                                            # practitioner lines on a CMS-1500 take PRA, not OPH
    for pt in ("02", "08"):                                       # hospital - and a practitioner - on a UB-04: OPH
        for f in both_ptp(spark, oph, [L("c", 1, "M", "P", D, "11111", form="O", ptype=pt),
                                       L("c", 2, "M", "P", D, "22222", form="o", ptype=pt)]):
            assert len(f) == 1, pt                                # (form case-normalised)
    asc = [L("c", 1, "M", "P", D, "11111", form="O", ptype="43"), L("c", 2, "M", "P", D, "22222", form="O", ptype="43")]
    for f in both_ptp(spark, oph, asc):
        assert f == []                                            # an ASC takes the PRA file even on a UB-04 ...
    for f in both_ptp(spark, HARD, asc):
        assert len(f) == 1                                        # ... so the practitioner edit judges it
    for pt in ("30", "C2", "54"):                                 # DME supplier (DME file), FQHC (optional: off),
        for f in both_ptp(spark, HARD, [L("c", 1, "M", "P", D, "11111", ptype=pt),        # dental hygienist (none)
                                        L("c", 2, "M", "P", D, "22222", ptype=pt)]):
            assert f == [], pt
    # a dentist is a physician practitioner (TGM Table 2 footnote 14): PRA on a CMS-1500, nothing on an ADA claim
    for form, n in (("A", 1), ("D", 0)):
        for f in both_ptp(spark, HARD, [L("c", 1, "M", "P", D, "11111", form=form, ptype="07"),
                                        L("c", 2, "M", "P", D, "22222", form=form, ptype="07")]):
            assert len(f) == n, form
    for f in both_ptp(spark, HARD, [L("c", 1, "M", "P", D, "11111", ptype="8"), L("c", 2, "M", "P", D, "22222", ptype=" 08")]):
        assert len(f) == 1                                        # '8' == '08' (a numeric code column), padded spaces
    mixed = [L("c", 1, "M", "P", D, "11111", form="A"), L("c", 2, "M", "P", D, "22222", form="O")]
    for f in both_ptp(spark, HARD, mixed):
        assert f == []                                            # both lines must take the rule's edit file


@pytest.mark.parametrize("route_by,optional,unmapped", [
    ("billing_provider_type", (), "form"),                                  # the defaults
    ("billing_provider_type", ("testing_facility", "other_outpatient"), "form"),
    ("billing_provider_type", ("other_outpatient",), "none"),
    ("provider_type", ("other_outpatient",), "form"),                       # billing type ignored
    ("form", (), "form"),
])
def test_edition_sql_matches_the_python_routing_for_every_code(spark, monkeypatch, route_by, optional, unmapped):
    """The SQL CASE the snapshot stamps == ncci_routing.edition() for every code in the table, as the billing AND as
    the servicing provider type, on every form, under every routing switch."""
    import ncci_routing as nr
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", route_by)
    monkeypatch.setattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", optional)
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", unmapped)
    codes = [r["sprov_type"] for r in nr.load_table()] + ["8", " 08 ", "c2", "ZZ", None, "", "8.0", "08.00", "nan",
                                                         " None ", "NULL", "NANA", "\t08", "8.5"]
    partners = ["08", "01", "07", "02", "C2", "E1", "30", "03", "ZZ", None, " 8", "NONE", "na"]
    combos = sorted({(t, b) for t in codes for b in partners} | {(t, b) for t in partners for b in codes},
                    key=lambda x: (str(x[0]), str(x[1])))
    forms = ("A", "O", "D", "a ")
    rows = [L(f"c{i}_{j}", 1, f"M{i}", "P", D, "11111", form=f, ptype=t, btype=b)
            for i, (t, b) in enumerate(combos) for j, f in enumerate(forms)]
    load(spark, rows)
    got = {r["ClaimID"]: r["e"] for r in spark.sql(f"SELECT ClaimID, pie_ncci_edition AS e FROM {dg.DETECT}").collect()}
    assert len(got) == len(rows)
    bad = [(t, b, f, got[f"c{i}_{j}"], nr.edition(f, t, billing_type=b))
           for i, (t, b) in enumerate(combos) for j, f in enumerate(forms)
           if got[f"c{i}_{j}"] != nr.edition(f, t, billing_type=b)]
    assert not bad, bad[:10]
    # 01 / 07 / gap read the RAW claims table through ncci_routing.routed_sql(): the same edit file on every line
    cols = {c.upper() for c in spark.table(dg.CLAIMS).columns}
    raw = {r["ClaimID"]: (r["e"], r["st"], r["bt"]) for r in spark.sql(
        f"SELECT ClaimID, {nr.PIE_EDITION} AS e, {nr.PIE_PROV_TYPE} AS st, {nr.PIE_BPROV_TYPE} AS bt "
        f"FROM {nr.routed_sql(dg.CLAIMS, C, cols=cols)} x").collect()}
    assert {k: v[0] for k, v in raw.items()} == got
    assert all(raw[f"c{i}_0"][1:] == (nr.norm_type(t), nr.norm_type(b)) for i, (t, b) in enumerate(combos))


@pytest.mark.parametrize("bt,st,form,optional,want", [
    ("02", "08", "A", (), "outpatient"),            # a hospital bills a physician's service: the hospital's row (OPH)
    ("08", "02", "A", (), "practitioner"),          # a physician bills: PRA whoever the servicing type is
    ("01", "08", "A", (), "practitioner"),          # group billing ID: practitioner row
    ("01", "01", "A", (), "practitioner"),          # ... rendering not identified: still PRA (Table 2 row 1)
    ("C2", "08", "A", (), None),                    # FQHC: optional row, off by default -> no NCCI
    ("C2", "08", "A", ("other_outpatient",), "practitioner"),   # on: rendering identified -> PRA
    ("C2", "C2", "A", ("other_outpatient",), "outpatient"),     # on: not identified -> OPH
    ("C2", "01", "A", ("other_outpatient",), "outpatient"),     # group ID is not a rendering practitioner
    ("C2", "08", "O", ("other_outpatient",), "outpatient"),     # UB-04: OPH
    ("ZZ", "02", "A", (), "outpatient"),            # unmapped billing type: the servicing type decides
    (None, "30", "A", (), "dme"),                   # no billing type: the servicing type decides
    ("ZZ", "ZZ", "O", (), None),                    # neither mapped: no NCCI (NCCI_UNMAPPED_PROVIDER_TYPE 'none')
    ("43", "08", "O", (), "practitioner"),          # ASC on a UB-04: PRA
    ("07", "07", "D", (), None),                    # ADA dental claim: never NCCI
])
def test_billing_provider_type_picks_the_edit_file_end_to_end(spark, monkeypatch, bt, st, form, optional, want):
    """2026-10-03: the BILLING provider type picks the Table 2 row; per-rule AND batch PTP statements judge a pair only
    on lines of the rule's edit file."""
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", "none")          # the default since 2026-10-04
    _route_case(spark, monkeypatch, bt, st, form, optional, want)


@pytest.mark.parametrize("unmapped,form,want", [("none", "O", None), ("none", "A", None),
                                                ("form", "O", "outpatient"), ("form", "A", "practitioner")])
def test_a_line_whose_provider_types_are_not_in_the_table_follows_the_unmapped_switch(spark, monkeypatch, unmapped,
                                                                                     form, want):
    """2026-10-04 (external review): a precision-first release does not GUESS the edit file from the claim form for
    a provider type nobody mapped - 'none' (default) gives no NCCI; 'form' is the old A -> PRA / O -> OPH guess."""
    monkeypatch.setattr(config, "NCCI_UNMAPPED_PROVIDER_TYPE", unmapped)
    _route_case(spark, monkeypatch, "ZZ", "ZZ", form, (), want)


def _route_case(spark, monkeypatch, bt, st, form, optional, want):
    monkeypatch.setattr(config, "NCCI_OPTIONAL_CATEGORIES_ON", optional)
    rules = {"practitioner": HARD, "outpatient": ncci_pair("11111", "22222", "0", form="O", svc="outpatient"),
             "dme": ncci_pair("11111", "22222", "0", svc="dme")}
    lines = [L("c", 1, "M", "P", D, "11111", form=form, ptype=st, btype=bt),
             L("c", 2, "M", "P", D, "22222", form=form, ptype=st, btype=bt)]
    load(spark, lines)
    write_edits(spark, list(rules.values()))
    for ed, rule in rules.items():
        assert len(run(spark, compile_one(rule))) == (1 if ed == want else 0), (ed, want)
    batch = run(spark, dg.batch_ptp_sql(build_id="B1"))
    assert [x["ncci_edition"] for x in batch] == ([want] if want else []), batch


# ======================================================== provider type allowed (2026-10-03, BProv_Type)
H0035_TYPES = ["B2", "B5", "02", "71"]          # Ch. 300 / B2 matrix: partial hospitalization billed only by these


def _allowed(types=H0035_TYPES, role=None, code="H0035", **kw):
    pred = {"type": "provider_type_allowed", "code_set": [code], "provider_types": types}
    if role:
        pred["provider_role"] = role
    return state(pred, origin="extracted", **kw)


def test_provider_type_allowed_flags_a_known_type_not_in_the_list(spark):
    load(spark, [L("bad", 1, "M1", "P", D, "H0035", ptype="77", btype="77"),        # BH clinic bills: finding
                 L("ok", 1, "M2", "P", D, "H0035", ptype="77", btype="02"),         # hospital bills: fine
                 L("pad", 1, "M3", "P", D, "h0035 ", ptype="77", btype=" 2"),       # '2' == '02', code normalised
                 L("lc", 1, "M4", "P", D, "H0035", ptype="77", btype="b5"),         # lower case B5
                 L("nul", 1, "M5", "P", D, "H0035", ptype="77", btype=None),        # unknown type: never a finding
                 L("blank", 1, "M6", "P", D, "H0035", ptype="77", btype="  "),
                 L("zero", 1, "M7", "P", D, "H0035", ptype="77", btype="77", paid=0),   # $0 line
                 L("rev", 1, "M8", "P", D, "H0035", ptype="77", btype="77", paid=40),
                 L("revR", 1, "M8", "P", D, "H0035", ptype="77", btype="77", units=-1, paid=-40),  # reversed
                 L("other", 1, "M9", "P", D, "H2017", ptype="77", btype="77")])      # another code
    f = run(spark, compile_one(_allowed()))
    assert [(x["claim_id"], x["finding_severity"]) for x in f] == [("bad", "provider_type_not_allowed")], f
    assert f[0]["finding"] == "H0035 billed by provider type 77 (allowed: 02/71/B2/B5)"
    assert float(f[0]["paid_at_risk"]) == 10.0 and float(f[0]["allowed_units"]) == 0


def test_provider_type_allowed_reads_the_role_it_names(spark):
    """Billing provider by default; provider_role='servicing' reads SProv_Type. The other role's type is ignored."""
    load(spark, [L("b_bad", 1, "M1", "P", D, "H0035", ptype="02", btype="77"),
                 L("s_bad", 1, "M2", "P", D, "H0035", ptype="77", btype="02")])
    assert [x["claim_id"] for x in run(spark, compile_one(_allowed()))] == ["b_bad"]
    assert [x["claim_id"] for x in run(spark, compile_one(_allowed(role="billing")))] == ["b_bad"]
    assert [x["claim_id"] for x in run(spark, compile_one(_allowed(role="servicing")))] == ["s_bad"]


def test_provider_type_allowed_pa_window_and_age(spark):
    load(spark, [L("pa", 1, "M1", "P", D, "H0035", btype="77", pa="PA1"),
                 L("early", 1, "M2", "P", "2024-07-07", "H0035", btype="77"),
                 L("kid", 1, "M3", "P", D, "H0035", btype="77", dob="2015-01-01")])
    got = {x["claim_id"]: x["finding_severity"] for x in run(spark, compile_one(_allowed(eff="2024-07-08")))}
    assert got == {"pa": "verify_pa", "kid": "provider_type_not_allowed"}
    adult = _allowed(population="members 18 and older")
    adult["predicate"]["age"] = {"min": 18}
    assert sorted(x["claim_id"] for x in run(spark, compile_one(adult))) == ["early", "pa"]


def test_provider_type_allowed_needs_codes_it_can_trust():
    for bad in ([], ["0 2"], ["02;--"], [None]):
        d = dg.build_detectors([_allowed(types=bad)])[0]
        assert not d["compiled"], bad


# ======================================================== MUE per line
def test_mue_per_line_paid_normalised_and_dedup(spark):
    r = ncci_mue("J3490", 1)
    for f in both_mue(spark, r, [L("m", 1, "M", "P", D, "j3490", units=5)]):
        assert len(f) == 1 and float(f[0]["excess_units"]) == 4.0
    for f in both_mue(spark, r, [L("m", 1, "M", "P", D, "J3490", units=5)] * 2):
        assert len(f) == 1                                        # C1-04: exact duplicate row
    for f in both_mue(spark, r, [L("m", 1, "M", "P", D, "J3490", units=5, paid=0)]):
        assert f == []                                            # $0 line
    for f in both_mue(spark, r, [L("m", 1, "M", "P", D, "J3490", units=1), L("m", 2, "M", "P", D, "J3490", units=1)]):
        assert f == []                                            # per LINE, never summed across lines


def test_mue_changed_later_is_verify_not_violation(spark):
    """C2-03: CMS raises MUEs retroactively; a line within a LATER quarter's value is a verify finding."""
    raised = ncci_mue("J3490", 1, later=3)
    for f in both_mue(spark, raised, [L("m", 1, "M", "P", D, "J3490", units=2)]):
        assert len(f) == 1 and f[0]["finding_severity"] == "verify_mue_changed_later"
    for f in both_mue(spark, raised, [L("m", 1, "M", "P", D, "J3490", units=5)]):
        assert len(f) == 1 and f[0]["finding_severity"] == "units_over_limit"
    removed = ncci_mue("J3490", 1, removed=True)
    for f in both_mue(spark, removed, [L("m", 1, "M", "P", D, "J3490", units=5)]):
        assert f[0]["finding_severity"] == "verify_mue_changed_later"


def test_mue_two_windows(spark):
    early, late = ncci_mue("A1234", 2, eff="2025-01-01", end="2025-03-31"), ncci_mue("A1234", 4, eff="2025-04-01")
    load(spark, [L("a", 1, "M", "P", "2025-02-10", "A1234", units=3), L("b", 1, "M", "P", "2025-05-10", "A1234", units=3)])
    write_edits(spark, [early, late])
    f = run(spark, dg.batch_mue_sql(build_id="B1"))
    assert [(x["claim_id"], int(x["allowed_units"])) for x in f] == [("a", 2)]
    assert run(spark, dg.batch_mue_sql(build_id="OTHER")) == []   # C4-01: SQL only reads ITS build's edits


# ======================================================== state rules
def test_state_pair_scope_default_narrow_and_explicit_member(spark):
    pair = {"type": "code_pair_prohibited", "code_a": "S9484", "code_b": "S9485", "modifier_indicator": "0"}
    load(spark, [L("x", 1, "M", "P1", D, "S9484"), L("y", 1, "M", "P2", D, "S9485")])
    assert run(spark, compile_one(state(dict(pair), origin="extracted"))) == []       # C3-01
    wide = state(dict(pair, scope="member_day"), origin="extracted")
    assert len(run(spark, compile_one(wide))) == 1
    load(spark, [L("x", 1, None, "P1", D, "S9484"), L("y", 1, None, "P2", D, "S9485")])
    assert run(spark, compile_one(wide)) == []                                       # C1-05: no member


def test_state_pa_on_either_line_and_blank_pa(spark):
    pair = state({"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961", "modifier_indicator": "0",
                  "scope": "member_day"})
    load(spark, [L("a", 1, "M", "P", D, "98960", pa="PA1"), L("b", 1, "M", "Q", D, "98961", pa="  ")])
    f = run(spark, compile_one(pair))
    assert len(f) == 1 and f[0]["finding_severity"] == "verify_pa" and f[0]["pa_present"] == 1
    nc = state({"type": "code_not_covered", "code": "11975"})
    load(spark, [L("w", 1, "M", "P", D, "11975", pa="PA7"), L("n", 1, "M", "P", D, "11975"),
                 L("b", 1, "M", "P", D, "11975", pa="   ")])
    got = {x["claim_id"]: (x["pa_present"], x["finding_severity"]) for x in run(spark, compile_one(nc))}
    assert got == {"w": (1, "verify_pa"), "n": (0, "not_covered_paid"), "b": (0, "not_covered_paid")}
    # NCCI ignores PA (CMS: a PA is not an NCCI bypass) - pa_present is NULL (not evaluated), never 0 ("no PA")
    for f in both_mue(spark, ncci_mue("11975", 0 + 1), [L("w", 1, "M", "P", D, "11975", units=3, pa="PA7")]):
        assert f[0]["finding_severity"] == "units_over_limit" and f[0]["pa_present"] is None
    for f in both_ptp(spark, HARD, [L("p", 1, "M", "P", D, "11111", pa="PA1"), L("p", 2, "M", "P", D, "22222", pa="PA2")]):
        assert f[0]["finding_severity"] == "hard_denial" and f[0]["pa_present"] is None


def test_state_not_covered_ignores_zero_and_reversed(spark):
    nc = state({"type": "code_not_covered", "code": "11975"})
    load(spark, [L("z", 1, "M", "P", D, "11975", paid=0), L("o", 1, "M", "P", D, "11975", paid=300),
                 L("oR", 1, "M", "P", D, "11975", units=-1, paid=-300), L("k", 1, "M", "P", D, "11975 ", paid=50)])
    assert sorted(x["claim_id"] for x in run(spark, compile_one(nc))) == ["k"]


def test_daily_cap_code_set_dedup_null_member_and_evidence(spark):
    cap = state({"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4})
    load(spark, [L("c4", 1, "M", "P", D, "98960", units=3), L("c4", 2, "M", "P", D, "98961", units=2)])
    f = run(spark, compile_one(cap))
    assert len(f) == 1 and float(f[0]["observed_units"]) == 5 and f[0]["evidence_lines"] == "c4:1,c4:2"
    assert float(f[0]["excess_units"]) == 1.0 and round(float(f[0]["paid_at_risk"]), 2) == 4.0     # 20 * 1/5
    load(spark, [L("d", 1, "M", "P", D, "98962", units=3)] * 2)
    assert run(spark, compile_one(cap)) == []                                         # C1-04
    load(spark, [L("x", 1, None, "P", D, "98962", units=3), L("y", 1, None, "P", D, "98962", units=3)])
    assert run(spark, compile_one(cap)) == []                                         # C1-05
    load(spark, [L("e", i, "M", f"P{i}", D, "98962", units=1) for i in (3, 1, 2, 0, 4)])
    ev = run(spark, compile_one(cap))[0]["evidence_lines"]
    assert ev == ",".join(sorted(ev.split(",")))                                     # C1-10
    load(spark, [L("r", 1, "M", "P", D, "98962", units=3, paid=30), L("r", 2, "M", "P", D, "98962", units=3, paid=30),
                 L("rR", 1, "M", "P", D, "98962", units=-3, paid=-30)])
    assert run(spark, compile_one(cap)) == []                                         # reversal nets out


def test_per_dos_cap_ignores_missing_provider(spark):
    load(spark, [L("x", 1, "M", None, D, "97110", units=2), L("y", 1, "M", None, D, "97110", units=1)])
    assert run(spark, compile_one(state({"type": "max_units_per_dos", "code": "97110", "threshold": 2}))) == []


@pytest.mark.parametrize("period,dates,start,end", [
    ("benefit_year", ["2025-10-01", "2026-09-30"], "2025-10-01", "2026-09-30"),
    ("year", ["2026-01-01", "2026-12-31"], "2026-01-01", "2026-12-31"),
    ("month", ["2026-02-01", "2026-02-28"], "2026-02-01", "2026-02-28"),
])
def test_period_start_and_end_are_dates(spark, period, dates, start, end):
    load(spark, [L("b", i + 1, "M", "P", d, "T1021", units=6) for i, d in enumerate(dates)])
    f = run(spark, compile_one(state({"type": "max_units_per_period", "code": "T1021", "threshold": 10,
                                      "period": period})))
    assert len(f) == 1 and str(f[0]["period_start"])[:10] == start and str(f[0]["period_end"])[:10] == end


def test_benefit_year_boundary_splits_sep30_oct1(spark):
    load(spark, [L("a", 1, "M", "P", "2025-09-30", "T1021", units=6), L("b", 1, "M", "P", "2025-10-01", "T1021", units=6)])
    assert run(spark, compile_one(state({"type": "max_units_per_period", "code": "T1021", "threshold": 10,
                                         "period": "benefit_year"}))) == []


# ======================================================== age (date_of_birth on the claim)
def test_age_condition_on_date_of_service(spark):
    adult = state({"type": "code_not_covered", "code": "11975", "age": {"min": 21}}, origin="extracted",
                  population="members 21 and older")
    acc, _ = validate_gate.gate([Rule.from_dict(adult)])
    assert acc[0]["machine_checkable"], acc[0]["gate_notes"]       # an age-scoped rule now compiles
    load(spark, [L("turns21", 1, "M1", "P", "2026-01-15", "11975", dob="2005-01-15"),    # 21st birthday
                 L("day_before", 1, "M2", "P", "2026-01-14", "11975", dob="2005-01-15"),
                 L("nodob", 1, "M3", "P", D, "11975", dob=None)])
    assert sorted(x["claim_id"] for x in run(spark, compile_one(acc[0]))) == ["turns21"]
    child = state({"type": "code_not_covered", "code": "11975", "age": {"below": 21}}, origin="extracted")
    assert sorted(x["claim_id"] for x in run(spark, compile_one(child))) == ["day_before"]
    # a scoped rule with NO age condition stays a lead
    alt = Rule.from_dict(state({"type": "code_not_covered", "code": "11975"}, origin="extracted",
                               population="ALTCS members"))
    acc2, _ = validate_gate.gate([alt])
    assert not acc2[0]["machine_checkable"]


# ======================================================== qualifiers
def test_exception_and_discretionary_label_findings(spark):
    exc = state({"type": "max_units_per_day", "code": "A0422", "threshold": 1,
                 "exception": "unless the additional transport is a separately identifiable service"}, origin="extracted")
    load(spark, [L("t1", 1, "M", "P", D, "A0422"), L("t2", 1, "M", "P", D, "A0422")])
    f = run(spark, compile_one(exc))
    assert len(f) == 1 and f[0]["finding_severity"] == "verify_exception" and f[0]["finding_basis"] == "units_over_limit"
    may = state({"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2017", "modifier_indicator": "0",
                 "scope": "member_day", "discretionary": True}, origin="extracted")
    load(spark, [L("pd", 1, "M", "P1", D, "H2018"), L("ps", 1, "M", "P2", D, "H2017")])
    f = run(spark, compile_one(may))
    assert len(f) == 1 and f[0]["claim_id"] == "ps" and f[0]["finding_severity"] == "discretionary"


# ======================================================== rolling-window SIGNAL (not a finding)
def test_rolling_window_signal_vs_contract_year(spark):
    """15 visits Aug-Sep 2025 + 15 visits Oct-Nov 2025 with a 15-per-contract-year limit: the policy check
    finds NOTHING (15 in each contract year), the rolling 365-day signal sees 30."""
    rule = state({"type": "max_units_per_period", "code": "97110", "threshold": 15, "period": "benefit_year"},
                 origin="extracted")
    days = [date(2025, 8, 1) + timedelta(days=4 * i) for i in range(15)] + \
           [date(2025, 10, 1) + timedelta(days=4 * i) for i in range(15)]
    load(spark, [L(f"v{i}", 1, "M", "P", d, "97110") for i, d in enumerate(days)])
    assert run(spark, compile_one(rule)) == []
    sig = run(spark, dg.compile_rolling_signal(rule))
    assert len(sig) == 1 and float(sig[0]["rolling_units"]) == 30 and int(sig[0]["rolling_days"]) == 365


# ======================================================== compile-time guards
def test_padded_self_pair_never_compiles():
    bad = Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy", statement="s",
               source_doc="Ch10", predicate={"type": "code_pair_prohibited", "code_a": "99213", "code_b": "99213 ",
                                             "modifier_indicator": "0"}, codes=["99213"]).assign_id()
    acc, _ = validate_gate.gate([bad])
    assert not dg.build_detectors(acc)[0]["compiled"]


def test_impossible_or_inverted_dates_are_leads():
    d = dg.build_detectors([state({"type": "code_not_covered", "code": "11975"}, eff="2025-02-30")])[0]
    assert not d["compiled"]
    d = dg.build_detectors([state({"type": "code_not_covered", "code": "11975"}, eff="2025-05-01", end="2025-04-01")])[0]
    assert not d["compiled"]
    d = dg.build_detectors([state({"type": "code_not_covered", "code": "１１９７５"})])[0]       # full-width digits
    assert not d["compiled"]


# ======================================================== snapshot accounting
def test_snapshot_stats(spark):
    load(spark, [L("a", 1, "M", "P", D, "11975", paid=300), L("aR", 1, "M", "P", D, "11975", units=-1, paid=-300),
                 L("a", 1, "M", "P", D, "11975", paid=300),              # exact duplicate of a:1
                 L("z", 1, "M", "P", D, "11975", paid=0), L("n", 1, None, "P", D, "11975"),
                 L("d", 1, "M", "P", D, "11975", dob=None)])
    s = spark.sql(dg.snapshot_stats_sql()).collect()[0].asDict()
    assert s["source_rows"] == 6 and s["snapshot_rows"] == 4          # duplicate and no-member rows dropped
    assert s["reversal_rows"] == 1 and s["cancelled_lines"] == 1 and s["zero_paid_lines"] == 1
    assert s["payable_lines"] == 1 and s["dob_missing_lines"] == 1


# ======================================================== batch == per-rule on random adversarial data
@pytest.mark.parametrize("seed", [1, 2, 3])
def test_batch_equals_per_rule_multiset(spark, seed):
    rnd = random.Random(seed)
    codes = ["11111", "22222", "33333", "44444", "99213"]
    mods = [None, None, None, "59", "LT", "RT", "25", " xu", "lt"]
    forms = ["A", "A", "A", "O", "D"]
    ptypes = ["08", "08", "02", "43", "30", "C2", None]
    lines = []
    for i in range(160):
        dos = date(2026, 1, 1) + timedelta(days=rnd.randint(0, 3))
        lines.append(L(f"c{rnd.randint(0, 40)}", rnd.randint(1, 4), f"M{rnd.randint(0, 6)}", f"P{rnd.randint(0, 2)}",
                       dos, rnd.choice(codes), units=rnd.choice([1, 2, 3, 0.5]), paid=rnd.choice([10, 25, 0]),
                       m1=rnd.choice(mods), m2=rnd.choice(mods), form=rnd.choice(forms), ptype=rnd.choice(ptypes),
                       btype=rnd.choice(ptypes + ["01", "ZZ"])))
    rules = [ncci_pair("11111", "22222", "0"), ncci_pair("33333", "44444", "1"),
             ncci_pair("22222", "99213", "1", eff="2026-01-02"), ncci_pair("11111", "22222", "1", form="O"),
             ncci_mue("11111", 1), ncci_mue("22222", 2, end="2026-01-02"), ncci_mue("33333", 1, form="O")]
    load(spark, lines)
    write_edits(spark, rules)
    key = lambda f: (f["claim_id"], f["line_no"], f.get("col1_claim_id"), f.get("col1_line_no"),
                     f["finding_severity"], f.get("evidence_lines"), float(f["paid_amt"] or 0))
    per = Counter()
    for r in rules:
        per.update(map(key, run(spark, compile_one(r))))
    batch = Counter(map(key, run(spark, dg.batch_ptp_sql(build_id="B1")) + run(spark, dg.batch_mue_sql(build_id="B1"))))
    assert per == batch and sum(per.values()) > 0


# ======================================================== the query validation pack (query_pack.py)
def test_query_pack_scenarios_all_pass(spark, monkeypatch):
    import query_pack as qp
    monkeypatch.setattr(qp, "SCRATCH_SCHEMA", "spark_catalog.policy_kb")
    rules = [
        state({"type": "code_pair_prohibited", "code_a": "S9484", "code_b": "S9485", "modifier_indicator": "0",
               "scope": "member_provider_day"}, origin="extracted"),
        state({"type": "code_pair_prohibited", "code_a": "H2018", "code_b": "H2017", "modifier_indicator": "0",
               "scope": "member_day", "discretionary": True}, origin="extracted"),
        state({"type": "max_units_per_day", "code": "A0422", "threshold": 1,
               "exception": "unless the additional transport is a separately identifiable service"}, origin="extracted"),
        state({"type": "max_units_per_day", "code_set": ["98960", "98961", "98962"], "threshold": 4}, origin="extracted"),
        state({"type": "max_units_per_period", "code_set": ["97110"], "threshold": 15, "period": "benefit_year",
               "age": {"min": 21}}, origin="extracted", population="members 21 and older"),
        state({"type": "max_units_per_period", "code_set": ["98960", "98961", "98962"], "threshold": 24,
               "period": "month"}, origin="extracted"),
        state({"type": "code_not_covered", "code": "11975"}, origin="extracted", eff="2025-07-01"),
    ]
    for r in rules:
        r["reviewer"] = "SS"
    dets = dg.build_detectors(rules)
    assert all(d["compiled"] for d in dets), [d["reason"] for d in dets if not d["compiled"]]
    ncci = [ncci_pair("11111", "22222", "0"), ncci_pair("33333", "44444", "1"),
            ncci_pair("55555", "66666", "1", form="O", svc="outpatient"), ncci_mue("J3490", 1),
            ncci_mue("J1100", 2, later=5), ncci_mue("E0601", 1, form="O", svc="dme")]
    batch_rows = [{"batch": "ncci_ptp", "sql": dg.batch_ptp_sql(build_id="BX")},
                  {"batch": "ncci_mue", "sql": dg.batch_mue_sql(build_id="BX")}]
    ptp_s, mue_s = qp.sample_ncci(ncci, n_ptp=3, n_mue=3)
    q, s = qp.build_pack(spark, rules, dets, batch_rows, ptp_s, mue_s, fmt="parquet", build_id="BX")
    bad = s[~s["pass"]]
    assert bad.empty, bad[["query_id", "scenario", "description", "result"]].to_string()
    n_period = sum(r["predicate"]["type"] == "max_units_per_period" for r in rules)
    # one query per rule + the two NCCI statements + one rolling-window SIGNAL query per period limit
    assert set(q["auto_test"]) == {"PASS"} and len(q) == len(rules) + 2 + n_period
    assert q["query_id"].str.startswith("SIGNAL:").sum() == n_period
    assert set(q["query_kind"]) == {"state rule (finding query)", "NCCI batch (finding query)",
                                    "utilization signal (NOT a finding)"}
    # the signal really is the gaming case: 15/contract year straddling Oct 1 is a signal, never a finding
    sig = s[s["query_id"].str.startswith("SIGNAL:") & (s["scenario"] == "F1")]
    assert len(sig) == n_period and sig["pass"].all()
    assert (s.groupby("query_id")["expected_findings"].max() >= 1).all()      # every query has a must-flag case
    assert q.loc[q["query_id"] == rules[1]["rule_id"], "what_it_does"].iloc[0].count("MAY be denied") == 1


# ======================================================== independent-oracle findings (2026-10-02), fixed
def test_reversal_rows_never_add_units_whatever_their_sign(spark):
    """R-01: a reversal booked with POSITIVE units (paid < 0) used to add its units to a daily sum and never
    cancel its line. The snapshot now counts a money-back row's units as negative."""
    cap = state({"type": "max_units_per_day", "code": "98960", "threshold": 4})
    for runits in (-3, 3):
        load(spark, [L("x", 1, "M", "P", D, "98960", units=3, paid=30),
                     L("r", 1, "M", "P", D, "98960", units=runits, paid=-30),
                     L("y", 1, "M", "P", D, "98960", units=2, paid=20)])
        assert run(spark, compile_one(cap)) == [], runits             # 3 - 3 + 2 = 2 <= 4
        s = {r["ClaimID"]: (r["pie_payable"], r["pie_cancelled"], float(r["QUANTITY_PAID"]), float(r["pie_units_raw"]))
             for r in spark.sql(f"SELECT * FROM {dg.DETECT}").collect()}
        assert s["x"][:2] == (False, True) and s["r"][2] == -3.0 and s["r"][3] == float(runits) and s["y"][0]


def test_evidence_keeps_missing_ids_is_distinct_and_numeric_ordered(spark):
    """F-01 / S-02 / S-03: a NULL line number dropped the line from evidence_lines (and 08 then mislabelled the pair);
    one line counted twice was listed twice; text order put C1:12 before C1:3 while Column One was C1:3."""
    lines = [L("C1", 3, "M", "P", D, "11111"), L("C1", 12, "M", "P", D, "11111"), L("C1", None, "M", "P", D, "11111"),
             L("C1", 7, "M", "P", D, "22222")]
    for f in both_ptp(spark, HARD, lines):                        # per-rule AND batch statement
        assert len(f) == 1
        assert f[0]["evidence_lines"] == "C1:,C1:3,C1:12" and f[0]["col1_claim_id"] == "C1" and f[0]["col1_line_no"] is None
    cap = state({"type": "max_units_per_day", "code_set": ["98960", "98961"], "threshold": 4})
    load(spark, [L("C2", 3, "M", "P", D, "98960", units=3), L("C2", 12, "M", "P", D, "98961", units=1),
                 L("C2", None, "M", "P", D, "98961", units=1)])
    f = run(spark, compile_one(cap))
    assert len(f) == 1 and f[0]["evidence_lines"] == "C2:,C2:3,C2:12" and float(f[0]["observed_units"]) == 5.0


def test_evidence_order_is_numeric_when_the_claims_table_holds_line_numbers_as_text(spark):
    """2026-10-03: production's LN_NO type is unconfirmed. Held as text, '12' sorted before '3' and Column One became
    C1:12. The sort key is now the line number as a number whatever the column type."""
    from pyspark.sql import types as T
    sch = T.StructType([T.StructField(f.name, T.StringType() if f.name == C["line_no"] else f.dataType)
                        for f in _schema().fields])
    rows = [tuple(str(v) if i == 1 and v is not None else v for i, v in enumerate(r))
            for r in [L("C1", 3, "M", "P", D, "11111"), L("C1", 12, "M", "P", D, "11111"),
                      L("C1", None, "M", "P", D, "11111"), L("C1", 7, "M", "P", D, "22222")]]
    spark.createDataFrame(rows, sch).write.mode("overwrite").format("parquet").saveAsTable(dg.CLAIMS)
    dg.create_snapshot(spark, fmt="parquet")
    write_edits(spark, [HARD])
    for f in (run(spark, compile_one(HARD)), run(spark, dg.batch_ptp_sql(build_id="B1"))):
        assert len(f) == 1 and f[0]["evidence_lines"] == "C1:,C1:3,C1:12", f
    cap = state({"type": "max_units_per_day", "code_set": ["98960", "98961"], "threshold": 4})
    rows = [tuple(str(v) if i == 1 and v is not None else v for i, v in enumerate(r))
            for r in [L("C2", 12, "M", "P", D, "98960", units=3), L("C2", 3, "M", "P", D, "98961", units=2)]]
    spark.createDataFrame(rows, sch).write.mode("overwrite").format("parquet").saveAsTable(dg.CLAIMS)
    dg.create_snapshot(spark, fmt="parquet")
    f = run(spark, compile_one(cap))
    assert len(f) == 1 and f[0]["evidence_lines"] == "C2:3,C2:12"


def test_a_reversal_cancels_the_lowest_line_NUMBER_when_line_numbers_are_text(spark):
    """Spec §1: of identical lines, a reversal cancels the first by (claim id, line NUMBER). Held as text, '12' sorted
    before '3' and the wrong line stayed payable (mutant B16, 2026-10-03)."""
    from pyspark.sql import types as T
    sch = T.StructType([T.StructField(f.name, T.StringType() if f.name == C["line_no"] else f.dataType)
                        for f in _schema().fields])
    rows = [tuple(str(v) if i == 1 and v is not None else v for i, v in enumerate(r))
            for r in [L("C1", 3, "M", "P", D, "11975", paid=300), L("C1", 12, "M", "P", D, "11975", paid=300),
                      L("R1", 1, "M", "P", D, "11975", units=-1, paid=-300)]]
    spark.createDataFrame(rows, sch).write.mode("overwrite").format("parquet").saveAsTable(dg.CLAIMS)
    dg.create_snapshot(spark, fmt="parquet")
    f = run(spark, compile_one(state({"type": "code_not_covered", "code": "11975"})))
    assert [(x["claim_id"], str(x["line_no"])) for x in f] == [("C1", "12")], f


def test_rows_of_one_claim_line_that_differ_only_in_billing_type_cancel_in_a_fixed_order(spark):
    """Spec §1 (v2.3): two rows of one claim line (same claim id and line number) tie on the cancellation order; the
    billing type (missing first, then ascending) decides which one a reversal cancels - every run the same."""
    lines = [L("C1", 1, "M", "P", D, "H0035", paid=180, btype="77"), L("C1", 1, "M", "P", D, "H0035", paid=180, btype="02"),
             L("R1", 1, "M", "P", D, "H0035", units=-1, paid=-180, btype="77")]
    for order in (lines, lines[::-1]):
        load(spark, order)
        s = {r["pie_bprov_type"]: r["pie_cancelled"] for r in spark.sql(
            f"SELECT pie_bprov_type, pie_cancelled FROM {dg.DETECT} WHERE PMT_AMT > 0").collect()}
        assert s == {"02": True, "77": False}, s                       # '02' < '77': the 02 row is cancelled
        f = run(spark, compile_one(_allowed()))
        assert [x["finding"] for x in f] == ["H0035 billed by provider type 77 (allowed: 02/71/B2/B5)"], f


# Every NCCI-associated modifier, one member each (2026-10-03). The lists are typed here from CMS - NOT imported from
# detector_gen - so dropping a modifier from the code fails this test (red-team mutants Q25-Q27 survived random tests).
# CMS 2026 Medicaid NCCI TGM s8.1 / NCCI Policy Manual ch. I: anatomic E1-E4, FA, F1-F9, LC, LD, LM, LT, RC, RI, RT, TA,
# T1-T9; global surgery 24, 25, 57, 58, 78, 79 (24/25/57 on E&M codes only); other 27, 59, 91, XE, XS, XP, XU. Same
# anatomic modifier on both lines: NOT bypassed unless 58, 59, 78, 79, XE, XP, XS or XU is also present.
CMS_ANATOMIC = ["E1", "E2", "E3", "E4", "FA"] + [f"F{i}" for i in range(1, 10)] + ["TA"] + [f"T{i}" for i in range(1, 10)] \
    + ["LT", "RT", "LC", "LD", "RC", "LM", "RI"]
CMS_OTHER_BYPASS = ["58", "78", "79", "27", "59", "91", "XE", "XS", "XP", "XU"]
CMS_EM_ONLY = ["24", "25", "57"]
CMS_SAME_SITE_OVERRIDE = ["58", "59", "78", "79", "XE", "XP", "XS", "XU"]


def test_every_ncci_modifier_bypasses_or_not_exactly_as_cms_lists(spark):
    soft, soft_em = ncci_pair("11111", "22222", "1"), ncci_pair("11111", "99213", "1")
    lines, expect = [], {}

    def case(mem, b_code, a_mods=(None, None), b_mods=(None, None), flagged=True):
        lines.append(L(f"a{mem}", 1, mem, "P", D, "11111", m1=a_mods[0], m2=a_mods[1]))
        lines.append(L(f"b{mem}", 1, mem, "P", D, b_code, m1=b_mods[0], m2=b_mods[1]))
        expect[mem] = flagged

    case("NONE", "22222")                                                       # no modifier: flagged
    for m in CMS_ANATOMIC + CMS_OTHER_BYPASS:
        case(f"B_{m}", "22222", b_mods=(m, None), flagged=False)                 # on the Column Two line
        case(f"A_{m}", "22222", a_mods=(m, None), flagged=False)                 # on the Column One line
        case(f"L_{m}", "22222", b_mods=(m.lower() + " ", None), flagged=False)   # lower case / padded
    for m in CMS_EM_ONLY:
        case(f"NE_{m}", "22222", b_mods=(m, None), flagged=True)                 # not an E&M code: no bypass
        case(f"EM_{m}", "99213", b_mods=(m, None), flagged=False)                # E&M code line: bypass
    for m in CMS_ANATOMIC:
        case(f"S_{m}", "22222", a_mods=(m, None), b_mods=(None, m), flagged=True)            # same site, any position
        case(f"SO_{m}", "22222", a_mods=(m, None), b_mods=(m, "59"), flagged=False)          # ... unless 59
    for o in CMS_SAME_SITE_OVERRIDE:
        case(f"O_{o}", "22222", a_mods=("LT", o), b_mods=("LT", None), flagged=False)
    case("DIFF", "22222", a_mods=("LT", None), b_mods=("RT", None), flagged=False)          # different sites
    load(spark, lines)
    write_edits(spark, [soft, soft_em])
    per = {f["member_id"] for r in (soft, soft_em) for f in run(spark, compile_one(r))}
    batch = {f["member_id"] for f in run(spark, dg.batch_ptp_sql(build_id="B1"))}
    want = {m for m, fl in expect.items() if fl}
    assert per == want, (sorted(per - want), sorted(want - per))
    assert batch == want, (sorted(batch - want), sorted(want - batch))


def test_batch_pair_never_crosses_edit_files_on_one_provider_day(spark):
    """Red-team mutant Q34 (2026-10-03) survived random tests: the batch statement joined the Column Two line on member,
    provider and day but not on its edit file. A physician (type 08) billing the same day on a CMS-1500 (practitioner
    file) and a UB-04 (outpatient file) then had the UB-04 line judged by a practitioner edit."""
    out_rule = ncci_pair("11111", "22222", "0", form="O")            # the outpatient-file twin of the same pair
    # both files in the edit table (as in production), so the UB-04 line is a candidate line for the batch
    cases = {"PRA pair + a UB-04 22222": ([L("A1", 1, "M", "P", D, "11111", form="A"), L("A1", 2, "M", "P", D, "22222", form="A"),
                                           L("O1", 1, "M", "P", D, "22222", form="O")], [("A1", 2)]),
             "OPH pair + a CMS-1500 22222": ([L("O1", 1, "M", "P", D, "11111", form="O"), L("O1", 2, "M", "P", D, "22222", form="O"),
                                              L("A1", 1, "M", "P", D, "22222", form="A")], [("O1", 2)]),
             "codes split across files": ([L("A1", 1, "M", "P", D, "11111", form="A"), L("O1", 1, "M", "P", D, "22222", form="O"),
                                           L("O1", 2, "M", "P", D, "11111", form="O")], [("O1", 1)])}
    for name, (lines, want) in cases.items():
        load(spark, lines)
        write_edits(spark, [HARD, out_rule])
        per = sorted((x["claim_id"], x["line_no"]) for r in (HARD, out_rule) for x in run(spark, compile_one(r)))
        batch = sorted((x["claim_id"], x["line_no"]) for x in run(spark, dg.batch_ptp_sql(build_id="B1")))
        assert per == batch == want, (name, per, batch)


def test_a_predicate_with_both_code_and_code_set_never_compiles():
    d = dg.build_detectors([state({"type": "max_units_per_day", "code": "98961", "code_set": ["98962"], "threshold": 4})])[0]
    assert not d["compiled"] and "both code and code_set" in d["reason"]


def test_ncci_pair_scope_is_always_per_provider():
    r = ncci_pair("11111", "22222", "0")
    r["predicate"]["scope"] = "member_day"
    d = dg.build_detectors([r])[0]
    assert d["pair_scope"] == "member_provider_day" and "a.SProv_ID = b.SProv_ID" in d["sql"]


# ======================================================== AHCCCS rule tables (v5.2, 2026-10-04)
# SB's decisions of 2026-10-04 (contract v5.2): the Same Day Disallow table (D = any provider, A* = the same provider;
# the ROW code's line is the finding, the per-diem COLUMN code's line the evidence; note 2 -> verify_exception), the
# daily limits table (most UNITS per member + provider + date) and the B2 matrix (H0xxx / H2xxx: the BILLING provider
# types allowed) compile as STATE rules with origin "ahcccs_table", run through three batch statements. Each statement
# must give exactly the findings of the per-rule SQL of the same rules (multiset), on every column.
TNOTE2 = "Exceptions to limitations on service frequency or duration may be approved based on medical necessity."
_TSCOPE = {"D": "member_day", "A*": "member_provider_day"}
FCOLS = ("rule_id", "claim_id", "line_no", "member_id", "servicing_provider", "dos", "form_typ", "ncci_edition",
         "paid_amt", "col1_claim_id", "col1_line_no", "pair_scope", "finding", "observed_units", "allowed_units",
         "excess_units", "paid_at_risk", "pa_present", "finding_severity", "finding_basis", "evidence_lines")


def tbl(pred, eff=None, end=None):
    codes = schema.predicate_codes(pred)
    return Rule(origin="ahcccs_table", plane="coding_edit", binding_status="state_policy",
                statement=f"AHCCCS table {pred['type']} {codes} {eff} {end}", source_doc="AHCCCS table",
                source_locator=f"cell {codes}", predicate=pred, codes=codes, effective_date=eff,
                end_date=end).assign_id().to_dict()


def sdd(col, row, ind="D", scope=None, both_ways=False, **kw):
    """A Same Day Disallow cell. scope overrides the indicator's scope (v2.6: A* -> member_servicing_billing_day);
    both_ways=True when the version marks the same two codes in both directions (v2.6, predicate key both_ways)."""
    pred = {"type": "code_pair_prohibited", "code_a": col, "code_b": row, "modifier_indicator": "0",
            "scope": scope or _TSCOPE[ind], "exception": TNOTE2, "service_category": "state_bh"}
    if both_ways:
        pred["both_ways"] = True
    return tbl(pred, **kw)


def dlim(code, n, scope="member_provider_day", **kw):
    return tbl({"type": "max_units_per_day", "code": code, "threshold": n, "scope": scope}, **kw)


def b2(code, types, role="billing", **kw):
    return tbl({"type": "provider_type_allowed", "code_set": [code], "provider_types": sorted(types),
                "provider_role": role}, **kw)


def write_tables(spark, rules, build_id="B1"):
    """The three edit tables as 07 writes them (kb_io.write_table, build_id stamped)."""
    for df, t in zip(dg.ahcccs_edit_tables(rules),
                     (dg.AHCCCS_PAIR_EDITS_TABLE, dg.AHCCCS_DAILY_LIMITS_TABLE, dg.AHCCCS_PTYPE_TABLE)):
        kb_io.write_table(spark, df.assign(build_id=build_id), t, "overwrite")


def per_rule(spark, rules):
    """Per-rule findings with the rule's id attached (08 adds it as a constant)."""
    return [dict(f, rule_id=r["rule_id"]) for r in rules for f in run(spark, compile_one(r))]


def batched(spark, build_id="B1"):
    return [f for k in dg.TABLE_BATCHES for f in run(spark, dg.TABLE_BATCH_SQL[k](build_id=build_id))]


def fkey(f):
    return tuple(f.get(c) for c in FCOLS)


def both_tables(spark, rules, lines):
    load(spark, lines)
    write_tables(spark, rules)
    per, bat = per_rule(spark, rules), batched(spark)
    assert Counter(map(fkey, per)) == Counter(map(fkey, bat)), (sorted(map(fkey, per)), sorted(map(fkey, bat)))
    return per


def test_daily_cap_scope_member_provider_day_vs_member_day(spark):
    """2026-10-04 (v5.2): max_units_per_day scope. member_day (default, every rule before v5.2) adds the member's units
    from ANY provider; member_provider_day adds them per servicing provider and ignores lines with no provider."""
    md = state({"type": "max_units_per_day", "code": "H2014", "threshold": 4})
    md2 = state({"type": "max_units_per_day", "code": "H2014", "threshold": 4, "scope": "member_day"})
    mpd = state({"type": "max_units_per_day", "code": "H2014", "threshold": 4, "scope": "member_provider_day"})
    load(spark, [L("x", 1, "M", "P1", D, "H2014", units=3), L("y", 1, "M", "P2", D, "H2014", units=2),
                 L("z", 1, "M", None, D, "H2014", units=4)])
    for r in (md, md2):
        f = run(spark, compile_one(r))
        assert len(f) == 1 and float(f[0]["observed_units"]) == 9 and "servicing_provider" not in f[0]
        assert f[0]["evidence_lines"] == "x:1,y:1,z:1"
    assert run(spark, compile_one(mpd)) == []                     # 3 from P1, 2 from P2, the no-provider line ignored
    load(spark, [L("x", 1, "M", "P1", D, "H2014", units=3), L("y", 1, "M", "P1", D, "H2014", units=2, pa="PA9"),
                 L("w", 1, "M", "P2", D, "H2014", units=1)])
    f = run(spark, compile_one(mpd))
    assert [(x["servicing_provider"], float(x["observed_units"]), x["evidence_lines"], x["finding_severity"])
            for x in f] == [("P1", 5.0, "x:1,y:1", "verify_pa")]
    assert round(float(f[0]["paid_at_risk"]), 2) == 4.0           # 20 x (5 - 4) / 5


def test_ahcccs_same_day_batch_d_any_provider_a_star_same_provider_windows_exception_and_pa(spark):
    d = sdd("H0017", "H2014", "D", eff="2026-01-02")                # this version: D (any provider) from Jan 2
    a = sdd("H0017", "H2014", "A*", end="2026-01-01")               # the version before it said A* (same provider)
    J1, J2 = "2026-01-01", "2026-01-02"
    lines = [L("a1", 1, "M1", "P1", J1, "H0017"), L("a1", 2, "M1", "P2", J1, "H2014"),     # A*, other provider: no
             L("a2", 1, "M2", "P1", J1, "H0017"), L("a2", 2, "M2", "P1", J1, "H2014"),     # A*, same provider: yes
             L("d3", 1, "M3", "P1", J2, "H0017"), L("d3", 2, "M3", "P2", J2, "H2014"),     # D, other provider: yes
             L("d4", 1, "M4", "P1", J2, "H0017", pa="PA4"), L("d4", 2, "M4", "P1", J2, "H2014"),   # PA on col line
             L("d5", 1, "M5", "P1", J2, "H2014"),                                         # row code alone
             L("d6", 1, "M6", "P1", J2, "H0017", paid=0), L("d6", 2, "M6", "P1", J2, "H2014"),     # col line $0
             L("d7", 1, "M7", "P1", J2, "H0017"), L("d7", 2, "M7", "P1", "2026-01-03", "H2014"),   # next day
             L("d8", 1, "M8", None, J2, "H0017"), L("d8", 2, "M8", None, J2, "H2014", m1="59"),   # no provider; 59
             L("d9", 1, "M9", "P1", J2, "H0017"), L("d9", 2, "M9", "P1", J2, "H2014", paid=0)]    # row line $0
    f = both_tables(spark, [d, a], lines)
    got = sorted((x["member_id"], x["rule_id"] == d["rule_id"], x["finding_severity"], x["pair_scope"],
                  x["evidence_lines"], x["pa_present"]) for x in f)
    assert got == [("M2", False, "verify_exception", "member_provider_day", "a2:1", 0),
                   ("M3", True, "verify_exception", "member_day", "d3:1", 0),
                   ("M4", True, "verify_pa", "member_day", "d4:1", 1),
                   ("M8", True, "verify_exception", "member_day", "d8:1", 0)], got
    assert all(x["finding"] == "H2014 billed with H0017" and x["finding_basis"] == "hard_denial"
               and x["ncci_edition"] is None for x in f)


def test_ahcccs_daily_batch_per_provider_vs_across_providers(spark):
    mpd, md = dlim("H2014", 4), dlim("T1019", 3, scope="member_day")
    lines = [L("m1", 1, "M1", "P1", D, "H2014", units=3), L("m1", 2, "M1", "P2", D, "H2014", units=2),     # no
             L("m2", 1, "M2", "P1", D, "H2014", units=3), L("m2", 2, "M2", "P1", D, "H2014", units=2),     # yes
             L("m3", 1, "M3", "P1", D, "H2014", units=4), L("m3", 2, "M3", "P1", D, "H2014", units=1, paid=0),   # $0
             L("m4", 1, "M4", "P1", D, "H2014", units=4), L("m4", 2, "M4", "P1", D, "H2014", units=2, paid=20),
             L("m4R", 1, "M4", "P1", D, "H2014", units=-2, paid=-20),                                     # reversed
             L("m5", 1, "M5", "P1", D, "T1019", units=2), L("m5", 2, "M5", "P2", D, "T1019", units=2),     # yes (md)
             L("m6", 1, "M6", "P1", D, "T1019", units=4, pa="PA6"),                                       # verify_pa
             L("m7", 1, "M7", None, D, "H2014", units=5),                                                 # no provider
             L("m8", 1, "M8", "P1", D, "T1019", units=2, paid=0), L("m8", 2, "M8", "P1", D, "T1019", units=2, paid=0)]
    f = both_tables(spark, [mpd, md], lines)
    got = sorted((x["member_id"], x.get("servicing_provider"), float(x["observed_units"]), int(x["allowed_units"]),
                  x["finding_severity"]) for x in f)
    assert got == [("M2", "P1", 5.0, 4, "units_over_limit"), ("M5", None, 4.0, 3, "units_over_limit"),
                   ("M6", None, 4.0, 3, "verify_pa")], got


def test_ahcccs_provider_type_batch_allowed_not_allowed_missing_and_role(spark):
    bill, serv = b2("H0017", ["B2", "77"]), b2("H2014", ["02"], role="servicing")
    lines = [L("zz", 1, "M1", "P", D, "H0017", btype="ZZ"),                      # not in the list: finding
             L("lc", 1, "M2", "P", D, "H0017", btype=" b2 "),                    # B2, padded / lower case
             L("nul", 1, "M3", "P", D, "H0017", btype=None),                     # unknown is not a violation
             L("txt", 1, "M4", "P", D, "H0017", btype=" none "),                 # textual null = missing
             L("zero", 1, "M5", "P", D, "H0017", btype="ZZ", paid=0),            # $0 line
             L("oth", 1, "M6", "P", D, "H0017", ptype="ZZ", btype="77"),         # only the BILLING type counts
             L("pa", 1, "M7", "P", D, "H0017", btype="05", pa="PA7"),            # verify_pa
             L("s08", 1, "M8", "P", D, "H2014", ptype="08", btype="02"),         # servicing role: 08 not allowed
             L("s2", 1, "M9", "P", D, "H2014", ptype=" 2", btype="ZZ")]          # servicing 02: fine
    f = both_tables(spark, [bill, serv], lines)
    got = sorted((x["claim_id"], x["finding"], x["finding_severity"]) for x in f)
    assert got == [("pa", "H0017 billed by provider type 05 (allowed: 77/B2)", "verify_pa"),
                   ("s08", "H2014 billed by provider type 08 (allowed: 02)", "provider_type_not_allowed"),
                   ("zz", "H0017 billed by provider type ZZ (allowed: 77/B2)", "provider_type_not_allowed")], got


def test_ahcccs_batches_read_only_their_build_and_run_on_empty_edit_tables(spark):
    rules = [sdd("H0017", "H2014"), dlim("H2014", 1), b2("H0017", ["B2"])]
    load(spark, [L("c", 1, "M", "P", D, "H0017", btype="ZZ"), L("c", 2, "M", "P", D, "H2014", units=3)])
    write_tables(spark, rules)
    assert len(batched(spark)) == 3
    assert batched(spark, build_id="OTHER") == []                # C4-01: a statement reads only its build's rows
    write_tables(spark, [])                                      # a build with no table loaded: empty tables
    assert batched(spark) == []


def _random_table_claims(rnd, n=220):
    codes = ["H0017", "S5151", "H2014", "T1019", "H0004", "H0005", "99213"]
    types = ["B2", "77", "02", "B5", " 2", "b5", None, "ZZ", "NONE", "08"]
    lines = []
    for i in range(n):
        dos = date(2026, 1, 1) + timedelta(days=rnd.randint(0, 3))
        mem, prov, code = f"M{rnd.randint(0, 5)}", rnd.choice(["P0", "P1", "P2", "P1", None]), rnd.choice(codes)
        units, paid, m1 = rnd.choice([1, 2, 3, 0.5, 4]), rnd.choice([10, 25, 0, 40]), rnd.choice([None, None, "59", "XU", "LT"])
        lines.append(L(f"c{rnd.randint(0, 50)}", rnd.choice([1, 2, 3, 4, None]), mem, prov, dos, code, units=units,
                       paid=paid, m1=m1, pa=rnd.choice([None, None, None, "PA1", "  "]), form=rnd.choice(["A", "A", "O", "D"]),
                       ptype=rnd.choice(types), btype=rnd.choice(types)))
        if paid and rnd.random() < 0.15:          # an exact reversal (cancels the line) or a partial recoupment
            exact = rnd.random() < 0.7
            lines.append(L(f"r{i}", 1, mem, prov, dos, code, units=-units, paid=-paid if exact else -5, m1=m1))
    return lines


TABLE_RULES = [
    sdd("H0017", "H2014", "D", eff="2026-01-02"), sdd("H0017", "H2014", "A*", end="2026-01-01"),
    sdd("S5151", "T1019", "A*"), sdd("S5151", "H0004", "D", end="2026-01-03"), sdd("H0017", "H0005", "D"),
    tbl({"type": "code_pair_prohibited", "code_a": "S5151", "code_b": "H2014", "modifier_indicator": "1",
         "scope": "member_provider_day", "discretionary": True}),
    tbl({"type": "code_pair_prohibited", "code_a": "T1019", "code_b": "H0017", "modifier_indicator": "0",
         "scope": "member_day"}),
    dlim("H2014", 4), dlim("T1019", 3, scope="member_day", eff="2026-01-02"), dlim("T1019", 2, scope="member_day",
                                                                                  end="2026-01-01"),
    tbl({"type": "max_units_per_day", "code_set": ["H0004", "H0005", "H0004"], "threshold": 5,
         "scope": "member_provider_day", "exception": TNOTE2}),
    tbl({"type": "max_units_per_day", "code": "S5151", "threshold": 1}),
    b2("H0017", ["B2", "77"]), b2("H2014", ["02", "B5"], role="servicing", eff="2026-01-02"),
    tbl({"type": "provider_type_allowed", "code_set": ["H0004", "H0005"], "provider_types": ["B5"],
         "provider_role": "billing", "exception": TNOTE2}),
]


def test_ahcccs_batches_equal_per_rule_multiset_on_random_claims(spark):
    """The three statements == the per-rule SQL of the same 15 rules, as multisets of findings on EVERY output column
    (rule, line, member, provider, date, dollars, paid_at_risk, units, scope, severity, PA, evidence), on 6 random
    adversarial claim sets: padded / lower-case provider types, textual nulls, missing providers and line numbers,
    $0 lines, exact reversals and partial recoupments, PA numbers and blanks, modifiers, forms, two versions of one pair
    with different scopes, a code set with a repeated code, both provider roles."""
    assert all(dg.table_batch_kind(r) for r in TABLE_RULES)
    seen, total = Counter(), 0
    for seed in range(1, 7):
        rnd = random.Random(seed)
        load(spark, _random_table_claims(rnd))
        write_tables(spark, TABLE_RULES)
        per, bat = per_rule(spark, TABLE_RULES), batched(spark)
        assert Counter(map(fkey, per)) == Counter(map(fkey, bat)), seed
        for r in TABLE_RULES:                                    # every column the per-rule SQL has is in the batch
            cols = set(spark.sql(compile_one(r)).columns)
            assert cols <= set(spark.sql(dg.TABLE_BATCH_SQL[dg.table_batch_kind(r)](build_id="B1")).columns), r
        total += len(per)
        seen.update((dg.table_batch_kind(next(r for r in TABLE_RULES if r["rule_id"] == f["rule_id"])),
                     f["finding_severity"]) for f in per)
        seen.update(("scope", f.get("pair_scope") or ("provider" if f.get("servicing_provider") else "member"))
                    for f in per if f.get("claim_id") is None or f.get("pair_scope"))
    print(f"AHCCCS batch == per-rule: 6 seeds, {total} findings, {dict(seen)}")
    # v2.6 (B3): these claims' daily groups now end as verify_span (one line alone over the cap) or verify_modifier (59 /
    # XU / LT are on the list) - never the plain base label; units_over_limit is required by the v2.6 random test below
    for k, sev in (("ahcccs_same_day", "verify_exception"), ("ahcccs_same_day", "verify_pa"),
                   ("ahcccs_same_day", "discretionary"), ("ahcccs_same_day", "hard_denial"),
                   ("ahcccs_daily_max", "verify_span"), ("ahcccs_daily_max", "verify_modifier"),
                   ("ahcccs_daily_max", "verify_pa"),
                   ("ahcccs_daily_max", "verify_exception"), ("ahcccs_provider_type", "provider_type_not_allowed"),
                   ("ahcccs_provider_type", "verify_pa"), ("ahcccs_provider_type", "verify_exception"),
                   ("scope", "member_day"), ("scope", "member_provider_day"), ("scope", "provider"),
                   ("scope", "member")):
        assert seen[(k, sev)] > 0, (k, sev, dict(seen))


def test_query_pack_table_batch_scenarios_all_pass(spark, monkeypatch):
    """v06 on the three table statements: every sampled rule's must / must-NOT scenarios (D any provider, A* same vs
    other provider, note-2 exception and PA labels, both ends of a version window, daily sums per provider vs across
    providers, $0 line, provider type allowed / not / missing) through the STORED batch SQL."""
    import query_pack as qp
    monkeypatch.setattr(qp, "SCRATCH_SCHEMA", "spark_catalog.policy_kb")
    sample = [sdd("H0017", "H2014", "D", eff="2026-10-01"), sdd("S5151", "T1019", "A*", eff="2025-10-01",
                                                                   end="2026-09-30"),
              dlim("H2014", 4, eff="2025-09-14"), dlim("T1019", 3, scope="member_day"),
              tbl({"type": "max_units_per_day", "code_set": ["H0004", "H0005"], "threshold": 5,
                   "scope": "member_provider_day", "exception": TNOTE2}),
              b2("H0017", ["B2", "77"], eff="2026-10-01"), b2("H2014", ["02"], role="servicing")]
    rows = [{"batch": k, "sql": dg.TABLE_BATCH_SQL[k](build_id="BX"), "sql_sha256": "h"} for k in dg.TABLE_BATCHES]
    q, s = qp.build_pack(spark, [], [], rows, fmt="parquet", build_id="BX", table_sample=sample)
    bad = s[~s["pass"]]
    assert bad.empty, bad[["query_id", "scenario", "description", "result"]].to_string()
    assert set(q["query_id"]) == {f"BATCH:{k}" for k in dg.TABLE_BATCHES} and set(q["auto_test"]) == {"PASS"}
    assert (s.groupby("rule_id")["expected_findings"].max() >= 1).all()          # every rule has a must-flag case
    assert {"F2", "N4", "N6", "N7", "W1", "W2", "F4", "F7"} <= set(s["scenario"])


# ======================================================== v2.6 (2026-10-04, after the independent critic of v5.2)
# QUERY_SEMANTICS v2.6: scope member_servicing_billing_day (B1), provider role billing_or_rendering (B2), the daily-cap
# labels verify_span / verify_modifier (B3), pairs disallowed both ways (B4). Every case runs the per-rule SQL AND the
# table batch statement (both_tables: multiset-equal on every column) and pins the expected findings.
MSBD = "member_servicing_billing_day"


def test_v26_b1_pair_same_servicing_and_billing_provider(spark):
    """A* read as the same servicing AND the same billing provider id: a missing id of either never matches."""
    r = sdd("H0017", "H2014", "A*", scope=MSBD)
    lines = [L("s1", 1, "M1", "P1", D, "H0017", bprov="B1"), L("s1", 2, "M1", "P1", D, "H2014", bprov="B1"),   # yes
             L("s2", 1, "M2", "P1", D, "H0017", bprov="B1"), L("s2", 2, "M2", "P1", D, "H2014", bprov="B2"),   # billing
             L("s3", 1, "M3", "P1", D, "H0017", bprov=None), L("s3", 2, "M3", "P1", D, "H2014", bprov=None),   # no id
             L("s4", 1, "M4", None, D, "H0017", bprov="B1"), L("s4", 2, "M4", None, D, "H2014", bprov="B1"),   # no id
             L("s5", 1, "M5", "P1", D, "H0017", bprov="B1"), L("s5", 2, "M5", "P2", D, "H2014", bprov="B1"),   # servicing
             L("s6", 1, "M6", "P1", D, "H0017", bprov="B1"), L("s6", 2, "M6", "P1", D, "H0017", bprov="B2"),
             L("s6", 3, "M6", "P1", D, "H2014", bprov=" B2 ")]                     # evidence: only the B2 line (trimmed)
    f = both_tables(spark, [r], lines)
    got = sorted((x["member_id"], x["claim_id"], x["line_no"], x["evidence_lines"], x["pair_scope"]) for x in f)
    assert got == [("M1", "s1", 2, "s1:1", MSBD), ("M6", "s6", 3, "s6:2", MSBD)], got


def test_v26_b1_daily_cap_per_member_servicing_billing_and_day(spark):
    cap = dlim("H2014", 4, scope=MSBD)
    lines = [L("d1", 1, "M1", "P1", D, "H2014", units=3, bprov="B1"), L("d1", 2, "M1", "P1", D, "H2014", units=2, bprov="B1"),
             L("d2", 1, "M2", "P1", D, "H2014", units=3, bprov="B1"), L("d2", 2, "M2", "P1", D, "H2014", units=2, bprov="B2"),
             L("d3", 1, "M3", "P1", D, "H2014", units=3, bprov=None), L("d3", 2, "M3", "P1", D, "H2014", units=2, bprov=None),
             L("d4", 1, "M4", None, D, "H2014", units=3, bprov="B1"), L("d4", 2, "M4", None, D, "H2014", units=2, bprov="B1"),
             L("d5", 1, "M5", "P1", D, "H2014", units=3, bprov="B1"), L("d5", 2, "M5", "P2", D, "H2014", units=2, bprov="B1"),
             L("d6", 1, "M6", "P1", D, "H2014", units=2, bprov="B1"), L("d6", 2, "M6", "P1", D, "H2014", units=3, bprov="B1"),
             L("d6", 3, "M6", "P1", D, "H2014", units=4, bprov=None)]                    # not counted: no billing id
    f = both_tables(spark, [cap], lines)
    got = sorted((x["member_id"], x["servicing_provider"], float(x["observed_units"]), x["evidence_lines"]) for x in f)
    assert got == [("M1", "P1", 5.0, "d1:1,d1:2"), ("M6", "P1", 5.0, "d6:1,d6:2")], got


def test_v26_b2_billing_or_rendering_group_lines_judged_on_the_rendering_type(spark):
    """B2 matrix, provider_role billing_or_rendering: a group (billing type 01, however the claims spell it) is judged on
    the rendering (servicing) type; every other biller on its own type; a missing judged type is never a finding."""
    r = b2("H0004", ["03", "77"], role="billing_or_rendering")
    billing = b2("H0005", ["03"], role="billing")                        # the billing role is unchanged on a group line
    lines = [L("g_ok", 1, "M1", "P", D, "H0004", btype="01", ptype="03"),          # group, rendering allowed: none
             L("g_sp", 1, "M2", "P", D, "H0004", btype=" 1 ", ptype="77"),         # '1' is 01: none
             L("g_bad", 1, "M3", "P", D, "H0004", btype="01", ptype="05"),         # group, rendering not allowed
             L("g_bad2", 1, "M4", "P", D, "H0004", btype=" 01 ", ptype="zz"),      # ' 01 ' is 01, 'zz' is ZZ
             L("g_nul", 1, "M5", "P", D, "H0004", btype="01", ptype=None),         # rendering type missing: none
             L("g_txt", 1, "M6", "P", D, "H0004", btype="1", ptype=" none "),      # textual null: missing
             L("b_bad", 1, "M7", "P", D, "H0004", btype="05", ptype="03"),         # a non-group biller: its own type
             L("b_ok", 1, "M8", "P", D, "H0004", btype="77", ptype="05"),          # allowed biller: none
             L("b_nul", 1, "M9", "P", D, "H0004", btype=None, ptype="05"),         # billing type missing: none
             L("g_pa", 1, "M10", "P", D, "H0004", btype="01", ptype="05", pa="PA1"),
             L("h5", 1, "M11", "P", D, "H0005", btype="01", ptype="03")]           # role billing: 01 is judged
    f = both_tables(spark, [r, billing], lines)
    got = sorted((x["claim_id"], x["finding"], x["finding_severity"]) for x in f)
    assert got == [("b_bad", "H0004 billed by provider type 05 (allowed: 03/77)", "provider_type_not_allowed"),
                   ("g_bad", "H0004 rendered by provider type 05 for a group (01) (allowed: 03/77)",
                    "provider_type_not_allowed"),
                   ("g_bad2", "H0004 rendered by provider type ZZ for a group (01) (allowed: 03/77)",
                    "provider_type_not_allowed"),
                   ("g_pa", "H0004 rendered by provider type 05 for a group (01) (allowed: 03/77)", "verify_pa"),
                   ("h5", "H0005 billed by provider type 01 (allowed: 03)", "provider_type_not_allowed")], got


def _cap_cases(code, prov="P"):
    """(member suffix, lines, label) for a daily cap of 4 units: one line over the cap vs several lines over it, the
    modifiers of config.DAILY_CAP_VERIFY_MODIFIERS on each of the four columns (lower case / padded), PA first."""
    m = lambda s: f"{code}_{s}"
    return [("one", [L(m("one"), 1, m("one"), prov, D, code, units=5)], "verify_span"),
            ("two", [L(m("two"), 1, m("two"), prov, D, code, units=3), L(m("two"), 2, m("two"), prov, D, code, units=2)],
             None),                                                             # several lines, none over alone
            ("eq", [L(m("eq"), 1, m("eq"), prov, D, code, units=4), L(m("eq"), 2, m("eq"), prov, D, code, units=1)],
             None),                                                             # a line AT the cap is not over it
            ("big2", [L(m("big2"), 1, m("big2"), prov, D, code, units=5), L(m("big2"), 2, m("big2"), prov, D, code, units=6)],
             "verify_span"),                                                     # several lines each over it
            ("rtlt", [L(m("rtlt"), 1, m("rtlt"), prov, D, code, units=3, m1="RT"),
                      L(m("rtlt"), 2, m("rtlt"), prov, D, code, units=2, m4=" lt ")], "verify_modifier"),
            ("m50", [L(m("m50"), 1, m("m50"), prov, D, code, units=3, m2="50"),
                     L(m("m50"), 2, m("m50"), prov, D, code, units=2)], "verify_modifier"),
            ("m59", [L(m("m59"), 1, m("m59"), prov, D, code, units=3, m3="xu"),
                     L(m("m59"), 2, m("m59"), prov, D, code, units=2)], "verify_modifier"),
            ("sprt", [L(m("sprt"), 1, m("sprt"), prov, D, code, units=5, m1="RT")], "verify_span"),     # span first
            ("pasp", [L(m("pasp"), 1, m("pasp"), prov, D, code, units=5, pa="PA1", m1="RT")], "verify_pa"),
            ("gt", [L(m("gt"), 1, m("gt"), prov, D, code, units=3, m1="GT"),
                    L(m("gt"), 2, m("gt"), prov, D, code, units=2)], None),            # GT is not in the list
            ("zrt", [L(m("zrt"), 1, m("zrt"), prov, D, code, units=3), L(m("zrt"), 2, m("zrt"), prov, D, code, units=2),
                     L(m("zrt"), 3, m("zrt"), prov, D, code, units=1, paid=0, m1="RT")], None)]   # $0 line not counted


def test_v26_b3_daily_cap_labels_verify_span_and_verify_modifier(spark):
    """Spec §3 (v2.6): daily caps of state rules (every origin; max_units_per_day and max_units_per_dos; per-rule SQL and
    the AHCCCS daily batch): verify_pa > verify_span > verify_modifier > the rule's qualified label."""
    day = state({"type": "max_units_per_day", "code": "H2014", "threshold": 4}, origin="extracted")
    exc = state({"type": "max_units_per_day", "code": "H2015", "threshold": 4, "exception": "unless x"},
                origin="extracted")
    dos = state({"type": "max_units_per_dos", "code": "97110", "threshold": 4}, origin="manual")
    table = dlim("H2016", 4, scope=MSBD)
    cases = {(r["rule_id"], f"{c}_{s}"): (lab or base) for r, c, base in
             ((day, "H2014", "units_over_limit"), (exc, "H2015", "verify_exception"), (dos, "97110", "units_over_limit"),
              (table, "H2016", "units_over_limit")) for s, _, lab in _cap_cases(c)}
    lines = [ln for c in ("H2014", "H2015", "97110", "H2016") for _, ls, _ in _cap_cases(c) for ln in ls]
    both_tables(spark, [table], lines)                       # the batch == the per-rule SQL of the table rule
    got = {(r["rule_id"], f["member_id"]): f["finding_severity"]
           for r in (day, exc, dos, table) for f in run(spark, compile_one(r))}
    assert got == cases, sorted(set(got.items()) ^ set(cases.items()))
    # a finding keeps its basis; pa_present says whether a PA is on file
    f = {x["member_id"]: x for x in run(spark, compile_one(day))}
    assert {x["finding_basis"] for x in f.values()} == {"units_over_limit"} and f["H2014_pasp"]["pa_present"] == 1


def test_v26_daily_cap_labels_read_payable_lines_only(spark):
    """Critic re-check N4 (2026-10-05): a 30-unit line a reversal cancels nets out of the day's sum - it must not make
    the day look like one long line (verify_span), nor lend it a modifier (verify_modifier). Two payable 12-unit lines
    over a cap of 20 are units_over_limit, per rule and in the AHCCCS daily batch; with the payable 30-unit line kept
    (no reversal) the same day IS verify_span."""
    day = state({"type": "max_units_per_day", "code": "H2014", "threshold": 20}, origin="extracted")
    table = dlim("H2016", 20, scope=MSBD)
    lines = []
    for code, m in (("H2014", "M1"), ("H2016", "M2")):
        lines += [L(f"{m}x", 1, m, "P1", D, code, units=30, paid=300, m1="RT"),        # cancelled by the reversal below
                  L(f"{m}r", 1, m, "P1", D, code, units=-30, paid=-300, m1="RT"),
                  L(f"{m}a", 1, m, "P1", D, code, units=12, paid=120),
                  L(f"{m}b", 1, m, "P1", D, code, units=12, paid=120)]
        lines += [L(f"{m}k", 1, m + "k", "P1", D, code, units=30, paid=300),             # kept: one line over the cap
                  L(f"{m}l", 1, m + "k", "P1", D, code, units=1, paid=10)]
    both_tables(spark, [table], lines)                       # the batch == the per-rule SQL of the table rule
    got = {(f["member_id"], f["finding_severity"]) for r in (day, table) for f in run(spark, compile_one(r))}
    assert got == {("M1", "units_over_limit"), ("M2", "units_over_limit"),
                   ("M1k", "verify_span"), ("M2k", "verify_span")}, sorted(got)


def test_v26_misses_of_the_table_readings_are_counted_in_01_and_08(spark):
    """Critic re-check N2 (2026-10-05): member_servicing_billing_day never pairs / counts a line with no billing provider
    id, and billing_or_rendering never judges a group's line with no rendering type - misses, never findings. 01's data
    shape (on the claims table) and 08's snapshot numbers (on payable lines, in the run log) count both."""
    import preflight_sql as pq
    lines = [L("c1", 1, "M1", "P1", D, "H2014"),                                   # ordinary
             L("c2", 1, "M2", "P1", D, "H2014", bprov=None),                       # no billing id
             L("c3", 1, "M3", "P2", D, "H0004", ptype=None, btype=" 1 "),           # group, no rendering type
             L("c4", 1, "M4", "P2", D, "H0004", ptype="85", btype="01"),            # group with a rendering type
             L("c5", 1, "M5", "P3", D, "H2014", bprov=None, paid=0)]               # no billing id, not payable
    load(spark, lines)
    shape = spark.sql(pq.sql_data_shape(dg.CLAIMS, config.CLAIM_COLS)).collect()[0].asDict()
    assert (shape["bprov_missing"], shape["group_billed_no_rendering_type"]) == (2, 1), shape
    snap = spark.sql(dg.snapshot_stats_sql()).collect()[0].asDict()
    assert (snap["payable_lines_no_billing_id"], snap["payable_group_lines_no_rendering_type"]) == (1, 1), snap


def test_v26_b4_pair_disallowed_both_ways_flags_both_lines_with_the_text(spark):
    """Both directions of a both-ways pair flag their own row line (both lines of the member's day) with the both-ways
    text, per rule and in the batch; the edit table carries both_ways (C7 counts those dollars once)."""
    fwd, rev = sdd("H0017", "H2014", "D", both_ways=True), sdd("H2014", "H0017", "D", both_ways=True)
    one = sdd("S5151", "T1019", "D")
    lines = [L("b1", 1, "M1", "P1", D, "H0017", paid=40), L("b1", 2, "M1", "P2", D, "H2014", paid=25),
             L("o1", 1, "M2", "P1", D, "S5151"), L("o1", 2, "M2", "P1", D, "T1019")]
    f = both_tables(spark, [fwd, rev, one], lines)
    note = " (pair disallowed both ways: AHCCCS would deny one of the two lines)"
    got = sorted((x["claim_id"], x["line_no"], x["finding"], x["evidence_lines"], float(x["paid_at_risk"])) for x in f)
    assert got == [("b1", 1, "H0017 billed with H2014" + note, "b1:2", 40.0),
                   ("b1", 2, "H2014 billed with H0017" + note, "b1:1", 25.0),
                   ("o1", 2, "T1019 billed with S5151", "o1:1", 10.0)], got
    e = spark.table(dg.AHCCCS_PAIR_EDITS_TABLE).toPandas()
    assert dict(zip(e["rule_id"], e["both_ways"])) == {fwd["rule_id"]: True, rev["rule_id"]: True, one["rule_id"]: False}


def test_v26_b5_query_pack_scenarios_all_pass_through_the_stored_sql(spark, monkeypatch):
    """v06 on the v2.6 cases, through the STORED SQL: group billing (01 + allowed rendering type -> none, 01 + other
    rendering type -> finding naming it, 01 + no rendering type -> none, a non-group biller on its own type), the new
    scope (same servicing + other billing -> no finding, both the same -> finding), a pair disallowed both ways (both
    lines flagged, the text), verify_span (one line over the cap) and verify_modifier (RT + LT lines), daily per
    servicing + billing provider; and a state daily cap's per-rule SQL."""
    import query_pack as qp
    monkeypatch.setattr(qp, "SCRATCH_SCHEMA", "spark_catalog.policy_kb")
    fwd = sdd("H0017", "H2014", "A*", scope=MSBD, both_ways=True, eff="2026-10-01")
    rev = sdd("H2014", "H0017", "D", both_ways=True, eff="2026-10-01")
    sample = [fwd, rev, sdd("S5151", "T1019", "A*", scope=MSBD),
              dlim("H2014", 4, scope=MSBD, eff="2025-09-14"),
              tbl({"type": "max_units_per_day", "code_set": ["H0004", "H0005"], "threshold": 5, "scope": MSBD,
                   "exception": TNOTE2}),
              b2("H0004", ["03", "77"], role="billing_or_rendering"), b2("H0017", ["B2", "77"])]
    assert qp.sample_tables(sample, 9, 9, 9) and all(dg.table_batch_kind(r) for r in sample)
    rows = [{"batch": k, "sql": dg.TABLE_BATCH_SQL[k](build_id="BX"), "sql_sha256": "h"} for k in dg.TABLE_BATCHES]
    cap = state({"type": "max_units_per_day", "code": "A0422", "threshold": 1}, origin="extracted")
    cap["reviewer"] = "SS"
    dets = dg.build_detectors([cap])
    q, s = qp.build_pack(spark, [cap], dets, rows, fmt="parquet", build_id="BX", table_sample=sample)
    bad = s[~s["pass"]]
    assert bad.empty, bad[["query_id", "scenario", "description", "result"]].to_string()
    assert set(q["auto_test"]) == {"PASS"} and len(q) == 4
    want = {"BW", "N9", "N10", "N8", "S1", "S2", "G1", "G2", "G3", "F1", "N5"}
    assert want <= set(s["scenario"]), want - set(s["scenario"])
    assert (s[s["scenario"] == "BW"]["expected_findings"] == 2).all()
    assert set(s[s["query_id"] == cap["rule_id"]]["scenario"]) >= {"S1", "S2", "F1", "F2"}


def _random_v26_claims(rnd, n=240):
    """Random claims for the v2.6 cases: billing provider ids that differ from the servicing id or are missing (and
    missing servicing ids), group billing types spelled '01' / '1' / ' 01 ' / '1.0', rendering types incl. textual
    nulls, modifiers of the daily-cap list (and others) on ANY of the four columns, lower case / padded, units that put
    ONE line over a cap or several lines over it together, $0 lines, PA numbers and blanks, exact reversals and partial
    recoupments."""
    codes = ["H0017", "S5151", "H2014", "T1019", "H0004", "H0005", "99213"]
    btypes = ["01", "1", " 01 ", "1.0", "03", "77", "B5", None, "ZZ", "02", " b5 "]
    stypes = ["03", "77", "05", None, " none ", "B5", "zz", "02", "B2"]
    mods = [None] * 6 + ["RT", "lt", " 50 ", "59", "xu", "GT", "25", "76", "e1"]
    lines = []
    for i in range(n):
        dos = date(2026, 1, 1) + timedelta(days=rnd.randint(0, 2))
        mem, prov, code = f"M{rnd.randint(0, 3)}", rnd.choice(["P0", "P1", "P1", None]), rnd.choice(codes)
        bprov = rnd.choice([_SAME, _SAME, _SAME, _SAME, "B1", None])
        units, paid = rnd.choice([1, 2, 3, 0.5, 4, 5, 1, 2]), rnd.choice([10, 25, 0, 40])
        m = [rnd.choice(mods) for _ in range(4)] if rnd.random() < 0.35 else [None] * 4
        lines.append(L(f"c{rnd.randint(0, 50)}", rnd.choice([1, 2, 3, 4, None]), mem, prov, dos, code, units=units,
                       paid=paid, m1=m[0], m2=m[1], m3=m[2], m4=m[3], pa=rnd.choice([None] * 4 + ["PA1", "  "]),
                       form=rnd.choice(["A", "A", "O", "D"]), ptype=rnd.choice(stypes), btype=rnd.choice(btypes),
                       bprov=bprov))
        if paid and rnd.random() < 0.12:          # an exact reversal (cancels the line) or a partial recoupment
            exact = rnd.random() < 0.7
            lines.append(L(f"r{i}", 1, mem, prov, dos, code, units=-units, paid=-paid if exact else -5, m1=m[0], m2=m[1],
                           m3=m[2], m4=m[3], bprov=bprov))
    # groups every seed has, so each daily-cap label is reached (a random member-day holds ~20 lines: almost always one
    # line over the cap, a listed modifier or a PA): several lines over a cap together, no modifier / PA -> the base
    # label; the same under an exception -> verify_exception
    x = f"FX{rnd.randint(0, 999)}"
    lines += [L(f"{x}a", 1, x, "P1", D, "H2014", units=3, bprov="B1"), L(f"{x}a", 2, x, "P1", D, "H2014", units=2, bprov="B1"),
              L(f"{x}b", 1, x, "P1", D, "H0004", units=2), L(f"{x}b", 2, x, "P2", D, "H0005", units=2),
              L(f"{x}c", 1, x, "P2", D, "99213", units=2, m2="GT"), L(f"{x}c", 2, x, "P1", D, "99213", units=1)]
    return lines


TABLE_RULES_V26 = [
    # pairs: the new scope, both ways (mixed scopes), two versions of one pair, indicator 1, the v5.2 scopes
    sdd("H0017", "H2014", "A*", scope=MSBD, both_ways=True), sdd("H2014", "H0017", "D", both_ways=True),
    sdd("S5151", "T1019", "A*", scope=MSBD, end="2026-01-02"), sdd("S5151", "T1019", "D", eff="2026-01-03"),
    tbl({"type": "code_pair_prohibited", "code_a": "S5151", "code_b": "H0004", "modifier_indicator": "1",
         "scope": MSBD, "discretionary": True}),
    tbl({"type": "code_pair_prohibited", "code_a": "H2014", "code_b": "H0005", "modifier_indicator": "1",
         "scope": "member_day", "discretionary": True}),
    sdd("H0017", "H0005", "A*"), sdd("T1019", "H0004", "D"),
    # daily caps: the new scope, member_day, member_provider_day, a code set, an exception, a cap of 1
    dlim("H2014", 4, scope=MSBD), dlim("T1019", 3, scope=MSBD, eff="2026-01-02"),
    dlim("T1019", 2, scope="member_day", end="2026-01-01"), dlim("H0017", 2, scope="member_provider_day"),
    tbl({"type": "max_units_per_day", "code_set": ["H0004", "H0005", "H0004"], "threshold": 3, "scope": "member_day",
         "exception": TNOTE2}),
    dlim("S5151", 1, scope=MSBD), dlim("99213", 2, scope="member_day"),
    # provider types: billing_or_rendering (group lines on the rendering type), servicing, billing, an exception
    b2("H0004", ["03", "77"], role="billing_or_rendering"), b2("H0005", ["B5"], role="billing_or_rendering",
                                                               eff="2026-01-02"),
    b2("H2014", ["02", "B5"], role="servicing"), b2("H0017", ["B2", "77"]),
    tbl({"type": "provider_type_allowed", "code_set": ["S5151", "T1019"], "provider_types": ["03", "B5"],
         "provider_role": "billing_or_rendering", "exception": TNOTE2}),
]


@pytest.mark.parametrize("seeds", [(11, 12), (13, 14)])
def test_v26_batches_equal_per_rule_multiset_on_random_claims(spark, seeds):
    """B6: the three statements == the per-rule SQL of the same rules, as multisets on EVERY output column (incl. the
    finding text, servicing provider, labels, evidence, dollars), for the new scope, the new provider role, the
    daily-cap labels and pairs disallowed both ways - on random claims full of the v2.6 hard cases."""
    assert all(dg.table_batch_kind(r) for r in TABLE_RULES_V26)
    seen = Counter()
    for seed in seeds:
        load(spark, _random_v26_claims(random.Random(seed)))
        write_tables(spark, TABLE_RULES_V26)
        per, bat = per_rule(spark, TABLE_RULES_V26), batched(spark)
        assert Counter(map(fkey, per)) == Counter(map(fkey, bat)), seed
        assert len(per) > 0
        for r in TABLE_RULES_V26:
            assert set(spark.sql(compile_one(r)).columns) <= \
                set(spark.sql(dg.TABLE_BATCH_SQL[dg.table_batch_kind(r)](build_id="B1")).columns), r
        kind = {r["rule_id"]: dg.table_batch_kind(r) for r in TABLE_RULES_V26}
        scope = {r["rule_id"]: (r["predicate"].get("scope") or r["predicate"].get("provider_role")) for r in TABLE_RULES_V26}
        for f in per:
            seen[(kind[f["rule_id"]], f["finding_severity"])] += 1
            seen[("scope", scope[f["rule_id"]])] += 1
            seen[("text", "both ways" if "both ways" in f["finding"] else "rendered" if "rendered by" in f["finding"]
                  else "billed by" if "billed by" in f["finding"] else "other")] += 1
    print(f"v2.6 batch == per-rule: seeds {seeds}, {dict(seen)}")
    need = [("ahcccs_same_day", "verify_exception"), ("ahcccs_same_day", "verify_pa"),
            ("ahcccs_same_day", "discretionary"), ("ahcccs_daily_max", "units_over_limit"),
            ("ahcccs_daily_max", "verify_span"), ("ahcccs_daily_max", "verify_modifier"),
            ("ahcccs_daily_max", "verify_pa"), ("ahcccs_daily_max", "verify_exception"),
            ("ahcccs_provider_type", "provider_type_not_allowed"), ("ahcccs_provider_type", "verify_pa"),
            ("ahcccs_provider_type", "verify_exception"), ("scope", MSBD), ("scope", "member_day"),
            ("scope", "member_provider_day"), ("scope", "billing_or_rendering"), ("text", "both ways"),
            ("text", "rendered"), ("text", "billed by")]
    assert all(seen[k] > 0 for k in need), [k for k in need if not seen[k]]


def test_v26_b2_exposure_in_01_before_signing(spark):
    """Critic F1 follow-up (2026-10-05): 01 check T shows what B2 would flag in the claims before the reading is signed -
    per code and the type its role judges (billing_or_rendering: a group's line on its rendering type)."""
    import pandas as pd
    import ahcccs_tables as at
    cols = at.TABLE_COLUMNS["b2_matrix"]
    rows = []
    for code, pt in (("H0004", "85"), ("H0004", "77"), ("90791", "08")):               # 90791: recorded, not compiled
        r = {c: None for c in cols}
        r.update(version_date="2026-10-01", file_sha256="a" * 64, file_name="b2.xlsx", sheet="s", code=code,
                 provider_type=pt, source_row=11)
        rows.append(r)
    lines = [L("e1", 1, "M1", "P1", D, "H0004", btype="77", paid=100),               # clinic 77: allowed
             L("e2", 1, "M2", "P2", D, "H0004", ptype="85", btype="01", paid=50),     # group, rendering 85: allowed
             L("e3", 1, "M3", "P3", D, "H0004", ptype="03", btype=" 1 ", paid=40),    # group, rendering 03: flagged
             L("e4", 1, "M4", "P4", D, "H0004", ptype="05", btype="05", paid=30),     # clinic 05: flagged
             L("e5", 1, "M5", "P5", D, "H0004", ptype=None, btype="01", paid=20),     # group, no rendering type
             L("e6", 1, "M6", "P6", D, "90791", btype="05", paid=99),                 # not a compiled code
             L("e7", 1, "M7", "P7", D, "H0004", btype="05", paid=0)]                  # not paid
    load(spark, lines)
    ex = spark.sql(at.b2_exposure_sql(dg.CLAIMS, config.CLAIM_COLS, pd.DataFrame(rows))).toPandas()
    got = {(r.judged_type if isinstance(r.judged_type, str) else None, r.status): (int(r.lines), float(r.paid))
           for r in ex.itertuples()}
    assert got == {("77", "allowed"): (1, 100.0), ("85", "allowed"): (1, 50.0), ("03", "flagged"): (1, 40.0),
                   ("05", "flagged"): (1, 30.0), (None, "no_type"): (1, 20.0)}, got
