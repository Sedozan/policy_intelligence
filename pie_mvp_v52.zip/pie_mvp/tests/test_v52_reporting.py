"""v5.2b (2026-10-04, independent critic of the AHCCCS rule tables) - Role C: build / run / reporting.

  C1 (F7)  07 step 3b checks the rows read back from the catalog against 00b's load log (ahcccs_tables.check_loaded) and
           stops before building anything when they disagree
  C2 (F12) 07 warns per table when the claims run past its newest version + config.AHCCCS_TABLE_MAX_AGE_DAYS; build log
           ahcccs_stale_vs_claims; v03 shows it in the corpus row
  C3 (F8)  build log ahcccs_readings_sha256 (the readings file the build signed against)
  C4 (F18) the overlap register leaves AHCCCS table rules out (table caps vs NCCI MUEs are different authorities)
  C5 (F9)  v03's sign-off bar judges AHCCCS table rules by their readings, never as unsigned state rules
  C6 (F10) coverage counts a rule only for the paid dollars INSIDE its date window (computed in Spark)
  C7 (F4)  08 reports the Same Day pairs disallowed both ways and the dollars their findings count twice

Notebook code paths run from SOURCE: the cells are cut out of the notebook text and executed (07 / 08 with the in-memory
catalog of tests/nbfake_m51.py or a small local Spark; v03 whole, through nbfake_m51.run_notebook).
Run: cd pie_mvp && python -m pytest tests/test_v52_reporting.py -q
"""
import ast
import hashlib
import json
import os
import shutil
import sys
import tempfile

import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, PKG)
sys.path.insert(0, HERE)

import ahcccs_tables  # noqa: E402
import config  # noqa: E402
import detector_gen as dg  # noqa: E402
import gap  # noqa: E402
import nbfake_m51 as nbf  # noqa: E402
import quality  # noqa: E402
import registers  # noqa: E402
from schema import Rule  # noqa: E402

TBL = "ahcccs_table"


# ====================================================================== helpers
def _nb(rel):
    return open(os.path.join(PKG, "notebooks", rel)).read()


def _cells(src):
    return src.split("\n# COMMAND ----------\n")


def _code_after(src, heading):
    """The first CODE cell after the markdown cell whose text contains `heading` (a notebook section)."""
    cells = _cells(src)
    i = next(k for k, c in enumerate(cells) if "# MAGIC %md" in c and heading in c)
    return next(c for c in cells[i + 1:] if "# MAGIC %md" not in c.strip().splitlines()[0])


def _dict_keys(src, var):
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) \
                and node.targets[0].id == var and isinstance(node.value, ast.Dict):
            return {k.value for k in node.value.keys if isinstance(k, ast.Constant)}
    raise AssertionError(f"{var} = {{...}} not found")


def _rule(origin, pred, codes, eff=None, end=None, **kw):
    binding = {"ncci": "mandatory"}.get(origin, "state_policy")
    return Rule(origin=origin, plane="coding_edit", binding_status=binding, statement=f"{origin} {pred['type']}",
                source_doc="src", source_locator="loc", predicate=pred, codes=codes, effective_date=eff, end_date=end,
                **kw).assign_id().to_dict()


def _mue(code, v, edition="practitioner", eff=None, end=None):
    return _rule("ncci", {"type": "max_units_per_line", "code": code, "threshold": v, "service_category": edition,
                          "ncci_edition": edition}, [code], eff, end)


def _daily(code, n, origin="extracted", eff=None, end=None, scope=None):
    p = {"type": "max_units_per_day", "code": code, "threshold": n}
    if scope:
        p["scope"] = scope
    return _rule(origin, p, [code], eff, end)


# ====================================================================== C4 (F18): the overlap register
def test_c4_overlap_register_leaves_out_ahcccs_table_rules():
    """A table daily cap against an NCCI MUE on the same code is two authorities on purpose (per day vs per line); the
    table's agreements / disagreements with STATE rules are policy_ahcccs_conflicts. Only the extracted cap is listed."""
    mue = _mue("H0004", 8)
    table_cap = _daily("H0004", 32, origin=TBL, eff="2026-01-01", scope="member_servicing_billing_day")
    ext_cap = _daily("H0004", 4)
    table_pair = _rule(TBL, {"type": "code_pair_prohibited", "code_a": "H0014", "code_b": "H0004",
                             "modifier_indicator": "0", "scope": "member_day"}, ["H0014", "H0004"], "2026-01-01")
    ptp = _rule("ncci", {"type": "code_pair_prohibited", "code_a": "H0014", "code_b": "H0004", "modifier_indicator": "0",
                         "service_category": "practitioner", "ncci_edition": "practitioner"}, ["H0014", "H0004"])
    ov = registers.rule_overlaps([mue, table_cap, ext_cap, table_pair, ptp])
    assert ov["state_rule_id"].tolist() == [ext_cap["rule_id"]], ov[["state_rule_id", "relationship"]]
    assert ov["relationship"].tolist() == ["different_basis"]
    doc = registers.rule_overlaps.__doc__
    assert "ahcccs_table" in doc and "policy_ahcccs_conflicts" in doc


# ====================================================================== C5 (F9): the sign-off bar and the table readings
def _compiled_state(rows):
    cols = ["rule_id", "origin", "predicate_type", "review_status", "reviewer"]
    return pd.DataFrame([dict(zip(cols, r)) for r in rows], columns=cols)


EXT_OK = ("EXT-1", "extracted", "code_not_covered", "approved", "SB")
TBL_PAIR = ("TBL-1", TBL, "code_pair_prohibited", "state_table", None)
TBL_DAILY = ("TBL-2", TBL, "max_units_per_day", "state_table", None)
TBL_B2 = ("TBL-3", TBL, "provider_type_allowed", "state_table", None)


def test_c5_signoff_bar_does_not_count_table_rules_as_unsigned_state_rules():
    ok, why = quality.signoff_bar(_compiled_state([EXT_OK, TBL_PAIR, TBL_DAILY]))
    assert ok, why
    assert "all 1 compiled state rule(s) approved by a named reviewer" in why
    assert "2 AHCCCS table rule(s)" in why and "readings" in why
    # a build whose only state rules are table rules: nothing extracted / hand-authored to sign - the readings decide
    ok, why = quality.signoff_bar(_compiled_state([TBL_PAIR]))
    assert ok and "no extracted or hand-authored state rule compiles" in why, why
    # unchanged: an unsigned extracted rule, an empty build
    ok, why = quality.signoff_bar(_compiled_state([EXT_OK[:3] + ("approved", None), TBL_PAIR]))
    assert not ok and why.startswith("1 of 1 compiled state rule(s) lack") and "TBL-1" not in why, why
    assert quality.signoff_bar(_compiled_state([]))[0] is False


SIGNED_SD = {"loaded": True, "signed": True, "reason": "same_day_disallow: all 7 reading(s) signed (SB)"}
UNSIGNED_DL = {"loaded": True, "signed": False,
               "reason": "daily_limits: 4 of 4 reading(s) not signed (daily_max, not_compiled, period_limits, versions)"}


def test_c5_table_readings_bar_states_each_loaded_tables_readings():
    tables = {"same_day_disallow": SIGNED_SD, "daily_limits": UNSIGNED_DL}
    ok, why = quality.table_readings_bar(_compiled_state([EXT_OK, TBL_PAIR]), tables)
    assert ok, why
    assert "same_day_disallow: all 7 reading(s) signed (SB); 1 rule(s) compiled" in why
    assert "daily_limits: 4 of 4 reading(s) not signed" in why and "held back: no rule compiled" in why
    assert why.startswith("AHCCCS rule tables (signed through their readings")
    # rules of a table whose readings are NOT signed compile (config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS off): NOT YET
    ok, why = quality.table_readings_bar(_compiled_state([EXT_OK, TBL_PAIR, TBL_DAILY]), tables)
    assert not ok and "daily_limits" in why and "1 rule(s) compiled UNSIGNED" in why, why
    # table rules of a table the load log does not list: their readings cannot be named - NOT YET
    ok, why = quality.table_readings_bar(_compiled_state([TBL_B2]), tables)
    assert not ok and "b2_matrix: 1 rule(s) compiled, but no readings status" in why, why
    # no table loaded, no table rule: nothing to say (the bar reads as before v5.2)
    assert quality.table_readings_bar(_compiled_state([EXT_OK]), {}) == (True, "")
    assert quality.table_readings_bar(None, None) == (True, "")


# ---- v03 runs both halves in one bar (from source, in-memory catalog)
V03 = "validation/v03_pipeline_health.py"
_EXTRA_WHERE = [  # the where clauses v03's sign-off and validation sections use (nbfake_m51 models simpler ones)
    (r"^\s*compiled AND \(origin IS NULL OR origin <> 'ncci'\)\s*$",
     lambda d, m: (d["compiled"] == True) & (d["origin"].isna() | (d["origin"] != "ncci"))),  # noqa: E712
    (r"^\s*origin IS NULL OR origin <> 'ncci'\s*$", lambda d, m: d["origin"].isna() | (d["origin"] != "ncci")),
    (r"^\s*compiled AND (\w+) IS NOT NULL\s*$", lambda d, m: (d["compiled"] == True) & d[m[1]].notna()),  # noqa: E712
]


def _kb(name):
    return f"{config.KB}.{name}"


def _readings_copy(tmp_path, sign):
    """reference/ahcccs_table_readings.csv with every reading of the tables in `sign` signed by a named reviewer."""
    import csv
    with open(os.path.join(PKG, "reference", "ahcccs_table_readings.csv"), newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))
    out = os.path.join(str(tmp_path), "readings.csv")
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=[c.strip() for c in rows[0]])
        w.writeheader()
        for r in rows:
            r = {k.strip(): v for k, v in r.items()}
            if r["table_key"] in sign:
                r.update(status="signed", reviewer="Reviewer X", reviewed_at="2026-10-04")
            w.writerow(r)
    return out


def _load_log(keys=("same_day_disallow", "daily_limits")):
    return pd.DataFrame([{"table_key": k, "file_name": f"{k}.xlsx", "file_sha256": k[0] * 64, "version_date": "2026-10-01",
                          "rows": 10, "status": "loaded", "detail": None, "loaded_at": "2026-10-04T09:00:00",
                          "archived_path": None} for k in keys])


def _v03_signoff(monkeypatch, tmp_path, rules, sign=("same_day_disallow",), require=True, build_log=None):
    import re
    nbf.install(monkeypatch)
    monkeypatch.setattr(config, "NCCI_ROUTE_BY", "form")                      # no claims read
    monkeypatch.setattr(nbf, "_WHERE", nbf._WHERE + [(re.compile(p), f) for p, f in _EXTRA_WHERE])
    monkeypatch.setattr(config, "AHCCCS_TABLE_READINGS", _readings_copy(tmp_path, sign))
    monkeypatch.setattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", require)
    batch = {"code_pair_prohibited": "ahcccs_same_day", "max_units_per_day": "ahcccs_daily_max",
             "provider_type_allowed": "ahcccs_provider_type"}
    t = {config.STATE_RULES_TABLE: pd.DataFrame([{"rule_id": "EXT-1", "origin": "extracted", "chapter": "19",
                                                   "review_status": "approved", "reviewer": "SB"}]),
         _kb("policy_document_inventory"): pd.DataFrame([{"chapter": "19", "doc_hash": "H19",
                                                          "fetched_at": "2026-10-01T00:00:00"}]),
         _kb("policy_rules"): pd.DataFrame([{"rule_id": r[0], "origin": r[1], "review_status": r[3], "reviewer": r[4],
                                             "build_id": "B1"} for r in rules]),
         _kb("policy_detectors"): pd.DataFrame([{"rule_id": r[0], "origin": r[1], "predicate_type": r[2], "compiled": True,
                                                 "batch": batch[r[2]] if r[1] == TBL else None,
                                                 "sql": None if r[1] == TBL else "SELECT 1",
                                                 "sql_sha256": None if r[1] == TBL else "h1", "build_id": "B1"}
                                                for r in rules]),
         config.AHCCCS_TABLES_LOG: _load_log()}
    if build_log is not None:
        t[_kb("policy_build_log")] = pd.DataFrame([build_log])
    g = nbf.run_notebook(V03, nbf.FakeSpark(t))
    return g, {r["measurement bar item"]: (r["status"], r["reason"]) for r in g["go_table"].to_dict("records")}


SIGNOFF = "Every executable state rule signed by a named reviewer"


def test_c5_v03_signoff_bar_is_go_with_table_rules_signed_through_their_readings(monkeypatch, tmp_path):
    g, bars = _v03_signoff(monkeypatch, tmp_path, [EXT_OK, TBL_PAIR])
    st, why = bars[SIGNOFF]
    assert st == "GO", why
    assert "all 1 compiled state rule(s) approved by a named reviewer" in why and "TBL-1" not in why
    assert "same_day_disallow:" in why.split("AHCCCS rule tables")[1] and "1 rule(s) compiled" in why
    sd = why.split("same_day_disallow:")[1].split("|")[0]
    assert "signed (Reviewer X)" in sd, sd
    dl = why.split("daily_limits:")[1].split("|")[0]
    assert "not signed" in dl and "held back: no rule compiled" in dl, dl
    assert set(g["TABLE_READINGS"]) == {"same_day_disallow", "daily_limits"}            # the LOADED tables only
    assert g["TABLE_READINGS"]["same_day_disallow"]["signed"] and not g["TABLE_READINGS"]["daily_limits"]["signed"]


def test_c5_v03_signoff_bar_holds_table_rules_compiled_on_unsigned_readings(monkeypatch, tmp_path):
    """config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS off: the daily limits compile although nobody signed their readings."""
    _, bars = _v03_signoff(monkeypatch, tmp_path, [EXT_OK, TBL_PAIR, TBL_DAILY], require=False)
    st, why = bars[SIGNOFF]
    assert st == "NOT YET" and "1 rule(s) compiled UNSIGNED" in why and "NOT YET for daily_limits" in why, why


# ====================================================================== 07 step 3b: C1 (F7), C2 (F12), C3 (F8)
LOADED_AT = "2026-10-04T09:00:00"


def _sd_rows(vd="2026-10-01", sha="a" * 64):
    base = {"version_date": vd, "file_sha256": sha, "file_name": "SameDayDisallowTable.xlsx", "sheet": "1012026",
            "row_unit": "15 min", "col_unit": "Per Diem", "changed": False, "loaded_at": LOADED_AT}
    return [dict(base, row_code="H0001", row_description="Assessment", col_code="H0014", indicator="D", cell="D7"),
            dict(base, row_code="H0001", row_description="Assessment", col_code="H0035", indicator="A*", cell="E7")]


def _dl_rows(vd="2026-09-14", sha="c" * 64, codes=("H0004", "H2014")):
    return [{"version_date": vd, "file_sha256": sha, "file_name": "HCPCSCPTProcedureswithDailyLimits.xlsx",
             "sheet": "September 2026", "code": c, "description": f"desc {c}", "daily_max": 32, "limit1": None,
             "freq1_value": None, "freq1_cd": None, "limit2": None, "freq2_value": None, "freq2_cd": None,
             "source_row": 5 + i, "loaded_at": LOADED_AT} for i, c in enumerate(codes)]


def _log_rows(frames):
    """A load log that agrees with the frames: one 'loaded' row per (table, version, file) with its row count."""
    out = []
    for key, rows in frames.items():
        df = pd.DataFrame(rows)
        for (vd, sha), g in df.groupby(["version_date", "file_sha256"]):
            out.append({"table_key": key, "file_name": g["file_name"].iloc[0], "file_sha256": sha, "version_date": vd,
                        "rows": len(g), "status": "loaded", "detail": None, "loaded_at": LOADED_AT,
                        "archived_path": None})
    return pd.DataFrame(out)


def _catalog(frames, log):
    t = {config.AHCCCS_TABLES[k]["table"]: pd.DataFrame(rows) for k, rows in frames.items()}
    if log is not None:
        t[config.AHCCCS_TABLES_LOG] = log
    return t


def _run_07_3b(monkeypatch, tables, claims_window=("2026-01-01", "2026-12-31"), scope_codes=None):
    """07's step 3b cell, run from the notebook source against the in-memory catalog."""
    import kb_io
    nbf.install(monkeypatch)
    src = _code_after(_nb("07_build_kb.py"), "## 3b. AHCCCS rule tables")
    assert "ahcccs_tables.frames_for_build(spark)" in src
    g = {"spark": nbf.FakeSpark(tables), "config": config, "kb_io": kb_io, "ahcccs_tables": ahcccs_tables,
         "detector_gen": dg, "json": json, "pd": pd, "quality": quality, "CLAIMS_WINDOW": claims_window,
         "scope_codes": scope_codes}
    exec(compile(src, "07_build_kb.py:3b", "exec"), g)
    return g


FRAMES = {"same_day_disallow": _sd_rows(), "daily_limits": _dl_rows()}


def test_c1_07_checks_the_catalog_rows_against_the_load_log_before_building(monkeypatch):
    """The wiring: check_loaded gets the three frames as read from the catalog and the load log; a problem stops 07
    with "AHCCCS TABLE CHECK FAILED" before a single table rule is built."""
    seen = {}

    def fake_check(frames, log):
        seen["frames"], seen["log"] = frames, log
        return ["daily_limits version 2026-09-14: 1 row(s) in the catalog, the log loaded 2"]

    def no_rules(*a, **k):
        raise AssertionError("rules were built although the table check failed")
    monkeypatch.setattr(ahcccs_tables, "check_loaded", fake_check, raising=False)
    monkeypatch.setattr(ahcccs_tables, "rules_from_frames", no_rules)
    log = _log_rows(FRAMES)
    with pytest.raises(RuntimeError) as e:
        _run_07_3b(monkeypatch, _catalog(FRAMES, log))
    assert str(e.value).startswith("AHCCCS TABLE CHECK FAILED") and "1 row(s) in the catalog, the log loaded 2" in str(e.value)
    assert set(seen["frames"]) == {"same_day_disallow", "daily_limits", "b2_matrix"}
    assert len(seen["frames"]["daily_limits"]) == 2 and not len(seen["frames"]["b2_matrix"])  # empty frame: not loaded
    assert list(seen["log"]["table_key"]) == list(log["table_key"])
    # no log table at all: check_loaded is still asked (log None) - rows nobody logged are its call, not 07's
    seen.clear()
    with pytest.raises(RuntimeError):
        _run_07_3b(monkeypatch, _catalog(FRAMES, None))
    assert seen["log"] is None


def test_c1_07_stops_on_a_row_deleted_in_the_catalog(monkeypatch):
    """With the real ahcccs_tables.check_loaded (Role A): the log says 2 daily-limit rows were loaded, the catalog holds 1
    (a row deleted there by hand) -> 07 stops; when they agree it goes on."""
    log = _log_rows(FRAMES)
    g = _run_07_3b(monkeypatch, _catalog(FRAMES, log))                     # agree: no error
    assert g["AHCCCS_STATUS"]["daily_limits"]["loaded"] and g["AHCCCS_STATUS"]["same_day_disallow"]["loaded"]
    cut = dict(FRAMES, daily_limits=_dl_rows()[:1])
    with pytest.raises(RuntimeError, match="AHCCCS TABLE CHECK FAILED"):
        _run_07_3b(monkeypatch, _catalog(cut, log))
    gone = {"same_day_disallow": FRAMES["same_day_disallow"]}             # the daily limits table dropped
    with pytest.raises(RuntimeError, match="AHCCCS TABLE CHECK FAILED"):
        _run_07_3b(monkeypatch, _catalog(gone, log))
    # a row EDITED in the catalog (same count): caught by the rows hash 00b logs (ahcccs_tables.rows_sha256)
    hashed = log.copy()
    hashed["rows_sha256"] = [ahcccs_tables.rows_sha256(k, pd.DataFrame(FRAMES[k])) for k in hashed["table_key"]]
    _run_07_3b(monkeypatch, _catalog(FRAMES, hashed))                      # as loaded: no error
    edited = dict(FRAMES, daily_limits=[dict(r, daily_max=99) if r["code"] == "H2014" else r for r in _dl_rows()])
    with pytest.raises(RuntimeError, match="AHCCCS TABLE CHECK FAILED"):
        _run_07_3b(monkeypatch, _catalog(edited, hashed))


def test_c2_07_warns_per_table_when_the_claims_run_past_its_max_age(monkeypatch, capsys):
    monkeypatch.setattr(config, "AHCCCS_TABLE_MAX_AGE_DAYS", {"same_day_disallow": 366, "daily_limits": 62,
                                                              "b2_matrix": 62})
    monkeypatch.setattr(ahcccs_tables, "check_loaded", lambda frames, log: [], raising=False)
    monkeypatch.setattr(ahcccs_tables, "readings_sha256", lambda path=None: "r" * 64, raising=False)
    tables = _catalog(FRAMES, _log_rows(FRAMES))
    g = _run_07_3b(monkeypatch, tables, claims_window=("2026-01-01", "2026-12-31"))
    # daily limits: 2026-09-14 + 62 days = 2026-11-15 < 2026-12-31; same day: 2026-10-01 + 366 days = 2027-10-02
    assert g["AHCCCS_STALE"] == {"daily_limits": {"newest_version": "2026-09-14", "max_age_days": 62,
                                                  "stale_after": "2026-11-15", "claims_to": "2026-12-31"}}
    out = capsys.readouterr().out
    assert "WARNING" in out and "daily_limits" in out.split("WARNING")[1] and "2026-11-15" in out
    # the boundary: claims to the last day of the max age are not past it
    g = _run_07_3b(monkeypatch, tables, claims_window=("2026-01-01", "2026-11-15"))
    assert g["AHCCCS_STALE"] == {}


def test_c2_tables_stale_vs_claims():
    f = quality.tables_stale_vs_claims
    ages = {"same_day_disallow": 366, "daily_limits": 62, "b2_matrix": 62}
    v = {"daily_limits": ["2026-07-01", "2026-09-14"], "b2_matrix": ["2026-10-01"], "same_day_disallow": []}
    assert f(v, "2026-11-16", ages) == {"daily_limits": {"newest_version": "2026-09-14", "max_age_days": 62,
                                                         "stale_after": "2026-11-15", "claims_to": "2026-11-16"}}
    assert f(v, "2026-11-15", ages) == {}                                  # on the last day: not past it
    assert set(f(v, "2027-01-01", ages)) == {"daily_limits", "b2_matrix"}
    assert f(v, None, ages) == {} and f({}, "2030-01-01", ages) == {}
    assert f({"daily_limits": ["2026-09-14"]}, "2030-01-01", {}) == {}      # no max age configured: never stale
    txt = quality.stale_tables_text(f(v, "2027-01-01", ages))
    assert "daily_limits (newest version 2026-09-14 + 62 days = 2026-11-15; claims run to 2027-01-01)" in txt
    assert quality.stale_tables_text({}) == ""


def test_c3_07_records_the_readings_file_it_was_gated_on(monkeypatch):
    """ahcccs_tables.readings_sha256() (Role A): the sha256 of the readings file's bytes, kept in the build log."""
    monkeypatch.setattr(ahcccs_tables, "check_loaded", lambda frames, log: [], raising=False)
    g = _run_07_3b(monkeypatch, _catalog(FRAMES, _log_rows(FRAMES)))
    with open(config.AHCCCS_TABLE_READINGS, "rb") as fh:
        assert g["AHCCCS_READINGS_SHA256"] == hashlib.sha256(fh.read()).hexdigest()


def test_c1_c2_c3_build_log_fields():
    src = _nb("07_build_kb.py")
    keys = _dict_keys(src, "build_meta")
    assert {"ahcccs_stale_vs_claims", "ahcccs_readings_sha256"} <= keys
    assert '"ahcccs_stale_vs_claims": json.dumps(AHCCCS_STALE' in src
    assert '"ahcccs_readings_sha256": AHCCCS_READINGS_SHA256' in src
    # the check runs on the frames as read, with the log, BEFORE the rules are built
    i_chk = src.index("ahcccs_tables.check_loaded(_frames_all, AHCCCS_LOG)")
    assert src.index("AHCCCS_LOG = kb_io.table_or_none(spark, config.AHCCCS_TABLES_LOG)") < i_chk
    assert i_chk < src.index("ahcccs_tables.rules_from_frames(") and i_chk < src.index("ahcccs_tables.table_compiles(key)")


STALE = {"daily_limits": {"newest_version": "2026-09-14", "max_age_days": 62, "stale_after": "2026-11-15",
                          "claims_to": "2026-12-31"}}


def test_c2_corpus_bar_names_the_tables_the_claims_outran():
    chapters = {"1": 0}
    loaded = {"daily_limits": [{"version_date": "2026-09-14"}], "same_day_disallow": [{"version_date": "2026-10-01"}]}
    ok, why = quality.corpus_bar({"1": "a"}, chapters, {"daily_limits": ("d", "u")}, "c", loaded, stale_tables=STALE)
    assert ok, why                                                      # a warning, not a failure of the corpus
    assert ("2 AHCCCS rule table(s) loaded: daily_limits (2026-09-14), same_day_disallow (2026-10-01); the claims run "
            "past the newest version's max age (config.AHCCCS_TABLE_MAX_AGE_DAYS) of daily_limits (newest version "
            "2026-09-14 + 62 days = 2026-11-15; claims run to 2026-12-31)") in why
    assert quality.corpus_bar({"1": "a"}, chapters, {}, "c", loaded, stale_tables={}) == \
        quality.corpus_bar({"1": "a"}, chapters, {}, "c", loaded)


def test_c2_v03_shows_the_stale_tables_of_the_latest_build_in_the_corpus_row(monkeypatch, tmp_path):
    blog = {"build_id": "B1", "built_at": "2026-10-04T10:00:00", "claims_to": "2026-12-31",
            "ahcccs_stale_vs_claims": json.dumps(STALE)}
    g, bars = _v03_signoff(monkeypatch, tmp_path, [EXT_OK], build_log=blog)
    st, why = next(v for k, v in bars.items() if k.startswith("Corpus frozen and complete"))
    assert "daily_limits (newest version 2026-09-14 + 62 days = 2026-11-15; claims run to 2026-12-31)" in why, why
    # a build log written before v5.2b (no such field): the row reads as before
    blog.pop("ahcccs_stale_vs_claims")
    g, bars = _v03_signoff(monkeypatch, tmp_path, [EXT_OK], build_log=blog)
    st, why = next(v for k, v in bars.items() if k.startswith("Corpus frozen and complete"))
    assert "max age" not in why


# ====================================================================== C6 (F10): coverage inside each rule's window
EXP_COLS = ["code", "form_typ", "ncci_edition", "lines", "units", "paid_dollars", "paid_dollars_state_window",
            "paid_dollars_federal_window", "paid_dollars_any_window", "lines_state_window", "lines_federal_window",
            "lines_any_window"]
DATED_EXP = pd.DataFrame([
    ("H0004", "A", "practitioner", 3, 60.0, 1000.0, 600.0, 0.0, 600.0, 2, 0, 2),     # a state rule judges part of it
    ("H0005", "A", "practitioner", 2, 2.0, 500.0, 0.0, 0.0, 0.0, 0, 0, 0),           # every dollar outside its window
    ("11111", "A", "practitioner", 2, 2.0, 300.0, 0.0, 100.0, 100.0, 0, 1, 1),       # NCCI judges part of it
    ("22222", "A", "practitioner", 1, 1.0, 50.0, 50.0, 50.0, 50.0, 1, 1, 1),         # both, wholly
    ("99213", "A", "practitioner", 4, 4.0, 300.0, 0.0, 0.0, 0.0, 0, 0, 0),           # nothing checks it
], columns=EXP_COLS)
CLAIMS_WINDOW = ("2025-01-01", "2026-12-31")


def _cov_rules():
    rules = [_daily("H0004", 4, eff="2026-01-01"), _daily("H0005", 4, eff="2026-06-01"),
             _rule("ncci", {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222",
                            "modifier_indicator": "0", "service_category": "practitioner",
                            "ncci_edition": "practitioner"}, ["11111", "22222"], "2010-01-01", "2025-12-31"),
             _daily("22222", 1, origin=TBL, eff="2026-01-01"),
             _rule("extracted", {"type": "code_not_covered", "code": "99213"}, ["99213"])]       # a lead (below)
    dets = [{"rule_id": r["rule_id"], "compiled": r["codes"] != ["99213"]} for r in rules]
    return rules, dets


def test_c6_a_code_whose_dollars_lie_outside_every_state_window_is_not_state_covered():
    rules, dets = _cov_rules()
    cov = gap.coverage_from_exposure(DATED_EXP, rules, dets, CLAIMS_WINDOW).set_index("code")
    assert cov["coverage"].to_dict() == {"H0004": "state_only", "H0005": "none", "11111": "federal_only",
                                         "22222": "both", "99213": "none"}
    assert cov.loc["H0005", "state_rules"] == 1 and cov.loc["99213", "state_leads"] == 1       # counts as before
    for c in EXP_COLS[6:]:
        assert c in cov.columns                                            # the dated columns are kept
    # without the dated columns (an exposure computed the old way): rule presence, as before v5.2b
    old = gap.coverage_from_exposure(DATED_EXP[EXP_COLS[:6]], rules, dets, CLAIMS_WINDOW).set_index("code")
    assert old.loc["H0005", "coverage"] == "state_only" and old["paid_dollars_state_window"].isna().all()


def test_c6_coverage_percentages_use_the_dated_dollars():
    rules, dets = _cov_rules()
    cov = gap.coverage_from_exposure(DATED_EXP, rules, dets, CLAIMS_WINDOW)
    # paid 2150: inside a state rule's window 600 + 50; inside any rule's window 600 + 100 + 50
    assert gap.coverage_pcts(cov) == (round(100 * 750 / 2150, 2), round(100 * 650 / 2150, 2))
    old = gap.coverage_from_exposure(DATED_EXP[EXP_COLS[:6]], rules, dets, CLAIMS_WINDOW)
    assert gap.coverage_pcts(old) == (round(100 * 1850 / 2150, 2), round(100 * 1550 / 2150, 2))  # rule presence
    nan_any, nan_state = gap.coverage_pcts(cov.assign(paid_dollars=0.0))
    assert nan_any != nan_any and nan_state != nan_state                   # no paid dollars: no percentage


def test_c6_gap_rows_are_the_dollars_no_state_rule_judges():
    rules, dets = _cov_rules()
    g = gap.gap_rows(gap.coverage_from_exposure(DATED_EXP, rules, dets, CLAIMS_WINDOW))
    assert g["code"].tolist() == ["H0005", "H0004", "99213", "11111"]      # 22222: every dollar inside a state window
    assert g.set_index("code")["paid_dollars_outside_state_window"].to_dict() == {"H0005": 500.0, "H0004": 400.0,
                                                                                  "99213": 300.0, "11111": 300.0}


def test_c6_coverage_summary_splits_dollars_and_lines_by_window():
    rules, dets = _cov_rules()
    s = gap.coverage_summary(gap.coverage_from_exposure(DATED_EXP, rules, dets, CLAIMS_WINDOW)).set_index("coverage")
    assert s["paid_dollars"].to_dict() == {"none": 1400.0, "state_only": 600.0, "federal_only": 100.0, "both": 50.0}
    assert s["lines"].to_dict() == {"none": 8, "state_only": 2, "federal_only": 1, "both": 1}
    assert s["codes"].to_dict() == {"none": 4, "state_only": 1, "federal_only": 1, "both": 1}   # H0004: in two classes
    assert s.loc["none", "pct_paid"] == round(100 * 1400 / 2150, 1) and s["pct_lines"].sum() == pytest.approx(100, abs=0.2)
    # the summary and the build log tell one story: state = both + state_only; any = 100 - none
    pa, ps = gap.coverage_pcts(gap.coverage_from_exposure(DATED_EXP, rules, dets, CLAIMS_WINDOW))
    assert ps == round(100 * (50 + 600) / 2150, 2) and pa == round(100 - 100 * 1400 / 2150, 2)


def test_c6_rule_windows_are_the_live_rules_windows_merged_per_code():
    rs = [_daily("H0004", 4, eff="2026-01-01"),
          _daily("H0004", 32, origin=TBL, eff="2026-03-01", end="2026-05-31"),          # inside the first: merged
          _daily("H0005", 4, eff="2025-01-01", end="2025-06-30"),
          _daily("H0005", 6, origin="manual", eff="2025-07-01", end="2025-08-31"),       # adjacent: merged
          _daily("H0005", 8, eff="2025-10-01"),                                          # a gap before it: separate
          _rule("ncci", {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222",
                         "modifier_indicator": "0", "ncci_edition": "practitioner"}, ["11111", "22222"],
                "2010-01-01", "2025-12-31"),
          _mue("11111", 2, edition="outpatient", eff="2012-01-01"),
          _rule("ncci", {"type": "max_units_per_line", "code": "33333", "threshold": 1}, ["33333"]),  # no edition
          _daily("44444", 1),                                                            # no dates: always
          _rule("extracted", {"type": "code_not_covered", "code": "99213"}, ["99213"])]  # a lead
    dets = [{"rule_id": r["rule_id"], "compiled": r["codes"] != ["99213"]} for r in rs]
    w = gap.rule_windows(rs, dets)
    assert list(w.columns) == ["kind", "code", "edition", "effective_date", "end_date"]
    got = [tuple(None if v is None or v != v else v for v in r) for r in w.itertuples(index=False)]
    assert got == [("federal", "11111", "outpatient", "2012-01-01", None),
                   ("federal", "11111", "practitioner", "2010-01-01", "2025-12-31"),
                   ("federal", "22222", "practitioner", "2010-01-01", "2025-12-31"),
                   ("federal", "33333", None, None, None),
                   ("state", "44444", None, None, None),
                   ("state", "H0004", None, "2026-01-01", None),
                   ("state", "H0005", None, "2025-01-01", "2025-08-31"),
                   ("state", "H0005", None, "2025-10-01", None)]
    assert len(gap.rule_windows(rs, [])) == 0                                # nothing compiled: no window


# ---- in Spark (the window test runs where the claim lines are: 17M of them on Databricks)
def _drop_stand_in_pyspark():
    """tests/test_offline.py (test_kb_io_explicit_schema_...) leaves stand-in pyspark modules in sys.modules for the rest
    of the pytest process, and every later `from pyspark.sql import SparkSession` fails. When a pyspark module there has
    no file (a stand-in), forget them all so the real package is imported."""
    names = [n for n in list(sys.modules) if n == "pyspark" or n.startswith("pyspark.")]
    if any(getattr(sys.modules[n], "__file__", None) is None for n in names):
        for n in names:
            del sys.modules[n]


@pytest.fixture(scope="module")
def spark():
    _drop_stand_in_pyspark()
    pytest.importorskip("pyspark", reason="pyspark not installed: the Spark tests of C6 / C7 did NOT run")
    if not (shutil.which("java") or os.environ.get("JAVA_HOME")):
        pytest.skip("no Java runtime for Spark: the Spark tests of C6 / C7 did NOT run")
    from pyspark.sql import SparkSession
    root = tempfile.mkdtemp(prefix="pie_v52c_")
    s = (SparkSession.builder.master("local[1]").appName("pie-v52-reporting")
         .config("spark.ui.enabled", "false").config("spark.sql.ansi.enabled", "true")
         .config("spark.driver.memory", "1g").config("spark.sql.shuffle.partitions", "1")
         .config("spark.sql.codegen.fallback", "false")
         .config("spark.sql.warehouse.dir", os.path.join(root, "wh")).getOrCreate())
    s.sparkContext.setLogLevel("ERROR")
    s.sql("CREATE SCHEMA IF NOT EXISTS spark_catalog.policy_kb")
    yield s
    s.stop()
    shutil.rmtree(root, ignore_errors=True)


CC = config.CLAIM_COLS


def _claims_view(spark, rows, name="pie_cov_claims"):
    """A claims table with the configured column names: (code, form, servicing type, billing type, dos, units, paid)."""
    from datetime import date
    from decimal import Decimal
    from pyspark.sql import types as T
    schema = T.StructType([T.StructField(CC["code"], T.StringType()), T.StructField(CC["form"], T.StringType()),
                           T.StructField(CC["prov_type"], T.StringType()), T.StructField(CC["billing_type"], T.StringType()),
                           T.StructField(CC["dos"], T.DateType()), T.StructField(CC["units"], T.DecimalType(15, 4)),
                           T.StructField(CC["paid_amt"], T.DecimalType(15, 2))])
    data = [(c, f, pt, bt, None if d is None else date.fromisoformat(d), Decimal(str(u)), Decimal(str(p)))
            for c, f, pt, bt, d, u, p in rows]
    spark.createDataFrame(data, schema).createOrReplaceTempView(name)
    return name


CLAIM_ROWS = [
    ("H0004", "A", "08", "08", "2025-12-15", 20, 400.00),       # before the state window
    ("H0004", "A", "08", "08", "2026-01-20", 20, 400.00),       # inside it (two state windows overlap here: once)
    ("h0004 ", "A", "08", "08", "2026-01-20", 10, 200.00),      # the same code, padded / lower case
    ("H0004", "A", "08", "08", None, 5, 100.00),                # no date of service: never inside a window
    ("11111", "A", "08", "08", "2025-06-01", 1, 100.00),        # inside the practitioner edit's window
    ("11111", "A", "08", "08", "2026-02-01", 1, 200.00),        # after the edit's deletion
    ("11111", "D", "08", "08", "2025-06-01", 1, 70.00),         # dental: takes no NCCI file
    ("33333", "D", "08", "08", "2025-06-01", 1, 30.00),         # an edit with no edition counts on every line
    ("22222", "A", "08", "08", "2026-01-20", 1, 50.00),         # state and federal
]
WINDOWS = pd.DataFrame([("state", "H0004", None, "2026-01-01", None),
                        ("state", "H0004", None, "2026-01-15", "2026-02-28"),
                        ("federal", "11111", "practitioner", "2010-01-01", "2025-12-31"),
                        ("federal", "11111", "outpatient", "2010-01-01", None),
                        ("federal", "33333", None, None, None),
                        ("state", "22222", None, None, None),
                        ("federal", "22222", "practitioner", "2010-01-01", None)],
                       columns=["kind", "code", "edition", "effective_date", "end_date"])


def test_c6_exposure_by_code_counts_the_dollars_inside_the_windows_in_spark(spark):
    v = _claims_view(spark, CLAIM_ROWS)
    e = gap.exposure_by_code(spark, v, CC["paid_amt"], windows=WINDOWS)
    e = e.set_index(["code", "form_typ", e["ncci_edition"].fillna("-")])
    cols = ["lines", "paid_dollars", "paid_dollars_state_window", "paid_dollars_federal_window",
            "paid_dollars_any_window", "lines_state_window", "lines_federal_window", "lines_any_window"]
    got = {k: tuple(float(x) for x in r) for k, r in zip(e.index, e[cols].itertuples(index=False))}
    assert got == {("H0004", "A", "practitioner"): (4, 1100, 600, 0, 600, 2, 0, 2),
                   ("11111", "A", "practitioner"): (2, 300, 0, 100, 100, 0, 1, 1),
                   ("11111", "D", "-"): (1, 70, 0, 0, 0, 0, 0, 0),
                   ("33333", "D", "-"): (1, 30, 0, 30, 30, 0, 1, 1),
                   ("22222", "A", "practitioner"): (1, 50, 50, 50, 50, 1, 1, 1)}
    # without windows: the old exposure, no dated columns
    old = gap.exposure_by_code(spark, v, CC["paid_amt"])
    assert "paid_dollars_state_window" not in old.columns and float(old["paid_dollars"].sum()) == 1550.0
    # the window table is broadcast to the lines: never the lines to pandas
    assert "BROADCAST" in gap.dated_exposure_sql("t", "w", CC["paid_amt"], CC["units"], CC["code"], CC["dos"],
                                                  "''", "CAST(NULL AS STRING)")


def test_c6_coverage_table_in_spark_from_the_rules(spark):
    v = _claims_view(spark, CLAIM_ROWS)
    rules = [_daily("H0004", 4, eff="2026-01-01"),
             _rule("ncci", {"type": "code_pair_prohibited", "code_a": "11111", "code_b": "22222",
                            "modifier_indicator": "0", "ncci_edition": "practitioner"}, ["11111", "22222"],
                   "2010-01-01", "2025-12-31"),
             _daily("22222", 1, origin=TBL, eff="2026-01-01")]
    dets = [{"rule_id": r["rule_id"], "compiled": True} for r in rules]
    cov = gap.coverage_table(spark, rules, v, CC["paid_amt"], detectors=dets, claims_window=("2025-01-01", "2026-12-31"))
    c = {(r.code, r.form_typ): r for r in cov.itertuples()}
    assert c[("H0004", "A")].coverage == "state_only" and c[("H0004", "A")].paid_dollars_state_window == 600
    assert c[("11111", "A")].coverage == "federal_only" and c[("11111", "A")].paid_dollars_federal_window == 100
    # 22222 on 2026-01-20: the table rule judges it (from 2026-01-01); the NCCI edit was deleted on 2025-12-31
    assert c[("22222", "A")].coverage == "state_only" and c[("22222", "A")].paid_dollars_federal_window == 0
    assert c[("11111", "D")].coverage == "none" and c[("33333", "D")].coverage == "none"


def test_c6_07_build_log_and_print_use_the_dated_dollars():
    src = _nb("07_build_kb.py")
    assert "PCT_PAID_COVERED_ANY, PCT_PAID_COVERED_STATE = gap.coverage_pcts(coverage)" in src
    assert '"pct_paid_covered_any": PCT_PAID_COVERED_ANY, "pct_paid_covered_state": PCT_PAID_COVERED_STATE' in src
    assert 'coverage.groupby("coverage")["paid_dollars"]' not in src            # the undated percentages are gone
    assert "gap.coverage_table(spark, accepted, CLAIMS, PAID_COL, detectors=detectors, claims_window=CLAIMS_WINDOW)" in src
    assert "dated inside the window of a compiled rule" in _nb(V03)


# ====================================================================== C7 (F4): 08 - pairs disallowed both ways
KB_LOCAL = "spark_catalog.policy_kb"
BW_EDITS = pd.DataFrame([
    {"rule_id": "TBL-a", "code_a": "H0014", "code_b": "H0001", "both_ways": True},    # finding on the H0001 line
    {"rule_id": "TBL-b", "code_a": "H0001", "code_b": "H0014", "both_ways": True},    # finding on the H0014 line
    {"rule_id": "TBL-c", "code_a": "H0035", "code_b": "H0001", "both_ways": False},   # one way only
])


def _finding(rule, member, dos, claim, line, paid, run="R1", batch="ahcccs_same_day"):
    return {"run_id": run, "build_id": "B1", "rule_id": rule, "batch": batch, "origin": TBL, "member_id": member,
            "dos": dos, "claim_id": claim, "line_no": str(line), "paid_amt": paid, "paid_at_risk": paid}


BW_FINDINGS = [
    _finding("TBL-a", "m1", "2026-01-20", "c1", 1, 90.0),        # m1: both lines flagged: at most 150 at risk
    _finding("TBL-b", "m1", "2026-01-20", "c2", 1, 150.0),
    _finding("TBL-c", "m1", "2026-01-20", "c1", 1, 90.0),        # the same line, by a one-way rule: not counted here
    _finding("TBL-a", "m2", "2026-01-21", "c3", 1, 80.0),        # m2: only the H0001 line flagged -> nothing twice
    _finding("TBL-a", "m3", "2026-01-22", "c5", 1, 10.0),        # m3: H0001 10 + 20, H0014 30: at most 30
    _finding("TBL-a", "m3", "2026-01-22", "c5", 2, 20.0),
    _finding("TBL-b", "m3", "2026-01-22", "c6", 1, 30.0),
    _finding("TBL-b", "m1", "2026-01-20", "c2", 1, 150.0, run="R0"),                # another run
    _finding("NCCI-1", "m1", "2026-01-20", "c2", 1, 150.0, batch="ncci_ptp"),      # another statement
]


def _run_08_both_ways(spark, edits, findings, hits=7):
    for name, df in (("policy_ahcccs_pair_edits", edits.assign(build_id="B1")),
                     ("policy_findings", pd.DataFrame(findings))):
        spark.createDataFrame(df).write.mode("overwrite").format("parquet").saveAsTable(f"{KB_LOCAL}.{name}")
    src = _code_after(_nb("08_run_detectors.py"), "## 3c. Same Day pairs disallowed both ways")
    runs = [{"rule_id": f"BATCH:{dg.BATCH_AHCCCS_PAIR}", "hits": hits, "batch": dg.BATCH_AHCCCS_PAIR}]
    g = {"spark": spark, "KB": KB_LOCAL, "FINDINGS": f"{KB_LOCAL}.policy_findings", "run_id": "R1", "BUILD_ID": "B1",
         "detector_gen": dg, "json": json, "pd": pd, "runs": runs}
    exec(compile(src, "08_run_detectors.py:3c", "exec"), g)
    return g


def test_c7_08_counts_the_dollars_both_ways_pairs_flag_twice(spark, capsys):
    g = _run_08_both_ways(spark, BW_EDITS, BW_FINDINGS)
    # per member-day over DISTINCT lines (critic re-check N5): AHCCCS keeps one code's lines, so at most m1 150 (240 -
    # 90), m2 80 (one code), m3 30 (60 - the cheaper code's 30) = 260 at risk; 380 - 260 = 120 counted more than once
    assert g["BOTH_WAYS"] == {"ahcccs_both_ways_findings": 6, "ahcccs_both_ways_paid_at_risk": 380.0,
                              "ahcccs_both_ways_at_risk_at_most": 260.0,
                              "ahcccs_both_ways_groups": 2, "ahcccs_dollars_counted_twice": 120.0}
    out = capsys.readouterr().out
    assert "disallowed both ways" in out and "260.00" in out and "counted more than once" in out
    # a line disallowed with TWO codes is flagged twice; three codes pairwise both ways (150 / 120 / 200): the findings
    # carry 940, at most 470 - 120 = 350 is at risk (the critic's example)
    tri = pd.DataFrame([{"rule_id": f"TBL-{a}{b}", "code_a": a, "code_b": b, "both_ways": True}
                        for a in ("H0014", "H0015", "H0018") for b in ("H0014", "H0015", "H0018") if a != b])
    paid = {"H0014": 150.0, "H0015": 120.0, "H0018": 200.0}
    line = {"H0014": 1, "H0015": 2, "H0018": 3}
    tf = [_finding(f"TBL-{a}{b}", "m9", "2026-01-23", "c9", line[b], paid[b])
          for a in paid for b in paid if a != b]
    g3 = _run_08_both_ways(spark, tri, tf)["BOTH_WAYS"]
    assert (g3["ahcccs_both_ways_paid_at_risk"], g3["ahcccs_both_ways_at_risk_at_most"],
            g3["ahcccs_dollars_counted_twice"]) == (940.0, 350.0, 590.0), g3
    # nothing found by the Same Day statement: zeros, no query; the statement did not run: not evaluated (None)
    assert set(_run_08_both_ways(spark, BW_EDITS, BW_FINDINGS, hits=0)["BOTH_WAYS"].values()) == {0}
    assert set(_run_08_both_ways(spark, BW_EDITS, BW_FINDINGS, hits=None)["BOTH_WAYS"].values()) == {None}
    # a pair edit table written before v5.2b (no both_ways column): not evaluated, said so - never a crash
    g = _run_08_both_ways(spark, BW_EDITS.drop(columns=["both_ways"]), BW_FINDINGS)
    assert set(g["BOTH_WAYS"].values()) == {None} and "no both_ways column" in capsys.readouterr().out
    # a failing report never stops a run whose findings are written: not evaluated, the error kept for the run log
    g = _run_08_both_ways(spark, BW_EDITS, [{k: v for k, v in f.items() if k != "paid_at_risk"} for f in BW_FINDINGS])
    assert g["BOTH_WAYS"]["ahcccs_dollars_counted_twice"] is None and g["BOTH_WAYS"]["ahcccs_both_ways_error"]


def test_c7_08_records_the_both_ways_numbers_in_the_run_snapshot():
    src = _nb("08_run_detectors.py")
    snap = src[src.index('"rule_id": "RUN:snapshot"'):]
    assert "**BOTH_WAYS" in snap.split('"rules_in_batch"')[0]
    # the cell runs after the three table statements and before the state queries, and joins on the build's edit rows
    i = src.index("## 3c. Same Day pairs disallowed both ways")
    assert src.index("## 3b. AHCCCS rule tables") < i < src.index("## 4. State")
    cell = _code_after(src, "## 3c. Same Day pairs disallowed both ways")
    assert "TABLE_BATCH_EDIT_TABLE[detector_gen.BATCH_AHCCCS_PAIR]" in cell and "both_ways" in cell
    assert "e.build_id = '{BUILD_ID}'" in cell and "f.run_id = '{run_id}'" in cell


def test_c7_08_on_the_pair_edit_table_07_writes(spark, monkeypatch):
    """The contract end to end: a Same Day version marking H0001 x H0014 D both ways -> two rules with both_ways
    (ahcccs_tables, Role A) -> the pair edit rows with a boolean both_ways column (detector_gen, Role B), written as 07
    writes them (kb_io) -> 08's report finds the member-day where both lines are flagged."""
    import kb_io
    monkeypatch.setattr(config, "TABLE_FORMAT", "parquet")
    base = _sd_rows()[0]
    sd = pd.DataFrame([dict(base, row_code="H0001", col_code="H0014", indicator="D", cell="D7"),
                       dict(base, row_code="H0014", col_code="H0001", indicator="D", cell="C8", row_unit="Per Diem")])
    rules = [r.to_dict() for r in ahcccs_tables.rules_from_frames({"same_day_disallow": sd})]
    assert len(rules) == 2 and all(r["predicate"].get("both_ways") is True for r in rules)
    pairs = dg.ahcccs_edit_tables(rules)[0].assign(build_id="B1")
    assert pairs["both_ways"].tolist() == [True, True]
    kb_io.write_table(spark, pairs, f"{KB_LOCAL}.policy_ahcccs_pair_edits", "overwrite")
    on = {r["predicate"]["code_b"]: r["rule_id"] for r in rules}        # the finding line's code -> its rule
    f = [_finding(on["H0001"], "m1", "2026-10-02", "c1", 1, 90.0), _finding(on["H0014"], "m1", "2026-10-02", "c2", 1, 150.0)]
    spark.createDataFrame(pd.DataFrame(f)).write.mode("overwrite").format("parquet").saveAsTable(
        f"{KB_LOCAL}.policy_findings")
    src = _code_after(_nb("08_run_detectors.py"), "## 3c. Same Day pairs disallowed both ways")
    g = {"spark": spark, "KB": KB_LOCAL, "FINDINGS": f"{KB_LOCAL}.policy_findings", "run_id": "R1", "BUILD_ID": "B1",
         "detector_gen": dg, "json": json, "pd": pd, "runs": [{"rule_id": f"BATCH:{dg.BATCH_AHCCCS_PAIR}", "hits": 2}]}
    exec(compile(src, "08_run_detectors.py:3c", "exec"), g)
    assert g["BOTH_WAYS"] == {"ahcccs_both_ways_findings": 2, "ahcccs_both_ways_paid_at_risk": 240.0,
                              "ahcccs_both_ways_at_risk_at_most": 150.0,
                              "ahcccs_both_ways_groups": 1, "ahcccs_dollars_counted_twice": 90.0}
