"""
End-to-end run of the REAL notebooks, in README order, on a local Spark (no Databricks).

    SPARK_HOME=... PYTHONPATH=<pyspark> python tests/e2e_local_spark.py [--keep] [--demos]

What is real: every notebook's source, every module, Spark SQL (ANSI mode on, as on DBR 17),
the fixture PDF (AHCCCS Chapter 10 layout). What is simulated: the claims and NCCI tables
(synthetic, real column names), tables are parquet instead of Delta, the model is the STUB
pattern backend, and the SME review is filled in by this script.

Scenario:
  1  00_acquire_ncci (drop zone, CMS-shaped zips) + hand-loaded-style NCCI table for an older quarter
  2  01_preflight_ncci, 02_migrate_state_rules (twice: must be idempotent, must keep reviews)
  3  03_stage -> 04_extract (STUB) -> 05_persist -> reviewer approves -> 06_review_decisions
  4  07_build_kb -> 08_run_detectors; assert findings for the planted violations
  5  the Ch10 PDF is REVISED -> re-extract -> approved rules become needs_review, 07_build_kb
     excludes nothing stale that was re-signed... and 08 still runs
  5b (v5.2) the AHCCCS rule tables: 00b loads 4 synthetic versions (twice: the second run loads nothing); 07 with the
     readings as shipped builds no table rule; with Same Day + daily signed it builds those two, B2 held back; with all
     signed, B2 too; 08 finds exactly the planted table violations (t30..t48 in make_claims); a table edited in the catalog stops 07
  6  (--demos) every notebook under notebooks/demos and notebooks/validation
"""
from __future__ import annotations

import io
import json
import os
import shutil
import sys
import tempfile
import time
import traceback
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ROOT = os.environ.get("E2E_ROOT", os.path.join(tempfile.gettempdir(), "pie_e2e"))
KEEP = "--keep" in sys.argv
DEMOS = "--demos" in sys.argv

if not KEEP and os.path.exists(ROOT):
    shutil.rmtree(ROOT)
os.makedirs(ROOT, exist_ok=True)
os.environ.update({
    "PKB_PACKAGE_DIR": PKG, "PKB_CATALOG": "spark_catalog", "PKB_OUTPUT_CATALOG": "spark_catalog",
    "PKB_CLAIMS": "spark_catalog.prod_input.all_data_c_a", "PKB_TABLE_FORMAT": "parquet",
    "PKB_WORKSPACE_DATA_DIR": os.path.join(ROOT, "data"), "PKB_NCCI_RAW_DIR": os.path.join(ROOT, "data", "ncci_raw"),
})
sys.path.insert(0, PKG)
sys.path.insert(0, HERE)

import pandas as pd  # noqa: E402
from pyspark.sql import SparkSession  # noqa: E402

spark = (SparkSession.builder.master("local[2]").appName("pie-e2e")
         .config("spark.ui.enabled", "false").config("spark.sql.ansi.enabled", "true")
         .config("spark.sql.warehouse.dir", os.path.join(ROOT, "warehouse"))
         .config("spark.sql.shuffle.partitions", "4").config("spark.driver.memory", "2g")
         .config("spark.sql.codegen.fallback", "false").getOrCreate())     # code too big to compile = a failure
spark.sparkContext.setLogLevel("ERROR")
for s in ("sedo", "policy_kb", "prod_input"):
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS spark_catalog.{s}")

import config  # noqa: E402

DISPLAYED: list = []


def display(x):
    DISPLAYED.append(x)
    try:
        df = x.toPandas() if hasattr(x, "toPandas") else x
        print(df.head(12).to_string() if hasattr(df, "to_string") else df)
    except Exception as e:                       # display must never be the thing that fails
        print(f"[display] {type(e).__name__}: {e}")


class _Lib:
    def restartPython(self):
        pass


class _DBU:
    library = _Lib()

    class widgets:
        @staticmethod
        def get(name):
            raise Exception("no widgets locally")


def run_nb(rel: str, subs: dict | None = None):
    path = os.path.join(PKG, "notebooks", rel)
    src = open(path).read()
    for old, new in (subs or {}).items():
        assert old in src, f"{rel}: substitution target not found: {old!r}"
        src = src.replace(old, new)
    g = {"spark": spark, "display": display, "dbutils": _DBU(), "__name__": "__main__", "__file__": path}
    t0 = time.time()
    print(f"\n{'=' * 100}\n>>> {rel}\n{'=' * 100}")
    cwd = os.getcwd()
    os.chdir(os.path.dirname(path))
    try:
        exec(compile(src, path, "exec"), g)
    finally:
        os.chdir(cwd)
    print(f"<<< {rel} OK ({time.time() - t0:.1f}s)")
    return g


def T(name):
    return spark.table(f"spark_catalog.{name}").toPandas()


# ---------------------------------------------------------------- fixtures
def make_claims():
    """Planted violations (all on 2026-01-15 unless noted):
       m1/p1: 11111 + 22222 same provider, no modifier        -> NCCI PTP hard denial (indicator 0)
       m2/p1: 33333 + 44444, 59 on one line                    -> bypassed (indicator 1) -> no finding
       m3/p1: J3490 x 5 units                                   -> NCCI MUE 1/line
       m4:    98960 x 3 + 98961 x 2 same day                    -> Ch10 CHW 4/day seed + same-day pair seed
       m5:    11975                                             -> Ch10 'do not bill' (not covered)"""
    C = config.CLAIM_COLS
    rows = []

    def add(cid, ln, mem, prov, dos, code, units, paid, m1="", pa=None, form="A", dob="1980-01-01", pt="08", bt="same",
            bprov=None):
        bt = pt if bt == "same" else bt                  # BILLING provider type: by default the provider bills itself
        rows.append({C["claim_id"]: cid, C["line_no"]: ln, C["member"]: mem, C["servicing_provider"]: prov,
                     C["billing_provider"]: bprov or prov, C["dos"]: dos, C["code"]: code, C["units"]: units,
                     C["paid_amt"]: paid, C["pos"]: "11", C["form"]: form, C["mods"][0]: m1, C["mods"][1]: "",
                     C["mods"][2]: "", C["mods"][3]: "", C["pa_no"]: pa, C["dob"]: dob, C["prov_type"]: pt,
                     "SProv_Type_Desc": "MD-Physician" if pt == "08" else None, C["billing_type"]: bt,
                     "BProv_Type_Desc": {"08": "MD-Physician", "02": "Hospital"}.get(bt)})
    add("c1", 1, "m1", "p1", "2026-01-15", "11111", 1, 100.0)
    add("c1", 2, "m1", "p1", "2026-01-15", "22222", 1, 60.0)
    add("c2", 1, "m2", "p1", "2026-01-15", "33333", 1, 80.0)
    add("c2", 2, "m2", "p1", "2026-01-15", "44444", 1, 40.0, m1="59")
    add("c3", 1, "m3", "p2", "2026-01-15", "J3490", 5, 25.0)
    add("c4", 1, "m4", "p3", "2026-01-15", "98960", 3, 30.0)
    add("c4", 2, "m4", "p3", "2026-01-15", "98961", 2, 20.0, pa="PA123")
    add("c5", 1, "m5", "p4", "2026-02-01", "11975", 1, 300.0)
    # v5 (2026-10-02) - things that must NOT be findings:
    add("d6", 1, "m6", "p5", "2026-01-15", "11111", 1, 50.0, form="D")     # dental form: NCCI never applies
    add("d6", 2, "m6", "p5", "2026-01-15", "22222", 1, 50.0, form="D")
    add("z7", 1, "m7", "p6", "2026-01-15", "11111", 1, 80.0)               # Column Two paid $0
    add("z7", 2, "m7", "p6", "2026-01-15", "22222", 1, 0.0)
    add("r8", 1, "m8", "p7", "2026-02-01", "11975", 1, 300.0)              # paid, then reversed
    add("r8R", 1, "m8", "p7", "2026-02-01", "11975", -1, -300.0)
    add("c9", 1, "m9", "p8", "2026-01-15", "j3490 ", 5, 25.0)              # padded / lower-case code: still an MUE
    add("c9", 1, "m9", "p8", "2026-01-15", "j3490 ", 5, 25.0)              # ...loaded twice: still ONE finding
    # 2026-10-03: the NCCI edit file comes from the servicing provider type x form (CMS TGM Table 2)
    add("q10", 1, "m10", "p9", "2026-01-15", "11111", 1, 70.0, pt="30")    # DME supplier: DME file, not practitioner
    add("q10", 2, "m10", "p9", "2026-01-15", "22222", 1, 70.0, pt="30")
    add("q11", 1, "m11", "p9", "2026-01-15", "11111", 1, 70.0, pt="8")     # '8' == '08' (numeric code column)
    add("q11", 2, "m11", "p9", "2026-01-15", "22222", 1, 70.0, pt="8")
    # 2026-10-03 (BProv_Type): the BILLING provider type picks the Table 2 row - a hospital billing a physician's
    # service takes the OUTPATIENT file, so the practitioner edit loaded here does not judge it
    add("q12", 1, "m12", "p9", "2026-01-15", "11111", 1, 70.0, bt="02")
    add("q12", 2, "m12", "p9", "2026-01-15", "22222", 1, 70.0, bt="02")
    add("q13", 1, "m13", "p9", "2026-01-15", "11111", 1, 70.0, bt=" none ")  # textual null = missing -> servicing 08
    add("q13", 2, "m13", "p9", "2026-01-15", "22222", 1, 70.0, bt=" none ")
    # 2026-10-04 (v5.2): the AHCCCS rule tables, as written by tables_fixtures() - Same Day Disallow (version 2026-01-01):
    # H0001 x H0014 = D (any provider), H0001 x H0035 = A* (same provider), H0001 x S5151 = A (no rule); daily limits
    # (versions 2026-01-01 and 2026-03-01): H0004 32, then 48, units per member + provider + day; B2 (2026-01-01): H0035
    # billed only by provider types 02 / 71 / B5 / B6. The ROW code's line (H0001) is the pair finding.
    add("t30a", 1, "m30", "p30", "2026-01-20", "H0014", 1, 150.0)
    add("t30b", 1, "m30", "p31", "2026-01-20", "H0001", 1, 90.0)          # D, another provider -> finding
    add("t31", 1, "m31", "p32", "2026-01-20", "H0035", 1, 200.0, bt="02")
    add("t31", 2, "m31", "p32", "2026-01-20", "H0001", 1, 90.0)           # A*, same provider -> finding
    add("t32a", 1, "m32", "p33", "2026-01-20", "H0035", 1, 200.0, bt="02")
    add("t32b", 1, "m32", "p34", "2026-01-20", "H0001", 1, 90.0)          # A*, another provider -> none
    add("t33", 1, "m33", "p35", "2026-01-20", "S5151", 1, 120.0)
    add("t33", 2, "m33", "p35", "2026-01-20", "H0001", 1, 90.0)           # A -> none
    add("t34", 1, "m34", "p36", "2026-01-20", "H0004", 40, 400.0)         # 40 > 32 -> finding
    add("t35a", 1, "m35", "p37", "2026-01-20", "H0004", 20, 200.0)        # 20 + 20 from two providers -> none
    add("t35b", 1, "m35", "p38", "2026-01-20", "H0004", 20, 200.0)
    add("t36", 1, "m36", "p39", "2025-12-15", "H0004", 40, 400.0)         # before the oldest version -> not judged
    add("t37", 1, "m37", "p40", "2026-01-20", "H0035", 1, 200.0, bt="77")  # a BH clinic (77) billing H0035 -> B2 finding
    add("t38a", 1, "m38", "p41", "2026-01-20", "H0014", 1, 150.0)
    add("t38b", 1, "m38", "p42", "2026-01-20", "H0001", 1, 90.0, pa="PA777")  # D with a PA on file -> verify_pa
    add("t39", 1, "m39", "p43", "2026-03-05", "H0004", 40, 400.0)         # the 2026-03-01 version: 40 <= 48 -> none
    add("t40", 1, "m40", "p44", "2026-03-05", "H0004", 50, 500.0)         # the 2026-03-01 version: 50 > 48 -> finding
    # 2026-10-04 (v5.2b, QUERY_SEMANTICS v2.6, after the independent critic):
    add("t41", 1, "m41", "p49", "2026-01-20", "H0035", 1, 200.0, bt="01")   # a GROUP (01) billing, rendering 08 -> B2
    add("t42", 1, "m42", "p50", "2026-01-20", "H0035", 1, 200.0, pt="71", bt="01")   # group, rendering 71 -> none
    add("t43", 1, "m43", "p51", "2026-01-20", "H0035", 1, 200.0, bt="02", bprov="g1")  # A*: same servicing p51 ...
    add("t43", 2, "m43", "p51", "2026-01-20", "H0001", 1, 90.0, bprov="g2")           # ... other billing id -> none
    add("t44", 1, "m44", "p52", "2026-01-20", "H0004", 20, 200.0)        # 20 + 20 on two lines -> units_over_limit
    add("t44", 2, "m44", "p52", "2026-01-20", "H0004", 20, 200.0)
    add("t45", 1, "m45", "p53", "2026-01-20", "H0004", 20, 200.0, m1="59")   # ... one line with 59 -> verify_modifier
    add("t45", 2, "m45", "p53", "2026-01-20", "H0004", 20, 200.0)
    add("t46", 1, "m46", "p54", "2026-01-20", "01967", 8, 640.0)         # anesthesia (time units): recorded only
    add("t48", 1, "m48", "p55", "2026-01-20", "J7190", 3500, 7000.0)     # an all-nines maximum (999): recorded only
    add("t47", 1, "m47", "p47", "2026-01-20", "H0014", 1, 150.0)         # H0014 x H0035 disallowed BOTH ways ->
    add("t47", 2, "m47", "p48", "2026-01-20", "H0035", 1, 200.0, bt="02")  # both lines, dollars counted twice: 150
    for i in range(40):                                     # background volume, no violations
        add(f"bg{i}", 1, f"b{i % 7}", "p9", "2025-11-0" + str(1 + i % 9), "99213", 1, 75.0)
    df = pd.DataFrame(rows)
    import kb_io
    sdf = kb_io.to_spark(spark, df)
    from pyspark.sql import functions as F
    sdf = (sdf.withColumn(C["dos"], F.to_date(C["dos"])).withColumn(C["dob"], F.to_date(C["dob"]))
              .withColumn(C["units"], F.col(C["units"]).cast("decimal(15,4)"))
              .withColumn(C["paid_amt"], F.col(C["paid_amt"]).cast("decimal(15,2)")))
    sdf.write.mode("overwrite").format("parquet").saveAsTable(config.CLAIMS_TABLE)


def cms_zip(path, member, text):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(member, text)


def make_ncci():
    raw = os.path.join(config.NCCI_RAW_DIR, "2026q1")
    os.makedirs(raw, exist_ok=True)
    ptp = ("Medicaid NCCI PTP Edits - Practitioner Services\n"
           "Quarter Begin Date\tCategory\tColumn One\tColumn Two\tEffective Date\tDeletion Date\tModifier Indicator\tPTP Edit Rationale\n"
           "20260101\tPractitioner\t11111\t22222\t20100101\t*\t0\tMutually exclusive procedures\n"
           "20260101\tPractitioner\t33333\t44444\t20100101\t*\t1\tMisuse of column two code\n"
           "20260101\tPractitioner\t98960\t98961\t20100101\t*\t1\tStandard\n")
    mue = ("Quarter Begin Date\tCategory\tHCPCS/CPT Code\tPractitioner Services MUE Values\tMUE Rationale\n"
           "20260101\tPractitioner\tJ3490\t1\tNature of Service\n"
           "20260101\tPractitioner\t98960\t8\tClinical\n")
    cms_zip(os.path.join(raw, "medicaid-ncci-2026-q1-ptp-edits-practitioner-services.zip"), "PTP.txt", ptp)
    cms_zip(os.path.join(raw, "medicaid-ncci-2026-q1-mue-edits-practitioner-services.zip"), "MUE.txt", mue)
    # an OLDER quarter loaded the old manual way (SB's column names), so ingest sees both shapes
    old = pd.DataFrame({"HCPCS/CPT Code": ["J3490", "98960"], "Practitioner Services MUE Values": [1, 8],
                        "MUE Rationale": ["Nature of Service", "Clinical"]})
    (spark.createDataFrame(old).toDF("HCPCS_CPT_Code_manual", "Practitioner_Services_MUE_Values", "MUE_Rationale")
     .write.mode("overwrite").format("parquet")
     .saveAsTable(f"spark_catalog.sedo.medicaid_ncci_edit_practitioner_mue_q4_2025"))


def fixture_pdf(dest_dir, revised=False):
    import fixture_pdf
    os.makedirs(dest_dir, exist_ok=True)
    path = os.path.join(dest_dir, os.path.basename(config.CHAPTERS["10"][1]))
    fixture_pdf.build(path)
    if revised:                                            # a revision = new bytes = new doc_hash
        with open(path, "ab") as f:
            f.write(b"\n% revised 2026-10-01\n")
    return path


def tables_fixtures():
    """v5.2: synthetic AHCCCS rule-table workbooks in the real layouts (tests/test_ahcccs_tables builders), dropped where
    00b looks: Same Day Disallow and B2 dated 2026-01-01; daily limits dated 2026-01-01 (in a sub-folder, any name) and
    2026-03-01 (H0004 raised from 32 to 48). Returns {path: table_key}."""
    import test_ahcccs_tables as tat
    tdir = config.AHCCCS_TABLES_DIR
    os.makedirs(os.path.join(tdir, "earlier"), exist_ok=True)
    # v5.2b: an anesthesia code (max 1, billed in time units) and an all-nines maximum - both recorded, never compiled
    extra = [("01967  - NEURAXIAL LABOR ANALGESIA/ANESTHESIA FOR PLANNED VAGINAL DELIVERY", "000001", "   ", "   ", " ",
              "   ", "   ", " "),
             ("J7190  - FACTOR VIII (ANTIHEMOPHILIC FACTOR, HUMAN) PER I.U.", "000999", "   ", "   ", " ", "   ", "   ", " ")]
    daily_jan = list(tat.DAILY_ROWS) + extra
    daily_mar = [(r[0], "000048") + tuple(r[2:]) if r[0].startswith("H0004") else r for r in daily_jan]
    # v5.2b: H0035 as a ROW too - H0014 x H0035 is then D in both directions (both_ways)
    sd_rows = list(tat.SD_ROWS) + [("H0035", "Mental health partial hospitalization, less than 24 hours", "Per Diem",
                                    ["D", "D", "A"])]
    return {tat.same_day_xlsx(os.path.join(tdir, "SameDayDisallowTable.xlsx"), updated="1/1/2026",
                              rows=sd_rows): "same_day_disallow",
            tat.daily_xlsx(os.path.join(tdir, "earlier", "limits_jan.xlsx"), as_of="1/1/26",
                           rows=daily_jan): "daily_limits",
            tat.daily_xlsx(os.path.join(tdir, "HCPCSCPTProcedureswithDailyLimits.xlsx"), as_of="3/1/26",
                           rows=daily_mar): "daily_limits",
            tat.b2_xlsx(os.path.join(tdir, "B2Matrix.xlsx"), as_of="1/1/26"): "b2_matrix"}


def readings_copy(sign_tables, name):
    """reference/ahcccs_table_readings.csv with every reading of `sign_tables` signed by a named reviewer."""
    import csv
    with open(os.path.join(PKG, "reference", "ahcccs_table_readings.csv"), newline="", encoding="utf-8") as fh:
        rows_ = list(csv.DictReader(fh))
    out = os.path.join(ROOT, name)
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w_ = csv.DictWriter(fh, fieldnames=list(rows_[0]))
        w_.writeheader()
        for r_ in rows_:
            w_.writerow({**r_, **({"status": "signed", "reviewer": "e2e reviewer", "reviewed_at": "2026-10-04"}
                                  if r_["table_key"] in sign_tables else {})})
    return out


def last_build():
    """The newest build log row (build ids are B<timestamp>: they sort by time; parquet keeps no row order)."""
    return T("policy_kb.policy_build_log").sort_values("build_id").iloc[-1]


def latest_run_findings():
    f_ = T("policy_kb.policy_findings")
    return f_[f_["run_id"] == f_["run_id"].max()]


def approve_all(reviewer="SB (e2e)", note=None):
    import state_rules
    wb = os.path.join(config.WORKSPACE_DATA_DIR, "review", "policy_rules_review.xlsx")
    df = pd.read_excel(wb)
    df["decision"] = "Approve"
    df["reviewer"] = reviewer
    if note:
        df["review_note"] = note
    df.to_excel(wb, index=False)
    return len(df)


# ------------------------------------------------------------------ scenario
FAIL = []


def check(cond, msg):
    print(("  PASS  " if cond else "  FAIL  ") + msg)
    if not cond:
        FAIL.append(msg)


def main():
    make_claims()
    make_ncci()
    pdf_dir = config.STAGE_PDF_DIR
    fixture_pdf(pdf_dir)

    run_nb("00_acquire_ncci.py", {"DOWNLOAD         = True": "DOWNLOAD         = False"})
    log = T("sedo.ncci_acquisition_log")
    check(set(log["status"]) == {"loaded"}, f"acquire: both CMS zips loaded ({log['status'].tolist()})")
    run_nb("01_preflight_ncci.py")

    run_nb("02_migrate_state_rules.py")
    n_seed = len(T("sedo.state_rules"))
    check(n_seed > 0, f"migrate: {n_seed} seed rows")

    stage_subs = {"CHAPTERS_TO_STAGE = list(config.CHAPTERS)": 'CHAPTERS_TO_STAGE = ["10"]',
                  "DOWNLOAD          = True": "DOWNLOAD          = False"}
    gpu_subs = {'CHAPTERS_TO_RUN = ["19"]': 'CHAPTERS_TO_RUN = ["10"]',
                'LLM_BACKEND     = "HYBRID"': 'LLM_BACKEND     = "STUB"',
                "ALLOW_PATTERNS_ONLY = False": "ALLOW_PATTERNS_ONLY = True"}
    run_nb("03_stage_inputs.py", stage_subs)
    run_nb("04_extract_chapters_gpu.py", gpu_subs)
    run_nb("05_persist_extraction.py")
    sr = T("sedo.state_rules")
    drafts = sr[sr["review_status"] == "draft"]
    check(len(drafts) > 0, f"extraction: {len(drafts)} drafts from the fixture PDF")
    check(drafts["extraction_source"].notna().all(), "drafts carry extraction_source")
    outc = T("policy_kb.policy_extraction_outcomes")
    check(len(outc) > 0 and set(outc["outcome"]) >= {"proposals"}, f"outcomes recorded: {outc['outcome'].value_counts().to_dict()}")

    n = approve_all()
    run_nb("06_review_decisions.py")
    sr = T("sedo.state_rules")
    check((sr["review_status"] == "approved").sum() == n, f"review: {n} approved with a named reviewer")

    run_nb("02_migrate_state_rules.py")                     # D6: re-run must keep the approvals
    sr2 = T("sedo.state_rules")
    check((sr2["review_status"] == "approved").sum() == n and len(sr2) == len(sr), "migrate re-run kept every review (D6)")

    run_nb("07_build_kb.py")
    bl = last_build()
    check(bl["detectors_batched"] > 0, f"build: {bl['detectors_batched']} NCCI rules batched, {bl['detectors_compiled']} compiled")
    # 2026-10-04 (SB, fresh start): one engine in the KB - no hand-authored rule, every extracted rule from a v2 run
    pr = T("policy_kb.policy_rules")
    check(not (pr["origin"] == "manual").any() and (pr["origin"] == "extracted").any()
          and json.loads(bl["kb_prompt_versions"]) == ["v2"] and json.loads(bl["engine_excluded"]) == {}
          and not bool(bl["compile_hand_authored"]),
          "build: one engine in the KB - no hand-authored rule compiles, every extracted rule comes from a prompt-v2 run")
    check(str(bl.get("ncci_rules_scope")) == "executable_against_claims"
          and '"source_rows"' in str(bl.get("ncci_source_vs_claims_scope")),
          "build log: NCCI rules counted as edits executable against these claims, next to the CMS files' sizes")
    check(str(bl.get("corpus_version") or "").startswith("corpus-") and "same_day_disallow" in str(bl.get("corpus_pending")),
          f"build log: corpus_version {bl.get('corpus_version')} and the sources still to load")

    # 2026-10-04 (external review): NCCI runs only on SIGNED routing. The shipped table is PROPOSED, so 08 must record
    # both NCCI statements as not run - and still run the state rules
    run_nb("08_run_detectors.py")
    runs0 = T("policy_kb.policy_detector_runs")
    r0 = runs0[runs0["run_id"] == runs0["run_id"].max()]
    b0 = r0[r0["rule_id"].astype(str).str.startswith("BATCH:ncci_")]          # v5.2: + 3 AHCCCS table statements
    check(len(b0) == 2 and b0["skipped"].astype(str).str.contains("have no SIGNED routing row").all(),
          f"08 on the unsigned routing table: both NCCI statements not run ({b0['skipped'].astype(str).str[:70].tolist()})")
    f0 = T("policy_kb.policy_findings")
    f0 = f0[f0["run_id"] == r0["run_id"].iloc[0]]
    check(not (f0["origin"] == "ncci").any() and ((f0["origin"] != "ncci") & (f0["claim_id"] == "c5")).any(),
          "... no NCCI finding in that run; the state rules still ran (c5)")
    snap0 = str(r0[r0["rule_id"] == "RUN:snapshot"]["error"].iloc[0])
    check('"ncci_routing": "unsigned"' in snap0 and '"ncci_gate": "not run' in snap0,
          "... and the run log says the routing was unsigned and why NCCI did not run")
    check(bool(r0["partial_run"].astype(bool).all()), "... and the run is marked partial (NCCI held back)")
    # a reviewer signs the rows (here: a signed copy of the whole table; in Databricks, the CSV in reference/)
    import csv
    src_tbl = os.path.join(PKG, "reference", "ncci_provider_type_routing.csv")
    with open(src_tbl, newline="", encoding="utf-8") as fh:
        rows_t = list(csv.DictReader(fh))
    for r_ in rows_t:
        r_.update(status="signed", reviewer="e2e reviewer", reviewed_at="2026-10-04")
    signed_tbl = os.path.join(ROOT, "ncci_provider_type_routing_SIGNED_e2e.csv")
    with open(signed_tbl, "w", newline="", encoding="utf-8") as fh:
        w_ = csv.DictWriter(fh, fieldnames=list(rows_t[0]))
        w_.writeheader()
        w_.writerows(rows_t)
    os.environ["PKB_NCCI_PROVIDER_TYPE_TABLE"] = signed_tbl          # read by config on the notebooks' reload

    run_nb("08_run_detectors.py")
    runs1 = T("policy_kb.policy_detector_runs")
    r1_ = runs1[runs1["run_id"] == runs1["run_id"].max()]
    check('"ncci_routing": "signed"' in str(r1_[r1_["rule_id"] == "RUN:snapshot"]["error"].iloc[0])
          and r1_[r1_["rule_id"].astype(str).str.startswith("BATCH:ncci_")]["skipped"].isna().all(),
          "08 on the signed routing table: both NCCI statements run")
    f = T("policy_kb.policy_findings")
    f_n = f[(f["run_id"] == f["run_id"].max()) & (f["origin"] == "ncci")]
    check(len(f_n) > 0 and (f_n["ncci_routing"] == "signed").all() and not bool(r1_["partial_run"].astype(bool).any()),
          "every NCCI finding says ncci_routing = 'signed'; the run is complete")
    last = f[f["run_id"] == f["run_id"].max()]
    got = {(r.origin, r.predicate_type, r.claim_id) for r in last.itertuples()}
    print(last[["origin", "predicate_type", "rule_id", "claim_id", "line_no", "finding", "paid_amt", "pa_status"]].to_string())
    check(("ncci", "code_pair_prohibited", "c1") in got, "PTP hard denial found on the Column Two line (c1)")
    check(not any(k[2] == "c2" and k[1] == "code_pair_prohibited" and k[0] == "ncci" for k in got), "59-bypassed pair NOT flagged")
    check(("ncci", "max_units_per_line", "c3") in got, "MUE J3490 5 > 1 found")
    check(any(k[0] != "ncci" and k[2] == "c5" for k in got), "state 'do not bill 11975' found")
    # v5: the critics' false-positive classes are not findings
    check(not any(k[2] == "d6" for k in got), "dental (form D) lines are never judged by NCCI")
    check(not any(k[2] == "q10" and k[0] == "ncci" for k in got),
          "a DME supplier's lines never take the practitioner edit file (provider type x form, CMS Table 2)")
    check(("ncci", "code_pair_prohibited", "q11") in got, "provider type '8' is read as '08' (practitioner file)")
    check(not any(k[2] == "q12" and k[0] == "ncci" for k in got),
          "a hospital (BProv_Type 02) billing a physician's service takes the outpatient file, not the practitioner one")
    check(("ncci", "code_pair_prohibited", "q13") in got,
          "BProv_Type ' none ' (missing) falls back to the servicing type (08): practitioner file")
    check(not any(k[2] == "z7" for k in got), "a $0 Column Two line is not a finding")
    check(not any(k[2] in ("r8", "r8R") for k in got), "a paid line and its reversal are not findings")
    c9 = last[(last["claim_id"] == "c9") & (last["origin"] == "ncci")]
    check(len(c9) == 1, f"padded lower-case 'j3490 ' loaded twice -> exactly one MUE finding ({len(c9)})")
    chw = last[(last["member_id"] == "m4") & (last["predicate_type"] == "max_units_per_day")]
    check(len(chw) >= 1 and float(chw["observed_units"].max()) == 5.0,
          f"CHW combined daily cap: 98960 x3 + 98961 x2 = 5 > 4 found ({len(chw)} finding(s))")
    check(last["finding_id"].notna().all() and last["finding_id"].is_unique, "every finding has a unique finding_id")
    runs = T("policy_kb.policy_detector_runs")
    snap = runs[(runs["run_id"] == last["run_id"].iloc[0]) & (runs["rule_id"] == "RUN:snapshot")]
    check(len(snap) == 1 and '"source_rows"' in str(snap["error"].iloc[0]), "the run logged its snapshot numbers")
    dh = T("policy_kb.policy_detectors_history")
    comp = dh[(dh["build_id"] == bl["build_id"]) & (dh["compiled"] == True) & dh["batch"].isna()]
    check(len(comp) > 0 and comp["sql"].notna().all() and comp["sql_sha256"].notna().all(),
          f"policy_detectors_history keeps the SQL and its sha256 ({len(comp)} state queries)")
    bh = T("policy_kb.policy_batch_detectors_history")
    check(set(bh[bh["build_id"] == bl["build_id"]]["batch"]) == {"ncci_ptp", "ncci_mue", "ahcccs_same_day",
                                                                  "ahcccs_daily_max", "ahcccs_provider_type"},
          "batch SQL history kept (2 NCCI + 3 AHCCCS table statements, always written)")
    check(json.loads(bl["ahcccs_rules_by_batch"]) == {"ahcccs_same_day": 0, "ahcccs_daily_max": 0,
                                                      "ahcccs_provider_type": 0}
          and "not loaded" in str(bl["ahcccs_tables"]),
          "before 00b: the three AHCCCS table statements are built with 0 rules (tables not loaded, said so)")
    check(str(bl.get("status")) == "complete", "build log row says complete")

    # ---- C4-01: 08 must refuse a half-written build
    bd = T("policy_kb.policy_batch_detectors")
    bd["build_id"] = "B_OLD_HALF_WRITTEN"
    import kb_io
    kb_io.write_table(spark, bd, "spark_catalog.policy_kb.policy_batch_detectors", "overwrite")
    try:
        run_nb("08_run_detectors.py")
        check(False, "08 refused a half-written build")
    except RuntimeError as e:
        check("BUILD CHECK FAILED" in str(e), "08 refused a half-written build (build ids differ)")
    run_nb("07_build_kb.py")                                   # a full build restores consistency
    check(last["build_id"].notna().all() and last["paid_amt"].notna().all(), "findings carry build_id and paid_amt")
    hist = T("policy_kb.policy_rules_history")
    j = last.merge(hist, on=["build_id", "rule_id"], how="left")
    check(j["statement"].notna().all(), "every finding joins policy_rules_history on (build_id, rule_id)")

    # ---- a PDF revision: approvals must go back for re-sign and stop compiling until then
    fixture_pdf(pdf_dir, revised=True)
    run_nb("03_stage_inputs.py", stage_subs)
    run_nb("04_extract_chapters_gpu.py", gpu_subs)
    run_nb("05_persist_extraction.py")
    sr3 = T("sedo.state_rules")
    ext = sr3[sr3["origin"] == "extracted"]
    check((ext["review_status"] == "needs_review").all() and ext["prior_review"].notna().all(),
          f"revision: extracted approvals -> needs_review with prior_review ({ext['review_status'].value_counts().to_dict()})")
    run_nb("07_build_kb.py")
    rules = T("policy_kb.policy_rules")
    check(not (rules["origin"] == "extracted").any(), "revision: no extracted rule compiles until re-signed (D5)")
    approve_all("SB (e2e) re-sign", note="re-read against the revised PDF")
    run_nb("06_review_decisions.py")
    run_nb("07_build_kb.py")
    rules = T("policy_kb.policy_rules")
    check((rules["origin"] == "extracted").any(), "after re-sign: extracted rules compile again")
    # every draft of every run is kept per run (v01 samples the LATEST run's own drafts, not rows an older run left)
    dr = T("policy_kb.policy_extraction_drafts")
    runs_x = sorted(dr["run_id"].dropna().astype(str).unique())
    check(len(runs_x) == 2 and (dr["run_id"] == runs_x[-1]).sum() > 0,
          f"policy_extraction_drafts keeps both extraction runs' drafts ({runs_x})")
    LATEST_X = runs_x[-1]
    run_nb("08_run_detectors.py")

    # ---- v5.2 (2026-10-04): the AHCCCS rule tables - load (00b), governance gate (readings), build, detect
    import ahcccs_tables as at
    fixtures = tables_fixtures()
    run_nb("00b_load_ahcccs_tables.py")
    tl = T("sedo.ahcccs_table_log")
    want_rows = {}
    for p_, k_ in fixtures.items():
        want_rows[k_] = want_rows.get(k_, 0) + len(at.parse_file(p_)["frame"])
    got_rows = {k_: spark.table(config.AHCCCS_TABLES[k_]["table"]).count() for k_ in at.TABLE_KEYS}
    check(len(tl) == 4 and set(tl["status"]) == {"loaded"}
          and tl.groupby("table_key")["version_date"].apply(sorted).to_dict()
          == {"b2_matrix": ["2026-01-01"], "daily_limits": ["2026-01-01", "2026-03-01"],
              "same_day_disallow": ["2026-01-01"]} and got_rows == want_rows,
          f"00b: 4 versions loaded (daily limits twice, one from a sub-folder) with every parsed row ({got_rows})")
    check(all(os.path.exists(str(p_)) for p_ in tl["archived_path"]), "00b archived every original under _versions/")
    run_nb("00b_load_ahcccs_tables.py")
    tl2 = T("sedo.ahcccs_table_log")
    check(len(tl2) == 8 and int((tl2["status"] == "already_loaded").sum()) == 4
          and {k_: spark.table(config.AHCCCS_TABLES[k_]["table"]).count() for k_ in at.TABLE_KEYS} == got_rows,
          "00b re-run: every file already_loaded, no row appended")

    TB = ("ahcccs_same_day", "ahcccs_daily_max", "ahcccs_provider_type")
    run_nb("07_build_kb.py")                                    # the readings as shipped: proposed, nothing builds
    blt = last_build()
    held = json.loads(blt["ahcccs_held_back_unsigned"])
    check(json.loads(blt["ahcccs_rules_by_batch"]) == {k_: 0 for k_ in TB} and set(held) == set(at.TABLE_KEYS)
          and all(held[k_] for k_ in held) and json.loads(blt["corpus_pending"]).count("same_day_disallow") == 0,
          f"07 with the shipped (proposed) readings: tables loaded, no table rule built, unsigned readings listed "
          f"({ {k_: len(v) for k_, v in held.items()} }); the loaded tables leave corpus_pending")
    os.environ["PKB_AHCCCS_TABLE_READINGS"] = readings_copy({"same_day_disallow", "daily_limits"},
                                                            "ahcccs_table_readings_partial_e2e.csv")
    run_nb("07_build_kb.py")
    blt = last_build()
    nbt = json.loads(blt["ahcccs_rules_by_batch"])
    check(nbt["ahcccs_same_day"] == 5 and nbt["ahcccs_daily_max"] == 6 and nbt["ahcccs_provider_type"] == 0
          and list(json.loads(blt["ahcccs_held_back_unsigned"])) == ["b2_matrix"],
          f"07 with Same Day + daily readings signed, B2 not: 5 in-scope pairs (D / A* only, no diagonal, both codes "
          f"paid), 6 daily limits (3 codes x 2 versions; the anesthesia and all-nines rows recorded only), B2 held back "
          f"({nbt})")
    prt = T("policy_kb.policy_rules")
    prt = prt[prt["origin"] == "ahcccs_table"]
    check(len(prt) > 0 and prt["rule_id"].astype(str).str.startswith("TBL-").all()
          and (prt["review_status"] == "state_table").all() and prt["source_url"].notna().all()
          and prt["doc_hash"].notna().all() and not prt["codes"].astype(str).str.contains("T1016|81286|01967|J7190").any(),
          "table rules: TBL- ids, review_status state_table, cite the file (url + sha256), scoped to paid codes; no rule "
          "for the anesthesia / all-nines rows")
    cf0 = T("policy_kb.policy_ahcccs_conflicts")
    check({"not_compiled_anesthesia_time_units", "not_compiled_placeholder_maximum"}
          <= set(cf0["relationship"].astype(str)),
          "the anesthesia and all-nines daily rows are listed for SB in policy_ahcccs_conflicts")
    run_nb("08_run_detectors.py")
    ft = latest_run_findings()
    ft = ft[ft["origin"] == "ahcccs_table"]
    print(ft[["batch", "rule_id", "claim_id", "line_no", "member_id", "dos", "finding_severity", "pa_status",
              "evidence_lines", "observed_units", "allowed_units", "finding"]].to_string())
    pairs = {(r.claim_id, str(r.line_no)): r for r in ft[ft["batch"] == "ahcccs_same_day"].itertuples()}
    want_pairs = {("t30b", "1"), ("t31", "2"), ("t38b", "1"), ("t47", "1"), ("t47", "2")}
    check(set(pairs) == want_pairs,
          f"Same Day: D any provider (t30b), A* same servicing AND billing id (t31), D with PA (t38b), a pair disallowed "
          f"both ways (both t47 lines) - the ROW code's line; nothing for A* across providers (t32), A* with another "
          f"billing id (t43), A (t33), or the column code's line ({sorted(pairs)})")
    check(set(pairs) == want_pairs
          and pairs[("t30b", "1")].finding_severity == "verify_exception"
          and pairs[("t31", "2")].finding_severity == "verify_exception"
          and pairs[("t38b", "1")].finding_severity == "verify_pa" and pairs[("t38b", "1")].pa_status == "pa_on_file"
          and "t30a:1" in str(pairs[("t30b", "1")].evidence_lines)
          and all("both ways" in str(pairs[("t47", ln)].finding) for ln in ("1", "2"))
          and "both ways" not in str(pairs[("t30b", "1")].finding),
          "Same Day findings are verify_exception (table note 2), verify_pa with a PA on file; the column line is "
          "evidence; only the both-ways pair says so in its finding")
    daily = ft[ft["batch"] == "ahcccs_daily_max"]
    got_daily = {r.member_id: (int(r.allowed_units), r.finding_severity) for r in daily.itertuples()}
    check(got_daily == {"m34": (32, "verify_span"), "m40": (48, "verify_span"), "m44": (32, "units_over_limit"),
                        "m45": (32, "verify_modifier")},
          f"daily limits per member + servicing + billing provider + day, each version on its own dates; ONE line over "
          f"the cap = verify_span (m34 40 > 32 Jan, m40 50 > 48 Mar), two lines = units_over_limit (m44), a line with 59 "
          f"= verify_modifier (m45); not 20 + 20 from two providers, not before the oldest version, not 40 <= 48, not "
          f"the anesthesia / all-nines codes ({got_daily})")
    check(not (ft["batch"] == "ahcccs_provider_type").any(), "B2 readings unsigned: no provider-type finding")
    snap_t = json.loads(str(T("policy_kb.policy_detector_runs").query("rule_id == 'RUN:snapshot'")
                            .sort_values("run_id").iloc[-1]["error"]))
    check(snap_t.get("ahcccs_both_ways_findings") == 2 and abs(float(snap_t.get("ahcccs_dollars_counted_twice")) - 150) < 1e-6,
          f"08's run log: 2 both-ways findings, $150 counted twice (the smaller line of the pair) "
          f"({ {k: v for k, v in snap_t.items() if 'both_ways' in k or 'twice' in k} })")

    os.environ["PKB_AHCCCS_TABLE_READINGS"] = readings_copy(set(at.TABLE_KEYS), "ahcccs_table_readings_signed_e2e.csv")
    run_nb("07_build_kb.py")
    blt = last_build()
    check(json.loads(blt["ahcccs_rules_by_batch"])["ahcccs_provider_type"] == 1
          and json.loads(blt["ahcccs_held_back_unsigned"]) == {}
          and len(str(blt["ahcccs_readings_sha256"] or "")) == 64
          and "b2_matrix" in json.loads(blt["ahcccs_stale_vs_claims"]),
          "07 with every reading signed: the B2 rule of H0035 builds; the readings file's sha256 is logged; B2 "
          "(2026-01-01 + 62 days) is flagged stale against claims to 2026-03-05")
    cf = T("policy_kb.policy_ahcccs_conflicts")
    print(cf.head(10).to_string())
    check(set(cf["build_id"].astype(str)) <= {str(blt["build_id"])}, "policy_ahcccs_conflicts rewritten by this build")
    run_nb("08_run_detectors.py")
    ft = latest_run_findings()
    ft = ft[ft["origin"] == "ahcccs_table"]
    b2 = ft[ft["batch"] == "ahcccs_provider_type"]
    b2f = {r.claim_id: str(r.finding) for r in b2.itertuples()}
    check(set(b2f) == {"t37", "t41"} and "billed by provider type 77" in b2f["t37"]
          and "rendered by provider type 08 for a group (01)" in b2f["t41"],
          f"B2: H0035 billed by a BH clinic (77) is a finding; a group (01) is judged on its rendering type - 08 a "
          f"finding, 71 not; a hospital (02) billing it is not ({b2f})")
    hist_t = T("policy_kb.policy_rules_history")
    jt = ft.merge(hist_t, on=["build_id", "rule_id"], how="left")
    check(len(ft) == 11 and jt["statement"].notna().all() and ft["finding_id"].is_unique,
          f"11 table findings (5 Same Day, 4 daily, 2 B2), unique finding ids, each joins policy_rules_history on "
          f"(build_id, rule_id) ({len(ft)})")
    rt = T("policy_kb.policy_detector_runs")
    rt = rt[(rt["run_id"] == ft["run_id"].iloc[0]) & rt["rule_id"].isin([f"BATCH:{b_}" for b_ in TB])]
    check(len(rt) == 3 and rt["error"].isna().all() and rt["skipped"].isna().all() and rt["hits"].sum() == 11,
          "08 ran the three table statements, no error, hits logged")

    # v5.2b (critic F7): a table edited in the catalog by hand is not what 00b loaded - 07 stops before building
    fq = config.AHCCCS_TABLES["daily_limits"]["table"]
    spark.table(fq).write.mode("overwrite").format("parquet").saveAsTable(fq + "_e2e_bak")
    bak = spark.table(fq + "_e2e_bak")
    bak.where("code <> 'H0004'").write.mode("overwrite").format("parquet").saveAsTable(fq)
    try:
        run_nb("07_build_kb.py")
        check(False, "07 stops when a loaded table lost rows in the catalog")
    except RuntimeError as e:
        check("AHCCCS TABLE CHECK FAILED" in str(e), f"07 stops when a loaded table lost rows in the catalog ({str(e)[:160]})")
    spark.table(fq + "_e2e_bak").write.mode("overwrite").format("parquet").saveAsTable(fq)
    spark.sql(f"DROP TABLE IF EXISTS {fq}_e2e_bak")
    run_nb("07_build_kb.py")                                   # restored: the build passes the check again
    check(json.loads(last_build()["ahcccs_rules_by_batch"])["ahcccs_daily_max"] == 6,
          "after the table is restored, 07 builds the same table rules again")
    run_nb("08_run_detectors.py")

    if DEMOS:
        import random
        import quality

        def table_counts():
            out = {}
            for db in ("sedo", "policy_kb", "prod_input"):
                for t in spark.catalog.listTables(db):
                    out[f"{db}.{t.name}"] = spark.table(f"spark_catalog.{db}.{t.name}").count()
            return out

        def try_nb(rel, subs=None, label=None):
            try:
                g = run_nb(rel, subs)
                check(True, f"{label or rel} ran")
                return g
            except Exception as e:
                traceback.print_exc()
                check(False, f"{label or rel}: {type(e).__name__}: {e}")
                return None

        before = table_counts()
        G = {}
        for sub in ("demos", "validation"):
            d = os.path.join(PKG, "notebooks", sub)
            for nb in sorted(os.listdir(d)) if os.path.isdir(d) else []:
                if nb.endswith(".py"):
                    G[nb] = try_nb(f"{sub}/{nb}", E2E_DEMO_SUBS.get(nb)) or {}
        after = table_counts()
        changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k)
                         and k != "policy_kb.policy_query_validation_tests")        # v06 records its auto-tests
        check(not changed, f"demos + validation exports wrote no table rows (changed: {changed})")
        # v06: every stored query passes its scenarios; a validator's decisions are recorded, bound to the SQL hash
        g6 = G.get("v06_query_validation_pack.py", {})
        p6 = g6.get("EXPORT_PATH")
        check(bool(p6) and os.path.exists(p6), f"v06 exported the query validation pack ({p6})")
        if p6 and os.path.exists(p6):
            book = quality.xlsx_read_sheets(p6)
            qq = book["QUERIES"]
            check(len(qq) > 0 and (qq["auto_test"] == "PASS").all(),
                  f"v06: every query passes its scenarios ({qq['auto_test'].value_counts().to_dict()})")
            check({f"BATCH:{b_}" for b_ in TB} <= set(qq["query_id"].astype(str)),
                  "v06: the three AHCCCS table statements are in the pack, with their scenarios")
            qq["validator"] = "Boss (e2e)"
            qq["validator_decision"] = "OK"
            qq.loc[qq.index[0], "sql_sha256"] = "0" * 64                     # one tampered row must be refused
            signed = os.path.join(os.path.dirname(p6), "signed_v06.xlsx")
            quality.xlsx_write_sheets({"QUERIES": qq}, signed)
            try_nb("validation/v06_query_validation_pack.py",
                   {"EXPORT          = True": "EXPORT          = False", "SIGNED_WORKBOOK = None": f"SIGNED_WORKBOOK = {signed!r}"},
                   "v06 INGEST")
            qv = T("policy_kb.policy_query_validation")
            check(len(qv) == len(qq) - 1, f"v06 ingest: {len(qv)} decisions recorded, the tampered one refused")
            # 2026-10-03: a validator's PROBLEM stops that query in 08; every other finding says whether its query
            # was signed OK for the SQL that ran
            f0 = T("policy_kb.policy_findings")
            f0 = f0[f0["run_id"] == f0["run_id"].max()]
            bad_q = str(f0[(f0["claim_id"] == "c5") & (f0["origin"] != "ncci")]["rule_id"].iloc[0])
            row = quality.xlsx_read_sheets(p6)["QUERIES"]                 # fresh: qq above was tampered in place
            row = row[row["query_id"] == bad_q].copy()
            row["validator"], row["validator_decision"] = "Boss (e2e)", "PROBLEM"
            row["validator_note"] = "e2e: scenario looks wrong"
            signed2 = os.path.join(os.path.dirname(p6), "signed_v06_problem.xlsx")
            quality.xlsx_write_sheets({"QUERIES": row}, signed2)
            time.sleep(1.1)                                            # validated_at has one-second resolution
            try_nb("validation/v06_query_validation_pack.py",
                   {"EXPORT          = True": "EXPORT          = False",
                    "SIGNED_WORKBOOK = None": f"SIGNED_WORKBOOK = {signed2!r}"}, "v06 INGEST (PROBLEM)")
            run_nb("08_run_detectors.py")
            f1 = T("policy_kb.policy_findings")
            f1 = f1[f1["run_id"] == f1["run_id"].max()]
            r1 = T("policy_kb.policy_detector_runs")
            r1 = r1[r1["run_id"] == f1["run_id"].iloc[0]]
            skip = r1[r1["rule_id"] == bad_q]
            check(not (f1["rule_id"] == bad_q).any() and len(skip) == 1 and "PROBLEM" in str(skip["skipped"].iloc[0]),
                  f"08 does not run a query the validator marked PROBLEM ({bad_q})")
            check(set(f1["query_validation"]) <= {"OK", "not_validated"} and (f1["query_validation"] == "OK").any(),
                  f"every finding says whether its query was validated ({f1['query_validation'].value_counts().to_dict()})")
        check(bool(G.get("d05_ambiguity_register.py")) and os.path.isdir(os.path.join(config.WORKSPACE_DATA_DIR, "demos"))
              and any(f.endswith(".xlsx") for f in os.listdir(os.path.join(config.WORKSPACE_DATA_DIR, "demos"))),
              "d05 exported the ambiguity register workbook under data/demos/")
        go0 = G.get("v03_pipeline_health.py", {}).get("go_table")
        quality_rows = go0[go0["measurement bar item"].str.contains("precision|recall|fidelity", case=False)] if go0 is not None else None
        check(quality_rows is not None and len(quality_rows) == 6 and (quality_rows["status"] == "NOT YET").all(),
              f"v03 before any scoring: every quality row is NOT YET (no GO without a metric): "
              f"{quality_rows['measurement bar item'].tolist() if quality_rows is not None else None}")

        # d01 on a code the KB has never seen must say so explicitly
        g = try_nb("demos/d01_code_lookup.py", {'CODE     = "98960"': 'CODE     = "ZZZZ9"'}, "d01 on an unknown code")
        check(g is not None and g.get("found_anything") is False, "d01 reports 'No governing authority found' for an unknown code")

        # the package finder must work two levels down without PKB_PACKAGE_DIR
        saved = os.environ.pop("PKB_PACKAGE_DIR")
        try:
            try_nb("demos/d04_coverage_gap.py", None, "d04 without PKB_PACKAGE_DIR (grandparent finder)")
        finally:
            os.environ["PKB_PACKAGE_DIR"] = saved

        # ---- validation INGEST paths: score the exported workbooks (random but deterministic) and ingest them
        rng = random.Random(20260929)
        v01 = G.get("v01_extraction_scoring.py", {}).get("EXPORT_PATH")
        v02 = G.get("v02_detector_precision.py", {}).get("EXPORT_PATH")
        check(bool(v01) and os.path.exists(v01), f"v01 exported a workbook ({v01})")
        check(bool(v02) and os.path.exists(v02), f"v02 exported a workbook ({v02})")
        ingest = {"EXPORT          = True": "EXPORT          = False"}
        if v01 and os.path.exists(v01):
            book = quality.xlsx_read_sheets(v01)
            r = book["RULES"]
            check(len(r) > 0 and set(r["extraction_run_id"].astype(str)) == {LATEST_X}
                  and set(r["population"].astype(str)) == {quality.ENGINE_POPULATION}
                  and r["corpus_version"].astype(str).str.startswith("corpus-").all(),
                  f"v01 samples the latest run's own drafts ({LATEST_X}), stamped with population and corpus_version")
            r["is_real_rule"] = [rng.choice("YYYYN") for _ in range(len(r))]
            r["faithful_to_source"] = [rng.choice("YYYYYYN") if x == "Y" else None for x in r["is_real_rule"]]
            r["scorer"] = "e2e"
            sc = book["RECALL"]
            # 2026-10-04: recall = real rules found / (real rules found + missed) - both counts filled per section
            sc["real_rules_found"] = [rng.randint(0, int(n)) if pd.notna(n) else 0 for n in sc["rules_extracted"]]
            sc["missed_rules"] = [rng.choice([0, 0, 1]) for _ in range(len(sc))]
            sc["scorer"] = "e2e"
            dr = book.get("DROPPED")
            if dr is not None and len(dr):
                dr["is_real_rule"] = [rng.choice("YNN") for _ in range(len(dr))]
                dr["scorer"] = "e2e"
            scored = os.path.join(os.path.dirname(v01), "scored_v01.xlsx")
            quality.xlsx_write_sheets(book, scored)
            try_nb("validation/v01_extraction_scoring.py", {**ingest, "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"},
                   "v01 INGEST")
            qm = T("policy_kb.policy_quality_metrics")
            check(set(qm["metric"]) >= {"extraction_precision", "extraction_fidelity", "extraction_recall"},
                  f"v01 ingest: extraction metrics in policy_quality_metrics ({sorted(set(qm['metric']))})")
            n_dr = len(book["DROPPED"]) if book.get("DROPPED") is not None else 0
            check(len(T("policy_kb.policy_extraction_scores")) == len(r) + len(sc) + n_dr,
                  f"v01 ingest: raw scores appended (RULES {len(r)} + RECALL {len(sc)} + DROPPED {n_dr})")
            try:
                run_nb("validation/v01_extraction_scoring.py", {**ingest, "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"})
                check(False, "v01 refuses to ingest the same sample twice")
            except AssertionError:
                check(True, "v01 refuses to ingest the same sample twice")
        if v02 and os.path.exists(v02):
            book = quality.xlsx_read_sheets(v02)
            fs = book["FINDINGS"]
            fs["disposition"] = [rng.choice(["true_violation", "true_violation", "false_positive", "cannot_tell"]) for _ in range(len(fs))]
            fs["reviewer"] = "e2e"
            scored = os.path.join(os.path.dirname(v02), "scored_v02.xlsx")
            quality.xlsx_write_sheets(book, scored)
            try_nb("validation/v02_detector_precision.py", {**ingest, "SCORED_WORKBOOK = None": f"SCORED_WORKBOOK = {scored!r}"},
                   "v02 INGEST")
            qm = T("policy_kb.policy_quality_metrics")
            check("detector_precision" in set(qm["metric"]) and len(qm) > 0, f"v02 ingest: detector metrics ({len(qm)} metric rows)")
            check(len(T("policy_kb.policy_finding_reviews")) == len(fs), "v02 ingest: raw reviews appended")
        g = try_nb("validation/v03_pipeline_health.py", None, "v03 after ingest")
        go = g.get("go_table") if g else None
        if go is not None:
            fid = go[go["measurement bar item"].str.startswith("Extraction fidelity")].iloc[0]
            m = T("policy_kb.policy_quality_metrics")
            m = m[(m["metric"] == "extraction_fidelity") & (m["scope"] == "all")].iloc[-1]
            check((fid["status"] == "GO") == bool(m["ci_low"] >= 0.95),
                  f"v03 fidelity row agrees with the metric (lower bound {m['ci_low']:.3f} -> {fid['status']})")

    print("\n" + ("ALL CHECKS PASSED" if not FAIL else f"{len(FAIL)} CHECK(S) FAILED:\n  - " + "\n  - ".join(FAIL)))
    return 0 if not FAIL else 1


# per-notebook parameter substitutions for demos that need an input (e.g. a code to look up)
E2E_DEMO_SUBS: dict = {
    "d01_code_lookup.py": {'CODE     = "98960"': 'CODE     = "98960"'},          # the planted CHW code (Ch10 + NCCI)
    "d03_provider_review.py": {"MIN_PEERS = 5 ": "MIN_PEERS = 1 "},              # every synthetic code has one provider
    "d09_policy_text_search.py": {'QUERY         = "prior authorization"': 'QUERY         = "same day"'},
    "v04_chapter_profile.py": {"DOWNLOAD  = True": "DOWNLOAD  = False",
                               'CHAPTERS  = list(config.CHAPTERS)': 'CHAPTERS  = ["10"]'},
}

if __name__ == "__main__":
    try:
        sys.exit(main())
    finally:
        spark.stop()
