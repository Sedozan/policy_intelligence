"""Offline tests for preflight_sql (the SQL behind notebooks/01_preflight_ncci) and for the notebook's
fail-only-on-unreadable-NCCI contract. String-level: no Spark here. (The statements were also executed
end to end against fixtures through a DuckDB stand-in during development; see the implementer report.)"""
import ast
import os
import re
import sys
from datetime import date

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config  # noqa: E402
import ingest_ncci_tables as ing  # noqa: E402
import preflight_sql as pq  # noqa: E402

C = config.CLAIM_COLS
CLAIMS = config.CLAIMS_TABLE
NB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "notebooks", "01_preflight_ncci.py")

ACQUIRED_PTP = {"QuarterBeginDate": "int", "Category": "string", "Col1": "string", "Col2": "string", "EffDt": "int",
                "DelDt": "int", "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable": "string",
                "PTP_Edit_Rationale": "string", "src_sha256": "string"}
HAND_PTP = {"Col1": "bigint", "Col2": "string", "EffDt": "double", "DelDt": "string",
            "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable": "bigint", "PTP_Edit_Rationale": "string"}
HAND_MUE = {"HCPCS/CPT Code": "string", "Practitioner Services MUE Values": "string", "MUE Rationale": "string"}


def test_type_dispatch():
    assert pq.is_numeric("decimal(15,4)") and pq.is_numeric("bigint") and pq.is_numeric("double")
    assert not pq.is_numeric("interval day to second") and not pq.is_numeric("string")
    assert pq.is_datelike("date") and pq.is_datelike("timestamp_ntz") and not pq.is_datelike("string")


def test_code_expression_pads_lost_zeros_but_never_truncates():
    num = pq.code_expr("Col1", "bigint")
    assert "TRY_CAST(`Col1` AS BIGINT)" in num and "LENGTH(" in num and "< 5 THEN LPAD(" in num
    s = pq.code_expr("Col1", "string")
    assert "UPPER(TRIM(CAST(`Col1` AS STRING)))" in s and "RLIKE '^[0-9]{1,4}$'" in s and "'[.]0$'" in s


def test_ncci_value_expressions_never_use_an_ansi_cast_that_can_fail():
    for e in (pq.ymd_expr("EffDt", "double"), pq.mi_expr("m", "bigint"), pq.int_expr("v", "string"),
              pq.int_expr("v", "bigint"), pq.code_expr("c", "double")):
        assert "TRY_CAST(" in e
        assert not re.search(r"(?<!TRY_)CAST\(`\w+` AS (INT|BIGINT|DOUBLE|DATE)\)", e), e
    assert pq.ymd_expr("EffDt", "date") == "DATE_FORMAT(`EffDt`, 'yyyyMMdd')"
    assert pq.mi_expr("m", "string") == "SUBSTR(TRIM(CAST(`m` AS STRING)), 1, 1)"


def test_date_expression_handles_date_string_and_yyyymmdd():
    assert pq.date_expr("date_of_birth", "date") == "`date_of_birth`"
    s = pq.date_expr("date_of_birth", "string")
    assert s.startswith("COALESCE(TRY_CAST(TRIM(CAST(`date_of_birth` AS STRING)) AS DATE)") and "RLIKE '^[0-9]{8}$'" in s
    n = pq.date_expr("date_of_birth", "int")
    assert "TRY_CAST(`date_of_birth` AS BIGINT)" in n and "CONCAT_WS('-'" in n and "COALESCE" not in n


def test_sources_resolve_hand_loaded_and_acquired_columns():
    a = pq.ptp_source("main.sedo.t_new", ACQUIRED_PTP, ing._find_col, "practitioner")
    h = pq.ptp_source("main.sedo.t_old", HAND_PTP, ing._find_col, "practitioner")
    for s in (a, h):
        assert s.startswith("SELECT 'practitioner' AS svc,") and " AS a, " in s and " AS mi FROM main.sedo.t_" in s
    assert "LPAD(" in h and "TRY_CAST(`EffDt` AS BIGINT)" in h                      # numeric hand-load normalised
    m = pq.mue_source("main.sedo.m", HAND_MUE, ing._find_col, "practitioner", 3)
    assert "3 AS qi" in m and "`HCPCS/CPT Code`" in m and "`Practitioner Services MUE Values`" in m
    with pytest.raises(KeyError, match="mod"):
        pq.ptp_source("main.sedo.bad", {"Col1": "string", "Col2": "string", "EffDt": "int"}, ing._find_col, "dme")


def test_ccmi_change_joins_on_pair_and_effective_date_null_safely():
    summary, ex = pq.sql_ccmi_changes("SELECT 1", "SELECT 2")
    assert "ON o.a = n.a AND o.b = n.b AND o.eff = n.eff" in summary
    assert "NOT (mi_old <=> mi_new)" in summary and "mi_old = '1' AND mi_new = '0'" in summary
    assert ex.rstrip().endswith("LIMIT 10")


def test_mue_later_changes_compares_later_quarters_and_the_next_loaded_one():
    summary, ex = pq.sql_mue_later_changes(["SELECT a", "SELECT b", "SELECT c"], CLAIMS, C)
    assert "y.qi > x.qi AND y.val > x.val" in summary
    assert "LEFT ANTI JOIN p b ON b.code = a.code AND b.qi = a.qi + 1 WHERE a.qi < 2" in summary
    assert summary.count("UNION ALL") == 2 and "ex AS (SELECT code FROM raised" in ex


def test_claims_dates_one_scan_for_both_coverage_checks():
    s = pq.sql_claims_dates(CLAIMS, C, [date(2026, 4, 1)], [date(2026, 12, 31), date(2026, 9, 30)])
    assert s.count(f"FROM {CLAIMS}") == 1
    assert "< DATE '2026-04-01' THEN 1 ELSE 0 END) AS before_0" in s
    assert "> DATE '2026-12-31' THEN 1 ELSE 0 END) AS after_0" in s and "AS after_1" in s


def test_edition_exclusive_queries_need_both_codes_paid_and_split_by_the_lines_edit_file():
    p = pq.sql_ptp_exclusive(["SELECT x"], CLAIMS, C)
    assert "JOIN paid pa ON pa.code = u.a JOIN paid pb ON pb.code = u.b" in p and "mi IN ('0', '1')" in p
    m = pq.sql_mue_exclusive(["SELECT y"], CLAIMS, C)
    # the paid lines are split by the edit file each LINE takes (provider type x form - ncci_routing)
    assert f"`{C['form']}`" in m and f"`{C['prov_type']}`" in m and "AS form_typ" in m and "k.n_ed = 1" in m


def test_route_distribution_keys_on_the_provider_type_code_not_the_description():
    r = pq.sql_route_distribution(CLAIMS, C, "SProv_Type_Desc")
    assert f"`{C['prov_type']}`" in r and "GROUP BY 1, 2, 4" in r and "MAX(CAST(`SProv_Type_Desc` AS STRING))" in r


def test_data_shape_queries_cover_every_c1_item_with_the_configured_columns():
    s = pq.sql_data_shape(CLAIMS, C)
    for alias in ("paid_nonpositive", "paid_negative", "units_nonpositive", "proc_unnormalised", "mods_unnormalised",
                  "member_missing", "sprov_missing", "claim_id_null", "line_no_null"):
        assert f"AS {alias}" in s, alias
    for col in [C["paid_amt"], C["units"], C["code"], C["member"], C["servicing_provider"], *C["mods"]]:
        assert f"`{col}`" in s, col
    d = pq.sql_duplicate_keys(CLAIMS, C)
    assert f"GROUP BY `{C['claim_id']}`, `{C['line_no']}` HAVING COUNT(*) > 1" in d
    t = pq.sql_top_members(CLAIMS, C)
    assert "ORDER BY lines DESC" in t and t.rstrip().endswith("LIMIT 10")
    b = pq.sql_dob(CLAIMS, C, "string")
    assert f"`{C['dob']}` IS NULL" in b and "AS dob_unparseable" in b and "AS dob_after_dos" in b
    assert re.match(pq.PLACEHOLDER_KEY_RE, "UNKNOWN", re.I) and re.match(pq.PLACEHOLDER_KEY_RE, "000", re.I)
    assert not re.match(pq.PLACEHOLDER_KEY_RE, "M12345", re.I)


def test_preflight_notebook_wraps_every_check_and_raises_only_for_unreadable_ncci_tables():
    src = open(NB).read()
    assert src.startswith("# Databricks notebook source\n") and "# COMMAND ----------" in src
    ids = re.findall(r'^run\("(\w+)",', src, re.M)
    assert ids == ["0", "1", "2", "3", "B", "4", "A", "C", "D", "E", "F", "T"]     # T: AHCCCS rule tables (v5.2)
    tree = ast.parse(src)
    raises = [n for n in ast.walk(tree) if isinstance(n, ast.Raise)]
    # the package-finder ImportError, and the final 'NCCI table(s) cannot be read' - nothing else
    msgs = [ast.unparse(n.exc) for n in raises]
    assert len(raises) == 2 and "ImportError" in msgs[0] and "cannot be read" in msgs[1]
    assert re.search(r"^if UNREADABLE:\n    raise RuntimeError", src, re.M)
    for name in ("table_or_none", "write_table", "saveAsTable", ".write."):          # read-only notebook
        assert name not in src
