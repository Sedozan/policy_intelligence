"""One extraction engine in the KB (SB, 2026-10-04: "I want to fresh and to keep rules that are extracted using the
same version of extraction"). The hand-written rules are a checklist v05 scores runs against, not KB rules; a rule an
older engine produced stays out until the current engine produces it again.

  config.COMPILE_HAND_AUTHORED  False (default): hand-authored rules (origin 'manual') are never exported for review
                                and never compiled
  config.KB_PROMPT_VERSIONS     ("v2",): an extracted rule compiles only when the LAST run that produced it
                                (extraction_run_id) used one of these prompt versions (policy_extraction_log)
  state_rules.merge_drafts      a DECIDED row the new run produced again names that run (its decision untouched)
Run: cd pie_mvp && python -m pytest tests/test_one_engine.py -q
"""
import json
import os
import sys

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import config  # noqa: E402
import state_rules as sr  # noqa: E402

PRED = {"type": "code_not_covered", "code": "11975"}


def _row(key, origin="extracted", status="approved", run="R2", **kw):
    r = {c: None for c in sr.STATE_RULE_COLUMNS}
    r.update(rule_id=("EXT-" if origin == "extracted" else "MAN-") + key, extraction_key=key if origin == "extracted"
             else None, origin=origin, chapter="10", doc_hash="D10" if origin == "extracted" else None,
             statement=f"rule {key}", predicate=json.dumps(PRED), codes=json.dumps(["11975"]), population="all",
             review_status=status, reviewer="SB" if status == "approved" else None, plane="coverage_scope",
             binding_status="state_policy", machine_checkable=True, extraction_run_id=run if origin == "extracted"
             else None, source_doc="Chapter 10", source_locator="page 3", source_url="https://x")
    r.update(kw)
    return r


RUNS = {"R1": "v1", "R2": "v2"}


def _ids(rules):
    """The rows a list of Rule objects came from (row_to_rule leaves the content id to 07's normaliser)."""
    return sorted(("MAN-" if r.origin == "manual" else "EXT-") + r.statement.split()[-1] for r in rules)


def test_only_rules_of_the_current_engine_compile(monkeypatch):
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", False)
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ("v2",))
    df = pd.DataFrame([_row("new", run="R2"), _row("old", run="R1"), _row("lost", run="R9"),
                       _row("seed", origin="manual", status="approved")])
    rep = {}
    got = sr.rules_from_frame(df, current_doc_hash={"10": "D10"}, report=rep, run_prompt=RUNS)
    assert _ids(got) == ["EXT-new"]
    why = {r["rule_id"]: r["reason"] for r in rep["engine_excluded"]}
    assert why == {"EXT-old": "other_engine", "EXT-lost": "engine_unknown", "MAN-seed": "hand_authored"}
    # the switches, one at a time
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ())                      # any engine
    assert _ids(sr.rules_from_frame(df, current_doc_hash={"10": "D10"}, run_prompt=RUNS)) == [
        "EXT-lost", "EXT-new", "EXT-old"]
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", True)                 # hand-authored once signed
    assert "MAN-seed" in _ids(sr.rules_from_frame(df, current_doc_hash={"10": "D10"}, run_prompt=RUNS))
    # run_prompt None (a caller that does not apply the rule): unchanged behaviour
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", False)
    monkeypatch.setattr(config, "KB_PROMPT_VERSIONS", ("v2",))
    assert len(sr.rules_from_frame(df, current_doc_hash={"10": "D10"})) == 4


def test_a_decided_rule_the_new_engine_reproduces_names_the_new_run():
    """The merge keeps a decided row (never downgraded) but records that the new run produced it again - otherwise the
    one-engine rule would drop an approved rule the current engine DID reproduce."""
    approved = _row("k1", status="approved", run="R1", approved_predicate_sha256="abc")
    rejected = _row("k2", status="rejected", run="R1")
    gone = _row("k3", status="approved", run="R1")                                # the new run does not produce it
    new = [_row("k1", status="draft", run="R2", extraction_backend="HYBRID:gpt-oss-120b"),
           _row("k2", status="draft", run="R2")]
    merged, counts = sr.merge_drafts(pd.DataFrame([approved, rejected, gone]), new, run_id="R2")
    m = {r["extraction_key"]: r for r in merged.to_dict("records")}
    assert counts["reproduced_decided"] == 2 and counts["kept_reviewed"] == 1 and counts["kept_rejected"] == 1
    assert m["k1"]["extraction_run_id"] == "R2" and m["k1"]["review_status"] == "approved"
    assert m["k1"]["reviewer"] == "SB" and m["k1"]["approved_predicate_sha256"] == "abc"
    assert m["k1"]["extraction_backend"] == "HYBRID:gpt-oss-120b"
    assert m["k2"]["extraction_run_id"] == "R2" and m["k2"]["review_status"] == "rejected"
    assert m["k3"]["extraction_run_id"] == "R1"                                    # only an older engine produced it
    # the same merge again changes nothing more
    _, again = sr.merge_drafts(merged, new, run_id="R2")
    assert again["reproduced_decided"] == 0


class _Spark:
    def __init__(self, rows):
        self.rows = rows

    def table(self, name):
        rows = self.rows
        return type("T", (), {"toPandas": lambda self: pd.DataFrame(rows)})()


def test_hand_authored_rules_are_not_sent_for_review_by_default(tmp_path, monkeypatch):
    rows = [_row("d1", status="draft"), _row("seed", origin="manual", status="legacy_hand_authored")]
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", False)
    p = sr.export_review_workbook(_Spark(rows), "t", str(tmp_path / "wb.xlsx"))
    assert list(pd.read_excel(p)["origin"]) == ["extracted"]
    monkeypatch.setattr(config, "COMPILE_HAND_AUTHORED", True)
    p = sr.export_review_workbook(_Spark(rows), "t", str(tmp_path / "wb2.xlsx"))
    assert sorted(pd.read_excel(p)["origin"]) == ["extracted", "manual"]


def test_the_switches_read_their_environment(monkeypatch):
    import importlib
    try:
        monkeypatch.setenv("PKB_COMPILE_HAND_AUTHORED", "1")
        monkeypatch.setenv("PKB_KB_PROMPT_VERSIONS", "any")
        importlib.reload(config)
        assert config.COMPILE_HAND_AUTHORED is True and config.KB_PROMPT_VERSIONS == ()
        monkeypatch.setenv("PKB_COMPILE_HAND_AUTHORED", "off")
        monkeypatch.setenv("PKB_KB_PROMPT_VERSIONS", "v2, v3")
        importlib.reload(config)
        assert config.COMPILE_HAND_AUTHORED is False and config.KB_PROMPT_VERSIONS == ("v2", "v3")
    finally:
        monkeypatch.delenv("PKB_COMPILE_HAND_AUTHORED", raising=False)
        monkeypatch.delenv("PKB_KB_PROMPT_VERSIONS", raising=False)
        importlib.reload(config)
    assert config.COMPILE_HAND_AUTHORED is False and config.KB_PROMPT_VERSIONS == ("v2",)
