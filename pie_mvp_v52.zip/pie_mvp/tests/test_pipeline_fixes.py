"""2026-09-29 pipeline fixes (D3-D10 + batch NCCI + governance). Every compiler check EXECUTES
SQL in SQLite; Spark-only syntax is rewritten by _sqlite() below and nothing else."""
import json
import os
import random
import re
import sqlite3
import sys

import pandas as pd
import pytest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.dirname(HERE))

import config  # noqa: E402
import detector_gen as dg  # noqa: E402
import ingest_ncci_tables as ing  # noqa: E402
import rule_normalize as rn  # noqa: E402
from schema import Rule  # noqa: E402
import state_rules as sr  # noqa: E402
import gap  # noqa: E402
import registers  # noqa: E402

COLS = ["ClaimID", "LN_NO", "MEMBER_KEY", "SProv_ID", "Svc_Begin_Dt", "PROC_CD", "QUANTITY_PAID", "FORM_TYP",
        "PROC_MOD_1", "PROC_MOD_2", "PROC_MOD_3", "PROC_MOD_4", "EVENT_PA_NO", "PMT_AMT"]


def _sqlite(sql: str) -> str:
    sql = re.sub(r"CAST\(([\w.]+) AS DATE\)", r"\1", sql)
    return re.sub(r"DATE '(\d{4}-\d{2}-\d{2})'", r"'\1'", sql)


def _db(claims_rows, monkeypatch, ptp=None, mue=None):
    db = sqlite3.connect(":memory:")
    pd.DataFrame(claims_rows, columns=COLS).to_sql("claims", db, index=False)
    monkeypatch.setattr(dg, "CLAIMS", "claims")
    if ptp is not None:
        ptp.to_sql("ptp_edits", db, index=False)
    if mue is not None:
        mue.to_sql("mue_limits", db, index=False)
    return db


def _q(db, sql):
    cur = db.execute(_sqlite(sql))
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def _ncci_pair(a, b, mi, eff=None, end=None, svc="practitioner"):
    return Rule(origin="ncci", plane="coding_edit", binding_status="mandatory", statement=f"{b} with {a}",
                source_doc="CMS", source_locator=f"pair {a}/{b}", effective_date=eff, end_date=end,
                predicate={"type": "code_pair_prohibited", "code_a": a, "code_b": b, "modifier_indicator": mi,
                           "service_category": svc, "ncci_edition": svc}, codes=[a, b]).assign_id().to_dict()


def _ncci_mue(code, v, eff=None, end=None, svc="practitioner"):
    return Rule(origin="ncci", plane="coding_edit", binding_status="mandatory", statement=f"{code} max {v}",
                source_doc="CMS", source_locator=f"code {code}", effective_date=eff, end_date=end,
                predicate={"type": "max_units_per_line", "code": code, "threshold": v, "service_category": svc,
                           "ncci_edition": svc},
                codes=[code]).assign_id().to_dict()


# ---------------------------------------------------------- batch == per-rule
# 2026-10-02: the SQLite equivalence test that lived here is SUPERSEDED by
# tests/test_sql_spark.py::test_batch_equals_per_rule_multiset, which executes both paths on a real
# Spark (ANSI on) and compares MULTISETS (the SQLite version compared sets, hiding duplicate findings,
# and needed regex rewrites the v5 SQL - NAMED_STRUCT, ARRAY_SORT, <=>, RLIKE - cannot survive).


def test_batch_rows_carry_no_sql_and_edit_rows_carry_the_edit_file():
    rules = [_ncci_pair("11111", "22222", "0"), _ncci_mue("11111", 1)]
    dets = dg.build_detectors(rules, batch_ncci=True)
    assert [d["batch"] for d in dets] == ["ncci_ptp", "ncci_mue"] and all(d["sql"] is None for d in dets)
    ptp, mue = dg.ncci_edit_tables(rules)
    assert list(ptp["ncci_edition"]) == ["practitioner"] and list(mue["ncci_edition"]) == ["practitioner"]
    assert list(ptp.columns) == dg.PTP_EDIT_COLUMNS and list(mue.columns) == dg.MUE_LIMIT_COLUMNS
    # the batch statements read only their own build's edit rows (C4-01)
    assert "WHERE build_id = 'B9'" in dg.batch_ptp_sql(build_id="B9") and "WHERE build_id = 'B9'" in dg.batch_mue_sql(build_id="B9")
    # (execution of both statements: tests/test_sql_spark.py)


def test_deactivated_and_bad_dates_become_leads():
    r = _ncci_mue("11111", 1)
    r["deactivated"] = True
    assert dg.build_detectors([r])[0]["reason"] == "deactivated"
    r = _ncci_mue("11111", 1)
    r["effective_date"] = "10/1/2025"
    d = dg.build_detectors([r])[0]
    assert not d["compiled"] and "not ISO" in d["reason"]


# ------------------------------------------------------------------ NCCI ingest (D8-D10)
def _meta(edit="ptp"):
    return {"table": f"medicaid_ncci_edit_practitioner_{edit}_q4_2026", "service": "practitioner",
            "label": "2026Q4", "starts": "2026-10-01", "edit_type": edit, "year": 2026, "quarter": 4}


def _ptp_df(rows):
    return pd.DataFrame(rows, columns=["Col1", "Col2", "EffDt", "DelDt",
                                       "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable",
                                       "PTP_Edit_Rationale"])


def test_ptp_blank_modifier_and_missing_effective_date_raise_D9(monkeypatch):
    monkeypatch.setattr(config, "NCCI_STRICT", True, raising=False)
    with pytest.raises(ValueError, match="modifier indicator"):
        ing.ptp_rules(_ptp_df([["11111", "22222", 20200101, None, "", "x"]]), _meta())
    with pytest.raises(ValueError, match="effective date"):
        ing.ptp_rules(_ptp_df([["11111", "22222", None, None, "1", "x"]]), _meta())
    monkeypatch.setattr(config, "NCCI_STRICT", False)
    assert len(ing.ptp_rules(_ptp_df([["11111", "22222", 20200101, None, "", "x"],
                                      ["11111", "33333", 20200101, None, "0", "x"]]), _meta())) == 1


def test_mue_non_numeric_value_raises_D9(monkeypatch):
    monkeypatch.setattr(config, "NCCI_STRICT", True, raising=False)
    df = pd.DataFrame({"HCPCS_CPT_Code": ["11111"], "MUE_Values": ["N/A"], "MUE_Rationale": ["x"]})
    with pytest.raises(ValueError, match="non-numeric MUE"):
        ing.mue_history([(_meta("mue"), df)])


def test_no_ncci_tables_stops_the_build_D9(monkeypatch):
    monkeypatch.setattr(ing, "discover_tables", lambda *a, **k: [])
    monkeypatch.setattr(config, "NCCI_ALLOW_EMPTY", False, raising=False)
    with pytest.raises(ValueError, match="no medicaid_ncci_edit"):
        ing.ingest_tables(spark=None, catalog="main", schema="sedo")


def test_deletion_date_semantics_switch_D10(monkeypatch):
    df = _ptp_df([["11111", "22222", 20200101, 20251231, "0", "x"]])
    monkeypatch.setattr(config, "NCCI_DELETION_DATE_INCLUSIVE", True, raising=False)
    assert ing.ptp_rules(df, _meta())[0].end_date == "2025-12-31"
    monkeypatch.setattr(config, "NCCI_DELETION_DATE_INCLUSIVE", False)
    assert ing.ptp_rules(df, _meta())[0].end_date == "2025-12-30"


def test_ncci_rule_id_is_stable_across_quarters_D8():
    df = _ptp_df([["11111", "22222", 20200101, None, "0", "x"]])
    q3 = dict(_meta(), table="medicaid_ncci_edit_practitioner_ptp_q3_2026", label="2026Q3")
    assert ing.ptp_rules(df, q3)[0].rule_id == ing.ptp_rules(df, _meta())[0].rule_id


# ------------------------------------------------------------------ state duplicates / PA / code_set
def _state(pred, origin="manual", stmt="s", **kw):
    return Rule(origin=origin, plane="coverage_scope", binding_status="state_policy", statement=stmt,
                source_doc="Ch10", predicate=pred, codes=kw.pop("codes", []), **kw).assign_id().to_dict()


def test_seed_and_extracted_duplicate_collapse_to_the_extracted_rule():
    p = {"type": "code_not_covered", "code": "11975", "service_category": "practitioner"}
    seed = _state(p, "manual", "seed wording", codes=["11975"])
    ext = _state(dict(p, service_category="state"), "extracted", "model wording", codes=["11975"])
    out, rep = rn.normalize_rules([seed, ext])
    assert len(out) == 1 and out[0]["origin"] == "extracted" and rep["state_duplicates_collapsed"] == 1
    assert out[0]["supersedes"] == [seed["rule_id"]]


def test_uncoded_leads_with_same_reason_are_not_merged():
    a = _state({"type": "not_checkable", "reason": "requires_medical_record"}, stmt="one", machine_checkable=False)
    b = _state({"type": "not_checkable", "reason": "requires_medical_record"}, stmt="two", machine_checkable=False)
    out, _ = rn.normalize_rules([a, b])
    assert len(out) == 2


# test_state_pair_checks_pa_on_either_line: moved to tests/test_sql_spark.py (executed on Spark)

# test_daily_cap_over_a_code_set: moved to tests/test_sql_spark.py (executed on Spark)

def _row(key, status, doc_hash, reviewer=None):
    r = sr.rule_to_row(Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy",
                            statement="s", source_doc="Ch10", predicate={"type": "code_not_covered", "code": "11975"},
                            codes=["11975"], doc_hash=doc_hash), chapter="10", review_status=status, reviewer=reviewer)
    r.update(rule_id=f"EXT-{key}", extraction_key=key)
    return r


def test_new_document_version_sends_approvals_back_for_resign_D5():
    existing = pd.DataFrame([_row("k1", "approved", "OLD", "Kim"), _row("k2", "rejected", "OLD", "Kim"),
                             _row("k3", "approved", "NEW", "Kim")])
    merged, counts = sr.merge_drafts(existing, [_row("k1", "draft", "NEW"), _row("k2", "draft", "NEW"),
                                                _row("k3", "draft", "NEW")])
    by = merged.set_index("extraction_key")
    assert by.loc["k1", "review_status"] == "needs_review" and json.loads(by.loc["k1", "prior_review"])["reviewer"] == "Kim"
    assert by.loc["k2", "review_status"] == "needs_review"
    assert by.loc["k3", "review_status"] == "approved"                       # same version: untouched
    assert counts["resign_new_version"] == 2
    from extract_io import guard_state_rules_merge
    guard_state_rules_merge(existing, merged, "t")                          # re-sign is not a "shrink"


def test_stale_approval_is_not_loaded_D5():
    df = pd.DataFrame([_row("k1", "approved", "OLD", "Kim"), _row("k3", "approved", "NEW", "Kim")])
    rep = {}
    rules = sr.rules_from_frame(df, current_doc_hash={"10": "NEW"}, report=rep)
    assert len(rules) == 1 and [s["rule_id"] for s in rep["stale"]] == ["EXT-k1"]


def test_seed_upsert_keeps_reviews_D6():
    existing = pd.DataFrame([_row("k1", "approved", "H", "Kim")])
    seed = sr.rule_to_row(Rule(origin="manual", plane="coverage_scope", binding_status="state_policy", statement="x",
                               source_doc="Ch10", predicate={"type": "code_not_covered", "code": "11977"},
                               codes=["11977"]).assign_id(), chapter="10", review_status="legacy_hand_authored")
    out, c = sr.upsert_seed_rows(existing, [seed])
    assert len(out) == 2 and (out["review_status"] == "approved").sum() == 1
    out2, c2 = sr.upsert_seed_rows(out, [seed])
    assert len(out2) == 2 and c2["replaced_seed"] == 1


def test_coverage_counts_only_compiled_in_window_rules_D7():
    exp = pd.DataFrame({"code": ["A", "B", "C"], "lines": [1, 1, 1], "units": [1.0, 1.0, 1.0],
                        "paid_dollars": [30.0, 20.0, 10.0]})
    rules = [{"rule_id": "n1", "origin": "ncci", "codes": ["A"], "end_date": "2019-12-31"},   # expired before claims
             {"rule_id": "s1", "origin": "extracted", "codes": ["B"]},                          # lead (not compiled)
             {"rule_id": "s2", "origin": "extracted", "codes": ["C"]}]
    dets = [{"rule_id": "n1", "compiled": True}, {"rule_id": "s1", "compiled": False}, {"rule_id": "s2", "compiled": True}]
    cov = gap.coverage_from_exposure(exp, rules, dets, ("2025-01-01", "2026-06-30")).set_index("code")
    assert cov.loc["A", "coverage"] == "none" and cov.loc["B", "coverage"] == "none" and cov.loc["B", "state_leads"] == 1
    assert cov.loc["C", "coverage"] == "state_only"


def test_overlap_register_labels_relationships():
    mue = _ncci_mue("98960", 8)
    st_cap = _state({"type": "max_units_per_line", "code": "98960", "threshold": 4}, codes=["98960"])
    st_day = _state({"type": "max_units_per_day", "code": "98960", "threshold": 4}, codes=["98960"])
    nc = _state({"type": "code_not_covered", "code": "98960"}, codes=["98960"])
    ov = registers.rule_overlaps([mue, st_cap, st_day, nc])
    assert sorted(ov["relationship"]) == ["different_basis", "state_not_covered_vs_federal_edit", "state_stricter"]


def test_state_pair_duplicates_collapse_despite_routing_labels_and_nan_dates():
    seed = _state({"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961", "modifier_indicator": "0",
                   "service_category": "practitioner", "scope": "member_day"}, "manual", codes=["98960", "98961"])
    ext = _state({"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961", "modifier_indicator": "0",
                  "service_category": "state", "scope": "member_day"}, "extracted", codes=["98960", "98961"])
    seed["effective_date"], ext["effective_date"] = float("nan"), float("nan")
    out, rep = rn.normalize_rules([seed, ext])
    assert len(out) == 1 and out[0]["origin"] == "extracted"
    # an extracted pair with NO scope compiles narrow (member_provider_day, C3-01): it is a DIFFERENT rule from a
    # member-wide seed, so both are kept rather than one silently standing in for the other
    narrow = _state({"type": "code_pair_prohibited", "code_a": "98960", "code_b": "98961", "modifier_indicator": "0"},
                    "extracted", codes=["98960", "98961"])
    out2, _ = rn.normalize_rules([seed, narrow])
    assert len(out2) == 2


def test_verbatim_quote_survives_row_to_rule_and_extracted_ids_say_EXT():
    r = Rule(origin="extracted", plane="coverage_scope", binding_status="state_policy", statement="s", source_doc="Ch10",
             predicate={"type": "code_not_covered", "code": "11975"}, codes=["11975"],
             verbatim_quote="Do not bill for CPT codes: 11975.", section_id="10-s3").assign_id()
    back = sr.row_to_rule(sr.rule_to_row(r, chapter="10"))
    assert back.verbatim_quote == "Do not bill for CPT codes: 11975." and back.section_id == "10-s3"
    assert r.rule_id.startswith("EXT-")
    assert back.assign_id().rule_id == r.rule_id                 # quote is not part of the id


def test_mue_run_cites_first_and_last_quarter_table():
    q = lambda y, n: {"table": f"medicaid_ncci_edit_practitioner_mue_q{n}_{y}", "service": "practitioner",
                      "label": f"{y}Q{n}", "starts": f"{y}-{ing.QUARTER_START[n]}", "year": y, "quarter": n}
    df = pd.DataFrame({"HCPCS_CPT_Code": ["J3490"], "MUE_Values": [1], "MUE_Rationale": ["x"]})
    rules = ing.mue_history([(q(2025, 4), df), (q(2026, 1), df)])
    assert rules[0].doc_version == "medicaid_ncci_edit_practitioner_mue_q4_2025..medicaid_ncci_edit_practitioner_mue_q1_2026"
