"""
registers.py  -  the two policy-improvement products (definition-of-done pillars 5 and 6, first cut).

ambiguity_register   policy text that does not resolve to an executable rule, or that a reviewer
                     or the pipeline flagged as ambiguous - quoted, categorised, sized. Built from
                     state_rules (every status except rejected) plus NCCI edition disagreements.
rule_overlaps        every code checked by BOTH a federal and a state rule (the AHCCCS rule-table rules
                     excepted: policy_ahcccs_conflicts covers them), with the relationship
                     computed where the predicates are comparable:
                       state_stricter / federal_stricter / same_limit      (unit caps)
                       different_basis                                     (per line vs per day ...)
                       state_not_covered_vs_federal_edit                   (contradiction CANDIDATE:
                           AHCCCS says not covered; CMS publishes an edit that presumes payment)
                       both_pair_prohibitions / different_rule_types
                     Both rules still compile - both authorities apply. This is the reconciliation
                     record, and the contradiction-register CANDIDATE list for human review; it
                     never decides which authority wins.
"""
from __future__ import annotations

import json

import pandas as pd

from schema import NOT_CHECKABLE_REASONS

AMBIGUITY_COLUMNS = ["category", "reason", "rule_id", "extraction_key", "origin", "chapter", "review_status",
                     "statement", "verbatim_quote", "codes", "source_doc", "source_locator", "source_url",
                     "doc_hash"]
OVERLAP_COLUMNS = ["code", "relationship", "federal_rule_id", "federal_type", "federal_limit", "federal_edition",
                   "state_rule_id", "state_type", "state_limit", "state_quote", "state_source", "federal_source"]
TABLE_ORIGIN = "ahcccs_table"           # detector_gen.TABLE_ORIGIN: rules read from the AHCCCS rule tables (v5.2)

_UNIT_TYPES = {"max_units_per_line", "max_units_per_dos", "max_units_per_day", "max_units_per_period"}


def _j(v, default):
    if isinstance(v, str):
        try:
            return json.loads(v) if v else default
        except Exception:
            return default
    return default if v is None or (isinstance(v, float) and pd.isna(v)) else v


def _category(reason) -> str:
    if not reason or (isinstance(reason, float) and pd.isna(reason)):
        return "flagged_ambiguous"
    r = str(reason).strip()
    return r if r in NOT_CHECKABLE_REASONS else f"other:{r[:40]}"


def ambiguity_register(state_rows: pd.DataFrame, accepted_rules: list[dict]) -> pd.DataFrame:
    out = []
    if state_rows is not None and len(state_rows):
        # rejected decisions and drafts a later run superseded are not open policy questions
        df = state_rows[~state_rows["review_status"].isin(["rejected", "superseded"])]
        not_mc = ~df["machine_checkable"].fillna(False).astype(bool)
        flag = df["ambiguity_flag"].fillna(False).astype(bool)
        for r in df[not_mc | flag].to_dict("records"):
            pred = _j(r.get("predicate"), {})
            reason = r.get("not_checkable_reason") or pred.get("reason")
            out.append({
                "category": _category(reason) if not bool(r.get("machine_checkable")) else "flagged_ambiguous",
                "reason": " | ".join(str(x) for x in (reason, r.get("ambiguity_note")) if x and str(x) != "nan"),
                "rule_id": r.get("rule_id"), "extraction_key": r.get("extraction_key"), "origin": r.get("origin"),
                "chapter": r.get("chapter"), "review_status": r.get("review_status"),
                "statement": r.get("statement"), "verbatim_quote": r.get("verbatim_quote"),
                "codes": json.dumps(_j(r.get("codes"), [])), "source_doc": r.get("source_doc"),
                "source_locator": r.get("source_locator"), "source_url": r.get("source_url"),
                "doc_hash": r.get("doc_hash")})
    for r in accepted_rules:
        if r.get("origin") == "ncci" and str(r.get("reconciliation") or "").startswith("ncci_editions_disagree"):
            out.append({"category": "ncci_edition_disagreement", "reason": r.get("ambiguity_note"),
                        "rule_id": r.get("rule_id"), "extraction_key": None, "origin": "ncci", "chapter": None,
                        "review_status": "federal", "statement": r.get("statement"), "verbatim_quote": None,
                        "codes": json.dumps(r.get("codes") or []), "source_doc": r.get("source_doc"),
                        "source_locator": r.get("source_locator"), "source_url": r.get("source_url"),
                        "doc_hash": r.get("doc_hash")})
    return pd.DataFrame(out, columns=AMBIGUITY_COLUMNS)


def _limit(r: dict):
    p = r.get("predicate") or {}
    return p.get("threshold")


def _unit_relationship(fed: dict, st: dict) -> str:
    if fed["predicate"]["type"] != st["predicate"]["type"] or fed["predicate"].get("period") != st["predicate"].get("period"):
        return "different_basis"            # e.g. NCCI per claim line vs AHCCCS per member-day
    a, b = int(_limit(fed)), int(_limit(st))
    return "state_stricter" if b < a else "federal_stricter" if a < b else "same_limit"


def _row(code, rel, f, s, federal_limit=None, federal_type=None):
    return {"code": code, "relationship": rel,
            "federal_rule_id": f["rule_id"], "federal_type": federal_type or f["predicate"]["type"],
            "federal_limit": federal_limit if federal_limit is not None else _limit(f),
            # the NCCI edit file the federal rule comes from (lines take one file: provider type x form)
            "federal_edition": (f.get("predicate") or {}).get("ncci_edition"),
            "state_rule_id": s["rule_id"], "state_type": s["predicate"]["type"], "state_limit": _limit(s),
            "state_quote": s.get("verbatim_quote") or s.get("notes"),
            "state_source": f"{s.get('source_doc')} | {s.get('source_locator')}",
            "federal_source": f"{f.get('source_doc')} | {f.get('source_locator')}"}


def rule_overlaps(rules: list[dict], detectors: list[dict] | None = None) -> pd.DataFrame:
    """Only COMPARABLE pairs are listed (a state unit cap is not compared with every PTP pair
    that mentions the code - that would be noise, not reconciliation):
      state unit cap      x  federal MUE on the same code
      state pair (a,b)    x  federal PTP on the same two codes, either direction
      state not-covered   x  any federal edit on the code   (one row per code)
    AHCCCS rule-table rules (origin 'ahcccs_table': Same Day Disallow, daily limits, B2 matrix) are left out
    (2026-10-04, v5.2b, critic F18): a table's daily cap next to an NCCI MUE is two authorities on purpose (units per
    member + provider + day vs units per claim line), and listing them flooded the register with one row per table code
    and quarter. Where a table agrees with, contradicts or qualifies a STATE rule, policy_ahcccs_conflicts
    (ahcccs_tables.table_conflicts) lists it."""
    compiled = None if detectors is None else {d["rule_id"] for d in detectors if d.get("compiled")}
    live = [r for r in rules if (compiled is None or r.get("rule_id") in compiled) and r.get("origin") != TABLE_ORIGIN]
    mue: dict[str, list] = {}
    ptp: dict[frozenset, list] = {}
    fed_any: dict[str, list] = {}
    for r in live:
        if r.get("origin") != "ncci":
            continue
        p = r["predicate"]
        if p["type"] in _UNIT_TYPES:
            mue.setdefault(str(p["code"]).upper(), []).append(r)
        elif p["type"] == "code_pair_prohibited":
            ptp.setdefault(frozenset((str(p["code_a"]).upper(), str(p["code_b"]).upper())), []).append(r)
        for c in r.get("codes") or []:
            fed_any.setdefault(str(c).upper(), []).append(r)
    rows = []
    for s in live:
        if s.get("origin") == "ncci":
            continue
        p = s["predicate"]
        t = p["type"]
        if t in _UNIT_TYPES:
            for code in [p.get("code")] + list(p.get("code_set") or []):
                if code:
                    for f in mue.get(str(code).upper(), []):
                        rows.append(_row(str(code).upper(), _unit_relationship(f, s), f, s))
        elif t == "code_pair_prohibited":
            key = frozenset((str(p["code_a"]).upper(), str(p["code_b"]).upper()))
            for f in ptp.get(key, []):
                rows.append(_row("/".join(sorted(key)), "both_pair_prohibitions", f, s))
        elif t == "code_not_covered":
            for code in [p.get("code")] + list(p.get("code_set") or []):
                fs = fed_any.get(str(code).upper(), []) if code else []
                if fs:
                    rows.append(_row(str(code).upper(), "state_not_covered_vs_federal_edit", fs[0], s,
                                     federal_limit=len(fs), federal_type=f"{len(fs)} federal edit(s)"))
    return pd.DataFrame(rows, columns=OVERLAP_COLUMNS)
