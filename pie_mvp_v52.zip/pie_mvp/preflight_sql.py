"""
preflight_sql.py  -  the SQL text behind notebooks/01_preflight_ncci (read-only checks).

Kept out of the notebook so each statement is built from config in one place and unit-tested offline
(tests/test_preflight_sql.py). Nothing here imports Spark or touches a table.

Rules every statement follows (DBR 17.3 = Spark 4, ANSI mode ON):
  * A value that may not parse goes through TRY_CAST (an ANSI CAST of a bad string fails the query).
  * NCCI tables are read through *_expr() helpers that pick the expression from the column's TYPE:
    hand-loaded tables can hold codes as numbers (01996 -> 1996), dates as int / double / string and
    the modifier indicator as 1 / 1.0 / '1'. Codes are normalised exactly as the claims are compared
    (UPPER(TRIM()), 5 characters), so a join to PROC_CD means what the detectors mean.
  * Identifiers are back-quoted; table names are passed in already fully qualified.
"""
from __future__ import annotations

from datetime import date

PTP_FIND = {"c1": ("column1", "col1", "comprehensive code"), "c2": ("column2", "col2", "component code"),
            "eff": ("effective date", "effdt"), "mod": ("modifier indicator", "modifier")}
MUE_FIND = {"code": ("hcpcs/cpt code", "hcpcs cpt code", "procedure code", "code"), "val": ("mue value", "mue values")}

_NUMERIC = {"tinyint", "smallint", "int", "bigint", "long", "integer", "short", "byte", "float", "double",
            "decimal", "real"}
PLACEHOLDER_KEY_RE = r"^(0+|9+|-1|N/?A|NULL|NONE|UNKNOWN|UNK|TBD|X+|DUMMY|TEST)$"


def q(name: str) -> str:
    return "`" + str(name).replace("`", "``") + "`"


def is_numeric(dtype: str) -> bool:
    # the base type name only: 'decimal(15,4)' is numeric, 'interval day' is not
    return str(dtype).lower().split("(")[0].strip() in _NUMERIC


def is_datelike(dtype: str) -> bool:
    d = str(dtype).lower()
    return d == "date" or d.startswith("timestamp")


def code_expr(col: str, dtype: str) -> str:
    """A procedure code as the claims carry it: trimmed, upper case, 5 characters. A numeric column (or an
    all-digit string shorter than 5, or '1996.0') lost a leading zero in a hand-load and is padded back.
    Never LPAD a longer value: LPAD truncates, and would turn an invalid 6-digit value into a real code."""
    c = q(col)
    if is_numeric(dtype):
        s = f"CAST(TRY_CAST({c} AS BIGINT) AS STRING)"
        return f"CASE WHEN LENGTH({s}) < 5 THEN LPAD({s}, 5, '0') ELSE {s} END"
    s = f"REGEXP_REPLACE(UPPER(TRIM(CAST({c} AS STRING))), '[.]0$', '')"
    return f"CASE WHEN {s} RLIKE '^[0-9]{{1,4}}$' THEN LPAD({s}, 5, '0') ELSE {s} END"


def ymd_expr(col: str, dtype: str) -> str:
    """A CMS date as a 'yyyymmdd' STRING whatever the column type (20100101, 2.0100101E7, '20100101', DATE)."""
    c = q(col)
    if is_numeric(dtype):
        return f"CAST(TRY_CAST({c} AS BIGINT) AS STRING)"
    if is_datelike(dtype):
        return f"DATE_FORMAT({c}, 'yyyyMMdd')"
    return f"NULLIF(REGEXP_REPLACE(TRIM(CAST({c} AS STRING)), '[.]0$', ''), '')"


def mi_expr(col: str, dtype: str) -> str:
    """Modifier indicator as '0' / '1' / '9' (int 1, double 1.0, '1', ' 1 ' -> '1')."""
    c = q(col)
    if is_numeric(dtype):
        return f"CAST(TRY_CAST({c} AS INT) AS STRING)"
    return f"SUBSTR(TRIM(CAST({c} AS STRING)), 1, 1)"


def int_expr(col: str, dtype: str) -> str:
    """An MUE value as INT; NULL (not an error) when it does not parse."""
    c = q(col)
    if is_numeric(dtype):
        return f"TRY_CAST({c} AS INT)"
    return f"TRY_CAST(TRY_CAST(TRIM(CAST({c} AS STRING)) AS DOUBLE) AS INT)"


def date_expr(col: str, dtype: str) -> str:
    """A DATE from a DATE / TIMESTAMP / 'yyyy-MM-dd' string / yyyymmdd number or string; NULL when it does
    not parse. 'MM/dd/yyyy' strings stay NULL on purpose: a CAST-based age would not read them either."""
    c = q(col)
    if str(dtype).lower() == "date":
        return c
    if str(dtype).lower().startswith("timestamp"):
        return f"CAST({c} AS DATE)"
    s = f"TRIM(CAST(TRY_CAST({c} AS BIGINT) AS STRING))" if is_numeric(dtype) else f"TRIM(CAST({c} AS STRING))"
    ymd = (f"CASE WHEN {s} RLIKE '^[0-9]{{8}}$' THEN TRY_CAST(CONCAT_WS('-', SUBSTR({s}, 1, 4), SUBSTR({s}, 5, 2), "
           f"SUBSTR({s}, 7, 2)) AS DATE) END")
    return ymd if is_numeric(dtype) else f"COALESCE(TRY_CAST({s} AS DATE), {ymd})"


def resolve(columns, find_col, spec: dict, table: str) -> dict:
    """Real column names for the logical ones in spec (ingest._find_col handles hand-loaded and acquired
    names). Raises KeyError naming the table when one cannot be found."""
    out = {k: find_col(list(columns), *cands) for k, cands in spec.items()}
    missing = [k for k, v in out.items() if not v]
    if missing:
        raise KeyError(f"{table}: cannot resolve {missing} among {list(columns)}")
    return out


def ptp_source(fqn: str, types: dict, find_col, svc: str) -> str:
    """SELECT svc, a, b, eff, mi FROM <a PTP quarter table>, normalised."""
    r = resolve(types, find_col, PTP_FIND, fqn)
    return (f"SELECT '{svc}' AS svc, {code_expr(r['c1'], types[r['c1']])} AS a, "
            f"{code_expr(r['c2'], types[r['c2']])} AS b, {ymd_expr(r['eff'], types[r['eff']])} AS eff, "
            f"{mi_expr(r['mod'], types[r['mod']])} AS mi FROM {fqn}")


def mue_source(fqn: str, types: dict, find_col, svc: str, qi: int = 0) -> str:
    """SELECT svc, qi, code, val FROM <an MUE quarter table>, normalised; qi = position in the quarter order."""
    r = resolve(types, find_col, MUE_FIND, fqn)
    return (f"SELECT '{svc}' AS svc, {int(qi)} AS qi, {code_expr(r['code'], types[r['code']])} AS code, "
            f"{int_expr(r['val'], types[r['val']])} AS val FROM {fqn}")


def claims_code(c: dict) -> str:
    return f"UPPER(TRIM(CAST({q(c['code'])} AS STRING)))"


# ---------------------------------------------------------------------- 2. PTP cumulative assumption
def sql_ptp_dropout(old_src: str, new_src: str, examples: int = 5) -> tuple[str, str]:
    """Pairs in the OLDEST PTP quarter that are absent from the NEWEST (latest-only loading loses them)."""
    base = (f"WITH o AS (SELECT DISTINCT a, b FROM ({old_src}) x), n AS (SELECT DISTINCT a, b FROM ({new_src}) y), "
            f"miss AS (SELECT a, b FROM o EXCEPT SELECT a, b FROM n) ")
    return (base + "SELECT (SELECT COUNT(*) FROM o) AS n_old, (SELECT COUNT(*) FROM n) AS n_new, "
                   "(SELECT COUNT(*) FROM miss) AS n_miss",
            base + f"SELECT a, b FROM miss ORDER BY a, b LIMIT {int(examples)}")


# ------------------------------------------------------------------- 3 / B. date coverage (C2-14)
def sql_claims_dates(claims: str, c: dict, befores: list[date], afters: list[date], dos_type: str = "date") -> str:
    """One scan: MIN/MAX date of service, lines dated BEFORE each first-quarter start (no MUE check at all)
    and AFTER each newest-quarter end (judged by a table carried forward past its quarter: edits CMS
    deleted later stay, edits CMS added later are missing - C2-14). Columns before_<i>, after_<i>."""
    d = date_expr(c["dos"], dos_type)
    cols = "".join(f", SUM(CASE WHEN {d} < DATE '{b.isoformat()}' THEN 1 ELSE 0 END) AS before_{i}"
                   for i, b in enumerate(befores))
    cols += "".join(f", SUM(CASE WHEN {d} > DATE '{e.isoformat()}' THEN 1 ELSE 0 END) AS after_{i}"
                    for i, e in enumerate(afters))
    return (f"SELECT MIN({d}) AS lo, MAX({d}) AS hi, COUNT(*) AS n, "
            f"SUM(CASE WHEN {d} IS NULL THEN 1 ELSE 0 END) AS no_dos{cols} FROM {claims}")


# ------------------------------------------------------------- 4 / E. edition overlap and exclusivity
def sql_mue_disagreement(mue_srcs: list[str], claims: str, c: dict) -> tuple[str, str]:
    """Latest MUE quarter per edition: codes in >1 edition and how many disagree, with the paid exposure."""
    u = " UNION ALL ".join(mue_srcs)
    paid = (f"SELECT {claims_code(c)} AS code, COUNT(*) AS lines, SUM({q(c['paid_amt'])}) AS dollars "
            f"FROM {claims} GROUP BY {claims_code(c)}")
    base = f"WITH u AS (SELECT svc, code, val FROM ({u}) x WHERE code IS NOT NULL) "
    summary = (base + f", multi AS (SELECT code, COUNT(DISTINCT svc) AS n_ed, COUNT(DISTINCT val) AS n_val "
                      f"FROM u GROUP BY code HAVING COUNT(DISTINCT svc) > 1), paid AS ({paid}) "
                      f"SELECT COUNT(*) AS codes_in_multiple_editions, "
                      f"COALESCE(SUM(CASE WHEN n_val > 1 THEN 1 ELSE 0 END), 0) AS codes_disagreeing, "
                      f"COALESCE(SUM(CASE WHEN n_val > 1 THEN COALESCE(p.lines, 0) ELSE 0 END), 0) AS disagreeing_claim_lines, "
                      f"COALESCE(SUM(CASE WHEN n_val > 1 THEN COALESCE(p.dollars, 0) ELSE 0 END), 0) AS disagreeing_paid_dollars "
                      f"FROM multi LEFT JOIN paid p ON p.code = multi.code")
    top = (base + "SELECT code, ARRAY_JOIN(SORT_ARRAY(COLLECT_SET(CONCAT(svc, '=', CAST(val AS STRING)))), ', ') AS by_edition "
                  "FROM u GROUP BY code HAVING COUNT(DISTINCT val) > 1 ORDER BY code LIMIT 10")
    return summary, top


def sql_ptp_disagreement(ptp_srcs: list[str]) -> str:
    u = " UNION ALL ".join(ptp_srcs)
    return (f"WITH u AS (SELECT svc, a, b, mi FROM ({u}) x WHERE mi IN ('0', '1')) "
            f"SELECT COUNT(*) AS pairs_multi, COALESCE(SUM(CASE WHEN n_mi > 1 THEN 1 ELSE 0 END), 0) AS pairs_disagree "
            f"FROM (SELECT a, b, COUNT(DISTINCT svc) AS n_ed, COUNT(DISTINCT mi) AS n_mi FROM u GROUP BY a, b "
            f"HAVING COUNT(DISTINCT svc) > 1) k")


def sql_ptp_exclusive(ptp_srcs: list[str], claims: str, c: dict) -> str:
    """C2-02 sizing: active (indicator 0/1) PTP pairs whose BOTH codes are paid in the claims, per edition,
    and how many of them exist in that edition only."""
    u = " UNION ALL ".join(ptp_srcs)
    return (f"WITH u AS (SELECT DISTINCT svc, a, b FROM ({u}) x WHERE mi IN ('0', '1')), "
            f"paid AS (SELECT DISTINCT {claims_code(c)} AS code FROM {claims} WHERE {q(c['code'])} IS NOT NULL), "
            f"s AS (SELECT u.svc, u.a, u.b FROM u JOIN paid pa ON pa.code = u.a JOIN paid pb ON pb.code = u.b), "
            f"k AS (SELECT a, b, COUNT(DISTINCT svc) AS n_ed FROM s GROUP BY a, b) "
            f"SELECT s.svc, COUNT(*) AS pairs_in_claims_scope, "
            f"SUM(CASE WHEN k.n_ed = 1 THEN 1 ELSE 0 END) AS exclusive_pairs "
            f"FROM s JOIN k ON k.a = s.a AND k.b = s.b GROUP BY s.svc ORDER BY s.svc")


def sql_mue_exclusive(mue_srcs: list[str], claims: str, c: dict) -> str:
    """C2-02 sizing: MUE codes paid in the claims, per edition, how many exist in that edition only, and the
    paid lines / dollars on those edition-only codes BY THE EDIT FILE THE LINE TAKES (ncci_routing: provider type x
    form; returned in the column form_typ for compatibility). An edition-only edit on lines of another file is
    exactly what the routing keeps off."""
    import ncci_routing
    u = " UNION ALL ".join(mue_srcs)
    routed = ncci_routing.routed_sql(claims, c, q)
    return (f"WITH u AS (SELECT DISTINCT svc, code FROM ({u}) x WHERE code IS NOT NULL), "
            f"paid AS (SELECT {ncci_routing.PIE_EDITION} AS form_typ, {claims_code(c)} AS code, COUNT(*) AS lines, "
            f"SUM({q(c['paid_amt'])}) AS dollars FROM {routed} rc GROUP BY 1, 2), "
            f"pc AS (SELECT DISTINCT code FROM paid), "
            f"s AS (SELECT u.svc, u.code FROM u JOIN pc ON pc.code = u.code), "
            f"k AS (SELECT code, COUNT(DISTINCT svc) AS n_ed FROM s GROUP BY code), "
            f"t AS (SELECT s.svc, COUNT(*) AS codes_in_claims, SUM(CASE WHEN k.n_ed = 1 THEN 1 ELSE 0 END) AS exclusive_codes "
            f"FROM s JOIN k ON k.code = s.code GROUP BY s.svc), "
            f"f AS (SELECT s.svc, p.form_typ, SUM(p.lines) AS exclusive_lines, SUM(p.dollars) AS exclusive_paid "
            f"FROM s JOIN k ON k.code = s.code AND k.n_ed = 1 JOIN paid p ON p.code = s.code GROUP BY s.svc, p.form_typ) "
            f"SELECT t.svc, t.codes_in_claims, t.exclusive_codes, f.form_typ, f.exclusive_lines, f.exclusive_paid "
            f"FROM t LEFT JOIN f ON f.svc = t.svc ORDER BY t.svc, f.form_typ")


# ------------------------------------------------------------------------- A. FORM_TYP (C2-01/02)
def sql_route_distribution(claims: str, c: dict, desc_col: str | None = None, billing_desc_col: str | None = None,
                           cols: set | None = None) -> str:
    """Lines and dollars per (claim form, BILLING provider type CODE, servicing provider type CODE) and the NCCI edit
    file those lines take (CMS TGM s6.0 Table 2 via ncci_routing - the same expression the detection snapshot uses).
    The description columns are shown to help a person check the mapping; they never decide anything."""
    import ncci_routing as nr
    desc = f"MAX(CAST({q(desc_col)} AS STRING))" if desc_col else "CAST(NULL AS STRING)"
    bdesc = f"MAX(CAST({q(billing_desc_col)} AS STRING))" if billing_desc_col else "CAST(NULL AS STRING)"
    return (f"SELECT {nr.PIE_FORM} AS form_typ, {nr.PIE_BPROV_TYPE} AS bprov_type, {bdesc} AS bprov_type_desc, "
            f"{nr.PIE_PROV_TYPE} AS prov_type, {desc} AS prov_type_desc, {nr.PIE_EDITION} AS ncci_edition, "
            f"COUNT(*) AS lines, SUM({q(c['paid_amt'])}) AS paid FROM {nr.routed_sql(claims, c, q, cols)} rc "
            f"GROUP BY 1, 2, 4, 6 ORDER BY lines DESC")


def sql_form_distribution(claims: str, c: dict) -> str:
    form = f"CAST({q(c['form'])} AS STRING)"
    return (f"SELECT {form} AS form_typ, COUNT(*) AS lines, COUNT(DISTINCT {q(c['claim_id'])}) AS claims, "
            f"SUM({q(c['paid_amt'])}) AS paid FROM {claims} GROUP BY {form} ORDER BY lines DESC")


# ---------------------------------------------------------------------------- C. CCMI change (C2-12)
def sql_ccmi_changes(old_src: str, new_src: str, examples: int = 10) -> tuple[str, str]:
    """Same pair AND same effective date in the oldest and newest PTP quarter, different modifier indicator.
    Latest-only loading applies the NEWEST indicator to every past date of service: a 1 -> 0 change turns a
    past claim with a bypass modifier into a false hard denial; 0 -> 1 misses one."""
    base = (f"WITH o AS ({old_src}), n AS ({new_src}), "
            f"j AS (SELECT o.a, o.b, o.eff, o.mi AS mi_old, n.mi AS mi_new FROM o JOIN n "
            f"ON o.a = n.a AND o.b = n.b AND o.eff = n.eff) ")
    summary = (base + "SELECT COUNT(*) AS joined, "
                      "COALESCE(SUM(CASE WHEN NOT (mi_old <=> mi_new) THEN 1 ELSE 0 END), 0) AS changed, "
                      "COALESCE(SUM(CASE WHEN mi_old = '1' AND mi_new = '0' THEN 1 ELSE 0 END), 0) AS one_to_zero, "
                      "COALESCE(SUM(CASE WHEN mi_old = '0' AND mi_new = '1' THEN 1 ELSE 0 END), 0) AS zero_to_one, "
                      "COALESCE(SUM(CASE WHEN mi_new = '9' AND NOT (mi_old <=> '9') THEN 1 ELSE 0 END), 0) AS to_nine "
                      "FROM j")
    ex = base + (f"SELECT a, b, eff, mi_old, mi_new FROM j WHERE NOT (mi_old <=> mi_new) "
                 f"ORDER BY a, b, eff LIMIT {int(examples)}")
    return summary, ex


# --------------------------------------------------------------------- D. MUE later changes (C2-03)
def sql_mue_later_changes(mue_srcs: list[str], claims: str, c: dict, examples: int = 10) -> tuple[str, str]:
    """Over the loaded MUE quarters of ONE edition (mue_srcs in quarter order, qi = 0..n-1): codes whose value is
    HIGHER in a later quarter than in an earlier one (an earlier-quarter claim between the two values is judged
    by the stricter old value), and codes present in a quarter but absent from the next loaded one (removed
    later), each with the paid claim lines on those codes (any date: an upper bound)."""
    u = " UNION ALL ".join(mue_srcs)
    last = len(mue_srcs) - 1
    base = (f"WITH u AS (SELECT qi, code, val FROM ({u}) x WHERE code IS NOT NULL), "
            f"raised AS (SELECT DISTINCT x.code FROM u x JOIN u y ON y.code = x.code AND y.qi > x.qi AND y.val > x.val), "
            f"p AS (SELECT DISTINCT qi, code FROM u), "
            f"removed AS (SELECT DISTINCT a.code FROM p a LEFT ANTI JOIN p b ON b.code = a.code AND b.qi = a.qi + 1 "
            f"WHERE a.qi < {last}), "
            f"paid AS (SELECT {claims_code(c)} AS code, COUNT(*) AS lines FROM {claims} GROUP BY {claims_code(c)}) ")
    summary = (base + "SELECT r.n AS codes_raised_later, r.lines AS lines_on_raised, "
                      "m.n AS codes_removed_later, m.lines AS lines_on_removed "
                      "FROM (SELECT COUNT(*) AS n, COALESCE(SUM(paid.lines), 0) AS lines FROM raised "
                      "LEFT JOIN paid ON paid.code = raised.code) r "
                      "CROSS JOIN (SELECT COUNT(*) AS n, COALESCE(SUM(paid.lines), 0) AS lines FROM removed "
                      "LEFT JOIN paid ON paid.code = removed.code) m")
    ex = (base + f", ex AS (SELECT code FROM raised ORDER BY code LIMIT {int(examples)}) "
                 f"SELECT u.code, u.qi, u.val FROM u JOIN ex ON ex.code = u.code ORDER BY u.code, u.qi")
    return summary, ex


# ------------------------------------------------------------------------ F. data shape (C1-01..05)
def sql_data_shape(claims: str, c: dict) -> str:
    """One scan: the counts that decide whether the detectors' assumptions hold on this table."""
    paid, units, code = q(c["paid_amt"]), q(c["units"]), f"CAST({q(c['code'])} AS STRING)"
    mods_bad = " OR ".join(f"COALESCE(CAST({q(m)} AS STRING), '') <> UPPER(TRIM(COALESCE(CAST({q(m)} AS STRING), '')))"
                           for m in c["mods"])
    key = lambda x: f"NULLIF(TRIM(CAST({q(x)} AS STRING)), '')"     # noqa: E731
    pa_sum = f"SUM(CASE WHEN {key(c['pa_no'])} IS NOT NULL THEN 1 ELSE 0 END)" if c.get("pa_no") else "CAST(NULL AS BIGINT)"
    # 2026-10-05 (critic re-check N2): the scope member_servicing_billing_day (AHCCCS A* pairs, daily limits) never pairs
    # or counts a line with no billing provider id, and the B2 role billing_or_rendering never flags a group's line with
    # no rendering type - both are misses, counted here so they are seen before anyone signs
    bprov_sum = (f"SUM(CASE WHEN {key(c['billing_provider'])} IS NULL THEN 1 ELSE 0 END)" if c.get("billing_provider")
                 else "CAST(NULL AS BIGINT)")
    import config as _cfg
    import ncci_routing as _nr
    groups = sorted({t for t in (_nr.norm_type(v) for v in (getattr(_cfg, "GROUP_BILLING_PROVIDER_TYPES", ()) or ()))
                     if t})
    group_sum = (f"SUM(CASE WHEN {_nr.type_sql(c['billing_type'])} IN ({', '.join(repr(g) for g in groups)}) "
                 f"AND {_nr.type_sql(c['prov_type'])} IS NULL THEN 1 ELSE 0 END)"
                 if groups and c.get("billing_type") and c.get("prov_type") else "CAST(NULL AS BIGINT)")
    return f"""SELECT COUNT(*) AS lines,
  SUM(CASE WHEN {paid} <= 0 THEN 1 ELSE 0 END) AS paid_nonpositive,
  SUM(CASE WHEN {paid} < 0 THEN 1 ELSE 0 END) AS paid_negative,
  COALESCE(SUM(CASE WHEN {paid} < 0 THEN {paid} END), 0) AS paid_negative_sum,
  SUM(CASE WHEN {paid} IS NULL THEN 1 ELSE 0 END) AS paid_null,
  SUM(CASE WHEN {units} <= 0 THEN 1 ELSE 0 END) AS units_nonpositive,
  SUM(CASE WHEN {units} IS NULL THEN 1 ELSE 0 END) AS units_null,
  SUM(CASE WHEN {code} IS NULL OR TRIM({code}) = '' THEN 1 ELSE 0 END) AS proc_blank,
  SUM(CASE WHEN {code} <> UPPER(TRIM({code})) THEN 1 ELSE 0 END) AS proc_unnormalised,
  SUM(CASE WHEN {mods_bad} THEN 1 ELSE 0 END) AS mods_unnormalised,
  SUM(CASE WHEN {key(c['member'])} IS NULL THEN 1 ELSE 0 END) AS member_missing,
  SUM(CASE WHEN {key(c['servicing_provider'])} IS NULL THEN 1 ELSE 0 END) AS sprov_missing,
  {bprov_sum} AS bprov_missing,
  {group_sum} AS group_billed_no_rendering_type,
  SUM(CASE WHEN {q(c['claim_id'])} IS NULL THEN 1 ELSE 0 END) AS claim_id_null,
  SUM(CASE WHEN {q(c['line_no'])} IS NULL THEN 1 ELSE 0 END) AS line_no_null,
  SUM(CASE WHEN {paid} < 0 AND {units} > 0 THEN 1 ELSE 0 END) AS reversal_units_positive,
  SUM(CASE WHEN {paid} < 0 AND {units} < 0 THEN 1 ELSE 0 END) AS reversal_units_negative,
  {pa_sum} AS pa_filled,
  COUNT(DISTINCT {q(c['member'])}) AS members
FROM {claims}"""


def sql_modifier_examples(claims: str, c: dict, limit: int = 10) -> str:
    arr = ", ".join(f"CAST({q(m)} AS STRING)" for m in c["mods"])
    return (f"SELECT CONCAT('[', md, ']') AS modifier, COUNT(*) AS n FROM (SELECT EXPLODE(ARRAY({arr})) AS md "
            f"FROM {claims}) x WHERE md IS NOT NULL AND md <> UPPER(TRIM(md)) GROUP BY md ORDER BY n DESC, modifier "
            f"LIMIT {int(limit)}")


def sql_duplicate_keys(claims: str, c: dict) -> str:
    """Exact duplicate (ClaimID, LN_NO) keys; keys whose rows DIFFER are versions, not copies (C1-04)."""
    cid, ln = q(c["claim_id"]), q(c["line_no"])
    sig = ", ".join(f"COALESCE(CAST({q(c[k])} AS STRING), '~')" for k in ("code", "units", "paid_amt", "dos"))
    return (f"SELECT COUNT(*) AS dup_keys, COALESCE(SUM(n), 0) AS rows_in_dup_keys, "
            f"COALESCE(SUM(CASE WHEN n_distinct > 1 THEN 1 ELSE 0 END), 0) AS keys_with_differing_rows "
            f"FROM (SELECT {cid}, {ln}, COUNT(*) AS n, COUNT(DISTINCT CONCAT_WS('|', {sig})) AS n_distinct "
            f"FROM {claims} WHERE {cid} IS NOT NULL AND {ln} IS NOT NULL GROUP BY {cid}, {ln} HAVING COUNT(*) > 1) d")


def sql_top_members(claims: str, c: dict, limit: int = 10) -> str:
    """Placeholder detection (C1-05): a '0' / 'UNKNOWN' member key shows up here with a huge line count."""
    m = f"CAST({q(c['member'])} AS STRING)"
    return (f"SELECT {m} AS member_key, COUNT(*) AS lines, COUNT(DISTINCT {q(c['servicing_provider'])}) AS providers "
            f"FROM {claims} GROUP BY {m} ORDER BY lines DESC, member_key LIMIT {int(limit)}")


def sql_dob(claims: str, c: dict, dob_type: str, dos_type: str = "date") -> str:
    """NULL / unparseable date of birth (age-scoped rules never match those lines - they can only be missed),
    plus implausible values (born after the service, before 1900: placeholders such as 1900-01-01)."""
    raw, dob, dos = q(c["dob"]), date_expr(c["dob"], dob_type), date_expr(c["dos"], dos_type)
    return (f"SELECT COUNT(*) AS lines, SUM(CASE WHEN {raw} IS NULL THEN 1 ELSE 0 END) AS dob_null, "
            f"SUM(CASE WHEN {raw} IS NOT NULL AND {dob} IS NULL THEN 1 ELSE 0 END) AS dob_unparseable, "
            f"SUM(CASE WHEN {dob} > {dos} THEN 1 ELSE 0 END) AS dob_after_dos, "
            f"SUM(CASE WHEN {dob} < DATE '1900-01-02' THEN 1 ELSE 0 END) AS dob_1900_or_before FROM {claims}")


def sql_dob_examples(claims: str, c: dict, dob_type: str, limit: int = 5) -> str:
    raw, dob = q(c["dob"]), date_expr(c["dob"], dob_type)
    return (f"SELECT CAST({raw} AS STRING) AS dob, COUNT(*) AS n FROM {claims} WHERE {raw} IS NOT NULL AND {dob} IS NULL "
            f"GROUP BY CAST({raw} AS STRING) ORDER BY n DESC, dob LIMIT {int(limit)}")
