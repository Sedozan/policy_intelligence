"""
ahcccs_tables.py  -  AHCCCS rule tables (Same Day Disallow, HCPCS/CPT Daily Limits, B2 Matrix) -> versioned long
tables -> Rule objects.

AHCCCS publishes some billing rules as DATA on its Medical Coding Resources page. They are read the way the NCCI
files are (acquire_ncci / ingest_ncci_tables): by a deterministic reader that REFUSES what it cannot read, never by
the model, and every rule cites the file, sheet and cell (or row) it comes from. Contract v5.2 (2026-10-04).

Where it is used:
  notebooks/00b_load_ahcccs_tables  parse_file() every workbook in config.AHCCCS_TABLES_DIR -> one long table per table
                                    key (config.AHCCCS_TABLES[key]['table']), appended, one VERSION per file sha256;
                                    every file logged in config.AHCCCS_TABLES_LOG (load_files / write_log) with its
                                    rows_sha256; ends red when check_loaded() finds a table that no longer holds what
                                    the log loaded (v5.2b); drop_zone_files(skipped=) says what it did not read
  notebooks/07_build_kb             frames_for_build() -> check_loaded(frames, log) (v5.2b: stop on any problem) ->
                                    table_compiles() per table (every reading signed, every bound config value as
                                    signed) -> rules_from_frames(scope_codes) -> the gate / normalise / compile path;
                                    table_conflicts() -> the conflicts register; readings_sha256() -> the build log
  notebooks/01_preflight_ncci       check T: loaded_versions() + version_windows() + claims_window_sql(): what each
                                    loaded version judges, how many claim lines fall in it, would 07 compile the table;
                                    check_loaded() (FAIL), claims past config.AHCCCS_TABLE_MAX_AGE_DAYS (WARN)
  notebooks/validation/v03          corpus_entries(): a loaded table is part of the corpus

The three layouts, recognised by their HEADER TEXT (never the file name; verified on the real files of 2026-10-04 by
tests/test_ahcccs_tables.py):
  same_day_disallow  a legend "D = Disallowed  A=Allowable  A*= Allowable on same day for the member, cannot be
                     provided/billed by the same provider ...", a version date "Updated: m/d/yyyy", then a grid: the
                     row of column codes (from column D), their descriptions (column A of that row holds the numbered
                     notes), their units, and one row per code (A code, B description, C unit) with D / A / A* in
                     each cell. Values carry U+00A0 / U+202F spaces. A cell in RED font changed in this version (the
                     footnote: "Changed indicators are noted in red").
  daily_limits       a header 'Procedure Description', 'Procedure Maximum Occurrence', 'Limit 1', 'Frequency 1 Value',
                     'Frequency 1 Cd', 'Limit 2', 'Frequency 2 Value', 'Frequency 2 Cd'; "As of m/d/yy" above it; rows
                     "CODE  - DESCRIPTION", the maximum as zero-padded text ('000048'); blanks are spaces. The report's
                     last row (its print date and time) is a footer, never a code.
  b2_matrix          a header 'Procedure Code', 'Procedure Code Description', 'Provider Type', 'Provider Type
                     Description', 'AHCCCS Coverage Code', 'Category of Service Aggregated', 'Place of Service
                     Aggregated', 'Modifer Aggregated' (sic); "As of m/d/yy" above it. Thousands of merged ranges:
                     every cell of a range takes the top-left value, then duplicate rows and rows with a blank code
                     are dropped. Provider type codes are TEXT ('02', never 2).

Every rule-shaping decision (SB, 2026-10-04) is in ONE block below ("SB's readings"); nothing else in this module
decides what a cell means.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
from datetime import date, datetime, time as dtime, timedelta, timezone

import pandas as pd

import config
import ncci_routing
import schema
from schema import Rule

TABLE_KEYS = ("same_day_disallow", "daily_limits", "b2_matrix")
ORIGIN = "ahcccs_table"

# =====================================================================================================================
# SB's readings - 2026-10-04 (v5.2), contract "SB's decisions (2026-10-04) - binding". EVERY rule-shaping decision of
# this module is here, once, so a reviewer signs exactly what runs; the rule builders below only apply them. Each one is
# a row of reference/ahcccs_table_readings.csv, and a table compiles only while every one of its readings is signed
# (decision 5: table_compiles).
# ---------------------------------------------------------------------------------------------------------------------
# Decision 1 - Same Day Disallow. The legend: "D = Disallowed  A=Allowable  A*= Allowable on same day for the member,
# cannot be provided/billed by the same provider (service site or residential placement)".
#   D  -> the two codes may not be billed for the same member on the same date of service by ANY provider (member_day)
#   A* -> ... not by the SAME provider (config.AHCCCS_SAME_PROVIDER_SCOPE, read at call time: same_provider_scope())
#   A  -> allowed: no rule
# 2026-10-04 (v5.2, critic F5): "same provider" was the servicing provider id only (member_provider_day). The legend
# glosses it as "(service site or residential placement)" and AHCCCS corrected its own A* programming in 2026 without
# publishing the rule, so until SB settles clinician vs site the default is member_servicing_billing_day: the same
# servicing AND the same billing provider id - a finding then breaks the rule under either reading (some misses, never a
# false finding from the choice). The reading A_star binds the config value (its `binds` column).
INDICATORS = ("D", "A*", "A")                       # the legend's three values; any other cell value is refused
PAIR_INDICATORS = ("D", "A*")                       # the two that build a pair rule (A = allowed)
D_SCOPE = "member_day"
# Decision 1 - the ROW code's line is the finding; the per-diem / once-a-day COLUMN code's line is the evidence.
# detector_gen reports a pair on code_b's line, so code_a = the column code and code_b = the row code.
PAIR_FINDING_CODE = "row"
# Decision 1 - a code with itself (the diagonal, e.g. H0014 x H0014 = D) is not a pair rule: the daily limits table
# caps the units of a code.
SKIP_DIAGONAL = True
# Decision 1 - table note 2 qualifies every D / A* pair: predicate "exception" = the note's sentence, so a finding is
# verify_exception (verify_pa with a PA on file), never a plain violation. parse_file refuses a file whose note 2 no
# longer opens with this sentence: the reading (and its signature) rests on it.
NOTE2 = "Exceptions to limitations on service frequency or duration may be approved based on medical necessity."
PAIR_MODIFIER_INDICATOR = "0"                       # the table names no modifier that lets a D / A* pair through
PAIR_SERVICE_CATEGORY = "state_bh"
# Decision 2 - every file is a VERSION dated by its own "Updated" / "As of" date. It judges claims from that date to
# the day before the next loaded version's date (the latest: open-ended); claims before the OLDEST loaded version are
# not judged by the table (SB will obtain AHCCCS's earlier versions). version_windows() is the one implementation.
# Decision 3 - Daily limits: "Procedure Maximum Occurrence" ('000048' -> 48) = the most UNITS of the code per member +
# provider + date of service (config.AHCCCS_DAILY_LIMIT_SCOPE, read at call time: daily_limit_scope()). AHCCCS counts
# the daily limit in units (2020 encounter newsletter: J2350 "procedure daily limit ... changed to 300", 1 mg units).
# The Limit / Frequency columns (Frequency Cd D/W/M/Y/L) are RECORDED, not compiled: period semantics undecided (no
# switch on purpose - compiling them needs a signed reading of what "per 7 D" or "per 1 L" counts, and new code).
# Decision 3, follow-up (2026-10-04, v5.2, the lead): a code whose OWN "N per 1 day" limit (a Limit with Frequency Cd D
# and Frequency Value 1, in Limit 1 or Limit 2) DIFFERS from its Procedure Maximum Occurrence - 82435: maximum 1, Limit 1
# = 4 per 1 day - is a file stating two daily limits. Which one AHCCCS's edit applies is unknown, so NO daily rule is
# built for it (day_limits_differing); table_conflicts lists it as "file_states_two_daily_limits". A 1-day limit EQUAL
# to the maximum agrees with it, and the rule stands.
DAY_LIMIT_FREQUENCY = ("D", 1)                      # (Frequency Cd, Frequency Value) that make a Limit a per-day limit
SKIP_TWO_DAILY_LIMITS = True
# Decision 3, 2026-10-04 (v5.2, critic F2; proposed after independent review, SB to decide - reading not_compiled): a
# row builds NO rule when its code fully matches config.AHCCCS_DAILY_RECORD_ONLY_CODES (anesthesia CPT 00100-01999:
# billed in 15-minute TIME units - FFS Ch10 - yet 272 of the 274 anesthesia codes of the 9/14/26 file have a maximum of
# 1 or 2, so the maximum cannot be a count of units there) or its maximum, as digits, fully matches
# config.AHCCCS_DAILY_PLACEHOLDER_MAX (999 / 999999: a placeholder for "no practical limit"). Both are read at call
# time; table_conflicts lists every such row for SB. A row counts in the FIRST exclusion that applies, in this order:
DAILY_EXCLUSIONS = ("anesthesia_time_units", "placeholder_maximum", "two_daily_limits")
# Decision 4 - B2 Matrix: for a code matching config.AHCCCS_B2_COMPILE_CODES (HCPCS H0xxx / H2xxx, behavioral-health
# only; b2_compiles()) the matrix's provider types for that code and version are the COMPLETE list of provider types
# allowed (provider_type_allowed, codes normalised with ncci_routing.norm_type). Every other matrix code (CPT, S, T, A,
# J, G - billed outside behavioral health too), the places of service and the modifiers: recorded only.
# 2026-10-04 (v5.2, critic F1): which provider's type is judged = config.AHCCCS_B2_PROVIDER_ROLE, read at call time
# (b2_provider_role()). It was the BILLING type, but the matrix names no group billing type (it lists practitioner and
# agency / facility types), so every line a group billing ID (provider type 01, "Group-Payment ID") submitted was a
# finding. Default billing_or_rendering: a line whose billing type is a group type (config.GROUP_BILLING_PROVIDER_TYPES)
# is judged on its rendering (servicing) type, every other line on its billing type (QUERY_SEMANTICS §2 v2.6). The
# reading provider_types binds the values.
# Decision 5 - the readings each table needs SIGNED (status 'signed' + a reviewer) before it compiles, while
# config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS is on. A reading missing from the CSV counts as unsigned.
# 2026-10-04 (v5.2, critic F8): a signature is bound to the config values its words describe (the readings CSV's
# optional `binds` column, "KEY=VALUE; KEY2=VALUE2"): a reading whose bound value config no longer has counts as unsigned
# (binding_mismatches) until it is signed again. Daily limits gain the reading not_compiled (critic F2).
REQUIRED_READINGS = {
    "same_day_disallow": ("D", "A_star", "A", "flagged_line", "exception_note", "diagonal", "versions"),
    "daily_limits": ("daily_max", "not_compiled", "period_limits", "versions"),
    "b2_matrix": ("provider_types", "other_codes", "versions"),
}
# 2026-10-05 (critic re-check N1): the config values each reading's words describe MUST be bound - binds is optional in
# the CSV, so clearing a reading's binds cell (or the column) used to keep it signed while config changed under it. A
# reading that does not bind every key listed here counts as unsigned (binding_mismatches: signed = None).
REQUIRED_BINDS = {
    ("same_day_disallow", "A_star"): ("AHCCCS_SAME_PROVIDER_SCOPE",),
    ("daily_limits", "daily_max"): ("AHCCCS_DAILY_LIMIT_SCOPE",),
    ("daily_limits", "not_compiled"): ("AHCCCS_DAILY_RECORD_ONLY_CODES", "AHCCCS_DAILY_PLACEHOLDER_MAX"),
    ("b2_matrix", "provider_types"): ("AHCCCS_B2_COMPILE_CODES", "AHCCCS_B2_PROVIDER_ROLE",
                                      "GROUP_BILLING_PROVIDER_TYPES"),
}
# =====================================================================================================================


def _config_scope(name: str) -> str:
    s = str(getattr(config, name, "member_servicing_billing_day")).strip()
    if s not in schema.PAIR_SCOPES:
        raise ValueError(f"config.{name} must be one of {schema.PAIR_SCOPES}, got {s!r} - a scope nobody signed is never "
                         f"compiled")
    return s


def daily_limit_scope() -> str:
    """Decision 3: the scope of a daily maximum (config.AHCCCS_DAILY_LIMIT_SCOPE), validated - a typo must not compile."""
    return _config_scope("AHCCCS_DAILY_LIMIT_SCOPE")


def same_provider_scope() -> str:
    """Decision 1: the scope of an A* pair (config.AHCCCS_SAME_PROVIDER_SCOPE), validated like daily_limit_scope().
    2026-10-04 (v5.2, critic F5)."""
    return _config_scope("AHCCCS_SAME_PROVIDER_SCOPE")


def indicator_scope(indicator) -> str | None:
    """Decision 1: the pair scope a Same Day indicator builds (D: member_day; A*: same_provider_scope()); None for A."""
    return {"D": D_SCOPE, "A*": same_provider_scope()}.get(indicator) if indicator in PAIR_INDICATORS else None


def b2_compiles(code) -> bool:
    """Decision 4: does the B2 Matrix compile this code's provider list (config.AHCCCS_B2_COMPILE_CODES)?"""
    return bool(re.fullmatch(getattr(config, "AHCCCS_B2_COMPILE_CODES", r"^H[02][0-9]{3}$"), schema.norm_code(code)))


def b2_provider_role() -> str:
    """Decision 4: whose provider type a B2 rule judges (config.AHCCCS_B2_PROVIDER_ROLE), validated against
    schema.PROVIDER_ROLES - a typo must not compile. 2026-10-04 (v5.2, critic F1)."""
    s = str(getattr(config, "AHCCCS_B2_PROVIDER_ROLE", "billing_or_rendering")).strip()
    if s not in schema.PROVIDER_ROLES:
        raise ValueError(f"config.AHCCCS_B2_PROVIDER_ROLE must be one of {schema.PROVIDER_ROLES}, got {s!r} - a role "
                         f"nobody signed is never compiled")
    return s


def group_billing_types() -> list[str]:
    """config.GROUP_BILLING_PROVIDER_TYPES cleaned as the claims column is (' 1 ' / 1 / '1.0' -> '01'), sorted."""
    return sorted({t for t in (ncci_routing.norm_type(v) for v in getattr(config, "GROUP_BILLING_PROVIDER_TYPES", ())
                               or ()) if t})


def day_limits_differing(rec) -> list[tuple[str, int]]:
    """Decision 3 follow-up: [(limit number, N)] of a Daily Limits row's own 'N per 1 day' limits (Frequency Cd D,
    Frequency Value 1) that differ from its Procedure Maximum Occurrence. Non-empty = the file states two daily limits
    for the code and no daily rule is built. rec: a frame row (attributes) or a dict."""
    get = rec.get if isinstance(rec, dict) else (lambda k: getattr(rec, k))
    out = []
    for n in ("1", "2"):
        lim = get(f"limit{n}")
        if (get(f"freq{n}_cd"), get(f"freq{n}_value")) == DAY_LIMIT_FREQUENCY and lim is not None \
                and int(lim) != int(get("daily_max")):
            out.append((n, int(lim)))
    return out


def daily_exclusion(rec) -> str | None:
    """Decision 3: why a Daily Limits row builds no rule - the first of DAILY_EXCLUSIONS that applies - or None (it
    builds one). 2026-10-04 (v5.2, critic F2): 'anesthesia_time_units' (the code fully matches
    config.AHCCCS_DAILY_RECORD_ONLY_CODES), 'placeholder_maximum' (str(int(daily_max)) fully matches
    config.AHCCCS_DAILY_PLACEHOLDER_MAX), 'two_daily_limits' (day_limits_differing). rec: a frame row or a dict."""
    get = rec.get if isinstance(rec, dict) else (lambda k: getattr(rec, k))
    record_only = getattr(config, "AHCCCS_DAILY_RECORD_ONLY_CODES", None)
    placeholder = getattr(config, "AHCCCS_DAILY_PLACEHOLDER_MAX", None)
    mx = get("daily_max")
    if record_only and re.fullmatch(record_only, schema.norm_code(get("code"))):
        return "anesthesia_time_units"
    if placeholder and mx is not None and not _is_null(mx) and re.fullmatch(placeholder, str(int(mx))):
        return "placeholder_maximum"
    if SKIP_TWO_DAILY_LIMITS and day_limits_differing(rec):
        return "two_daily_limits"
    return None


# ------------------------------------------------------------------------------------------------ table shapes
# The normalised long tables (contract v5.2): parse_file returns these columns; 00b adds loaded_at and appends.
TABLE_COLUMNS = {
    "same_day_disallow": ["version_date", "file_sha256", "file_name", "sheet", "row_code", "row_description",
                          "row_unit", "col_code", "col_unit", "indicator", "changed", "cell"],
    "daily_limits": ["version_date", "file_sha256", "file_name", "sheet", "code", "description", "daily_max",
                     "limit1", "freq1_value", "freq1_cd", "limit2", "freq2_value", "freq2_cd", "source_row"],
    "b2_matrix": ["version_date", "file_sha256", "file_name", "sheet", "code", "code_description", "provider_type",
                  "provider_type_description", "coverage_code", "category_of_service", "places_of_service",
                  "modifiers", "source_row"],
}
_INT_COLUMNS = {"daily_max", "limit1", "freq1_value", "limit2", "freq2_value", "source_row"}
_BOOL_COLUMNS = {"changed"}
# Spark types pinned on every write (kb_io.write_table schema=): '02' stays text, counts stay whole numbers whatever a
# batch holds (an all-blank limit column must not become DOUBLE - C4-13)
TABLE_SCHEMA = {k: {c: ("boolean" if c in _BOOL_COLUMNS else "long" if c in _INT_COLUMNS else "string")
                    for c in cols + ["loaded_at"]} for k, cols in TABLE_COLUMNS.items()}
# 2026-10-04 (v5.2, critic F7): + rows_sha256 = rows_sha256(table_key, the version's rows) - check_loaded compares the
# tables with it (appended LAST: a log written before it reads the column as NULL; the count is then all it checks)
LOG_COLUMNS = ["table_key", "file_name", "file_sha256", "version_date", "rows", "status", "detail", "loaded_at",
               "archived_path", "rows_sha256"]
LOG_SCHEMA = {c: ("long" if c == "rows" else "string") for c in LOG_COLUMNS}
LOG_STATUSES = ("loaded", "already_loaded", "rejected")
ARCHIVE_DIRNAME = "_versions"                       # AHCCCS_TABLES_DIR/_versions/<table_key>/<version_date>_<sha12>.xlsx

CODE_RE = re.compile(r"^[A-Z0-9]{5}$")              # CPT / HCPCS Level II: every code the three files carry
FREQ_CODES = ("D", "W", "M", "Y", "L")              # day / week / month / year / lifetime (recorded, not compiled)
_MDY = r"(\d{1,2}/\d{1,2}/(?:\d{4}|\d{2}))"
VERSION_PATTERNS = {
    "same_day_disallow": re.compile(r"\bupdated\s*:?\s*" + _MDY + r"(?!\d)", re.I),
    "daily_limits": re.compile(r"\bas\s+of\s+" + _MDY + r"(?!\d)", re.I),
    "b2_matrix": re.compile(r"\bas\s+of\s+" + _MDY + r"(?!\d)", re.I),
}
# header rows, normalised (lower case, letters and digits only), in column order
DAILY_HEADER = ("proceduredescription", "proceduremaximumoccurrence", "limit1", "frequency1value", "frequency1cd",
                "limit2", "frequency2value", "frequency2cd")
DAILY_FIELDS = ("description_raw", "max", "limit1", "freq1_value", "freq1_cd", "limit2", "freq2_value", "freq2_cd")
B2_HEADER = ("procedurecode", "procedurecodedescription", "providertype", "providertypedescription",
             "ahcccscoveragecode", "categoryofserviceaggregated", "placeofserviceaggregated",
             ("modiferaggregated", "modifieraggregated"))          # AHCCCS spells it 'Modifer'
B2_FIELDS = ("code", "code_description", "provider_type", "provider_type_description", "coverage_code",
             "category_of_service", "places_of_service", "modifiers")
# the Same Day legend, normalised: SB's readings (decision 1) rest on these words - a legend without them is refused
SAME_DAY_LEGEND = ("d=disallowed", "a=allowable",
                   "a*=allowableonsamedayforthemember,cannotbeprovided/billedbythesameprovider")
HEADER_SCAN_ROWS = 60

# every kind of space the files carry (U+00A0 no-break, U+202F narrow no-break ...) + zero-width / BOM characters
_SPACE_RE = re.compile(r"[\s\u00a0\u202f\u2007\u2009\u200b\ufeff]+")


# ------------------------------------------------------------------------------------------------ small helpers
def _clean(v) -> str:
    """Cell text with every kind of space collapsed to one and trimmed; None -> ''."""
    if v is None:
        return ""
    return _SPACE_RE.sub(" ", str(v)).strip()


def _norm(v) -> str:
    return re.sub(r"[^a-z0-9*=,/]", "", _clean(v).lower())


def _hnorm(v) -> str:
    """A header cell normalised: lower case letters and digits only."""
    return re.sub(r"[^a-z0-9]", "", _clean(v).lower())


def _text(v) -> str:
    """A cell as text: a whole number without '.0', a date as ISO, text cleaned; None -> ''."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else repr(v)
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return _clean(v)


def _is_null(v) -> bool:
    if v is None:
        return True
    if isinstance(v, (list, dict, tuple, set)):
        return False
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _none_or_text(v):
    return None if _is_null(v) or _clean(v) == "" else _clean(v)


def _iso_mdy(s: str) -> str:
    """'10/1/26' / '10/1/2026' -> '2026-10-01' (a two-digit year is 20yy). An impossible date is refused."""
    m, d, y = (int(x) for x in s.split("/"))
    y = 2000 + y if y < 100 else y
    try:
        return date(y, m, d).isoformat()
    except ValueError as e:
        raise ValueError(f"version date {s!r} is not a calendar date ({e})") from None


def _iso_date(v) -> str:
    """An ISO date text from an ISO text / date / Timestamp; anything else is refused."""
    if isinstance(v, (datetime, pd.Timestamp)):
        return v.date().isoformat() if hasattr(v, "date") else str(v)[:10]
    if isinstance(v, date):
        return v.isoformat()
    s = _clean(v)
    try:
        return date.fromisoformat(s[:10]).isoformat() if len(s) >= 10 else date.fromisoformat(s).isoformat()
    except ValueError:
        raise ValueError(f"{v!r} is not an ISO date (yyyy-mm-dd)") from None


def _whole(v, what: str) -> int | None:
    """'  4' / '003' / 4 / 4.0 -> 4; blank -> None; anything else is refused (never guessed)."""
    if v is None or (isinstance(v, str) and _clean(v) == ""):
        return None
    if isinstance(v, bool):
        raise ValueError(f"{what}: {v!r} is not a whole number")
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        if v.is_integer():
            return int(v)
        raise ValueError(f"{what}: {v!r} is not a whole number")
    s = _clean(v)
    if s.isdigit():
        return int(s)
    raise ValueError(f"{what}: {v!r} is not a whole number")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _red(font) -> bool:
    """The cell's font is red (#FF0000): an RGB colour, or a palette index that resolves to it. A theme colour cannot
    be resolved without the workbook theme and counts as not red (the real file uses RGB FFFF0000)."""
    c = getattr(font, "color", None) if font is not None else None
    if c is None:
        return False
    kind = getattr(c, "type", None)
    rgb = None
    if kind == "rgb":
        rgb = c.rgb
    elif kind == "indexed":
        from openpyxl.styles.colors import COLOR_INDEX
        i = c.indexed
        rgb = COLOR_INDEX[i] if isinstance(i, int) and 0 <= i < len(COLOR_INDEX) else None
    return isinstance(rgb, str) and rgb.upper()[-6:] == "FF0000"


# ------------------------------------------------------------------------------------------------ layout detection
def _top_rows(ws, scan: int = HEADER_SCAN_ROWS) -> list[tuple[int, tuple]]:
    last = min(scan, ws.max_row or 0)
    return list(enumerate(ws.iter_rows(min_row=1, max_row=last, values_only=True), start=1)) if last else []


def _match_header(row: tuple, spec: tuple) -> dict | None:
    """{position in spec: column index (1-based)} when the row's first non-blank cells are `spec`, in order.
    2026-10-04 (v5.2, critic F6): a non-blank cell AFTER them no longer hides the layout ("not a layout this loader
    knows"): the layout is recognised and its parser refuses that cell by name (_refuse_right_of)."""
    cells = [(c, _hnorm(v)) for c, v in enumerate(row, start=1) if _hnorm(v)]
    if len(cells) < len(spec):
        return None
    for (c, n), want in zip(cells, spec):
        if n not in (want if isinstance(want, tuple) else (want,)):
            return None
    return {i: c for i, (c, _) in enumerate(cells[:len(spec)])}


def _refuse_right_of(ws, key: str, first_row: int, last_col: int, last_header: str) -> None:
    """2026-10-04 (v5.2, critic F6): any non-blank cell right of the table's last known column (last_col), from the
    header row (first_row) to the sheet's last row - a column AHCCCS adds, with or without a header, is refused naming
    the cell, never dropped silently. Blank = empty or spaces only (the files write blanks as spaces). Reads the cells
    the sheet holds (openpyxl's cell store), not every coordinate of a wide sheet."""
    store = getattr(ws, "_cells", None)
    if isinstance(store, dict):
        found = ((r, c, cell.value) for (r, c), cell in store.items() if r >= first_row and c > last_col)
    else:
        found = ((cell.row, cell.column, cell.value) for row in ws.iter_rows(min_row=first_row, min_col=last_col + 1)
                 for cell in row)
    hits = sorted((r, c, v) for r, c, v in found if _clean(v) != "")
    if hits:
        from openpyxl.utils import get_column_letter
        r, c, v = hits[0]
        raise ValueError(f"{key}: cell {get_column_letter(c)}{r} holds {v!r} to the right of the table's last known "
                         f"column ({last_header}) - a column this loader does not read is refused, never dropped "
                         f"silently ({len(hits)} such cell(s); first shown)")


def _find_header(ws, spec: tuple) -> tuple[int, dict] | None:
    for r, row in _top_rows(ws):
        m = _match_header(row, spec)
        if m is not None:
            return r, m
    return None


def _find_legend(ws) -> tuple[int, int, str] | None:
    for r, row in _top_rows(ws):
        for c, v in enumerate(row, start=1):
            n = _norm(v)
            if "d=disallowed" in n and "a*=" in n:
                return r, c, _clean(v)
    return None


def detect_layout(ws) -> str | None:
    """The table key whose header text this sheet carries, or None. Two layouts on one sheet is refused."""
    hits = [k for k, found in (("same_day_disallow", _find_legend(ws)), ("daily_limits", _find_header(ws, DAILY_HEADER)),
                               ("b2_matrix", _find_header(ws, B2_HEADER))) if found is not None]
    if len(hits) > 1:
        raise ValueError(f"sheet {ws.title!r} carries the headers of {hits} at once - not a layout this loader knows")
    return hits[0] if hits else None


def _version_date(ws, key: str, above_row: int) -> tuple[str, str]:
    """(ISO version date, the cell text it was read from), from the rows above the table. Two different dates, or
    none, is refused."""
    pat = VERSION_PATTERNS[key]
    hits = []
    for r, row in _top_rows(ws, max(above_row - 1, 0)):
        for v in row:
            t = _clean(v)
            m = pat.search(t) if t else None
            if m:
                hits.append((_iso_mdy(m.group(1)), t))
    if not hits:
        want = "'Updated: m/d/yyyy'" if key == "same_day_disallow" else "'As of m/d/yy'"
        raise ValueError(f"{key}: no version date ({want}) above the table in sheet {ws.title!r} - every file is a "
                         f"version and must say its date (contract v5.2 decision 2)")
    if len({h[0] for h in hits}) > 1:
        raise ValueError(f"{key}: sheet {ws.title!r} states two different version dates {sorted({h[1] for h in hits})}")
    return hits[0]


# ------------------------------------------------------------------------------------------------ parsers
def _parse_same_day(ws) -> tuple[pd.DataFrame, dict, str]:
    legend_r, legend_c, legend = _find_legend(ws)
    ln = _norm(legend)
    missing = [k for k in SAME_DAY_LEGEND if k not in ln]
    if missing:
        raise ValueError(f"same_day_disallow: the legend no longer reads D = Disallowed / A = Allowable / A* = allowable "
                         f"on the same day for the member, not by the same provider (got {legend!r}) - SB's readings "
                         f"(contract v5.2 decision 1) rest on it")
    version, version_text = _version_date(ws, "same_day_disallow", legend_r)
    # the column-code row: the first row below the legend with column codes
    header_r = cols = None
    for r in range(legend_r + 1, min(legend_r + 10, ws.max_row) + 1):
        found = [(c, _clean(ws.cell(r, c).value).upper()) for c in range(1, ws.max_column + 1)]
        codes = [(c, v) for c, v in found if CODE_RE.match(v)]
        if len(codes) >= 2:
            header_r, cols = r, codes
            break
    if header_r is None:
        raise ValueError("same_day_disallow: no row of column codes below the legend")
    first, last = cols[0][0], cols[-1][0]
    if first != 4:
        raise ValueError(f"same_day_disallow: the column codes start in column {first}, not D - the row code, its "
                         f"description and its unit are expected in A, B and C")
    # 2026-10-04 (v5.2, critic F6): nothing right of the last column code, in the header rows or the grid - a trailing
    # column whose header is not a bare code (or has none) used to be dropped silently
    _refuse_right_of(ws, "same_day_disallow", header_r, last,
                     f"{ws.cell(header_r, last).coordinate} {cols[-1][1]!r}, the last column code")
    gap = [ws.cell(header_r, c).coordinate for c in range(first, last + 1) if c not in {c_ for c_, _ in cols}]
    if gap:
        raise ValueError(f"same_day_disallow: column header cell(s) {gap} between the column codes are not codes")
    col_codes = {c: v for c, v in cols}
    dup = sorted({v for v in col_codes.values() if list(col_codes.values()).count(v) > 1})
    if dup:
        raise ValueError(f"same_day_disallow: column code(s) {dup} appear twice in one version")
    desc_r, unit_r = header_r + 1, header_r + 2
    col_desc = {c: _clean(ws.cell(desc_r, c).value) for c in col_codes}
    col_unit = {c: _clean(ws.cell(unit_r, c).value) for c in col_codes}
    no_unit = [col_codes[c] for c, u in col_unit.items() if not u]
    if no_unit:
        raise ValueError(f"same_day_disallow: no unit (row {unit_r}) for column code(s) {no_unit}")
    # the numbered notes (column A, below the legend and above the grid): note 2 is the exception (decision 1)
    notes_text = next((_clean(ws.cell(r, 1).value) for r in range(legend_r + 1, unit_r + 1)
                       if re.match(r"^1\.\s", _clean(ws.cell(r, 1).value))), "")
    parts = re.split(r"(?:^|(?<=\s))(\d{1,2})\.\s+", notes_text)
    notes = {int(parts[i]): parts[i + 1].strip() for i in range(1, len(parts) - 1, 2)}
    if sorted(notes) != list(range(1, len(notes) + 1)) or 2 not in notes:
        raise ValueError(f"same_day_disallow: the numbered table notes (1., 2., ...) were not found above the grid "
                         f"(got {notes_text[:120]!r})")
    if not _clean(notes[2]).lower().startswith(NOTE2.lower()):
        raise ValueError(f"same_day_disallow: table note 2 no longer opens with {NOTE2!r} (got {notes[2][:160]!r}) - "
                         f"the exception reading (decision 1, reading 'exception_note') rests on that sentence; update "
                         f"ahcccs_tables.NOTE2 and have the reading re-signed before loading this file")
    # the grid: one row per code, from the row below the units, while column A holds a code
    rows, r = [], unit_r + 1
    seen_rows: dict[str, int] = {}
    counts = {k: 0 for k in INDICATORS}
    changed_by = {k: 0 for k in INDICATORS}
    while r <= ws.max_row and CODE_RE.match(_clean(ws.cell(r, 1).value).upper()):
        code = _clean(ws.cell(r, 1).value).upper()
        if code in seen_rows:
            raise ValueError(f"same_day_disallow: row code {code} appears twice in one version (rows {seen_rows[code]} "
                             f"and {r})")
        seen_rows[code] = r
        row_desc, row_unit = _clean(ws.cell(r, 2).value), _clean(ws.cell(r, 3).value)
        for c, col in col_codes.items():
            cell = ws.cell(r, c)
            ind = _clean(cell.value).upper()
            if ind not in INDICATORS:
                raise ValueError(f"same_day_disallow: cell {cell.coordinate} ({code} x {col}) holds {cell.value!r}, "
                                 f"not D, A or A* (the legend's three values)")
            red = _red(cell.font)
            counts[ind] += 1
            changed_by[ind] += int(red)
            rows.append({"row_code": code, "row_description": row_desc, "row_unit": row_unit, "col_code": col,
                         "col_unit": col_unit[c], "indicator": ind, "changed": bool(red), "cell": cell.coordinate})
        r += 1
    if not rows:
        raise ValueError(f"same_day_disallow: no row code below the column units (row {unit_r + 1} onwards)")
    grid_end = r
    # below the grid only the footnotes may follow: a code or an indicator there is a second block nobody reads
    footnotes = []
    for rr, vals in enumerate(ws.iter_rows(min_row=grid_end, max_col=last, values_only=True), start=grid_end):
        a = _clean(vals[0])
        if CODE_RE.match(a.upper()) or any(_clean(vals[c - 1]) for c in col_codes):
            raise ValueError(f"same_day_disallow: unexpected content at row {rr} below the grid (rows "
                             f"{unit_r + 1}-{grid_end - 1}) - a code or an indicator outside the table")
        txt = " ".join(t for t in (_clean(v) for v in vals[:first - 1]) if t)
        if txt:
            footnotes.append(txt)
    frame = pd.DataFrame(rows)
    stats = {"version_text": version_text, "legend": legend, "row_codes": len(seen_rows), "col_codes": len(col_codes),
             "cells": len(frame), "indicators": counts, "changed": int(frame["changed"].sum()),
             "changed_by_indicator": changed_by,
             "diagonal": int((frame["row_code"] == frame["col_code"]).sum()),
             "notes": {str(k): v for k, v in notes.items()}, "footnotes": footnotes,
             "grid": f"{ws.cell(header_r, first).coordinate}:{ws.cell(grid_end - 1, last).coordinate}",
             "column_descriptions": {col_codes[c]: col_desc[c] for c in col_codes}}
    return frame, stats, version


_DAILY_ROW_RE = re.compile(r"^(\S+) -(?: (.*))?$")


def _parse_daily(ws) -> tuple[pd.DataFrame, dict, str]:
    header_r, pos = _find_header(ws, DAILY_HEADER)
    # 2026-10-04 (v5.2, critic F6): nothing right of the 8 header columns, in the header row or any row below it
    last = max(pos.values())
    _refuse_right_of(ws, "daily_limits", header_r, last,
                     f"{ws.cell(header_r, last).coordinate} {_clean(ws.cell(header_r, last).value)!r}")
    version, version_text = _version_date(ws, "daily_limits", header_r)
    colidx = {DAILY_FIELDS[i]: c for i, c in pos.items()}
    rows, seen = [], {}
    blank, footer = 0, None
    values = list(enumerate(ws.iter_rows(min_row=header_r + 1, values_only=True), start=header_r + 1))
    last_nonblank = max((r for r, v in values if any(_text(x) for x in v)), default=header_r)
    for r, v in values:
        cell = {k: (v[c - 1] if c - 1 < len(v) else None) for k, c in colidx.items()}
        if not any(_text(x) for x in v):
            blank += 1
            continue
        a = cell["description_raw"]
        if isinstance(a, (datetime, date, dtime)) or (a is None and any(isinstance(x, (datetime, dtime)) for x in v)):
            # the report's footer: its print date and time (and a page number) - tolerated ONLY as the last row
            if r != last_nonblank:
                raise ValueError(f"daily_limits: row {r} holds a date ({a!r}) where a 'CODE - DESCRIPTION' belongs, "
                                 f"and it is not the report's last row")
            footer = " ".join(_text(x) for x in v if _text(x))
            continue
        m = _DAILY_ROW_RE.match(_clean(a))
        if not m:
            raise ValueError(f"daily_limits: row {r}: {a!r} is not 'CODE - DESCRIPTION'")
        code = m.group(1).upper()
        if not CODE_RE.match(code):
            raise ValueError(f"daily_limits: row {r}: procedure code {m.group(1)!r} is not a 5-character CPT/HCPCS code")
        if code in seen:
            raise ValueError(f"daily_limits: code {code} appears twice in one version (rows {seen[code]} and {r})")
        seen[code] = r
        mx = _whole(cell["max"], f"daily_limits: row {r} ({code}) Procedure Maximum Occurrence")
        if mx is None or mx <= 0:
            raise ValueError(f"daily_limits: row {r} ({code}): Procedure Maximum Occurrence {cell['max']!r} is not a "
                             f"positive whole number")
        rec = {"code": code, "description": _clean(m.group(2) or ""), "daily_max": mx, "source_row": r}
        for n in ("1", "2"):
            lim = _whole(cell[f"limit{n}"], f"daily_limits: row {r} ({code}) Limit {n}")
            val = _whole(cell[f"freq{n}_value"], f"daily_limits: row {r} ({code}) Frequency {n} Value")
            cd = _clean(cell[f"freq{n}_cd"]).upper() or None
            if cd is not None and cd not in FREQ_CODES:
                raise ValueError(f"daily_limits: row {r} ({code}): Frequency {n} Cd {cell[f'freq{n}_cd']!r} is not one "
                                 f"of {FREQ_CODES}")
            if len({lim is None, val is None, cd is None}) > 1:
                raise ValueError(f"daily_limits: row {r} ({code}): Limit {n} / Frequency {n} Value / Frequency {n} Cd "
                                 f"must be all filled or all blank (got {cell[f'limit{n}']!r}, "
                                 f"{cell[f'freq{n}_value']!r}, {cell[f'freq{n}_cd']!r})")
            rec.update({f"limit{n}": lim, f"freq{n}_value": val, f"freq{n}_cd": cd})
        if rec["limit2"] is not None and rec["limit1"] is None:
            raise ValueError(f"daily_limits: row {r} ({code}): a Limit 2 without a Limit 1")
        rows.append(rec)
    if not rows:
        raise ValueError(f"daily_limits: no 'CODE - DESCRIPTION' row below the header (row {header_r})")
    frame = pd.DataFrame(rows)
    f1, f2 = frame["freq1_cd"].dropna(), frame["freq2_cd"].dropna()
    # decision 3 follow-up: codes whose own 'per 1 day' limit differs from the daily maximum (no rule is built for them)
    two = [rec["code"] for rec in rows if day_limits_differing(rec)]
    # 2026-10-04 (v5.2, critic F2): what 07 will not compile, by the first exclusion that applies (config at parse time)
    excl = [daily_exclusion(rec) for rec in rows]
    mx = frame["daily_max"]
    stats = {"version_text": version_text, "rows": len(frame), "codes": int(frame["code"].nunique()),
             "max_eq_1": int((mx == 1).sum()), "max_eq_999": int((mx == 999).sum()), "max_top": int(mx.max()),
             "freq1_cd": {k: int(v) for k, v in f1.value_counts().items()},
             "freq2_cd": {k: int(v) for k, v in f2.value_counts().items()},
             "period_limit_rows": int(len(f1)), "second_limits": int(len(f2)),
             "per_day_limit_differs_from_max": len(two), "two_daily_limits": two, "blank_rows": blank,
             "footer": footer, "not_compiled": {k: excl.count(k) for k in DAILY_EXCLUSIONS}}
    return frame, stats, version


def _parse_b2(ws) -> tuple[pd.DataFrame, dict, str]:
    header_r, pos = _find_header(ws, B2_HEADER)
    # 2026-10-04 (v5.2, critic F6): nothing right of the 8 header columns, in the header row or any row below it
    last = max(pos.values())
    _refuse_right_of(ws, "b2_matrix", header_r, last,
                     f"{ws.cell(header_r, last).coordinate} {_clean(ws.cell(header_r, last).value)!r}")
    version, version_text = _version_date(ws, "b2_matrix", header_r)
    colidx = {B2_FIELDS[i]: c for i, c in pos.items()}
    ncols = max(colidx.values())
    first = header_r + 1
    grid = {r: list(v) + [None] * (ncols - len(v))
            for r, v in enumerate(ws.iter_rows(min_row=first, max_col=ncols, values_only=True), start=first)}
    merged = list(ws.merged_cells.ranges)
    for mr in merged:
        if mr.max_row < first or mr.min_col > ncols:
            continue
        if mr.min_row < first:
            raise ValueError(f"b2_matrix: merged range {mr.coord} crosses the header row {header_r}")
        v = ws.cell(mr.min_row, mr.min_col).value               # every cell of a range takes the top-left value
        for r in range(mr.min_row, mr.max_row + 1):
            for c in range(mr.min_col, min(mr.max_col, ncols) + 1):
                grid.setdefault(r, [None] * ncols)[c - 1] = v
    rows, seen, by_key = [], set(), {}
    blank = dupes = 0
    for r in sorted(grid):
        rec = {k: _text(grid[r][c - 1]) for k, c in colidx.items()}
        if not rec["code"]:
            if any(rec.values()):
                raise ValueError(f"b2_matrix: row {r} has no procedure code but holds {rec}")
            blank += 1
            continue
        key = tuple(rec[k] for k in B2_FIELDS)
        if key in seen:                                          # a merged record's continuation row, or a repeat
            dupes += 1
            continue
        seen.add(key)
        code = rec["code"].upper()
        if not CODE_RE.match(code):
            raise ValueError(f"b2_matrix: row {r}: procedure code {rec['code']!r} is not a 5-character CPT/HCPCS code")
        pt = ncci_routing.norm_type(rec["provider_type"])
        if not pt or not re.fullmatch(r"[A-Z0-9]{1,4}", pt):
            raise ValueError(f"b2_matrix: row {r} ({code}): provider type {rec['provider_type']!r} is not a provider "
                             f"type code")
        if (code, pt) in by_key:
            raise ValueError(f"b2_matrix: code {code} with provider type {pt} appears twice in one version with "
                             f"different values (rows {by_key[(code, pt)]} and {r})")
        by_key[(code, pt)] = r
        rows.append(dict(rec, code=code, provider_type=pt, source_row=r))
    if not rows:
        raise ValueError(f"b2_matrix: no procedure code below the header (row {header_r})")
    frame = pd.DataFrame(rows)[[f for f in B2_FIELDS] + ["source_row"]]
    codes = sorted(frame["code"].unique())
    kinds: dict[str, int] = {}
    for c in codes:
        k = ("H0xxx/H2xxx" if re.fullmatch(r"H[02]\d{3}", c) else "CPT" if re.fullmatch(r"\d{4}[0-9A-Z]", c)
             else c[0])
        kinds[k] = kinds.get(k, 0) + 1
    stats = {"version_text": version_text, "merged_ranges": len(merged), "sheet_rows": len(grid), "rows": len(frame),
             "codes": len(codes), "provider_types": int(frame["provider_type"].nunique()),
             "codes_by_kind": kinds, "compile_codes": sum(1 for c in codes if b2_compiles(c)),
             "duplicate_rows_dropped": dupes, "blank_code_rows": blank}
    return frame, stats, version


_PARSERS = {"same_day_disallow": _parse_same_day, "daily_limits": _parse_daily, "b2_matrix": _parse_b2}


def parse_file(path: str) -> dict:
    """Read one AHCCCS rule-table workbook. The layout is recognised by its header text (never the file name).

    Returns {table_key, version_date (ISO), sheet, frame (pandas: TABLE_COLUMNS[table_key]), stats, file_name,
    file_sha256, path}. Raises ValueError naming what is wrong: not a workbook, no / two known layouts, no version date,
    an indicator other than D / A / A*, a code twice in one version, a non-numeric daily maximum, a changed legend or
    table note 2, content where none belongs - since 2026-10-04 (v5.2, critic F6) also any non-blank cell right of the
    table's last known column, named (Same Day: the last column code; Daily Limits / B2: the 8 header columns) ..."""
    import openpyxl
    name = os.path.basename(path)
    try:
        # not read_only: the red font (changed in this version) and the merged ranges are needed
        wb = openpyxl.load_workbook(path, data_only=True)
    except Exception as e:
        raise ValueError(f"{name}: not a readable .xlsx workbook ({type(e).__name__}: {str(e)[:200]})") from None
    try:
        found = [(detect_layout(ws), ws) for ws in wb.worksheets]
        found = [(k, ws) for k, ws in found if k]
        if not found:
            raise ValueError(f"{name}: not a layout this loader knows - no sheet carries the Same Day Disallow legend, "
                             f"the Daily Limits header or the B2 Matrix header (sheets {wb.sheetnames})")
        if len(found) > 1:
            raise ValueError(f"{name}: several sheets carry a known layout {[(k, ws.title) for k, ws in found]} - one "
                             f"file must be one table version")
        key, ws = found[0]
        try:
            frame, stats, version = _PARSERS[key](ws)
        except ValueError as e:
            raise ValueError(f"{name} (sheet {ws.title!r}): {e}") from None
        sha = sha256_file(path)
        frame.insert(0, "version_date", version)
        frame.insert(1, "file_sha256", sha)
        frame.insert(2, "file_name", name)
        frame.insert(3, "sheet", ws.title)
        # Python values in object columns: an int column with blanks must not come back as float (4 -> 4.0)
        frame = normalise_frame(key, frame[TABLE_COLUMNS[key]])
        return {"table_key": key, "version_date": version, "sheet": ws.title, "frame": frame, "stats": stats,
                "file_name": name, "file_sha256": sha, "path": path}
    finally:
        wb.close()


# ------------------------------------------------------------------------------------------------ versions (decision 2)
def version_windows(version_dates) -> dict:
    """{version_date: (effective_date, end_date or None)}: a version judges claims from its own date to the day before
    the next version's date; the latest is open-ended (contract v5.2 decision 2). Duplicates collapse."""
    ds = sorted({_iso_date(d) for d in version_dates if not _is_null(d) and _clean(d) != ""})
    out = {}
    for i, d in enumerate(ds):
        nxt = ds[i + 1] if i + 1 < len(ds) else None
        out[d] = (d, (date.fromisoformat(nxt) - timedelta(days=1)).isoformat() if nxt else None)
    return out


def _version_meta(key: str, df: pd.DataFrame) -> dict:
    """{version_date: {file_sha256, file_name, sheet}} of a normalised frame. Two files for one version is refused:
    nothing can tell which one judges the claims (00b never loads a second file for a loaded version)."""
    out = {}
    for (vd, sha), g in df.groupby(["version_date", "file_sha256"], sort=True, dropna=False):
        if vd in out:
            raise ValueError(f"{key}: version {vd} is held by two different files ({out[vd]['file_sha256'][:12]} and "
                             f"{str(sha)[:12]}) - remove one from {config.AHCCCS_TABLES[key]['table']}")
        out[vd] = {"file_sha256": sha, "file_name": g["file_name"].iloc[0], "sheet": g["sheet"].iloc[0]}
    return out


# ------------------------------------------------------------------------------------------------ readings (decision 5)
READING_COLUMNS = ["table_key", "reading_id", "reading", "decided_by", "status", "reviewer", "reviewed_at"]
# 2026-10-04 (v5.2, critic F8): "KEY=VALUE; KEY2=VALUE2" - the config values the reading's words describe (KEY a config
# attribute; a tuple / list value written comma-joined; a value never holds ';'). Optional: a reading without binds
# depends on no config value.
READING_OPTIONAL_COLUMNS = ["binds"]
READING_STATUSES = ("proposed", "signed", "rejected")
_BIND_KEY_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")


def readings_path() -> str:
    return getattr(config, "AHCCCS_TABLE_READINGS", None) or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "reference", "ahcccs_table_readings.csv")


def readings_sha256(path: str | None = None) -> str:
    """sha256 of the readings file's bytes (default readings_path()) - the build log records which signatures it ran
    on. 2026-10-04 (v5.2, critic F8)."""
    return sha256_file(path or readings_path())


def parse_binds(text) -> dict:
    """A reading's binds cell -> {KEY: VALUE} (insertion order). '' -> {}. Raises ValueError on an entry that is not
    KEY=VALUE, a KEY that is not a config attribute name, or a KEY named twice. 2026-10-04 (v5.2, critic F8)."""
    out: dict = {}
    for part in (_clean(text) if not _is_null(text) else "").split(";"):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            raise ValueError(f"binds entry {part!r} is not KEY=VALUE")
        k, v = (x.strip() for x in part.split("=", 1))
        if not _BIND_KEY_RE.match(k):
            raise ValueError(f"binds key {k!r} is not a config attribute name (upper case, e.g. AHCCCS_B2_PROVIDER_ROLE)")
        if k in out:
            raise ValueError(f"binds names {k} twice")
        out[k] = v
    return out


def config_value_text(value) -> str:
    """A config value as a binds VALUE is written: a tuple / list comma-joined, anything else as text."""
    if isinstance(value, (list, tuple)):
        return ",".join(str(x).strip() for x in value)
    return str(value).strip()


def _bound_value_holds(signed: str, current) -> bool:
    if isinstance(current, (list, tuple)):                       # element by element: '01, B9' is ('01', 'B9')
        want = [x.strip() for x in signed.split(",")] if signed.strip() else []
        return want == [str(x).strip() for x in current]
    return signed.strip() == str(current).strip()


def binding_mismatches(table_key: str, rows: list | None = None) -> list[dict]:
    """[{reading_id, key, signed, current}] - every value a reading of the table binds (column binds) that config no
    longer has (current None: config has no such attribute), in file order. Empty = every bound value holds.
    2026-10-04 (v5.2, critic F8)."""
    if table_key not in TABLE_KEYS:
        raise ValueError(f"unknown table key {table_key!r} (one of {TABLE_KEYS})")
    rows = read_readings() if rows is None else rows
    out = []
    for r in rows:
        if r.get("table_key") != table_key:
            continue
        bound = parse_binds(r.get("binds"))
        for k in REQUIRED_BINDS.get((table_key, r.get("reading_id")), ()):
            if k not in bound:                    # critic re-check N1: a required bind missing = signed for nothing
                out.append({"reading_id": r.get("reading_id"), "key": k, "signed": None,
                            "current": config_value_text(getattr(config, k)) if hasattr(config, k) else None})
        for k, v in bound.items():
            if not hasattr(config, k):
                out.append({"reading_id": r.get("reading_id"), "key": k, "signed": v, "current": None})
            elif not _bound_value_holds(v, getattr(config, k)):
                out.append({"reading_id": r.get("reading_id"), "key": k, "signed": v,
                            "current": config_value_text(getattr(config, k))})
    return out


def _mismatch_words(m: dict) -> str:
    now = (f"config has no {m['key']}" if m["current"] is None else f"config.{m['key']} is {m['current']!r}")
    if m["signed"] is None:                       # critic re-check N1
        return (f"reading {m['reading_id']} does not bind {m['key']} (its binds column must say {m['key']}=<the value "
                f"signed>; {now})")
    return f"reading {m['reading_id']} binds {m['key']}={m['signed']} but {now}"


def read_readings(path: str | None = None) -> list[dict]:
    """Rows of reference/ahcccs_table_readings.csv, validated: the columns, a known table key, a reading id once per
    table, a known status, a well-formed binds cell (optional column). A malformed file raises (a governance file is
    never half-read). 2026-10-04 (v5.2, critic F16): read as utf-8-sig - Excel's 'CSV UTF-8' starts the file with a
    byte-order mark, which made the first header '\ufefftable_key' ('missing column table_key') - and header names
    stripped."""
    path = path or readings_path()
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        reader.fieldnames = [_clean(h) for h in (reader.fieldnames or [])]
        missing = [c for c in READING_COLUMNS if c not in reader.fieldnames]
        if missing:
            raise ValueError(f"{path}: missing column(s) {missing} (need {READING_COLUMNS}; optional "
                             f"{READING_OPTIONAL_COLUMNS}; got {reader.fieldnames})")
        rows = [{k: _clean(v) for k, v in r.items() if k is not None} for r in reader]
    bad, seen = [], set()
    for r in rows:
        k, rid, st = r.get("table_key"), r.get("reading_id"), r.get("status", "").lower()
        if k not in TABLE_KEYS:
            bad.append(f"unknown table_key {k!r}")
        if not rid:
            bad.append(f"blank reading_id in {r}")
        if (k, rid) in seen:
            bad.append(f"{k}/{rid} listed twice")
        seen.add((k, rid))
        if st not in READING_STATUSES:
            bad.append(f"{k}/{rid}: status {r.get('status')!r} is not one of {READING_STATUSES}")
        r["status"] = st
        try:
            parse_binds(r.get("binds"))
        except ValueError as e:
            bad.append(f"{k}/{rid}: binds {r.get('binds')!r}: {e}")
    if bad:
        raise ValueError(f"{path}: " + "; ".join(bad[:10]))
    return rows


def is_signed(row: dict) -> bool:
    """A reading counts as signed when its status says 'signed' AND a reviewer is named (as ncci_routing.is_signed)."""
    return str(row.get("status") or "").strip().lower() == "signed" and bool(_clean(row.get("reviewer")))


def unsigned_readings(table_key: str, rows: list | None = None) -> list[str]:
    """The reading ids of a table that are not signed: a required reading missing from the CSV, or present and not
    signed (proposed / rejected / no reviewer). Extra readings the CSV adds for the table must be signed too.
    2026-10-04 (v5.2, critic F8): also a reading that binds a config value config no longer has - its signature is for
    another value (binding_mismatches says which)."""
    if table_key not in TABLE_KEYS:
        raise ValueError(f"unknown table key {table_key!r} (one of {TABLE_KEYS})")
    rows = read_readings() if rows is None else rows
    have = {r.get("reading_id"): r for r in rows if r.get("table_key") == table_key}
    need = list(REQUIRED_READINGS[table_key]) + sorted(k for k in have if k not in REQUIRED_READINGS[table_key])
    moved = {m["reading_id"] for m in binding_mismatches(table_key, rows)}
    return [k for k in need if k not in have or not is_signed(have[k]) or k in moved]


def table_compiles(table_key: str, rows: list | None = None) -> tuple[bool, str]:
    """(compiles?, why) - contract v5.2 decision 5: a table's rules compile only when EVERY reading of that table is
    signed, while config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS is on - 2026-10-04 (v5.2, critic F8) and every config
    value a reading binds still has the signed value (the reason names reading, key, signed and current value).
    Switched off: True (findings then rest on readings nobody signed - said so, with any binding that no longer
    holds)."""
    if table_key not in TABLE_KEYS:
        raise ValueError(f"unknown table key {table_key!r} (one of {TABLE_KEYS})")
    if not getattr(config, "AHCCCS_TABLES_REQUIRE_SIGNED_READINGS", True):
        try:
            moved = binding_mismatches(table_key, rows)
        except (OSError, ValueError):                           # the note is informative only; the switch is off
            moved = []
        return True, (f"{table_key}: config.AHCCCS_TABLES_REQUIRE_SIGNED_READINGS is off - compiles whatever the "
                      f"readings' status (findings rest on readings nobody signed)"
                      + "".join(f"; {_mismatch_words(m)}" for m in moved))
    if rows is None:
        try:
            rows = read_readings()
        except FileNotFoundError:
            return False, f"{table_key}: no readings file {readings_path()} - nothing compiles unsigned"
    moved = binding_mismatches(table_key, rows)
    have = {r.get("reading_id"): r for r in rows if r.get("table_key") == table_key}
    not_signed = [k for k in unsigned_readings(table_key, rows) if k not in have or not is_signed(have[k])]
    n = len(set(REQUIRED_READINGS[table_key]) | set(have))
    if not_signed or moved:
        parts = ([f"{len(not_signed)} of {n} reading(s) not signed ({', '.join(not_signed)})"] if not_signed else []) \
            + [f"{_mismatch_words(m)} - signed for another value: sign it again for the current value, or set config "
               f"back" for m in moved]
        return False, (f"{table_key}: " + "; ".join(parts) + f" - its rules do not compile until a reviewer signs every "
                       f"reading in {os.path.basename(readings_path())} for the config in force")
    who = sorted({_clean(r.get("reviewer")) for r in rows if r.get("table_key") == table_key})
    bound = sum(len(parse_binds(r.get("binds"))) for r in have.values())
    return True, (f"{table_key}: all {n} reading(s) signed ({', '.join(who)})"
                  + (f"; the {bound} config value(s) they bind are as signed" if bound else ""))


# ------------------------------------------------------------------------------------------------ frames
def empty_frame(table_key: str) -> pd.DataFrame:
    return pd.DataFrame({c: pd.Series(dtype=object) for c in TABLE_COLUMNS[table_key]})


def normalise_frame(table_key: str, df: pd.DataFrame | None) -> pd.DataFrame:
    """A frame from parse_file or read back from the UC table, with the contract's columns and Python types: text
    trimmed (None when blank), version_date ISO, changed bool, counts int, codes upper case, provider types as
    ncci_routing.norm_type keys them ('2' / 2 -> '02'). A missing column is refused."""
    if df is None or not len(df):
        return empty_frame(table_key)
    miss = [c for c in TABLE_COLUMNS[table_key] if c not in df.columns]
    if miss:
        raise ValueError(f"{table_key}: the frame lacks column(s) {miss}")
    out = pd.DataFrame(index=range(len(df)))
    for c in TABLE_COLUMNS[table_key]:
        vals = df[c].tolist()
        if c in _BOOL_COLUMNS:
            conv = [False if _is_null(v) else (v.strip().lower() in ("true", "t", "1", "yes", "y"))
                    if isinstance(v, str) else bool(v) for v in vals]
        elif c in _INT_COLUMNS:
            conv = [None if _is_null(v) or _clean(v) == "" else _whole(v, f"{table_key}.{c}") for v in vals]
        elif c == "version_date":
            conv = [_iso_date(v) for v in vals]
        elif c in ("row_code", "col_code", "code"):
            conv = [None if _none_or_text(v) is None else _clean(v).upper() for v in vals]
        elif c == "provider_type":
            conv = [ncci_routing.norm_type(_none_or_text(v)) for v in vals]
        elif c in ("indicator", "freq1_cd", "freq2_cd"):
            # 2026-10-04 (independent oracle G6): a Frequency Cd is a code like the indicator - 'd' is 'D'
            conv = [None if _none_or_text(v) is None else _clean(v).upper() for v in vals]
        else:
            conv = [_none_or_text(v) for v in vals]
        out[c] = pd.Series(conv, dtype=object)
    if table_key == "same_day_disallow":
        bad = sorted({v for v in out["indicator"] if v not in INDICATORS}, key=str)
        if bad:
            raise ValueError(f"same_day_disallow: indicator(s) {bad} are not D, A or A*")
    if table_key == "daily_limits" and any(v is None or v <= 0 for v in out["daily_max"]):
        raise ValueError("daily_limits: a daily_max is blank or not positive")
    # 2026-10-04 (independent oracle G1 / G3 / G7): parse_file refuses these in a file; a frame read back from the
    # catalog is checked again, because a row added or edited there by hand would otherwise build a rule for a code
    # named 'None', drop a row silently, or build two rules for one cell / code (two findings, dollars counted twice)
    keys = {"same_day_disallow": ["row_code", "col_code"], "daily_limits": ["code"], "b2_matrix": ["code"]}[table_key]
    blank = out[out[keys].isna().any(axis=1)]
    if len(blank):
        raise ValueError(f"{table_key}: {len(blank)} row(s) without {' / '.join(keys)} (first: "
                         f"{blank.iloc[0].to_dict()}) - every row needs its code(s)")
    if table_key != "b2_matrix":                  # B2: one row per (code, provider type); a repeat changes nothing
        # per file: two FILES for one version are refused by _version_meta with their own message
        dup = out[out.duplicated(["version_date", "file_sha256"] + keys, keep=False)]
        if len(dup):
            first = dup.iloc[0]
            raise ValueError(f"{table_key}: version {first['version_date']} holds "
                             f"{' x '.join(str(first[k]) for k in keys)} more than once ({len(dup)} rows) - one "
                             f"{'cell' if len(keys) == 2 else 'row'} per version; remove the extra row(s) from "
                             f"{config.AHCCCS_TABLES[table_key]['table']}")
    return out


def frames_for_build(spark) -> tuple[dict, list[str]]:
    """({table_key: normalised frame}, notes) from the three UC tables (config.AHCCCS_TABLES[key]['table']). A table
    that does not exist gives an empty frame and a note; one that exists but cannot be read RAISES (kb_io.table_or_none:
    a 403 is never 'no rows')."""
    import kb_io
    frames, notes = {}, []
    for key in TABLE_KEYS:
        fqn = config.AHCCCS_TABLES[key]["table"]
        df = kb_io.table_or_none(spark, fqn)
        if df is None:
            frames[key] = empty_frame(key)
            notes.append(f"{key}: {fqn} does not exist - no {key} rules in this build (run 00b_load_ahcccs_tables)")
            continue
        frames[key] = normalise_frame(key, df)
        if not len(frames[key]):
            notes.append(f"{key}: {fqn} is empty - no {key} rules in this build")
    return frames, notes


# ------------------------------------------------------------------------------------------------ rules
_PAIR_FIELDS = ["proc_cd", "member_id", "provider_id", "srvc_bgn_dt", "mod_1", "mod_2", "mod_3", "mod_4"]
_DAILY_FIELDS = ["proc_cd", "units", "member_id", "provider_id", "srvc_bgn_dt"]
# 2026-10-04 (v5.2, critic F1): the provider type column(s) each role reads (billing_type = BProv_Type, prov_type =
# SProv_Type) - billing_or_rendering reads both
_PTYPE_FIELDS = {"billing": ["proc_cd", "billing_type"], "servicing": ["proc_cd", "prov_type"],
                 "billing_or_rendering": ["proc_cd", "billing_type", "prov_type"]}
# whose provider type each role judges, in plain words ({groups}: the group billing types, e.g. '01')
B2_ROLE_WORDS = {
    "billing": "the billing provider's type",
    "servicing": "the servicing (rendering) provider's type",
    "billing_or_rendering": ("the billing provider's type - for a group (billing provider type {groups}) the rendering "
                             "provider's type"),
}


def _role_words(role: str) -> str:
    groups = " or ".join(group_billing_types()) or "none configured"
    return B2_ROLE_WORDS.get(role, f"the {role} provider's type").format(groups=groups)
# plain-English statements, one per reading (the words a reviewer signs in reference/ahcccs_table_readings.csv)
_PAIR_WORDS = {
    "D": ("{b} and {a} may not both be billed for the same member on the same date of service, {who}; the {b} line is "
          "the finding{both} (AHCCCS Same Day Disallow Table, version {vd}: D = Disallowed)."),
    "A*": ("{b} and {a} may not both be billed for the same member on the same date of service {who}{other}; the {b} "
           "line is the finding{both} (AHCCCS Same Day Disallow Table, version {vd}: A* = allowable on the same day for "
           "the member, not by the same provider)."),
}
# 2026-10-04 (v5.2, critic F4): a pair the version marks D / A* in BOTH directions (predicate both_ways)
_BOTH_WAYS_WORDS = (", and since the table disallows the pair both ways the {a} line is also the finding of the reverse "
                    "rule - AHCCCS would deny one of the two lines")
# 2026-10-04 (v5.2, critic F5): every scope in plain words - whose lines a pair compares, whose units a daily limit adds -
# and how "same provider" is read (the sentence each rule's notes carry)
PAIR_SCOPE_WORDS = {
    "member_day": "by any provider",
    "member_provider_day": "by the same provider - the same servicing provider id",
    "member_servicing_billing_day": "by the same provider - the same servicing and billing provider ids",
}
DAILY_SCOPE_WORDS = {
    "member_day": "per member per date of service (all providers together)",
    "member_provider_day": "per member, per provider (the same servicing provider id), per date of service",
    "member_servicing_billing_day": ("per member, per provider (the same servicing and billing provider ids), per date "
                                     "of service"),
}
_SCOPE_READING = {
    "member_day": "Lines of any providers count together.",
    "member_provider_day": ("'Same provider' is read as the same servicing provider id (SProv_ID); a line with no "
                            "servicing provider id is never {verb}."),
    "member_servicing_billing_day": (
        "'Same provider' is read as the same servicing provider id (SProv_ID) AND the same billing provider id "
        "(BProv_ID): the legend glosses it as '(service site or residential placement)' and AHCCCS has not said whether "
        "it means the clinician or the site, so a finding breaks the rule under either reading (a clinician billing "
        "through two agencies, or two clinicians of one site, are not compared); a line missing either id is never "
        "{verb}."),
}
# 2026-10-04 (v5.2, critic F5): how many line pairs each scope compares, widest first - table_conflicts tells a rule
# wider than the table's reading (it flags lines the table allows) from a narrower one (it misses what the table forbids)
_SCOPE_WIDTH = {"member_day": 0, "member_provider_day": 1, "member_servicing_billing_day": 2}


def _scope_fields(fields: list, scope: str) -> list:
    """The claim fields a rule needs: the billing provider id too when its scope compares it (the gate downgrades a
    rule whose field the extract lacks to a lead, never a query that finds nothing)."""
    return list(fields) + (["billing_provider_id"] if scope == "member_servicing_billing_day" else [])


def _meta(key: str) -> dict:
    return config.AHCCCS_TABLES[key]


def _source_doc(key: str, version_date: str) -> str:
    return f"{_meta(key)['title']} (version {version_date})"


def _rule(key: str, version_date: str, v: dict, windows: dict, **kw) -> Rule:
    eff, end = windows[version_date]
    return Rule(origin=ORIGIN, plane="coding_edit", binding_status="state_policy", population="all",
                machine_checkable=True, source_doc=_source_doc(key, version_date), source_url=_meta(key)["url"],
                doc_version=version_date, doc_hash=v["file_sha256"], effective_date=eff, end_date=end, **kw).assign_id()


def _same_day_rules(df, versions, windows, scope, rep) -> list[Rule]:
    out = []
    counts = {k: 0 for k in INDICATORS}
    diag = allowed = scoped = 0
    # 2026-10-04 (v5.2, critic F4): every cell by (version, row, column) - a rule's reverse cell says "both ways"
    cells = {(x.version_date, x.row_code, x.col_code): (x.indicator, x.cell) for x in df.itertuples(index=False)}
    for r in df.itertuples(index=False):
        counts[r.indicator] += 1
        if SKIP_DIAGONAL and r.row_code == r.col_code:          # decision 1: not a pair rule
            diag += 1
            continue
        if r.indicator not in PAIR_INDICATORS:                   # decision 1: A = allowed, no rule
            allowed += 1
            continue
        if scope is not None and not (r.row_code in scope and r.col_code in scope):
            scoped += 1
            continue
        # 2026-10-04 (v5.2, critic F5): A* takes config.AHCCCS_SAME_PROVIDER_SCOPE (validated), D stays member_day
        pscope = indicator_scope(r.indicator)
        # decision 1: the row code's line is the finding (code_b), the column code's line its evidence (code_a)
        a, b = (r.col_code, r.row_code) if PAIR_FINDING_CODE == "row" else (r.row_code, r.col_code)
        v = versions[r.version_date]
        # 2026-10-04 (v5.2, critic F4): the reverse cell (column code x row code) is D / A* too - both lines are
        # findings, each of its own rule, although AHCCCS would deny one of them: both rules carry both_ways
        rev = cells.get((r.version_date, r.col_code, r.row_code))
        both = rev is not None and rev[0] in PAIR_INDICATORS
        out.append(_rule(
            "same_day_disallow", r.version_date, v, windows,
            statement=_PAIR_WORDS[r.indicator].format(
                a=a, b=b, vd=r.version_date, who=PAIR_SCOPE_WORDS[pscope],
                other=f" (another provider may bill {b})" if pscope != "member_day" else "",
                both=_BOTH_WAYS_WORDS.format(a=a) if both else ""),
            predicate={"type": "code_pair_prohibited", "code_a": a, "code_b": b,
                       "modifier_indicator": PAIR_MODIFIER_INDICATOR, "scope": pscope, "exception": NOTE2,
                       "service_category": PAIR_SERVICE_CATEGORY, **({"both_ways": True} if both else {})},
            codes=[a, b], required_claim_fields=_scope_fields(_PAIR_FIELDS, pscope),
            source_locator=f"sheet '{v['sheet']}' cell {r.cell} (row {r.row_code} x column {r.col_code})",
            notes=(f"Cell {r.cell} reads '{r.indicator}'"
                   + (" - in red: changed in this version (the table's footnote: 'Changed indicators are noted in "
                      "red')" if r.changed else "")
                   + f". Row {r.row_code}: {r.row_description or '?'} ({r.row_unit or '?'}); column {r.col_code}: "
                     f"{r.col_unit or '?'}. The finding sits on the {b} line (the row code); the {a} line is its "
                     f"evidence. "
                   + _SCOPE_READING[pscope].format(verb="paired")
                   + f" Table note 2: '{NOTE2} ...' - a finding is verify_exception (verify_pa with a PA on file), "
                     f"never a plain violation (SB 2026-10-04)."
                   + (f" The table marks the pair both ways (cell {r.cell} '{r.indicator}', reverse cell {rev[1]} "
                      f"'{rev[0]}'): both lines are findings, each of its own rule (both_ways); AHCCCS would deny one "
                      f"of the two lines, so the two findings' dollars are not additive - count the pair once."
                      if both else ""))))
    rep.update({"cells": int(len(df)), "indicators": counts, "diagonal_skipped": diag, "allowed_no_rule": allowed,
                "rules": len(out), "scoped_out": scoped,
                # pairs whose both lines are findings (reading flagged_line: each rule carries both_ways, and the two
                # findings' dollars are not additive - AHCCCS would deny one of the two lines)
                "pairs_both_ways": sum(len(v) for v in pairs_both_ways(df).values()),
                "rules_both_ways": sum(1 for x in out if x.predicate.get("both_ways")),
                "recorded_not_compiled": {"A_cells": allowed, "diagonal_cells": diag}})
    return out


def _daily_rules(df, versions, windows, scope, rep) -> list[Rule]:
    out = []
    scoped = periods = 0
    excluded: dict = {k: [] for k in DAILY_EXCLUSIONS}
    dscope = daily_limit_scope()                                 # decision 3
    for r in df.itertuples(index=False):
        if r.limit1 is not None or r.limit2 is not None:
            periods += 1                                         # decision 3: recorded, not compiled
        # decision 3 + follow-ups: anesthesia time units, an all-nines placeholder (2026-10-04, v5.2, critic F2), two
        # daily limits stated - recorded, no rule; a row counts in the first exclusion that applies
        why = daily_exclusion(r)
        if why is not None:
            excluded[why].append(r.code)
            continue
        if scope is not None and r.code not in scope:
            scoped += 1
            continue
        v = versions[r.version_date]
        n = int(r.daily_max)
        rec = "; ".join(f"Limit {i}: {lim} per {val} {cd}" for i, lim, val, cd in
                        (("1", r.limit1, r.freq1_value, r.freq1_cd), ("2", r.limit2, r.freq2_value, r.freq2_cd))
                        if lim is not None)
        out.append(_rule(
            "daily_limits", r.version_date, v, windows,
            statement=(f"{r.code}: at most {n} unit(s) {DAILY_SCOPE_WORDS[dscope]} (AHCCCS HCPCS/CPT Procedures with "
                       f"Daily Limits, version {r.version_date}: Procedure Maximum Occurrence {n})."),
            predicate={"type": "max_units_per_day", "code": r.code, "threshold": n, "scope": dscope},
            codes=[r.code], required_claim_fields=_scope_fields(_DAILY_FIELDS, dscope),
            source_locator=f"sheet '{v['sheet']}' row {r.source_row} ({r.code})",
            notes=(f"Row {r.source_row}: {r.description or '?'}. 'Procedure Maximum Occurrence' read as the most UNITS "
                   f"{DAILY_SCOPE_WORDS[dscope]} (SB 2026-10-04; AHCCCS counts the daily limit in units). "
                   + _SCOPE_READING[dscope].format(verb="counted")
                   + (f" Period limits recorded, NOT compiled (period semantics undecided): {rec}." if rec else ""))))
    two = excluded["two_daily_limits"]
    rep.update({"rows": int(len(df)), "rules": len(out), "scoped_out": scoped,
                "two_daily_limits": {"count": len(two), "codes": sorted(set(two))},
                "recorded_not_compiled": {"period_limit_rows": periods,
                                          **{k: len(excluded[k]) for k in DAILY_EXCLUSIONS}}})
    return out


def _b2_statement(code: str, types: list, blank: bool, vd: str, role: str) -> str:
    """Decision 4 in plain words, per provider role (2026-10-04, v5.2, critic F1: the role is config's)."""
    listed = (", ".join(types) or "(none listed)") + (" and a type the matrix leaves blank" if blank else "")
    cite = f" (AHCCCS B2 Matrix, version {vd}: the provider types the matrix lists for {code})."
    if role == "servicing":
        return f"{code} may be rendered only by servicing provider types {listed}{cite}"
    if role == "billing_or_rendering":
        groups = " or ".join(group_billing_types()) or "none configured"
        return (f"{code} may be billed only by provider types {listed}; a line billed by a group (billing provider type "
                f"{groups}) is judged on its rendering (servicing) provider's type{cite}")
    return f"{code} may be billed only by billing provider types {listed}{cite}"


def _b2_rules(df, versions, windows, scope, rep) -> list[Rule]:
    out = []
    scoped = 0
    recorded_codes = set()
    role = b2_provider_role()                                    # decision 4 (2026-10-04, v5.2, critic F1)
    for (vd, code), g in df.groupby(["version_date", "code"], sort=True):
        if not b2_compiles(code):                                # decision 4: recorded only
            recorded_codes.add((vd, code))
            continue
        if scope is not None and code not in scope:
            scoped += 1
            continue
        v = versions[vd]
        types = sorted({t for t in g["provider_type"] if t})
        # a matrix row of the code with NO provider type (parse_file refuses one; a frame edited in the catalog could
        # hold one) leaves the complete list unknown: a blank entry keeps the rule a lead - QUERY_SEMANTICS §2 (v2.3)
        # "an entry that is missing after clean-up ... makes the rule a lead (never a guess)"
        blank = any(not t for t in g["provider_type"])
        desc = {t: d for t, d in zip(g["provider_type"], g["provider_type_description"])}
        rows = sorted(int(x) for x in g["source_row"] if x is not None)
        out.append(_rule(
            "b2_matrix", vd, v, windows,
            statement=_b2_statement(code, types, blank, vd, role),
            predicate={"type": "provider_type_allowed", "code_set": [code],
                       "provider_types": types + ([""] if blank else []), "provider_role": role},
            codes=[code], required_claim_fields=list(_PTYPE_FIELDS[role]),
            source_locator=(f"sheet '{v['sheet']}' procedure code {code}, rows "
                            f"{rows[0]}-{rows[-1]}" if rows else f"sheet '{v['sheet']}' procedure code {code}"),
            notes=(f"The B2 Matrix lists {len(types)} provider type(s) for {code}: "
                   + "; ".join(f"{t} {desc.get(t) or ''}".strip() for t in types)
                   + ". Read as the COMPLETE list of provider types allowed for this behavioral-health-only code (SB "
                     f"2026-10-04), judged on {_role_words(role)}"
                   + (" (the matrix names no group billing type; proposed after independent review 2026-10-04)"
                      if role == "billing_or_rendering" else "")
                   + "; a line whose judged provider type is missing is never a finding. Places of service and "
                     "modifiers are recorded in the table, not compiled.")))
    rep.update({"rows": int(len(df)), "codes": int(df["code"].nunique()) if len(df) else 0, "rules": len(out),
                "scoped_out": scoped,
                "recorded_not_compiled": {"codes": len({c for _, c in recorded_codes}),
                                          "rows": sum(1 for c in df["code"] if not b2_compiles(c))}})
    return out


_BUILDERS = {"same_day_disallow": _same_day_rules, "daily_limits": _daily_rules, "b2_matrix": _b2_rules}


def rules_from_frames(frames: dict, scope_codes: set | None = None, report: dict | None = None) -> list[Rule]:
    """Rules (origin 'ahcccs_table', plane coding_edit, binding state_policy) from the normalised long tables, every
    one dated by its version's window (version_windows) and citing file, sheet and cell / row. Contract v5.2 decisions
    1, 3, 4 shape them (the readings block at the top). scope_codes (the claims scope, like NCCI): a pair needs BOTH
    codes in it, a daily limit / provider rule its code. report[table_key] gets the counts (versions, cells / rows,
    rules, scoped out, recorded-not-compiled). Does NOT apply the readings gate: the caller asks table_compiles()."""
    report = report if report is not None else {}
    scope = None if scope_codes is None else {schema.norm_code(c) for c in scope_codes}
    out: list[Rule] = []
    for key in TABLE_KEYS:
        df = normalise_frame(key, (frames or {}).get(key))
        rep = report.setdefault(key, {})
        versions = _version_meta(key, df) if len(df) else {}
        windows = version_windows(versions)
        rep.update({"versions": sorted(versions), "windows": {k: list(w) for k, w in windows.items()}})
        if not len(df):
            rep.update({"rules": 0, "scoped_out": 0})
            continue
        out += _BUILDERS[key](df, versions, windows, scope, rep)
    return out


def two_daily_limits(df) -> list[dict]:
    """Decision 3 follow-up: every Daily Limits row whose file states two daily limits - one dict per differing 'N per
    1 day' limit: {version_date, code, daily_max, limit_no, limit, source_row}, in version and sheet-row order. No
    daily rule is built for these codes; table_conflicts lists them (file_states_two_daily_limits)."""
    out = [{"version_date": r.version_date, "code": r.code, "daily_max": int(r.daily_max), "limit_no": n,
            "limit": lim, "source_row": r.source_row}
           for r in normalise_frame("daily_limits", df).itertuples(index=False) for n, lim in day_limits_differing(r)]
    return sorted(out, key=lambda x: (x["version_date"], x["source_row"] or 0, x["limit_no"]))


def daily_not_compiled(df) -> list[dict]:
    """Decision 3: every Daily Limits row that builds no rule, under the FIRST exclusion that applies
    (daily_exclusion): {version_date, code, daily_max, source_row, exclusion, limit_no, limit} - one dict per row, and
    for 'two_daily_limits' one per differing 'N per 1 day' limit (as two_daily_limits()). Version and sheet-row order.
    2026-10-04 (v5.2, critic F2)."""
    out = []
    for r in normalise_frame("daily_limits", df).itertuples(index=False):
        why = daily_exclusion(r)
        base = {"version_date": r.version_date, "code": r.code, "daily_max": int(r.daily_max),
                "source_row": r.source_row, "exclusion": why, "limit_no": None, "limit": None}
        if why == "two_daily_limits":
            out += [dict(base, limit_no=n, limit=lim) for n, lim in day_limits_differing(r)]
        elif why is not None:
            out.append(base)
    return sorted(out, key=lambda x: (x["version_date"], x["source_row"] or 0, x["limit_no"] or ""))


def pairs_both_ways(df) -> dict:
    """{version_date: [(code, code), ...]}: the code pairs a Same Day Disallow version marks D / A* in BOTH directions
    (row x column and column x row), each pair once, sorted. Both lines of such a pair are findings - each is the row
    code of one cell (decision 1) - although AHCCCS would deny one of them: since 2026-10-04 (v5.2, critic F4) both
    rules carry predicate both_ways = True and say so, and the two findings' dollars are not additive (reading
    flagged_line)."""
    f = normalise_frame("same_day_disallow", df)
    out = {}
    for vd, g in f.groupby("version_date", sort=True):
        rule = {(a, b) for a, b, i in zip(g["row_code"], g["col_code"], g["indicator"])
                if i in PAIR_INDICATORS and a != b}
        out[vd] = sorted({tuple(sorted(p)) for p in rule if (p[1], p[0]) in rule})
    return out


# ------------------------------------------------------------------------------------------------ conflicts
CONFLICT_COLUMNS =["table_key", "version_date", "codes", "table_reading", "rule_id", "rule_origin", "rule_reading",
                    "relationship", "detail"]


def _rule_dict(r) -> dict:
    d = r.to_dict() if hasattr(r, "to_dict") else dict(r)
    p = d.get("predicate")
    if isinstance(p, str):
        try:
            p = json.loads(p) if p.strip() else {}
        except ValueError:
            p = {}
    d["predicate"] = p if isinstance(p, dict) else {}
    return d


def _overlaps(r: dict, window: tuple) -> bool:
    lo, hi = window
    eff = None if _is_null(r.get("effective_date")) or not _clean(r.get("effective_date")) else _iso_date(r["effective_date"])
    end = None if _is_null(r.get("end_date")) or not _clean(r.get("end_date")) else _iso_date(r["end_date"])
    return (hi is None or eff is None or eff <= hi) and (end is None or lo <= end)


def _rule_pair_scope(p: dict) -> str:
    s = p.get("scope")
    return s if s in schema.PAIR_SCOPES else "member_provider_day"   # detector_gen.pair_scope: no scope = narrow


def table_conflicts(frames: dict, state_rules: list) -> pd.DataFrame:
    """Extracted / hand-authored rules the AHCCCS tables contradict or qualify (CONFLICT_COLUMNS), per table version
    whose window overlaps the rule's own window:
      table_allows            a code pair the rule prohibits and the Same Day table marks A (allowed)
      pair_scope_differs      the rule's pair scope differs from the table's D (any provider) / A* (same provider)
      provider_types_differ   a provider-type rule's list differs from the B2 Matrix for a compiled (H0xxx / H2xxx) code
      provider_role_differs   the same list, judged on another provider's type than the table reading
                              (config.AHCCCS_B2_PROVIDER_ROLE) - 2026-10-04 (v5.2, critic F1)
      daily_threshold_differs a daily unit cap differs from the table's Procedure Maximum Occurrence
    and, whatever the rules, the table against ITSELF (rule_id / rule_origin empty) - every Daily Limits row that
    builds no rule, under the first exclusion that applies (daily_not_compiled):
      not_compiled_anesthesia_time_units  an anesthesia code (config.AHCCCS_DAILY_RECORD_ONLY_CODES): billed in time
                                          units, its maximum cannot count them (2026-10-04, v5.2, critic F2)
      not_compiled_placeholder_maximum    an all-nines maximum (config.AHCCCS_DAILY_PLACEHOLDER_MAX): a placeholder
      file_states_two_daily_limits  a Daily Limits row whose own 'N per 1 day' limit differs from its Procedure Maximum
                                    Occurrence - no daily rule is built for it (decision 3 follow-up)
    NCCI and table rules are not compared; rejected / superseded rows are skipped. A candidate list for a person: it
    never decides which source wins."""
    fr = {k: normalise_frame(k, (frames or {}).get(k)) for k in TABLE_KEYS}
    win = {k: version_windows(fr[k]["version_date"].unique()) if len(fr[k]) else {} for k in TABLE_KEYS}
    sd = {(r.version_date, r.row_code, r.col_code): r for r in fr["same_day_disallow"].itertuples(index=False)}
    dl = {(r.version_date, r.code): r for r in fr["daily_limits"].itertuples(index=False)}
    b2: dict = {}
    for r in fr["b2_matrix"].itertuples(index=False):
        b2.setdefault((r.version_date, r.code), set()).add(r.provider_type)
    rows = []
    # 2026-10-04 (v5.2, critic F2): every Daily Limits row that builds no rule, under the first exclusion that applies
    for t in daily_not_compiled(fr["daily_limits"]):
        base = {"table_key": "daily_limits", "version_date": t["version_date"], "codes": t["code"],
                "table_reading": f"Procedure Maximum Occurrence {t['daily_max']} unit(s), row {t['source_row']}",
                "rule_id": None, "rule_origin": None}
        if t["exclusion"] == "two_daily_limits":
            rows.append(dict(base, rule_reading=f"Limit {t['limit_no']} = {t['limit']} per 1 day (the same row)",
                             relationship="file_states_two_daily_limits",
                             detail=(f"AHCCCS's file states two daily limits for {t['code']}: Procedure Maximum "
                                     f"Occurrence {t['daily_max']} and Limit {t['limit_no']} = {t['limit']} per 1 day "
                                     f"(Frequency Cd D, Frequency Value 1) - which one AHCCCS's edit applies is unknown, "
                                     f"so no daily rule is built")))
        elif t["exclusion"] == "anesthesia_time_units":
            rows.append(dict(base, rule_reading="an anesthesia code (config.AHCCCS_DAILY_RECORD_ONLY_CODES): recorded",
                             relationship="not_compiled_anesthesia_time_units",
                             detail=(f"{t['code']} is an anesthesia code: AHCCCS bills anesthesia in 15-minute time "
                                     f"units, so a maximum of {t['daily_max']} cannot be a count of its units (what it "
                                     f"counts is unknown) - no daily rule is built; the row is recorded")))
        else:
            rows.append(dict(base, rule_reading="an all-nines maximum (config.AHCCCS_DAILY_PLACEHOLDER_MAX): recorded",
                             relationship="not_compiled_placeholder_maximum",
                             detail=(f"the maximum {t['daily_max']} of {t['code']} is all nines - a placeholder for no "
                                     f"practical limit, not a limit to enforce - no daily rule is built; the row is "
                                     f"recorded")))
    for raw in state_rules or []:
        d = _rule_dict(raw)
        if d.get("origin") in ("ncci", ORIGIN) or str(d.get("review_status") or "") in ("rejected", "superseded"):
            continue
        p, rid, org = d["predicate"], d.get("rule_id"), d.get("origin")
        t = p.get("type")
        if t == "code_pair_prohibited" and p.get("code_a") and p.get("code_b"):
            a, b = schema.norm_code(p["code_a"]), schema.norm_code(p["code_b"])
            rs = _rule_pair_scope(p)
            for vd, w in win["same_day_disallow"].items():
                if not _overlaps(d, w):
                    continue
                cell = sd.get((vd, b, a)) or sd.get((vd, a, b))       # the rule's direction first
                if cell is None:
                    continue
                same_dir = (cell.row_code, cell.col_code) == (b, a)
                where = (f"cell {cell.cell} (row {cell.row_code} x column {cell.col_code})"
                         + ("" if same_dir else "; the table's finding line is the other code"))
                base = {"table_key": "same_day_disallow", "version_date": vd, "codes": f"{a}/{b}", "rule_id": rid,
                        "rule_origin": org, "rule_reading": f"code_pair_prohibited {a} -> {b} ({rs})",
                        "table_reading": f"{cell.indicator} at {where}"}
                if cell.indicator == "A":
                    rows.append(dict(base, relationship="table_allows",
                                     detail=(f"the Same Day Disallow Table marks {cell.row_code} x {cell.col_code} A "
                                             f"(allowable on the same day) - the rule prohibits the pair")))
                elif indicator_scope(cell.indicator) != rs:
                    # 2026-10-04 (v5.2, critic F5): three scopes - wider / narrower by how many line pairs each compares
                    ts = indicator_scope(cell.indicator)
                    rows.append(dict(base, relationship="pair_scope_differs",
                                     detail=(f"the table's {cell.indicator} reads {ts} ({PAIR_SCOPE_WORDS[ts]}); the "
                                             f"rule reads {rs} ({PAIR_SCOPE_WORDS[rs]}) - "
                                             + ("the rule is narrower: a pair split across two providers is missed"
                                                if _SCOPE_WIDTH[rs] > _SCOPE_WIDTH[ts] else
                                                "the rule is wider: it flags two providers the table allows"))))
        elif t == "provider_type_allowed":
            codes = [schema.norm_code(c) for c in ([p.get("code")] if p.get("code") else []) + list(p.get("code_set") or [])]
            mine = sorted({ncci_routing.norm_type(x) for x in (p.get("provider_types") or [])} - {None})
            role = str(p.get("provider_role") or "billing").strip().lower()
            trole = b2_provider_role()                  # 2026-10-04 (v5.2, critic F1): the table reading's role
            for code in codes:
                if not b2_compiles(code):
                    continue
                for vd, w in win["b2_matrix"].items():
                    theirs = b2.get((vd, code))
                    if theirs is None or not _overlaps(d, w):
                        continue
                    same_list, same_role = set(mine) == theirs, role == trole
                    if same_list and same_role:
                        continue
                    listed = sorted(t for t in theirs if t) + (["(blank)"] if None in theirs else [])
                    only_r = sorted(set(mine) - theirs)
                    only_t = sorted(t for t in theirs - set(mine) if t) + (["(blank)"] if None in theirs else [])
                    # 2026-10-04 (v5.2, critic F1): the same list judged on another provider's type is its own
                    # relationship - e.g. a rule on the billing type flags a group's line the table reading does not
                    roles = "" if same_role else (f"the rule judges {_role_words(role)}, the table reading judges "
                                                  f"{_role_words(trole)}")
                    rows.append({"table_key": "b2_matrix", "version_date": vd, "codes": code,
                                 "table_reading": f"{trole} provider types {', '.join(listed)}",
                                 "rule_id": rid, "rule_origin": org,
                                 "rule_reading": f"provider_type_allowed {role} {', '.join(mine)}",
                                 "relationship": "provider_role_differs" if same_list else "provider_types_differ",
                                 "detail": (f"the provider types agree; {roles}" if same_list else "; ".join(x for x in (
                                     f"only in the rule: {', '.join(only_r)}" if only_r else "",
                                     f"only in the B2 Matrix: {', '.join(only_t)}" if only_t else "", roles) if x))})
        elif t in ("max_units_per_day", "max_units_per_dos"):
            codes = [schema.norm_code(c) for c in ([p.get("code")] if p.get("code") else []) + list(p.get("code_set") or [])]
            n = schema.integral(p.get("threshold"))
            rs = p.get("scope") if p.get("scope") in schema.PAIR_SCOPES else (
                "member_provider_day" if t == "max_units_per_dos" else "member_day")
            for code in codes:
                for vd, w in win["daily_limits"].items():
                    lim = dl.get((vd, code))
                    if lim is None or not _overlaps(d, w) or n is None or int(lim.daily_max) == n:
                        continue
                    combined = f" (a combined cap over {'/'.join(codes)})" if len(codes) > 1 else ""
                    rows.append({"table_key": "daily_limits", "version_date": vd, "codes": code,
                                 "table_reading": f"Procedure Maximum Occurrence {lim.daily_max} unit(s) "
                                                  f"({daily_limit_scope()}), row {lim.source_row}",
                                 "rule_id": rid, "rule_origin": org,
                                 "rule_reading": f"{t} {n} unit(s) ({rs}){combined}",
                                 "relationship": "daily_threshold_differs",
                                 "detail": (f"the table allows {lim.daily_max} unit(s) per day, the rule {n}{combined}: "
                                            + ("the rule is stricter" if n < int(lim.daily_max) else
                                               "the rule is looser - the table would flag more")
                                            + ("" if rs == daily_limit_scope() else
                                               f"; scopes differ too (table {daily_limit_scope()}, rule {rs})"))})
    out = pd.DataFrame(rows, columns=CONFLICT_COLUMNS)
    return out.sort_values(["table_key", "version_date", "codes", "rule_id"], kind="mergesort").reset_index(drop=True)


# ------------------------------------------------------------------------------------------------ log / versions loaded
def _log_rows(log_frame) -> list[dict]:
    if log_frame is None or not len(log_frame):
        return []
    df = log_frame if isinstance(log_frame, pd.DataFrame) else pd.DataFrame(log_frame)
    return [{c: (None if _is_null(r.get(c)) else r.get(c)) for c in LOG_COLUMNS} for r in df.to_dict("records")]


def _loaded_rows(log_frame) -> dict:
    """{table_key: {(version_date, file_sha256): log row}} - for every version 00b LOADED, its LATEST 'loaded' log row
    (by loaded_at, then log order): a row logged again for the same file supersedes the earlier one. 'already_loaded'
    and 'rejected' rows are not loads. Every table key is present."""
    best: dict = {}
    for i, r in enumerate(_log_rows(log_frame)):
        k, st = r.get("table_key"), _clean(r.get("status")).lower()
        if st != "loaded" or k not in TABLE_KEYS or not r.get("version_date") or not r.get("file_sha256"):
            continue
        key = (k, _iso_date(r["version_date"]), _clean(r["file_sha256"]))
        rank = (_clean(r.get("loaded_at")), i)
        if key not in best or rank >= best[key][0]:
            best[key] = (rank, r)
    out: dict = {k: {} for k in TABLE_KEYS}
    for (k, vd, sha), (_, r) in best.items():
        out[k][(vd, sha)] = r
    return out


def loaded_versions(log_frame) -> dict:
    """{table_key: [{version_date, file_sha256, file_name, rows, rows_sha256, loaded_at, archived_path}, ...] sorted by
    version} - the versions 00b LOADED (status 'loaded' in config.AHCCCS_TABLES_LOG; one entry per (version, file), from
    its latest 'loaded' row). Every table key is present (an empty list = not loaded)."""
    out: dict = {k: [] for k in TABLE_KEYS}
    for k, vs in _loaded_rows(log_frame).items():
        for (vd, sha), r in vs.items():
            out[k].append({"version_date": vd, "file_sha256": sha, "file_name": r.get("file_name"),
                           "rows": None if r.get("rows") is None else int(r["rows"]),
                           "rows_sha256": _clean(r.get("rows_sha256")) or None, "loaded_at": r.get("loaded_at"),
                           "archived_path": r.get("archived_path")})
        out[k].sort(key=lambda x: (x["version_date"], x["file_sha256"]))
    return out


def _hash_text(v):
    """A normalised cell as the rows hash reads it: None stays None, a bool 'true' / 'false', anything else its text."""
    if v is None:
        return None
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def rows_sha256(table_key: str, frame) -> str:
    """A canonical sha256 of a table version's rows - 2026-10-04 (v5.2, critic F7). The frame is normalised first
    (normalise_frame: the catalog round trip - a long read back as 4.0, text 'true', ' h0001 ' - changes nothing), then
    the columns TABLE_COLUMNS[table_key] (never loaded_at), every value as text (None stays null), rows sorted, hashed as
    one JSON document. 00b logs it per loaded version; check_loaded recomputes it from the tables."""
    cols = TABLE_COLUMNS[table_key]
    f = normalise_frame(table_key, frame)
    rows = sorted(([_hash_text(v) for v in r] for r in f[cols].itertuples(index=False, name=None)),
                  key=lambda r: [(0, "") if x is None else (1, x) for x in r])
    doc = json.dumps({"table_key": table_key, "columns": cols, "rows": rows}, ensure_ascii=False,
                     separators=(",", ":"))
    return hashlib.sha256(doc.encode("utf-8")).hexdigest()


def check_loaded(frames: dict, log) -> list:
    """The AHCCCS tables against the log 00b wrote - 2026-10-04 (v5.2, critic F7): 07 used to trust the UC tables, so a
    row deleted or edited there changed the rules silently and a dropped table built 0 rules while the log said
    loaded. frames: {table_key: frame} as frames_for_build gives (a missing key = an empty table); log: the
    config.AHCCCS_TABLES_LOG frame (None = no log). Per table, for every version the log calls loaded (its latest
    'loaded' row per table_key + version_date + file_sha256): the table holds exactly the logged number of rows of that
    version and, when the log row has rows_sha256, rows with that hash (a log row written before rows_sha256: the count
    only); a version the table holds that the log never loaded is a problem; so is a table with no row while the log
    has loaded versions. Returns the problems in plain words - empty = OK. 07 stops on any; 01 check T fails them."""
    problems: list = []
    loaded = _loaded_rows(log)
    for key in TABLE_KEYS:
        fqn = config.AHCCCS_TABLES[key]["table"]
        want = loaded[key]
        try:
            df = normalise_frame(key, (frames or {}).get(key))
        except ValueError as e:
            problems.append(f"{key}: {fqn} cannot be read as 00b writes it: {e}")
            continue
        have = ({vs: g for vs, g in df.groupby(["version_date", "file_sha256"], sort=True, dropna=False)}
                if len(df) else {})
        if not have and want:
            problems.append(f"{key}: {fqn} holds no row, yet the log has {len(want)} loaded version(s) "
                            f"({', '.join(sorted({vd for vd, _ in want}))}) - the table was dropped or emptied outside "
                            f"00b; restore it from its Delta history (00b never reloads a logged version)")
            continue
        for (vd, sha), lr in sorted(want.items()):
            g = have.get((vd, sha))
            n = 0 if g is None else len(g)
            label = f"{key} version {vd} ({lr.get('file_name') or '?'}, sha256 {sha[:12]})"
            logged = None if lr.get("rows") is None else int(lr["rows"])
            if logged is None:
                problems.append(f"{label}: its log row gives no row count - the log was edited by hand; nothing can "
                                f"say whether {fqn} still holds the version as loaded")
            elif n != logged:
                problems.append(f"{label}: the log loaded {logged:,} row(s), {fqn} holds {n:,} - rows were deleted or "
                                f"added outside 00b; restore the table from its Delta history")
            elif _clean(lr.get("rows_sha256")):
                try:
                    got = rows_sha256(key, g)
                except ValueError as e:
                    problems.append(f"{label}: its rows in {fqn} cannot be read as 00b writes them: {e}")
                    continue
                if got != _clean(lr["rows_sha256"]):
                    problems.append(f"{label}: {fqn} holds the logged {n:,} row(s) but not the rows 00b loaded (rows "
                                    f"hash {got[:12]}, logged {_clean(lr['rows_sha256'])[:12]}) - a row was edited "
                                    f"outside 00b; restore the table from its Delta history")
        for vd, sha in sorted(set(have) - set(want), key=lambda t: (str(t[0]), str(t[1]))):
            problems.append(f"{key}: {fqn} holds {len(have[(vd, sha)]):,} row(s) of version {vd} (sha256 "
                            f"{str(sha)[:12]}) that the log never loaded - rows added outside 00b; remove them, or "
                            f"load the file with 00b_load_ahcccs_tables")
    return problems


def corpus_entries(log_or_loaded) -> dict:
    """{f"table:{key}:{version_date}": file sha256} for every loaded table version - joined to the document hashes in
    policy_docs.corpus_version, a loaded table is part of the corpus (v03). Two files for one version (never loaded by
    00b) join their hashes, sorted, so the id still changes."""
    loaded = log_or_loaded if isinstance(log_or_loaded, dict) else loaded_versions(log_or_loaded)
    out: dict = {}
    for k, vs in (loaded or {}).items():
        for v in vs:
            key = f"table:{k}:{v['version_date']}"
            out[key] = "+".join(sorted(set(filter(None, out.get(key, "").split("+"))) | {v["file_sha256"]}))
    return out


def claims_window_sql(claims: str, dos_col: str, dos_type: str, windows: dict) -> str:
    """One scan of the claims for 01: date range, lines without a usable date of service, lines BEFORE the oldest
    version (not judged by the table - decision 2) and lines in each version's window (w_<i>, versions in date order)."""
    import preflight_sql as pq
    d = pq.date_expr(dos_col, dos_type)
    vs = sorted(windows)
    cols = [f"SUM(CASE WHEN {d} < DATE '{_iso_date(vs[0])}' THEN 1 ELSE 0 END) AS before_oldest"] if vs else []
    for i, v in enumerate(vs):
        s, e = windows[v]
        cond = f"{d} >= DATE '{_iso_date(s)}'" + (f" AND {d} <= DATE '{_iso_date(e)}'" if e else "")
        cols.append(f"SUM(CASE WHEN {cond} THEN 1 ELSE 0 END) AS w_{i}")
    return (f"SELECT MIN({d}) AS lo, MAX({d}) AS hi, COUNT(*) AS n, SUM(CASE WHEN {d} IS NULL THEN 1 ELSE 0 END) "
            f"AS no_dos" + "".join(f", {c}" for c in cols) + f" FROM {claims}")


def b2_exposure_sql(claims: str, cols: dict, b2_frame) -> str | None:
    """2026-10-05 (critic F1 follow-up): what the B2 rules would flag in these claims BEFORE anyone signs them - per
    compiled code of the NEWEST B2 version (b2_compiles) and the provider type its role judges
    (config.AHCCCS_B2_PROVIDER_ROLE: billing_or_rendering = the billing type, a group's line on its servicing type), the
    paid lines and dollars, status allowed / flagged / no_type. All claim dates (the rule judges from its version's
    date: 01 says so). None when no code compiles. cols: config.CLAIM_COLS."""
    import ncci_routing
    f = normalise_frame("b2_matrix", b2_frame)
    if not len(f):
        return None
    newest = max(f["version_date"])
    g = f[(f["version_date"] == newest) & f["code"].map(b2_compiles)]
    if not len(g):
        return None
    allowed = g.groupby("code")["provider_type"].apply(lambda s_: "/".join(sorted({t for t in s_ if t})))
    vals = ", ".join(f"('{c}', '{a}')" for c, a in sorted(allowed.items()))
    role = b2_provider_role()
    bt = ncci_routing.type_sql(cols["billing_type"]) if cols.get("billing_type") else "CAST(NULL AS STRING)"
    st = ncci_routing.type_sql(cols["prov_type"]) if cols.get("prov_type") else "CAST(NULL AS STRING)"
    groups = group_billing_types()
    if role == "servicing":
        judged = st
    elif role == "billing_or_rendering" and groups:
        judged = f"CASE WHEN {bt} IN ({', '.join(repr(x) for x in groups)}) THEN {st} ELSE {bt} END"
    else:
        judged = bt
    paid = cols.get("paid_amt")
    pos = f"WHERE {paid} > 0" if paid else ""
    return f"""WITH a AS (SELECT * FROM VALUES {vals} AS a(code, allowed)),
c AS (SELECT UPPER(TRIM(CAST({cols['code']} AS STRING))) AS code, {judged} AS judged_type,
             {f'{paid}' if paid else 'CAST(NULL AS DOUBLE)'} AS paid
      FROM {claims} {pos})
SELECT c.code, c.judged_type,
       CASE WHEN c.judged_type IS NULL THEN 'no_type'
            WHEN ARRAY_CONTAINS(SPLIT(a.allowed, '/'), c.judged_type) THEN 'allowed' ELSE 'flagged' END AS status,
       a.allowed, COUNT(*) AS lines, ROUND(SUM(c.paid), 2) AS paid
FROM c JOIN a ON a.code = c.code
GROUP BY c.code, c.judged_type, a.allowed
ORDER BY status, paid DESC"""


# ------------------------------------------------------------------------------------------------ 00b: drop zone, load
def drop_zone_files(tables_dir: str, skipped: list | None = None) -> list[str]:
    """Every .xlsx under tables_dir (any name, any sub-folder) except the archive (folders starting with '_' or '.')
    and Excel lock files ('~$...'). 2026-10-04 (v5.2, critic F17): skipped (a list) receives what was NOT read, so 00b
    can say it - {path (relative, '/'-separated), kind 'folder' | 'file', why} - in walk order (a folder's files, then its
    sub-folders' content)."""
    out = []

    def rel(*parts):
        return os.path.relpath(os.path.join(*parts), tables_dir).replace(os.sep, "/")
    for root, dirs, files in os.walk(tables_dir):
        keep = []
        for d in sorted(dirs):
            if not d.startswith(("_", ".")):
                keep.append(d)
            elif skipped is not None:
                r = rel(root, d)
                skipped.append({"path": r, "kind": "folder",
                                "why": ("the archive of loaded versions" if r == ARCHIVE_DIRNAME
                                        else "its name starts with '_' or '.'") + " - nothing in it is read"})
        dirs[:] = keep
        for fn in sorted(files):
            if fn.lower().endswith(".xlsx") and not fn.startswith(("~$", ".")):
                out.append(os.path.join(root, fn))
            elif skipped is not None:
                skipped.append({"path": rel(root, fn), "kind": "file",
                                "why": ("an Excel lock file" if fn.startswith("~$") else "a hidden file"
                                        if fn.startswith(".") else "not an .xlsx workbook")})
    return out


def archive_path(tables_dir: str, table_key: str, version_date: str, sha: str) -> str:
    return os.path.join(tables_dir, ARCHIVE_DIRNAME, table_key, f"{version_date}_{sha[:12]}.xlsx")


def _archive(src: str, dest: str, sha: str) -> str:
    """Copy the original into the archive (never move it, never overwrite a different file)."""
    if os.path.exists(dest):
        if sha256_file(dest) != sha:
            raise ValueError(f"archive file {dest} exists with different content - not overwritten")
        return dest
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    shutil.copyfile(src, tmp)
    os.replace(tmp, dest)
    return dest


def table_hashes(spark, fqn: str) -> set:
    """The file sha256s whose rows a table already holds (empty when the table does not exist)."""
    try:
        if not spark.catalog.tableExists(fqn):
            return set()
    except Exception:
        pass
    import kb_io
    try:
        df = spark.table(fqn).select("file_sha256").distinct().toPandas()
    except Exception as e:
        if kb_io._is_not_found(e):
            return set()
        raise
    return {str(v) for v in df["file_sha256"] if not _is_null(v)}


def versions_without_rows(spark, loaded: dict) -> dict:
    """{table_key: [version_date, ...]} of versions the log says are LOADED whose table holds no row of that file.
    2026-10-04 (v5.2): 00b skips an already-loaded file, so a table dropped or rows deleted outside 00b would otherwise
    go unnoticed (silent loss of rules) - 00b ends red on any."""
    out = {}
    for key, vs in (loaded or {}).items():
        if not vs:
            continue
        have = table_hashes(spark, config.AHCCCS_TABLES[key]["table"])
        gone = [v["version_date"] for v in vs if v["file_sha256"] not in have]
        if gone:
            out[key] = gone
    return out


def load_files(spark, paths: list, tables_dir: str, log_frame=None, *, write_rows=None, existing_hashes=None,
               log=print, now: str | None = None) -> list[dict]:
    """00b's work, one log row per file (LOG_COLUMNS), status:
      already_loaded  the file's sha256 is already a loaded version (log) - nothing is read or written
      rejected        parse_file refused it, or another file already holds (or claims, in this run) the same table
                      version, or writing failed - NOTHING but the log row is written
      loaded          archived under <tables_dir>/_versions/<table_key>/<version_date>_<sha12>.xlsx (a copy: the
                      drop-zone file stays) and its rows appended to config.AHCCCS_TABLES[key]['table']
    write_rows(frame, table_key) and existing_hashes(table_key) -> set default to Spark (kb_io.write_table append with
    TABLE_SCHEMA; table_hashes); tests inject fakes. Never deletes anything."""
    import kb_io
    now = now or _now()
    if write_rows is None:
        def write_rows(frame, key):                                       # noqa: E306
            return kb_io.write_table(spark, frame, config.AHCCCS_TABLES[key]["table"], mode="append",
                                     schema=TABLE_SCHEMA[key])
    if existing_hashes is None:
        def existing_hashes(key):                                         # noqa: E306
            return table_hashes(spark, config.AHCCCS_TABLES[key]["table"])
    loaded = loaded_versions(log_frame)
    by_sha = {v["file_sha256"]: (k, v) for k, vs in loaded.items() for v in vs}
    by_version = {(k, v["version_date"]): v for k, vs in loaded.items() for v in vs}
    results, parsed = [], []
    for path in paths:
        name = os.path.basename(path)
        row = {"table_key": None, "file_name": name, "file_sha256": None, "version_date": None, "rows": None,
               "status": None, "detail": None, "loaded_at": now, "archived_path": None, "rows_sha256": None}
        try:
            row["file_sha256"] = sha = sha256_file(path)
        except OSError as e:
            results.append(dict(row, status="rejected", detail=f"cannot read the file: {e}"))
            continue
        if sha in by_sha:
            k, v = by_sha[sha]
            results.append(dict(row, table_key=k, version_date=v["version_date"], rows=v.get("rows"),
                                status="already_loaded", archived_path=v.get("archived_path"),
                                detail=f"this file is version {v['version_date']} of {k}, loaded {v.get('loaded_at')}"))
            continue
        try:
            got = parse_file(path)
        except ValueError as e:                                   # what the reader refuses, said in its own words
            results.append(dict(row, status="rejected", detail=str(e)[:2000]))
            continue
        except Exception as e:
            # 2026-10-04 (v5.2): an error the reader did not foresee still leaves a log row; the other files go on
            results.append(dict(row, status="rejected", detail=f"{type(e).__name__}: {str(e)[:2000]}"))
            continue
        parsed.append((row, got))
    # the same table version claimed by two different files: nothing can tell which one judges the claims
    claims: dict = {}
    for row, got in parsed:
        claims.setdefault((got["table_key"], got["version_date"]), set()).add(got["file_sha256"])
    done_sha: dict = {}
    for row, got in parsed:
        k, vd, sha = got["table_key"], got["version_date"], got["file_sha256"]
        row.update(table_key=k, version_date=vd)                  # rows: only what a loaded version holds
        if sha in done_sha:                                       # the same bytes twice in the drop zone
            results.append(dict(row, status="already_loaded", archived_path=done_sha[sha], rows=len(got["frame"]),
                                detail="the same file was loaded from another name in this run"))
            continue
        if (k, vd) in by_version:
            v = by_version[(k, vd)]
            results.append(dict(row, status="rejected", detail=(
                f"version {vd} of {k} is already loaded from another file ({v.get('file_name')}, sha256 "
                f"{v['file_sha256'][:12]}): two different files claim one version - a person must compare them; this "
                f"loader never replaces a loaded version")))
            continue
        if len(claims[(k, vd)]) > 1:
            results.append(dict(row, status="rejected", detail=(
                f"{len(claims[(k, vd)])} different files in the drop zone claim version {vd} of {k} - keep exactly "
                f"one (nothing can tell which judges the claims)")))
            continue
        try:
            dest = _archive(got["path"], archive_path(tables_dir, k, vd, sha), sha)
            if sha in existing_hashes(k):
                # an earlier run appended the rows and stopped before its log row: never append them twice
                note = "rows already in the table (an earlier run stopped before its log row) - not appended again"
            else:
                write_rows(got["frame"].assign(loaded_at=now), k)
                note = None
        except Exception as e:
            results.append(dict(row, status="rejected", detail=f"load failed: {type(e).__name__}: {str(e)[:800]}"))
            continue
        done_sha[sha] = dest
        row["rows"] = len(got["frame"])
        # 2026-10-04 (v5.2, critic F7): what check_loaded will hold the table to
        row["rows_sha256"] = rows_sha256(k, got["frame"])
        st = got["stats"]
        summary = {"same_day_disallow": lambda: f"{st['cells']} cells {st['indicators']}, {st['changed']} changed (red)",
                   "daily_limits": lambda: (f"{st['rows']} codes, {st['period_limit_rows']} with a period limit, "
                                            f"{st['per_day_limit_differs_from_max']} whose own 1-day limit differs "
                                            f"from the maximum (no rule)"
                                            + (f"; no rule either for {st['not_compiled']['anesthesia_time_units']} "
                                               f"anesthesia code(s) and {st['not_compiled']['placeholder_maximum']} "
                                               f"all-nines maximum(s)" if "not_compiled" in st else "")),
                   "b2_matrix": lambda: (f"{st['rows']} rows, {st['codes']} codes, {st['provider_types']} provider "
                                         f"types ({st['merged_ranges']} merged ranges expanded)")}[k]()
        results.append(dict(row, status="loaded", archived_path=dest,
                            detail="; ".join(x for x in (f"{st['version_text']!r} in sheet {got['sheet']!r}: {summary}",
                                                         note) if x)))
        log(f"  {k:18s} version {vd}  {len(got['frame']):>7,} rows  <- {got['file_name']}")
    for r in results:
        if r["status"] != "loaded":
            log(f"  {str(r['table_key'] or '?'):18s} {r['status']:15s} {r['file_name']}: {str(r['detail'])[:300]}")
    return results


def log_frame(results: list[dict]) -> pd.DataFrame:
    """The log rows with fixed columns (LOG_COLUMNS) and Python types, whatever this run held."""
    df = pd.DataFrame([{c: r.get(c) for c in LOG_COLUMNS} for r in results], columns=LOG_COLUMNS)
    for c in LOG_COLUMNS:
        df[c] = pd.Series([None if _is_null(v) else (int(v) if c == "rows" else str(v)) for v in df[c].tolist()],
                          dtype=object, index=df.index)
    return df


def write_log(spark, results: list[dict], fqn: str | None = None) -> int:
    """Append the log rows (types pinned: LOG_SCHEMA)."""
    import kb_io
    if not results:
        return 0
    return kb_io.write_table(spark, log_frame(results), fqn or config.AHCCCS_TABLES_LOG, mode="append",
                             schema=LOG_SCHEMA)


def download(url: str, tables_dir: str, session=None) -> dict:
    """Fetch one AHCCCS table into the drop zone (00b with DOWNLOAD = True). Never overwrites: bytes already present
    under any name are not saved again; a name taken by OTHER bytes gets the sha256 prefix appended."""
    import acquire_ncci as acq
    r = acq._get(session or acq.make_session(), url)
    data = r.content
    if not data.startswith(b"PK"):
        raise ValueError(f"{url} did not return an .xlsx workbook ({len(data):,} bytes starting {data[:60]!r}) - "
                         f"download it by hand into {tables_dir}")
    sha = hashlib.sha256(data).hexdigest()
    os.makedirs(tables_dir, exist_ok=True)
    for p in drop_zone_files(tables_dir):
        if sha256_file(p) == sha:
            return {"path": p, "sha256": sha, "status": "already_in_drop_zone"}
    name = os.path.basename(url.split("?")[0]) or "ahcccs_table.xlsx"
    dest = os.path.join(tables_dir, name)
    if os.path.exists(dest):
        stem, ext = os.path.splitext(name)
        dest = os.path.join(tables_dir, f"{stem}_{sha[:12]}{ext}")
    tmp = dest + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, dest)
    return {"path": dest, "sha256": sha, "status": "downloaded"}
