"""
ingest_ncci_tables.py  -  Medicaid NCCI quarterly edit tables -> Rule objects.

Discovers every  medicaid_ncci_edit_<service>_<ptp|mue>_q<N>_<YYYY>  table in
the source schema and turns it into dated, cited, machine-checkable rules.

Design (MVP):
  * Scope filter is applied IN SPARK before anything reaches pandas, so a
    claims-scoped run over the full federal library stays cheap.
  * PTP: a pair is kept only when BOTH codes are in scope. A PTP violation
    needs both codes co-billed, so a pair with one never-paid code can never
    fire; keeping it only inflates the rule count.
  * PTP quarterly files are cumulative snapshots and each pair carries its own
    effective/deletion date, so only the LATEST PTP quarter per service is
    loaded. Loading several duplicates every active pair.
    C2-12: the OLDEST loaded PTP quarter is also read (four columns, scoped the same
    way) for ONE purpose: a pair whose modifier indicator differs between the oldest
    and the newest file for the SAME effective date may have been changed
    prospectively, and today's indicator must not judge older dates of service more
    strictly than the file in force then. Such a rule is split at the newest quarter's
    start (before: the most permissive of the two indicators; from: the newest),
    flagged ambiguous and labelled 'ccmi_changed_across_quarters'.
  * C2-05: a PTP row whose effective date equals its deletion date is a retroactive
    deletion. CMS 2026 Medicaid NCCI Technical Guidance Manual (TGM), App. B: "Bypass
    the edit if the effective date and the deletion date are the same". Dropped and
    counted whatever its indicator.
  * MUE files carry no dates, so validity is reconstructed from the quarter
    sequence: a value carries forward until it changes or the code disappears.
    A code that vanishes from a later quarter gets its run closed (previously
    a removed MUE stayed live forever).
    C2-03: CMS raises and deletes MUEs RETROACTIVELY and the public files are undated,
    so a run carries `later_max_threshold` (highest value the code has in any later
    loaded quarter of the same edition) and `removed_later` (the code is absent from a
    later loaded quarter) - attached here when a later quarter has something to say,
    defaulted (None / False) by rule_normalize for every other MUE. The detector labels a
    finding 'verify_mue_changed_later' when its units are within that later value or the
    code was removed later.
  * Medicaid NCCI MUEs are per-claim-line edits. CMS's Medicaid NCCI Technical
    Guidance states the MUE is compared to the units of service on ONE claim line
    at a time and is NOT summed across lines for a date of service. So every MUE
    compiles per-line. MAI (MUE Adjudication Indicator) is not present in the
    Medicaid files; if a future file carries it, it is recorded for audit only and
    never switches adjudication to a date-of-service sum (that is the Medicare model).
  * NCCI edit files apply by PROVIDER TYPE and claim FORM (TGM s6.0 Table 2, s5.2): each claim
    line takes one edit file (ncci_routing, stamped in the detection snapshot); every rule here
    keeps its edition in predicate['service_category'] and rule_normalize copies it to
    predicate['ncci_edition'] (see route_note()).
  * No 'enforcement' plane. "A hard-denial pair was paid anyway" is a finding
    the detector labels at run time (finding_severity), not a second rule.
  * Every NCCI rule carries source_url and a content hash (doc_hash) so a
    reviewer can tell exactly which edit and which snapshot it came from.
    C2-19: when the table was loaded by acquire_ncci, doc_hash is the sha256 of the
    archived CMS zip and source_url its download URL (from the src_* columns acquire
    writes into the table, else acquire_ncci.acquisition_provenance); a table with no
    acquisition record says doc_version 'hand_loaded:<table>' and keeps the content hash.
  * C2-11: codes are normalised before use (a numeric code column turns anesthesia
    00100 into 100 / 100.0: zero-padded back to 5 characters) and every code must be
    a 5-character CPT/HCPCS code; a table whose name looks like an NCCI table but
    does not match the naming pattern is an error, not a silent skip.
"""
from __future__ import annotations

import hashlib
import numbers
import re
from datetime import date, datetime, timedelta

import pandas as pd

import config
from schema import Rule

# --------------------------------------------------------------- constants
MEDICAID_NCCI_URL = ("https://www.cms.gov/medicare/coding-billing/"
                     "ncci-medicaid/medicaid-ncci-edit-files")

QUARTER_START = {1: "01-01", 2: "04-01", 3: "07-01", 4: "10-01"}
QUARTER_END = {1: "03-31", 2: "06-30", 3: "09-30", 4: "12-31"}

TABLE_PREFIX = "medicaid_ncci_edit_"
_TABLE_RE = re.compile(
    r"^medicaid_ncci_edit_(?P<service>[a-z]+)_(?P<edit>ptp|mue)_q(?P<q>[1-4])_(?P<y>\d{4})$",
    re.I)

# CPT / HCPCS Level II (same pattern acquire_ncci validates with)
CODE_RE = re.compile(r"^[A-Z0-9]{5}$")

# C2-23: a deletion date of 9999-12-31 (or ...-30) is "no deletion", not a date: treated as
# open-ended so nothing downstream adds a day to date.max.
OPEN_END = date(9999, 12, 30)
# cells that mean "no date" (a blank deletion date = still active)
_BLANK_DATE = {"", "*", "nan", "nat", "none", "<na>", "null", "99999999"}
# formats acquire_ncci._to_yyyymmdd accepts besides yyyymmdd (+ two common export spellings)
_DATE_FORMATS = ("%m/%d/%Y", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%y", "%m/%d/%Y %H:%M:%S", "%Y/%m/%d")

# C2-24: the MUE Adjudication Indicator column is matched on these EXACT normalised names
# only. The old substring match mapped any header containing 'mai' ('Remaining_Units_Note')
# to the MAI, and its values then split runs on spurious 'changes'.
MAI_COLUMN_NAMES = ("mueadjudicationindicator", "adjudicationindicator", "mai")

# most permissive first: 9 = no edit, 1 = a modifier may bypass, 0 = hard denial
_CCMI_PERMISSIVE_ORDER = ("9", "1", "0")


# ----------------------------------------------------------------- helpers
def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def _find_col(columns, *cands):
    """Return the real column name whose normalised form matches any candidate
    (exact first, then prefix), or None."""
    norm = {_norm(c): c for c in columns}
    for cand in cands:
        k = _norm(cand)
        if k in norm:
            return norm[k]
    for cand in cands:
        k = _norm(cand)
        for nk, real in norm.items():
            if nk.startswith(k):
                return real
    for cand in cands:
        k = _norm(cand)
        for nk, real in norm.items():
            if k in nk:
                return real
    return None


def _find_col_exact(columns, *cands):
    """C2-24: exact normalised-name match only (no prefix / substring fallback)."""
    norm = {_norm(c): c for c in columns}
    for cand in cands:
        k = _norm(cand)
        if k in norm:
            return norm[k]
    return None


def _ptp_columns(cols) -> dict:
    return {"c1": _find_col(cols, "column1", "col1", "comprehensive code"),
            "c2": _find_col(cols, "column2", "col2", "component code"),
            "mod": _find_col(cols, "modifier indicator", "modifier"),
            "eff": _find_col(cols, "effective date", "effdt"),
            "del": _find_col(cols, "deletion date", "deldt"),
            "rat": _find_col(cols, "ptp edit rationale", "edit rationale", "rationale")}


def _mue_code_column(cols):
    return _find_col(cols, "hcpcs/cpt code", "hcpcs cpt code", "procedure code", "code")


def _missing(v) -> bool:
    if v is None:
        return True
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def norm_code(v) -> str:
    """C2-11: procedure code as the claims table spells it. A code column read as a number
    loses leading zeros (anesthesia 00100 -> 100 / 100.0, '0938' -> 938); purely numeric
    codes are zero-padded back to 5 characters. Anything else is upper-cased and trimmed;
    a missing cell becomes '' (and fails CODE_RE, so it is reported, not matched)."""
    if _missing(v):
        return ""
    if isinstance(v, bool):
        return str(v).upper()
    if isinstance(v, numbers.Integral):
        s = str(int(v))
    elif isinstance(v, numbers.Real):
        f = float(v)
        s = str(int(f)) if f.is_integer() else str(v)
    else:
        s = str(v).strip().upper()
        if re.fullmatch(r"\d+\.0+", s):
            s = s.split(".")[0]
    if s.isdigit() and len(s) < 5:
        s = s.zfill(5)
    return s


def _parse_date(v, open_end: bool = False) -> tuple[str | None, bool]:
    """CMS date cell -> (iso | None, ok).

    '20250101', 20250101.0, '1/1/2025', '2025-01-01', date/datetime objects parse.
    '*', blank, NaN, None and 99999999 mean 'no date' -> (None, True).
    open_end=True (deletion dates): a date on or after 9999-12-30 is also 'no date' (C2-23).
    Anything else ('20251301', 0, '00000000', 'soon') -> (None, False): the caller must report
    it. C2-10: the old parser returned None for those too, so a garbled deletion date made a
    deleted edit 'active forever' without a word."""
    if _missing(v):
        return None, True
    if isinstance(v, datetime):
        d = v.date()
    elif isinstance(v, date):
        d = v
    else:
        if isinstance(v, bool):
            return None, False
        if isinstance(v, numbers.Integral):
            s = str(int(v))
        elif isinstance(v, numbers.Real):
            s = str(int(v)) if float(v).is_integer() else str(v)
        else:
            s = str(v).strip()
        if s.endswith(".0"):                # CMS dates read as floats: 20241231.0
            s = s[:-2]
        if s.lower() in _BLANK_DATE:
            return None, True
        d = None
        if re.fullmatch(r"\d{8}", s):
            try:
                d = datetime.strptime(s, "%Y%m%d").date()
            except ValueError:
                return None, False
        else:
            for fmt in _DATE_FORMATS:
                try:
                    d = datetime.strptime(s, fmt).date()
                    break
                except ValueError:
                    pass
            if d is None:
                return None, False
    if open_end and d >= OPEN_END:
        return None, True
    return d.isoformat(), True


def _iso(v) -> str | None:
    """CMS date cells: '20250101', '1/1/2025', '*', '', NaN. '*' and blank mean
    'no date' (for deletion date: still active). Returns None for an unparseable cell
    too; ptp_rules uses _parse_date() so that case is an error, not 'active' (C2-10)."""
    iso, _ok = _parse_date(v, open_end=True)
    return iso


def _hash(*parts) -> str:
    return hashlib.sha256(
        "|".join("" if p is None else str(p) for p in parts).encode()
    ).hexdigest()[:16]


def _strict_report(meta: dict, what: str, bad: list, strict: bool, dropped: bool, n: int | None = None):
    """D9: never lose NCCI rows silently. strict (config.NCCI_STRICT, default True) raises;
    otherwise the count and examples are printed. n = total count when `bad` holds examples only."""
    if not bad:
        return
    count = len(bad) if n is None else n
    msg = (f"{meta['table']}: {count:,} rows with {what}"
           f"{' - NOT loaded' if dropped else ''}; e.g. {bad[:5]}")
    if strict:
        raise ValueError(msg + ". Fix the source table, or set config.NCCI_STRICT=False to load with a warning.")
    print("    WARNING " + msg)


def quarter_sort_key(meta: dict):
    return (int(meta["year"]), int(meta["quarter"]))


def quarter_end(meta: dict) -> str:
    """Last calendar day of the meta's quarter (ISO)."""
    return f"{int(meta['year'])}-{QUARTER_END[int(meta['quarter'])]}"


def newest_quarter_end(metas: list[dict]) -> dict[tuple[str, str], str]:
    """C2-14: {(service, edit_type): last day of the NEWEST loaded quarter}. The last MUE run and
    every undeleted PTP edit are open-ended; claims dated after this day are judged against the
    newest snapshot without any evidence it still holds, so 07/08 compare it with MAX(DOS)."""
    newest: dict[tuple[str, str], dict] = {}
    for m in metas:
        k = (m["service"], m["edit_type"])
        if k not in newest or quarter_sort_key(m) > quarter_sort_key(newest[k]):
            newest[k] = m
    return {k: quarter_end(m) for k, m in sorted(newest.items())}


def discover_tables(spark, catalog: str, schema: str, strict: bool | None = None) -> list[dict]:
    if strict is None:
        strict = getattr(config, "NCCI_STRICT", True)
    rows = spark.sql(f"SHOW TABLES IN {catalog}.{schema}").collect()
    metas, unmatched = [], []
    for r in rows:
        name = r["tableName"]
        m = _TABLE_RE.match(name)
        if not m:
            # C2-11: 'medicaid_ncci_edit_durable_medical_equipment_ptp_q4_2026' or a '_v2' copy used
            # to vanish without a message, taking a whole edition with it.
            if str(name).lower().startswith(TABLE_PREFIX):
                unmatched.append(str(name))
            continue
        q, y = int(m["q"]), int(m["y"])
        metas.append({
            "table": name,
            "fqn": f"{catalog}.{schema}.{name}",
            "service": m["service"].lower(),
            "edit_type": m["edit"].lower(),
            "quarter": q, "year": y,
            "label": f"{y}Q{q}",
            "starts": f"{y}-{QUARTER_START[q]}",
        })
    if unmatched:
        msg = (f"{catalog}.{schema}: {len(unmatched)} table(s) start with '{TABLE_PREFIX}' but do not match "
               f"'{TABLE_PREFIX}<service>_<ptp|mue>_q<1-4>_<YYYY>' (service = letters only) and are NOT "
               f"loaded: {sorted(unmatched)}")
        if strict:
            raise ValueError(msg + ". Rename or drop them, or set config.NCCI_STRICT=False to skip them with a warning.")
        print("  WARNING " + msg)
    metas.sort(key=lambda m: (m["service"], m["edit_type"], quarter_sort_key(m)))
    return metas


# ---------------------------------------------------- Spark-side scoping
def scope_variants(codes) -> list[str]:
    """C2-11: the spellings an in-scope code can have in a source table whose code column lost
    its leading zeros: '00100' -> '00100', '0100', '100'. Spark-side scoping compares the
    column (cast to string, '.0' stripped) against these, so a numeric code column no longer
    drops every anesthesia edit before pandas can zero-pad it."""
    out = set()
    for c in codes:
        c = str(c).strip().upper()
        if not c:
            continue
        out.add(c)
        if c.isdigit():
            i = 0
            while i < len(c) - 1 and c[i] == "0":
                i += 1
                out.add(c[i:])
    return sorted(out)


def _code_expr(F, col):
    """Spark-side code text: CAST AS STRING (a numeric column), trimmed, upper-cased, with a
    trailing '.0' / '.00' removed (a double / decimal column). No LPAD: LPAD truncates longer
    strings and would invent matches."""
    return F.regexp_replace(F.upper(F.trim(col.cast("string"))), r"\.0+$", "")


def _scope_in_spark(sdf, edit_type: str, code_filter):
    """Filter the Spark frame to in-scope codes BEFORE toPandas(). Falls back
    to no filter (pandas re-filters) if the code columns cannot be resolved."""
    if not code_filter:
        return sdf
    from pyspark.sql import functions as F
    codes = scope_variants(code_filter)
    if edit_type == "ptp":
        c1 = _find_col(sdf.columns, "column1", "col1", "comprehensive code")
        c2 = _find_col(sdf.columns, "column2", "col2", "component code")
        if not (c1 and c2):
            print(f"    WARNING: PTP code columns not resolved; NOT scoping in Spark (whole table goes to pandas). "
                  f"Columns: {sdf.columns}")
            return sdf
        return sdf.filter(_code_expr(F, sdf[c1]).isin(codes) & _code_expr(F, sdf[c2]).isin(codes))
    c = _mue_code_column(sdf.columns)
    if not c:
        print(f"    WARNING: MUE code column not resolved; NOT scoping in Spark. Columns: {sdf.columns}")
        return sdf
    return sdf.filter(_code_expr(F, sdf[c]).isin(codes))


def _code_columns(columns, edit_type: str) -> list[str]:
    if edit_type == "ptp":
        p = _ptp_columns(columns)
        return [c for c in (p["c1"], p["c2"]) if c]
    c = _mue_code_column(columns)
    return [c] if c else []


def _warn_numeric_code_columns(sdf, meta: dict):
    """C2-11: a numeric code column is the tell-tale of lost leading zeros (Excel / CSV import)."""
    try:
        types = dict(sdf.dtypes)
    except Exception:                       # noqa: BLE001 - informational only
        return
    num = [c for c in _code_columns(list(types), meta["edit_type"])
           if re.match(r"^(tinyint|smallint|int|bigint|long|float|double|decimal)", str(types.get(c, "")).lower())]
    if num:
        print(f"    WARNING [{meta['table']}]: code column(s) {num} are numeric "
              f"({[types[c] for c in num]}): leading zeros were lost at load; codes are zero-padded to 5 characters.")


def check_codes(df: pd.DataFrame, meta: dict, strict: bool | None = None) -> pd.DataFrame:
    """C2-11: normalise the code column(s) of one source frame (zero-pad numeric codes) and
    report every code that is not a 5-character CPT/HCPCS code. strict (config.NCCI_STRICT)
    raises; otherwise the rows are kept (a malformed code cannot match a paid claim) and a
    warning names them. Returns a normalised copy."""
    if strict is None:
        strict = getattr(config, "NCCI_STRICT", True)
    cols = _code_columns(df.columns, meta["edit_type"])
    if not cols or df.empty:
        return df
    df = df.copy()
    padded = 0
    bad_mask = pd.Series(False, index=df.index)
    for c in cols:
        before = df[c]
        after = before.map(norm_code)
        padded += int((after != before.map(lambda v: "" if _missing(v) else str(v).strip().upper())).sum())
        df[c] = after
        bad_mask |= ~after.str.fullmatch(CODE_RE.pattern)
    if padded:
        print(f"    [{meta.get('label', '')}] {meta['table']}: {padded:,} code cell(s) normalised "
              f"(zero-padded / '.0' removed)")
    if bad_mask.any():
        ex = df.loc[bad_mask, cols].head(5).astype(str).agg("/".join, axis=1).map(repr).tolist()
        _strict_report(meta, "a procedure code that is not a 5-character CPT/HCPCS code", ex, strict,
                       dropped=False, n=int(bad_mask.sum()))
    return df


# --------------------------------------------------------------------- PTP
def _ptp_rule(service: str, table: str, a: str, b: str, mi: str, eff: str, end: str | None,
              rat: str, inclusive: bool, ambiguity_note: str | None = None,
              reconciliation: str | None = None) -> Rule:
    bypass = ("an NCCI-associated modifier may bypass this edit when documented"
              if mi == "1" else "no modifier can bypass this edit")
    return Rule(
        origin="ncci", plane="coding_edit", binding_status="mandatory",
        statement=(f"NCCI PTP ({service}): {b} should not be reported with {a} "
                   f"for the same member, provider and date of service "
                   f"(modifier indicator {mi})."),
        predicate={"type": "code_pair_prohibited", "code_a": a, "code_b": b,
                   "modifier_indicator": mi, "service_category": service},
        codes=[a, b], population="all",
        machine_checkable=True,
        # the claim form and provider type are read too: they decide the edit file a line takes
        required_claim_fields=["proc_cd", "member_id", "provider_id",
                               "srvc_bgn_dt", "mod_1", "mod_2", "mod_3", "mod_4", "form_type", "prov_type"],
        source_doc=f"CMS Medicaid NCCI PTP edits ({service})",
        # D8: no quarter label in the locator - it is part of the content id, and an
        # unchanged edit must keep the SAME rule_id across quarters or old findings orphan.
        source_locator=f"pair {a}/{b}",
        source_url=MEDICAID_NCCI_URL,
        doc_version=table,
        doc_hash=_hash(table, "ptp", a, b, mi, eff, end),
        effective_date=eff, end_date=end,
        ambiguity_flag=bool(ambiguity_note),
        ambiguity_note=ambiguity_note,
        reconciliation=reconciliation,
        notes=(f"Modifier indicator {mi}: {bypass}."
               + (f" Edit deleted; last date of service it applies to is {end}"
                  f" (config.NCCI_DELETION_DATE_INCLUSIVE={inclusive})." if end else "")
               + (f" CMS rationale: {rat}." if rat else "")),
    ).assign_id()


def most_permissive_ccmi(values) -> str:
    """'9' (no edit) > '1' (bypassable) > '0' (hard denial)."""
    vals = set(str(v) for v in values)
    for v in _CCMI_PERMISSIVE_ORDER:
        if v in vals:
            return v
    raise ValueError(f"no modifier indicator in {values!r}")


def ptp_indicator_frame(df: pd.DataFrame, code_filter=None) -> pd.DataFrame | None:
    """C2-12: one PTP snapshot -> DataFrame[code_a, code_b, eff, mi] (codes normalised, eff ISO,
    mi in 0/1/9). Rows without a parseable effective date or indicator are left out (they are
    reported by ptp_rules); None if the columns cannot be resolved."""
    p = _ptp_columns(df.columns)
    if not (p["c1"] and p["c2"] and p["mod"] and p["eff"]):
        return None
    out = pd.DataFrame({
        "code_a": df[p["c1"]].map(norm_code),
        "code_b": df[p["c2"]].map(norm_code),
        "eff": df[p["eff"]].map(lambda v: _parse_date(v)[0]),
        "mi": df[p["mod"]].map(lambda v: str(v).strip()[:1]),
    })
    out = out[out["eff"].notna() & out["mi"].isin(["0", "1", "9"])]
    if code_filter:
        out = out[out["code_a"].isin(code_filter) & out["code_b"].isin(code_filter)]
    return out.drop_duplicates().reset_index(drop=True)


def ccmi_changes(old: pd.DataFrame | None, new: pd.DataFrame | None) -> pd.DataFrame:
    """C2-12 (pure): pairs present in BOTH snapshots with the same effective date whose modifier
    indicator(s) differ. Columns: code_a, code_b, eff, mi_old, mi_new (the sorted indicator
    set of each snapshot, e.g. '0' or '01'), mi_before (most permissive over both)."""
    cols = ["code_a", "code_b", "eff", "mi_old", "mi_new", "mi_before"]
    if old is None or new is None or old.empty or new.empty:
        return pd.DataFrame(columns=cols)
    key = ["code_a", "code_b", "eff"]
    agg = lambda s: "".join(sorted(set(s)))              # noqa: E731
    o = old.groupby(key)["mi"].agg(agg).rename("mi_old")
    n = new.groupby(key)["mi"].agg(agg).rename("mi_new")
    m = pd.concat([o, n], axis=1, join="inner").reset_index()
    m = m[m["mi_old"] != m["mi_new"]].copy()
    m["mi_before"] = [most_permissive_ccmi(set(a) | set(b)) for a, b in zip(m["mi_old"], m["mi_new"])]
    return m[cols].reset_index(drop=True)


def ccmi_split(eff: str, end: str | None, mi_new: str, mi_before: str, split_start: str) -> list[tuple]:
    """C2-12 (pure): windows for a rule whose indicator changed between snapshots.
    -> [(eff, end, mi), ...]. Before split_start the most permissive indicator (mi_before; '9' =
    no edit, so no part); from split_start the newest. No split when they are equal or the
    edit starts on/after split_start."""
    if mi_before == mi_new or eff >= split_start:
        return [(eff, end, mi_new)]
    s = date.fromisoformat(split_start)
    before_end = (s - timedelta(days=1)).isoformat()
    if end is not None and end < before_end:
        before_end = end
    parts = []
    if mi_before in ("0", "1"):
        parts.append((eff, before_end, mi_before))
    if end is None or end >= split_start:
        parts.append((split_start, end, mi_new))
    return parts


def ptp_rules(df: pd.DataFrame, meta: dict, code_filter=None, stats: dict | None = None,
              ccmi: pd.DataFrame | None = None, ccmi_from: dict | None = None) -> list[Rule]:
    """One PTP snapshot -> rules. ccmi = ccmi_changes(oldest, this) and ccmi_from = the oldest
    snapshot's meta (C2-12); stats (optional dict) receives the row counts."""
    cols = df.columns
    pc = _ptp_columns(cols)
    c1, c2, c_mod, c_eff, c_del, c_rat = pc["c1"], pc["c2"], pc["mod"], pc["eff"], pc["del"], pc["rat"]
    if not (c1 and c2):
        raise ValueError(f"{meta['table']}: cannot find Column 1/2. Saw {list(cols)}")
    if not c_mod:
        # without this every row would be treated as indicator 9 and silently skipped
        raise ValueError(f"{meta['table']}: cannot find the modifier-indicator column. Saw {list(cols)}")
    if not (c_eff and c_del):
        print(f"    WARNING [{meta['table']}]: effective/deletion date column not found "
              f"(eff={c_eff}, del={c_del}); deleted edits would stay live. Saw {list(cols)}")

    service = meta["service"]
    strict = getattr(config, "NCCI_STRICT", True)
    inclusive = getattr(config, "NCCI_DELETION_DATE_INCLUSIVE", True)
    changes = {}
    if ccmi is not None and len(ccmi):
        changes = {(r["code_a"], r["code_b"], r["eff"]): r for r in ccmi.to_dict("records")}
    old_table = (ccmi_from or {}).get("table", "the oldest loaded quarter")
    rules, skipped9, bad_mi, bad_eff, bad_del = [], 0, [], [], []
    retro = inverted = ccmi_flagged = ccmi_split_n = ccmi_before_dropped = 0
    for row in df.to_dict("records"):
        a = norm_code(row[c1])
        b = norm_code(row[c2])
        if code_filter and not (a in code_filter and b in code_filter):
            continue
        raw_mi = str(row[c_mod]).strip()
        mi = raw_mi[:1]
        if mi == "9":
            skipped9 += 1          # 9 = edit deleted; nothing to enforce
            continue
        end, del_ok = _parse_date(row[c_del], open_end=True) if c_del else (None, True)
        if not del_ok:
            # C2-10: an unparseable deletion date (20251301, 0, 00000000) used to read as "no
            # deletion" - a deleted edit stayed live forever. Strict error, like a bad indicator.
            bad_del.append(f"{a}/{b}:{row[c_del]!r}")
            continue
        eff, _eff_ok = _parse_date(row[c_eff]) if c_eff else (None, True)
        if eff is not None and end is not None and end == eff:
            # C2-05: TGM App. B "Bypass the edit if the effective date and the deletion date are
            # the same" (a retroactive deletion). It used to compile into a one-day hard denial.
            retro += 1
            continue
        if eff is not None and end is not None and end < eff:
            inverted += 1          # deleted before it took effect: never active on any date
            continue
        if mi not in ("0", "1"):
            # D9: a blank / garbled indicator used to be counted as "deleted" and dropped.
            bad_mi.append(f"{a}/{b}:{raw_mi!r}")
            continue
        raw_eff = eff
        if eff is None:
            # D9: a missing effective date used to become the start of the LATEST quarter,
            # silently truncating the edit's history.
            bad_eff.append(f"{a}/{b}:{row[c_eff] if c_eff else '<no column>'!r}")
            eff = meta["starts"]
        if end and not inclusive:
            # D10: config.NCCI_DELETION_DATE_INCLUSIVE=False -> the edit stops the day BEFORE DelDt
            end = (date.fromisoformat(end) - timedelta(days=1)).isoformat()
        rat = str(row[c_rat]).strip() if c_rat and str(row[c_rat]).strip() not in ("nan", "", "None") else ""
        ch = changes.get((a, b, raw_eff)) if raw_eff else None
        if ch is None:
            rules.append(_ptp_rule(service, meta["table"], a, b, mi, eff, end, rat, inclusive))
            continue
        # C2-12: the oldest loaded snapshot gives this pair a different indicator for the SAME
        # effective date. Whether CMS changed it retroactively or prospectively is unknown, so no
        # date of service before the newest quarter is judged more strictly than either file.
        ccmi_flagged += 1
        parts = ccmi_split(eff, end, mi, ch["mi_before"], meta["starts"])
        if parts != [(eff, end, mi)]:
            ccmi_split_n += 1
        if ch["mi_before"] == "9" and eff < meta["starts"]:
            # the oldest file says 'not applicable' (9): no edit before the newest quarter; an edit
            # that also ended before it produces no rule at all (parts == [])
            ccmi_before_dropped += 1
        note = (f"Modifier indicator differs between {old_table} ({ch['mi_old']}) and {meta['table']} "
                f"({ch['mi_new']}) for this pair with effective date {raw_eff}; CMS may have changed it "
                f"prospectively. Before {meta['starts']} the most permissive ({ch['mi_before']}) is applied, "
                f"from {meta['starts']} the newest ({mi}). Confirm against the CMS change reports.")
        for p_eff, p_end, p_mi in parts:
            rules.append(_ptp_rule(service, meta["table"], a, b, p_mi, p_eff, p_end, rat, inclusive,
                                   ambiguity_note=note, reconciliation="ccmi_changed_across_quarters"))

    _strict_report(meta, "modifier indicator not 0/1/9", bad_mi, strict, dropped=True)
    _strict_report(meta, "deletion date unparseable", bad_del, strict, dropped=True)
    _strict_report(meta, "effective date missing/unparseable (used quarter start)", bad_eff, strict, dropped=False)
    print(f"    [{meta['label']}] {service:12s} ptp  {len(rules):,} rules"
          f"  (skipped {skipped9:,} deleted-indicator rows, {retro:,} EffDt==DelDt retroactive deletions"
          + (f", {inverted:,} deleted before effective" if inverted else "")
          + (f", {ccmi_flagged:,} indicator changed vs {old_table}" if changes else "") + ")")
    if stats is not None:
        stats.update(rules=len(rules), skipped_indicator9=skipped9, retro_deleted=retro, inverted=inverted,
                     bad_indicator=len(bad_mi), bad_deletion_date=len(bad_del), bad_effective_date=len(bad_eff),
                     ccmi_changes=len(changes), ccmi_flagged=ccmi_flagged, ccmi_split=ccmi_split_n,
                     ccmi_no_edit_before_newest=ccmi_before_dropped)
    return rules


# --------------------------------------------------------------------- MUE
def quarter_gaps(quarters: list[dict]) -> list[str]:
    """ISO start dates of quarters missing between consecutive loaded quarters."""
    missing = []
    for prev, nxt in zip(quarters, quarters[1:]):
        d = date.fromisoformat(prev["starts"])
        end = date.fromisoformat(nxt["starts"])
        while True:
            m = d.month + 3
            d = date(d.year + (m - 1) // 12, (m - 1) % 12 + 1, 1)
            if d >= end:
                break
            missing.append(d.isoformat())
    return missing


def _mue_value(v):
    """Whole, non-negative MUE value or None. 4.9 must not become a stricter 4 (D9 spirit)."""
    try:
        f = float(str(v).strip())
    except (TypeError, ValueError):
        return None
    if f != f or f < 0 or not f.is_integer():
        return None
    return int(f)


def later_changes(per_q: dict, quarters: list[dict], last_label: str) -> tuple:
    """C2-03 (pure): for a run whose last observed quarter is `last_label` ->
    (later_max_threshold, removed_later) over the loaded quarters AFTER it: the highest value
    the code has in any of them (None if it never reappears) and whether it is absent from any."""
    labels = [m["label"] for m in quarters]
    later = labels[labels.index(last_label) + 1:]
    vals = [per_q[q][0] for q in later if q in per_q]
    return (max(vals) if vals else None), any(q not in per_q for q in later)


def mue_history(frames: list[tuple[dict, pd.DataFrame]], code_filter=None,
                allow_gaps: bool = False, stats: dict | None = None) -> list[Rule]:
    """Quarterly MUE snapshots -> dated rules (run-length over the sequence).

    A run opens when a code first appears or its value/MAI changes, and closes
    the day before the next quarter in which the value changes OR the code is
    absent. The last run stays open (end_date=None) only if the code is present
    in the most recent quarter loaded.
    A run that a later loaded quarter shows again or drops carries later_max_threshold /
    removed_later in its predicate (C2-03); they are left out of the rule id (the id must not
    change when a later quarter is loaded).
    """
    by_service: dict[str, list[tuple[dict, pd.DataFrame]]] = {}
    for meta, df in frames:
        by_service.setdefault(meta["service"], []).append((meta, df))

    strict = getattr(config, "NCCI_STRICT", True)
    rules: list[Rule] = []
    mai_seen = False
    n_dup_same = n_dup_conflict = 0
    for service, seq in by_service.items():
        seq.sort(key=lambda t: quarter_sort_key(t[0]))
        quarters = [m for m, _ in seq]
        # F15: the run-length reconstruction assumes CONSECUTIVE quarters. A missing
        # quarter would silently extend the previous value across it. Refuse to infer
        # across a gap unless the caller opts in, and then flag every run that spans one.
        gaps = quarter_gaps(quarters)
        if gaps and not allow_gaps:
            raise ValueError(f"{service}: MUE quarters are not contiguous; missing {gaps}. "
                             f"Load the missing tables or call mue_history(..., allow_gaps=True).")
        gap_starts = [g for g in gaps]

        # code -> {quarter_label: (value, rationale, mai)}
        obs: dict[str, dict[str, tuple]] = {}
        for meta, df in seq:
            bad_val: list = []
            cols = df.columns
            c_code = _mue_code_column(cols)
            c_val = _find_col(cols, "mue value", "mue values")
            c_rat = _find_col(cols, "mue rationale", "rationale")
            # C2-24: exact names only ('Remaining_Units_Note' is not an adjudication indicator)
            c_mai = _find_col_exact(cols, *MAI_COLUMN_NAMES)
            if not (c_code and c_val):
                raise ValueError(f"{meta['table']}: cannot find code/value. Saw {list(cols)}")
            if c_mai:
                mai_seen = True
            seen: dict[str, tuple] = {}            # this quarter's code -> (value, rationale, mai)
            dup_same, dup_conflict = 0, []
            for row in df.to_dict("records"):
                code = norm_code(row[c_code])
                if code_filter and code not in code_filter:
                    continue
                val = _mue_value(row[c_val])
                if val is None:
                    bad_val.append(f"{code}:{row[c_val]!r}")      # D9: was dropped silently
                    continue
                mai = None
                if c_mai:
                    try:
                        mai = int(str(row[c_mai]).strip()[:1])
                    except (TypeError, ValueError):
                        mai = None
                rat = str(row[c_rat]).strip() if c_rat else ""
                if rat in ("nan", "None"):
                    rat = ""
                if code in seen:
                    # C2-21: the same code twice in ONE quarter used to let the last row win silently.
                    pv, _prat, pmai = seen[code]
                    if (pv, pmai) == (val, mai):
                        dup_same += 1              # identical values: de-duplicated
                        continue
                    dup_conflict.append(f"{code}:{pv} vs {val}")
                    if val > pv:                   # non-strict: keep the MOST PERMISSIVE (max) value
                        seen[code] = (val, rat, mai)
                    continue
                seen[code] = (val, rat, mai)
            for code, v in seen.items():
                obs.setdefault(code, {})[meta["label"]] = v
            _strict_report(meta, "non-numeric MUE value", bad_val, strict, dropped=True)
            _strict_report(meta, "a code listed twice with DIFFERENT MUE values (the maximum is kept)",
                           dup_conflict, strict, dropped=False)
            if dup_same:
                print(f"    [{meta['label']}] {service:12s} mue  {dup_same:,} duplicate row(s) with identical "
                      f"values de-duplicated")
            n_dup_same += dup_same
            n_dup_conflict += len(dup_conflict)

        for code, per_q in obs.items():
            runs = []  # [start_meta, end_iso|None, val, rat, mai, last_meta]
            for i, meta in enumerate(quarters):
                cur = per_q.get(meta["label"])
                if cur is None:                        # code absent this quarter
                    if runs and runs[-1][1] is None:
                        runs[-1][1] = (date.fromisoformat(meta["starts"])
                                       - timedelta(days=1)).isoformat()
                    continue
                val, rat, mai = cur
                if runs and runs[-1][1] is None and runs[-1][2] == val and runs[-1][4] == mai:
                    runs[-1][5] = meta                 # unchanged -> extend (remember the last quarter seen)
                    continue
                if runs and runs[-1][1] is None:       # value changed -> close prior
                    runs[-1][1] = (date.fromisoformat(meta["starts"])
                                   - timedelta(days=1)).isoformat()
                runs.append([meta, None, val, rat, mai, meta])

            for start_meta, end, val, rat, mai, last_meta in runs:
                # CMS Medicaid NCCI Technical Guidance: an MUE is applied to the units
                # of service on ONE claim line at a time and is NOT summed across lines
                # for a DOS. Every Medicaid MUE is therefore a per-line edit. MAI, when
                # present, is kept for audit only; it never routes to a per-DOS sum (the
                # per-DOS/same-provider compiler exists only for state daily caps).
                pred = {"type": "max_units_per_line", "code": code, "threshold": val,
                        "service_category": service}
                if mai is not None:
                    pred["mai"] = mai
                mai_note = (f" Source MAI={mai} recorded for reference; Medicaid NCCI "
                            f"adjudicates per claim line regardless." if mai in (2, 3) else "")
                spans_gap = [g for g in gap_starts
                             if g > start_meta["starts"] and (end is None or g <= end)]
                later_max, removed_later = later_changes(per_q, quarters, last_meta["label"])
                later_note = ""
                if (later_max is not None and later_max > val) or removed_later:
                    # C2-03: the public files are undated and CMS revises MUEs retroactively
                    later_note = (" A later loaded quarter "
                                  + (f"raises this code's MUE to {later_max}" if later_max is not None
                                     and later_max > val else "")
                                  + (" and " if later_max is not None and later_max > val and removed_later else "")
                                  + ("drops this code" if removed_later else "")
                                  + "; CMS revises MUEs retroactively and the public files are undated, so a "
                                    "finding within the later value (or on a dropped code) is labelled "
                                    "verify_mue_changed_later.")
                rule = Rule(
                    origin="ncci", plane="coding_edit", binding_status="mandatory",
                    statement=(f"NCCI MUE ({service}): {code} maximum {val} unit(s) "
                               f"per claim line."),
                    predicate=pred,
                    codes=[code], population="all",
                    machine_checkable=True,
                    required_claim_fields=["proc_cd", "units", "form_type", "prov_type"],
                    source_doc=f"CMS Medicaid NCCI MUE values ({service})",
                    source_locator=f"code {code}",          # D8: stable id across quarters
                    source_url=MEDICAID_NCCI_URL,
                    # every quarter table the value was observed in, first..last
                    doc_version=(start_meta["table"] if last_meta is start_meta
                                 else f"{start_meta['table']}..{last_meta['table']}"),
                    doc_hash=_hash(start_meta["table"], "mue", code, val, mai, end),
                    effective_date=start_meta["starts"], end_date=end,
                    ambiguity_flag=bool(spans_gap),
                    ambiguity_note=(f"Run spans unloaded quarter(s) {spans_gap}; value in "
                                    f"those quarters is inferred, not observed." if spans_gap else None),
                    notes=(("Validity reconstructed from the quarterly sequence; "
                            "MUE files carry no effective-date column.")
                           + mai_note
                           + (f" Value retired {end}." if end else "")
                           + later_note
                           + (f" CMS rationale: {rat}." if rat else "")),
                ).assign_id()
                # C2-03: added AFTER assign_id - they change whenever a later quarter is loaded and
                # must not move the rule id (rule_normalize.rule_id_for leaves them out too).
                # Attached only when a later quarter has the code again or drops it; for the
                # open-ended run rule_normalize.route_ncci_rules sets the defaults (None / False),
                # so every MUE has both keys after normalize_rules.
                if later_max is not None or removed_later:
                    rule.predicate["later_max_threshold"] = later_max
                    rule.predicate["removed_later"] = bool(removed_later)
                rules.append(rule)

    if not mai_seen:
        print("    MUE: source tables carry no MUE Adjudication Indicator (MAI); "
              "all MUEs modelled as per-claim-line caps.")
    if stats is not None:
        stats.update(rules=len(rules), duplicate_rows_deduplicated=n_dup_same,
                     duplicate_codes_conflicting=n_dup_conflict,
                     runs_changed_later=sum(1 for r in rules if r.predicate.get("removed_later")
                                            or (r.predicate.get("later_max_threshold") or 0) > r.predicate["threshold"]))
    return rules


# -------------------------------------------------------------- provenance
def _clean(v):
    return None if _missing(v) or str(v).strip() == "" else v


def _as_record(v) -> dict:
    if isinstance(v, dict):
        return dict(v)
    if isinstance(v, str):                  # {table: '<sha256>'}
        return {"sha256": v}
    if hasattr(v, "__dataclass_fields__"):
        from dataclasses import asdict
        return asdict(v)
    return dict(getattr(v, "__dict__", {}) or {})


def normalize_provenance(raw) -> dict[str, dict]:
    """C2-19: whatever acquire_ncci.acquisition_provenance returns (a {table: record} dict, a list of
    records / LoadResults, or the acquisition-log DataFrame) -> {table_name_lower: {sha256, url, zip,
    loaded_at}}. Records without a zip sha256, and failed / skipped loads, are not provenance (a
    'skipped_exists' record hashes a zip that did NOT produce the table)."""
    if raw is None:
        return {}
    if isinstance(raw, pd.DataFrame):
        items = raw.to_dict("records")
    elif isinstance(raw, dict):
        items = []
        for k, v in raw.items():
            rec = _as_record(v)
            rec.setdefault("table", k)
            items.append(rec)
    else:
        items = [_as_record(v) for v in raw]
    out: dict[str, dict] = {}
    for rec in items:
        t = str(_clean(rec.get("table")) or _clean(rec.get("table_name")) or _clean(rec.get("fqn")) or "")
        t = t.split(".")[-1].strip().lower()
        sha = _clean(rec.get("src_sha256")) or _clean(rec.get("sha256"))
        status = _clean(rec.get("status"))
        if not t or not sha or status not in (None, "loaded"):
            continue
        url = _clean(rec.get("src_url")) or _clean(rec.get("url"))
        url = str(url) if url is not None and str(url).startswith("http") else None
        loaded = str(_clean(rec.get("loaded_at")) or "")
        prev = out.get(t)
        if prev is None or loaded >= prev["loaded_at"]:
            out[t] = {"sha256": str(sha), "url": url, "zip": _clean(rec.get("src_zip")), "loaded_at": loaded}
    return out


def load_acquisition_provenance(spark, catalog: str, schema: str) -> dict[str, dict]:
    """C2-19: acquire_ncci.acquisition_provenance(spark, catalog, schema) when it exists, normalised;
    {} when it does not exist or fails (provenance then comes from the tables' own src_* columns
    only, else 'hand_loaded')."""
    try:
        import acquire_ncci
        raw = acquire_ncci.acquisition_provenance(spark, catalog, schema)
    except AttributeError:
        print("    provenance: acquire_ncci.acquisition_provenance not available; using the tables' src_* columns only")
        return {}
    except Exception as e:                  # noqa: BLE001 - provenance never blocks the build
        print(f"    provenance: acquisition record not readable ({type(e).__name__}: {str(e)[:200]}); "
              f"using the tables' src_* columns only")
        return {}
    try:
        return normalize_provenance(raw)
    except Exception as e:                  # noqa: BLE001
        print(f"    provenance: unexpected acquisition record shape ({type(e).__name__}); ignored")
        return {}


def table_provenance(prov: dict, meta: dict, df: pd.DataFrame | None = None) -> dict | None:
    """The acquisition record of one source table; None = hand-loaded.

    The src_sha256 / src_url columns acquire_ncci writes into every row it loads come first: they
    travel WITH the data, so a table overwritten by hand after an acquisition cannot inherit the old
    zip's hash. The acquisition log (acquire_ncci.acquisition_provenance) covers tables without
    those columns. A disagreement between the two is printed."""
    log = (prov or {}).get(str(meta["table"]).lower())
    if df is not None and "src_sha256" in df.columns:
        shas = sorted({str(v) for v in df["src_sha256"] if _clean(v) is not None})
        if shas:
            urls = (sorted({str(v) for v in df["src_url"] if _clean(v) is not None and str(v).startswith("http")})
                    if "src_url" in df.columns else [])
            rec = {"sha256": ";".join(shas), "url": "; ".join(urls) or None, "source": "table_columns"}
            if log and log.get("sha256") != rec["sha256"]:
                print(f"    WARNING [{meta['table']}]: the acquisition log says zip sha256 {str(log.get('sha256'))[:12]}... "
                      f"but the table's rows say {rec['sha256'][:12]}...; the rows are cited")
            elif rec["url"] is None and log and log.get("url"):
                rec["url"] = log["url"]          # same zip: the log may know the download URL
            return rec
    if log:
        return dict(log, source="acquisition_log")
    return None


def apply_provenance(rules: list[Rule], table_prov: dict) -> dict:
    """C2-19: doc_hash = the source zip's sha256 and source_url = its download URL when the rule's
    source table has an acquisition record; otherwise doc_version 'hand_loaded:<table>' and the
    content hash stays. The source table is doc_version (an MUE run: the quarter its value was first
    observed in). Ids are untouched (doc_hash / source_url / doc_version are not part of them)."""
    n_acq = n_hand = 0
    for r in rules:
        dv = r.doc_version or ""
        if dv.startswith("hand_loaded:"):
            n_hand += 1
            continue
        rec = (table_prov or {}).get(dv.split("..")[0].lower())
        if rec and rec.get("sha256"):
            r.doc_hash = rec["sha256"]
            if rec.get("url"):
                r.source_url = rec["url"]
            n_acq += 1
        else:
            r.doc_version = f"hand_loaded:{dv}"
            n_hand += 1
    return {"rules_with_acquisition_record": n_acq, "rules_hand_loaded": n_hand}


# ------------------------------------------------------------------ driver
def _load(spark, meta: dict, cf, strict: bool, columns: tuple | None = None,
          counts: list | None = None) -> pd.DataFrame:
    """One NCCI table as pandas, scoped to the claims' codes in Spark. counts (optional list) receives
    {table, service, edit_type, quarter, source_rows, rows_in_claims_scope}: the CMS file's size next to the part of it
    that can touch this claims population (2026-10-04 external review: the KB's NCCI count is the edits executable
    against these claims, not the size of the CMS edit set - report both)."""
    sdf = spark.table(meta["fqn"])
    _warn_numeric_code_columns(sdf, meta)
    total = sdf.count() if counts is not None else None
    sdf = _scope_in_spark(sdf, meta["edit_type"], cf)
    if columns:
        sdf = sdf.select(*[c for c in columns if c])
    df = check_codes(sdf.toPandas(), meta, strict)
    if counts is not None:
        counts.append({"table": meta["table"], "service": meta["service"], "edit_type": meta["edit_type"],
                       "quarter": meta.get("label"), "source_rows": int(total),
                       "rows_in_claims_scope": int(len(df)) if cf else int(total)})
    return df


def scope_lines(counts: list[dict], scoped: bool) -> list[str]:
    """The source-vs-claims lines 07 prints and stores (one per table read for rules)."""
    out = []
    for c in counts:
        share = f" ({c['rows_in_claims_scope'] / c['source_rows']:.1%})" if c["source_rows"] else ""
        what = "with both codes" if c["edit_type"] == "ptp" else "whose code is"
        out.append(f"{c['edit_type'].upper()} {c['service']} {c['quarter']}: {c['source_rows']:,} rows in the CMS file; "
                   + (f"{c['rows_in_claims_scope']:,} {what} paid in these claims{share}" if scoped
                      else "no claims scope (all rows read)"))
    return out


def ingest_tables(spark, catalog: str | None = None, schema: str | None = None,
                  code_filter=None, allow_mue_gaps: bool | None = None,
                  report: dict | None = None) -> list[Rule]:
    """Build NCCI rules. code_filter: iterable of procedure codes (None = all).
    allow_mue_gaps: infer MUE validity across an unloaded quarter (flagged ambiguous);
    default config.NCCI_ALLOW_MUE_GAPS (False = refuse and name the missing quarters).
    report (optional dict) receives the counts printed below (JSON-safe)."""
    if allow_mue_gaps is None:
        allow_mue_gaps = getattr(config, "NCCI_ALLOW_MUE_GAPS", False)
    catalog = catalog or config.CATALOG
    schema = schema or config.SCHEMA
    strict = getattr(config, "NCCI_STRICT", True)
    cf = set(norm_code(c) for c in code_filter) if code_filter else None

    metas = discover_tables(spark, catalog, schema, strict=strict)
    if not metas:
        # D9: this used to print and return [] - the build then published a KB with NO federal edits.
        if getattr(config, "NCCI_ALLOW_EMPTY", False):
            print(f"  WARNING: no NCCI tables found in {catalog}.{schema}; building WITHOUT federal edits")
            return []
        raise ValueError(f"no medicaid_ncci_edit_* tables in {catalog}.{schema}. Run acquire_ncci, or set "
                         f"config.NCCI_ALLOW_EMPTY=True to build state rules only.")
    print(f"  found {len(metas)} NCCI tables"
          + (f"; scope = {len(cf):,} codes" if cf else "; scope = all codes"))
    prov = load_acquisition_provenance(spark, catalog, schema)

    # latest PTP quarter per service (files are cumulative snapshots); oldest for C2-12
    latest_ptp: dict[str, dict] = {}
    oldest_ptp: dict[str, dict] = {}
    for m in metas:
        if m["edit_type"] == "ptp":
            cur = latest_ptp.get(m["service"])
            if cur is None or quarter_sort_key(m) > quarter_sort_key(cur):
                latest_ptp[m["service"]] = m
            old = oldest_ptp.get(m["service"])
            if old is None or quarter_sort_key(m) < quarter_sort_key(old):
                oldest_ptp[m["service"]] = m

    rules: list[Rule] = []
    table_prov: dict[str, dict | None] = {}
    ptp_stats: dict[str, dict] = {}
    scope_counts: list | None = [] if report is not None else None     # source vs claims-scope rows (07 reports)
    for service in sorted(latest_ptp):
        new_m, old_m = latest_ptp[service], oldest_ptp[service]
        changes, old_frame = None, None
        if old_m is not new_m:
            # C2-12: only the four columns the comparison needs, scoped exactly like the newest
            cols = spark.table(old_m["fqn"]).columns
            pc = _ptp_columns(cols)
            old_df = _load(spark, old_m, cf, strict, columns=(pc["c1"], pc["c2"], pc["eff"], pc["mod"]))
            old_frame = ptp_indicator_frame(old_df, cf)
            if old_frame is None:
                print(f"    WARNING [{old_m['table']}]: cannot resolve Col1/Col2/EffDt/modifier; "
                      f"indicator changes across quarters NOT checked for {service}")
            del old_df
        df = _load(spark, new_m, cf, strict, counts=scope_counts)
        table_prov[new_m["table"].lower()] = table_provenance(prov, new_m, df)
        if old_frame is not None:
            changes = ccmi_changes(old_frame, ptp_indicator_frame(df, cf))
        st: dict = {}
        rules += ptp_rules(df, new_m, cf, stats=st, ccmi=changes, ccmi_from=old_m if old_frame is not None else None)
        ptp_stats[service] = dict(st, snapshot=new_m["label"],
                                  compared_with=old_m["label"] if old_frame is not None else None)
        del df

    mue_frames: list[tuple[dict, pd.DataFrame]] = []
    for m in metas:
        if m["edit_type"] != "mue":
            continue
        df = _load(spark, m, cf, strict, counts=scope_counts)
        table_prov[m["table"].lower()] = table_provenance(prov, m, df)
        mue_frames.append((m, df))

    mue_stats: dict = {}
    if mue_frames:
        mue = mue_history(mue_frames, cf, allow_gaps=allow_mue_gaps, stats=mue_stats)
        by_svc: dict[str, int] = {}
        for r in mue:
            by_svc[r.predicate["service_category"]] = by_svc.get(r.predicate["service_category"], 0) + 1
        print(f"    MUE: {len(mue):,} dated rules " + str(by_svc)
              + f"; {mue_stats.get('runs_changed_later', 0):,} run(s) raised or dropped by a later quarter (C2-03)")
        rules += mue

    prov_stats = apply_provenance(rules, table_prov)
    hand = sorted(t for t, rec in table_prov.items() if not rec)
    print(f"    provenance: {prov_stats['rules_with_acquisition_record']:,} rules cite their CMS zip (sha256); "
          f"{prov_stats['rules_hand_loaded']:,} come from hand-loaded tables" + (f" {hand}" if hand else ""))

    ptp_labels = {s: m["label"] for s, m in latest_ptp.items()}
    newest = newest_quarter_end(metas)
    print(f"  NCCI rules built: {len(rules):,}   (PTP snapshot used: {ptp_labels}; newest quarter ends "
          f"{ {f'{s}/{e}': d for (s, e), d in newest.items()} })")
    if report is not None:
        for line in scope_lines(scope_counts, bool(cf)):
            print(f"    {line}")
        report.update({
            "tables": len(metas), "rules": len(rules),
            "ptp": ptp_stats, "mue": mue_stats, "provenance": dict(prov_stats, hand_loaded_tables=hand),
            "newest_quarter_end": {f"{s}/{e}": d for (s, e), d in newest.items()},
            "claims_scoped": bool(cf), "source_vs_claims_scope": scope_counts,
        })
    return rules


def route_note() -> str:
    """How NCCI edit files reach claim lines, generated from config so it cannot drift."""
    import ncci_routing
    sm = ncci_routing.summary()
    if sm["mode"] == "form":
        how = "routing by claim FORM only (config.NCCI_ROUTE_BY = 'form'): form A -> practitioner file, form O -> outpatient file"
    else:
        who = ("BILLING provider type CODE (the servicing type when the billing type is missing or not in the table; "
               "the servicing type also says whether a rendering practitioner is identified)"
               if sm["mode"] == "billing_provider_type" else "SERVICING provider type CODE")
        unm = ("no NCCI on the line" if sm["unmapped_provider_type"] == "none"
               else "the claim form decides (A -> practitioner, O -> outpatient)")
        how = (f"routing by {who} x claim form ({sm['table']}, {sm['types_mapped']} AHCCCS provider types, "
               f"{sm['types_signed']} signed; 08 requires every observed type signed: {sm.get('require_signed')}); "
               f"optional Table 2 rows switched on: {sm['optional_on'] or 'none'}; a provider type the table does not "
               f"map: {unm}")
    return ("Each claim line takes ONE Medicaid NCCI edit file, as CMS 2026 Medicaid NCCI Technical Guidance Manual s6.0 "
            "Table 2 assigns it by provider type and claim form (practitioners and ASCs -> PRA, outpatient hospitals -> "
            "OPH, DME suppliers -> DME; a practitioner on a UB-04 -> OPH, an ASC on a UB-04 -> PRA); s5.2: none on "
            "dental, pharmacy, inpatient or residential claims. The DME edits are identical inside the PRA and OPH files "
            f"(TGM fn 19), so files are never merged. This build: {how}. Every NCCI rule carries predicate['ncci_edition'] "
            "and its query checks only lines whose pie_ncci_edition matches (both lines of a pair).")
