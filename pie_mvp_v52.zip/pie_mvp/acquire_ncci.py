"""
acquire_ncci.py  -  CMS Medicaid NCCI quarterly files -> raw archive -> main.sedo Delta tables.

Replaces the manual loop (download 6 zips, open, reformat columns, load a table per file).
Output tables use the SAME names and column names as the hand-loaded ones, so
ingest_ncci_tables.discover_tables / ptp_rules / mue_history need no change:

    main.sedo.medicaid_ncci_edit_<practitioner|outpatient|dme>_<ptp|mue>_q<N>_<YYYY>

Facts this module is built on (checked against the live CMS page, 2026-09-28):
  * Page: https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files
  * 6 zips per quarter (PTP + MUE x practitioner / outpatient hospital / DME) + a change report.
  * Each zip holds text AND Excel; large PTP files are split across several workbooks.
  * PTP layout: Quarter Begin Date, Category, Column One, Column Two, Effective Date,
    Deletion Date, Modifier Indicator, PTP Edit Rationale.
    MUE layout: Quarter Begin Date, Category, HCPCS/CPT code, MUE Value, MUE Rationale.
  * URL slugs are NOT uniform across quarters (2026Q3 outpatient is
    "...-ptp-edits-hospital-outpatient-services.zip", 2026Q4 is "...-outpatient-hospital-services.zip";
    2026Q3 DME PTP drops "-services"). So links are DISCOVERED from the page, never built.
  * The page lists only the current and previous quarter. A quarter not captured while it is
    listed is gone from this source -> run this on a schedule, and archive every zip.

Re-checked 2026-10-02 (WebFetch; the sandbox shell cannot reach cms.gov):
  * The edit-files page itself does NOT describe the file layout (no 'Quarter Begin Date' or
    'Category' text on it); it says only "each zip file contains both text and Excel file(s)
    formats". The layout above is therefore the module's ASSUMPTION, which is why the header is
    located, not assumed. The CMS change-report PDF names the editions PRA / OPH / DME.
  * MUE history lives on https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-mue-archive
    (2020Q1..2026Q2). There is NO Medicaid PTP archive page (PTP files are cumulative). Real archive
    names use four different quarter spellings, and one quarter has a re-issued file:
        medicaid-ncci-2025q2-mue-edits-practitioner-services.zip        year first
        medicaid-ncci-q2-2026-mue-edits-practitioner-services.zip       quarter first (2025Q4-2026Q2)
        medicaid-mcd-mue-dmeservices-effective10012022.zip               effective MMDDYYYY (2020-2022)
        2023q1nccimueedits-durablemedicalservices.zip                    no separators, 'durablemedical'
        2025-q1-r1-ncci-mue-edits-practitioner-services.zip              revision r1 ("Effective Jan. 29, 2025")
    and the archive's 'DME, April 1, 2025' entry links the PRACTITIONER zip (C2-16).

Not verified (sandbox cannot reach cms.gov): the exact preamble/header rows inside the text
file and the delimiter. The parser therefore LOCATES the header row and SNIFFS the delimiter,
and fails loudly (ParseError) instead of guessing when the layout is not what it expects.

Design rules (same spirit as kb_io.table_or_none):
  * Nothing is silently dropped: bad dates, bad modifier indicators, non-numeric MUE values,
    a quarter-begin date that disagrees with the link, or an HTML page saved as a .zip -> raise.
  * Nothing is silently overwritten: an existing table is skipped unless overwrite=True.
    (C2-15) The one exception: a HIGHER revision of the file a table was loaded from replaces it,
    and the log row says so (status 'replaced').
  * Raw zips are kept forever, hashed, under <data>/ncci_raw/<YYYY>q<N>/.
  * Retries only on transient failures (connection errors, 429, 5xx), bounded, with backoff.
    A 403/404 is not retried - it means blocked or moved, and retrying hides that.
  * (C2-16) A file is classified by its FILE NAME only and must agree with its own content
    (Category column, edition-named MUE header); a disagreement is refused, never resolved.
  * (C4-09) A log row's sha256 is always the hash of that row's own file; the src_* columns are
    filled only on rows that actually loaded a table from it.
"""
from __future__ import annotations

import csv
import hashlib
import io
import os
import re
import time
import zipfile
from dataclasses import dataclass, field, asdict, fields
from datetime import date, datetime, timedelta, timezone
from html import unescape
from urllib.parse import urljoin

import pandas as pd

CMS_PAGE = "https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files"
CMS_MUE_ARCHIVE = "https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-mue-archive"
USER_AGENT = "Mozilla/5.0 (compatible; PIE-NCCI-acquire/1.0; +policy-intelligence)"
TABLE_TEMPLATE = "medicaid_ncci_edit_{service}_{edit}_q{quarter}_{year}"
QUARTER_START = {1: (1, 1), 2: (4, 1), 3: (7, 1), 4: (10, 1)}

# Service keys MUST match the existing table names (ingest regex is [a-z]+).
# C2-15: kept as the list of editions (check_quarter_complete) and as documentation. Classification
# now uses _services_named(), which also knows the archive spellings 'durablemedicalservices',
# 'durable-medical-services' and 'dmeservices', and refuses a name that names two editions instead
# of letting the first keyword win.
SERVICE_KEYWORDS = [                     # checked in order; first hit wins
    ("dme", ("durable-medical-equipment", "durable medical equipment", "-dme",
             "durablemedical", "durable-medical")),
    ("outpatient", ("outpatient",)),
    ("practitioner", ("practitioner",)),
]
SERVICES = tuple(s for s, _ in SERVICE_KEYWORDS)

# Output column names = the names in SB's hand-loaded tables (exact-match in ingest._find_col).
# A key matches as a substring of the normalised header; a key starting with '=' must equal the
# WHOLE normalised header (C2-24).
PTP_COLUMNS = {
    "QuarterBeginDate": ("quarterbegin",),
    "Category": ("category",),
    "Col1": ("column1", "columnone", "col1", "comprehensive"),
    "Col2": ("column2", "columntwo", "col2", "component"),
    "PriorTo1996Flag": ("1996",),                      # Medicare layout only; kept if present
    "EffDt": ("effective",),
    "DelDt": ("deletion",),
    "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable": ("modifier",),
    "PTP_Edit_Rationale": ("rationale",),
}
PTP_REQUIRED = ("Col1", "Col2", "EffDt", "DelDt",
                "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable")

MUE_COLUMNS = {
    "QuarterBeginDate": ("quarterbegin",),
    "Category": ("category",),
    "HCPCS_CPT_Code": ("hcpcs", "cptcode"),
    "MUE_Values": ("muevalue",),
    # C2-24: exact names only. As substrings, 'mai' matched 'Remaining Notes' / 'Maintenance' and
    # 'adjudication' matched any adjudication note, so the MAI was read from an unrelated column.
    "MUE_Adjudication_Indicator": ("=mueadjudicationindicator", "=mai",
                                   "=adjudicationindicator", "=mueadjudicationindicatormai"),
    "MUE_Rationale": ("rationale",),
}
MUE_REQUIRED = ("HCPCS_CPT_Code", "MUE_Values")

PROVENANCE_COLUMNS = ["src_zip", "src_sha256", "src_member", "src_url", "loaded_at"]

CODE_RE = re.compile(r"^[A-Z0-9]{5}$")                 # CPT / HCPCS Level II
MAX_NON_DATA_ROWS = 50                                  # preamble/footer lines tolerated

# C2-18: free text CMS puts around the data (AMA notice, titles, notes). A body row with NO valid
# code is skipped only when its code cells are blank (and it carries no edit data), when it repeats
# the header, or when it is a short free-text line (<= 2 non-blank cells) matching one of these.
# Anything else raises. Add a pattern only for text actually seen in a CMS file.
FOOTER_PATTERNS = (
    r"copyright", r"american medical association", r"all rights reserved", r"cpt codes?,? descriptions",
    r"dfars", r"current dental terminology", r"^\s*notes?\s*:", r"^\s*end of (file|report)",
    r"^\s*page \d+", r"^\s*total\b", r"^\s*medicaid ncci", r"^\s*\*\s*=",
)
FOOTER_RE = re.compile("|".join(f"(?:{p})" for p in FOOTER_PATTERNS), re.I)

# Statuses of an acquisition-log row. Only LOADED_STATUSES mean "this table now holds this file".
LOADED_STATUSES = ("loaded", "replaced")
CATEGORY_CHECK_MODES = ("strict", "lenient")


class ParseError(ValueError):
    """The file is not in the layout this module was built for. Never guess past it."""


class DownloadError(RuntimeError):
    """The file could not be fetched, or what came back is not a zip."""


class ConflictError(ValueError):
    """Two sources claim the same table, or a revision cannot be applied safely. Never resolved by guessing."""


class DuplicateLinkError(ConflictError):
    """C2-15: two different files classify as the same (edit, service, quarter, revision)."""


# ------------------------------------------------------------------ discovery
@dataclass
class Link:
    url: str
    text: str
    kind: str                     # "edits" | "change_report" | "unknown"
    edit: str | None = None       # "ptp" | "mue"
    service: str | None = None    # "practitioner" | "outpatient" | "dme"
    year: int | None = None
    quarter: int | None = None
    revision: int = 0             # C2-15: 0 = original, 1 = "...-r1-..." re-issue, ...
    note: str | None = None       # why it is unclassified, or a link text that contradicts the name

    @property
    def label(self) -> str:
        return f"{self.year}q{self.quarter}" if self.year else "unknown"

    @property
    def table(self) -> str | None:
        if self.kind != "edits":
            return None
        return TABLE_TEMPLATE.format(service=self.service, edit=self.edit,
                                     quarter=self.quarter, year=self.year)

    @property
    def name(self) -> str:
        return _basename(self.url)


_HREF_RE = re.compile(r"""<a\b[^>]*?href\s*=\s*["']([^"']+?\.zip)["'][^>]*>(.*?)</a>""", re.I | re.S)
# C2-15: the four quarter spellings in real CMS file names (see the module docstring).
_YQ_RE = re.compile(r"(?<!\d)(20\d{2})[\s_-]*q([1-4])(?!\d)", re.I)          # 2026-q4, 2025q2, 2023q1
_QY_RE = re.compile(r"(?<![a-z0-9])q([1-4])[\s_-]*(20\d{2})(?!\d)", re.I)     # q2-2026
_EFF_RE = re.compile(r"effective[\s_-]*(\d{2})(\d{2})(20\d{2})(?!\d)", re.I)  # effective10012022
_REV_RE = re.compile(r"(?<![a-z0-9])r(\d{1,2})(?![a-z0-9])", re.I)           # 2025-q1-r1-...


def _basename(url_or_path: str) -> str:
    return os.path.basename(str(url_or_path).split("?", 1)[0].split("#", 1)[0].rstrip("/"))


def _services_named(text) -> set[str]:
    """Editions a piece of text names: file name, Category value or column header. A set, so a
    text naming two editions is visibly ambiguous instead of 'first keyword wins'."""
    s = str(text).lower()
    n = re.sub(r"[^a-z0-9]", "", s)
    words = set(re.findall(r"[a-z]+", s))
    out = set()
    # 'dme' must start a word ('-dme', 'dmeservices', 'DME Supplier'); 'amendment' must not count
    if "durablemedical" in n or re.search(r"(?<![a-z])dme", s):
        out.add("dme")
    if "outpatient" in n or "oph" in words:            # OPH / PRA: the change-report abbreviations
        out.add("outpatient")
    if "practitioner" in n or "pra" in words:
        out.add("practitioner")
    return out


def _edits_named(text) -> set[str]:
    n = re.sub(r"[^a-z0-9]", "", str(text).lower())
    out = set()
    if "ptp" in n or "proceduretoprocedure" in n:
        out.add("ptp")
    if "mue" in n or "medicallyunlikely" in n:
        out.add("mue")
    return out


def _quarters_named(text) -> set[tuple[int, int]]:
    s = str(text)
    return ({(int(y), int(q)) for y, q in _YQ_RE.findall(s)}
            | {(int(y), int(q)) for q, y in _QY_RE.findall(s)})


def classify_name(name: str) -> dict:
    """What a CMS zip FILE NAME says. C2-16: only the basename is read - never a folder name (a drop
    zone under '.../outpatient_project/...' turned a practitioner file into 'outpatient'), never
    link text (the MUE archive's link text is a posting date: 'Effective Sep. 2, 2025' is the 2025Q4
    file). Returns edit, service, year, quarter, revision, change_report and 'problems' (why the
    name cannot be classified; empty when it can)."""
    base = _basename(name)
    stem = base[:-4] if base.lower().endswith(".zip") else base
    low = stem.lower()
    norm = re.sub(r"[^a-z0-9]", "", low)
    problems: list[str] = []
    change_report = "changereport" in norm
    quarters = _quarters_named(low)
    for mm, dd, yy in _EFF_RE.findall(low):
        try:
            d = date(int(yy), int(mm), int(dd))
        except ValueError:
            problems.append(f"invalid effective date '{mm}{dd}{yy}'")
            continue
        q = (d.month - 1) // 3 + 1
        if (d.month, d.day) != QUARTER_START[q] and not change_report:
            # an edit file 'effective' mid-quarter cannot be placed in a quarter table safely
            problems.append(f"effective date {d.isoformat()} is not a quarter start")
        quarters.add((d.year, q))
    if len(quarters) > 1:
        problems.append(f"names more than one quarter {sorted(quarters)}")
    revs = {int(r) for r in _REV_RE.findall(low)}
    if len(revs) > 1:
        problems.append(f"more than one revision marker {sorted(revs)}")
    edits, services = _edits_named(low), _services_named(low)
    if not change_report:
        if len(edits) != 1:
            problems.append("no PTP/MUE marker" if not edits else "names both PTP and MUE")
        if len(services) != 1:
            problems.append("no edition (practitioner / outpatient / DME)" if not services
                            else f"names several editions {sorted(services)}")
        if not quarters:
            problems.append("no year/quarter")
    y, q = next(iter(quarters)) if len(quarters) == 1 else (None, None)
    return {"name": base, "edit": next(iter(edits)) if len(edits) == 1 else None,
            "service": next(iter(services)) if len(services) == 1 else None,
            "year": y, "quarter": q, "revision": max(revs) if len(revs) == 1 else 0,
            "change_report": change_report, "problems": problems}


def file_revision(name) -> int | None:
    """Revision number in a CMS file name (0 = original); None when there is no usable name."""
    if not name or not str(name).strip() or str(name).strip().lower() in ("none", "nan"):
        return None
    return classify_name(str(name))["revision"]


def _text_contradiction(a: dict, text: str) -> str | None:
    """Link text that names a DIFFERENT edit/edition/quarter than the file name (display only;
    the file name decides and the content check in parse_zip has the last word)."""
    t = re.sub(r"<[^>]+>", " ", unescape(text or ""))
    said = []
    ed, sv, qs = _edits_named(t), _services_named(t), _quarters_named(t)
    if len(ed) == 1 and a["edit"] and ed != {a["edit"]}:
        said.append(f"edit {next(iter(ed))}")
    if len(sv) == 1 and a["service"] and sv != {a["service"]}:
        said.append(f"edition {next(iter(sv))}")
    if len(qs) == 1 and a["year"] and qs != {(a["year"], a["quarter"])}:
        y, q = next(iter(qs))
        said.append(f"quarter {y}q{q}")
    if not said:
        return None
    return (f"link text says {', '.join(said)} but the file name says {a['edit']}/{a['service']} "
            f"{a['year']}q{a['quarter']} - classified by the file name")


def _classify(url: str, text: str) -> Link:
    a = classify_name(url)
    link = Link(url=url, text=re.sub(r"\s+", " ", unescape(re.sub(r"<[^>]+>", " ", text))).strip(),
                kind="unknown", revision=a["revision"])
    if a["year"]:
        link.year, link.quarter = a["year"], a["quarter"]
    if a["change_report"]:
        link.kind = "change_report"
        link.note = "; ".join(a["problems"]) or None
        return link
    if a["problems"]:
        link.note = f"unclassifiable file name {a['name']!r}: " + "; ".join(a["problems"])
        return link
    link.kind, link.edit, link.service = "edits", a["edit"], a["service"]
    link.note = _text_contradiction(a, text)
    return link


def discover_links(html: str, base: str = CMS_PAGE) -> list[Link]:
    """Every .zip link on the page, classified. Unclassifiable links are returned with
    kind='unknown' so the caller REPORTS them (a new CMS naming scheme must be seen).
    The same file linked twice (same file name, e.g. under two headings) is listed once."""
    seen, out = set(), []
    for href, text in _HREF_RE.findall(html):
        url = urljoin(base, unescape(href.strip()))
        key = _basename(url).lower()
        if url in seen or key in seen:
            continue
        seen.update((url, key))
        out.append(_classify(url, text))
    return out


def duplicate_links(links: list[Link]) -> dict[str, list[str]]:
    """C2-15: {'2025q2 mue/practitioner r0': [file names]} for every (quarter, edit, edition, revision)
    that more than one DIFFERENT file claims. An original plus its '-r1-' re-issue is not a
    duplicate (the higher revision wins, see plan_loads); two files with the same revision are."""
    groups: dict[tuple, list[str]] = {}
    for l in links:
        if l.kind == "edits":
            groups.setdefault((l.label, l.edit, l.service, l.revision), []).append(l.url)
    return {f"{q} {e}/{s} r{r}": sorted(set(u)) for (q, e, s, r), u in sorted(groups.items())
            if len(set(u)) > 1}


def check_quarter_complete(links: list[Link], allow_duplicates: bool = False) -> dict[str, list[str]]:
    """{'2026q4': [missing 'ptp/dme', ...]} - a quarter should have all 6 edit files.
    C2-15: two different files for the same (edit, edition, quarter, revision) is an ERROR
    (DuplicateLinkError) - nothing can tell which one is right. allow_duplicates=True only skips
    the raise so the caller can still report the missing files (acquire() fails the duplicates)."""
    dups = duplicate_links(links)
    if dups and not allow_duplicates:
        raise DuplicateLinkError("duplicate NCCI edit files (keep exactly one per quarter/edit/edition/"
                                 f"revision): {dups}")
    want = {(e, s) for e in ("ptp", "mue") for s in SERVICES}
    have: dict[str, set] = {}
    for l in links:
        if l.kind == "edits":
            have.setdefault(l.label, set()).add((l.edit, l.service))
    return {q: sorted(f"{e}/{s}" for e, s in want - got) for q, got in have.items() if want - got}


def plan_loads(links: list[Link]) -> dict[str, tuple[str, str | None]]:
    """{url: (action, why)} for every edit link; action 'load' | 'superseded' | 'duplicate'.
    C2-15: per (quarter, edit, edition) only the HIGHEST revision is loaded; lower revisions are
    archived and logged 'superseded' (they used to load first and leave the revision
    'skipped_exists'). Two files at the highest revision -> both 'duplicate' (failed), and the
    lower ones are not loaded either - loading a known-superseded file would be worse."""
    groups: dict[tuple, list[Link]] = {}
    for l in links:
        if l.kind == "edits":
            groups.setdefault((l.label, l.edit, l.service), []).append(l)
    plan: dict[str, tuple[str, str | None]] = {}
    for (q, e, s), group in groups.items():
        top = max(l.revision for l in group)
        tops = [l for l in group if l.revision == top]
        top_names = sorted({l.name for l in tops})
        for l in group:
            if l.revision == top and len({x.url for x in tops}) > 1:
                plan[l.url] = ("duplicate", f"{q} {e}/{s} r{top} is claimed by {len(tops)} files "
                                            f"{sorted(x.url for x in tops)}; keep exactly one")
            elif l.revision < top:
                why = (f"superseded by revision r{top} ({tops[0].name})" if len(tops) == 1
                       else f"superseded by revision r{top}, which is duplicated ({top_names}) - nothing loaded")
                plan[l.url] = ("superseded", why)
            else:
                plan[l.url] = ("load", None)
    return plan


# ------------------------------------------------------------------- network
def make_session():
    import requests
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT})
    return s


def _get(session, url: str, timeout: int = 120, attempts: int = 4, backoff: float = 2.0,
         sleep=time.sleep):
    """GET with bounded retries on TRANSIENT failures only. Returns the response."""
    last = None
    for i in range(attempts):
        try:
            r = session.get(url, timeout=timeout)
        except Exception as e:                            # connection reset, DNS, timeout
            last = f"{type(e).__name__}: {e}"
        else:
            if r.status_code == 200:
                return r
            if r.status_code not in (429, 500, 502, 503, 504):
                raise DownloadError(f"GET {url} -> HTTP {r.status_code} (not retried: "
                                    f"{'blocked by egress/WAF' if r.status_code == 403 else 'not transient'})")
            last = f"HTTP {r.status_code}"
        if i < attempts - 1:
            sleep(backoff * (2 ** i))
    raise DownloadError(f"GET {url} failed after {attempts} attempts; last error: {last}")


def probe_egress(session=None, url: str = CMS_PAGE) -> tuple[bool, str]:
    """(ok, detail). Run first: most locked-down clusters fail here, not later."""
    try:
        r = _get(session or make_session(), url, timeout=30, attempts=1)
        return True, f"HTTP 200, {len(r.content):,} bytes"
    except Exception as e:
        return False, str(e)[:400]


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def archive_path(raw_dir: str, link: Link) -> str:
    return os.path.join(raw_dir, link.label, os.path.basename(link.url))


def download(link: Link, raw_dir: str, session=None, force: bool = False) -> dict:
    """Fetch one zip into the archive. Idempotent: an archived file is reused, not refetched."""
    dest = archive_path(raw_dir, link)
    if os.path.exists(dest) and not force:
        _assert_zip(dest)
        return {"path": dest, "sha256": sha256_file(dest), "bytes": os.path.getsize(dest), "status": "archived"}
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    r = _get(session or make_session(), link.url)
    data = r.content
    if not data.startswith(b"PK"):
        head = data[:120].decode("latin-1", "replace").replace("\n", " ")
        raise DownloadError(f"{link.url} did not return a zip (got {len(data):,} bytes starting {head!r}) - "
                            f"usually a WAF/interstitial page; download it by hand into {os.path.dirname(dest)}")
    tmp = dest + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, dest)                                  # never leave a half-written zip under the real name
    return {"path": dest, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "status": "downloaded"}


def _assert_zip(path: str):
    with open(path, "rb") as f:
        if f.read(2) != b"PK":
            raise DownloadError(f"{path} is not a zip (an HTML error page saved as .zip?) - delete it and refetch")


def links_from_drop_zone(raw_dir: str) -> list[Link]:
    """No egress? Download the zips by hand into <raw_dir>/<anything>/ (or raw_dir itself).
    File names carry year/quarter/edit/service, so they classify exactly like page links.
    C2-16: only the FILE NAME is classified; the folders it sits in are ignored."""
    out = []
    for root, _, files in os.walk(raw_dir):
        for fn in sorted(files):
            if fn.lower().endswith(".zip"):
                out.append(_classify(os.path.join(root, fn), fn))
    return out


# -------------------------------------------------------------------- parsing
def _norm(s) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def _key_hit(key: str, normalised: str) -> bool:
    # C2-24: '=name' must equal the whole normalised header; other keys match as substrings
    return normalised == key[1:] if key.startswith("=") else key in normalised


def _map_header(cells: list, spec: dict) -> dict[int, str]:
    """{position: canonical name}. Unknown headers keep a sanitized name (as-delivered)."""
    out, used = {}, set()
    for i, raw in enumerate(cells):
        n = _norm(raw)
        if not n:
            continue
        canon = next((c for c, keys in spec.items() if c not in used and any(_key_hit(k, n) for k in keys)), None)
        if canon is None:
            canon = re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")[:60] or f"col_{i}"
        used.add(canon)
        out[i] = canon
    return out


def _merge_rows(row: list, nxt: list) -> list[str]:
    width = max(len(row), len(nxt))
    return [f"{row[j] if j < len(row) else ''} {nxt[j] if j < len(nxt) else ''}" for j in range(width)]


def _find_header(rows: list[list], spec: dict, required: tuple, scan: int = 60) -> tuple[int, dict, int]:
    """Locate the header row (optionally continued on the next row, as CMS Excel headers often are).
    Returns (row index, {pos: canonical}, header height)."""
    for i, row in enumerate(rows[:scan]):
        for height in (1, 2):
            if i + height > len(rows):
                continue
            cells = row if height == 1 else _merge_rows(row, rows[i + 1])
            mapping = _map_header(cells, spec)
            if all(r in mapping.values() for r in required):
                return i, mapping, height
    raise ParseError(f"no header row with {list(required)} in the first {scan} rows; "
                     f"first rows seen: {[r[:6] for r in rows[:5]]}")


def _header_cells(rows: list[list], hi: int, height: int) -> list[str]:
    cells = rows[hi] if height == 1 else _merge_rows(rows[hi], rows[hi + 1])
    return [re.sub(r"\s+", " ", str(c)).strip() for c in cells]


class _Rows(list):
    """Parsed rows; for a text file also which PHYSICAL lines were non-blank (C2-17 invariant)."""
    line_nonblank: list | None = None


def _split_lines(txt: str) -> list[str]:
    # Only CR/LF end a record. str.splitlines() also splits on \x0b, \x0c, \x1c-\x1e, \x85 (NEL - a
    # latin-1-decoded cp1252 ellipsis) and U+2028/9, which would cut one edit line in two.
    lines = re.split(r"\r\n|\n|\r", txt)
    if lines and lines[-1] == "":
        lines.pop()
    return lines


def _unquote(cell: str) -> str:
    """QUOTE_NONE keeps quote characters literally. A cell wholly wrapped in double quotes is
    unwrapped (and "" -> "); a cell that merely STARTS with a quote is kept as is."""
    s = cell.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        return s[1:-1].replace('""', '"')
    return cell


def _text_rows(data: bytes) -> list[list[str]]:
    try:
        txt = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        txt = data.decode("latin-1")
    lines = _split_lines(txt)
    sample = [l for l in lines[:80] if l.strip()]
    delim = None
    for d in ("\t", "|", ","):                               # CMS text files: tab first
        # >= 2 delimiters = >= 3 columns: a Medicaid MUE file can be just 'HCPCS/CPT Code', '<edition> MUE
        # Values', 'MUE Rationale' (the hand-loaded tables' layout); the old '>= 3' refused that file.
        n = sum(l.count(d) >= 2 for l in sample)
        if n >= 3 or (n >= 2 and n == len(sample)):
            delim = d
            break
    if delim is None:
        raise ParseError("could not detect a delimiter (tab, pipe, comma) in the text file")
    rows = _Rows()
    if delim == ",":
        # C2-17: a comma file needs CSV quoting (commas inside a field), but each physical line is
        # parsed ON ITS OWN, so an unbalanced quote ends with its line instead of eating the next ones.
        for line in lines:
            rows.append(next(csv.reader([line], delimiter=","), []))
    else:
        # C2-17: tab/pipe text has no quoting convention. With csv's default quotechar ONE field that
        # began with a double quote swallowed every following line into a single field (repro: 10
        # edit lines -> 1 row, no warning). QUOTE_NONE: one physical line = one row, always.
        for line, r in zip(lines, csv.reader(lines, delimiter=delim, quoting=csv.QUOTE_NONE)):
            rows.append([_unquote(c) for c in r] if '"' in line else r)
    if len(rows) != len(lines):
        raise ParseError(f"text parse produced {len(rows):,} rows from {len(lines):,} lines")
    rows.line_nonblank = [bool(l.strip()) for l in lines]
    return rows


def _xlsx_rows(data: bytes) -> list[list]:
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    rows = []
    for ws in wb.worksheets:
        for r in ws.iter_rows(values_only=True):
            rows.append(["" if v is None else v for v in r])
    wb.close()
    return rows


def _to_yyyymmdd(v) -> int | None:
    """CMS dates: 20250101 / 20250101.0 / 1/1/2025 / 2025-01-01 / Excel datetime. '*' or blank = none."""
    if v is None:
        return None
    if isinstance(v, (datetime, date)):
        return v.year * 10000 + v.month * 100 + v.day
    s = str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    if s in ("", "*", "nan", "NaT", "None"):
        return None
    if re.fullmatch(r"\d{8}", s):
        int(datetime.strptime(s, "%Y%m%d").strftime("%Y%m%d"))   # validates the calendar date
        return int(s)
    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%y"):
        try:
            d = datetime.strptime(s, fmt)
            return d.year * 10000 + d.month * 100 + d.day
        except ValueError:
            pass
    raise ValueError(s)


def _code(v) -> str:
    """Excel stores 01996 as the number 1996; a text file keeps the string."""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, int) or (isinstance(v, float) and v == v and v.is_integer()):
        return str(int(v)).zfill(5)
    return str(v).strip().upper()


def _dates_to_int(s: pd.Series) -> tuple[pd.Series, list]:
    """Vectorised fast path for yyyymmdd (the bulk of CMS rows); per-value fallback for the rest."""
    txt = s.map(lambda v: "" if v is None else (v.strftime("%Y%m%d") if isinstance(v, (datetime, date)) else str(v)))
    txt = txt.str.strip().str.replace(r"\.0$", "", regex=True)
    out = pd.Series(pd.NA, index=s.index, dtype="Int64")
    blank = txt.isin(["", "*", "nan", "NaT", "None"])
    ymd = txt.str.fullmatch(r"\d{8}")
    ok = ymd & pd.to_datetime(txt.where(ymd), format="%Y%m%d", errors="coerce").notna()
    out[ok] = txt[ok].astype("int64")
    errs = []
    for i in txt.index[~ok & ~blank]:
        try:
            out[i] = _to_yyyymmdd(txt[i])
        except ValueError:
            errs.append(txt[i])
    return out, errs[:5] + ([f"({len(errs)} rows)"] if errs else [])


_MOD_COL = "ModifierIndicator_0_not_allowed_1_allowed_9_not_applicable"
# C2-18: columns that carry EDIT DATA. A row with blank codes but parseable data here is a malformed
# edit, not a footer (a header continuation row such as 'Date' / '0=not allowed ...' does not parse).
_DATA_BEARING = {"ptp": ("QuarterBeginDate", "EffDt", "DelDt", _MOD_COL), "mue": ("QuarterBeginDate", "MUE_Values")}


def _is_edit_data(col: str, v) -> bool:
    s = "" if v is None else str(v).strip()
    if not s:
        return False
    if col == _MOD_COL:
        return s in ("0", "1", "9", "0.0", "1.0", "9.0")
    if col == "MUE_Values":
        return re.fullmatch(r"\d+(\.0+)?", s) is not None
    if col == "DelDt" and s == "*":
        return True
    try:
        return _to_yyyymmdd(v) is not None
    except ValueError:
        return False


def _repeat_of_header(body: list, k: int, spec: dict, required: tuple, is_data) -> tuple[dict, int] | None:
    """(mapping, height) when body[k] (optionally continued on body[k+1]) is another header row."""
    for height in (1, 2):
        if k + height > len(body):
            continue
        if height == 2 and (bool(is_data.iloc[k + 1])                     # never merge a header with a data row,
                            or all(r in _map_header(body[k + 1], spec).values() for r in required)):
            continue                                      # nor a note line with a header that stands alone
        cells = body[k] if height == 1 else _merge_rows(body[k], body[k + 1])
        m = _map_header(cells, spec)
        if all(r in m.values() for r in required):
            return m, height
    return None


def _cells(row) -> list[str]:
    return ["" if v is None else str(v).strip() for v in row]


def frame_from_rows(rows: list[list], edit: str) -> tuple[pd.DataFrame, dict]:
    """Rows of one member file -> canonical frame + parse stats. Raises ParseError on anything off.

    C2-18: every non-blank body row is exactly one of
      * data      - every code column holds a 5-char CPT/HCPCS code;
      * tolerated - (a) code cells all blank and no edit data on the row (footer / notes /
                    header-continuation line), (b) a repeat of the header (sheet boundary), or
                    (c) a short free-text line (<= 2 non-blank cells) matching FOOTER_PATTERNS;
      * an ERROR  - one code valid and the other not (e.g. a blank Column Two), edit data with blank
                    codes, or any other text in a code column. The old rule dropped up to 50 such rows
                    per member with only a warning.
    C2-17 invariant: data rows == non-blank lines after the header - tolerated rows, or ParseError.
    """
    spec, required = (PTP_COLUMNS, PTP_REQUIRED) if edit == "ptp" else (MUE_COLUMNS, MUE_REQUIRED)
    hi, mapping, height = _find_header(rows, spec, required)
    header_cells = _header_cells(rows, hi, height)
    body = rows[hi + height:]
    pos = sorted(mapping)
    cols = [mapping[i] for i in pos]
    raw = pd.DataFrame(body) if body else pd.DataFrame()
    df = pd.DataFrame({mapping[i]: (raw[i] if i in raw.columns else "") for i in pos}, columns=cols)
    df = df.fillna("")

    code_cols = ["Col1", "Col2"] if edit == "ptp" else ["HCPCS_CPT_Code"]
    for c in code_cols:
        df[c] = df[c].map(_code)
    valid = pd.DataFrame({c: df[c].astype(str).str.fullmatch(CODE_RE.pattern).fillna(False).astype(bool)
                          for c in code_cols}, index=df.index)
    is_data = valid.all(axis=1) if len(df) else pd.Series(dtype=bool)
    partial = valid.any(axis=1) & ~is_data if len(df) else pd.Series(dtype=bool)
    if partial.any():
        ex = df.loc[partial, code_cols].head(5).values.tolist()
        raise ParseError(f"{int(partial.sum()):,} rows have one valid code column and one that is not a 5-char "
                         f"CPT/HCPCS code - malformed edits, not loaded and not skipped (C2-18); "
                         f"examples {code_cols}: {ex}")

    tolerated = {"blank_code_cells": 0, "header_repeat": 0, "footer_text": 0}
    tol_examples: list = []
    bad: list = []
    no_codes: list = []
    data_bearing = [c for c in _DATA_BEARING[edit] if c in df.columns]
    skip_until = -1
    for k in df.index[~is_data] if len(df) else []:
        if k < skip_until:
            continue
        cells = _cells(body[k])
        nonblank = [c for c in cells if c]
        if not nonblank:
            continue                                      # blank line
        rep = _repeat_of_header(body, k, spec, required, is_data)
        if rep is not None:
            m, h = rep
            if m != mapping:
                raise ParseError(f"body row {hi + height + k + 1}: a second header with a DIFFERENT column layout "
                                 f"({[m[i] for i in sorted(m)]} vs {cols}); refusing to guess column positions")
            n = sum(1 for j in range(k, k + h) if any(_cells(body[j])))
            tolerated["header_repeat"] += n
            skip_until = k + h
            continue
        if all(df.at[k, c] == "" for c in code_cols):
            if any(_is_edit_data(c, df.at[k, c]) for c in data_bearing):
                no_codes.append(nonblank[:6])
            else:
                tolerated["blank_code_cells"] += 1
                if len(tol_examples) < 3:
                    tol_examples.append(nonblank[:3])
            continue
        if len(nonblank) <= 2 and FOOTER_RE.search(" ".join(nonblank)):
            tolerated["footer_text"] += 1
            if len(tol_examples) < 3:
                tol_examples.append(nonblank[:3])
            continue
        bad.append([df.at[k, c] for c in code_cols])
    if no_codes:
        raise ParseError(f"{len(no_codes):,} rows carry edit data (dates / indicator / value) but no codes - "
                         f"malformed edits (C2-18); examples: {no_codes[:3]}")
    if bad:
        raise ParseError(f"{len(bad):,} body rows have a code column that is not a 5-char CPT/HCPCS code and are "
                         f"not blank, footer or header lines (C2-18); examples {code_cols}: {bad[:3]}. If this is "
                         f"a CMS note line, add its text to acquire_ncci.FOOTER_PATTERNS")
    n_tol = sum(tolerated.values())
    # blank lines and footers are fine; a body full of non-codes means a misread layout
    if n_tol > MAX_NON_DATA_ROWS:
        raise ParseError(f"{n_tol:,} non-data body rows ({tolerated}) - more than {MAX_NON_DATA_ROWS}; the layout "
                         f"is probably misread (rows whose code column is not a 5-char CPT/HCPCS code); "
                         f"examples: {tol_examples}")
    # C2-17 invariant, counted from the PHYSICAL lines for a text file (independent of the csv parse)
    if getattr(rows, "line_nonblank", None) is not None:
        n_lines = sum(rows.line_nonblank[hi + height:])
    else:
        n_lines = sum(1 for r in body if any(_cells(r)))
    n_data = int(is_data.sum()) if len(df) else 0
    if n_data != n_lines - n_tol:
        raise ParseError(f"row accounting failed: {n_lines:,} non-blank lines after the header, {n_tol:,} "
                         f"tolerated, but {n_data:,} data rows - a quote or delimiter problem merged or split "
                         f"lines (C2-17)")
    # text outside the header's named columns is ignored - say so (an extra tab can shift a row)
    outside = [c for c in raw.columns if c not in mapping] if len(raw) else []
    wide = 0
    if outside:
        ext = raw.loc[is_data[is_data].index, outside].fillna("").astype(str)
        wide = int((ext.apply(lambda s: s.str.strip()) != "").any(axis=1).sum())
    df = df[is_data].reset_index(drop=True) if len(df) else df
    if df.empty:
        raise ParseError("header found but no data rows")

    bad_vals: dict[str, list] = {}
    date_cols = [c for c in ("QuarterBeginDate", "EffDt", "DelDt") if c in df.columns]
    for c in date_cols:
        df[c], errs = _dates_to_int(df[c])
        if errs:
            bad_vals[c] = errs
    if edit == "ptp":
        if df["EffDt"].isna().any():
            bad_vals.setdefault("EffDt", []).append(f"{int(df['EffDt'].isna().sum())} blank effective dates")
        mc = _MOD_COL
        df[mc] = df[mc].map(lambda v: str(v).strip()[:1] if str(v).strip() else "")
        badm = df.loc[~df[mc].isin(["0", "1", "9"]), mc]
        if len(badm):
            bad_vals[mc] = badm.head(5).tolist() + [f"({len(badm)} rows)"]
    else:
        vals = pd.to_numeric(df["MUE_Values"].map(lambda v: str(v).strip()), errors="coerce")
        badv = df.loc[vals.isna() | (vals < 0) | (vals % 1 != 0), "MUE_Values"]
        if len(badv):
            bad_vals["MUE_Values"] = badv.head(5).tolist() + [f"({len(badv)} rows)"]
        df["MUE_Values"] = vals.astype("Int64")
    if bad_vals:
        raise ParseError(f"unparseable values (not dropped, fix or report): { {k: v[:6] for k, v in bad_vals.items()} }")

    for c in df.columns:
        if c not in date_cols and c != "MUE_Values":
            df[c] = df[c].map(lambda v: None if v is None or str(v).strip() == "" else str(v).strip())
    stats = {"header_row": hi, "header_height": height, "rows": len(df),
             "non_data_rows_skipped": n_tol, "non_data_examples": tol_examples,
             "tolerated": tolerated, "nonblank_lines_after_header": n_lines, "rows_with_text_outside_header": wide,
             "raw_headers": {mapping[i]: header_cells[i] for i in pos if i < len(header_cells)},
             "columns": cols}
    return df, stats


def check_edition(df: pd.DataFrame, members: list[dict], service: str, mode: str = "strict",
                  name: str = "") -> tuple[str | None, list[str]]:
    """C2-16: the file's own content must agree with the edition its NAME claims. Evidence read: the
    Category column values and an edition-named MUE value header ('Practitioner Services MUE
    Values'). A value naming ANOTHER edition is refused in every mode; a value naming no known edition
    is refused in 'strict' (default) and only warned about in 'lenient'. Returns (evidence, warnings)."""
    if mode not in CATEGORY_CHECK_MODES:
        raise ValueError(f"category_check must be one of {CATEGORY_CHECK_MODES}, got {mode!r}")
    evidence, warnings, problems = [], [], []
    if "Category" in df.columns:
        vals = sorted({str(v).strip() for v in df["Category"].dropna().unique() if str(v).strip()})
        for v in vals:
            named = _services_named(v)
            if named == {service}:
                continue
            if named:
                problems.append(f"Category {v!r} is the {'/'.join(sorted(named))} edition")
            elif mode == "strict":
                problems.append(f"Category {v!r} is not a known spelling of the {service} edition "
                                f"(category_check='lenient' loads it on the file name, with a warning)")
            else:
                warnings.append(f"Category {v!r} not recognised as an edition; loaded on the file name (lenient)")
        if vals:
            evidence.append(f"Category={vals}")
    for m in members:
        h = (m.get("raw_headers") or {}).get("MUE_Values")
        named = _services_named(h) if h else set()
        if named and named != {service}:
            problems.append(f"{m.get('member')}: value column {h!r} is the {'/'.join(sorted(named))} edition")
        elif named:
            evidence.append(f"header={h!r}")
    if problems:
        raise ParseError(f"{name}: the file name says the {service} edition but the file content disagrees: "
                         f"{problems[:5]}. Not loaded (C2-16) - the CMS MUE archive has linked one edition's "
                         f"zip under another edition's heading before; fetch the right file.")
    if not evidence:
        warnings.append(f"edition '{service}' taken from the file name only (no Category column or "
                        f"edition-named header to confirm it)")
    return "; ".join(dict.fromkeys(evidence)) or None, warnings


def parse_zip(path: str, edit: str, expected_quarter: tuple[int, int] | None = None,
              prefer: str = "txt", cross_check_xlsx: bool = False,
              expected_service: str | None = None, category_check: str = "strict") -> tuple[pd.DataFrame, dict]:
    """All member files of the preferred format, concatenated. Excel is the fallback (and the
    optional cross-check: same row count from both formats = the text parse is complete).
    expected_service: the edition the file NAME claims; the content must agree (C2-16)."""
    _assert_zip(path)
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if not n.endswith("/") and not os.path.basename(n).startswith(("~", "."))]
        txt = sorted(n for n in names if n.lower().endswith((".txt", ".csv")))
        xls = sorted(n for n in names if n.lower().endswith(".xlsx"))
        order = [("txt", txt), ("xlsx", xls)] if prefer == "txt" else [("xlsx", xls), ("txt", txt)]
        fmt, members = next(((f, m) for f, m in order if m), (None, []))
        if not members:
            raise ParseError(f"{os.path.basename(path)}: no .txt/.csv/.xlsx inside; members: {names}")
        frames, per_member = [], []
        for n in members:
            rows = _text_rows(z.read(n)) if fmt == "txt" else _xlsx_rows(z.read(n))
            try:
                df, st = frame_from_rows(rows, edit)
            except ParseError as e:
                raise ParseError(f"{os.path.basename(path)}::{n}: {e}") from None
            df["src_member"] = n
            frames.append(df)
            per_member.append({"member": n, **st})
        df = pd.concat(frames, ignore_index=True)
        stats = {"format": fmt, "members": per_member, "rows": len(df)}
        if cross_check_xlsx and fmt == "txt" and xls:
            n_x = sum(frame_from_rows(_xlsx_rows(z.read(n)), edit)[0].shape[0] for n in xls)
            stats["xlsx_rows"] = n_x
            if n_x != len(df):
                raise ParseError(f"{os.path.basename(path)}: text has {len(df):,} rows, Excel has {n_x:,}")

    if expected_quarter and "QuarterBeginDate" in df.columns:
        y, q = expected_quarter
        mo, d = QUARTER_START[q]
        want = y * 10000 + mo * 100 + d
        got = sorted({int(v) for v in df["QuarterBeginDate"].dropna().unique()})
        if got and got != [want]:
            raise ParseError(f"{os.path.basename(path)}: Quarter Begin Date {got} but the link says {y}Q{q} ({want})")
    if expected_service:
        stats["edition_evidence"], stats["edition_warnings"] = check_edition(
            df, per_member, expected_service, category_check, os.path.basename(path))
    return df, stats


# ------------------------------------------------------------------- checks
def compare_to_previous(new_rows: int, prev_rows: int | None, max_drop: float = 0.20) -> str | None:
    """A quarter that loses >20% of rows vs the previous one is almost always a partial parse."""
    if prev_rows and new_rows < prev_rows * (1 - max_drop):
        return f"row count fell {prev_rows:,} -> {new_rows:,} ({1 - new_rows / prev_rows:.0%}); check before trusting"
    return None


def current_quarter(today: date | None = None) -> tuple[int, int]:
    t = today or date.today()
    return t.year, (t.month - 1) // 3 + 1


def quarter_end(year: int, quarter: int) -> date:
    """Last day of a calendar quarter (C2-14: claims after it are judged by a carried-forward table)."""
    nxt = date(year + 1, 1, 1) if quarter == 4 else date(year, QUARTER_START[quarter + 1][0], 1)
    return nxt - timedelta(days=1)


def missing_quarters(loaded: list[tuple[int, int]], today: date | None = None) -> list[str]:
    """Quarters between the earliest loaded and the current one that have no table."""
    if not loaded:
        return []
    y, q = min(loaded)
    cy, cq = current_quarter(today)
    have, out = set(loaded), []
    while (y, q) <= (cy, cq):
        if (y, q) not in have:
            out.append(f"{y}Q{q}")
        y, q = (y + 1, 1) if q == 4 else (y, q + 1)
    return out


# ------------------------------------------------------------------- writing
def to_spark_fast(spark, df: pd.DataFrame):
    """Arrow-backed createDataFrame with an explicit schema (kb_io.to_spark is row-by-row and
    too slow for ~2M PTP rows). Dates stay int yyyymmdd, like the hand-loaded tables."""
    from pyspark.sql import types as T
    fields_ = []
    for c in df.columns:
        if c in ("QuarterBeginDate", "EffDt", "DelDt"):
            t = T.IntegerType()
        elif c == "MUE_Values":
            t = T.LongType()
        else:
            t = T.StringType()
        fields_.append(T.StructField(c, t, True))
    spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")
    pdf = df.astype(object).where(df.notna(), None)
    return spark.createDataFrame(pdf, schema=T.StructType(fields_))


def table_exists(spark, fqn: str) -> bool:
    return bool(spark.catalog.tableExists(fqn))


def write_edit_table(spark, df: pd.DataFrame, fqn: str, mode: str = "errorifexists"):
    """mode 'errorifexists' for a new quarter table, 'overwrite' only for a replacement decided by
    decide_existing() (a higher revision, or OVERWRITE=True). Delta keeps the replaced version
    (DESCRIBE HISTORY / VERSION AS OF), and the replaced zip stays in the raw archive."""
    import config
    (to_spark_fast(spark, df).write.format(getattr(config, "TABLE_FORMAT", "delta"))
     .mode(mode).option("overwriteSchema", "true").saveAsTable(fqn))


def existing_table_source(spark, fqn: str) -> dict | None:
    """None = no such table. Otherwise what the table was loaded from, read from the TABLE ITSELF
    (acquire writes src_zip/src_sha256 into every row; hand-loaded tables have neither):
    {"known": bool, "src_zip": str|None, "src_sha256": str|None, "revision": int|None}."""
    if not table_exists(spark, fqn):
        return None
    cols = set(spark.table(fqn).columns)
    if not {"src_zip", "src_sha256"} <= cols:
        return {"known": False, "src_zip": None, "src_sha256": None, "revision": None}
    rows = spark.sql(f"SELECT DISTINCT src_zip, src_sha256 FROM {fqn} LIMIT 3").collect()
    if len(rows) != 1 or not rows[0]["src_zip"] or not rows[0]["src_sha256"]:
        # several sources (or blanks) in one table: it was changed outside acquire(); trust none of it
        return {"known": False, "src_zip": "; ".join(str(r["src_zip"]) for r in rows) or None,
                "src_sha256": None, "revision": None}
    z = rows[0]["src_zip"]
    return {"known": True, "src_zip": z, "src_sha256": rows[0]["src_sha256"], "revision": file_revision(z) or 0}


def decide_existing(ex: dict, link: Link, sha256: str | None, overwrite: bool) -> tuple[str, str | None, str]:
    """The table for `link` already exists (ex = existing_table_source()). Returns
    (decision, message, existing_source): decision 'skip' | 'replace' | 'refuse'; existing_source
    says how the TABLE's source relates to this file: same_file | different_file |
    earlier_revision | later_revision | no_provenance.
    C2-15: a higher revision always replaces a lower one (never 'skipped_exists'); a lower revision
    never replaces a higher one, not even with OVERWRITE=True; a revision next to a hand-loaded table
    of unknown origin is refused (the table may or may not already hold it) - a human decides."""
    rev = link.revision or 0
    if not ex.get("known"):
        if overwrite:
            return "replace", "OVERWRITE=True replaced a table that had no acquisition provenance", "no_provenance"
        if rev > 0:
            msg = (f"{link.table} exists without acquisition provenance (hand-loaded?) and CMS has revision "
                   f"r{rev} of this file ({link.name}); the table may still hold the original. Compare them, "
                   f"then re-run with OVERWRITE = True and QUARTERS = {{'{link.label}'}}")
            return "refuse", msg, "no_provenance"
        return "skip", None, "no_provenance"
    ex_rev = ex.get("revision") or 0
    if sha256 and ex.get("src_sha256") == sha256:
        source = "same_file"
    elif ex_rev < rev:
        source = "earlier_revision"
    elif ex_rev > rev:
        source = "later_revision"
    else:
        source = "different_file"
    if rev > ex_rev:
        return "replace", (f"revision r{rev} ({link.name}) replaces {ex.get('src_zip')} (r{ex_rev}) in {link.table}; "
                           f"the replaced zip stays in the raw archive"), source
    if source == "later_revision":
        return "skip", (f"{link.table} holds a later revision ({ex.get('src_zip')}); this older file is not loaded"
                        + (" (OVERWRITE=True does not downgrade a revision)" if overwrite else "")), source
    if overwrite:
        return "replace", "OVERWRITE=True", source
    if source == "same_file":
        return "skip", None, source
    return "skip", (f"{link.table} was loaded from a DIFFERENT file of the same revision ({ex.get('src_zip')}); "
                    f"CMS may have re-issued it - compare, then OVERWRITE = True for {link.label}"), source


@dataclass
class LoadResult:
    quarter: str
    edit: str | None
    service: str | None
    kind: str
    url: str
    table: str | None = None
    # loaded | replaced | skipped_exists | superseded | archived_only | failed
    status: str = ""
    sha256: str | None = None        # C4-09: hash of THIS row's own file (the zip at url), never another's
    bytes: int | None = None
    rows: int | None = None
    fmt: str | None = None
    members: str | None = None
    warning: str | None = None       # needs a human look before 07_build_kb
    error: str | None = None
    loaded_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="seconds"))
    revision: int = 0                # C2-15
    # C4-09 / C2-19: what the TABLE now holds - filled only when this row loaded it from this file
    src_sha256: str | None = None
    src_url: str | None = None       # None for a drop-zone file (fetched by hand; origin URL not known)
    src_member: str | None = None
    src_zip: str | None = None
    rows_loaded: int | None = None
    tolerated_rows: int | None = None    # C2-18: blank / footer / header-repeat lines skipped, counted
    edition_evidence: str | None = None  # C2-16: what in the file confirmed the edition
    existing_source: str | None = None   # same_file | different_file | earlier_revision | later_revision | no_provenance
    replaced_src_zip: str | None = None  # C2-15: what a 'replaced' row replaced
    note: str | None = None              # informational (superseded by, tolerated rows, ...)


def _fetch(l: Link, raw_dir: str, session, download_files: bool) -> dict:
    if download_files and l.url.startswith("http"):
        return download(l, raw_dir, session)
    _assert_zip(l.url)
    return {"path": l.url, "sha256": sha256_file(l.url), "bytes": os.path.getsize(l.url), "status": "drop_zone"}


def acquire(spark, links: list[Link], raw_dir: str, catalog: str, schema: str, *,
            download_files: bool = True, overwrite: bool = False, session=None,
            quarters: set[str] | None = None, cross_check_xlsx: bool = False,
            prev_counts: dict[str, int] | None = None, log=print,
            category_check: str = "strict", existing=None, writer=None) -> list[LoadResult]:
    """Download (or read from the drop zone), parse, validate and load every edit file.
    One file's failure is recorded and does not stop the others; the caller decides go/no-go.

    C2-15: per (quarter, edit, edition) only the highest revision loads (plan_loads); a revision
    replaces a table loaded from a lower one (status 'replaced'). Duplicate files fail.
    C4-09: sha256 is always this row's own file; src_* / rows_loaded only on loaded/replaced rows.
    existing(fqn) -> None | dict and writer(df, fqn, mode) default to Spark; tests inject fakes."""
    session = session or (make_session() if download_files else None)
    links = [l for l in links if not quarters or l.label in quarters]
    plan = plan_loads(links)
    if existing is None:
        existing = (lambda fqn: existing_table_source(spark, fqn)) if spark is not None else (lambda fqn: None)
    if writer is None and spark is not None:
        writer = lambda df, fqn, mode: write_edit_table(spark, df, fqn, mode)       # noqa: E731
    results: list[LoadResult] = []
    for l in links:
        res = LoadResult(quarter=l.label, edit=l.edit, service=l.service, kind=l.kind, url=l.url, table=l.table,
                         revision=l.revision)
        try:
            got = _fetch(l, raw_dir, session, download_files)
            res.sha256, res.bytes = got["sha256"], got["bytes"]       # C4-09: THIS file's own hash, always
            if l.kind != "edits":
                res.status = "archived_only"
                res.note = l.note
                results.append(res)
                log(f"  {l.label} {l.kind:13s} archived ({got['status']})")
                continue
            action, why = plan.get(l.url, ("load", None))
            if action == "duplicate":
                raise DuplicateLinkError(why)
            if action == "superseded":
                res.status, res.note = "superseded", why
                results.append(res)
                log(f"  {l.label} {l.edit}/{l.service:12s} {l.name}: {why} (archived, not loaded)")
                continue
            fqn = f"{catalog}.{schema}.{l.table}"
            ex = existing(fqn)
            mode, notes = "errorifexists", []           # notes: informational; warns: needs a human look
            if ex is not None:
                decision, msg, res.existing_source = decide_existing(ex, l, got["sha256"], overwrite)
                if decision == "refuse":
                    raise ConflictError(msg)
                if decision == "skip":
                    res.status = "skipped_exists"
                    if res.existing_source in ("different_file",):
                        res.warning = msg
                    else:
                        res.note = msg or (None if res.existing_source == "same_file" else
                                           "table exists without acquisition provenance (hand-loaded?) - not overwritten")
                    results.append(res)
                    log(f"  {l.label} {l.edit}/{l.service:12s} table exists - not overwritten ({fqn})"
                        + (f"   {msg}" if msg else ""))
                    continue
                mode = "overwrite"
                res.replaced_src_zip = ex.get("src_zip") or "no_provenance"
                notes.append(msg)
            df, st = parse_zip(got["path"], l.edit, (l.year, l.quarter), cross_check_xlsx=cross_check_xlsx,
                               expected_service=l.service, category_check=category_check)
            src_zip = os.path.basename(got["path"])
            src_url = l.url if l.url.startswith("http") else None
            df["src_zip"] = src_zip
            df["src_sha256"] = got["sha256"]
            df["src_url"] = src_url
            df["loaded_at"] = res.loaded_at
            res.rows, res.fmt = len(df), st["format"]
            res.members = "; ".join(m["member"] for m in st["members"])
            res.edition_evidence = st.get("edition_evidence")
            res.tolerated_rows = sum(m["non_data_rows_skipped"] for m in st["members"])
            prev_key = f"{l.edit}/{l.service}"
            warns = [compare_to_previous(len(df), (prev_counts or {}).get(prev_key))]
            warns += st.get("edition_warnings") or []
            wide = sum(m.get("rows_with_text_outside_header", 0) for m in st["members"])
            if wide:
                warns.append(f"{wide} data rows have text in columns the header does not name (ignored) - "
                             f"check for a shifted column")
            if l.revision:
                # the MUE archive dates 2025-q1-r1 'Effective Jan. 29, 2025': a revision can start
                # mid-quarter, but a quarter table has one value per code for the whole quarter
                warns.append(f"revision r{l.revision}: its values are applied from the quarter start; CMS may "
                             f"have made it effective mid-quarter (see {CMS_MUE_ARCHIVE})")
            res.warning = "; ".join(w for w in warns if w) or None
            if res.tolerated_rows:
                tol: dict = {}
                for m in st["members"]:
                    for k, v in m["tolerated"].items():
                        tol[k] = tol.get(k, 0) + v
                ex_ = [e for m in st["members"] for e in m["non_data_examples"]][:3]
                notes.append(f"{res.tolerated_rows} non-data body rows tolerated "
                             f"{ {k: v for k, v in tol.items() if v} } e.g. {ex_}")
            res.note = "; ".join(n for n in notes if n) or None
            if writer is not None:
                writer(df, fqn, mode)
            res.status = "replaced" if mode == "overwrite" else "loaded"
            # C4-09 / C2-19: provenance of what is now IN the table = this file; set only after the write
            res.src_sha256, res.src_url, res.src_member = got["sha256"], src_url, res.members
            res.src_zip, res.rows_loaded = src_zip, len(df)
            log(f"  {l.label} {l.edit}/{l.service:12s} {len(df):>10,} rows  {st['format']}  -> {fqn}"
                + (f"   ({res.status}: {res.replaced_src_zip})" if res.status == "replaced" else "")
                + (f"   WARNING {res.warning}" if res.warning else ""))
        except Exception as e:
            res.status, res.error = "failed", f"{type(e).__name__}: {str(e)[:800]}"
            log(f"  {l.label} {l.edit}/{l.service} FAILED  {res.error[:300]}")
        results.append(res)
    return results


_LOG_INT_COLUMNS = ("bytes", "rows", "revision", "rows_loaded", "tolerated_rows")


def results_frame(results: list[LoadResult]) -> pd.DataFrame:
    """One acquisition-log row per file. Fixed columns and dtypes whatever the run's content: a
    run whose only file failed used to give 'rows' float64 (-> double) and the next run int64 (->
    long), which a Delta append with mergeSchema can refuse - and then the log of a load is lost."""
    cols = [f.name for f in fields(LoadResult)]
    df = pd.DataFrame([asdict(r) for r in results], columns=cols)
    for c in cols:
        if c in _LOG_INT_COLUMNS:
            df[c] = pd.array([None if v is None or (isinstance(v, float) and v != v) else int(v) for v in df[c]],
                             dtype="Int64")
        else:
            df[c] = pd.Series([None if v is None or (isinstance(v, float) and v != v) else str(v) for v in df[c]],
                              dtype=object, index=df.index)
    return df


def write_log(spark, results: list[LoadResult], fqn: str) -> int:
    """Append the acquisition log. New columns are added (mergeSchema); a column that already exists
    with another type (e.g. 'rows' written as double by an older run) is cast to that type first."""
    import config
    import kb_io
    pdf = results_frame(results)
    if pdf.empty:
        return 0
    sdf = kb_io.to_spark(spark, pdf)
    if table_exists(spark, fqn):
        have = {f.name: f.dataType.simpleString() for f in spark.table(fqn).schema.fields}
        new = {f.name: f.dataType.simpleString() for f in sdf.schema.fields}
        sdf = sdf.selectExpr(*[f"CAST(`{c}` AS {have[c]}) AS `{c}`" if c in have and have[c] != new[c] else f"`{c}`"
                               for c in sdf.columns])
    (sdf.write.format(getattr(config, "TABLE_FORMAT", "delta")).mode("append")
     .option("mergeSchema", "true").saveAsTable(fqn))
    print(f"  wrote {fqn}  ({len(pdf):,} rows, append)")
    return len(pdf)


# ---------------------------------------------------------------- provenance
def _first(*vals):
    for v in vals:
        if v is None or (isinstance(v, float) and v != v) or v is pd.NA:
            continue
        s = str(v).strip()
        if s and s.lower() not in ("nan", "none", "<na>"):
            return v if not isinstance(v, str) else s
    return None


def acquisition_provenance(spark, catalog: str | None = None, schema: str | None = None) -> dict:
    """C2-19: {table_name: {"src_sha256", "src_url", "src_member", "quarter": "YYYYqN", "service",
    "edit_type": "ptp"|"mue", "loaded_at", ...}} for every NCCI table acquire() loaded, from
    config.NCCI_ACQUISITION_LOG: the LATEST successful load (status loaded | replaced) per table.
    {} when the log table does not exist (every table was loaded by hand). A log that exists but
    cannot be read raises kb_io.TableAccessError - it is never treated as 'no provenance'.
    Extra keys: src_zip, rows_loaded, status. src_url is None for a drop-zone file.
    Rows written before 2026-10-02 have no src_* columns; for them (status 'loaded' only) sha256 /
    url / members WERE the loaded file. Cross-check for the caller: an acquired table carries the
    same src_sha256 in every row; a disagreement means the table was changed outside acquire()."""
    import config
    import kb_io
    fqn = config.NCCI_ACQUISITION_LOG
    if catalog or schema:
        fqn = f"{catalog or config.CATALOG}.{schema or config.SCHEMA}.{fqn.rsplit('.', 1)[-1]}"
    log = kb_io.table_or_none(spark, fqn)
    if log is None or log.empty:
        return {}
    log = log.copy()
    for c in ("status", "kind", "table", "loaded_at", "sha256", "src_sha256", "url", "src_url", "members",
              "src_member", "quarter", "service", "edit", "src_zip", "rows", "rows_loaded"):
        if c not in log.columns:
            log[c] = None
    ok = log[log["status"].isin(LOADED_STATUSES) & log["table"].notna()
             & log["kind"].map(lambda k: _first(k) in (None, "edits"))]
    ok = ok.assign(_t=ok["loaded_at"].map(lambda v: _first(v) or "")).sort_values("_t", kind="stable")
    out: dict[str, dict] = {}
    for r in ok.to_dict("records"):                       # later rows overwrite: latest load per table wins
        url = _first(r.get("url"))
        src_url = _first(r.get("src_url"), url if str(url or "").startswith("http") else None)
        rows_loaded = _first(r.get("rows_loaded"), r.get("rows"))
        out[str(r["table"])] = {
            "src_sha256": _first(r.get("src_sha256"), r.get("sha256")),
            "src_url": src_url,
            "src_member": _first(r.get("src_member"), r.get("members")),
            "quarter": _first(r.get("quarter")),
            "service": _first(r.get("service")),
            "edit_type": _first(r.get("edit")),
            "loaded_at": _first(r.get("loaded_at")),
            "src_zip": _first(r.get("src_zip"), _basename(url) if url else None),
            "rows_loaded": int(rows_loaded) if rows_loaded is not None else None,
            "status": _first(r.get("status")),
        }
    return out
