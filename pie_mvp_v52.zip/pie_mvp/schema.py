"""
schema.py  -  the rule object. This IS the product.

Everything downstream (detector SQL, gap analysis, review workbook, narratives)
reads this and nothing else. Interpretation happens here, once, and is
human-reviewable; downstream is mechanical translation only.

MVP changes vs the PoC:
  * rule_id is derived from CONTENT (source + statement + predicate + dates).
    The PoC hashed codes + predicate type + source, so nine different Chapter 10
    rules with codes=[] shared one id.
  * 'enforcement' is no longer a plane. A claims outcome ("a hard-denial pair
    was paid") is a finding the detector labels, not a policy authority. It is
    still accepted on read so old authoring modules do not crash; the build
    re-derives plane from the predicate anyway.
  * Predicate grammar gained max_units_per_dos, max_units_per_period,
    code_not_covered (compiled) and keeps the not-yet-compiled types so rules
    can be authored ahead of the compiler and land as leads, never as errors.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

# ---------------------------------------------------------------- vocab
PLANES = {"coding_edit", "coverage_scope", "medical_necessity"}
LEGACY_PLANES = {"enforcement"}          # accepted on read, never written

BINDING = {"mandatory", "state_plan", "state_policy", "contract", "guidance", "advisory"}
BINDING_RANK = {"mandatory": 0, "state_plan": 1, "state_policy": 2,
                "contract": 3, "guidance": 4, "advisory": 5}

# Closed predicate grammar. COMPILED types have a SQL compiler in detector_gen;
# AUTHORABLE types are legal to write but land as review leads until compiled.
PREDICATE_TYPES_COMPILED = {
    "code_pair_prohibited",    # code_a, code_b, modifier_indicator, service_category
    "max_units_per_line",      # code, threshold                       (NCCI MUE / MAI 1)
    "max_units_per_dos",       # code, threshold, mai                  (NCCI MUE MAI 2/3)
    "max_units_per_day",       # code, threshold, scope (optional)     (state daily cap, per member - or per member +
                               #                                        provider with scope member_provider_day)
    "max_units_per_period",    # code|code_set, threshold, period      (month|year|benefit_year)
    "code_not_covered",        # code|code_set
    "provider_type_allowed",   # code|code_set, provider_types, provider_role (billing | servicing; default billing)
}
PREDICATE_TYPES_AUTHORABLE = {
    "max_dollars_per_period",  # needs paid amount + benefit year + often age
    "frequency_limit",
    "modifier_required",
    "not_checkable",           # reason
    "edit_failure",            # legacy; dropped by the build
}
PREDICATE_TYPES = PREDICATE_TYPES_COMPILED | PREDICATE_TYPES_AUTHORABLE

# ONE canonical list of reasons a rule cannot be checked on a paid claim. The extraction prompt,
# the reviewer brief, the review ingest and the registers all read it from here (it used to exist
# in three different versions, and 69 of 146 reviewer fixes in the first run only relabelled it).
# Ordered: a reviewer or model takes the FIRST that fits.
PROMPT_REASONS = (
    ("requires_medical_record",   "medical necessity, documentation, diagnosis justification, clinical judgement"),
    ("requires_member_attribute", "a member fact not on the claim: program (ALTCS, EPSDT status), setting, "
                                  "enrollment, residence, inpatient stay. AGE IS ON THE CLAIM (use the age condition)"),
    ("process_obligation",        "a provider duty: register, enroll, notify, obtain/attach a form, keep records"),
    ("policy_reference",          "adopts or points to another source (\"AHCCCS follows CCI\", \"see AMPM 310\")"),
    ("ambiguous_source",          "the text is unclear, conditional on something unstated, or contradicts itself"),
    ("cross_source_conflict",     "conflicts with another policy source"),
    ("no_claim_field",            "needs a claim field the claims table does not have (revenue code, NDC, bill type, "
                                  "taxonomy, time of day, rendering credential)"),
    ("unit_incommensurability",   "the limit and the billing unit cannot be compared (hours vs per diem)"),
    ("predicate_not_in_grammar",  "checkable in principle but not expressible yet: code ranges, episodes, visit "
                                  "counting, lifetime caps, per-provider period caps"),
)
NOT_CHECKABLE_REASONS = {r for r, _ in PROMPT_REASONS} | {
    "missing_claim_field",                 # set by the gate only (a required claim field is not mapped)
    "monthly_aggregation_not_in_grammar",  # legacy
}

# --------------------------------------------------- predicate grammar contract
# Code-pair co-occurrence scope. member_provider_day = same member, same servicing provider, same date
# of service (how CMS adjudicates NCCI PTP). member_day = same member and date, ANY provider (only when
# the policy text says so, e.g. "for the same member"). A state pair with no scope compiles to the
# NARROW scope (member_provider_day): a wider reading must be an explicit, signed decision.
# 2026-10-04 (v5.2): max_units_per_day takes the same optional "scope". Its default stays member_day (the member's units
# from ANY provider on one date - every daily cap written before v5.2 keeps exactly its SQL); member_provider_day adds
# them per servicing provider (SB's reading of the AHCCCS daily limits table: "Procedure Maximum Occurrence" = units per
# member + provider + date of service). Either way the scope is part of what the reviewer signs.
# 2026-10-04 (v5.2, QUERY_SEMANTICS v2.6): "member_servicing_billing_day" = the same member, date, servicing provider
# AND billing provider (a missing id never matches) - "same provider" under both readings of the A* legend
PAIR_SCOPES = ("member_provider_day", "member_day", "member_servicing_billing_day")
# provider_type_allowed roles: billing (BProv_Type), servicing (SProv_Type), and (v2.6) billing_or_rendering = the
# billing type, except a group billing type (config.GROUP_BILLING_PROVIDER_TYPES) -> the servicing (rendering) type
PROVIDER_ROLES = ("billing", "servicing", "billing_or_rendering")
PERIODS = ("month", "year", "benefit_year")
# Age condition (member age ON THE DATE OF SERVICE, from config.CLAIM_COLS['dob']):
#   {"min": 21}              21 and older                (age >= 21)
#   {"below": 21}            under 21 (EPSDT age)         (age < 21)
#   {"min": 21, "below": 65} 21 through 64
# Allowed on every compiled predicate type. A rule whose `population` is not "all" compiles only when
# its population is fully expressed by this condition (the reviewer signs that), otherwise it is a lead.
AGE_KEYS = ("min", "below")
# Optional qualifiers that never widen a rule, only label its findings for review:
#   "exception": "<verbatim exception clause>"  e.g. "unless the additional transport is a separately
#                identifiable service" -> findings are 'verify_exception', never a plain violation
#   "discretionary": true   the text says MAY be denied -> findings are 'discretionary'
QUALIFIER_KEYS = ("exception", "discretionary")

REQUIRED_KEYS = {
    "code_pair_prohibited": ("code_a", "code_b"),
    "max_units_per_line": ("code", "threshold"),
    "max_units_per_dos": ("code", "threshold"),
    "max_units_per_day": ("threshold",),            # + code or code_set
    "max_units_per_period": ("threshold", "period"),  # + code or code_set
    "code_not_covered": (),                          # + code or code_set
    "max_dollars_per_period": ("threshold", "period"),
    "frequency_limit": ("threshold",),
    "modifier_required": ("modifier",),
    "provider_type_allowed": ("provider_types",),
    "not_checkable": ("reason",),
}
_NEEDS_CODES = {"max_units_per_day", "max_units_per_period", "code_not_covered", "max_dollars_per_period",
                "modifier_required", "provider_type_allowed", "frequency_limit"}


def integral(v):
    """int, integral float (4.0) or digit string ('4') -> int; anything else (4.9, True, 'four') -> None."""
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        return int(v) if v.is_integer() else None
    if isinstance(v, str) and v.strip().isdigit():
        return int(v.strip())
    return None


def norm_code(c) -> str:
    return str(c).strip().upper()


def predicate_codes(p: dict) -> list:
    out = [norm_code(p[k]) for k in ("code_a", "code_b", "code") if p.get(k) not in (None, "")]
    out += [norm_code(c) for c in (p.get("code_set") or [])]
    return list(dict.fromkeys(out))


def normalize_indicator(v, origin: str | None = None):
    """'0' or '1', or None if invalid. 0/1 ints, '0.0', ' 1 ' are accepted. A state pair with no or a
    blank indicator means 'no modifier bypasses this prohibition' ('0'); an NCCI row must say."""
    if v is None or (isinstance(v, float) and v != v) or str(v).strip() == "":
        return None if origin == "ncci" else "0"
    s = str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s if s in ("0", "1") else None


def validate_age(a) -> tuple:
    if not isinstance(a, dict) or not a or set(a) - set(AGE_KEYS):
        return False, f"age must be a dict with keys {AGE_KEYS} (got {a!r})"
    vals = {}
    for k, v in a.items():
        n = integral(v)
        if n is None or not (0 <= n <= 125):
            return False, f"age.{k} must be a whole number 0-125 (got {v!r})"
        vals[k] = n
    if "min" in vals and "below" in vals and vals["min"] >= vals["below"]:
        return False, f"age.min {vals['min']} must be < age.below {vals['below']}"
    return True, ""


def validate_predicate(p: dict, strict_reason: bool = False, origin: str | None = None) -> tuple:
    """Structural check of a predicate against the closed grammar. (ok, why).

    strict_reason=True also requires a not_checkable reason from NOT_CHECKABLE_REASONS: a human-authored
    reason must be a known category; extraction does not insist, so a model rule with an off-list reason
    is still shown to a reviewer instead of being dropped."""
    if not isinstance(p, dict):
        return False, "predicate is not an object"
    t = p.get("type")
    if t not in PREDICATE_TYPES:
        return False, f"unknown predicate type {t!r}"
    for k in REQUIRED_KEYS.get(t, ()):
        if p.get(k) in (None, "", []):
            return False, f"{t} missing {k}"
    codes = predicate_codes(p)
    if t in _NEEDS_CODES and not codes:
        return False, f"{t} needs code or code_set"
    for c in codes:
        if not (c.isascii() and c.isalnum()):
            return False, f"bad code {c!r}"
    if t in ("max_units_per_line", "max_units_per_dos") and p.get("code_set"):
        return False, f"{t} takes one code, not a code_set"          # the per-line compiler reads p['code']
    if p.get("code") not in (None, "") and p.get("code_set") not in (None, "", []):
        # oracle F-04 (2026-10-02): the compilers read code_set and ignored code, while the reviewer saw both
        return False, f"{t} has both code and code_set - give one (list every code in code_set)"
    if t == "code_pair_prohibited":
        if norm_code(p["code_a"]) == norm_code(p["code_b"]):
            return False, "self pair"
        if "modifier_indicator" in p and normalize_indicator(p.get("modifier_indicator"), origin) is None:
            return False, f"modifier_indicator must be '0' or '1' (got {p.get('modifier_indicator')!r})"
        if p.get("scope") not in (None, "") and p.get("scope") not in PAIR_SCOPES:
            return False, f"scope must be one of {PAIR_SCOPES} (got {p.get('scope')!r})"
        # v2.6: an AHCCCS Same Day pair disallowed in both directions says so (the finding text, 08's dollar report)
        if "both_ways" in p and not isinstance(p["both_ways"], bool):
            return False, f"both_ways must be true or false (got {p['both_ways']!r})"
    if t == "max_units_per_day" and p.get("scope") not in (None, "") and p.get("scope") not in PAIR_SCOPES:
        # 2026-10-04 (v5.2): an unknown scope is not read as either scope - the rule becomes a lead with this reason
        return False, f"scope must be one of {PAIR_SCOPES} (got {p.get('scope')!r})"
    if t == "provider_type_allowed":
        pts = p.get("provider_types")
        if not isinstance(pts, (list, tuple)) or not pts:
            return False, "provider_types must be a non-empty list of provider type codes"
        import ncci_routing                       # the claims column's clean-up: ' 8 ' / 8 / '8.0' -> '08'
        for v in pts:
            tv = ncci_routing.norm_type(v) or ""
            if not tv or not (tv.isascii() and tv.isalnum()) or len(tv) > 4:
                return False, f"bad provider type code {v!r}"
        if p.get("provider_role") not in (None, "") + PROVIDER_ROLES:
            return False, f"provider_role must be one of {PROVIDER_ROLES} (got {p.get('provider_role')!r})"
    if t in ("max_units_per_period", "max_dollars_per_period") and p.get("period") not in PERIODS:
        return False, f"bad period {p.get('period')!r}"
    if t == "frequency_limit" and p.get("period") not in (None,) + PERIODS:
        return False, f"bad period {p.get('period')!r}"
    if t == "modifier_required":
        m = str(p.get("modifier") or "").strip().upper()
        if not (len(m) == 2 and m.isascii() and m.isalnum()):
            return False, f"modifier must be ONE two-character modifier (got {p.get('modifier')!r})"
    if "threshold" in p:
        n = integral(p["threshold"])
        if n is None:
            return False, f"threshold not an integer ({p['threshold']!r})"   # 4.9 must not become 4
        if n <= 0:
            return False, "threshold must be positive"
    if "age" in p and p["age"] not in (None, {}):
        ok, why = validate_age(p["age"])
        if not ok:
            return False, why
    if "exception" in p and p["exception"] is not None and not str(p["exception"]).strip():
        return False, "exception must quote the exception clause"
    if "discretionary" in p and not isinstance(p["discretionary"], bool):
        return False, "discretionary must be true/false"
    if t == "not_checkable" and strict_reason and p.get("reason") not in NOT_CHECKABLE_REASONS:
        return False, (f"unknown not_checkable reason {p.get('reason')!r} "
                       f"(use one of {[r for r, _ in PROMPT_REASONS]})")
    return True, ""


def age_label(a) -> str:
    """Plain-English form of an age condition, for statements and the review workbook."""
    if not a:
        return "all ages"
    lo, hi = a.get("min"), a.get("below")
    if lo is not None and hi is not None:
        return f"age {lo} through {int(hi) - 1}"
    if lo is not None:
        return f"age {lo} and older"
    return f"under {hi}"


# ------------------------------------------------------------ stable id
def content_signature(d: dict) -> str:
    pred = d.get("predicate") or {}
    # 2026-10-04 (v5.2, critic F11): an AHCCCS table rule is (table, version, cell / row) - its END date only says when
    # the next version arrived, so loading a newer version must not re-number every rule of the older one
    end = None if d.get("origin") == "ahcccs_table" else d.get("end_date")
    parts = [d.get("origin"), d.get("source_doc"), d.get("source_locator"),
             (d.get("statement") or "").strip(),
             json.dumps(pred, sort_keys=True, default=str),
             d.get("effective_date"), end]
    # C4-06: population is part of WHAT a rule says. Two rules identical except "all members" vs
    # "members under 21" used to share an id, and the dedupe silently dropped one. Appended only
    # when it is not the default, so every existing all-member id (and every NCCI id) is unchanged.
    pop = (d.get("population") or "all").strip().lower()
    if pop not in ("all", "", "any", "all members"):
        parts.append(f"population={pop}")
    return hashlib.sha256("|".join("" if p is None else str(p) for p in parts).encode()).hexdigest()


def stable_rule_id(d: dict) -> str:
    # 2026-10-04 (v5.2): rules read from the AHCCCS rule tables (origin "ahcccs_table", ahcccs_tables.py) are TBL-, so a
    # finding's rule id says at a glance it came from a table cell, not a manual page; the hash part is unchanged (the
    # origin was always in content_signature), and every other prefix is unchanged
    prefix = {"ncci": "NCCI", "extracted": "EXT", "ahcccs_table": "TBL"}.get(d.get("origin"), "MAN")
    return f"{prefix}-{content_signature(d)[:16]}"


# ------------------------------------------------------------------ Rule
@dataclass
class Rule:
    origin: str                          # "ncci" | "manual" (hand-authored) | "extracted" (PDF pipeline)
                                         # | "ahcccs_table" (AHCCCS rule tables, v5.2: a state rule read from a cell)
    plane: str                           # see PLANES
    binding_status: str                  # see BINDING
    statement: str                       # one plain-English sentence, the rule as interpreted
    predicate: dict                      # structured form; type in PREDICATE_TYPES
    codes: list = field(default_factory=list)
    population: str = "all"
    machine_checkable: bool = True
    not_checkable_reason: Optional[str] = None
    required_claim_fields: list = field(default_factory=list)
    ambiguity_flag: bool = False
    ambiguity_note: Optional[str] = None
    alternates: list = field(default_factory=list)      # [{"reading":..., "locator":...}]
    source_doc: str = ""
    source_locator: str = ""             # page / section / row
    source_url: str = ""
    doc_version: str = ""
    doc_hash: str = ""
    effective_date: Optional[str] = None # ISO; None = from the beginning of the data
    end_date: Optional[str] = None       # ISO, inclusive; None = still in force
    deactivated: bool = False
    supersedes: Optional[list] = None
    notes: str = ""
    rule_id: str = ""
    # stable content key from the extraction pipeline (EXT-<key>); carried through
    # normalization so an approved review decision joins to the exact executable rule.
    # None for NCCI / hand-authored rules. NOT part of content_signature (ids unchanged).
    extraction_key: Optional[str] = None
    # how this rule relates to others covering the same code (rule_normalize / registers);
    # e.g. "ncci_editions_agree", "ncci_editions_disagree:most_permissive". Not part of the id.
    reconciliation: Optional[str] = None
    # the policy sentence(s) the rule was read from, and the section they sit in (extracted rules).
    # Carried to policy_rules / policy_rules_history so every finding reaches its exact text span.
    # Not part of the id.
    verbatim_quote: Optional[str] = None
    section_id: Optional[str] = None

    # --- lifecycle -----------------------------------------------------
    def assign_id(self) -> "Rule":
        self.rule_id = stable_rule_id(self.to_dict())
        return self

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Rule":
        known = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**known)

    # --- validation ----------------------------------------------------
    def problems(self) -> list[str]:
        """Structural problems that make a rule unusable (-> rejected by the gate)."""
        p = []
        if not (self.statement or "").strip():
            p.append("empty statement")
        if not (self.source_doc or "").strip():
            p.append("no source_doc")
        if not isinstance(self.predicate, dict) or not self.predicate.get("type"):
            p.append("predicate has no type")
        if self.plane not in PLANES | LEGACY_PLANES:
            p.append(f"unknown plane {self.plane!r}")
        if self.binding_status not in BINDING:
            p.append(f"unknown binding_status {self.binding_status!r}")
        return p
