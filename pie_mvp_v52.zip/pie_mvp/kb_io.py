"""
kb_io.py  -  pandas -> Delta without schema-inference surprises.

spark.createDataFrame(pdf) infers types from values. A column that is all None
(common: end_date, reviewer, error, sql for leads on a small run) cannot be
inferred and the write fails with "Can not merge type" / "can not infer schema".
This helper builds an explicit schema from pandas dtypes instead: bool -> boolean,
int -> long, float -> double, everything else -> string (None preserved).

C4-13: inference alone still let an APPEND change a column's type from batch to batch
(a run with one failed chapter turned policy_extraction_log.sections from bigint into
double; an all-empty Excel column became DOUBLE in the review log). So:
  * write_table(..., schema={col: type}) pins types explicitly (a pyspark DataType or a
    name: string | long | int | double | boolean | date | timestamp);
  * on append, a column the target table already has keeps the TABLE's type, and a
    column that is all-null in this batch is written as string, never DOUBLE.
C4-18: an EMPTY frame written in overwrite mode replaces the table with an empty one
(previous build's rows removed, schema kept) instead of silently keeping old rows.
C4-11: write_run_rows() appends one extraction run's rows after removing any rows of the
same run_id already in the table, so re-running 05 on a run folder never doubles them.
"""
from __future__ import annotations

import json

import pandas as pd


def _spark_types():
    from pyspark.sql import types as T
    return T


# ------------------------------------------------------------- type helpers
_TYPE_NAMES = {
    "string": "StringType", "str": "StringType",
    "long": "LongType", "bigint": "LongType", "int": "IntegerType", "integer": "IntegerType",
    "double": "DoubleType", "float": "DoubleType",
    "boolean": "BooleanType", "bool": "BooleanType",
    "date": "DateType", "timestamp": "TimestampType",
}
# what a type name means for value coercion
_KIND = {"string": "string", "str": "string", "long": "long", "bigint": "long", "int": "long", "integer": "long",
         "short": "long", "byte": "long", "double": "double", "float": "double", "boolean": "boolean",
         "bool": "boolean", "date": "date", "timestamp": "timestamp", "timestamp_ntz": "timestamp"}


def _resolve_type(T, t):
    """A pyspark DataType instance, or a name from _TYPE_NAMES -> a DataType instance."""
    if isinstance(t, str):
        name = _TYPE_NAMES.get(t.strip().lower())
        if not name:
            raise ValueError(f"unknown column type {t!r}; use one of {sorted(_TYPE_NAMES)}")
        return getattr(T, name)()
    return t


def _type_name(t) -> str:
    if isinstance(t, str):
        return t.strip().lower()
    tn = getattr(t, "typeName", None)
    if callable(tn):
        try:
            return str(tn()).lower()
        except Exception:
            pass
    return type(t).__name__.lower().replace("type", "") or str(t).lower()


def _kind(t) -> str:
    """string | long | double | boolean | date | timestamp | other (decimal, arrays, ...)."""
    return _KIND.get(_type_name(t), "other")


def _is_null(v) -> bool:
    if v is None:
        return True
    if isinstance(v, (list, dict, tuple, set)):
        return False
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _coerce(s: pd.Series, kind: str, col: str) -> pd.Series:
    """Values of one column -> Python values Spark accepts for `kind`. Nulls (None/NaN/NaT) stay None."""
    if kind == "other":
        return s
    int_like_float = (pd.api.types.is_float_dtype(s)
                      and all(float(v).is_integer() for v in s.dropna()))

    def one(v):
        if _is_null(v):
            return None
        if kind == "string":
            if isinstance(v, (list, dict)):
                return json.dumps(v, default=str)
            if int_like_float and isinstance(v, float):
                return str(int(v))              # 7.0 in a NaN-promoted int column is "7", not "7.0"
            return str(v)
        if kind == "long":
            if isinstance(v, bool):
                return int(v)
            if isinstance(v, float):
                if not v.is_integer():
                    raise TypeError(f"column {col!r}: {v!r} is not a whole number but the column is integer-typed")
                return int(v)
            try:
                return int(v)
            except (TypeError, ValueError):
                raise TypeError(f"column {col!r}: {v!r} does not fit an integer column") from None
        if kind == "double":
            try:
                return float(v)
            except (TypeError, ValueError):
                raise TypeError(f"column {col!r}: {v!r} does not fit a double column") from None
        if kind == "boolean":
            if isinstance(v, str):
                t = v.strip().lower()
                if t in ("true", "t", "yes", "y", "1"):
                    return True
                if t in ("false", "f", "no", "n", "0", ""):
                    return False
                raise TypeError(f"column {col!r}: {v!r} is not a boolean")
            return bool(v)
        if kind == "date":
            return pd.Timestamp(v).date()
        if kind == "timestamp":
            return pd.Timestamp(v).to_pydatetime()
        return v
    # a Python list, not Series.map: map() re-infers a dtype, and an Int64 column with a null came back as
    # float64 (2 -> 2.0), which a LongType column then refused on the second append (found by the v5 e2e)
    return pd.Series([one(v) for v in s.tolist()], index=s.index, dtype=object)


def _plan(pdf: pd.DataFrame, schema: dict | None):
    """(converted frame, [(column, DataType)]) - explicit schema first, then inference from dtypes."""
    T = _spark_types()
    pdf = pdf.copy()
    schema = schema or {}
    fields = []
    for c in pdf.columns:
        s = pdf[c]
        if c in schema:
            t = _resolve_type(T, schema[c])
            pdf[c] = _coerce(s, _kind(t), str(c))
        elif pd.api.types.is_bool_dtype(s):
            t = T.BooleanType()
            pdf[c] = s.astype(bool)
        elif pd.api.types.is_integer_dtype(s):
            t = T.LongType()
        elif pd.api.types.is_float_dtype(s):
            t = T.DoubleType()
            pdf[c] = s.astype(float)
        else:
            t = T.StringType()
            pdf[c] = s.map(lambda v: None if v is None or (isinstance(v, float) and pd.isna(v))
                           else (json.dumps(v, default=str) if isinstance(v, (list, dict)) else str(v)))
        fields.append((str(c), t))
    return pdf, fields


def to_spark(spark, pdf: pd.DataFrame, schema: dict | None = None):
    """pandas -> Spark with an explicit schema. `schema` ({col: type}) pins the listed columns;
    the rest are inferred from pandas dtypes (see the module docstring)."""
    T = _spark_types()
    pdf, fields = _plan(pdf, schema)
    pdf = pdf.astype(object).where(pdf.notna(), None)
    # Arrow path (spark falls back to row-by-row on its own if Arrow cannot convert): the old
    # values.tolist() route took minutes for the ~500k-row policy_rules / policy_detectors.
    try:
        spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")
    except Exception:
        pass
    return spark.createDataFrame(pdf, schema=T.StructType([T.StructField(n, t, True) for n, t in fields]))


_NOT_FOUND_MARKERS = ("TABLE_OR_VIEW_NOT_FOUND", "SCHEMA_NOT_FOUND", "does not exist", "cannot be found",
                      "not found", "NoSuchTableException", "AnalysisException: Table")


def _is_not_found(e: Exception) -> bool:
    msg = f"{type(e).__name__}: {e}"
    return any(m.lower() in msg.lower() for m in _NOT_FOUND_MARKERS) and "ACCESS_DENIED" not in msg.upper()


class TableAccessError(RuntimeError):
    """A table exists (or may exist) but could not be read. NEVER treat this as 'no rows'."""


def table_or_none(spark, fqn: str) -> pd.DataFrame | None:
    """Read a table to pandas. Returns None ONLY when the table does not exist.

    Any other failure - CLOUD_ACCESS_DENIED / 403 on the metastore storage, a cluster
    without Unity Catalog access, a transient error - is raised as TableAccessError.
    On 2026-09-21 a bare `except: return None` turned a 403 on state_rules into an
    empty frame, and the merge step then tried to OVERWRITE the reviewed rules table
    with nothing; only the skip-on-empty guard in write_table stopped it.
    (That guard now lives in state_rules.write_state_rules - C4-18 made write_table
    honour an empty overwrite for every other table.)
    """
    try:
        return spark.table(fqn).toPandas()
    except Exception as e:
        msg = f"{type(e).__name__}: {e}"
        if _is_not_found(e):
            return None
        raise TableAccessError(
            f"could not read {fqn} - this is NOT an empty table. If the message mentions CLOUD_ACCESS_DENIED / "
            f"403 / AuthorizationFailure, this cluster's identity cannot reach the Unity Catalog storage; use a "
            f"UC-enabled cluster (the one the summarization pipeline's CPU notebook uses). Original: {msg[:600]}"
        ) from e


def _existing_schema(spark, fqn: str, strict: bool = False):
    """The target table's StructType, or None when it does not exist. strict=True raises
    TableAccessError on any other failure (used where 'absent' would hide old rows)."""
    try:
        return spark.table(fqn).schema
    except Exception as e:
        if _is_not_found(e) or not strict:
            return None
        raise TableAccessError(f"could not describe {fqn} (NOT treated as absent): {type(e).__name__}: {e}") from e


def _types_of(struct) -> dict:
    return {f.name: f.dataType for f in getattr(struct, "fields", []) or []}


def _write_empty(spark, pdf: pd.DataFrame, fqn: str, mode: str, schema: dict | None, fmt: str) -> int:
    """C4-18: an empty result REPLACES the previous one in overwrite mode. Skipping the write used to
    leave e.g. last build's ambiguity register in place, presented as this build's."""
    if mode != "overwrite":
        print(f"  (skipped {fqn}: no rows to {mode})")
        return 0
    T = _spark_types()
    struct = _existing_schema(spark, fqn, strict=True)
    if struct is None:
        if len(pdf.columns) == 0:
            print(f"  (skipped {fqn}: no rows, no columns, and the table does not exist - nothing to create)")
            return 0
        _, fields = _plan(pdf, schema)
        struct = T.StructType([T.StructField(n, t, True) for n, t in fields])
        how = "created as an EMPTY table"
    else:
        how = "REPLACED with an empty table (the previous rows are gone; schema kept)"
    (spark.createDataFrame([], struct).write.format(fmt).mode("overwrite")
     .option("overwriteSchema", "true").saveAsTable(fqn))
    print(f"  wrote {fqn}  (0 rows, overwrite): {how}")
    return 0


def write_table(spark, rows_or_df, fqn: str, mode: str = "overwrite", schema: dict | None = None) -> int:
    """Write rows (list of dicts or a DataFrame) to fqn. `schema` = {col: type} pins column types
    (C4-13) of a new table / new columns. On append, columns the table already has keep the
    table's types and an all-null column is string. An empty frame in overwrite mode empties the
    table (C4-18)."""
    pdf = rows_or_df if isinstance(rows_or_df, pd.DataFrame) else pd.DataFrame(rows_or_df)
    import config
    fmt = getattr(config, "TABLE_FORMAT", "delta")
    if pdf.empty:
        return _write_empty(spark, pdf, fqn, mode, schema, fmt)
    eff = dict(schema or {})
    if mode == "append":
        existing = _types_of(_existing_schema(spark, fqn))
        for c in pdf.columns:
            if c in existing and _kind(existing[c]) != "other":
                # the TABLE's type wins, even over `schema`: appending must never fight the column type
                # an earlier run created (no bigint -> double drift, no merge conflict)
                eff[c] = existing[c]
            elif c not in eff and pdf[c].map(_is_null).all():
                eff[c] = "string"                        # all-null text is never DOUBLE
    w = to_spark(spark, pdf, schema=eff).write.format(fmt).mode(mode)
    w = w.option("overwriteSchema", "true") if mode == "overwrite" else w.option("mergeSchema", "true")
    w.saveAsTable(fqn)
    print(f"  wrote {fqn}  ({len(pdf):,} rows, {mode})")
    return len(pdf)


def _sql_lit(v) -> str:
    return "'" + str(v).replace("\\", "\\\\").replace("'", "\\'") + "'"


def write_run_rows(spark, rows_or_df, fqn: str, run_id: str, schema: dict | None = None,
                   col: str = "run_id") -> int:
    """C4-11: append ONE extraction run's rows idempotently. Rows of the same run_id already in the
    table (an earlier persist of the same run folder) are removed first - DELETE on Delta, or
    read-filter-overwrite where DELETE is unsupported (the offline e2e uses parquet) - so re-running
    05 never doubles inventory/sections/log/dropped/changes/outcomes. Every row is stamped with
    run_id (inventory rows did not carry one). Returns the number of rows appended."""
    if not run_id:
        raise ValueError(f"write_run_rows({fqn}): run_id is required")
    pdf = rows_or_df.copy() if isinstance(rows_or_df, pd.DataFrame) else pd.DataFrame(rows_or_df)
    if len(pdf.columns) or len(pdf):
        if col not in pdf.columns:
            pdf[col] = run_id
        else:
            pdf[col] = pdf[col].map(lambda v: run_id if _is_null(v) or str(v).strip() == "" else str(v))
    ids = sorted({str(run_id)} | (set(pdf[col].astype(str)) if col in pdf.columns else set()))
    struct = _existing_schema(spark, fqn)
    if struct is not None:
        if col in _types_of(struct):
            _delete_runs(spark, fqn, col, ids)
        else:
            print(f"  note: {fqn} has no {col} column yet - rows of persists made before C4-11 cannot be matched "
                  f"to a run and are kept as they are")
    if pdf.empty:
        print(f"  (nothing to append to {fqn} for run {run_id})")
        return 0
    return write_table(spark, pdf, fqn, mode="append", schema=schema)


def _delete_runs(spark, fqn: str, col: str, ids: list[str]) -> int:
    where = f"`{col}` IN ({', '.join(_sql_lit(i) for i in ids)})"
    n = int(spark.sql(f"SELECT COUNT(*) AS n FROM {fqn} WHERE {where}").collect()[0][0])
    if not n:
        return 0
    import config
    try:
        spark.sql(f"DELETE FROM {fqn} WHERE {where}")
        how = "DELETE"
    except Exception as e:
        if getattr(config, "TABLE_FORMAT", "delta") == "delta":
            raise                                # Delta supports DELETE: a failure is real (permission, conflict)
        # not Delta (the offline e2e's parquet): rewrite the table without those rows
        old = spark.table(fqn).toPandas()
        types = _types_of(spark.table(fqn).schema)
        keep = old[~old[col].map(lambda v: (not _is_null(v)) and str(v) in set(ids))]
        write_table(spark, keep, fqn, mode="overwrite", schema=types)
        how = f"rewrite ({type(e).__name__} on DELETE)"
    print(f"  {fqn}: removed {n:,} row(s) of run {', '.join(ids)} from an earlier persist ({how}) - "
          f"a re-run of the same run never doubles it")
    return n
